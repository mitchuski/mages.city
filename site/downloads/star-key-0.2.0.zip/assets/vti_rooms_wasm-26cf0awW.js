import { n as e } from "./rolldown-runtime-Dd_uD5pT.js";
let r, i, a, o, s, c;
let __tla = (async () => {
  let t, n;
  t = `/assets/vti_rooms_wasm_bg-Bwtqcna2.wasm`;
  n = async (e2 = {}, t2) => {
    let n2;
    if (t2.startsWith(`data:`)) {
      let r2 = t2.replace(/^data:.*?base64,/, ``), i2;
      if (typeof Buffer == `function` && typeof Buffer.from == `function`) i2 = Buffer.from(r2, `base64`);
      else if (typeof atob == `function`) {
        let e3 = atob(r2);
        i2 = new Uint8Array(e3.length);
        for (let t3 = 0; t3 < e3.length; t3++) i2[t3] = e3.charCodeAt(t3);
      } else throw Error(`Cannot decode base64-encoded data URL`);
      n2 = await WebAssembly.instantiate(i2, e2);
    } else {
      let r2 = await fetch(t2), i2 = r2.headers.get(`Content-Type`) || ``;
      if (`instantiateStreaming` in WebAssembly && i2.startsWith(`application/wasm`)) n2 = await WebAssembly.instantiateStreaming(r2, e2);
      else {
        let t3 = await r2.arrayBuffer();
        n2 = await WebAssembly.instantiate(t3, e2);
      }
    }
    return n2.instance.exports;
  };
  r = class e2 {
    static __wrap(t2) {
      let n2 = Object.create(e2.prototype);
      return n2.__wbg_ptr = t2, O.register(n2, n2.__wbg_ptr, n2), n2;
    }
    __destroy_into_raw() {
      let e3 = this.__wbg_ptr;
      return this.__wbg_ptr = 0, O.unregister(this), e3;
    }
    free() {
      let e3 = this.__destroy_into_raw();
      Q.__wbg_fileopener_free(e3, 0);
    }
    finish() {
      let e3, t2;
      try {
        let c2 = Q.__wbindgen_add_to_stack_pointer(-16);
        Q.fileopener_finish(c2, this.__wbg_ptr);
        var n2 = I().getInt32(c2 + 0, true), r2 = I().getInt32(c2 + 4, true), i2 = I().getInt32(c2 + 8, true), a2 = I().getInt32(c2 + 12, true), o2 = n2, s2 = r2;
        if (a2) throw o2 = 0, s2 = 0, q(i2);
        return e3 = o2, t2 = s2, L(o2, s2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16), Q.__wbindgen_export2(e3, t2, 1);
      }
    }
    push(e3) {
      try {
        let a2 = Q.__wbindgen_add_to_stack_pointer(-16), o2 = G(e3, Q.__wbindgen_export3), s2 = Z;
        Q.fileopener_push(a2, this.__wbg_ptr, o2, s2);
        var t2 = I().getInt32(a2 + 0, true), n2 = I().getInt32(a2 + 4, true), r2 = I().getInt32(a2 + 8, true);
        if (I().getInt32(a2 + 12, true)) throw q(r2);
        var i2 = P(t2, n2).slice();
        return Q.__wbindgen_export2(t2, n2 * 1, 1), i2;
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
    get verified() {
      return Q.fileopener_verified(this.__wbg_ptr) !== 0;
    }
    static withKey(t2, n2, r2, i2) {
      try {
        let s2 = Q.__wbindgen_add_to_stack_pointer(-16), c2 = K(t2, Q.__wbindgen_export3, Q.__wbindgen_export4), l2 = Z, u2 = K(n2, Q.__wbindgen_export3, Q.__wbindgen_export4), d2 = Z, f2 = K(r2, Q.__wbindgen_export3, Q.__wbindgen_export4), p2 = Z, m2 = K(i2, Q.__wbindgen_export3, Q.__wbindgen_export4), h2 = Z;
        Q.fileopener_withKey(s2, c2, l2, u2, d2, f2, p2, m2, h2);
        var a2 = I().getInt32(s2 + 0, true), o2 = I().getInt32(s2 + 4, true);
        if (I().getInt32(s2 + 8, true)) throw q(o2);
        return e2.__wrap(a2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
  };
  Symbol.dispose && (r.prototype[Symbol.dispose] = r.prototype.free);
  i = class e2 {
    static __wrap(t2) {
      let n2 = Object.create(e2.prototype);
      return n2.__wbg_ptr = t2, k.register(n2, n2.__wbg_ptr, n2), n2;
    }
    __destroy_into_raw() {
      let e3 = this.__wbg_ptr;
      return this.__wbg_ptr = 0, k.unregister(this), e3;
    }
    free() {
      let e3 = this.__destroy_into_raw();
      Q.__wbg_filesealer_free(e3, 0);
    }
    get chunkSize() {
      return Q.filesealer_chunkSize(this.__wbg_ptr) >>> 0;
    }
    finish() {
      try {
        let i2 = Q.__wbindgen_add_to_stack_pointer(-16);
        Q.filesealer_finish(i2, this.__wbg_ptr);
        var e3 = I().getInt32(i2 + 0, true), t2 = I().getInt32(i2 + 4, true), n2 = I().getInt32(i2 + 8, true);
        if (I().getInt32(i2 + 12, true)) throw q(n2);
        var r2 = P(e3, t2).slice();
        return Q.__wbindgen_export2(e3, t2 * 1, 1), r2;
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
    manifests() {
      let e3, t2;
      try {
        let c2 = Q.__wbindgen_add_to_stack_pointer(-16);
        Q.filesealer_manifests(c2, this.__wbg_ptr);
        var n2 = I().getInt32(c2 + 0, true), r2 = I().getInt32(c2 + 4, true), i2 = I().getInt32(c2 + 8, true), a2 = I().getInt32(c2 + 12, true), o2 = n2, s2 = r2;
        if (a2) throw o2 = 0, s2 = 0, q(i2);
        return e3 = o2, t2 = s2, L(o2, s2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16), Q.__wbindgen_export2(e3, t2, 1);
      }
    }
    push(e3) {
      try {
        let a2 = Q.__wbindgen_add_to_stack_pointer(-16), o2 = G(e3, Q.__wbindgen_export3), s2 = Z;
        Q.filesealer_push(a2, this.__wbg_ptr, o2, s2);
        var t2 = I().getInt32(a2 + 0, true), n2 = I().getInt32(a2 + 4, true), r2 = I().getInt32(a2 + 8, true);
        if (I().getInt32(a2 + 12, true)) throw q(r2);
        var i2 = P(t2, n2).slice();
        return Q.__wbindgen_export2(t2, n2 * 1, 1), i2;
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
    static withKey(t2, n2, r2, i2, a2, o2, s2, c2, l2) {
      try {
        let m2 = Q.__wbindgen_add_to_stack_pointer(-16), h2 = K(t2, Q.__wbindgen_export3, Q.__wbindgen_export4), g2 = Z, _2 = K(n2, Q.__wbindgen_export3, Q.__wbindgen_export4), v2 = Z, y2 = K(i2, Q.__wbindgen_export3, Q.__wbindgen_export4), b2 = Z, x2 = K(s2, Q.__wbindgen_export3, Q.__wbindgen_export4), S2 = Z;
        var u2 = W(c2) ? 0 : K(c2, Q.__wbindgen_export3, Q.__wbindgen_export4), d2 = Z;
        Q.filesealer_withKey(m2, h2, g2, _2, v2, r2, y2, b2, a2, o2, x2, S2, u2, d2, W(l2) ? 2 ** 53 - 1 : l2 >>> 0);
        var f2 = I().getInt32(m2 + 0, true), p2 = I().getInt32(m2 + 4, true);
        if (I().getInt32(m2 + 8, true)) throw q(p2);
        return e2.__wrap(f2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
  };
  Symbol.dispose && (i.prototype[Symbol.dispose] = i.prototype.free);
  a = class e2 {
    static __wrap(t2) {
      let n2 = Object.create(e2.prototype);
      return n2.__wbg_ptr = t2, A.register(n2, n2.__wbg_ptr, n2), n2;
    }
    __destroy_into_raw() {
      let e3 = this.__wbg_ptr;
      return this.__wbg_ptr = 0, A.unregister(this), e3;
    }
    free() {
      let e3 = this.__destroy_into_raw();
      Q.__wbg_identity_free(e3, 0);
    }
    get did() {
      let e3, t2;
      try {
        let i2 = Q.__wbindgen_add_to_stack_pointer(-16);
        Q.identity_did(i2, this.__wbg_ptr);
        var n2 = I().getInt32(i2 + 0, true), r2 = I().getInt32(i2 + 4, true);
        return e3 = n2, t2 = r2, L(n2, r2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16), Q.__wbindgen_export2(e3, t2, 1);
      }
    }
    static mint() {
      try {
        let r2 = Q.__wbindgen_add_to_stack_pointer(-16);
        Q.identity_mint(r2);
        var t2 = I().getInt32(r2 + 0, true), n2 = I().getInt32(r2 + 4, true);
        if (I().getInt32(r2 + 8, true)) throw q(n2);
        return e2.__wrap(t2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
    present(e3, t2, n2, r2) {
      let i2, a2;
      try {
        let m2 = Q.__wbindgen_add_to_stack_pointer(-16), h2 = K(e3, Q.__wbindgen_export3, Q.__wbindgen_export4), g2 = Z, _2 = K(t2, Q.__wbindgen_export3, Q.__wbindgen_export4), v2 = Z, y2 = K(n2, Q.__wbindgen_export3, Q.__wbindgen_export4), b2 = Z;
        var o2 = W(r2) ? 0 : K(r2, Q.__wbindgen_export3, Q.__wbindgen_export4), s2 = Z;
        Q.identity_present(m2, this.__wbg_ptr, h2, g2, _2, v2, y2, b2, o2, s2);
        var c2 = I().getInt32(m2 + 0, true), l2 = I().getInt32(m2 + 4, true), u2 = I().getInt32(m2 + 8, true), d2 = I().getInt32(m2 + 12, true), f2 = c2, p2 = l2;
        if (d2) throw f2 = 0, p2 = 0, q(u2);
        return i2 = f2, a2 = p2, L(f2, p2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16), Q.__wbindgen_export2(i2, a2, 1);
      }
    }
    static restore(t2) {
      try {
        let i2 = Q.__wbindgen_add_to_stack_pointer(-16), a2 = K(t2, Q.__wbindgen_export3, Q.__wbindgen_export4), o2 = Z;
        Q.identity_restore(i2, a2, o2);
        var n2 = I().getInt32(i2 + 0, true), r2 = I().getInt32(i2 + 4, true);
        if (I().getInt32(i2 + 8, true)) throw q(r2);
        return e2.__wrap(n2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
    signDocument(e3) {
      let t2, n2;
      try {
        let l2 = Q.__wbindgen_add_to_stack_pointer(-16), u2 = K(e3, Q.__wbindgen_export3, Q.__wbindgen_export4), d2 = Z;
        Q.identity_signDocument(l2, this.__wbg_ptr, u2, d2);
        var r2 = I().getInt32(l2 + 0, true), i2 = I().getInt32(l2 + 4, true), a2 = I().getInt32(l2 + 8, true), o2 = I().getInt32(l2 + 12, true), s2 = r2, c2 = i2;
        if (o2) throw s2 = 0, c2 = 0, q(a2);
        return t2 = s2, n2 = c2, L(s2, c2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16), Q.__wbindgen_export2(t2, n2, 1);
      }
    }
    snapshot() {
      let e3, t2;
      try {
        let c2 = Q.__wbindgen_add_to_stack_pointer(-16);
        Q.identity_snapshot(c2, this.__wbg_ptr);
        var n2 = I().getInt32(c2 + 0, true), r2 = I().getInt32(c2 + 4, true), i2 = I().getInt32(c2 + 8, true), a2 = I().getInt32(c2 + 12, true), o2 = n2, s2 = r2;
        if (a2) throw o2 = 0, s2 = 0, q(i2);
        return e3 = o2, t2 = s2, L(o2, s2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16), Q.__wbindgen_export2(e3, t2, 1);
      }
    }
  };
  Symbol.dispose && (a.prototype[Symbol.dispose] = a.prototype.free);
  o = class e2 {
    static __wrap(t2) {
      let n2 = Object.create(e2.prototype);
      return n2.__wbg_ptr = t2, j.register(n2, n2.__wbg_ptr, n2), n2;
    }
    __destroy_into_raw() {
      let e3 = this.__wbg_ptr;
      return this.__wbg_ptr = 0, j.unregister(this), e3;
    }
    free() {
      let e3 = this.__destroy_into_raw();
      Q.__wbg_roommember_free(e3, 0);
    }
    addLinks(e3) {
      try {
        let n2 = Q.__wbindgen_add_to_stack_pointer(-16), r2 = K(e3, Q.__wbindgen_export3, Q.__wbindgen_export4), i2 = Z;
        Q.roommember_addLinks(n2, this.__wbg_ptr, r2, i2);
        var t2 = I().getInt32(n2 + 0, true);
        if (I().getInt32(n2 + 4, true)) throw q(t2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
    applyCommit(e3) {
      let t2, n2;
      try {
        let l2 = Q.__wbindgen_add_to_stack_pointer(-16), u2 = G(e3, Q.__wbindgen_export3), d2 = Z;
        Q.roommember_applyCommit(l2, this.__wbg_ptr, u2, d2);
        var r2 = I().getInt32(l2 + 0, true), i2 = I().getInt32(l2 + 4, true), a2 = I().getInt32(l2 + 8, true), o2 = I().getInt32(l2 + 12, true), s2 = r2, c2 = i2;
        if (o2) throw s2 = 0, c2 = 0, q(a2);
        return t2 = s2, n2 = c2, L(s2, c2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16), Q.__wbindgen_export2(t2, n2, 1);
      }
    }
    earliestReadableEpoch() {
      try {
        let n2 = Q.__wbindgen_add_to_stack_pointer(-16);
        Q.roommember_earliestReadableEpoch(n2, this.__wbg_ptr);
        var e3 = I().getInt32(n2 + 0, true), t2 = I().getInt32(n2 + 4, true);
        if (I().getInt32(n2 + 8, true)) throw q(t2);
        return e3 >>> 0;
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
    get epoch() {
      return Q.roommember_epoch(this.__wbg_ptr) >>> 0;
    }
    fileOpener(e3, t2) {
      try {
        let a2 = Q.__wbindgen_add_to_stack_pointer(-16), o2 = K(e3, Q.__wbindgen_export3, Q.__wbindgen_export4), s2 = Z, c2 = K(t2, Q.__wbindgen_export3, Q.__wbindgen_export4), l2 = Z;
        Q.roommember_fileOpener(a2, this.__wbg_ptr, o2, s2, c2, l2);
        var n2 = I().getInt32(a2 + 0, true), i2 = I().getInt32(a2 + 4, true);
        if (I().getInt32(a2 + 8, true)) throw q(i2);
        return r.__wrap(n2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
    fileSealer(e3, t2, n2, r2, a2) {
      try {
        let u2 = Q.__wbindgen_add_to_stack_pointer(-16), d2 = K(n2, Q.__wbindgen_export3, Q.__wbindgen_export4), f2 = Z;
        var o2 = W(r2) ? 0 : K(r2, Q.__wbindgen_export3, Q.__wbindgen_export4), s2 = Z;
        Q.roommember_fileSealer(u2, this.__wbg_ptr, e3, t2, d2, f2, o2, s2, W(a2) ? 2 ** 53 - 1 : a2 >>> 0);
        var c2 = I().getInt32(u2 + 0, true), l2 = I().getInt32(u2 + 4, true);
        if (I().getInt32(u2 + 8, true)) throw q(l2);
        return i.__wrap(c2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
    static join(t2, n2, r2, i2, a2, o2) {
      try {
        let d2 = Q.__wbindgen_add_to_stack_pointer(-16), f2 = K(t2, Q.__wbindgen_export3, Q.__wbindgen_export4), p2 = Z, m2 = K(n2, Q.__wbindgen_export3, Q.__wbindgen_export4), h2 = Z, g2 = G(r2, Q.__wbindgen_export3), _2 = Z, v2 = K(i2, Q.__wbindgen_export3, Q.__wbindgen_export4), y2 = Z, b2 = K(a2, Q.__wbindgen_export3, Q.__wbindgen_export4), x2 = Z;
        var s2 = W(o2) ? 0 : G(o2, Q.__wbindgen_export3), c2 = Z;
        Q.roommember_join(d2, f2, p2, m2, h2, g2, _2, v2, y2, b2, x2, s2, c2);
        var l2 = I().getInt32(d2 + 0, true), u2 = I().getInt32(d2 + 4, true);
        if (I().getInt32(d2 + 8, true)) throw q(u2);
        return e2.__wrap(l2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
    openRecord(e3, t2, n2) {
      try {
        let s2 = Q.__wbindgen_add_to_stack_pointer(-16), c2 = K(e3, Q.__wbindgen_export3, Q.__wbindgen_export4), l2 = Z, u2 = K(n2, Q.__wbindgen_export3, Q.__wbindgen_export4), d2 = Z;
        Q.roommember_openRecord(s2, this.__wbg_ptr, c2, l2, t2, u2, d2);
        var r2 = I().getInt32(s2 + 0, true), i2 = I().getInt32(s2 + 4, true), a2 = I().getInt32(s2 + 8, true);
        if (I().getInt32(s2 + 12, true)) throw q(a2);
        var o2 = P(r2, i2).slice();
        return Q.__wbindgen_export2(r2, i2 * 1, 1), o2;
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
    static restore(t2) {
      try {
        let i2 = Q.__wbindgen_add_to_stack_pointer(-16), a2 = K(t2, Q.__wbindgen_export3, Q.__wbindgen_export4), o2 = Z;
        Q.roommember_restore(i2, a2, o2);
        var n2 = I().getInt32(i2 + 0, true), r2 = I().getInt32(i2 + 4, true);
        if (I().getInt32(i2 + 8, true)) throw q(r2);
        return e2.__wrap(n2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16);
      }
    }
    get roomId() {
      let e3, t2;
      try {
        let i2 = Q.__wbindgen_add_to_stack_pointer(-16);
        Q.roommember_roomId(i2, this.__wbg_ptr);
        var n2 = I().getInt32(i2 + 0, true), r2 = I().getInt32(i2 + 4, true);
        return e3 = n2, t2 = r2, L(n2, r2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16), Q.__wbindgen_export2(e3, t2, 1);
      }
    }
    sealRecord(e3, t2, n2) {
      let r2, i2;
      try {
        let d2 = Q.__wbindgen_add_to_stack_pointer(-16), f2 = K(e3, Q.__wbindgen_export3, Q.__wbindgen_export4), p2 = Z, m2 = G(n2, Q.__wbindgen_export3), h2 = Z;
        Q.roommember_sealRecord(d2, this.__wbg_ptr, f2, p2, t2, m2, h2);
        var a2 = I().getInt32(d2 + 0, true), o2 = I().getInt32(d2 + 4, true), s2 = I().getInt32(d2 + 8, true), c2 = I().getInt32(d2 + 12, true), l2 = a2, u2 = o2;
        if (c2) throw l2 = 0, u2 = 0, q(s2);
        return r2 = l2, i2 = u2, L(l2, u2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16), Q.__wbindgen_export2(r2, i2, 1);
      }
    }
    snapshot() {
      let e3, t2;
      try {
        let c2 = Q.__wbindgen_add_to_stack_pointer(-16);
        Q.roommember_snapshot(c2, this.__wbg_ptr);
        var n2 = I().getInt32(c2 + 0, true), r2 = I().getInt32(c2 + 4, true), i2 = I().getInt32(c2 + 8, true), a2 = I().getInt32(c2 + 12, true), o2 = n2, s2 = r2;
        if (a2) throw o2 = 0, s2 = 0, q(i2);
        return e3 = o2, t2 = s2, L(o2, s2);
      } finally {
        Q.__wbindgen_add_to_stack_pointer(16), Q.__wbindgen_export2(e3, t2, 1);
      }
    }
  };
  Symbol.dispose && (o.prototype[Symbol.dispose] = o.prototype.free);
  s = function(e2, t2, n2, r2, i2) {
    let a2, o2;
    try {
      let h2 = Q.__wbindgen_add_to_stack_pointer(-16), g2 = K(e2, Q.__wbindgen_export3, Q.__wbindgen_export4), _2 = Z, v2 = K(t2, Q.__wbindgen_export3, Q.__wbindgen_export4), y2 = Z, b2 = K(n2, Q.__wbindgen_export3, Q.__wbindgen_export4), x2 = Z, S2 = K(r2, Q.__wbindgen_export3, Q.__wbindgen_export4), C2 = Z;
      var s2 = W(i2) ? 0 : G(i2, Q.__wbindgen_export3), c2 = Z;
      Q.mintKeyPackage(h2, g2, _2, v2, y2, b2, x2, S2, C2, s2, c2);
      var l2 = I().getInt32(h2 + 0, true), u2 = I().getInt32(h2 + 4, true), d2 = I().getInt32(h2 + 8, true), f2 = I().getInt32(h2 + 12, true), p2 = l2, m2 = u2;
      if (f2) throw p2 = 0, m2 = 0, q(d2);
      return a2 = p2, o2 = m2, L(p2, m2);
    } finally {
      Q.__wbindgen_add_to_stack_pointer(16), Q.__wbindgen_export2(a2, o2, 1);
    }
  };
  c = function(e2, t2, n2, r2, i2) {
    let a2, o2;
    try {
      let h2 = Q.__wbindgen_add_to_stack_pointer(-16), g2 = K(e2, Q.__wbindgen_export3, Q.__wbindgen_export4), _2 = Z, v2 = K(t2, Q.__wbindgen_export3, Q.__wbindgen_export4), y2 = Z, b2 = K(n2, Q.__wbindgen_export3, Q.__wbindgen_export4), x2 = Z, S2 = K(r2, Q.__wbindgen_export3, Q.__wbindgen_export4), C2 = Z;
      var s2 = W(i2) ? 0 : G(i2, Q.__wbindgen_export3), c2 = Z;
      Q.verifyInvitation(h2, g2, _2, v2, y2, b2, x2, S2, C2, s2, c2);
      var l2 = I().getInt32(h2 + 0, true), u2 = I().getInt32(h2 + 4, true), d2 = I().getInt32(h2 + 8, true), f2 = I().getInt32(h2 + 12, true), p2 = l2, m2 = u2;
      if (f2) throw p2 = 0, m2 = 0, q(d2);
      return a2 = p2, o2 = m2, L(p2, m2);
    } finally {
      Q.__wbindgen_add_to_stack_pointer(16), Q.__wbindgen_export2(a2, o2, 1);
    }
  };
  function l(e2, t2) {
    return M(Error(L(e2, t2)));
  }
  function u(e2) {
    return typeof B(e2) == `function`;
  }
  function d(e2) {
    let t2 = B(e2);
    return typeof t2 == `object` && !!t2;
  }
  function f(e2) {
    return typeof B(e2) == `string`;
  }
  function p(e2) {
    return B(e2) === void 0;
  }
  function m(e2, t2) {
    throw Error(L(e2, t2));
  }
  function h() {
    return V(function(e2, t2, n2) {
      return M(B(e2).call(B(t2), B(n2)));
    }, arguments);
  }
  function g(e2) {
    let t2 = B(e2).crypto;
    return M(t2);
  }
  function _() {
    return V(function(e2, t2) {
      globalThis.crypto.getRandomValues(P(e2, t2));
    }, arguments);
  }
  function v() {
    return V(function(e2, t2) {
      B(e2).getRandomValues(B(t2));
    }, arguments);
  }
  function y(e2) {
    return B(e2).getTime();
  }
  function b(e2) {
    return B(e2).length;
  }
  function x(e2) {
    let t2 = B(e2).msCrypto;
    return M(t2);
  }
  function S() {
    return M(/* @__PURE__ */ new Date());
  }
  function C(e2) {
    return M(new Uint8Array(e2 >>> 0));
  }
  function ee(e2) {
    let t2 = B(e2).node;
    return M(t2);
  }
  function te() {
    return Date.now();
  }
  function ne(e2) {
    let t2 = B(e2).process;
    return M(t2);
  }
  function w(e2, t2, n2) {
    Uint8Array.prototype.set.call(P(e2, t2), B(n2));
  }
  function T() {
    return V(function(e2, t2) {
      B(e2).randomFillSync(q(t2));
    }, arguments);
  }
  function E() {
    return V(function() {
      let e2 = module.require;
      return M(e2);
    }, arguments);
  }
  function D() {
    let e2 = typeof global > `u` ? null : global;
    return W(e2) ? 0 : M(e2);
  }
  function re() {
    let e2 = typeof globalThis > `u` ? null : globalThis;
    return W(e2) ? 0 : M(e2);
  }
  function ie() {
    let e2 = typeof self > `u` ? null : self;
    return W(e2) ? 0 : M(e2);
  }
  function ae() {
    let e2 = typeof window > `u` ? null : window;
    return W(e2) ? 0 : M(e2);
  }
  function oe(e2, t2, n2) {
    return M(B(e2).subarray(t2 >>> 0, n2 >>> 0));
  }
  function se(e2) {
    let t2 = B(e2).versions;
    return M(t2);
  }
  function ce(e2, t2) {
    return M(P(e2, t2));
  }
  function le(e2, t2) {
    return M(L(e2, t2));
  }
  function ue(e2) {
    return M(B(e2));
  }
  function de(e2) {
    q(e2);
  }
  var O = typeof FinalizationRegistry > `u` ? {
    register: () => {
    },
    unregister: () => {
    }
  } : new FinalizationRegistry((e2) => Q.__wbg_fileopener_free(e2, 1)), k = typeof FinalizationRegistry > `u` ? {
    register: () => {
    },
    unregister: () => {
    }
  } : new FinalizationRegistry((e2) => Q.__wbg_filesealer_free(e2, 1)), A = typeof FinalizationRegistry > `u` ? {
    register: () => {
    },
    unregister: () => {
    }
  } : new FinalizationRegistry((e2) => Q.__wbg_identity_free(e2, 1)), j = typeof FinalizationRegistry > `u` ? {
    register: () => {
    },
    unregister: () => {
    }
  } : new FinalizationRegistry((e2) => Q.__wbg_roommember_free(e2, 1));
  function M(e2) {
    U === H.length && H.push(H.length + 1);
    let t2 = U;
    return U = H[t2], H[t2] = e2, t2;
  }
  function N(e2) {
    e2 < 1028 || (H[e2] = U, U = e2);
  }
  function P(e2, t2) {
    return e2 >>>= 0, z().subarray(e2 / 1, e2 / 1 + t2);
  }
  var F = null;
  function I() {
    return (F === null || F.buffer.detached === true || F.buffer.detached === void 0 && F.buffer !== Q.memory.buffer) && (F = new DataView(Q.memory.buffer)), F;
  }
  function L(e2, t2) {
    return pe(e2 >>> 0, t2);
  }
  var R = null;
  function z() {
    return (R === null || R.byteLength === 0) && (R = new Uint8Array(Q.memory.buffer)), R;
  }
  function B(e2) {
    return H[e2];
  }
  function V(e2, t2) {
    try {
      return e2.apply(this, t2);
    } catch (e3) {
      Q.__wbindgen_export(M(e3));
    }
  }
  var H = Array(1024).fill(void 0);
  H.push(void 0, null, true, false);
  var U = H.length;
  function W(e2) {
    return e2 == null;
  }
  function G(e2, t2) {
    let n2 = t2(e2.length * 1, 1) >>> 0;
    return z().set(e2, n2 / 1), Z = e2.length, n2;
  }
  function K(e2, t2, n2) {
    if (n2 === void 0) {
      let n3 = X.encode(e2), r3 = t2(n3.length, 1) >>> 0;
      return z().subarray(r3, r3 + n3.length).set(n3), Z = n3.length, r3;
    }
    let r2 = e2.length, i2 = t2(r2, 1) >>> 0, a2 = z(), o2 = 0;
    for (; o2 < r2; o2++) {
      let t3 = e2.charCodeAt(o2);
      if (t3 > 127) break;
      a2[i2 + o2] = t3;
    }
    if (o2 !== r2) {
      o2 !== 0 && (e2 = e2.slice(o2)), i2 = n2(i2, r2, r2 = o2 + e2.length * 3, 1) >>> 0;
      let t3 = z().subarray(i2 + o2, i2 + r2), a3 = X.encodeInto(e2, t3);
      o2 += a3.written, i2 = n2(i2, r2, o2, 1) >>> 0;
    }
    return Z = o2, i2;
  }
  function q(e2) {
    let t2 = B(e2);
    return N(e2), t2;
  }
  var J = new TextDecoder(`utf-8`, {
    ignoreBOM: true,
    fatal: true
  });
  J.decode();
  var fe = 2146435072, Y = 0;
  function pe(e2, t2) {
    return Y += t2, Y >= fe && (J = new TextDecoder(`utf-8`, {
      ignoreBOM: true,
      fatal: true
    }), J.decode(), Y = t2), J.decode(z().subarray(e2, e2 + t2));
  }
  var X = new TextEncoder();
  `encodeInto` in X || (X.encodeInto = function(e2, t2) {
    let n2 = X.encode(e2);
    return t2.set(n2), {
      read: e2.length,
      written: n2.length
    };
  });
  var Z = 0, Q;
  function me(e2) {
    Q = e2;
  }
  var he = e({
    __abort_handler: () => Ye,
    __instance_terminated: () => Xe,
    __wbg_fileopener_free: () => _e,
    __wbg_filesealer_free: () => ve,
    __wbg_identity_free: () => ye,
    __wbg_roommember_free: () => be,
    __wbindgen_add_to_stack_pointer: () => Qe,
    __wbindgen_export: () => Ze,
    __wbindgen_export2: () => $e,
    __wbindgen_export3: () => et,
    __wbindgen_export4: () => tt,
    fileopener_finish: () => xe,
    fileopener_push: () => Se,
    fileopener_verified: () => Ce,
    fileopener_withKey: () => we,
    filesealer_chunkSize: () => Te,
    filesealer_finish: () => Ee,
    filesealer_manifests: () => De,
    filesealer_push: () => Oe,
    filesealer_withKey: () => ke,
    identity_did: () => Ae,
    identity_mint: () => je,
    identity_present: () => Me,
    identity_restore: () => Ne,
    identity_signDocument: () => Pe,
    identity_snapshot: () => Fe,
    memory: () => ge,
    mintKeyPackage: () => Ie,
    roommember_addLinks: () => Le,
    roommember_applyCommit: () => Re,
    roommember_earliestReadableEpoch: () => ze,
    roommember_epoch: () => Be,
    roommember_fileOpener: () => Ve,
    roommember_fileSealer: () => He,
    roommember_join: () => Ue,
    roommember_openRecord: () => We,
    roommember_restore: () => Ge,
    roommember_roomId: () => Ke,
    roommember_sealRecord: () => $,
    roommember_snapshot: () => qe,
    verifyInvitation: () => Je
  });
  URL = globalThis.URL;
  var { memory: ge, __wbg_fileopener_free: _e, __wbg_filesealer_free: ve, __wbg_identity_free: ye, __wbg_roommember_free: be, fileopener_finish: xe, fileopener_push: Se, fileopener_verified: Ce, fileopener_withKey: we, filesealer_chunkSize: Te, filesealer_finish: Ee, filesealer_manifests: De, filesealer_push: Oe, filesealer_withKey: ke, identity_did: Ae, identity_mint: je, identity_present: Me, identity_restore: Ne, identity_signDocument: Pe, identity_snapshot: Fe, mintKeyPackage: Ie, roommember_addLinks: Le, roommember_applyCommit: Re, roommember_earliestReadableEpoch: ze, roommember_epoch: Be, roommember_fileOpener: Ve, roommember_fileSealer: He, roommember_join: Ue, roommember_openRecord: We, roommember_restore: Ge, roommember_roomId: Ke, roommember_sealRecord: $, roommember_snapshot: qe, verifyInvitation: Je, __abort_handler: Ye, __instance_terminated: Xe, __wbindgen_export: Ze, __wbindgen_add_to_stack_pointer: Qe, __wbindgen_export2: $e, __wbindgen_export3: et, __wbindgen_export4: tt } = await n({
    "./vti_rooms_wasm_bg.js": {
      __wbindgen_object_drop_ref: de,
      __wbg_getRandomValues_c44a50d8cfdaebeb: v,
      __wbg_randomFillSync_6c25eac9869eb53c: T,
      __wbg_crypto_38df2bab126b63dc: g,
      __wbg_process_44c7a14e11e9f69e: ne,
      __wbg_versions_276b2795b1c6a219: se,
      __wbg_node_84ea875411254db1: ee,
      __wbg_require_b4edbdcf3e2a1ef0: E,
      __wbg_msCrypto_bd5a034af96bcba6: x,
      __wbg_call_6bcf8d3e20937e46: h,
      __wbg_getTime_65922ba0b59d55a7: y,
      __wbg_new_0_35540e542ba689d2: S,
      __wbg_now_d1fb6650485d7f3e: te,
      __wbg_prototypesetcall_ae9f5e7459250748: w,
      __wbg_new_with_length_5ffeddb9d9fbb96f: C,
      __wbg_subarray_1daff70dde20c145: oe,
      __wbg_length_31bdaf014f5fbde2: b,
      __wbg_static_accessor_GLOBAL_THIS_1e7044f654e934db: re,
      __wbg_static_accessor_SELF_d8b50611246a6d92: ie,
      __wbg_static_accessor_GLOBAL_8eb4cd83130a11a0: D,
      __wbg_static_accessor_WINDOW_fd0bc376bf0f8b42: ae,
      __wbindgen_object_clone_ref: ue,
      __wbg_getRandomValues_436a51d0629d84e1: _,
      __wbg___wbindgen_throw_5d9e815e6fdf150f: m,
      __wbg_Error_67e7344beaa85059: l,
      __wbg___wbindgen_is_object_edb6b15aa3afe12e: d,
      __wbg___wbindgen_is_string_c4f7cb494a2a21f1: f,
      __wbg___wbindgen_is_function_fcda5e3902d732fe: u,
      __wbg___wbindgen_is_undefined_8c687d0b90d5b524: p,
      __wbindgen_generic_0000000000000001: ce,
      __wbindgen_generic_0000000000000002: le
    }
  }, t);
  me(he);
})();
export {
  r as FileOpener,
  i as FileSealer,
  a as Identity,
  o as RoomMember,
  __tla,
  s as mintKeyPackage,
  c as verifyInvitation
};
