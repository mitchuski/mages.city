import { t as e } from "./rolldown-runtime-Dd_uD5pT.js";
var t = e(((e2) => {
  var t2 = /* @__PURE__ */ Symbol.for(`react.transitional.element`), n2 = /* @__PURE__ */ Symbol.for(`react.portal`), r2 = /* @__PURE__ */ Symbol.for(`react.fragment`), i2 = /* @__PURE__ */ Symbol.for(`react.strict_mode`), a2 = /* @__PURE__ */ Symbol.for(`react.profiler`), o2 = /* @__PURE__ */ Symbol.for(`react.consumer`), s2 = /* @__PURE__ */ Symbol.for(`react.context`), c2 = /* @__PURE__ */ Symbol.for(`react.forward_ref`), l2 = /* @__PURE__ */ Symbol.for(`react.suspense`), u2 = /* @__PURE__ */ Symbol.for(`react.memo`), d2 = /* @__PURE__ */ Symbol.for(`react.lazy`), f2 = /* @__PURE__ */ Symbol.for(`react.activity`), p2 = /* @__PURE__ */ Symbol.for(`react.view_transition`), m2 = Symbol.iterator;
  function h2(e3) {
    return typeof e3 != `object` || !e3 ? null : (e3 = m2 && e3[m2] || e3[`@@iterator`], typeof e3 == `function` ? e3 : null);
  }
  var g2 = { isMounted: function() {
    return false;
  }, enqueueForceUpdate: function() {
  }, enqueueReplaceState: function() {
  }, enqueueSetState: function() {
  } }, _2 = Object.assign, v2 = {};
  function y2(e3, t3, n3) {
    this.props = e3, this.context = t3, this.refs = v2, this.updater = n3 || g2;
  }
  y2.prototype.isReactComponent = {}, y2.prototype.setState = function(e3, t3) {
    if (typeof e3 != `object` && typeof e3 != `function` && e3 != null) throw Error(`takes an object of state variables to update or a function which returns an object of state variables.`);
    this.updater.enqueueSetState(this, e3, t3, `setState`);
  }, y2.prototype.forceUpdate = function(e3) {
    this.updater.enqueueForceUpdate(this, e3, `forceUpdate`);
  };
  function b2() {
  }
  b2.prototype = y2.prototype;
  function ee2(e3, t3, n3) {
    this.props = e3, this.context = t3, this.refs = v2, this.updater = n3 || g2;
  }
  var te2 = ee2.prototype = new b2();
  te2.constructor = ee2, _2(te2, y2.prototype), te2.isPureReactComponent = true;
  var ne2 = Array.isArray;
  function re2() {
  }
  var x2 = { H: null, A: null, T: null, S: null }, ie2 = Object.prototype.hasOwnProperty;
  function ae2(e3, n3, r3) {
    var i3 = r3.ref;
    return { $$typeof: t2, type: e3, key: n3, ref: i3 === void 0 ? null : i3, props: r3 };
  }
  function oe2(e3, t3) {
    return ae2(e3.type, t3, e3.props);
  }
  function se2(e3) {
    return typeof e3 == `object` && !!e3 && e3.$$typeof === t2;
  }
  function ce2(e3) {
    var t3 = { "=": `=0`, ":": `=2` };
    return `$` + e3.replace(/[=:]/g, function(e4) {
      return t3[e4];
    });
  }
  var le2 = /\/+/g;
  function ue2(e3, t3) {
    return typeof e3 == `object` && e3 && e3.key != null ? ce2(`` + e3.key) : t3.toString(36);
  }
  function de(e3) {
    switch (e3.status) {
      case `fulfilled`:
        return e3.value;
      case `rejected`:
        throw e3.reason;
      default:
        switch (typeof e3.status == `string` ? e3.then(re2, re2) : (e3.status = `pending`, e3.then(function(t3) {
          e3.status === `pending` && (e3.status = `fulfilled`, e3.value = t3);
        }, function(t3) {
          e3.status === `pending` && (e3.status = `rejected`, e3.reason = t3);
        })), e3.status) {
          case `fulfilled`:
            return e3.value;
          case `rejected`:
            throw e3.reason;
        }
    }
    throw e3;
  }
  function fe(e3, r3, i3, a3, o3) {
    var s3 = typeof e3;
    (s3 === `undefined` || s3 === `boolean`) && (e3 = null);
    var c3 = false;
    if (e3 === null) c3 = true;
    else switch (s3) {
      case `bigint`:
      case `string`:
      case `number`:
        c3 = true;
        break;
      case `object`:
        switch (e3.$$typeof) {
          case t2:
          case n2:
            c3 = true;
            break;
          case d2:
            return c3 = e3._init, fe(c3(e3._payload), r3, i3, a3, o3);
        }
    }
    if (c3) return o3 = o3(e3), c3 = a3 === `` ? `.` + ue2(e3, 0) : a3, ne2(o3) ? (i3 = ``, c3 != null && (i3 = c3.replace(le2, `$&/`) + `/`), fe(o3, r3, i3, ``, function(e4) {
      return e4;
    })) : o3 != null && (se2(o3) && (o3 = oe2(o3, i3 + (o3.key == null || e3 && e3.key === o3.key ? `` : (`` + o3.key).replace(le2, `$&/`) + `/`) + c3)), r3.push(o3)), 1;
    c3 = 0;
    var l3 = a3 === `` ? `.` : a3 + `:`;
    if (ne2(e3)) for (var u3 = 0; u3 < e3.length; u3++) a3 = e3[u3], s3 = l3 + ue2(a3, u3), c3 += fe(a3, r3, i3, s3, o3);
    else if (u3 = h2(e3), typeof u3 == `function`) for (e3 = u3.call(e3), u3 = 0; !(a3 = e3.next()).done; ) a3 = a3.value, s3 = l3 + ue2(a3, u3++), c3 += fe(a3, r3, i3, s3, o3);
    else if (s3 === `object`) {
      if (typeof e3.then == `function`) return fe(de(e3), r3, i3, a3, o3);
      throw r3 = String(e3), Error(`Objects are not valid as a React child (found: ` + (r3 === `[object Object]` ? `object with keys {` + Object.keys(e3).join(`, `) + `}` : r3) + `). If you meant to render a collection of children, use an array instead.`);
    }
    return c3;
  }
  function S(e3, t3, n3) {
    if (e3 == null) return e3;
    var r3 = [], i3 = 0;
    return fe(e3, r3, ``, ``, function(e4) {
      return t3.call(n3, e4, i3++);
    }), r3;
  }
  function pe(e3) {
    if (e3._status === -1) {
      var t3 = e3._result, n3 = t3();
      n3.then(function(t4) {
        (e3._status === 0 || e3._status === -1) && (e3._status = 1, e3._result = t4, n3.status === void 0 && (n3.status = `fulfilled`, n3.value = t4));
      }, function(t4) {
        (e3._status === 0 || e3._status === -1) && (e3._status = 2, e3._result = t4, n3.status === void 0 && (n3.status = `rejected`, n3.reason = t4));
      }), e3._status === -1 && (e3._status = 0, e3._result = n3);
    }
    if (e3._status === 1) return e3._result.default;
    throw e3._result;
  }
  var me = typeof reportError == `function` ? reportError : function(e3) {
    if (typeof window == `object` && typeof window.ErrorEvent == `function`) {
      var t3 = new window.ErrorEvent(`error`, { bubbles: true, cancelable: true, message: typeof e3 == `object` && e3 && typeof e3.message == `string` ? String(e3.message) : String(e3), error: e3 });
      if (!window.dispatchEvent(t3)) return;
    } else if (typeof process == `object` && typeof process.emit == `function`) {
      process.emit(`uncaughtException`, e3);
      return;
    }
    console.error(e3);
  };
  function he(e3) {
    var t3 = x2.T, n3 = {};
    n3.types = t3 === null ? null : t3.types, x2.T = n3;
    try {
      var r3 = e3(), i3 = x2.S;
      i3 !== null && i3(n3, r3), typeof r3 == `object` && r3 && typeof r3.then == `function` && r3.then(re2, me);
    } catch (e4) {
      me(e4);
    } finally {
      t3 !== null && n3.types !== null && (t3.types = n3.types), x2.T = t3;
    }
  }
  function ge(e3) {
    var t3 = x2.T;
    if (t3 !== null) {
      var n3 = t3.types;
      n3 === null ? t3.types = [e3] : n3.indexOf(e3) === -1 && n3.push(e3);
    } else he(ge.bind(null, e3));
  }
  var _e = { map: S, forEach: function(e3, t3, n3) {
    S(e3, function() {
      t3.apply(this, arguments);
    }, n3);
  }, count: function(e3) {
    var t3 = 0;
    return S(e3, function() {
      t3++;
    }), t3;
  }, toArray: function(e3) {
    return S(e3, function(e4) {
      return e4;
    }) || [];
  }, only: function(e3) {
    if (!se2(e3)) throw Error(`React.Children.only expected to receive a single React element child.`);
    return e3;
  } };
  e2.Activity = f2, e2.Children = _e, e2.Component = y2, e2.Fragment = r2, e2.Profiler = a2, e2.PureComponent = ee2, e2.StrictMode = i2, e2.Suspense = l2, e2.ViewTransition = p2, e2.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = x2, e2.__COMPILER_RUNTIME = { __proto__: null, c: function(e3) {
    return x2.H.useMemoCache(e3);
  } }, e2.addTransitionType = ge, e2.cache = function(e3) {
    return function() {
      return e3.apply(null, arguments);
    };
  }, e2.cacheSignal = function() {
    return null;
  }, e2.cloneElement = function(e3, t3, n3) {
    if (e3 == null) throw Error(`The argument must be a React element, but you passed ` + e3 + `.`);
    var r3 = _2({}, e3.props), i3 = e3.key;
    if (t3 != null) for (a3 in t3.key !== void 0 && (i3 = `` + t3.key), t3) !ie2.call(t3, a3) || a3 === `key` || a3 === `__self` || a3 === `__source` || a3 === `ref` && t3.ref === void 0 || (r3[a3] = t3[a3]);
    var a3 = arguments.length - 2;
    if (a3 === 1) r3.children = n3;
    else if (1 < a3) {
      for (var o3 = Array(a3), s3 = 0; s3 < a3; s3++) o3[s3] = arguments[s3 + 2];
      r3.children = o3;
    }
    return ae2(e3.type, i3, r3);
  }, e2.createContext = function(e3) {
    return e3 = { $$typeof: s2, _currentValue: e3, _currentValue2: e3, _threadCount: 0, Provider: null, Consumer: null }, e3.Provider = e3, e3.Consumer = { $$typeof: o2, _context: e3 }, e3;
  }, e2.createElement = function(e3, t3, n3) {
    var r3, i3 = {}, a3 = null;
    if (t3 != null) for (r3 in t3.key !== void 0 && (a3 = `` + t3.key), t3) ie2.call(t3, r3) && r3 !== `key` && r3 !== `__self` && r3 !== `__source` && (i3[r3] = t3[r3]);
    var o3 = arguments.length - 2;
    if (o3 === 1) i3.children = n3;
    else if (1 < o3) {
      for (var s3 = Array(o3), c3 = 0; c3 < o3; c3++) s3[c3] = arguments[c3 + 2];
      i3.children = s3;
    }
    if (e3 && e3.defaultProps) for (r3 in o3 = e3.defaultProps, o3) i3[r3] === void 0 && (i3[r3] = o3[r3]);
    return ae2(e3, a3, i3);
  }, e2.createRef = function() {
    return { current: null };
  }, e2.forwardRef = function(e3) {
    return { $$typeof: c2, render: e3 };
  }, e2.isValidElement = se2, e2.lazy = function(e3) {
    return { $$typeof: d2, _payload: { _status: -1, _result: e3 }, _init: pe };
  }, e2.memo = function(e3, t3) {
    return { $$typeof: u2, type: e3, compare: t3 === void 0 ? null : t3 };
  }, e2.startTransition = he, e2.unstable_useCacheRefresh = function() {
    return x2.H.useCacheRefresh();
  }, e2.use = function(e3) {
    return x2.H.use(e3);
  }, e2.useActionState = function(e3, t3, n3) {
    return x2.H.useActionState(e3, t3, n3);
  }, e2.useCallback = function(e3, t3) {
    return x2.H.useCallback(e3, t3);
  }, e2.useContext = function(e3) {
    return x2.H.useContext(e3);
  }, e2.useDebugValue = function() {
  }, e2.useDeferredValue = function(e3, t3) {
    return x2.H.useDeferredValue(e3, t3);
  }, e2.useEffect = function(e3, t3) {
    return x2.H.useEffect(e3, t3);
  }, e2.useEffectEvent = function(e3) {
    return x2.H.useEffectEvent(e3);
  }, e2.useId = function() {
    return x2.H.useId();
  }, e2.useImperativeHandle = function(e3, t3, n3) {
    return x2.H.useImperativeHandle(e3, t3, n3);
  }, e2.useInsertionEffect = function(e3, t3) {
    return x2.H.useInsertionEffect(e3, t3);
  }, e2.useLayoutEffect = function(e3, t3) {
    return x2.H.useLayoutEffect(e3, t3);
  }, e2.useMemo = function(e3, t3) {
    return x2.H.useMemo(e3, t3);
  }, e2.useOptimistic = function(e3, t3) {
    return x2.H.useOptimistic(e3, t3);
  }, e2.useReducer = function(e3, t3, n3) {
    return x2.H.useReducer(e3, t3, n3);
  }, e2.useRef = function(e3) {
    return x2.H.useRef(e3);
  }, e2.useState = function(e3) {
    return x2.H.useState(e3);
  }, e2.useSyncExternalStore = function(e3, t3, n3) {
    return x2.H.useSyncExternalStore(e3, t3, n3);
  }, e2.useTransition = function() {
    return x2.H.useTransition();
  }, e2.version = `19.3.0`;
})), n = e(((e2, n2) => {
  n2.exports = t();
})), r = Math.PI * 2 / 25e3, i = [232, 82, 58], a = [77, 217, 232], o = [240, 238, 232], s = (1 + Math.sqrt(5)) / 2, c = [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]], l = c.map(([e2, t2, n2]) => [-e2, -t2, -n2]), u = [[0, 1, 2], [0, 3, 1], [0, 2, 3], [1, 3, 2]], d = [[0, 1], [0, 2], [0, 3], [1, 2], [1, 3], [2, 3]], f = 0.6, p = (e2, t2) => {
  let n2 = t2 / Math.hypot(...e2[0]);
  return e2.map(([e3, t3, r2]) => [e3 * n2, t3 * n2, r2 * n2]);
}, m = p(c, f), h = p(l, f), g = (() => {
  let e2 = [[0, 1, s], [0, 1, -s], [1, s, 0], [1, -s, 0], [s, 0, 1], [s, 0, -1]].map((e3) => e3.map((t3) => t3 / Math.hypot(...e3))), t2 = [], n2 = 0;
  for (let r2 = 0; r2 < 64; r2++) {
    let i2 = [0, 0, 0];
    for (let t3 = 0; t3 < 6; t3++) {
      let n3 = (r2 >> t3 & 1) - 0.5;
      for (let r3 = 0; r3 < 3; r3++) i2[r3] = i2[r3] + n3 * e2[t3][r3];
    }
    t2.push(i2), n2 = Math.max(n2, Math.hypot(...i2));
  }
  return t2.map((e3) => e3.map((e4) => e4 * 0.8 / n2));
})(), _ = (() => {
  let e2 = [], t2 = (e3, t3) => {
    let n2 = 1.18 + 0.07 * Math.sin(5 * e3) * Math.cos(6 * t3);
    return [n2 * Math.sin(e3) * Math.cos(t3), n2 * Math.cos(e3), n2 * Math.sin(e3) * Math.sin(t3)];
  };
  for (let n2 = 1; n2 < 8; n2++) {
    let r2 = n2 / 8 * Math.PI, i2 = [];
    for (let e3 = 0; e3 <= 96; e3++) i2.push(t2(r2, e3 / 96 * Math.PI * 2));
    e2.push(i2);
  }
  for (let n2 = 0; n2 < 12; n2++) {
    let r2 = n2 / 12 * Math.PI * 2, i2 = [];
    for (let e3 = 0; e3 <= 48; e3++) i2.push(t2(e3 / 48 * Math.PI, r2));
    e2.push(i2);
  }
  return e2;
})(), v = [1.75, 0.95, 0.35], y = 0.22, b = (e2, t2) => `rgba(${e2[0]},${e2[1]},${e2[2]},${Math.max(0, Math.min(1, t2))})`, ee = (e2, t2) => [e2[0] - t2[0], e2[1] - t2[1], e2[2] - t2[2]], te = (e2, t2) => [e2[1] * t2[2] - e2[2] * t2[1], e2[2] * t2[0] - e2[0] * t2[2], e2[0] * t2[1] - e2[1] * t2[0]], ne = (e2) => {
  let t2 = Math.hypot(...e2) || 1;
  return [e2[0] / t2, e2[1] / t2, e2[2] / t2];
};
function re(e2, t2 = {}) {
  let n2 = e2.getContext(`2d`);
  if (!n2) return { setLayers() {
  }, setSpinning() {
  }, isSpinning: () => false, destroy() {
  } };
  let s2 = typeof matchMedia == `function` && matchMedia(`(prefers-reduced-motion: reduce)`).matches, c2 = { yaw: 1.2, pitch: 0.8 }, l2 = c2.yaw, p2 = c2.pitch, re2 = !s2 && t2.spinning !== false, x2 = {}, ie2 = { field: 0, sword: 0, mage: 0, routes: 0, core: 0, hold: 0, invite: 0, constellation: 0, places: 0 }, ae2 = [], oe2 = null, se2 = 0, ce2 = false, le2 = 0, ue2 = 0, de = 0, fe = 0, S = 0, pe = 1, me = performance.now(), he = () => {
    let t3 = e2.getBoundingClientRect();
    pe = Math.min(2, window.devicePixelRatio || 1), fe = Math.max(1, t3.width), S = Math.max(1, t3.height), e2.width = Math.round(fe * pe), e2.height = Math.round(S * pe);
  };
  he();
  let ge = typeof ResizeObserver == `function` ? new ResizeObserver(he) : null;
  ge?.observe(e2);
  let _e = (e3) => {
    let t3 = Math.cos(l2), n3 = Math.sin(l2), r2 = Math.cos(p2), i2 = Math.sin(p2), a2 = e3[0] * t3 + e3[2] * n3, o2 = -e3[0] * n3 + e3[2] * t3;
    return [a2, e3[1] * r2 - o2 * i2, e3[1] * i2 + o2 * r2];
  }, C = (e3) => {
    let t3 = _e(e3), n3 = 4.2, r2 = Math.min(fe, S) / 2 / 1.75 * (n3 / (n3 - t3[2]));
    return { x: fe / 2 + t3[0] * r2, y: S / 2 - t3[1] * r2, z: t3[2], k: r2 };
  }, ve = ne([0.5, 0.8, 0.6]);
  function ye(e3, t3, r2, i2, a2 = [0, 0, 0], o2 = 1) {
    let s3 = e3.map(([e4, t4, n3]) => [a2[0] + e4 * o2, a2[1] + t4 * o2, a2[2] + n3 * o2]), c3 = u.map((e4) => {
      let t4 = s3[e4[0]], n3 = s3[e4[1]], r3 = s3[e4[2]], i3 = ne(_e(te(ee(n3, t4), ee(r3, t4)))), a3 = [(t4[0] + n3[0] + r3[0]) / 3, (t4[1] + n3[1] + r3[1]) / 3, (t4[2] + n3[2] + r3[2]) / 3];
      return { pts: [t4, n3, r3].map(C), z: _e(a3)[2], lit: 0.45 + 0.55 * Math.abs(i3[0] * ve[0] + i3[1] * ve[1] + i3[2] * ve[2]) };
    }).sort((e4, t4) => e4.z - t4.z);
    if (!i2) for (let e4 of c3) n2.beginPath(), e4.pts.forEach((e5, t4) => t4 ? n2.lineTo(e5.x, e5.y) : n2.moveTo(e5.x, e5.y)), n2.closePath(), n2.fillStyle = b(t3.map((t4) => Math.round(t4 * e4.lit)), 0.2 * r2), n2.fill();
    n2.setLineDash(i2 ? [4, 5] : []), n2.lineWidth = i2 ? 1 : 1.7;
    for (let [e4, a3] of d) {
      let o3 = C(s3[e4]), c4 = C(s3[a3]);
      n2.strokeStyle = b(t3, (i2 ? 0.55 : 0.95) * r2 * (0.65 + 0.35 * ((o3.z + c4.z) / 2 + 1))), n2.beginPath(), n2.moveTo(o3.x, o3.y), n2.lineTo(c4.x, c4.y), n2.stroke();
    }
    if (n2.setLineDash([]), !i2) for (let e4 of s3) be(C(e4), t3, 9 * o2 ** 0.5, 0.75 * r2);
  }
  function be(e3, t3, r2, i2) {
    let a2 = n2.createRadialGradient(e3.x, e3.y, 0, e3.x, e3.y, r2);
    a2.addColorStop(0, b(o, i2)), a2.addColorStop(0.3, b(t3, i2 * 0.8)), a2.addColorStop(1, b(t3, 0)), n2.fillStyle = a2, n2.beginPath(), n2.arc(e3.x, e3.y, r2, 0, Math.PI * 2), n2.fill();
  }
  let xe = (e3) => i.map((t3, n3) => Math.round(t3 + (a[n3] - t3) * e3));
  function Se(e3) {
    let t3 = Math.min(64, e3 - me);
    me = e3, !ce2 && re2 && (l2 += r * t3);
    for (let e4 of Object.keys(ie2)) {
      let n3 = x2[e4]?.level ?? 0;
      ie2[e4] += (n3 - ie2[e4]) * (s2 ? 1 : Math.min(1, t3 / 260));
    }
    n2.setTransform(pe, 0, 0, pe, 0, 0), n2.clearRect(0, 0, fe, S);
    let c3 = (e4) => ie2[e4], u2 = (e4) => !!x2[e4]?.next;
    if (c3(`hold`) > 0.01 && (n2.lineWidth = 0.8, n2.setLineDash(u2(`hold`) ? [3, 5] : []), _.forEach((e4, t4) => {
      n2.strokeStyle = b(xe(t4 / _.length), 0.22 * c3(`hold`)), n2.beginPath(), e4.forEach((e5, t5) => {
        let r2 = C(e5);
        t5 ? n2.lineTo(r2.x, r2.y) : n2.moveTo(r2.x, r2.y);
      }), n2.stroke();
    }), n2.setLineDash([])), c3(`routes`) > 0.01) {
      n2.lineWidth = 0.9, n2.setLineDash(u2(`routes`) ? [2, 4] : []);
      for (let e4 = 0; e4 < 64; e4++) {
        let t4 = C(g[e4]), r2 = C(g[(e4 + 1) % 64]);
        n2.strokeStyle = b(xe(e4 / 63), 0.4 * c3(`routes`) * (0.55 + 0.45 * ((t4.z + r2.z) / 2 + 1))), n2.beginPath(), n2.moveTo(t4.x, t4.y), n2.lineTo(r2.x, r2.y), n2.stroke();
      }
      n2.setLineDash([]);
    }
    if (c3(`field`) > 0.01 && g.map((e4, t4) => ({ q: C(e4), i: t4 })).sort((e4, t4) => e4.q.z - t4.q.z).forEach(({ q: e4, i: t4 }) => {
      n2.fillStyle = b(xe(t4 / 63), (u2(`field`) ? 0.35 : 0.85) * c3(`field`) * (0.45 + 0.55 * ((e4.z + 1) / 2))), n2.beginPath(), n2.arc(e4.x, e4.y, 1.6 + e4.z * 0.6, 0, Math.PI * 2), n2.fill();
    }), c3(`constellation`) > 0.01) {
      let e4 = x2.constellation, t4 = (e4?.vertices ?? []).filter((e5) => e5 >= 0 && e5 < 64), r2 = c3(`constellation`);
      n2.lineWidth = 1.4, n2.setLineDash(u2(`constellation`) ? [3, 4] : []);
      for (let e5 = 1; e5 < t4.length; e5++) {
        let i2 = C(g[t4[e5 - 1]]), a2 = C(g[t4[e5]]);
        n2.strokeStyle = b(o, 0.85 * r2 * (0.6 + 0.4 * ((i2.z + a2.z) / 2 + 1))), n2.beginPath(), n2.moveTo(i2.x, i2.y), n2.lineTo(a2.x, a2.y), n2.stroke();
      }
      if (n2.setLineDash([]), t4.forEach((e5, n3) => be(C(g[e5]), n3 === t4.length - 1 ? a : o, n3 === t4.length - 1 ? 9 : 5.5, (n3 === t4.length - 1 ? 0.95 : 0.7) * r2)), e4?.witness !== void 0 && e4.witness >= 0 && e4.witness < 64 && t4.length) {
        let a2 = C(g[t4[t4.length - 1]]), o2 = C(g[e4.witness]);
        n2.setLineDash([2, 5]), n2.lineWidth = 1, n2.strokeStyle = b(i, 0.55 * r2), n2.beginPath(), n2.moveTo(a2.x, a2.y), n2.lineTo(o2.x, o2.y), n2.stroke(), n2.setLineDash([]), n2.strokeStyle = b(i, 0.8 * r2), n2.lineWidth = 1, n2.beginPath(), n2.arc(o2.x, o2.y, 4.5, 0, Math.PI * 2), n2.stroke();
      }
    }
    let d2 = [[`sword`, m, i], [`mage`, h, a]];
    d2.sort((e4, t4) => _e(e4[1][0])[2] - _e(t4[1][0])[2]);
    for (let [e4, t4, n3] of d2) c3(e4) > 0.01 && ye(t4, n3, c3(e4), u2(e4));
    if (c3(`core`) > 0.01) {
      let t4 = C([0, 0, 0]), n3 = s2 ? 1 : 0.85 + 0.15 * Math.sin(e3 / 700);
      be(t4, a, 34 * n3, 0.5 * c3(`core`)), be(t4, i, 18 * n3, 0.7 * c3(`core`));
    }
    if (c3(`places`) > 0.01) {
      let e4 = c3(`places`), t4 = (x2.places?.places ?? []).filter((e5) => e5.vertex >= 0 && e5.vertex < 64);
      ae2 = [], t4.map((e5) => ({ p: e5, q: C(g[e5.vertex]) })).sort((e5, t5) => e5.q.z - t5.q.z).forEach(({ p: t5, q: r2 }) => {
        let i2 = 0.55 + 0.45 * ((r2.z + 1) / 2), s3 = oe2 === t5, c4 = (s3 ? 22 : 16) * i2;
        be(r2, s3 ? a : o, c4 * 1.6, (s3 ? 0.9 : 0.5) * e4 * i2), n2.font = `${Math.round(c4 * 1.15)}px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif`, n2.textAlign = `center`, n2.textBaseline = `middle`, n2.globalAlpha = Math.min(1, e4 * (0.6 + 0.4 * i2)), n2.fillText(t5.glyph, r2.x, r2.y), n2.globalAlpha = 1, ae2.push({ x: r2.x, y: r2.y, r: c4 + 6, place: t5 });
      });
    }
    if (c3(`invite`) > 0.01) {
      let e4 = C([0, 0, 0]), t4 = C(v);
      n2.setLineDash([3, 5]), n2.lineWidth = 1, n2.strokeStyle = b(o, 0.45 * c3(`invite`)), n2.beginPath(), n2.moveTo(e4.x, e4.y), n2.lineTo(t4.x, t4.y), n2.stroke(), n2.setLineDash([]), ye(m, i, c3(`invite`), u2(`invite`), v, y / f), ye(h, a, c3(`invite`), u2(`invite`), v, y / f);
    }
    se2 = requestAnimationFrame(Se);
  }
  let Ce = (t3) => {
    ce2 = true, le2 = 0, ue2 = t3.clientX, de = t3.clientY, e2.setPointerCapture(t3.pointerId);
  }, we = (e3, t3) => {
    let n3 = null, r2 = 1 / 0;
    for (let i2 of ae2) {
      let a2 = Math.hypot(i2.x - e3, i2.y - t3);
      a2 <= i2.r && a2 < r2 && (r2 = a2, n3 = i2.place);
    }
    return n3;
  }, Te = (n3) => {
    if (!ce2) {
      if (!ae2.length) return;
      let r2 = e2.getBoundingClientRect(), i2 = we(n3.clientX - r2.left, n3.clientY - r2.top);
      i2 !== oe2 && (oe2 = i2, e2.style.cursor = i2 ? `pointer` : `grab`, t2.onPlaceHover?.(i2));
      return;
    }
    le2 += Math.abs(n3.clientX - ue2) + Math.abs(n3.clientY - de), l2 += (n3.clientX - ue2) * 8e-3, p2 = Math.max(-1.2, Math.min(1.2, p2 + (n3.clientY - de) * 8e-3)), ue2 = n3.clientX, de = n3.clientY;
  }, Ee = (e3) => {
    re2 = e3, t2.onSpinChange?.(e3);
  }, w = () => {
    ce2 && le2 < 4 && (oe2 ? t2.onPlaceClick?.(oe2) : Ee(!re2)), ce2 = false;
  }, T = () => {
    oe2 && (oe2 = null, e2.style.cursor = `grab`, t2.onPlaceHover?.(null));
  }, De = () => {
    l2 = c2.yaw, p2 = c2.pitch;
  };
  return t2.interactive !== false && (e2.style.cursor = `grab`, e2.style.touchAction = `none`, e2.addEventListener(`pointerdown`, Ce), e2.addEventListener(`pointermove`, Te), e2.addEventListener(`pointerup`, w), e2.addEventListener(`pointercancel`, w), e2.addEventListener(`dblclick`, De), e2.addEventListener(`pointerleave`, T)), se2 = requestAnimationFrame(Se), { setLayers(e3) {
    x2 = e3;
  }, setSpinning: Ee, isSpinning: () => re2, destroy() {
    cancelAnimationFrame(se2), ge?.disconnect(), e2.removeEventListener(`pointerdown`, Ce), e2.removeEventListener(`pointermove`, Te), e2.removeEventListener(`pointerup`, w), e2.removeEventListener(`pointercancel`, w), e2.removeEventListener(`dblclick`, De), e2.removeEventListener(`pointerleave`, T);
  } };
}
var x = e(((e2) => {
  var t2 = /* @__PURE__ */ Symbol.for(`react.transitional.element`), n2 = /* @__PURE__ */ Symbol.for(`react.fragment`);
  function r2(e3, n3, r3) {
    var i2 = null;
    if (r3 !== void 0 && (i2 = `` + r3), n3.key !== void 0 && (i2 = `` + n3.key), `key` in n3) for (var a2 in r3 = {}, n3) a2 !== `key` && (r3[a2] = n3[a2]);
    else r3 = n3;
    return n3 = r3.ref, { $$typeof: t2, type: e3, key: i2, ref: n3 === void 0 ? null : n3, props: r3 };
  }
  e2.Fragment = n2, e2.jsx = r2, e2.jsxs = r2;
})), ie = e(((e2, t2) => {
  t2.exports = x();
})), ae = e(((e2) => {
  function t2(e3, t3) {
    var n3 = e3.length;
    e3.push(t3);
    a: for (; 0 < n3; ) {
      var r3 = n3 - 1 >>> 1, a3 = e3[r3];
      if (0 < i2(a3, t3)) e3[r3] = t3, e3[n3] = a3, n3 = r3;
      else break a;
    }
  }
  function n2(e3) {
    return e3.length === 0 ? null : e3[0];
  }
  function r2(e3) {
    if (e3.length === 0) return null;
    var t3 = e3[0], n3 = e3.pop();
    if (n3 !== t3) {
      e3[0] = n3;
      a: for (var r3 = 0, a3 = e3.length, o3 = a3 >>> 1; r3 < o3; ) {
        var s3 = 2 * (r3 + 1) - 1, c3 = e3[s3], l3 = s3 + 1, u3 = e3[l3];
        if (0 > i2(c3, n3)) l3 < a3 && 0 > i2(u3, c3) ? (e3[r3] = u3, e3[l3] = n3, r3 = l3) : (e3[r3] = c3, e3[s3] = n3, r3 = s3);
        else if (l3 < a3 && 0 > i2(u3, n3)) e3[r3] = u3, e3[l3] = n3, r3 = l3;
        else break a;
      }
    }
    return t3;
  }
  function i2(e3, t3) {
    var n3 = e3.sortIndex - t3.sortIndex;
    return n3 === 0 ? e3.id - t3.id : n3;
  }
  if (e2.unstable_now = void 0, typeof performance == `object` && typeof performance.now == `function`) {
    var a2 = performance;
    e2.unstable_now = function() {
      return a2.now();
    };
  } else {
    var o2 = Date, s2 = o2.now();
    e2.unstable_now = function() {
      return o2.now() - s2;
    };
  }
  var c2 = [], l2 = [], u2 = 1, d2 = null, f2 = 3, p2 = false, m2 = false, h2 = false, g2 = false, _2 = typeof setTimeout == `function` ? setTimeout : null, v2 = typeof clearTimeout == `function` ? clearTimeout : null, y2 = typeof setImmediate < `u` ? setImmediate : null;
  function b2(e3) {
    for (var i3 = n2(l2); i3 !== null; ) {
      if (i3.callback === null) r2(l2);
      else if (i3.startTime <= e3) r2(l2), i3.sortIndex = i3.expirationTime, t2(c2, i3);
      else break;
      i3 = n2(l2);
    }
  }
  function ee2(e3) {
    if (h2 = false, b2(e3), !m2) {
      if (n2(c2) !== null) m2 = true, te2 || (te2 = true, oe2());
      else {
        var t3 = n2(l2);
        t3 !== null && le2(ee2, t3.startTime - e3);
      }
    }
  }
  var te2 = false, ne2 = -1, re2 = 5, x2 = -1;
  function ie2() {
    return g2 ? true : !(e2.unstable_now() - x2 < re2);
  }
  function ae2() {
    if (g2 = false, te2) {
      var t3 = e2.unstable_now();
      x2 = t3;
      var i3 = true;
      try {
        a: {
          m2 = false, h2 && (h2 = false, v2(ne2), ne2 = -1), p2 = true;
          var a3 = f2;
          try {
            b: {
              for (b2(t3), d2 = n2(c2); d2 !== null && !(d2.expirationTime > t3 && ie2()); ) {
                var o3 = d2.callback;
                if (typeof o3 == `function`) {
                  d2.callback = null, f2 = d2.priorityLevel;
                  var s3 = o3(d2.expirationTime <= t3);
                  if (t3 = e2.unstable_now(), typeof s3 == `function`) {
                    d2.callback = s3, b2(t3), i3 = true;
                    break b;
                  }
                  d2 === n2(c2) && r2(c2), b2(t3);
                } else r2(c2);
                d2 = n2(c2);
              }
              if (d2 !== null) i3 = true;
              else {
                var u3 = n2(l2);
                u3 !== null && le2(ee2, u3.startTime - t3), i3 = false;
              }
            }
            break a;
          } finally {
            d2 = null, f2 = a3, p2 = false;
          }
          i3 = void 0;
        }
      } finally {
        i3 ? oe2() : te2 = false;
      }
    }
  }
  var oe2;
  if (typeof y2 == `function`) oe2 = function() {
    y2(ae2);
  };
  else if (typeof MessageChannel < `u`) {
    var se2 = new MessageChannel(), ce2 = se2.port2;
    se2.port1.onmessage = ae2, oe2 = function() {
      ce2.postMessage(null);
    };
  } else oe2 = function() {
    _2(ae2, 0);
  };
  function le2(t3, n3) {
    ne2 = _2(function() {
      t3(e2.unstable_now());
    }, n3);
  }
  e2.unstable_IdlePriority = 5, e2.unstable_ImmediatePriority = 1, e2.unstable_LowPriority = 4, e2.unstable_NormalPriority = 3, e2.unstable_Profiling = null, e2.unstable_UserBlockingPriority = 2, e2.unstable_cancelCallback = function(e3) {
    e3.callback = null;
  }, e2.unstable_forceFrameRate = function(e3) {
    0 > e3 || 125 < e3 ? console.error(`forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`) : re2 = 0 < e3 ? Math.floor(1e3 / e3) : 5;
  }, e2.unstable_getCurrentPriorityLevel = function() {
    return f2;
  }, e2.unstable_next = function(e3) {
    switch (f2) {
      case 1:
      case 2:
      case 3:
        var t3 = 3;
        break;
      default:
        t3 = f2;
    }
    var n3 = f2;
    f2 = t3;
    try {
      return e3();
    } finally {
      f2 = n3;
    }
  }, e2.unstable_requestPaint = function() {
    g2 = true;
  }, e2.unstable_runWithPriority = function(e3, t3) {
    switch (e3) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        break;
      default:
        e3 = 3;
    }
    var n3 = f2;
    f2 = e3;
    try {
      return t3();
    } finally {
      f2 = n3;
    }
  }, e2.unstable_scheduleCallback = function(r3, i3, a3) {
    var o3 = e2.unstable_now();
    switch (typeof a3 == `object` && a3 ? (a3 = a3.delay, a3 = typeof a3 == `number` && 0 < a3 ? o3 + a3 : o3) : a3 = o3, r3) {
      case 1:
        var s3 = -1;
        break;
      case 2:
        s3 = 250;
        break;
      case 5:
        s3 = 1073741823;
        break;
      case 4:
        s3 = 1e4;
        break;
      default:
        s3 = 5e3;
    }
    return s3 = a3 + s3, r3 = { id: u2++, callback: i3, priorityLevel: r3, startTime: a3, expirationTime: s3, sortIndex: -1 }, a3 > o3 ? (r3.sortIndex = a3, t2(l2, r3), n2(c2) === null && r3 === n2(l2) && (h2 ? (v2(ne2), ne2 = -1) : h2 = true, le2(ee2, a3 - o3))) : (r3.sortIndex = s3, t2(c2, r3), m2 || p2 || (m2 = true, te2 || (te2 = true, oe2()))), r3;
  }, e2.unstable_shouldYield = ie2, e2.unstable_wrapCallback = function(e3) {
    var t3 = f2;
    return function() {
      var n3 = f2;
      f2 = t3;
      try {
        return e3.apply(this, arguments);
      } finally {
        f2 = n3;
      }
    };
  };
})), oe = e(((e2, t2) => {
  t2.exports = ae();
})), se = e(((e2) => {
  var t2 = n();
  function r2(e3) {
    var t3 = `https://react.dev/errors/` + e3;
    if (1 < arguments.length) {
      t3 += `?args[]=` + encodeURIComponent(arguments[1]);
      for (var n2 = 2; n2 < arguments.length; n2++) t3 += `&args[]=` + encodeURIComponent(arguments[n2]);
    }
    return `Minified React error #` + e3 + `; visit ` + t3 + ` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`;
  }
  function i2() {
  }
  var a2 = { d: { f: i2, r: function() {
    throw Error(r2(522));
  }, D: i2, C: i2, L: i2, m: i2, X: i2, S: i2, M: i2 }, p: 0, findDOMNode: null }, o2 = /* @__PURE__ */ Symbol.for(`react.portal`), s2 = /* @__PURE__ */ Symbol.for(`react.recoverable`), c2 = /* @__PURE__ */ Symbol.for(`react.optimistic_key`);
  function l2(e3, t3, n2) {
    var r3 = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return { $$typeof: o2, key: r3 == null ? null : r3 === c2 ? c2 : `` + r3, children: e3, containerInfo: t3, implementation: n2 };
  }
  var u2 = t2.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
  function d2(e3, t3) {
    if (e3 === `font`) return ``;
    if (typeof t3 == `string`) return t3 === `use-credentials` ? t3 : ``;
  }
  e2.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = a2, e2.browser = function(e3) {
    return { $$typeof: s2, _reason: e3 };
  }, e2.createPortal = function(e3, t3) {
    var n2 = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!t3 || t3.nodeType !== 1 && t3.nodeType !== 9 && t3.nodeType !== 11) throw Error(r2(299));
    return l2(e3, t3, null, n2);
  }, e2.flushSync = function(e3) {
    var t3 = u2.T, n2 = a2.p;
    try {
      if (u2.T = null, a2.p = 2, e3) return e3();
    } finally {
      u2.T = t3, a2.p = n2, a2.d.f();
    }
  }, e2.preconnect = function(e3, t3) {
    typeof e3 == `string` && (t3 ? (t3 = t3.crossOrigin, t3 = typeof t3 == `string` ? t3 === `use-credentials` ? t3 : `` : void 0) : t3 = null, a2.d.C(e3, t3));
  }, e2.prefetchDNS = function(e3) {
    typeof e3 == `string` && a2.d.D(e3);
  }, e2.preinit = function(e3, t3) {
    if (typeof e3 == `string` && t3 && typeof t3.as == `string`) {
      var n2 = t3.as, r3 = d2(n2, t3.crossOrigin), i3 = typeof t3.integrity == `string` ? t3.integrity : void 0, o3 = typeof t3.fetchPriority == `string` ? t3.fetchPriority : void 0;
      n2 === `style` ? a2.d.S(e3, typeof t3.precedence == `string` ? t3.precedence : void 0, { crossOrigin: r3, integrity: i3, fetchPriority: o3 }) : n2 === `script` && a2.d.X(e3, { crossOrigin: r3, integrity: i3, fetchPriority: o3, nonce: typeof t3.nonce == `string` ? t3.nonce : void 0 });
    }
  }, e2.preinitModule = function(e3, t3) {
    if (typeof e3 == `string`) {
      if (typeof t3 == `object` && t3) {
        if (t3.as == null || t3.as === `script`) {
          var n2 = d2(t3.as, t3.crossOrigin);
          a2.d.M(e3, { crossOrigin: n2, integrity: typeof t3.integrity == `string` ? t3.integrity : void 0, nonce: typeof t3.nonce == `string` ? t3.nonce : void 0, fetchPriority: typeof t3.fetchPriority == `string` ? t3.fetchPriority : void 0 });
        }
      } else t3 ?? a2.d.M(e3);
    }
  }, e2.preload = function(e3, t3) {
    if (typeof e3 == `string` && typeof t3 == `object` && t3 && typeof t3.as == `string`) {
      var n2 = t3.as, r3 = d2(n2, t3.crossOrigin);
      a2.d.L(e3, n2, { crossOrigin: r3, integrity: typeof t3.integrity == `string` ? t3.integrity : void 0, nonce: typeof t3.nonce == `string` ? t3.nonce : void 0, type: typeof t3.type == `string` ? t3.type : void 0, fetchPriority: typeof t3.fetchPriority == `string` ? t3.fetchPriority : void 0, referrerPolicy: typeof t3.referrerPolicy == `string` ? t3.referrerPolicy : void 0, imageSrcSet: typeof t3.imageSrcSet == `string` ? t3.imageSrcSet : void 0, imageSizes: typeof t3.imageSizes == `string` ? t3.imageSizes : void 0, media: typeof t3.media == `string` ? t3.media : void 0 });
    }
  }, e2.preloadModule = function(e3, t3) {
    if (typeof e3 == `string`) {
      if (t3) {
        var n2 = d2(t3.as, t3.crossOrigin);
        a2.d.m(e3, { as: typeof t3.as == `string` && t3.as !== `script` ? t3.as : void 0, crossOrigin: n2, integrity: typeof t3.integrity == `string` ? t3.integrity : void 0, nonce: typeof t3.nonce == `string` ? t3.nonce : void 0, fetchPriority: typeof t3.fetchPriority == `string` ? t3.fetchPriority : void 0 });
      } else a2.d.m(e3);
    }
  }, e2.requestFormReset = function(e3) {
    a2.d.r(e3);
  }, e2.unstable_batchedUpdates = function(e3, t3) {
    return e3(t3);
  }, e2.useFormState = function(e3, t3, n2) {
    return u2.H.useFormState(e3, t3, n2);
  }, e2.useFormStatus = function() {
    return u2.H.useHostTransitionStatus();
  }, e2.version = `19.3.0`;
})), ce = e(((e2, t2) => {
  function n2() {
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < `u` && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE == `function`) try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n2);
    } catch (e3) {
      console.error(e3);
    }
  }
  n2(), t2.exports = se();
})), le = e(((e2) => {
  var t2 = oe(), r2 = n(), i2 = ce();
  function a2(e3) {
    var t3 = `https://react.dev/errors/` + e3;
    if (1 < arguments.length) {
      t3 += `?args[]=` + encodeURIComponent(arguments[1]);
      for (var n2 = 2; n2 < arguments.length; n2++) t3 += `&args[]=` + encodeURIComponent(arguments[n2]);
    }
    return `Minified React error #` + e3 + `; visit ` + t3 + ` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`;
  }
  function o2(e3) {
    return !(!e3 || e3.nodeType !== 1 && e3.nodeType !== 9 && e3.nodeType !== 11);
  }
  function s2(e3) {
    for (var t3 = e3, n2 = t3; n2 && !n2.alternate; ) t3 = n2, t3.flags & 4098 && (e3 = t3.return), n2 = t3.return;
    for (; t3.return; ) t3 = t3.return;
    return t3.tag === 3 ? e3 : null;
  }
  function c2(e3) {
    if (e3.tag === 13) {
      var t3 = e3.memoizedState;
      if (t3 === null && (e3 = e3.alternate, e3 !== null && (t3 = e3.memoizedState)), t3 !== null) return t3.dehydrated;
    }
    return null;
  }
  function l2(e3) {
    if (e3.tag === 31) {
      var t3 = e3.memoizedState;
      if (t3 === null && (e3 = e3.alternate, e3 !== null && (t3 = e3.memoizedState)), t3 !== null) return t3.dehydrated;
    }
    return null;
  }
  function u2(e3) {
    if (s2(e3) !== e3) throw Error(a2(188));
  }
  function d2(e3) {
    var t3 = e3.alternate;
    if (!t3) {
      if (t3 = s2(e3), t3 === null) throw Error(a2(188));
      return t3 === e3 ? e3 : null;
    }
    for (var n2 = e3, r3 = t3; ; ) {
      var i3 = n2.return;
      if (i3 === null) break;
      var o3 = i3.alternate;
      if (o3 === null) {
        if (r3 = i3.return, r3 !== null) {
          n2 = r3;
          continue;
        }
        break;
      }
      if (i3.child === o3.child) {
        for (o3 = i3.child; o3; ) {
          if (o3 === n2) return u2(i3), e3;
          if (o3 === r3) return u2(i3), t3;
          o3 = o3.sibling;
        }
        throw Error(a2(188));
      }
      if (n2.return !== r3.return) n2 = i3, r3 = o3;
      else {
        for (var c3 = false, l3 = i3.child; l3; ) {
          if (l3 === n2) {
            c3 = true, n2 = i3, r3 = o3;
            break;
          }
          if (l3 === r3) {
            c3 = true, r3 = i3, n2 = o3;
            break;
          }
          l3 = l3.sibling;
        }
        if (!c3) {
          for (l3 = o3.child; l3; ) {
            if (l3 === n2) {
              c3 = true, n2 = o3, r3 = i3;
              break;
            }
            if (l3 === r3) {
              c3 = true, r3 = o3, n2 = i3;
              break;
            }
            l3 = l3.sibling;
          }
          if (!c3) throw Error(a2(189));
        }
      }
      if (n2.alternate !== r3) throw Error(a2(190));
    }
    if (n2.tag !== 3) throw Error(a2(188));
    return n2.stateNode.current === n2 ? e3 : t3;
  }
  function f2(e3) {
    var t3 = e3.tag;
    if (t3 === 5 || t3 === 26 || t3 === 27 || t3 === 6) return e3;
    for (e3 = e3.child; e3 !== null; ) {
      if (t3 = f2(e3), t3 !== null) return t3;
      e3 = e3.sibling;
    }
    return null;
  }
  function p2(e3, t3, n2, r3, i3, a3) {
    for (; e3 !== null; ) {
      if ((e3.tag === 5 || e3.tag === 27 || e3.tag === 6) && n2(e3, r3, i3, a3) || (e3.tag !== 22 || e3.memoizedState === null) && (t3 || e3.tag !== 5 && e3.tag !== 27) && p2(e3.child, t3, n2, r3, i3, a3)) return true;
      e3 = e3.sibling;
    }
    return false;
  }
  function m2(e3) {
    for (e3 = e3.return; e3 !== null; ) {
      if (e3.tag === 3 || e3.tag === 5 || e3.tag === 27) return e3;
      e3 = e3.return;
    }
    return null;
  }
  function h2(e3) {
    var t3 = false;
    for (e3 = e3.return; e3 !== null && (e3.tag === 4 && (t3 = true), e3.tag !== 3 && e3.tag !== 5 && e3.tag !== 27); ) e3 = e3.return;
    return t3;
  }
  function g2(e3) {
    var t3 = [null, null], n2 = m2(e3);
    return n2 === null || _2(t3, e3, n2.child, { foundSelf: false }), t3;
  }
  function _2(e3, t3, n2, r3) {
    for (; n2 !== null; ) {
      if (n2 === t3) r3.foundSelf = true;
      else if (n2.tag === 5 || n2.tag === 27 || n2.tag === 6) {
        if (r3.foundSelf) return e3[1] = n2, true;
        e3[0] = n2;
      } else if ((n2.tag !== 22 || n2.memoizedState === null) && _2(e3, t3, n2.child, r3)) return true;
      n2 = n2.sibling;
    }
    return false;
  }
  function v2(e3) {
    switch (e3.tag) {
      case 5:
      case 27:
      case 6:
        return e3.stateNode;
      case 3:
        return e3.stateNode.containerInfo;
      default:
        throw Error(a2(559));
    }
  }
  var y2 = null, b2 = null;
  function ee2(e3, t3, n2) {
    return e3 === n2 || e3 === t3 && (y2 = e3, true);
  }
  function te2(e3, t3, n2) {
    return e3 === n2 ? (b2 = e3, false) : e3 === t3 && (b2 !== null && (y2 = e3), true);
  }
  function ne2(e3) {
    if (e3 === null) return null;
    do
      e3 = e3 === null ? null : e3.return;
    while (e3 && e3.tag !== 5 && e3.tag !== 27 && e3.tag !== 3);
    return e3 || null;
  }
  function re2(e3, t3, n2) {
    for (var r3 = 0, i3 = e3; i3; i3 = n2(i3)) r3++;
    i3 = 0;
    for (var a3 = t3; a3; a3 = n2(a3)) i3++;
    for (; 0 < r3 - i3; ) e3 = n2(e3), r3--;
    for (; 0 < i3 - r3; ) t3 = n2(t3), i3--;
    for (; r3--; ) {
      if (e3 === t3 || t3 !== null && e3 === t3.alternate) return e3;
      e3 = n2(e3), t3 = n2(t3);
    }
    return null;
  }
  var x2 = Object.assign, ie2 = /* @__PURE__ */ Symbol.for(`react.element`), ae2 = /* @__PURE__ */ Symbol.for(`react.transitional.element`), se2 = /* @__PURE__ */ Symbol.for(`react.portal`), le2 = /* @__PURE__ */ Symbol.for(`react.fragment`), ue2 = /* @__PURE__ */ Symbol.for(`react.strict_mode`), de = /* @__PURE__ */ Symbol.for(`react.profiler`), fe = /* @__PURE__ */ Symbol.for(`react.consumer`), S = /* @__PURE__ */ Symbol.for(`react.context`), pe = /* @__PURE__ */ Symbol.for(`react.forward_ref`), me = /* @__PURE__ */ Symbol.for(`react.suspense`), he = /* @__PURE__ */ Symbol.for(`react.suspense_list`), ge = /* @__PURE__ */ Symbol.for(`react.memo`), _e = /* @__PURE__ */ Symbol.for(`react.lazy`), C = /* @__PURE__ */ Symbol.for(`react.activity`), ve = /* @__PURE__ */ Symbol.for(`react.legacy_hidden`), ye = /* @__PURE__ */ Symbol.for(`react.memo_cache_sentinel`), be = /* @__PURE__ */ Symbol.for(`react.view_transition`), xe = /* @__PURE__ */ Symbol.for(`react.recoverable`), Se = Symbol.iterator;
  function Ce(e3) {
    return typeof e3 != `object` || !e3 ? null : (e3 = Se && e3[Se] || e3[`@@iterator`], typeof e3 == `function` ? e3 : null);
  }
  var we = /* @__PURE__ */ Symbol.for(`react.client.reference`);
  function Te(e3) {
    if (e3 == null) return null;
    if (typeof e3 == `function`) return e3.$$typeof === we ? null : e3.displayName || e3.name || null;
    if (typeof e3 == `string`) return e3;
    switch (e3) {
      case le2:
        return `Fragment`;
      case de:
        return `Profiler`;
      case ue2:
        return `StrictMode`;
      case me:
        return `Suspense`;
      case he:
        return `SuspenseList`;
      case C:
        return `Activity`;
      case be:
        return `ViewTransition`;
    }
    if (typeof e3 == `object`) switch (e3.$$typeof) {
      case se2:
        return `Portal`;
      case S:
        return e3.displayName || `Context`;
      case fe:
        return (e3._context.displayName || `Context`) + `.Consumer`;
      case pe:
        var t3 = e3.render;
        return e3 = e3.displayName, e3 ||= (e3 = t3.displayName || t3.name || ``, e3 === `` ? `ForwardRef` : `ForwardRef(` + e3 + `)`), e3;
      case ge:
        return t3 = e3.displayName || null, t3 === null ? Te(e3.type) || `Memo` : t3;
      case _e:
        t3 = e3._payload, e3 = e3._init;
        try {
          return Te(e3(t3));
        } catch {
        }
    }
    return null;
  }
  var Ee = Array.isArray, w = r2.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, T = i2.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, De = { pending: false, data: null, method: null, action: null }, Oe = [], ke = -1;
  function Ae(e3) {
    return { current: e3 };
  }
  function je(e3) {
    0 > ke || (e3.current = Oe[ke], Oe[ke] = null, ke--);
  }
  function E(e3, t3) {
    ke++, Oe[ke] = e3.current, e3.current = t3;
  }
  var Me = Ae(null), Ne = Ae(null), Pe = Ae(null), Fe = Ae(null);
  function Ie(e3, t3) {
    switch (E(Pe, t3), E(Ne, e3), E(Me, null), t3.nodeType) {
      case 9:
      case 11:
        e3 = (e3 = t3.documentElement) && (e3 = e3.namespaceURI) ? up(e3) : 0;
        break;
      default:
        if (e3 = t3.tagName, t3 = t3.namespaceURI) t3 = up(t3), e3 = dp(t3, e3);
        else switch (e3) {
          case `svg`:
            e3 = 1;
            break;
          case `math`:
            e3 = 2;
            break;
          default:
            e3 = 0;
        }
    }
    je(Me), E(Me, e3);
  }
  function Le() {
    je(Me), je(Ne), je(Pe);
  }
  function Re(e3) {
    var t3 = e3.memoizedState;
    t3 !== null && (sh._currentValue = t3.memoizedState, E(Fe, e3)), t3 = Me.current;
    var n2 = dp(t3, e3.type);
    t3 !== n2 && (E(Ne, e3), E(Me, n2));
  }
  function ze(e3) {
    Ne.current === e3 && (je(Me), je(Ne)), Fe.current === e3 && (je(Fe), sh._currentValue = De);
  }
  var Be, Ve;
  function He(e3) {
    if (Be === void 0) try {
      throw Error();
    } catch (e4) {
      var t3 = e4.stack.trim().match(/\n( *(at )?)/);
      Be = t3 && t3[1] || ``, Ve = -1 < e4.stack.indexOf(`
    at`) ? ` (<anonymous>)` : -1 < e4.stack.indexOf(`@`) ? `@unknown:0:0` : ``;
    }
    return `
` + Be + e3 + Ve;
  }
  var Ue = false;
  function We(e3, t3) {
    if (!e3 || Ue) return ``;
    Ue = true;
    var n2 = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      var r3 = { DetermineComponentFrameRoot: function() {
        try {
          if (t3) {
            var n3 = function() {
              throw Error();
            };
            if (Object.defineProperty(n3.prototype, "props", { set: function() {
              throw Error();
            } }), typeof Reflect == `object` && Reflect.construct) {
              try {
                Reflect.construct(n3, []);
              } catch (e4) {
                var r4 = e4;
              }
              Reflect.construct(e3, [], n3);
            } else {
              try {
                n3.call();
              } catch (e4) {
                r4 = e4;
              }
              n3 = false;
              try {
                var i4 = Object.getOwnPropertyDescriptor(e3.prototype, `props`);
                Object.defineProperty(e3.prototype, "props", { configurable: true, set: function() {
                  throw Error();
                } }), n3 = true, new e3();
              } finally {
                n3 && (i4 === void 0 ? delete e3.prototype.props : Object.defineProperty(e3.prototype, "props", i4));
              }
            }
          } else {
            try {
              throw Error();
            } catch (e4) {
              r4 = e4;
            }
            (n3 = e3()) && typeof n3.catch == `function` && n3.catch(function() {
            });
          }
        } catch (e4) {
          if (e4 && r4 && typeof e4.stack == `string`) return [e4.stack, r4.stack];
        }
        return [null, null];
      } };
      r3.DetermineComponentFrameRoot.displayName = `DetermineComponentFrameRoot`;
      var i3 = Object.getOwnPropertyDescriptor(r3.DetermineComponentFrameRoot, `name`);
      i3 && i3.configurable && Object.defineProperty(r3.DetermineComponentFrameRoot, "name", { value: `DetermineComponentFrameRoot` });
      var a3 = r3.DetermineComponentFrameRoot(), o3 = a3[0], s3 = a3[1];
      if (o3 && s3) {
        var c3 = o3.split(`
`), l3 = s3.split(`
`);
        for (i3 = r3 = 0; r3 < c3.length && !c3[r3].includes(`DetermineComponentFrameRoot`); ) r3++;
        for (; i3 < l3.length && !l3[i3].includes(`DetermineComponentFrameRoot`); ) i3++;
        if (r3 === c3.length || i3 === l3.length) for (r3 = c3.length - 1, i3 = l3.length - 1; 1 <= r3 && 0 <= i3 && c3[r3] !== l3[i3]; ) i3--;
        for (; 1 <= r3 && 0 <= i3; r3--, i3--) if (c3[r3] !== l3[i3]) {
          if (r3 !== 1 || i3 !== 1) do
            if (r3--, i3--, 0 > i3 || c3[r3] !== l3[i3]) {
              var u3 = `
` + c3[r3].replace(` at new `, ` at `);
              return e3.displayName && u3.includes(`<anonymous>`) && (u3 = u3.replace(`<anonymous>`, e3.displayName)), u3;
            }
          while (1 <= r3 && 0 <= i3);
          break;
        }
      }
    } finally {
      Ue = false, Error.prepareStackTrace = n2;
    }
    return (n2 = e3 ? e3.displayName || e3.name : ``) ? He(n2) : ``;
  }
  function Ge(e3, t3) {
    switch (e3.tag) {
      case 26:
      case 27:
      case 5:
        return He(e3.type);
      case 16:
        return He(`Lazy`);
      case 13:
        return e3.child !== t3 && t3 !== null ? He(`Suspense Fallback`) : He(`Suspense`);
      case 19:
        return He(`SuspenseList`);
      case 0:
      case 15:
        return We(e3.type, false);
      case 11:
        return We(e3.type.render, false);
      case 1:
        return We(e3.type, true);
      case 31:
        return He(`Activity`);
      case 30:
        return He(`ViewTransition`);
      default:
        return ``;
    }
  }
  function Ke(e3) {
    try {
      var t3 = ``, n2 = null;
      do
        t3 += Ge(e3, n2), n2 = e3, e3 = e3.return;
      while (e3);
      return t3;
    } catch (e4) {
      return `
Error generating stack: ` + e4.message + `
` + e4.stack;
    }
  }
  var qe = Object.prototype.hasOwnProperty, Je = t2.unstable_scheduleCallback, Ye = t2.unstable_cancelCallback, Xe = t2.unstable_shouldYield, Ze = t2.unstable_requestPaint, Qe = t2.unstable_now, $e = t2.unstable_getCurrentPriorityLevel, et = t2.unstable_ImmediatePriority, tt = t2.unstable_UserBlockingPriority, nt = t2.unstable_NormalPriority, rt = t2.unstable_LowPriority, it = t2.unstable_IdlePriority, at = t2.log, ot = t2.unstable_setDisableYieldValue, st = null, ct = null;
  function lt(e3) {
    if (typeof at == `function` && ot(e3), ct && typeof ct.setStrictMode == `function`) try {
      ct.setStrictMode(st, e3);
    } catch {
    }
  }
  var ut = Math.clz32 ? Math.clz32 : pt, dt = Math.log, ft = Math.LN2;
  function pt(e3) {
    return e3 >>>= 0, e3 === 0 ? 32 : 31 - (dt(e3) / ft | 0) | 0;
  }
  var mt = 256, ht = 262144, gt = 4194304;
  function _t(e3) {
    var t3 = e3 & 42;
    if (t3 !== 0) return t3;
    switch (e3 & -e3) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
        return 64;
      case 128:
        return 128;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
        return e3 & -e3;
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return e3 & 3932160;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return e3 & 62914560;
      case 67108864:
        return 67108864;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 0;
      default:
        return e3;
    }
  }
  function vt(e3, t3, n2) {
    var r3 = e3.pendingLanes;
    if (r3 === 0) return 0;
    var i3 = 0, a3 = e3.suspendedLanes, o3 = e3.pingedLanes;
    e3 = e3.warmLanes;
    var s3 = r3 & 134217727;
    return s3 === 0 ? (s3 = r3 & ~a3, s3 === 0 ? o3 === 0 ? n2 || (n2 = r3 & ~e3, n2 !== 0 && (i3 = _t(n2))) : i3 = _t(o3) : i3 = _t(s3)) : (r3 = s3 & ~a3, r3 === 0 ? (o3 &= s3, o3 === 0 ? n2 || (n2 = s3 & ~e3, n2 !== 0 && (i3 = _t(n2))) : i3 = _t(o3)) : i3 = _t(r3)), i3 === 0 ? 0 : t3 !== 0 && t3 !== i3 && (t3 & a3) === 0 && (a3 = i3 & -i3, n2 = t3 & -t3, a3 >= n2 || a3 === 32 && n2 & 4194048) ? t3 : i3;
  }
  function yt(e3, t3) {
    return (e3.pendingLanes & ~(e3.suspendedLanes & ~e3.pingedLanes) & t3) === 0;
  }
  function bt(e3, t3) {
    t3 & 8 && (t3 |= t3 & 32);
    var n2 = e3.entangledLanes;
    if (n2 !== 0) for (e3 = e3.entanglements, n2 &= t3; 0 < n2; ) {
      var r3 = 31 - ut(n2), i3 = 1 << r3;
      t3 |= e3[r3], n2 &= ~i3;
    }
    return t3;
  }
  function xt(e3, t3) {
    switch (e3) {
      case 1:
      case 2:
      case 4:
      case 8:
      case 64:
        return t3 + 250;
      case 16:
      case 32:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t3 + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return -1;
      case 67108864:
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function St() {
    var e3 = gt;
    return gt <<= 1, !(gt & 62914560) && (gt = 4194304), e3;
  }
  function Ct(e3) {
    for (var t3 = [], n2 = 0; 31 > n2; n2++) t3.push(e3);
    return t3;
  }
  function wt(e3, t3) {
    e3.pendingLanes |= t3, t3 !== 268435456 && (e3.suspendedLanes = 0, e3.pingedLanes = 0, e3.warmLanes = 0);
  }
  function Tt(e3, t3, n2, r3, i3, a3) {
    var o3 = e3.pendingLanes;
    e3.pendingLanes = n2, e3.suspendedLanes = 0, e3.pingedLanes = 0, e3.warmLanes = 0, e3.expiredLanes &= n2, e3.entangledLanes &= n2, e3.errorRecoveryDisabledLanes &= n2, e3.shellSuspendCounter = 0;
    var s3 = e3.entanglements, c3 = e3.expirationTimes, l3 = e3.hiddenUpdates;
    for (n2 = o3 & ~n2; 0 < n2; ) {
      var u3 = 31 - ut(n2), d3 = 1 << u3;
      s3[u3] = 0, c3[u3] = -1;
      var f3 = l3[u3];
      if (f3 !== null) for (l3[u3] = null, u3 = 0; u3 < f3.length; u3++) {
        var p3 = f3[u3];
        p3 !== null && (p3.lane &= -536870913);
      }
      n2 &= ~d3;
    }
    r3 !== 0 && Et(e3, r3, 0), a3 !== 0 && i3 === 0 && e3.tag !== 0 && (e3.suspendedLanes |= a3 & ~(o3 & ~t3));
  }
  function Et(e3, t3, n2) {
    e3.pendingLanes |= t3, e3.suspendedLanes &= ~t3;
    var r3 = 31 - ut(t3);
    e3.entangledLanes |= t3, e3.entanglements[r3] = e3.entanglements[r3] | 1073741824 | n2 & 261930;
  }
  function Dt(e3, t3) {
    var n2 = e3.entangledLanes |= t3;
    for (e3 = e3.entanglements; n2; ) {
      var r3 = 31 - ut(n2), i3 = 1 << r3;
      i3 & t3 | e3[r3] & t3 && (e3[r3] |= t3), n2 &= ~i3;
    }
  }
  function Ot(e3, t3) {
    var n2 = t3 & -t3;
    return n2 = n2 & 42 ? 1 : kt(n2), (n2 & (e3.suspendedLanes | t3)) === 0 ? n2 : 0;
  }
  function kt(e3) {
    switch (e3) {
      case 2:
        e3 = 1;
        break;
      case 8:
        e3 = 4;
        break;
      case 32:
        e3 = 16;
        break;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        e3 = 128;
        break;
      case 268435456:
        e3 = 134217728;
        break;
      default:
        e3 = 0;
    }
    return e3;
  }
  function At(e3) {
    return e3 &= -e3, 2 < e3 ? 8 < e3 ? e3 & 134217727 ? 32 : 268435456 : 8 : 2;
  }
  function jt() {
    var e3 = T.p;
    return e3 === 0 ? (e3 = window.event, e3 === void 0 ? 32 : Ch(e3.type)) : e3;
  }
  function Mt(e3, t3) {
    var n2 = T.p;
    try {
      return T.p = e3, t3();
    } finally {
      T.p = n2;
    }
  }
  var Nt = Math.random().toString(36).slice(2), Pt = `__reactFiber$` + Nt, Ft = `__reactProps$` + Nt, It = `__reactContainer$` + Nt, Lt = `__reactEvents$` + Nt, Rt = `__reactListeners$` + Nt, zt = `__reactHandles$` + Nt, Bt = `__reactResources$` + Nt, Vt = `__reactMarker$` + Nt, Ht = `__reactLoad$` + Nt;
  function Ut(e3) {
    delete e3[Pt], delete e3[Ft], delete e3[Rt], delete e3[zt];
  }
  function Wt(e3) {
    var t3;
    if (t3 = e3[Pt]) return t3;
    for (var n2 = e3.parentNode; n2; ) {
      if (t3 = n2[It] || n2[Pt]) {
        if (n2 = t3.alternate, t3.child !== null || n2 !== null && n2.child !== null) for (e3 = fm(e3); e3 !== null; ) {
          if (n2 = e3[Pt]) return n2;
          e3 = fm(e3);
        }
        return t3;
      }
      e3 = n2, n2 = e3.parentNode;
    }
    return null;
  }
  function Gt(e3) {
    if (e3 = e3[Pt] || e3[It]) {
      var t3 = e3.tag;
      if (t3 === 5 || t3 === 6 || t3 === 13 || t3 === 31 || t3 === 26 || t3 === 27 || t3 === 3) return e3;
    }
    return null;
  }
  function Kt(e3) {
    var t3 = e3.tag;
    if (t3 === 5 || t3 === 26 || t3 === 27 || t3 === 6) return e3.stateNode;
    throw Error(a2(33));
  }
  function qt(e3) {
    var t3 = e3[Bt];
    return t3 ||= e3[Bt] = { hoistableStyles: /* @__PURE__ */ new Map(), hoistableScripts: /* @__PURE__ */ new Map() }, t3;
  }
  function D(e3) {
    e3[Vt] = true;
  }
  function Jt(e3) {
    e3[Ht] = void 0;
  }
  var Yt = /* @__PURE__ */ new Set(), Xt = {};
  function Zt(e3, t3) {
    Qt(e3, t3), Qt(e3 + `Capture`, t3);
  }
  function Qt(e3, t3) {
    for (Xt[e3] = t3, e3 = 0; e3 < t3.length; e3++) Yt.add(t3[e3]);
  }
  var $t = RegExp(`^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`), en = {}, tn = {};
  function nn(e3) {
    return qe.call(tn, e3) ? true : qe.call(en, e3) ? false : $t.test(e3) ? tn[e3] = true : (en[e3] = true, false);
  }
  var O = false;
  function rn() {
    var e3 = O;
    return O = false, e3;
  }
  function an(e3, t3, n2) {
    if (nn(t3)) {
      if (n2 === null) e3.removeAttribute(t3);
      else {
        switch (typeof n2) {
          case `undefined`:
          case `function`:
          case `symbol`:
            e3.removeAttribute(t3);
            return;
          case `boolean`:
            var r3 = t3.toLowerCase().slice(0, 5);
            if (r3 !== `data-` && r3 !== `aria-`) {
              e3.removeAttribute(t3);
              return;
            }
        }
        e3.setAttribute(t3, n2);
      }
    }
  }
  function on(e3, t3, n2) {
    if (n2 === null) e3.removeAttribute(t3);
    else {
      switch (typeof n2) {
        case `undefined`:
        case `function`:
        case `symbol`:
        case `boolean`:
          e3.removeAttribute(t3);
          return;
      }
      e3.setAttribute(t3, n2);
    }
  }
  function sn(e3, t3, n2, r3) {
    if (r3 === null) e3.removeAttribute(n2);
    else {
      switch (typeof r3) {
        case `undefined`:
        case `function`:
        case `symbol`:
        case `boolean`:
          e3.removeAttribute(n2);
          return;
      }
      e3.setAttributeNS(t3, n2, r3);
    }
  }
  function cn(e3) {
    switch (typeof e3) {
      case `bigint`:
      case `boolean`:
      case `number`:
      case `string`:
      case `undefined`:
        return e3;
      case `object`:
        return e3;
      default:
        return ``;
    }
  }
  function ln(e3) {
    var t3 = e3.type;
    return (e3 = e3.nodeName) && e3.toLowerCase() === `input` && (t3 === `checkbox` || t3 === `radio`);
  }
  function un(e3, t3, n2) {
    var r3 = Object.getOwnPropertyDescriptor(e3.constructor.prototype, t3);
    if (!e3.hasOwnProperty(t3) && r3 !== void 0 && typeof r3.get == `function` && typeof r3.set == `function`) {
      var i3 = r3.get, a3 = r3.set;
      return Object.defineProperty(e3, t3, { configurable: true, get: function() {
        return i3.call(this);
      }, set: function(e4) {
        n2 = `` + e4, a3.call(this, e4);
      } }), Object.defineProperty(e3, t3, { enumerable: r3.enumerable }), { getValue: function() {
        return n2;
      }, setValue: function(e4) {
        n2 = `` + e4;
      }, stopTracking: function() {
        e3._valueTracker = null, delete e3[t3];
      } };
    }
  }
  function dn(e3) {
    if (!e3._valueTracker) {
      var t3 = ln(e3) ? `checked` : `value`;
      e3._valueTracker = un(e3, t3, `` + e3[t3]);
    }
  }
  function fn(e3) {
    if (!e3) return false;
    var t3 = e3._valueTracker;
    if (!t3) return true;
    var n2 = t3.getValue(), r3 = ``;
    return e3 && (r3 = ln(e3) ? e3.checked ? `true` : `false` : e3.value), e3 = r3, e3 !== n2 && (t3.setValue(e3), true);
  }
  var pn = /[\n"\\]/g;
  function mn(e3) {
    return e3.replace(pn, function(e4) {
      return `\\` + e4.charCodeAt(0).toString(16) + ` `;
    });
  }
  function hn(e3, t3, n2, r3, i3, a3, o3, s3) {
    e3.name = ``, o3 != null && typeof o3 != `function` && typeof o3 != `symbol` && typeof o3 != `boolean` ? e3.type = o3 : e3.removeAttribute(`type`), t3 == null ? o3 !== `submit` && o3 !== `reset` || e3.removeAttribute(`value`) : o3 === `number` ? (t3 === 0 && e3.value === `` || e3.value != t3) && (e3.value = `` + cn(t3)) : e3.value !== `` + cn(t3) && (e3.value = `` + cn(t3)), t3 == null ? n2 == null ? r3 != null && e3.removeAttribute(`value`) : _n(e3, cn(n2)) : o3 === `number` && e3.value == t3 ? _n(e3, cn(e3.value)) : _n(e3, cn(t3)), i3 == null && a3 != null && (e3.defaultChecked = !!a3), i3 != null && (e3.checked = i3 && typeof i3 != `function` && typeof i3 != `symbol`), s3 != null && typeof s3 != `function` && typeof s3 != `symbol` && typeof s3 != `boolean` ? e3.name = `` + cn(s3) : e3.removeAttribute(`name`);
  }
  function gn(e3, t3, n2, r3, i3, a3, o3, s3) {
    if (a3 != null && typeof a3 != `function` && typeof a3 != `symbol` && typeof a3 != `boolean` && (e3.type = a3), t3 != null || n2 != null) {
      if (!(a3 !== `submit` && a3 !== `reset` || t3 != null)) {
        dn(e3);
        return;
      }
      n2 = n2 == null ? `` : `` + cn(n2), t3 = t3 == null ? n2 : `` + cn(t3), s3 || t3 === e3.value || (e3.value = t3), e3.defaultValue = t3;
    }
    r3 ??= i3, r3 = typeof r3 != `function` && typeof r3 != `symbol` && !!r3, e3.checked = s3 ? e3.checked : !!r3, e3.defaultChecked = !!r3, o3 != null && typeof o3 != `function` && typeof o3 != `symbol` && typeof o3 != `boolean` && (e3.name = o3), dn(e3);
  }
  function _n(e3, t3) {
    e3.defaultValue !== `` + t3 && (e3.defaultValue = `` + t3);
  }
  function vn(e3, t3, n2, r3) {
    if (e3 = e3.options, t3) {
      t3 = {};
      for (var i3 = 0; i3 < n2.length; i3++) t3[`$` + n2[i3]] = true;
      for (n2 = 0; n2 < e3.length; n2++) i3 = t3.hasOwnProperty(`$` + e3[n2].value), e3[n2].selected !== i3 && (e3[n2].selected = i3), i3 && r3 && (e3[n2].defaultSelected = true);
    } else {
      for (n2 = `` + cn(n2), t3 = null, i3 = 0; i3 < e3.length; i3++) {
        if (e3[i3].value === n2) {
          e3[i3].selected = true, r3 && (e3[i3].defaultSelected = true);
          return;
        }
        t3 !== null || e3[i3].disabled || (t3 = e3[i3]);
      }
      t3 !== null && (t3.selected = true);
    }
  }
  function yn(e3, t3, n2) {
    if (t3 != null && (t3 = `` + cn(t3), t3 !== e3.value && (e3.value = t3), n2 == null)) {
      e3.defaultValue !== t3 && (e3.defaultValue = t3);
      return;
    }
    e3.defaultValue = n2 == null ? `` : `` + cn(n2);
  }
  function bn(e3, t3, n2, r3) {
    if (t3 == null) {
      if (r3 != null) {
        if (n2 != null) throw Error(a2(92));
        if (Ee(r3)) {
          if (1 < r3.length) throw Error(a2(93));
          r3 = r3[0];
        }
        n2 = r3;
      }
      n2 ??= ``, t3 = n2;
    }
    n2 = cn(t3), e3.defaultValue = n2, r3 = e3.textContent, r3 === n2 && r3 !== `` && r3 !== null && (e3.value = r3), dn(e3);
  }
  function xn(e3, t3) {
    if (t3) {
      var n2 = e3.firstChild;
      if (n2 && n2 === e3.lastChild && n2.nodeType === 3) {
        n2.nodeValue = t3;
        return;
      }
    }
    e3.textContent = t3;
  }
  var Sn = new Set(`animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp`.split(` `));
  function Cn(e3, t3, n2) {
    var r3 = t3.indexOf(`--`) === 0;
    n2 == null || typeof n2 == `boolean` || n2 === `` ? r3 ? e3.setProperty(t3, ``) : t3 === `float` ? e3.cssFloat = `` : e3[t3] = `` : r3 ? e3.setProperty(t3, n2) : typeof n2 != `number` || n2 === 0 || Sn.has(t3) ? t3 === `float` ? e3.cssFloat = n2 : e3[t3] = (`` + n2).trim() : e3[t3] = n2 + `px`;
  }
  function wn(e3, t3, n2) {
    if (t3 != null && typeof t3 != `object`) throw Error(a2(62));
    if (e3 = e3.style, n2 != null) {
      for (var r3 in n2) !n2.hasOwnProperty(r3) || t3 != null && t3.hasOwnProperty(r3) || (r3.indexOf(`--`) === 0 ? e3.setProperty(r3, ``) : r3 === `float` ? e3.cssFloat = `` : e3[r3] = ``, O = true);
      for (var i3 in t3) r3 = t3[i3], t3.hasOwnProperty(i3) && n2[i3] !== r3 && (Cn(e3, i3, r3), O = true);
    } else for (var o3 in t3) t3.hasOwnProperty(o3) && Cn(e3, o3, t3[o3]);
  }
  function Tn(e3) {
    if (e3.indexOf(`-`) === -1) return false;
    switch (e3) {
      case `annotation-xml`:
      case `color-profile`:
      case `font-face`:
      case `font-face-src`:
      case `font-face-uri`:
      case `font-face-format`:
      case `font-face-name`:
      case `missing-glyph`:
        return false;
      default:
        return true;
    }
  }
  var En = /* @__PURE__ */ new Map([[`acceptCharset`, `accept-charset`], [`htmlFor`, `for`], [`httpEquiv`, `http-equiv`], [`crossOrigin`, `crossorigin`], [`accentHeight`, `accent-height`], [`alignmentBaseline`, `alignment-baseline`], [`arabicForm`, `arabic-form`], [`baselineShift`, `baseline-shift`], [`capHeight`, `cap-height`], [`clipPath`, `clip-path`], [`clipRule`, `clip-rule`], [`colorInterpolation`, `color-interpolation`], [`colorInterpolationFilters`, `color-interpolation-filters`], [`colorProfile`, `color-profile`], [`colorRendering`, `color-rendering`], [`dominantBaseline`, `dominant-baseline`], [`enableBackground`, `enable-background`], [`fillOpacity`, `fill-opacity`], [`fillRule`, `fill-rule`], [`floodColor`, `flood-color`], [`floodOpacity`, `flood-opacity`], [`fontFamily`, `font-family`], [`fontSize`, `font-size`], [`fontSizeAdjust`, `font-size-adjust`], [`fontStretch`, `font-stretch`], [`fontStyle`, `font-style`], [`fontVariant`, `font-variant`], [`fontWeight`, `font-weight`], [`glyphName`, `glyph-name`], [`glyphOrientationHorizontal`, `glyph-orientation-horizontal`], [`glyphOrientationVertical`, `glyph-orientation-vertical`], [`horizAdvX`, `horiz-adv-x`], [`horizOriginX`, `horiz-origin-x`], [`imageRendering`, `image-rendering`], [`letterSpacing`, `letter-spacing`], [`lightingColor`, `lighting-color`], [`markerEnd`, `marker-end`], [`markerMid`, `marker-mid`], [`markerStart`, `marker-start`], [`maskType`, `mask-type`], [`overlinePosition`, `overline-position`], [`overlineThickness`, `overline-thickness`], [`paintOrder`, `paint-order`], [`panose-1`, `panose-1`], [`pointerEvents`, `pointer-events`], [`renderingIntent`, `rendering-intent`], [`shapeRendering`, `shape-rendering`], [`stopColor`, `stop-color`], [`stopOpacity`, `stop-opacity`], [`strikethroughPosition`, `strikethrough-position`], [`strikethroughThickness`, `strikethrough-thickness`], [`strokeDasharray`, `stroke-dasharray`], [`strokeDashoffset`, `stroke-dashoffset`], [`strokeLinecap`, `stroke-linecap`], [`strokeLinejoin`, `stroke-linejoin`], [`strokeMiterlimit`, `stroke-miterlimit`], [`strokeOpacity`, `stroke-opacity`], [`strokeWidth`, `stroke-width`], [`textAnchor`, `text-anchor`], [`textDecoration`, `text-decoration`], [`textRendering`, `text-rendering`], [`transformOrigin`, `transform-origin`], [`underlinePosition`, `underline-position`], [`underlineThickness`, `underline-thickness`], [`unicodeBidi`, `unicode-bidi`], [`unicodeRange`, `unicode-range`], [`unitsPerEm`, `units-per-em`], [`vAlphabetic`, `v-alphabetic`], [`vHanging`, `v-hanging`], [`vIdeographic`, `v-ideographic`], [`vMathematical`, `v-mathematical`], [`vectorEffect`, `vector-effect`], [`vertAdvY`, `vert-adv-y`], [`vertOriginX`, `vert-origin-x`], [`vertOriginY`, `vert-origin-y`], [`wordSpacing`, `word-spacing`], [`writingMode`, `writing-mode`], [`xmlnsXlink`, `xmlns:xlink`], [`xHeight`, `x-height`]]), Dn = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
  function On(e3) {
    return Dn.test(`` + e3) ? `javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')` : e3;
  }
  function kn() {
  }
  var An = null;
  function jn(e3) {
    return e3 = e3.target || e3.srcElement || window, e3.correspondingUseElement && (e3 = e3.correspondingUseElement), e3.nodeType === 3 ? e3.parentNode : e3;
  }
  var Mn = null, Nn = null;
  function Pn(e3) {
    var t3 = Gt(e3);
    if (t3 && (e3 = t3.stateNode)) {
      var n2 = e3[Ft] || null;
      a: switch (e3 = t3.stateNode, t3.type) {
        case `input`:
          if (hn(e3, n2.value, n2.defaultValue, n2.defaultValue, n2.checked, n2.defaultChecked, n2.type, n2.name), t3 = n2.name, n2.type === `radio` && t3 != null) {
            for (n2 = e3; n2.parentNode; ) n2 = n2.parentNode;
            for (n2 = n2.querySelectorAll(`input[name="` + mn(`` + t3) + `"][type="radio"]`), t3 = 0; t3 < n2.length; t3++) {
              var r3 = n2[t3];
              if (r3 !== e3 && r3.form === e3.form) {
                var i3 = r3[Ft] || null;
                if (!i3) throw Error(a2(90));
                hn(r3, i3.value, i3.defaultValue, i3.defaultValue, i3.checked, i3.defaultChecked, i3.type, i3.name);
              }
            }
            for (t3 = 0; t3 < n2.length; t3++) r3 = n2[t3], r3.form === e3.form && fn(r3);
          }
          break a;
        case `textarea`:
          yn(e3, n2.value, n2.defaultValue);
          break a;
        case `select`:
          t3 = n2.value, t3 != null && vn(e3, !!n2.multiple, t3, false);
      }
    }
  }
  var Fn = false;
  function In(e3, t3, n2) {
    if (Fn) return e3(t3, n2);
    Fn = true;
    try {
      return e3(t3);
    } finally {
      if (Fn = false, (Mn !== null || Nn !== null) && (zd(), Mn && (t3 = Mn, e3 = Nn, Nn = Mn = null, Pn(t3), e3))) for (t3 = 0; t3 < e3.length; t3++) Pn(e3[t3]);
    }
  }
  function Ln(e3, t3) {
    var n2 = e3.stateNode;
    if (n2 === null) return null;
    var r3 = n2[Ft] || null;
    if (r3 === null) return null;
    n2 = r3[t3];
    a: switch (t3) {
      case `onClick`:
      case `onClickCapture`:
      case `onDoubleClick`:
      case `onDoubleClickCapture`:
      case `onMouseDown`:
      case `onMouseDownCapture`:
      case `onMouseMove`:
      case `onMouseMoveCapture`:
      case `onMouseUp`:
      case `onMouseUpCapture`:
      case `onMouseEnter`:
        (r3 = !r3.disabled) || (e3 = e3.type, r3 = e3 !== `button` && e3 !== `input` && e3 !== `select` && e3 !== `textarea`), e3 = !r3;
        break a;
      default:
        e3 = false;
    }
    if (e3) return null;
    if (n2 && typeof n2 != `function`) throw Error(a2(231, t3, typeof n2));
    return n2;
  }
  var Rn = typeof window < `u` && window.document !== void 0 && window.document.createElement !== void 0, zn = false;
  if (Rn) try {
    var Bn = {};
    Object.defineProperty(Bn, "passive", { get: function() {
      zn = true;
    } }), window.addEventListener(`test`, Bn, Bn), window.removeEventListener(`test`, Bn, Bn);
  } catch {
    zn = false;
  }
  var Vn = null, Hn = null, Un = null;
  function Wn() {
    if (Un) return Un;
    var e3, t3 = Hn, n2 = t3.length, r3, i3 = `value` in Vn ? Vn.value : Vn.textContent, a3 = i3.length;
    for (e3 = 0; e3 < n2 && t3[e3] === i3[e3]; e3++) ;
    var o3 = n2 - e3;
    for (r3 = 1; r3 <= o3 && t3[n2 - r3] === i3[a3 - r3]; r3++) ;
    return Un = i3.slice(e3, 1 < r3 ? 1 - r3 : void 0);
  }
  function Gn(e3) {
    var t3 = e3.keyCode;
    return `charCode` in e3 ? (e3 = e3.charCode, e3 === 0 && t3 === 13 && (e3 = 13)) : e3 = t3, e3 === 10 && (e3 = 13), 32 <= e3 || e3 === 13 ? e3 : 0;
  }
  function Kn() {
    return true;
  }
  function qn() {
    return false;
  }
  function Jn(e3) {
    function t3(t4, n2, r3, i3, a3) {
      for (var o3 in this._reactName = t4, this._targetInst = r3, this.type = n2, this.nativeEvent = i3, this.target = a3, this.currentTarget = null, e3) e3.hasOwnProperty(o3) && (t4 = e3[o3], this[o3] = t4 ? t4(i3) : i3[o3]);
      return this.isDefaultPrevented = (i3.defaultPrevented == null ? false === i3.returnValue : i3.defaultPrevented) ? Kn : qn, this.isPropagationStopped = qn, this;
    }
    return x2(t3.prototype, { preventDefault: function() {
      this.defaultPrevented = true;
      var e4 = this.nativeEvent;
      e4 && (e4.preventDefault ? e4.preventDefault() : typeof e4.returnValue != `unknown` && (e4.returnValue = false), this.isDefaultPrevented = Kn);
    }, stopPropagation: function() {
      var e4 = this.nativeEvent;
      e4 && (e4.stopPropagation ? e4.stopPropagation() : typeof e4.cancelBubble != `unknown` && (e4.cancelBubble = true), this.isPropagationStopped = Kn);
    }, persist: function() {
    }, isPersistent: Kn }), t3;
  }
  var Yn = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(e3) {
    return e3.timeStamp || Date.now();
  }, defaultPrevented: 0, isTrusted: 0 }, Xn = Jn(Yn), Zn = x2({}, Yn, { view: 0, detail: 0 }), Qn = Jn(Zn), $n, er, tr, nr = x2({}, Zn, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: pr, button: 0, buttons: 0, relatedTarget: function(e3) {
    return e3.relatedTarget === void 0 ? e3.fromElement === e3.srcElement ? e3.toElement : e3.fromElement : e3.relatedTarget;
  }, movementX: function(e3) {
    return `movementX` in e3 ? e3.movementX : (e3 !== tr && (tr && e3.type === `mousemove` ? ($n = e3.screenX - tr.screenX, er = e3.screenY - tr.screenY) : er = $n = 0, tr = e3), $n);
  }, movementY: function(e3) {
    return `movementY` in e3 ? e3.movementY : er;
  } }), rr = Jn(nr), ir = Jn(x2({}, nr, { dataTransfer: 0 })), ar = Jn(x2({}, Zn, { relatedTarget: 0 })), or = Jn(x2({}, Yn, { animationName: 0, elapsedTime: 0, pseudoElement: 0 })), sr = Jn(x2({}, Yn, { clipboardData: function(e3) {
    return `clipboardData` in e3 ? e3.clipboardData : window.clipboardData;
  } })), cr = Jn(x2({}, Yn, { data: 0 })), lr = { Esc: `Escape`, Spacebar: ` `, Left: `ArrowLeft`, Up: `ArrowUp`, Right: `ArrowRight`, Down: `ArrowDown`, Del: `Delete`, Win: `OS`, Menu: `ContextMenu`, Apps: `ContextMenu`, Scroll: `ScrollLock`, MozPrintableKey: `Unidentified` }, ur = { 8: `Backspace`, 9: `Tab`, 12: `Clear`, 13: `Enter`, 16: `Shift`, 17: `Control`, 18: `Alt`, 19: `Pause`, 20: `CapsLock`, 27: `Escape`, 32: ` `, 33: `PageUp`, 34: `PageDown`, 35: `End`, 36: `Home`, 37: `ArrowLeft`, 38: `ArrowUp`, 39: `ArrowRight`, 40: `ArrowDown`, 45: `Insert`, 46: `Delete`, 112: `F1`, 113: `F2`, 114: `F3`, 115: `F4`, 116: `F5`, 117: `F6`, 118: `F7`, 119: `F8`, 120: `F9`, 121: `F10`, 122: `F11`, 123: `F12`, 144: `NumLock`, 145: `ScrollLock`, 224: `Meta` }, dr = { Alt: `altKey`, Control: `ctrlKey`, Meta: `metaKey`, Shift: `shiftKey` };
  function fr(e3) {
    var t3 = this.nativeEvent;
    return t3.getModifierState ? t3.getModifierState(e3) : (e3 = dr[e3]) ? !!t3[e3] : false;
  }
  function pr() {
    return fr;
  }
  var mr = Jn(x2({}, Zn, { key: function(e3) {
    if (e3.key) {
      var t3 = lr[e3.key] || e3.key;
      if (t3 !== `Unidentified`) return t3;
    }
    return e3.type === `keypress` ? (e3 = Gn(e3), e3 === 13 ? `Enter` : String.fromCharCode(e3)) : e3.type === `keydown` || e3.type === `keyup` ? ur[e3.keyCode] || `Unidentified` : ``;
  }, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: pr, charCode: function(e3) {
    return e3.type === `keypress` ? Gn(e3) : 0;
  }, keyCode: function(e3) {
    return e3.type === `keydown` || e3.type === `keyup` ? e3.keyCode : 0;
  }, which: function(e3) {
    return e3.type === `keypress` ? Gn(e3) : e3.type === `keydown` || e3.type === `keyup` ? e3.keyCode : 0;
  } })), hr = Jn(x2({}, nr, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 })), gr = Jn(x2({}, Yn, { submitter: 0 })), _r = Jn(x2({}, Zn, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: pr })), vr = Jn(x2({}, Yn, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 })), yr = Jn(x2({}, nr, { deltaX: function(e3) {
    return `deltaX` in e3 ? e3.deltaX : `wheelDeltaX` in e3 ? -e3.wheelDeltaX : 0;
  }, deltaY: function(e3) {
    return `deltaY` in e3 ? e3.deltaY : `wheelDeltaY` in e3 ? -e3.wheelDeltaY : `wheelDelta` in e3 ? -e3.wheelDelta : 0;
  }, deltaZ: 0, deltaMode: 0 })), br = Jn(x2({}, Yn, { newState: 0, oldState: 0, source: 0 })), xr = [9, 13, 27, 32], Sr = Rn && `CompositionEvent` in window, Cr = null;
  Rn && `documentMode` in document && (Cr = document.documentMode);
  var wr = Rn && `TextEvent` in window && !Cr, Tr = Rn && (!Sr || Cr && 8 < Cr && 11 >= Cr), Er = ` `, Dr = false;
  function Or(e3, t3) {
    switch (e3) {
      case `keyup`:
        return xr.indexOf(t3.keyCode) !== -1;
      case `keydown`:
        return t3.keyCode !== 229;
      case `keypress`:
      case `mousedown`:
      case `focusout`:
        return true;
      default:
        return false;
    }
  }
  function kr(e3) {
    return e3 = e3.detail, typeof e3 == `object` && `data` in e3 ? e3.data : null;
  }
  var Ar = false;
  function jr(e3, t3) {
    switch (e3) {
      case `compositionend`:
        return kr(t3);
      case `keypress`:
        return t3.which === 32 ? (Dr = true, Er) : null;
      case `textInput`:
        return e3 = t3.data, e3 === Er && Dr ? null : e3;
      default:
        return null;
    }
  }
  function Mr(e3, t3) {
    if (Ar) return e3 === `compositionend` || !Sr && Or(e3, t3) ? (e3 = Wn(), Un = Hn = Vn = null, Ar = false, e3) : null;
    switch (e3) {
      case `paste`:
        return null;
      case `keypress`:
        if (!(t3.ctrlKey || t3.altKey || t3.metaKey) || t3.ctrlKey && t3.altKey) {
          if (t3.char && 1 < t3.char.length) return t3.char;
          if (t3.which) return String.fromCharCode(t3.which);
        }
        return null;
      case `compositionend`:
        return Tr && t3.locale !== `ko` ? null : t3.data;
      default:
        return null;
    }
  }
  var Nr = { color: true, date: true, datetime: true, "datetime-local": true, email: true, month: true, number: true, password: true, range: true, search: true, tel: true, text: true, time: true, url: true, week: true };
  function Pr(e3) {
    var t3 = e3 && e3.nodeName && e3.nodeName.toLowerCase();
    return t3 === `input` ? !!Nr[e3.type] : t3 === `textarea`;
  }
  function Fr(e3, t3, n2, r3) {
    Mn ? Nn ? Nn.push(r3) : Nn = [r3] : Mn = r3, t3 = Jf(t3, `onChange`), 0 < t3.length && (n2 = new Xn(`onChange`, `change`, null, n2, r3), e3.push({ event: n2, listeners: t3 }));
  }
  var Ir = null, Lr = null;
  function Rr(e3) {
    Vf(e3, 0);
  }
  function zr(e3) {
    if (fn(Kt(e3))) return e3;
  }
  function Br(e3, t3) {
    if (e3 === `change`) return t3;
  }
  var Vr = false;
  if (Rn) {
    var Hr;
    if (Rn) {
      var Ur = `oninput` in document;
      if (!Ur) {
        var Wr = document.createElement(`div`);
        Wr.setAttribute(`oninput`, `return;`), Ur = typeof Wr.oninput == `function`;
      }
      Hr = Ur;
    } else Hr = false;
    Vr = Hr && (!document.documentMode || 9 < document.documentMode);
  }
  function Gr() {
    Ir && (Ir.detachEvent(`onpropertychange`, Kr), Lr = Ir = null);
  }
  function Kr(e3) {
    if (e3.propertyName === `value` && zr(Lr)) {
      var t3 = [];
      Fr(t3, Lr, e3, jn(e3)), In(Rr, t3);
    }
  }
  function qr(e3, t3, n2) {
    e3 === `focusin` ? (Gr(), Ir = t3, Lr = n2, Ir.attachEvent(`onpropertychange`, Kr)) : e3 === `focusout` && Gr();
  }
  function Jr(e3) {
    if (e3 === `selectionchange` || e3 === `keyup` || e3 === `keydown`) return zr(Lr);
  }
  function Yr(e3, t3) {
    if (e3 === `click`) return zr(t3);
  }
  function Xr(e3, t3) {
    if (e3 === `input` || e3 === `change`) return zr(t3);
  }
  function Zr(e3, t3) {
    return e3 === t3 && (e3 !== 0 || 1 / e3 == 1 / t3) || e3 !== e3 && t3 !== t3;
  }
  var Qr = typeof Object.is == `function` ? Object.is : Zr;
  function $r(e3, t3) {
    if (Qr(e3, t3)) return true;
    if (typeof e3 != `object` || !e3 || typeof t3 != `object` || !t3) return false;
    var n2 = Object.keys(e3), r3 = Object.keys(t3);
    if (n2.length !== r3.length) return false;
    for (r3 = 0; r3 < n2.length; r3++) {
      var i3 = n2[r3];
      if (!qe.call(t3, i3) || !Qr(e3[i3], t3[i3])) return false;
    }
    return true;
  }
  function ei(e3) {
    if (e3 ||= typeof document < `u` ? document : void 0, e3 === void 0) return null;
    try {
      return e3.activeElement || e3.body;
    } catch {
      return e3.body;
    }
  }
  function ti(e3) {
    for (; e3 && e3.firstChild; ) e3 = e3.firstChild;
    return e3;
  }
  function ni(e3, t3) {
    var n2 = ti(e3);
    e3 = 0;
    for (var r3; n2; ) {
      if (n2.nodeType === 3) {
        if (r3 = e3 + n2.textContent.length, e3 <= t3 && r3 >= t3) return { node: n2, offset: t3 - e3 };
        e3 = r3;
      }
      a: {
        for (; n2; ) {
          if (n2.nextSibling) {
            n2 = n2.nextSibling;
            break a;
          }
          n2 = n2.parentNode;
        }
        n2 = void 0;
      }
      n2 = ti(n2);
    }
  }
  function ri(e3, t3) {
    return e3 && t3 ? e3 === t3 ? true : e3 && e3.nodeType === 3 ? false : t3 && t3.nodeType === 3 ? ri(e3, t3.parentNode) : `contains` in e3 ? e3.contains(t3) : e3.compareDocumentPosition ? !!(e3.compareDocumentPosition(t3) & 16) : false : false;
  }
  function ii(e3) {
    e3 = e3 != null && e3.ownerDocument != null && e3.ownerDocument.defaultView != null ? e3.ownerDocument.defaultView : window;
    for (var t3 = ei(e3.document); t3 instanceof e3.HTMLIFrameElement; ) {
      try {
        var n2 = typeof t3.contentWindow.location.href == `string`;
      } catch {
        n2 = false;
      }
      if (n2) e3 = t3.contentWindow;
      else break;
      t3 = ei(e3.document);
    }
    return t3;
  }
  function ai(e3) {
    var t3 = e3 && e3.nodeName && e3.nodeName.toLowerCase();
    return t3 && (t3 === `input` && (e3.type === `text` || e3.type === `search` || e3.type === `tel` || e3.type === `url` || e3.type === `password`) || t3 === `textarea` || e3.contentEditable === `true`);
  }
  var oi = Rn && `documentMode` in document && 11 >= document.documentMode, si = null, ci = null, li = null, ui = false;
  function di(e3, t3, n2) {
    var r3 = n2.window === n2 ? n2.document : n2.nodeType === 9 ? n2 : n2.ownerDocument;
    ui || si == null || si !== ei(r3) || (r3 = si, `selectionStart` in r3 && ai(r3) ? r3 = { start: r3.selectionStart, end: r3.selectionEnd } : (r3 = (r3.ownerDocument && r3.ownerDocument.defaultView || window).getSelection(), r3 = { anchorNode: r3.anchorNode, anchorOffset: r3.anchorOffset, focusNode: r3.focusNode, focusOffset: r3.focusOffset }), li && $r(li, r3) || (li = r3, r3 = Jf(ci, `onSelect`), 0 < r3.length && (t3 = new Xn(`onSelect`, `select`, null, t3, n2), e3.push({ event: t3, listeners: r3 }), t3.target = si)));
  }
  function fi(e3, t3) {
    var n2 = {};
    return n2[e3.toLowerCase()] = t3.toLowerCase(), n2[`Webkit` + e3] = `webkit` + t3, n2[`Moz` + e3] = `moz` + t3, n2;
  }
  var pi = { animationend: fi(`Animation`, `AnimationEnd`), animationiteration: fi(`Animation`, `AnimationIteration`), animationstart: fi(`Animation`, `AnimationStart`), transitionrun: fi(`Transition`, `TransitionRun`), transitionstart: fi(`Transition`, `TransitionStart`), transitioncancel: fi(`Transition`, `TransitionCancel`), transitionend: fi(`Transition`, `TransitionEnd`) }, mi = {}, hi = {};
  Rn && (hi = document.createElement(`div`).style, `AnimationEvent` in window || (delete pi.animationend.animation, delete pi.animationiteration.animation, delete pi.animationstart.animation), `TransitionEvent` in window || delete pi.transitionend.transition);
  function gi(e3) {
    if (mi[e3]) return mi[e3];
    if (!pi[e3]) return e3;
    var t3 = pi[e3], n2;
    for (n2 in t3) if (t3.hasOwnProperty(n2) && n2 in hi) return mi[e3] = t3[n2];
    return e3;
  }
  var _i = gi(`animationend`), vi = gi(`animationiteration`), yi = gi(`animationstart`), bi = gi(`transitionrun`), xi = gi(`transitionstart`), Si = gi(`transitioncancel`), Ci = gi(`transitionend`), wi = /* @__PURE__ */ new Map(), Ti = `abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(` `);
  Ti.push(`scrollEnd`);
  function Ei(e3, t3) {
    wi.set(e3, t3), Zt(t3, [e3]);
  }
  var Di = 0;
  function Oi(e3, t3) {
    if (e3.name != null && e3.name !== `auto`) return e3.name;
    if (t3.autoName !== null) return t3.autoName;
    e3 = bd.identifierPrefix;
    var n2 = Di++;
    return e3 = `_` + e3 + `t_` + n2.toString(32) + `_`, t3.autoName = e3;
  }
  function ki(e3) {
    if (e3 == null || typeof e3 == `string`) return e3;
    var t3 = null, n2 = Od;
    if (n2 !== null) for (var r3 = 0; r3 < n2.length; r3++) {
      var i3 = e3[n2[r3]];
      if (i3 != null) {
        if (i3 === `none`) return `none`;
        t3 = t3 == null ? i3 : t3 + (` ` + i3);
      }
    }
    return t3 ?? e3.default;
  }
  function Ai(e3, t3) {
    return e3 = ki(e3), t3 = ki(t3), t3 == null ? e3 === `auto` ? null : e3 : t3 === `auto` ? null : t3;
  }
  var ji = typeof reportError == `function` ? reportError : function(e3) {
    if (typeof window == `object` && typeof window.ErrorEvent == `function`) {
      var t3 = new window.ErrorEvent(`error`, { bubbles: true, cancelable: true, message: typeof e3 == `object` && e3 && typeof e3.message == `string` ? String(e3.message) : String(e3), error: e3 });
      if (!window.dispatchEvent(t3)) return;
    } else if (typeof process == `object` && typeof process.emit == `function`) {
      process.emit(`uncaughtException`, e3);
      return;
    }
    console.error(e3);
  }, Mi = [], Ni = 0, Pi = 0;
  function Fi() {
    for (var e3 = Ni, t3 = Pi = Ni = 0; t3 < e3; ) {
      var n2 = Mi[t3];
      Mi[t3++] = null;
      var r3 = Mi[t3];
      Mi[t3++] = null;
      var i3 = Mi[t3];
      Mi[t3++] = null;
      var a3 = Mi[t3];
      if (Mi[t3++] = null, r3 !== null && i3 !== null) {
        var o3 = r3.pending;
        o3 === null ? i3.next = i3 : (i3.next = o3.next, o3.next = i3), r3.pending = i3;
      }
      a3 !== 0 && zi(n2, i3, a3);
    }
  }
  function Ii(e3, t3, n2, r3) {
    Mi[Ni++] = e3, Mi[Ni++] = t3, Mi[Ni++] = n2, Mi[Ni++] = r3, Pi |= r3, e3.lanes |= r3, e3 = e3.alternate, e3 !== null && (e3.lanes |= r3);
  }
  function Li(e3, t3, n2, r3) {
    return Ii(e3, t3, n2, r3), Bi(e3);
  }
  function Ri(e3, t3) {
    return Ii(e3, null, null, t3), Bi(e3);
  }
  function zi(e3, t3, n2) {
    e3.lanes |= n2;
    var r3 = e3.alternate;
    r3 !== null && (r3.lanes |= n2);
    for (var i3 = false, a3 = e3.return; a3 !== null; ) a3.childLanes |= n2, r3 = a3.alternate, r3 !== null && (r3.childLanes |= n2), a3.tag === 22 && (e3 = a3.stateNode, e3 === null || e3._visibility & 1 || (i3 = true)), e3 = a3, a3 = a3.return;
    return e3.tag === 3 ? (a3 = e3.stateNode, i3 && t3 !== null && (i3 = 31 - ut(n2), e3 = a3.hiddenUpdates, r3 = e3[i3], r3 === null ? e3[i3] = [t3] : r3.push(t3), t3.lane = n2 | 536870912), a3) : null;
  }
  function Bi(e3) {
    if (50 < kd) throw kd = 0, Ad = null, Error(a2(185));
    for (var t3 = e3.return; t3 !== null; ) e3 = t3, t3 = e3.return;
    return e3.tag === 3 ? e3.stateNode : null;
  }
  var Vi = {};
  function Hi(e3, t3, n2, r3) {
    this.tag = e3, this.key = n2, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t3, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r3, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
  }
  function Ui(e3, t3, n2, r3) {
    return new Hi(e3, t3, n2, r3);
  }
  function Wi(e3) {
    return e3 = e3.prototype, !(!e3 || !e3.isReactComponent);
  }
  function Gi(e3, t3) {
    var n2 = e3.alternate;
    return n2 === null ? (n2 = Ui(e3.tag, t3, e3.key, e3.mode), n2.elementType = e3.elementType, n2.type = e3.type, n2.stateNode = e3.stateNode, n2.alternate = e3, e3.alternate = n2) : (n2.pendingProps = t3, n2.type = e3.type, n2.flags = 0, n2.subtreeFlags = 0, n2.deletions = null), n2.flags = e3.flags & 1206910976, n2.childLanes = e3.childLanes, n2.lanes = e3.lanes, n2.child = e3.child, n2.memoizedProps = e3.memoizedProps, n2.memoizedState = e3.memoizedState, n2.updateQueue = e3.updateQueue, t3 = e3.dependencies, n2.dependencies = t3 === null ? null : { lanes: t3.lanes, firstContext: t3.firstContext }, n2.sibling = e3.sibling, n2.index = e3.index, n2.ref = e3.ref, n2.refCleanup = e3.refCleanup, n2;
  }
  function Ki(e3, t3) {
    e3.flags &= 1206910978;
    var n2 = e3.alternate;
    return n2 === null ? (e3.childLanes = 0, e3.lanes = t3, e3.child = null, e3.subtreeFlags = 0, e3.memoizedProps = null, e3.memoizedState = null, e3.updateQueue = null, e3.dependencies = null, e3.stateNode = null) : (e3.childLanes = n2.childLanes, e3.lanes = n2.lanes, e3.child = n2.child, e3.subtreeFlags = 0, e3.deletions = null, e3.memoizedProps = n2.memoizedProps, e3.memoizedState = n2.memoizedState, e3.updateQueue = n2.updateQueue, e3.type = n2.type, t3 = n2.dependencies, e3.dependencies = t3 === null ? null : { lanes: t3.lanes, firstContext: t3.firstContext }), e3;
  }
  function qi(e3, t3, n2, r3, i3, o3) {
    var s3 = 0;
    if (r3 = e3, typeof r3 == `function`) Wi(r3) && (s3 = 1);
    else if (typeof r3 == `string`) s3 = qm(e3, n2, Me.current) ? 26 : e3 === `html` || e3 === `head` || e3 === `body` ? 27 : 5;
    else a: switch (r3) {
      case C:
        return e3 = Ui(31, n2, t3, i3), e3.elementType = C, e3.lanes = o3, e3;
      case le2:
        return Ji(n2.children, i3, o3, t3);
      case ue2:
        s3 = 8, i3 |= 24;
        break;
      case de:
        return e3 = Ui(12, n2, t3, i3 | 2), e3.elementType = de, e3.lanes = o3, e3;
      case me:
        return e3 = Ui(13, n2, t3, i3), e3.elementType = me, e3.lanes = o3, e3;
      case he:
        return e3 = Ui(19, n2, t3, i3), e3.elementType = he, e3.lanes = o3, e3;
      case ve:
      case be:
        return e3 = i3 | 32, e3 = Ui(30, n2, t3, e3), e3.elementType = be, e3.lanes = o3, e3.stateNode = { autoName: null, paired: null, clones: null, ref: null }, e3;
      default:
        if (typeof r3 == `object` && r3) switch (r3.$$typeof) {
          case S:
            s3 = 10;
            break a;
          case fe:
            s3 = 9;
            break a;
          case pe:
            s3 = 11;
            break a;
          case ge:
            s3 = 14;
            break a;
          case _e:
            s3 = 16, r3 = null;
            break a;
        }
        s3 = 29, n2 = Error(a2(130, e3 === null ? `null` : typeof e3, ``)), r3 = null;
    }
    return t3 = Ui(s3, n2, t3, i3), t3.elementType = e3, t3.type = r3, t3.lanes = o3, t3;
  }
  function Ji(e3, t3, n2, r3) {
    return e3 = Ui(7, e3, r3, t3), e3.lanes = n2, e3;
  }
  function Yi(e3, t3, n2) {
    return e3 = Ui(6, e3, null, t3), e3.lanes = n2, e3;
  }
  function Xi(e3) {
    var t3 = Ui(18, null, null, 0);
    return t3.stateNode = e3, t3;
  }
  function Zi(e3, t3, n2) {
    return t3 = Ui(4, e3.children === null ? [] : e3.children, e3.key, t3), t3.lanes = n2, t3.stateNode = { containerInfo: e3.containerInfo, pendingChildren: null, implementation: e3.implementation }, t3;
  }
  var Qi = /* @__PURE__ */ new WeakMap();
  function $i(e3, t3) {
    if (typeof e3 == `object` && e3) {
      var n2 = Qi.get(e3);
      return n2 === void 0 ? (t3 = { value: e3, source: t3, stack: Ke(t3) }, Qi.set(e3, t3), t3) : n2;
    }
    return { value: e3, source: t3, stack: Ke(t3) };
  }
  var ea = [], ta = 0, na = null, ra = 0, ia = [], aa = 0, oa = null, sa = 1, ca = ``;
  function la(e3, t3) {
    ea[ta++] = ra, ea[ta++] = na, na = e3, ra = t3;
  }
  function ua(e3, t3, n2) {
    ia[aa++] = sa, ia[aa++] = ca, ia[aa++] = oa, oa = e3;
    var r3 = sa;
    e3 = ca;
    var i3 = 32 - ut(r3) - 1;
    r3 &= ~(1 << i3), n2 += 1;
    var a3 = 32 - ut(t3) + i3;
    if (30 < a3) {
      var o3 = i3 - i3 % 5;
      a3 = (r3 & (1 << o3) - 1).toString(32), r3 >>= o3, i3 -= o3, sa = 1 << 32 - ut(t3) + i3 | n2 << i3 | r3, ca = a3 + e3;
    } else sa = 1 << a3 | n2 << i3 | r3, ca = e3;
  }
  function da(e3) {
    e3.return !== null && (la(e3, 1), ua(e3, 1, 0));
  }
  function fa(e3) {
    for (; e3 === na; ) na = ea[--ta], ea[ta] = null, ra = ea[--ta], ea[ta] = null;
    for (; e3 === oa; ) oa = ia[--aa], ia[aa] = null, ca = ia[--aa], ia[aa] = null, sa = ia[--aa], ia[aa] = null;
  }
  function pa(e3, t3) {
    ia[aa++] = sa, ia[aa++] = ca, ia[aa++] = oa, sa = t3.id, ca = t3.overflow, oa = e3;
  }
  var ma = null, k = null, A = false, ha = null, ga = false, _a = Error(a2(519));
  function va(e3) {
    throw wa($i(Error(a2(418, 1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? `text` : `HTML`, ``)), e3)), _a;
  }
  function ya(e3) {
    var t3 = e3.stateNode, n2 = e3.type, r3 = e3.memoizedProps;
    switch (t3[Pt] = e3, t3[Ft] = r3, n2) {
      case `dialog`:
        Q(`cancel`, t3), Q(`close`, t3);
        break;
      case `iframe`:
      case `object`:
      case `embed`:
        Q(`load`, t3);
        break;
      case `video`:
      case `audio`:
        for (n2 = 0; n2 < zf.length; n2++) Q(zf[n2], t3);
        break;
      case `source`:
        Q(`error`, t3);
        break;
      case `img`:
      case `image`:
      case `link`:
        Q(`error`, t3), Q(`load`, t3);
        break;
      case `details`:
        Q(`toggle`, t3);
        break;
      case `input`:
        Q(`invalid`, t3), gn(t3, r3.value, r3.defaultValue, r3.checked, r3.defaultChecked, r3.type, r3.name, true);
        break;
      case `select`:
        Q(`invalid`, t3);
        break;
      case `textarea`:
        Q(`invalid`, t3), bn(t3, r3.value, r3.defaultValue, r3.children);
    }
    n2 = r3.children, typeof n2 != `string` && typeof n2 != `number` && typeof n2 != `bigint` || t3.textContent === `` + n2 || true === r3.suppressHydrationWarning || ep(t3.textContent, n2) ? (r3.popover != null && (Q(`beforetoggle`, t3), Q(`toggle`, t3)), r3.onScroll != null && Q(`scroll`, t3), r3.onScrollEnd != null && Q(`scrollend`, t3), r3.onClick != null && (t3.onclick = kn), t3 = true) : t3 = false, t3 || va(e3, true);
  }
  function ba(e3) {
    for (ma = e3.return; ma; ) switch (ma.tag) {
      case 5:
      case 31:
      case 13:
        ga = false;
        return;
      case 27:
      case 3:
        ga = true;
        return;
      default:
        ma = ma.return;
    }
  }
  function xa(e3) {
    if (e3 !== ma) return false;
    if (!A) return ba(e3), A = true, false;
    var t3 = e3.tag, n2;
    if ((n2 = t3 !== 3 && t3 !== 27) && ((n2 = t3 === 5) && (n2 = e3.type, n2 = n2 === `form` || n2 === `button` || pp(e3.type, e3.memoizedProps)), n2 = !n2), n2 && k && va(e3), ba(e3), t3 === 13) {
      if (e3 = e3.memoizedState, e3 = e3 === null ? null : e3.dehydrated, !e3) throw Error(a2(317));
      k = dm(e3);
    } else if (t3 === 31) {
      if (e3 = e3.memoizedState, e3 = e3 === null ? null : e3.dehydrated, !e3) throw Error(a2(317));
      k = dm(e3);
    } else t3 === 27 ? (t3 = k, Sp(e3.type) ? (e3 = um, um = null, k = e3) : k = t3) : k = ma ? lm(e3.stateNode.nextSibling) : null;
    return true;
  }
  function Sa() {
    k = ma = null, A = false;
  }
  function Ca() {
    var e3 = ha;
    return e3 !== null && (pd === null ? pd = e3 : pd.push.apply(pd, e3), ha = null), e3;
  }
  function wa(e3) {
    ha === null ? ha = [e3] : ha.push(e3);
  }
  var Ta = Ae(null), Ea = null, Da = null;
  function Oa(e3, t3, n2) {
    E(Ta, t3._currentValue), t3._currentValue = n2;
  }
  function ka(e3) {
    e3._currentValue = Ta.current, je(Ta);
  }
  function Aa(e3, t3, n2) {
    for (; e3 !== null; ) {
      var r3 = e3.alternate;
      if ((e3.childLanes & t3) === t3 ? r3 !== null && (r3.childLanes & t3) !== t3 && (r3.childLanes |= t3) : (e3.childLanes |= t3, r3 !== null && (r3.childLanes |= t3)), e3 === n2) break;
      e3 = e3.return;
    }
  }
  function ja(e3, t3, n2, r3) {
    var i3 = e3.child;
    for (i3 !== null && (i3.return = e3); i3 !== null; ) {
      var o3 = i3.dependencies;
      if (o3 !== null) {
        var s3 = i3.child;
        o3 = o3.firstContext;
        a: for (; o3 !== null; ) {
          var c3 = o3;
          o3 = i3;
          for (var l3 = 0; l3 < t3.length; l3++) if (c3.context === t3[l3]) {
            o3.lanes |= n2, c3 = o3.alternate, c3 !== null && (c3.lanes |= n2), Aa(o3.return, n2, e3), r3 || (s3 = null);
            break a;
          }
          o3 = c3.next;
        }
      } else if (i3.tag === 18) {
        if (s3 = i3.return, s3 === null) throw Error(a2(341));
        s3.lanes |= n2, o3 = s3.alternate, o3 !== null && (o3.lanes |= n2), Aa(s3, n2, e3), s3 = null;
      } else i3.tag === 13 && i3.memoizedState !== null && i3.memoizedState.dehydrated === null ? (i3.lanes |= n2, s3 = i3.alternate, s3 !== null && (s3.lanes |= n2), Aa(i3.return, n2, e3), s3 = i3.child, s3 = s3 === null ? null : s3.sibling) : s3 = i3.child;
      if (s3 !== null) s3.return = i3;
      else for (s3 = i3; s3 !== null; ) {
        if (s3 === e3) {
          s3 = null;
          break;
        }
        if (i3 = s3.sibling, i3 !== null) {
          i3.return = s3.return, s3 = i3;
          break;
        }
        s3 = s3.return;
      }
      i3 = s3;
    }
  }
  function Ma(e3, t3, n2, r3) {
    e3 = null;
    for (var i3 = t3, o3 = false; i3 !== null; ) {
      if (!o3) {
        if (i3.flags & 524288) o3 = true;
        else if (i3.flags & 262144) break;
      }
      if (i3.tag === 10) {
        var s3 = i3.alternate;
        if (s3 === null) throw Error(a2(387));
        if (s3 = s3.memoizedProps, s3 !== null) {
          var c3 = i3.type;
          Qr(i3.pendingProps.value, s3.value) || (e3 === null ? e3 = [c3] : e3.push(c3));
        }
      } else if (i3 === Fe.current) {
        if (s3 = i3.alternate, s3 === null) throw Error(a2(387));
        s3.memoizedState.memoizedState !== i3.memoizedState.memoizedState && (e3 === null ? e3 = [sh] : e3.push(sh));
      }
      i3 = i3.return;
    }
    return e3 !== null && ja(t3, e3, n2, r3), t3.flags |= 262144, e3 !== null;
  }
  function Na(e3) {
    for (e3 = e3.firstContext; e3 !== null; ) {
      if (!Qr(e3.context._currentValue, e3.memoizedValue)) return true;
      e3 = e3.next;
    }
    return false;
  }
  function Pa(e3) {
    Ea = e3, Da = null, e3 = e3.dependencies, e3 !== null && (e3.firstContext = null);
  }
  function Fa(e3) {
    return La(Ea, e3);
  }
  function Ia(e3, t3) {
    return Ea === null && Pa(e3), La(e3, t3);
  }
  function La(e3, t3) {
    var n2 = t3._currentValue;
    if (t3 = { context: t3, memoizedValue: n2, next: null }, Da === null) {
      if (e3 === null) throw Error(a2(308));
      Da = t3, e3.dependencies = { lanes: 0, firstContext: t3 }, e3.flags |= 524288;
    } else Da = Da.next = t3;
    return n2;
  }
  var Ra = typeof AbortController < `u` ? AbortController : function() {
    var e3 = [], t3 = this.signal = { aborted: false, addEventListener: function(t4, n2) {
      e3.push(n2);
    } };
    this.abort = function() {
      t3.aborted = true, e3.forEach(function(e4) {
        return e4();
      });
    };
  }, za = t2.unstable_scheduleCallback, Ba = t2.unstable_NormalPriority, j = { $$typeof: S, Consumer: null, Provider: null, _currentValue: null, _currentValue2: null, _threadCount: 0 };
  function Va() {
    return { controller: new Ra(), data: /* @__PURE__ */ new Map(), refCount: 0 };
  }
  function Ha(e3) {
    e3.refCount--, e3.refCount === 0 && za(Ba, function() {
      e3.controller.abort();
    });
  }
  function Ua(e3, t3) {
    if (e3.pendingLanes & 4194048) {
      var n2 = e3.transitionTypes;
      for (n2 === null && (n2 = e3.transitionTypes = []), e3 = 0; e3 < t3.length; e3++) {
        var r3 = t3[e3];
        n2.indexOf(r3) === -1 && n2.push(r3);
      }
    }
  }
  var Wa = null;
  function Ga(e3) {
    var t3 = e3.transitionTypes;
    return e3.transitionTypes = null, t3;
  }
  var Ka = null, qa = 0, Ja = 0, Ya = null;
  function Xa(e3, t3) {
    if (Ka === null) {
      var n2 = Ka = [];
      qa = 0, Ja = Pf(), Ya = { status: `pending`, value: void 0, then: function(e4) {
        n2.push(e4);
      } };
    }
    return qa++, t3.then(Za, Za), t3;
  }
  function Za() {
    if (--qa === 0 && (Wa = null, Ka !== null)) {
      Ya !== null && (Ya.status = `fulfilled`);
      var e3 = Ka;
      Ka = null, Ja = 0, Ya = null;
      for (var t3 = 0; t3 < e3.length; t3++) (0, e3[t3])();
    }
  }
  function Qa(e3, t3) {
    var n2 = [], r3 = { status: `pending`, value: null, reason: null, then: function(e4) {
      n2.push(e4);
    } };
    return e3.then(function() {
      r3.status = `fulfilled`, r3.value = t3;
      for (var e4 = 0; e4 < n2.length; e4++) (0, n2[e4])(t3);
    }, function(e4) {
      for (r3.status = `rejected`, r3.reason = e4, e4 = 0; e4 < n2.length; e4++) (0, n2[e4])(void 0);
    }), r3;
  }
  var $a = w.S;
  w.S = function(e3, t3) {
    if (gd = Qe(), typeof t3 == `object` && t3 && typeof t3.then == `function` && Xa(e3, t3), Wa !== null) for (var n2 = bf; n2 !== null; ) Ua(n2, Wa), n2 = n2.next;
    if (n2 = e3.types, n2 !== null) {
      for (var r3 = bf; r3 !== null; ) Ua(r3, n2), r3 = r3.next;
      if (Ja !== 0) {
        r3 = Wa, r3 === null && (r3 = Wa = []);
        for (var i3 = 0; i3 < n2.length; i3++) {
          var a3 = n2[i3];
          r3.indexOf(a3) === -1 && r3.push(a3);
        }
      }
    }
    $a !== null && $a(e3, t3);
  };
  var eo = Ae(null);
  function to() {
    var e3 = eo.current;
    return e3 === null ? G.pooledCache : e3;
  }
  function no(e3, t3) {
    t3 === null ? E(eo, eo.current) : E(eo, t3.pool);
  }
  function ro() {
    var e3 = to();
    return e3 === null ? null : { parent: j._currentValue, pool: e3 };
  }
  var io = Error(a2(460)), ao = Error(a2(474)), oo = Error(a2(542)), so = { then: function() {
  } };
  function co(e3) {
    return e3 = e3.status, e3 === `fulfilled` || e3 === `rejected`;
  }
  function lo(e3, t3, n2) {
    switch (n2 = e3[n2], n2 === void 0 ? e3.push(t3) : n2 !== t3 && (t3.then(kn, kn), t3 = n2), t3.status) {
      case `fulfilled`:
        return t3.value;
      case `rejected`:
        throw e3 = t3.reason, mo(e3), e3 === void 0 && !(`reason` in t3) ? Error(a2(600)) : e3;
      default:
        if (typeof t3.status == `string`) t3.then(kn, kn);
        else {
          if (e3 = G, e3 !== null && 100 < e3.shellSuspendCounter) throw Error(a2(482));
          e3 = t3, e3.status = `pending`, e3.then(function(e4) {
            if (t3.status === `pending`) {
              var n3 = t3;
              n3.status = `fulfilled`, n3.value = e4;
            }
          }, function(e4) {
            if (t3.status === `pending`) {
              var n3 = t3;
              n3.status = `rejected`, n3.reason = e4;
            }
          });
        }
        switch (t3.status) {
          case `fulfilled`:
            return t3.value;
          case `rejected`:
            throw e3 = t3.reason, mo(e3), e3;
        }
        throw fo = t3, io;
    }
  }
  function uo(e3) {
    try {
      var t3 = e3._init;
      return t3(e3._payload);
    } catch (e4) {
      throw typeof e4 == `object` && e4 && typeof e4.then == `function` ? (fo = e4, io) : e4;
    }
  }
  var fo = null;
  function po() {
    if (fo === null) throw Error(a2(459));
    var e3 = fo;
    return fo = null, e3;
  }
  function mo(e3) {
    if (e3 === io || e3 === oo) throw Error(a2(483));
  }
  var ho = null, go = 0;
  function _o(e3) {
    var t3 = go;
    return go += 1, ho === null && (ho = []), lo(ho, e3, t3);
  }
  function vo(e3, t3) {
    t3 = t3.props.ref, e3.ref = t3 === void 0 ? null : t3;
  }
  function yo(e3, t3) {
    throw t3.$$typeof === ie2 ? Error(a2(525)) : (e3 = Object.prototype.toString.call(t3), Error(a2(31, e3 === `[object Object]` ? `object with keys {` + Object.keys(t3).join(`, `) + `}` : e3)));
  }
  function bo(e3) {
    function t3(t4, n3) {
      if (e3) {
        var r4 = t4.deletions;
        r4 === null ? (t4.deletions = [n3], t4.flags |= 16) : r4.push(n3);
      }
    }
    function n2(n3, r4) {
      if (!e3) return null;
      for (; r4 !== null; ) t3(n3, r4), r4 = r4.sibling;
      return null;
    }
    function r3(e4) {
      for (var t4 = /* @__PURE__ */ new Map(); e4 !== null; ) e4.key === null ? t4.set(e4.index, e4) : t4.set(e4.key, e4), e4 = e4.sibling;
      return t4;
    }
    function i3(e4, t4) {
      return e4 = Gi(e4, t4), e4.index = 0, e4.sibling = null, e4;
    }
    function o3(t4, n3, r4) {
      return t4.index = r4, e3 ? (r4 = t4.alternate, r4 === null ? (t4.flags |= 134217730, n3) : (r4 = r4.index, r4 < n3 ? (t4.flags |= 2, n3) : r4)) : (t4.flags |= 1048576, n3);
    }
    function s3(t4) {
      return e3 && t4.alternate === null && (t4.flags |= 134217730), t4;
    }
    function c3(e4, t4, n3, r4) {
      return t4 === null || t4.tag !== 6 ? (t4 = Yi(n3, e4.mode, r4), t4.return = e4, t4) : (t4 = i3(t4, n3), t4.return = e4, t4);
    }
    function l3(e4, t4, n3, r4) {
      var a3 = n3.type;
      return a3 === le2 ? (e4 = d3(e4, t4, n3.props.children, r4, n3.key), vo(e4, n3), e4) : t4 !== null && (t4.elementType === a3 || typeof a3 == `object` && a3 && a3.$$typeof === _e && uo(a3) === t4.type) ? (t4 = i3(t4, n3.props), vo(t4, n3), t4.return = e4, t4) : (t4 = qi(n3.type, n3.key, n3.props, null, e4.mode, r4), vo(t4, n3), t4.return = e4, t4);
    }
    function u3(e4, t4, n3, r4) {
      return t4 === null || t4.tag !== 4 || t4.stateNode.containerInfo !== n3.containerInfo || t4.stateNode.implementation !== n3.implementation ? (t4 = Zi(n3, e4.mode, r4), t4.return = e4, t4) : (t4 = i3(t4, n3.children || []), t4.return = e4, t4);
    }
    function d3(e4, t4, n3, r4, a3) {
      return t4 === null || t4.tag !== 7 ? (t4 = Ji(n3, e4.mode, r4, a3), t4.return = e4, t4) : (t4 = i3(t4, n3), t4.return = e4, t4);
    }
    function f3(e4, t4, n3) {
      if (typeof t4 == `string` && t4 !== `` || typeof t4 == `number` || typeof t4 == `bigint`) return t4 = Yi(`` + t4, e4.mode, n3), t4.return = e4, t4;
      if (typeof t4 == `object` && t4) {
        switch (t4.$$typeof) {
          case ae2:
            return n3 = qi(t4.type, t4.key, t4.props, null, e4.mode, n3), vo(n3, t4), n3.return = e4, n3;
          case se2:
            return t4 = Zi(t4, e4.mode, n3), t4.return = e4, t4;
          case _e:
            return t4 = uo(t4), f3(e4, t4, n3);
        }
        if (Ee(t4) || Ce(t4)) return t4 = Ji(t4, e4.mode, n3, null), t4.return = e4, t4;
        if (typeof t4.then == `function`) return f3(e4, _o(t4), n3);
        if (t4.$$typeof === S) return f3(e4, Ia(e4, t4), n3);
        yo(e4, t4);
      }
      return null;
    }
    function p3(e4, t4, n3, r4) {
      var i4 = t4 === null ? null : t4.key;
      if (typeof n3 == `string` && n3 !== `` || typeof n3 == `number` || typeof n3 == `bigint`) return i4 === null ? c3(e4, t4, `` + n3, r4) : null;
      if (typeof n3 == `object` && n3) {
        switch (n3.$$typeof) {
          case ae2:
            return n3.key === i4 ? l3(e4, t4, n3, r4) : null;
          case se2:
            return n3.key === i4 ? u3(e4, t4, n3, r4) : null;
          case _e:
            return n3 = uo(n3), p3(e4, t4, n3, r4);
        }
        if (Ee(n3) || Ce(n3)) return i4 === null ? d3(e4, t4, n3, r4, null) : null;
        if (typeof n3.then == `function`) return p3(e4, t4, _o(n3), r4);
        if (n3.$$typeof === S) return p3(e4, t4, Ia(e4, n3), r4);
        yo(e4, n3);
      }
      return null;
    }
    function m3(e4, t4, n3, r4, i4) {
      if (typeof r4 == `string` && r4 !== `` || typeof r4 == `number` || typeof r4 == `bigint`) return e4 = e4.get(n3) || null, c3(t4, e4, `` + r4, i4);
      if (typeof r4 == `object` && r4) {
        switch (r4.$$typeof) {
          case ae2:
            return e4 = e4.get(r4.key === null ? n3 : r4.key) || null, l3(t4, e4, r4, i4);
          case se2:
            return e4 = e4.get(r4.key === null ? n3 : r4.key) || null, u3(t4, e4, r4, i4);
          case _e:
            return r4 = uo(r4), m3(e4, t4, n3, r4, i4);
        }
        if (Ee(r4) || Ce(r4)) return e4 = e4.get(n3) || null, d3(t4, e4, r4, i4, null);
        if (typeof r4.then == `function`) return m3(e4, t4, n3, _o(r4), i4);
        if (r4.$$typeof === S) return m3(e4, t4, n3, Ia(t4, r4), i4);
        yo(t4, r4);
      }
      return null;
    }
    function h3(i4, a3, s4, c4) {
      for (var l4 = null, u4 = null, d4 = a3, h4 = a3 = 0, g4 = null; d4 !== null && h4 < s4.length; h4++) {
        d4.index > h4 ? (g4 = d4, d4 = null) : g4 = d4.sibling;
        var _4 = p3(i4, d4, s4[h4], c4);
        if (_4 === null) {
          d4 === null && (d4 = g4);
          break;
        }
        e3 && d4 && _4.alternate === null && t3(i4, d4), a3 = o3(_4, a3, h4), u4 === null ? l4 = _4 : u4.sibling = _4, u4 = _4, d4 = g4;
      }
      if (h4 === s4.length) return n2(i4, d4), A && la(i4, h4), l4;
      if (d4 === null) {
        for (; h4 < s4.length; h4++) d4 = f3(i4, s4[h4], c4), d4 !== null && (a3 = o3(d4, a3, h4), u4 === null ? l4 = d4 : u4.sibling = d4, u4 = d4);
        return A && la(i4, h4), l4;
      }
      for (d4 = r3(d4); h4 < s4.length; h4++) g4 = m3(d4, i4, h4, s4[h4], c4), g4 !== null && (e3 && (_4 = g4.alternate, _4 !== null && d4.delete(_4.key === null ? h4 : _4.key)), a3 = o3(g4, a3, h4), u4 === null ? l4 = g4 : u4.sibling = g4, u4 = g4);
      return e3 && d4.forEach(function(e4) {
        return t3(i4, e4);
      }), A && la(i4, h4), l4;
    }
    function g3(i4, s4, c4, l4) {
      if (c4 == null) throw Error(a2(151));
      for (var u4 = null, d4 = null, h4 = s4, g4 = s4 = 0, _4 = null, v3 = c4.next(); h4 !== null && !v3.done; g4++, v3 = c4.next()) {
        h4.index > g4 ? (_4 = h4, h4 = null) : _4 = h4.sibling;
        var y3 = p3(i4, h4, v3.value, l4);
        if (y3 === null) {
          h4 === null && (h4 = _4);
          break;
        }
        e3 && h4 && y3.alternate === null && t3(i4, h4), s4 = o3(y3, s4, g4), d4 === null ? u4 = y3 : d4.sibling = y3, d4 = y3, h4 = _4;
      }
      if (v3.done) return n2(i4, h4), A && la(i4, g4), u4;
      if (h4 === null) {
        for (; !v3.done; g4++, v3 = c4.next()) v3 = f3(i4, v3.value, l4), v3 !== null && (s4 = o3(v3, s4, g4), d4 === null ? u4 = v3 : d4.sibling = v3, d4 = v3);
        return A && la(i4, g4), u4;
      }
      for (h4 = r3(h4); !v3.done; g4++, v3 = c4.next()) v3 = m3(h4, i4, g4, v3.value, l4), v3 !== null && (e3 && (_4 = v3.alternate, _4 !== null && h4.delete(_4.key === null ? g4 : _4.key)), s4 = o3(v3, s4, g4), d4 === null ? u4 = v3 : d4.sibling = v3, d4 = v3);
      return e3 && h4.forEach(function(e4) {
        return t3(i4, e4);
      }), A && la(i4, g4), u4;
    }
    function _3(e4, r4, o4, c4) {
      if (typeof o4 == `object` && o4 && o4.type === le2 && o4.key === null && o4.props.ref === void 0 && (o4 = o4.props.children), typeof o4 == `object` && o4) {
        switch (o4.$$typeof) {
          case ae2:
            a: {
              for (var l4 = o4.key; r4 !== null; ) {
                if (r4.key === l4) {
                  if (l4 = o4.type, l4 === le2) {
                    if (r4.tag === 7) {
                      n2(e4, r4.sibling), c4 = i3(r4, o4.props.children), vo(c4, o4), c4.return = e4, e4 = c4;
                      break a;
                    }
                  } else if (r4.elementType === l4 || typeof l4 == `object` && l4 && l4.$$typeof === _e && uo(l4) === r4.type) {
                    n2(e4, r4.sibling), c4 = i3(r4, o4.props), vo(c4, o4), c4.return = e4, e4 = c4;
                    break a;
                  }
                  n2(e4, r4);
                  break;
                }
                t3(e4, r4), r4 = r4.sibling;
              }
              o4.type === le2 ? (c4 = Ji(o4.props.children, e4.mode, c4, o4.key), vo(c4, o4), c4.return = e4, e4 = c4) : (c4 = qi(o4.type, o4.key, o4.props, null, e4.mode, c4), vo(c4, o4), c4.return = e4, e4 = c4);
            }
            return s3(e4);
          case se2:
            a: {
              for (l4 = o4.key; r4 !== null; ) {
                if (r4.key === l4) {
                  if (r4.tag === 4 && r4.stateNode.containerInfo === o4.containerInfo && r4.stateNode.implementation === o4.implementation) {
                    n2(e4, r4.sibling), c4 = i3(r4, o4.children || []), c4.return = e4, e4 = c4;
                    break a;
                  }
                  n2(e4, r4);
                  break;
                }
                t3(e4, r4), r4 = r4.sibling;
              }
              c4 = Zi(o4, e4.mode, c4), c4.return = e4, e4 = c4;
            }
            return s3(e4);
          case _e:
            return o4 = uo(o4), _3(e4, r4, o4, c4);
        }
        if (Ee(o4)) return h3(e4, r4, o4, c4);
        if (Ce(o4)) {
          if (l4 = Ce(o4), typeof l4 != `function`) throw Error(a2(150));
          return o4 = l4.call(o4), g3(e4, r4, o4, c4);
        }
        if (typeof o4.then == `function`) return _3(e4, r4, _o(o4), c4);
        if (o4.$$typeof === S) return _3(e4, r4, Ia(e4, o4), c4);
        yo(e4, o4);
      }
      return typeof o4 == `string` && o4 !== `` || typeof o4 == `number` || typeof o4 == `bigint` ? (o4 = `` + o4, r4 !== null && r4.tag === 6 ? (n2(e4, r4.sibling), c4 = i3(r4, o4), c4.return = e4, e4 = c4) : (n2(e4, r4), c4 = Yi(o4, e4.mode, c4), c4.return = e4, e4 = c4), s3(e4)) : n2(e4, r4);
    }
    return function(e4, t4, n3, r4) {
      try {
        go = 0;
        var i4 = _3(e4, t4, n3, r4);
        return ho = null, i4;
      } catch (t5) {
        if (t5 === io || t5 === oo) throw t5;
        var a3 = Ui(29, t5, null, e4.mode);
        return a3.lanes = r4, a3.return = e4, a3;
      }
    };
  }
  var xo = bo(true), So = bo(false), Co = false;
  function wo(e3) {
    e3.updateQueue = { baseState: e3.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, lanes: 0, hiddenCallbacks: null }, callbacks: null };
  }
  function To(e3, t3) {
    e3 = e3.updateQueue, t3.updateQueue === e3 && (t3.updateQueue = { baseState: e3.baseState, firstBaseUpdate: e3.firstBaseUpdate, lastBaseUpdate: e3.lastBaseUpdate, shared: e3.shared, callbacks: null });
  }
  function Eo(e3) {
    return { lane: e3, tag: 0, payload: null, callback: null, next: null };
  }
  function Do(e3, t3, n2) {
    var r3 = e3.updateQueue;
    if (r3 === null) return null;
    if (r3 = r3.shared, W & 2) {
      var i3 = r3.pending;
      return i3 === null ? t3.next = t3 : (t3.next = i3.next, i3.next = t3), r3.pending = t3, t3 = Bi(e3), zi(e3, null, n2), t3;
    }
    return Ii(e3, r3, t3, n2), Bi(e3);
  }
  function Oo(e3, t3, n2) {
    if (t3 = t3.updateQueue, t3 !== null && (t3 = t3.shared, n2 & 4194048)) {
      var r3 = t3.lanes;
      r3 &= e3.pendingLanes, n2 |= r3, t3.lanes = n2, Dt(e3, n2);
    }
  }
  function ko(e3, t3) {
    var n2 = e3.updateQueue, r3 = e3.alternate;
    if (r3 !== null && (r3 = r3.updateQueue, n2 === r3)) {
      var i3 = null, a3 = null;
      if (n2 = n2.firstBaseUpdate, n2 !== null) {
        do {
          var o3 = { lane: n2.lane, tag: n2.tag, payload: n2.payload, callback: null, next: null };
          a3 === null ? i3 = a3 = o3 : a3 = a3.next = o3, n2 = n2.next;
        } while (n2 !== null);
        a3 === null ? i3 = a3 = t3 : a3 = a3.next = t3;
      } else i3 = a3 = t3;
      n2 = { baseState: r3.baseState, firstBaseUpdate: i3, lastBaseUpdate: a3, shared: r3.shared, callbacks: r3.callbacks }, e3.updateQueue = n2;
      return;
    }
    e3 = n2.lastBaseUpdate, e3 === null ? n2.firstBaseUpdate = t3 : e3.next = t3, n2.lastBaseUpdate = t3;
  }
  var Ao = false;
  function jo() {
    if (Ao) {
      var e3 = Ya;
      if (e3 !== null) throw e3;
    }
  }
  function Mo(e3, t3, n2, r3) {
    Ao = false;
    var i3 = e3.updateQueue;
    Co = false;
    var a3 = i3.firstBaseUpdate, o3 = i3.lastBaseUpdate, s3 = i3.shared.pending;
    if (s3 !== null) {
      i3.shared.pending = null;
      var c3 = s3, l3 = c3.next;
      c3.next = null, o3 === null ? a3 = l3 : o3.next = l3, o3 = c3;
      var u3 = e3.alternate;
      u3 !== null && (u3 = u3.updateQueue, s3 = u3.lastBaseUpdate, s3 !== o3 && (s3 === null ? u3.firstBaseUpdate = l3 : s3.next = l3, u3.lastBaseUpdate = c3));
    }
    if (a3 !== null) {
      var d3 = i3.baseState;
      o3 = 0, u3 = l3 = c3 = null, s3 = a3;
      do {
        var f3 = s3.lane & -536870913, p3 = f3 !== s3.lane;
        if (p3 ? (q & f3) === f3 : (r3 & f3) === f3) {
          f3 !== 0 && f3 === Ja && (Ao = true), u3 !== null && (u3 = u3.next = { lane: 0, tag: s3.tag, payload: s3.payload, callback: null, next: null });
          a: {
            var m3 = e3, h3 = s3;
            f3 = t3;
            var g3 = n2;
            switch (h3.tag) {
              case 1:
                if (m3 = h3.payload, typeof m3 == `function`) {
                  d3 = m3.call(g3, d3, f3);
                  break a;
                }
                d3 = m3;
                break a;
              case 3:
                m3.flags = m3.flags & -65537 | 128;
              case 0:
                if (m3 = h3.payload, f3 = typeof m3 == `function` ? m3.call(g3, d3, f3) : m3, f3 == null) break a;
                d3 = x2({}, d3, f3);
                break a;
              case 2:
                Co = true;
            }
          }
          f3 = s3.callback, f3 !== null && (e3.flags |= 64, p3 && (e3.flags |= 8192), p3 = i3.callbacks, p3 === null ? i3.callbacks = [f3] : p3.push(f3));
        } else p3 = { lane: f3, tag: s3.tag, payload: s3.payload, callback: s3.callback, next: null }, u3 === null ? (l3 = u3 = p3, c3 = d3) : u3 = u3.next = p3, o3 |= f3;
        if (s3 = s3.next, s3 === null) {
          if (s3 = i3.shared.pending, s3 === null) break;
          p3 = s3, s3 = p3.next, p3.next = null, i3.lastBaseUpdate = p3, i3.shared.pending = null;
        }
      } while (1);
      u3 === null && (c3 = d3), i3.baseState = c3, i3.firstBaseUpdate = l3, i3.lastBaseUpdate = u3, a3 === null && (i3.shared.lanes = 0), sd |= o3, e3.lanes = o3, e3.memoizedState = d3;
    }
  }
  function No(e3, t3) {
    if (typeof e3 != `function`) throw Error(a2(191, e3));
    e3.call(t3);
  }
  function Po(e3, t3) {
    var n2 = e3.callbacks;
    if (n2 !== null) for (e3.callbacks = null, e3 = 0; e3 < n2.length; e3++) No(n2[e3], t3);
  }
  var Fo = Ae(null), Io = Ae(0);
  function Lo(e3, t3) {
    e3 = od, E(Io, e3), E(Fo, t3), od = e3 | t3.baseLanes;
  }
  function Ro() {
    E(Io, od), E(Fo, Fo.current);
  }
  function zo() {
    od = Io.current, je(Fo), je(Io);
  }
  var Bo = Ae(null), Vo = null;
  function Ho(e3) {
    var t3 = e3.alternate;
    E(qo, qo.current & 1), E(Bo, e3), Vo === null && (t3 === null || Fo.current !== null || t3.memoizedState !== null) && (Vo = e3);
  }
  function Uo(e3) {
    E(qo, qo.current), E(Bo, e3), Vo === null && (Vo = e3);
  }
  function Wo(e3) {
    e3.tag === 22 ? (E(qo, qo.current), E(Bo, e3), Vo === null && (Vo = e3)) : Go();
  }
  function Go() {
    E(qo, qo.current), E(Bo, Bo.current);
  }
  function Ko(e3) {
    je(Bo), Vo === e3 && (Vo = null), je(qo);
  }
  var qo = Ae(0);
  function Jo(e3, t3) {
    E(Bo, Bo.current), E(qo, t3);
  }
  function Yo(e3) {
    je(qo), je(Bo), Vo === e3 && (Vo = null);
  }
  function Xo(e3) {
    for (var t3 = e3; t3 !== null; ) {
      if (t3.tag === 13) {
        var n2 = t3.memoizedState;
        if (n2 !== null && (n2 = n2.dehydrated, n2 === null || om(n2) || sm(n2))) return t3;
      } else if (t3.tag === 19 && t3.memoizedProps.revealOrder !== `independent`) {
        if (t3.flags & 128) return t3;
      } else if (t3.child !== null) {
        t3.child.return = t3, t3 = t3.child;
        continue;
      }
      if (t3 === e3) break;
      for (; t3.sibling === null; ) {
        if (t3.return === null || t3.return === e3) return null;
        t3 = t3.return;
      }
      t3.sibling.return = t3.return, t3 = t3.sibling;
    }
    return null;
  }
  var Zo = 0, M = null, N = null, P = null, Qo = false, $o = false, es = false, ts = 0, ns = 0, rs = null, is = 0;
  function F() {
    throw Error(a2(321));
  }
  function as(e3, t3) {
    if (t3 === null) return false;
    for (var n2 = 0; n2 < t3.length && n2 < e3.length; n2++) if (!Qr(e3[n2], t3[n2])) return false;
    return true;
  }
  function os(e3, t3, n2, r3, i3, a3) {
    return Zo = a3, M = t3, t3.memoizedState = null, t3.updateQueue = null, t3.lanes = 0, w.H = e3 === null || e3.memoizedState === null ? Sc : Cc, es = false, a3 = n2(r3, i3), es = false, $o && (a3 = cs(t3, n2, r3, i3)), ss(e3), a3;
  }
  function ss(e3) {
    w.H = xc;
    var t3 = N !== null && N.next !== null;
    if (Zo = 0, P = N = M = null, Qo = false, ns = 0, rs = null, t3) throw Error(a2(300));
    e3 === null || L || (e3 = e3.dependencies, e3 !== null && Na(e3) && (L = true));
  }
  function cs(e3, t3, n2, r3) {
    M = e3;
    var i3 = 0;
    do {
      if ($o && (rs = null), ns = 0, $o = false, 25 <= i3) throw Error(a2(301));
      if (i3 += 1, P = N = null, e3.updateQueue != null) {
        var o3 = e3.updateQueue;
        o3.lastEffect = null, o3.events = null, o3.stores = null, o3.memoCache != null && (o3.memoCache.index = 0);
      }
      w.H = wc, o3 = t3(n2, r3);
    } while ($o);
    return o3;
  }
  function ls() {
    var e3 = w.H, t3 = e3.useState()[0];
    return t3 = typeof t3.then == `function` ? hs(t3) : t3, e3 = e3.useState()[0], (N === null ? null : N.memoizedState) !== e3 && (M.flags |= 1024), t3;
  }
  function us() {
    var e3 = ts !== 0;
    return ts = 0, e3;
  }
  function ds(e3, t3, n2) {
    t3.updateQueue = e3.updateQueue, t3.flags &= -2053, e3.lanes &= ~n2;
  }
  function fs(e3) {
    if (Qo) {
      for (e3 = e3.memoizedState; e3 !== null; ) {
        var t3 = e3.queue;
        t3 !== null && (t3.pending = null), e3 = e3.next;
      }
      Qo = false;
    }
    Zo = 0, P = N = M = null, $o = false, ns = ts = 0, rs = null;
  }
  function ps() {
    var e3 = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
    return P === null ? M.memoizedState = P = e3 : P = P.next = e3, P;
  }
  function I() {
    if (N === null) {
      var e3 = M.alternate;
      e3 = e3 === null ? null : e3.memoizedState;
    } else e3 = N.next;
    var t3 = P === null ? M.memoizedState : P.next;
    if (t3 !== null) P = t3, N = e3;
    else {
      if (e3 === null) throw M.alternate === null ? Error(a2(467)) : Error(a2(310));
      N = e3, e3 = { memoizedState: N.memoizedState, baseState: N.baseState, baseQueue: N.baseQueue, queue: N.queue, next: null }, P === null ? M.memoizedState = P = e3 : P = P.next = e3;
    }
    return P;
  }
  function ms() {
    return { lastEffect: null, events: null, stores: null, memoCache: null };
  }
  function hs(e3) {
    var t3 = ns;
    return ns += 1, rs === null && (rs = []), e3 = lo(rs, e3, t3), t3 = M, (P === null ? t3.memoizedState : P.next) === null && (t3 = t3.alternate, w.H = t3 === null || t3.memoizedState === null ? Sc : Cc), e3;
  }
  function gs(e3) {
    if (typeof e3 == `object` && e3) {
      if (typeof e3.then == `function`) return hs(e3);
      if (e3.$$typeof === xe) return;
      if (e3.$$typeof === S) return Fa(e3);
    }
    throw Error(a2(438, String(e3)));
  }
  function _s(e3) {
    var t3 = null, n2 = M.updateQueue;
    if (n2 !== null && (t3 = n2.memoCache), t3 == null) {
      var r3 = M.alternate;
      r3 !== null && (r3 = r3.updateQueue, r3 !== null && (r3 = r3.memoCache, r3 != null && (t3 = { data: r3.data.map(function(e4) {
        return e4.slice();
      }), index: 0 })));
    }
    if (t3 ??= { data: [], index: 0 }, n2 === null && (n2 = ms(), M.updateQueue = n2), n2.memoCache = t3, n2 = t3.data[t3.index], n2 === void 0) for (n2 = t3.data[t3.index] = Array(e3), r3 = 0; r3 < e3; r3++) n2[r3] = ye;
    return t3.index++, n2;
  }
  function vs(e3, t3) {
    return typeof t3 == `function` ? t3(e3) : t3;
  }
  function ys(e3) {
    return bs(I(), N, e3);
  }
  function bs(e3, t3, n2) {
    var r3 = e3.queue;
    if (r3 === null) throw Error(a2(311));
    r3.lastRenderedReducer = n2;
    var i3 = e3.baseQueue, o3 = r3.pending;
    if (o3 !== null) {
      if (i3 !== null) {
        var s3 = i3.next;
        i3.next = o3.next, o3.next = s3;
      }
      t3.baseQueue = i3 = o3, r3.pending = null;
    }
    if (o3 = e3.baseState, i3 === null) e3.memoizedState = o3;
    else {
      t3 = i3.next;
      var c3 = s3 = null, l3 = null, u3 = t3, d3 = false;
      do {
        var f3 = u3.lane & -536870913;
        if (f3 === u3.lane ? (Zo & f3) === f3 : (q & f3) === f3) {
          var p3 = u3.revertLane;
          if (p3 === 0) l3 !== null && (l3 = l3.next = { lane: 0, revertLane: 0, gesture: null, action: u3.action, hasEagerState: u3.hasEagerState, eagerState: u3.eagerState, next: null }), f3 === Ja && (d3 = true);
          else if ((Zo & p3) === p3) {
            u3 = u3.next, p3 === Ja && (d3 = true);
            continue;
          } else f3 = { lane: 0, revertLane: u3.revertLane, gesture: null, action: u3.action, hasEagerState: u3.hasEagerState, eagerState: u3.eagerState, next: null }, l3 === null ? (c3 = l3 = f3, s3 = o3) : l3 = l3.next = f3, M.lanes |= p3, sd |= p3;
          f3 = u3.action, es && n2(o3, f3), o3 = u3.hasEagerState ? u3.eagerState : n2(o3, f3);
        } else p3 = { lane: f3, revertLane: u3.revertLane, gesture: u3.gesture, action: u3.action, hasEagerState: u3.hasEagerState, eagerState: u3.eagerState, next: null }, l3 === null ? (c3 = l3 = p3, s3 = o3) : l3 = l3.next = p3, M.lanes |= f3, sd |= f3;
        u3 = u3.next;
      } while (u3 !== null && u3 !== t3);
      if (l3 === null ? s3 = o3 : l3.next = c3, !Qr(o3, e3.memoizedState) && (L = true, d3 && (n2 = Ya, n2 !== null))) throw n2;
      e3.memoizedState = o3, e3.baseState = s3, e3.baseQueue = l3, r3.lastRenderedState = o3;
    }
    return i3 === null && (r3.lanes = 0), [e3.memoizedState, r3.dispatch];
  }
  function xs(e3) {
    var t3 = I(), n2 = t3.queue;
    if (n2 === null) throw Error(a2(311));
    n2.lastRenderedReducer = e3;
    var r3 = n2.dispatch, i3 = n2.pending, o3 = t3.memoizedState;
    if (i3 !== null) {
      n2.pending = null;
      var s3 = i3 = i3.next;
      do
        o3 = e3(o3, s3.action), s3 = s3.next;
      while (s3 !== i3);
      Qr(o3, t3.memoizedState) || (L = true), t3.memoizedState = o3, t3.baseQueue === null && (t3.baseState = o3), n2.lastRenderedState = o3;
    }
    return [o3, r3];
  }
  function Ss(e3, t3, n2) {
    var r3 = M, i3 = I(), o3 = A;
    if (o3) {
      if (n2 === void 0) throw Error(a2(407));
      n2 = n2();
    } else n2 = t3();
    var s3 = !Qr((N || i3).memoizedState, n2);
    if (s3 && (i3.memoizedState = n2, L = true), i3 = i3.queue, qs(Ts.bind(null, r3, i3, e3), [e3]), e3 = i3.getSnapshot !== t3 || s3 || P !== null && !!(P.memoizedState.tag & 1), Hs(e3 ? 9 : 8, { destroy: void 0 }, ws.bind(null, r3, i3, n2, t3), null), e3) {
      if (r3.flags |= 2048, G === null) throw Error(a2(349));
      o3 || Zo & 127 || Cs(r3, t3, n2);
    }
    return n2;
  }
  function Cs(e3, t3, n2) {
    e3.flags |= 16384, e3 = { getSnapshot: t3, value: n2 }, t3 = M.updateQueue, t3 === null ? (t3 = ms(), M.updateQueue = t3, t3.stores = [e3]) : (n2 = t3.stores, n2 === null ? t3.stores = [e3] : n2.push(e3));
  }
  function ws(e3, t3, n2, r3) {
    t3.value = n2, t3.getSnapshot = r3, Es(t3) && Ds(e3);
  }
  function Ts(e3, t3, n2) {
    return n2(function() {
      Es(t3) && Ds(e3);
    });
  }
  function Es(e3) {
    var t3 = e3.getSnapshot;
    e3 = e3.value;
    try {
      var n2 = t3();
      return !Qr(e3, n2);
    } catch {
      return true;
    }
  }
  function Ds(e3) {
    var t3 = Ri(e3, 2);
    t3 !== null && Pd(t3, e3, 2);
  }
  function Os(e3) {
    var t3 = ps();
    if (typeof e3 == `function`) {
      var n2 = e3;
      if (e3 = n2(), es) {
        lt(true);
        try {
          n2();
        } finally {
          lt(false);
        }
      }
    }
    return t3.memoizedState = t3.baseState = e3, t3.queue = { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: vs, lastRenderedState: e3 }, t3;
  }
  function ks(e3, t3, n2, r3) {
    return e3.baseState = n2, bs(e3, N, typeof r3 == `function` ? r3 : vs);
  }
  function As(e3, t3, n2, r3, i3) {
    if (vc(e3)) throw Error(a2(485));
    if (e3 = t3.action, e3 !== null) {
      var o3 = { payload: i3, action: e3, next: null, isTransition: true, status: `pending`, value: null, reason: null, listeners: [], then: function(e4) {
        o3.listeners.push(e4);
      } };
      w.T === null ? o3.isTransition = false : n2(true), r3(o3), n2 = t3.pending, n2 === null ? (o3.next = t3.pending = o3, js(t3, o3)) : (o3.next = n2.next, t3.pending = n2.next = o3);
    }
  }
  function js(e3, t3) {
    var n2 = t3.action, r3 = t3.payload, i3 = e3.state;
    if (t3.isTransition) {
      var a3 = w.T, o3 = {};
      o3.types = a3 === null ? null : a3.types, w.T = o3;
      try {
        var s3 = n2(i3, r3), c3 = w.S;
        c3 !== null && c3(o3, s3), Ms(e3, t3, s3);
      } catch (n3) {
        Ps(e3, t3, n3);
      } finally {
        a3 !== null && o3.types !== null && (a3.types = o3.types), w.T = a3;
      }
    } else try {
      a3 = n2(i3, r3), Ms(e3, t3, a3);
    } catch (n3) {
      Ps(e3, t3, n3);
    }
  }
  function Ms(e3, t3, n2) {
    typeof n2 == `object` && n2 && typeof n2.then == `function` ? n2.then(function(n3) {
      Ns(e3, t3, n3);
    }, function(n3) {
      return Ps(e3, t3, n3);
    }) : Ns(e3, t3, n2);
  }
  function Ns(e3, t3, n2) {
    t3.status = `fulfilled`, t3.value = n2, Fs(t3), e3.state = n2, t3 = e3.pending, t3 !== null && (n2 = t3.next, n2 === t3 ? e3.pending = null : (n2 = n2.next, t3.next = n2, js(e3, n2)));
  }
  function Ps(e3, t3, n2) {
    var r3 = e3.pending;
    if (e3.pending = null, r3 !== null) {
      r3 = r3.next;
      do
        t3.status = `rejected`, t3.reason = n2, Fs(t3), t3 = t3.next;
      while (t3 !== r3);
    }
    e3.action = null;
  }
  function Fs(e3) {
    e3 = e3.listeners;
    for (var t3 = 0; t3 < e3.length; t3++) (0, e3[t3])();
  }
  function Is(e3, t3) {
    return t3;
  }
  function Ls(e3, t3) {
    if (A) {
      var n2 = G.formState;
      if (n2 !== null) {
        a: {
          var r3 = M;
          if (A) {
            if (k) {
              b: {
                for (var i3 = k, a3 = ga; i3.nodeType !== 8; ) {
                  if (!a3) {
                    i3 = null;
                    break b;
                  }
                  if (i3 = lm(i3.nextSibling), i3 === null) {
                    i3 = null;
                    break b;
                  }
                }
                a3 = i3.data, i3 = a3 === `F!` || a3 === `F` ? i3 : null;
              }
              if (i3) {
                k = lm(i3.nextSibling), r3 = i3.data === `F!`;
                break a;
              }
            }
            va(r3);
          }
          r3 = false;
        }
        r3 && (t3 = n2[0]);
      }
    }
    return n2 = ps(), n2.memoizedState = n2.baseState = t3, r3 = { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: Is, lastRenderedState: t3 }, n2.queue = r3, n2 = hc.bind(null, M, r3), r3.dispatch = n2, r3 = Os(false), a3 = _c.bind(null, M, false, r3.queue), r3 = ps(), i3 = { state: t3, dispatch: null, action: e3, pending: null }, r3.queue = i3, n2 = As.bind(null, M, i3, a3, n2), i3.dispatch = n2, r3.memoizedState = e3, [t3, n2, false];
  }
  function Rs(e3) {
    return zs(I(), N, e3);
  }
  function zs(e3, t3, n2) {
    if (t3 = bs(e3, t3, Is)[0], e3 = ys(vs)[0], typeof t3 == `object` && t3 && typeof t3.then == `function`) try {
      var r3 = hs(t3);
    } catch (e4) {
      throw e4 === io ? oo : e4;
    }
    else r3 = t3;
    t3 = I();
    var i3 = t3.queue, a3 = i3.dispatch;
    return n2 !== t3.memoizedState && (M.flags |= 2048, Hs(9, { destroy: void 0 }, Bs.bind(null, i3, n2), null)), [r3, a3, e3];
  }
  function Bs(e3, t3) {
    e3.action = t3;
  }
  function Vs(e3) {
    var t3 = I(), n2 = N;
    if (n2 !== null) return zs(t3, n2, e3);
    I(), t3 = t3.memoizedState, n2 = I();
    var r3 = n2.queue.dispatch;
    return n2.memoizedState = e3, [t3, r3, false];
  }
  function Hs(e3, t3, n2, r3) {
    return e3 = { tag: e3, create: n2, deps: r3, inst: t3, next: null }, t3 = M.updateQueue, t3 === null && (t3 = ms(), M.updateQueue = t3), n2 = t3.lastEffect, n2 === null ? t3.lastEffect = e3.next = e3 : (r3 = n2.next, n2.next = e3, e3.next = r3, t3.lastEffect = e3), e3;
  }
  function Us() {
    return I().memoizedState;
  }
  function Ws(e3, t3, n2, r3) {
    var i3 = ps();
    M.flags |= e3, i3.memoizedState = Hs(1 | t3, { destroy: void 0 }, n2, r3 === void 0 ? null : r3);
  }
  function Gs(e3, t3, n2, r3) {
    var i3 = I();
    r3 = r3 === void 0 ? null : r3;
    var a3 = i3.memoizedState.inst;
    N !== null && r3 !== null && as(r3, N.memoizedState.deps) ? i3.memoizedState = Hs(t3, a3, n2, r3) : (M.flags |= e3, i3.memoizedState = Hs(1 | t3, a3, n2, r3));
  }
  function Ks(e3, t3) {
    Ws(8390656, 8, e3, t3);
  }
  function qs(e3, t3) {
    Gs(2048, 8, e3, t3);
  }
  function Js(e3) {
    M.flags |= 4;
    var t3 = M.updateQueue;
    if (t3 === null) t3 = ms(), M.updateQueue = t3, t3.events = [e3];
    else {
      var n2 = t3.events;
      n2 === null ? t3.events = [e3] : n2.push(e3);
    }
  }
  function Ys(e3) {
    var t3 = I().memoizedState;
    return Js({ ref: t3, nextImpl: e3 }), function() {
      if (W & 2) throw Error(a2(440));
      return t3.impl.apply(void 0, arguments);
    };
  }
  function Xs(e3, t3) {
    return Gs(4, 2, e3, t3);
  }
  function Zs(e3, t3) {
    return Gs(4, 4, e3, t3);
  }
  function Qs(e3, t3) {
    if (typeof t3 == `function`) {
      e3 = e3();
      var n2 = t3(e3);
      return function() {
        typeof n2 == `function` ? n2() : t3(null);
      };
    }
    if (t3 != null) return e3 = e3(), t3.current = e3, function() {
      t3.current = null;
    };
  }
  function $s(e3, t3, n2) {
    n2 = n2 == null ? null : n2.concat([e3]), Gs(4, 4, Qs.bind(null, t3, e3), n2);
  }
  function ec() {
  }
  function tc(e3, t3) {
    var n2 = I();
    t3 = t3 === void 0 ? null : t3;
    var r3 = n2.memoizedState;
    return t3 !== null && as(t3, r3[1]) ? r3[0] : (n2.memoizedState = [e3, t3], e3);
  }
  function nc(e3, t3) {
    var n2 = I();
    t3 = t3 === void 0 ? null : t3;
    var r3 = n2.memoizedState;
    if (t3 !== null && as(t3, r3[1])) return r3[0];
    if (r3 = e3(), es) {
      lt(true);
      try {
        e3();
      } finally {
        lt(false);
      }
    }
    return n2.memoizedState = [r3, t3], r3;
  }
  function rc(e3, t3, n2) {
    return n2 === void 0 || Zo & 1073741824 && !(q & 261930) ? e3.memoizedState = t3 : (e3.memoizedState = n2, e3 = Md(), M.lanes |= e3, sd |= e3, n2);
  }
  function ic(e3, t3, n2, r3) {
    return Qr(n2, t3) ? n2 : Fo.current === null ? !(Zo & 106) || Zo & 1073741824 && !(q & 261930) ? (L = true, e3.memoizedState = n2) : (e3 = Md(), M.lanes |= e3, sd |= e3, t3) : (e3 = rc(e3, n2, r3), Qr(e3, t3) || (L = true), e3);
  }
  function ac(e3, t3, n2, r3, i3) {
    var a3 = T.p;
    T.p = a3 !== 0 && 8 > a3 ? a3 : 8;
    var o3 = w.T, s3 = {};
    s3.types = o3 === null ? null : o3.types, w.T = s3, _c(e3, false, t3, n2);
    try {
      var c3 = i3(), l3 = w.S;
      l3 !== null && l3(s3, c3), typeof c3 == `object` && c3 && typeof c3.then == `function` ? gc(e3, t3, Qa(c3, r3), jd(e3)) : gc(e3, t3, r3, jd(e3));
    } catch (n3) {
      gc(e3, t3, { then: function() {
      }, status: `rejected`, reason: n3 }, jd());
    } finally {
      T.p = a3, o3 !== null && s3.types !== null && (o3.types = s3.types), w.T = o3;
    }
  }
  function oc() {
  }
  function sc(e3, t3, n2, r3) {
    if (e3.tag !== 5) throw Error(a2(476));
    var i3 = cc(e3).queue;
    ac(e3, i3, t3, De, n2 === null ? oc : function() {
      return lc(e3), n2(r3);
    });
  }
  function cc(e3) {
    var t3 = e3.memoizedState;
    if (t3 !== null) return t3;
    t3 = { memoizedState: De, baseState: De, baseQueue: null, queue: { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: vs, lastRenderedState: De }, next: null };
    var n2 = {};
    return t3.next = { memoizedState: n2, baseState: n2, baseQueue: null, queue: { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: vs, lastRenderedState: n2 }, next: null }, e3.memoizedState = t3, e3 = e3.alternate, e3 !== null && (e3.memoizedState = t3), t3;
  }
  function lc(e3) {
    var t3 = cc(e3);
    t3.next === null && (t3 = e3.alternate.memoizedState), gc(e3, t3.next.queue, {}, jd());
  }
  function uc() {
    return Fa(sh);
  }
  function dc() {
    return I().memoizedState;
  }
  function fc() {
    return I().memoizedState;
  }
  function pc(e3) {
    for (var t3 = e3.return; t3 !== null; ) {
      switch (t3.tag) {
        case 24:
        case 3:
          var n2 = jd();
          e3 = Eo(n2);
          var r3 = Do(t3, e3, n2);
          r3 !== null && (Pd(r3, t3, n2), Oo(r3, t3, n2)), t3 = { cache: Va() }, e3.payload = t3;
          return;
      }
      t3 = t3.return;
    }
  }
  function mc(e3, t3, n2) {
    var r3 = jd();
    n2 = { lane: r3, revertLane: 0, gesture: null, action: n2, hasEagerState: false, eagerState: null, next: null }, vc(e3) ? yc(t3, n2) : (n2 = Li(e3, t3, n2, r3), n2 !== null && (Pd(n2, e3, r3), bc(n2, t3, r3)));
  }
  function hc(e3, t3, n2) {
    gc(e3, t3, n2, jd());
  }
  function gc(e3, t3, n2, r3) {
    var i3 = { lane: r3, revertLane: 0, gesture: null, action: n2, hasEagerState: false, eagerState: null, next: null };
    if (vc(e3)) yc(t3, i3);
    else {
      var a3 = e3.alternate;
      if (e3.lanes === 0 && (a3 === null || a3.lanes === 0) && (a3 = t3.lastRenderedReducer, a3 !== null)) try {
        var o3 = t3.lastRenderedState, s3 = a3(o3, n2);
        if (i3.hasEagerState = true, i3.eagerState = s3, Qr(s3, o3)) return Ii(e3, t3, i3, 0), G === null && Fi(), false;
      } catch {
      }
      if (n2 = Li(e3, t3, i3, r3), n2 !== null) return Pd(n2, e3, r3), bc(n2, t3, r3), true;
    }
    return false;
  }
  function _c(e3, t3, n2, r3) {
    if (r3 = { lane: 2, revertLane: Pf(), gesture: null, action: r3, hasEagerState: false, eagerState: null, next: null }, vc(e3)) {
      if (t3) throw Error(a2(479));
    } else t3 = Li(e3, n2, r3, 2), t3 !== null && Pd(t3, e3, 2);
  }
  function vc(e3) {
    var t3 = e3.alternate;
    return e3 === M || t3 !== null && t3 === M;
  }
  function yc(e3, t3) {
    $o = Qo = true;
    var n2 = e3.pending;
    n2 === null ? t3.next = t3 : (t3.next = n2.next, n2.next = t3), e3.pending = t3;
  }
  function bc(e3, t3, n2) {
    if (n2 & 4194048) {
      var r3 = t3.lanes;
      r3 &= e3.pendingLanes, n2 |= r3, t3.lanes = n2, Dt(e3, n2);
    }
  }
  var xc = { readContext: Fa, use: gs, useCallback: F, useContext: F, useEffect: F, useImperativeHandle: F, useLayoutEffect: F, useInsertionEffect: F, useMemo: F, useReducer: F, useRef: F, useState: F, useDebugValue: F, useDeferredValue: F, useTransition: F, useSyncExternalStore: F, useId: F, useHostTransitionStatus: F, useFormState: F, useActionState: F, useOptimistic: F, useMemoCache: F, useCacheRefresh: F, useEffectEvent: F }, Sc = { readContext: Fa, use: gs, useCallback: function(e3, t3) {
    return ps().memoizedState = [e3, t3 === void 0 ? null : t3], e3;
  }, useContext: Fa, useEffect: Ks, useImperativeHandle: function(e3, t3, n2) {
    n2 = n2 == null ? null : n2.concat([e3]), Ws(4194308, 4, Qs.bind(null, t3, e3), n2);
  }, useLayoutEffect: function(e3, t3) {
    return Ws(4194308, 4, e3, t3);
  }, useInsertionEffect: function(e3, t3) {
    Ws(4, 2, e3, t3);
  }, useMemo: function(e3, t3) {
    var n2 = ps();
    t3 = t3 === void 0 ? null : t3;
    var r3 = e3();
    if (es) {
      lt(true);
      try {
        e3();
      } finally {
        lt(false);
      }
    }
    return n2.memoizedState = [r3, t3], r3;
  }, useReducer: function(e3, t3, n2) {
    var r3 = ps();
    if (n2 !== void 0) {
      var i3 = n2(t3);
      if (es) {
        lt(true);
        try {
          n2(t3);
        } finally {
          lt(false);
        }
      }
    } else i3 = t3;
    return r3.memoizedState = r3.baseState = i3, e3 = { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: e3, lastRenderedState: i3 }, r3.queue = e3, e3 = e3.dispatch = mc.bind(null, M, e3), [r3.memoizedState, e3];
  }, useRef: function(e3) {
    var t3 = ps();
    return e3 = { current: e3 }, t3.memoizedState = e3;
  }, useState: function(e3) {
    e3 = Os(e3);
    var t3 = e3.queue, n2 = hc.bind(null, M, t3);
    return t3.dispatch = n2, [e3.memoizedState, n2];
  }, useDebugValue: ec, useDeferredValue: function(e3, t3) {
    return rc(ps(), e3, t3);
  }, useTransition: function() {
    var e3 = Os(false);
    return e3 = ac.bind(null, M, e3.queue, true, false), ps().memoizedState = e3, [false, e3];
  }, useSyncExternalStore: function(e3, t3, n2) {
    var r3 = M, i3 = ps();
    if (A) {
      if (n2 === void 0) throw Error(a2(407));
      n2 = n2();
    } else {
      if (n2 = t3(), G === null) throw Error(a2(349));
      q & 127 || Cs(r3, t3, n2);
    }
    i3.memoizedState = n2;
    var o3 = { value: n2, getSnapshot: t3 };
    return i3.queue = o3, Ks(Ts.bind(null, r3, o3, e3), [e3]), r3.flags |= 2048, Hs(9, { destroy: void 0 }, ws.bind(null, r3, o3, n2, t3), null), n2;
  }, useId: function() {
    var e3 = ps(), t3 = G.identifierPrefix;
    if (A) {
      var n2 = ca, r3 = sa;
      n2 = (r3 & ~(1 << 32 - ut(r3) - 1)).toString(32) + n2, t3 = `_` + t3 + `R_` + n2, n2 = ts++, 0 < n2 && (t3 += `H` + n2.toString(32)), t3 += `_`;
    } else n2 = is++, t3 = `_` + t3 + `r_` + n2.toString(32) + `_`;
    return e3.memoizedState = t3;
  }, useHostTransitionStatus: uc, useFormState: Ls, useActionState: Ls, useOptimistic: function(e3) {
    var t3 = ps();
    t3.memoizedState = t3.baseState = e3;
    var n2 = { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: null, lastRenderedState: null };
    return t3.queue = n2, t3 = _c.bind(null, M, true, n2), n2.dispatch = t3, [e3, t3];
  }, useMemoCache: _s, useCacheRefresh: function() {
    return ps().memoizedState = pc.bind(null, M);
  }, useEffectEvent: function(e3) {
    var t3 = ps(), n2 = { impl: e3 };
    return t3.memoizedState = n2, function() {
      if (W & 2) throw Error(a2(440));
      return n2.impl.apply(void 0, arguments);
    };
  } }, Cc = { readContext: Fa, use: gs, useCallback: tc, useContext: Fa, useEffect: qs, useImperativeHandle: $s, useInsertionEffect: Xs, useLayoutEffect: Zs, useMemo: nc, useReducer: ys, useRef: Us, useState: function() {
    return ys(vs);
  }, useDebugValue: ec, useDeferredValue: function(e3, t3) {
    return ic(I(), N.memoizedState, e3, t3);
  }, useTransition: function() {
    var e3 = ys(vs)[0], t3 = I().memoizedState;
    return [typeof e3 == `boolean` ? e3 : hs(e3), t3];
  }, useSyncExternalStore: Ss, useId: dc, useHostTransitionStatus: uc, useFormState: Rs, useActionState: Rs, useOptimistic: function(e3, t3) {
    return ks(I(), N, e3, t3);
  }, useMemoCache: _s, useCacheRefresh: fc, useEffectEvent: Ys }, wc = { readContext: Fa, use: gs, useCallback: tc, useContext: Fa, useEffect: qs, useImperativeHandle: $s, useInsertionEffect: Xs, useLayoutEffect: Zs, useMemo: nc, useReducer: xs, useRef: Us, useState: function() {
    return xs(vs);
  }, useDebugValue: ec, useDeferredValue: function(e3, t3) {
    var n2 = I();
    return N === null ? rc(n2, e3, t3) : ic(n2, N.memoizedState, e3, t3);
  }, useTransition: function() {
    var e3 = xs(vs)[0], t3 = I().memoizedState;
    return [typeof e3 == `boolean` ? e3 : hs(e3), t3];
  }, useSyncExternalStore: Ss, useId: dc, useHostTransitionStatus: uc, useFormState: Vs, useActionState: Vs, useOptimistic: function(e3, t3) {
    var n2 = I();
    return N === null ? (n2.baseState = e3, [e3, n2.queue.dispatch]) : ks(n2, N, e3, t3);
  }, useMemoCache: _s, useCacheRefresh: fc, useEffectEvent: Ys };
  function Tc(e3, t3, n2, r3) {
    t3 = e3.memoizedState, n2 = n2(r3, t3), n2 = n2 == null ? t3 : x2({}, t3, n2), e3.memoizedState = n2, e3.lanes === 0 && (e3.updateQueue.baseState = n2);
  }
  var Ec = { enqueueSetState: function(e3, t3, n2) {
    e3 = e3._reactInternals;
    var r3 = jd(), i3 = Eo(r3);
    i3.payload = t3, n2 != null && (i3.callback = n2), t3 = Do(e3, i3, r3), t3 !== null && (Pd(t3, e3, r3), Oo(t3, e3, r3));
  }, enqueueReplaceState: function(e3, t3, n2) {
    e3 = e3._reactInternals;
    var r3 = jd(), i3 = Eo(r3);
    i3.tag = 1, i3.payload = t3, n2 != null && (i3.callback = n2), t3 = Do(e3, i3, r3), t3 !== null && (Pd(t3, e3, r3), Oo(t3, e3, r3));
  }, enqueueForceUpdate: function(e3, t3) {
    e3 = e3._reactInternals;
    var n2 = jd(), r3 = Eo(n2);
    r3.tag = 2, t3 != null && (r3.callback = t3), t3 = Do(e3, r3, n2), t3 !== null && (Pd(t3, e3, n2), Oo(t3, e3, n2));
  } };
  function Dc(e3, t3, n2, r3, i3, a3, o3) {
    return e3 = e3.stateNode, typeof e3.shouldComponentUpdate == `function` ? e3.shouldComponentUpdate(r3, a3, o3) : t3.prototype && t3.prototype.isPureReactComponent ? !$r(n2, r3) || !$r(i3, a3) : true;
  }
  function Oc(e3, t3, n2, r3) {
    e3 = t3.state, typeof t3.componentWillReceiveProps == `function` && t3.componentWillReceiveProps(n2, r3), typeof t3.UNSAFE_componentWillReceiveProps == `function` && t3.UNSAFE_componentWillReceiveProps(n2, r3), t3.state !== e3 && Ec.enqueueReplaceState(t3, t3.state, null);
  }
  function kc(e3, t3) {
    var n2 = t3;
    if (`ref` in t3) for (var r3 in n2 = {}, t3) r3 !== `ref` && (n2[r3] = t3[r3]);
    if (e3 = e3.defaultProps) for (var i3 in n2 === t3 && (n2 = x2({}, n2)), e3) n2[i3] === void 0 && (n2[i3] = e3[i3]);
    return n2;
  }
  function Ac(e3) {
    ji(e3);
  }
  function jc(e3) {
    console.error(e3);
  }
  function Mc(e3) {
    ji(e3);
  }
  function Nc(e3, t3) {
    try {
      var n2 = e3.onUncaughtError;
      n2(t3.value, { componentStack: t3.stack });
    } catch (e4) {
      setTimeout(function() {
        throw e4;
      });
    }
  }
  function Pc(e3, t3, n2) {
    try {
      var r3 = e3.onCaughtError;
      r3(n2.value, { componentStack: n2.stack, errorBoundary: t3.tag === 1 ? t3.stateNode : null });
    } catch (e4) {
      setTimeout(function() {
        throw e4;
      });
    }
  }
  function Fc(e3, t3, n2) {
    return n2 = Eo(n2), n2.tag = 3, n2.payload = { element: null }, n2.callback = function() {
      Nc(e3, t3);
    }, n2;
  }
  function Ic(e3) {
    return e3 = Eo(e3), e3.tag = 3, e3;
  }
  function Lc(e3, t3, n2, r3) {
    var i3 = n2.type.getDerivedStateFromError;
    if (typeof i3 == `function`) {
      var a3 = r3.value;
      e3.payload = function() {
        return i3(a3);
      }, e3.callback = function() {
        Pc(t3, n2, r3);
      };
    }
    var o3 = n2.stateNode;
    o3 !== null && typeof o3.componentDidCatch == `function` && (e3.callback = function() {
      Pc(t3, n2, r3), typeof i3 != `function` && (yd === null ? yd = /* @__PURE__ */ new Set([this]) : yd.add(this));
      var e4 = r3.stack;
      this.componentDidCatch(r3.value, { componentStack: e4 === null ? `` : e4 });
    });
  }
  function Rc(e3, t3, n2, r3, i3) {
    if (n2.flags |= 32768, typeof r3 == `object` && r3 && typeof r3.then == `function`) {
      if (t3 = n2.alternate, t3 !== null && Ma(t3, n2, i3, true), n2 = Bo.current, n2 !== null) {
        switch (n2.tag) {
          case 31:
          case 13:
          case 19:
            return Vo === null ? Kd() : n2.alternate === null && Y === 0 && (Y = 3), n2.flags &= -257, n2.flags |= 65536, n2.lanes = i3, r3 === so ? n2.flags |= 16384 : (t3 = n2.updateQueue, t3 === null ? n2.updateQueue = /* @__PURE__ */ new Set([r3]) : t3.add(r3), mf(e3, r3, i3)), false;
          case 22:
            return n2.flags |= 65536, r3 === so ? n2.flags |= 16384 : (t3 = n2.updateQueue, t3 === null ? (t3 = { transitions: null, markerInstances: null, retryQueue: /* @__PURE__ */ new Set([r3]) }, n2.updateQueue = t3) : (n2 = t3.retryQueue, n2 === null ? t3.retryQueue = /* @__PURE__ */ new Set([r3]) : n2.add(r3)), mf(e3, r3, i3)), false;
        }
        throw Error(a2(435, n2.tag));
      }
      return mf(e3, r3, i3), Kd(), false;
    }
    if (A) return t3 = Bo.current, t3 === null ? (r3 !== _a && (t3 = Error(a2(423), { cause: r3 }), wa($i(t3, n2))), e3 = e3.current.alternate, e3.flags |= 65536, i3 &= -i3, e3.lanes |= i3, r3 = $i(r3, n2), i3 = Fc(e3.stateNode, r3, i3), ko(e3, i3), Y !== 4 && (Y = 2)) : (!(t3.flags & 65536) && (t3.flags |= 256), t3.flags |= 65536, t3.lanes = i3, r3 !== _a && (e3 = Error(a2(422), { cause: r3 }), wa($i(e3, n2)))), false;
    var o3 = Error(a2(520), { cause: r3 });
    if (o3 = $i(o3, n2), fd === null ? fd = [o3] : fd.push(o3), Y !== 4 && (Y = 2), t3 === null) return true;
    r3 = $i(r3, n2), n2 = t3;
    do {
      switch (n2.tag) {
        case 3:
          return n2.flags |= 65536, e3 = i3 & -i3, n2.lanes |= e3, e3 = Fc(n2.stateNode, r3, e3), ko(n2, e3), false;
        case 1:
          if (t3 = n2.type, o3 = n2.stateNode, !(n2.flags & 128) && (typeof t3.getDerivedStateFromError == `function` || o3 !== null && typeof o3.componentDidCatch == `function` && (yd === null || !yd.has(o3)))) return n2.flags |= 65536, i3 &= -i3, n2.lanes |= i3, i3 = Ic(i3), Lc(i3, e3, n2, r3), ko(n2, i3), false;
          break;
        case 22:
          if (n2.memoizedState !== null) return n2.flags |= 65536, false;
      }
      n2 = n2.return;
    } while (n2 !== null);
    return false;
  }
  var zc = Error(a2(461)), L = false;
  function R(e3, t3, n2, r3) {
    t3.child = e3 === null ? So(t3, null, n2, r3) : xo(t3, e3.child, n2, r3);
  }
  function Bc(e3, t3, n2, r3, i3) {
    n2 = n2.render;
    var a3 = t3.ref;
    if (`ref` in r3) {
      var o3 = {};
      for (var s3 in r3) s3 !== `ref` && (o3[s3] = r3[s3]);
    } else o3 = r3;
    return Pa(t3), r3 = os(e3, t3, n2, o3, a3, i3), s3 = us(), e3 !== null && !L ? (ds(e3, t3, i3), ml(e3, t3, i3)) : (A && s3 && da(t3), t3.flags |= 1, R(e3, t3, r3, i3), t3.child);
  }
  function Vc(e3, t3, n2, r3, i3) {
    if (e3 === null) {
      var a3 = n2.type;
      return typeof a3 == `function` && !Wi(a3) && a3.defaultProps === void 0 && n2.compare === null ? (t3.tag = 15, t3.type = a3, Hc(e3, t3, a3, r3, i3)) : (e3 = qi(n2.type, null, r3, t3, t3.mode, i3), e3.ref = t3.ref, e3.return = t3, t3.child = e3);
    }
    if (a3 = e3.child, !hl(e3, i3)) {
      var o3 = a3.memoizedProps;
      if (n2 = n2.compare, n2 = n2 === null ? $r : n2, n2(o3, r3) && e3.ref === t3.ref) return ml(e3, t3, i3);
    }
    return t3.flags |= 1, e3 = Gi(a3, r3), e3.ref = t3.ref, e3.return = t3, t3.child = e3;
  }
  function Hc(e3, t3, n2, r3, i3) {
    if (e3 !== null) {
      var a3 = e3.memoizedProps;
      if ($r(a3, r3) && e3.ref === t3.ref) {
        if (L = false, t3.pendingProps = r3 = a3, hl(e3, i3)) e3.flags & 131072 && (L = true);
        else return t3.lanes = e3.lanes, ml(e3, t3, i3);
      }
    }
    return Xc(e3, t3, n2, r3, i3);
  }
  function Uc(e3, t3, n2, r3) {
    var i3 = r3.children, a3 = e3 === null ? null : e3.memoizedState;
    if (e3 === null && t3.stateNode === null && (t3.stateNode = { _visibility: 1, _pendingMarkers: null, _retryCache: null, _transitions: null }), r3.mode === `hidden`) {
      if (t3.flags & 128) {
        if (a3 = a3 === null ? n2 : a3.baseLanes | n2, e3 !== null) {
          for (r3 = t3.child = e3.child, i3 = 0; r3 !== null; ) i3 = i3 | r3.lanes | r3.childLanes, r3 = r3.sibling;
          r3 = i3 & ~a3;
        } else r3 = 0, t3.child = null;
        return Gc(e3, t3, a3, n2, r3);
      }
      if (n2 & 536870912) t3.memoizedState = { baseLanes: 0, cachePool: null }, e3 !== null && no(t3, a3 === null ? null : a3.cachePool), a3 === null ? Ro() : Lo(t3, a3), Wo(t3);
      else return r3 = t3.lanes = 536870912, Gc(e3, t3, a3 === null ? n2 : a3.baseLanes | n2, n2, r3);
    } else a3 === null ? (e3 !== null && no(t3, null), Ro(), Go()) : (no(t3, a3.cachePool), Lo(t3, a3), Go(), t3.memoizedState = null);
    return R(e3, t3, i3, n2), t3.child;
  }
  function Wc(e3, t3) {
    return e3 !== null && e3.tag === 22 || t3.stateNode !== null || (t3.stateNode = { _visibility: 1, _pendingMarkers: null, _retryCache: null, _transitions: null }), t3.sibling;
  }
  function Gc(e3, t3, n2, r3, i3) {
    var a3 = to();
    return a3 = a3 === null ? null : { parent: j._currentValue, pool: a3 }, t3.memoizedState = { baseLanes: n2, cachePool: a3 }, e3 !== null && no(t3, null), Ro(), Wo(t3), e3 !== null && Ma(e3, t3, r3, true), t3.childLanes = i3, null;
  }
  function Kc(e3, t3) {
    return t3 = al({ mode: t3.mode, children: t3.children }, e3.mode), t3.ref = e3.ref, e3.child = t3, t3.return = e3, t3;
  }
  function qc(e3, t3, n2) {
    return xo(t3, e3.child, null, n2), e3 = Kc(t3, t3.pendingProps), e3.flags |= 2, Ko(t3), t3.memoizedState = null, e3;
  }
  function Jc(e3, t3, n2) {
    var r3 = t3.pendingProps, i3 = !!(t3.flags & 128);
    if (t3.flags &= -129, e3 === null) {
      if (A) {
        if (r3.mode === `hidden`) return e3 = Kc(t3, r3), t3.lanes = 536870912, e3.memoizedState = { baseLanes: 0, cachePool: null }, Wc(null, e3);
        if (Uo(t3), (e3 = k) ? (e3 = am(e3, ga), e3 = e3 !== null && e3.data === `&` ? e3 : null, e3 !== null && (t3.memoizedState = { dehydrated: e3, treeContext: oa === null ? null : { id: sa, overflow: ca }, retryLane: 536870912, hydrationErrors: null }, n2 = Xi(e3), n2.return = t3, t3.child = n2, ma = t3, k = null)) : e3 = null, e3 === null) throw va(t3);
        return t3.lanes = 536870912, null;
      }
      return Kc(t3, r3);
    }
    var o3 = e3.memoizedState;
    if (o3 !== null) {
      var s3 = o3.dehydrated;
      if (Uo(t3), i3) {
        if (t3.flags & 256) t3.flags &= -257, t3 = qc(e3, t3, n2);
        else if (t3.memoizedState !== null) t3.child = e3.child, t3.flags |= 128, t3 = null;
        else throw Error(a2(558));
      } else if (L || Ma(e3, t3, n2, false), i3 = (n2 & e3.childLanes) !== 0, L || i3) {
        if (Fo.current === null) {
          if (r3 = G, r3 !== null && (s3 = Ot(r3, n2), s3 !== 0 && s3 !== o3.retryLane)) throw o3.retryLane = s3, Ri(e3, s3), Pd(r3, e3, s3), zc;
          Kd();
        }
        t3 = qc(e3, t3, n2);
      } else e3 = o3.treeContext, k = lm(s3.nextSibling), ma = t3, A = true, ha = null, ga = false, e3 !== null && pa(t3, e3), t3 = Kc(t3, r3), t3.flags |= 134221824;
      return t3;
    }
    return e3 = Gi(e3.child, { mode: r3.mode, children: r3.children }), e3.ref = t3.ref, t3.child = e3, e3.return = t3, e3;
  }
  function Yc(e3, t3) {
    var n2 = t3.ref;
    if (n2 === null) e3 !== null && e3.ref !== null && (t3.flags |= 4194816);
    else {
      if (typeof n2 != `function` && typeof n2 != `object`) throw Error(a2(284));
      (e3 === null || e3.ref !== n2) && (t3.flags |= 4194816);
    }
  }
  function Xc(e3, t3, n2, r3, i3) {
    return Pa(t3), n2 = os(e3, t3, n2, r3, void 0, i3), r3 = us(), e3 !== null && !L ? (ds(e3, t3, i3), ml(e3, t3, i3)) : (A && r3 && da(t3), t3.flags |= 1, R(e3, t3, n2, i3), t3.child);
  }
  function Zc(e3, t3, n2, r3, i3, a3) {
    return Pa(t3), t3.updateQueue = null, n2 = cs(t3, r3, n2, i3), ss(e3), r3 = us(), e3 !== null && !L ? (ds(e3, t3, a3), ml(e3, t3, a3)) : (A && r3 && da(t3), t3.flags |= 1, R(e3, t3, n2, a3), t3.child);
  }
  function Qc(e3, t3, n2, r3, i3) {
    if (Pa(t3), t3.stateNode === null) {
      var a3 = Vi, o3 = n2.contextType;
      typeof o3 == `object` && o3 && (a3 = Fa(o3)), a3 = new n2(r3, a3), t3.memoizedState = a3.state !== null && a3.state !== void 0 ? a3.state : null, a3.updater = Ec, t3.stateNode = a3, a3._reactInternals = t3, a3 = t3.stateNode, a3.props = r3, a3.state = t3.memoizedState, a3.refs = {}, wo(t3), o3 = n2.contextType, a3.context = typeof o3 == `object` && o3 ? Fa(o3) : Vi, a3.state = t3.memoizedState, o3 = n2.getDerivedStateFromProps, typeof o3 == `function` && (Tc(t3, n2, o3, r3), a3.state = t3.memoizedState), typeof n2.getDerivedStateFromProps == `function` || typeof a3.getSnapshotBeforeUpdate == `function` || typeof a3.UNSAFE_componentWillMount != `function` && typeof a3.componentWillMount != `function` || (o3 = a3.state, typeof a3.componentWillMount == `function` && a3.componentWillMount(), typeof a3.UNSAFE_componentWillMount == `function` && a3.UNSAFE_componentWillMount(), o3 !== a3.state && Ec.enqueueReplaceState(a3, a3.state, null), Mo(t3, r3, a3, i3), jo(), a3.state = t3.memoizedState), typeof a3.componentDidMount == `function` && (t3.flags |= 4194308), r3 = true;
    } else if (e3 === null) {
      a3 = t3.stateNode;
      var s3 = t3.memoizedProps, c3 = kc(n2, s3);
      a3.props = c3;
      var l3 = a3.context, u3 = n2.contextType;
      o3 = Vi, typeof u3 == `object` && u3 && (o3 = Fa(u3));
      var d3 = n2.getDerivedStateFromProps;
      u3 = typeof d3 == `function` || typeof a3.getSnapshotBeforeUpdate == `function`, s3 = t3.pendingProps !== s3, u3 || typeof a3.UNSAFE_componentWillReceiveProps != `function` && typeof a3.componentWillReceiveProps != `function` || (s3 || l3 !== o3) && Oc(t3, a3, r3, o3), Co = false;
      var f3 = t3.memoizedState;
      a3.state = f3, Mo(t3, r3, a3, i3), jo(), l3 = t3.memoizedState, s3 || f3 !== l3 || Co ? (typeof d3 == `function` && (Tc(t3, n2, d3, r3), l3 = t3.memoizedState), (c3 = Co || Dc(t3, n2, c3, r3, f3, l3, o3)) ? (u3 || typeof a3.UNSAFE_componentWillMount != `function` && typeof a3.componentWillMount != `function` || (typeof a3.componentWillMount == `function` && a3.componentWillMount(), typeof a3.UNSAFE_componentWillMount == `function` && a3.UNSAFE_componentWillMount()), typeof a3.componentDidMount == `function` && (t3.flags |= 4194308)) : (typeof a3.componentDidMount == `function` && (t3.flags |= 4194308), t3.memoizedProps = r3, t3.memoizedState = l3), a3.props = r3, a3.state = l3, a3.context = o3, r3 = c3) : (typeof a3.componentDidMount == `function` && (t3.flags |= 4194308), r3 = false);
    } else {
      a3 = t3.stateNode, To(e3, t3), o3 = t3.memoizedProps, u3 = kc(n2, o3), a3.props = u3, d3 = t3.pendingProps, f3 = a3.context, l3 = n2.contextType, c3 = Vi, typeof l3 == `object` && l3 && (c3 = Fa(l3)), s3 = n2.getDerivedStateFromProps, (l3 = typeof s3 == `function` || typeof a3.getSnapshotBeforeUpdate == `function`) || typeof a3.UNSAFE_componentWillReceiveProps != `function` && typeof a3.componentWillReceiveProps != `function` || (o3 !== d3 || f3 !== c3) && Oc(t3, a3, r3, c3), Co = false, f3 = t3.memoizedState, a3.state = f3, Mo(t3, r3, a3, i3), jo();
      var p3 = t3.memoizedState;
      o3 !== d3 || f3 !== p3 || Co || e3 !== null && e3.dependencies !== null && Na(e3.dependencies) ? (typeof s3 == `function` && (Tc(t3, n2, s3, r3), p3 = t3.memoizedState), (u3 = Co || Dc(t3, n2, u3, r3, f3, p3, c3) || e3 !== null && e3.dependencies !== null && Na(e3.dependencies)) ? (l3 || typeof a3.UNSAFE_componentWillUpdate != `function` && typeof a3.componentWillUpdate != `function` || (typeof a3.componentWillUpdate == `function` && a3.componentWillUpdate(r3, p3, c3), typeof a3.UNSAFE_componentWillUpdate == `function` && a3.UNSAFE_componentWillUpdate(r3, p3, c3)), typeof a3.componentDidUpdate == `function` && (t3.flags |= 4), typeof a3.getSnapshotBeforeUpdate == `function` && (t3.flags |= 1024)) : (typeof a3.componentDidUpdate != `function` || o3 === e3.memoizedProps && f3 === e3.memoizedState || (t3.flags |= 4), typeof a3.getSnapshotBeforeUpdate != `function` || o3 === e3.memoizedProps && f3 === e3.memoizedState || (t3.flags |= 1024), t3.memoizedProps = r3, t3.memoizedState = p3), a3.props = r3, a3.state = p3, a3.context = c3, r3 = u3) : (typeof a3.componentDidUpdate != `function` || o3 === e3.memoizedProps && f3 === e3.memoizedState || (t3.flags |= 4), typeof a3.getSnapshotBeforeUpdate != `function` || o3 === e3.memoizedProps && f3 === e3.memoizedState || (t3.flags |= 1024), r3 = false);
    }
    return a3 = r3, Yc(e3, t3), r3 = !!(t3.flags & 128), a3 || r3 ? (a3 = t3.stateNode, n2 = r3 && typeof n2.getDerivedStateFromError != `function` ? null : a3.render(), t3.flags |= 1, e3 !== null && r3 ? (t3.child = xo(t3, e3.child, null, i3), t3.child = xo(t3, null, n2, i3)) : R(e3, t3, n2, i3), t3.memoizedState = a3.state, e3 = t3.child) : e3 = ml(e3, t3, i3), e3;
  }
  function $c(e3, t3, n2, r3) {
    return Sa(), t3.flags |= 256, R(e3, t3, n2, r3), t3.child;
  }
  var el = { dehydrated: null, treeContext: null, retryLane: 0, hydrationErrors: null };
  function tl(e3) {
    return { baseLanes: e3, cachePool: ro() };
  }
  function nl(e3, t3, n2) {
    return e3 = e3 === null ? 0 : e3.childLanes & ~n2, t3 && (e3 |= ud), e3;
  }
  function rl(e3, t3, n2) {
    var r3 = t3.pendingProps, i3 = false, a3 = !!(t3.flags & 128), o3;
    if ((o3 = a3) || (o3 = e3 !== null && e3.memoizedState === null ? false : !!(qo.current & 2)), o3 && (i3 = true, t3.flags &= -129), o3 = !!(t3.flags & 32), t3.flags &= -33, e3 === null) {
      if (A) {
        if (i3 ? Ho(t3) : Go(), (e3 = k) ? (e3 = am(e3, ga), e3 = e3 !== null && e3.data !== `&` ? e3 : null, e3 !== null && (t3.memoizedState = { dehydrated: e3, treeContext: oa === null ? null : { id: sa, overflow: ca }, retryLane: 536870912, hydrationErrors: null }, n2 = Xi(e3), n2.return = t3, t3.child = n2, ma = t3, k = null)) : e3 = null, e3 === null) throw va(t3);
        return t3.lanes = sm(e3) ? 32 : 536870912, null;
      }
      return a3 = r3.children, r3 = r3.fallback, i3 ? (Go(), i3 = t3.mode, a3 = al({ mode: `hidden`, children: a3 }, i3), r3 = Ji(r3, i3, n2, null), a3.return = t3, r3.return = t3, a3.sibling = r3, t3.child = a3, r3 = t3.child, r3.memoizedState = tl(n2), r3.childLanes = nl(e3, o3, n2), t3.memoizedState = el, Wc(null, r3)) : (Ho(t3), il(t3, a3));
    }
    var s3 = e3.memoizedState;
    if (s3 !== null) {
      var c3 = s3.dehydrated;
      if (c3 !== null) return sl(e3, t3, a3, o3, r3, c3, s3, n2);
    }
    return i3 ? (Go(), i3 = r3.fallback, a3 = t3.mode, s3 = e3.child, c3 = s3.sibling, r3 = Gi(s3, { mode: `hidden`, children: r3.children }), r3.subtreeFlags = s3.subtreeFlags & 1206910976, c3 === null ? (i3 = Ji(i3, a3, n2, null), i3.flags |= 2) : i3 = Gi(c3, i3), i3.return = t3, r3.return = t3, r3.sibling = i3, t3.child = r3, Wc(null, r3), r3 = t3.child, i3 = e3.child.memoizedState, i3 === null ? i3 = tl(n2) : (a3 = i3.cachePool, a3 === null ? a3 = ro() : (s3 = j._currentValue, a3 = a3.parent === s3 ? a3 : { parent: s3, pool: s3 }), i3 = { baseLanes: i3.baseLanes | n2, cachePool: a3 }), r3.memoizedState = i3, r3.childLanes = nl(e3, o3, n2), t3.memoizedState = el, Wc(e3.child, r3)) : (Ho(t3), n2 = e3.child, e3 = n2.sibling, n2 = Gi(n2, { mode: `visible`, children: r3.children }), n2.return = t3, n2.sibling = null, e3 !== null && (o3 = t3.deletions, o3 === null ? (t3.deletions = [e3], t3.flags |= 16) : o3.push(e3)), t3.child = n2, t3.memoizedState = null, n2);
  }
  function il(e3, t3) {
    return t3 = al({ mode: `visible`, children: t3 }, e3.mode), t3.return = e3, e3.child = t3;
  }
  function al(e3, t3) {
    return e3 = Ui(22, e3, null, t3), e3.lanes = 0, e3;
  }
  function ol(e3, t3, n2) {
    return xo(t3, e3.child, null, n2), e3 = il(t3, t3.pendingProps.children), e3.flags |= 2, t3.memoizedState = null, e3;
  }
  function sl(e3, t3, n2, r3, i3, o3, s3, c3) {
    if (n2) return t3.flags & 256 ? (Ho(t3), t3.flags &= -257, ol(e3, t3, c3)) : t3.memoizedState === null ? (Go(), o3 = i3.fallback, s3 = t3.mode, i3 = al({ mode: `visible`, children: i3.children }, s3), o3 = Ji(o3, s3, c3, null), o3.flags |= 2, i3.return = t3, o3.return = t3, i3.sibling = o3, t3.child = i3, xo(t3, e3.child, null, c3), i3 = t3.child, i3.memoizedState = tl(c3), i3.childLanes = nl(e3, r3, c3), t3.memoizedState = el, Wc(null, i3)) : (Go(), t3.child = e3.child, t3.flags |= 128, null);
    if (Ho(t3), sm(o3)) {
      if (r3 = o3.nextSibling && o3.nextSibling.dataset, r3) var l3 = r3.dgst;
      return r3 = l3, r3 !== `` && (i3 = Error(a2(419)), i3.stack = ``, i3.digest = r3, wa({ value: i3, source: null, stack: null })), ol(e3, t3, c3);
    }
    if (L || Ma(e3, t3, c3, false), r3 = (c3 & e3.childLanes) !== 0, L || r3) {
      if (Fo.current !== null) return ol(e3, t3, c3);
      if (r3 = G, r3 !== null && (i3 = Ot(r3, c3), i3 !== 0 && i3 !== s3.retryLane)) throw s3.retryLane = i3, Ri(e3, i3), Pd(r3, e3, i3), zc;
      return om(o3) || Kd(), ol(e3, t3, c3);
    }
    return om(o3) ? (t3.flags |= 192, t3.child = e3.child, null) : (e3 = s3.treeContext, k = lm(o3.nextSibling), ma = t3, A = true, ha = null, ga = false, e3 !== null && pa(t3, e3), t3 = il(t3, i3.children), t3.flags |= 134221824, t3);
  }
  function cl(e3, t3, n2) {
    e3.lanes |= t3;
    var r3 = e3.alternate;
    r3 !== null && (r3.lanes |= t3), Aa(e3.return, t3, n2);
  }
  function ll(e3) {
    for (var t3 = null; e3 !== null; ) {
      var n2 = e3.alternate;
      n2 !== null && Xo(n2) === null && (t3 = e3), e3 = e3.sibling;
    }
    return t3;
  }
  function ul(e3, t3, n2, r3, i3, a3) {
    var o3 = e3.memoizedState;
    o3 === null ? e3.memoizedState = { isBackwards: t3, rendering: null, renderingStartTime: 0, last: r3, tail: n2, tailMode: i3, treeForkCount: a3 } : (o3.isBackwards = t3, o3.rendering = null, o3.renderingStartTime = 0, o3.last = r3, o3.tail = n2, o3.tailMode = i3, o3.treeForkCount = a3);
  }
  function dl(e3) {
    var t3 = e3.child;
    for (e3.child = null; t3 !== null; ) {
      var n2 = t3.sibling;
      t3.sibling = e3.child, e3.child = t3, t3 = n2;
    }
  }
  function fl(e3, t3, n2) {
    var r3 = t3.pendingProps, i3 = r3.revealOrder, a3 = r3.tail;
    r3 = r3.children;
    var o3 = qo.current;
    if (t3.flags & 128) return Jo(t3, o3), null;
    var s3 = !!(o3 & 2);
    if (s3 ? (o3 = o3 & 1 | 2, t3.flags |= 128) : o3 &= 1, Jo(t3, o3), i3 === `backwards` && e3 !== null ? (dl(e3), R(e3, t3, r3, n2), dl(e3)) : R(e3, t3, r3, n2), r3 = A ? ra : 0, !s3 && e3 !== null && e3.flags & 128) a: for (e3 = t3.child; e3 !== null; ) {
      if (e3.tag === 13) e3.memoizedState !== null && cl(e3, n2, t3);
      else if (e3.tag === 19) cl(e3, n2, t3);
      else if (e3.child !== null) {
        e3.child.return = e3, e3 = e3.child;
        continue;
      }
      if (e3 === t3) break a;
      for (; e3.sibling === null; ) {
        if (e3.return === null || e3.return === t3) break a;
        e3 = e3.return;
      }
      e3.sibling.return = e3.return, e3 = e3.sibling;
    }
    switch (i3) {
      case `backwards`:
        n2 = ll(t3.child), n2 === null ? (i3 = t3.child, t3.child = null) : (i3 = n2.sibling, n2.sibling = null, dl(t3)), ul(t3, true, i3, null, a3, r3);
        break;
      case `unstable_legacy-backwards`:
        for (n2 = null, i3 = t3.child, t3.child = null; i3 !== null; ) {
          if (e3 = i3.alternate, e3 !== null && Xo(e3) === null) {
            t3.child = i3;
            break;
          }
          e3 = i3.sibling, i3.sibling = n2, n2 = i3, i3 = e3;
        }
        ul(t3, true, n2, null, a3, r3);
        break;
      case `together`:
        ul(t3, false, null, null, void 0, r3);
        break;
      case `independent`:
        t3.memoizedState = null;
        break;
      default:
        n2 = ll(t3.child), n2 === null ? (i3 = t3.child, t3.child = null) : (i3 = n2.sibling, n2.sibling = null), ul(t3, false, i3, n2, a3, r3);
    }
    return t3.child;
  }
  function pl(e3, t3, n2) {
    var r3 = t3.pendingProps;
    return Oa(t3, t3.type, r3.value), R(e3, t3, r3.children, n2), t3.child;
  }
  function ml(e3, t3, n2) {
    if (e3 !== null && (t3.dependencies = e3.dependencies), sd |= t3.lanes, (n2 & t3.childLanes) === 0) {
      if (e3 !== null) {
        if (Ma(e3, t3, n2, false), (n2 & t3.childLanes) === 0) return null;
      } else return null;
    }
    if (e3 !== null && t3.child !== e3.child) throw Error(a2(153));
    if (t3.child !== null) {
      for (e3 = t3.child, n2 = Gi(e3, e3.pendingProps), t3.child = n2, n2.return = t3; e3.sibling !== null; ) e3 = e3.sibling, n2 = n2.sibling = Gi(e3, e3.pendingProps), n2.return = t3;
      n2.sibling = null;
    }
    return t3.child;
  }
  function hl(e3, t3) {
    return (e3.lanes & t3) !== 0 || (e3 = e3.dependencies, !!(e3 !== null && Na(e3)));
  }
  function gl(e3, t3, n2) {
    switch (t3.tag) {
      case 3:
        Ie(t3, t3.stateNode.containerInfo), Oa(t3, j, e3.memoizedState.cache), Sa();
        break;
      case 27:
      case 5:
        Re(t3);
        break;
      case 4:
        Ie(t3, t3.stateNode.containerInfo);
        break;
      case 10:
        Oa(t3, t3.type, t3.memoizedProps.value);
        break;
      case 31:
        if (t3.memoizedState !== null) return t3.flags |= 128, Uo(t3), null;
        break;
      case 13:
        var r3 = t3.memoizedState;
        if (r3 !== null) {
          if (r3.dehydrated !== null) return Ho(t3), t3.flags |= 128, null;
          r3 = Ma(e3, t3, n2, false);
          var i3 = t3.child.childLanes;
          return r3 || (n2 & i3) !== 0 ? rl(e3, t3, n2) : (Ho(t3), e3 = ml(e3, t3, n2), e3 === null ? null : e3.sibling);
        }
        Ho(t3);
        break;
      case 19:
        if (t3.flags & 128) return fl(e3, t3, n2);
        if (i3 = !!(e3.flags & 128), r3 = (n2 & t3.childLanes) !== 0, r3 ||= (Ma(e3, t3, n2, false), (n2 & t3.childLanes) !== 0), i3) {
          if (r3) return fl(e3, t3, n2);
          t3.flags |= 128;
        }
        if (i3 = t3.memoizedState, i3 !== null && (i3.rendering = null, i3.tail = null, i3.lastEffect = null), Jo(t3, qo.current), r3) break;
        return null;
      case 22:
        return t3.lanes = 0, Uc(e3, t3, n2, t3.pendingProps);
      case 24:
        Oa(t3, j, e3.memoizedState.cache);
    }
    return ml(e3, t3, n2);
  }
  function _l(e3, t3, n2) {
    if (e3 !== null) {
      if (e3.memoizedProps !== t3.pendingProps) L = true;
      else {
        if (!hl(e3, n2) && !(t3.flags & 128)) return L = false, gl(e3, t3, n2);
        L = !!(e3.flags & 131072);
      }
    } else L = false, A && t3.flags & 1048576 && ua(t3, ra, t3.index);
    switch (t3.lanes = 0, t3.tag) {
      case 16:
        a: {
          var r3 = t3.pendingProps;
          if (e3 = uo(t3.elementType), t3.type = e3, typeof e3 == `function`) Wi(e3) ? (r3 = kc(e3, r3), t3.tag = 1, t3 = Qc(null, t3, e3, r3, n2)) : (t3.tag = 0, t3 = Xc(null, t3, e3, r3, n2));
          else {
            if (e3 != null) {
              var i3 = e3.$$typeof;
              if (i3 === pe) {
                t3.tag = 11, t3 = Bc(null, t3, e3, r3, n2);
                break a;
              }
              if (i3 === ge) {
                t3.tag = 14, t3 = Vc(null, t3, e3, r3, n2);
                break a;
              }
              if (i3 === S) {
                t3.tag = 10, t3.type = e3, t3 = pl(null, t3, n2);
                break a;
              }
            }
            throw t3 = Te(e3) || e3, Error(a2(306, t3, ``));
          }
        }
        return t3;
      case 0:
        return Xc(e3, t3, t3.type, t3.pendingProps, n2);
      case 1:
        return r3 = t3.type, i3 = kc(r3, t3.pendingProps), Qc(e3, t3, r3, i3, n2);
      case 3:
        a: {
          if (Ie(t3, t3.stateNode.containerInfo), e3 === null) throw Error(a2(387));
          r3 = t3.pendingProps;
          var o3 = t3.memoizedState;
          i3 = o3.element, To(e3, t3), Mo(t3, r3, null, n2);
          var s3 = t3.memoizedState;
          if (r3 = s3.cache, Oa(t3, j, r3), r3 !== o3.cache && ja(t3, [j], n2, true), jo(), r3 = s3.element, o3.isDehydrated) {
            if (o3 = { element: r3, isDehydrated: false, cache: s3.cache }, t3.updateQueue.baseState = o3, t3.memoizedState = o3, t3.flags & 256) {
              t3 = $c(e3, t3, r3, n2);
              break a;
            }
            if (r3 !== i3) {
              i3 = $i(Error(a2(424)), t3), wa(i3), t3 = $c(e3, t3, r3, n2);
              break a;
            }
            switch (e3 = t3.stateNode.containerInfo, e3.nodeType) {
              case 9:
                e3 = e3.body;
                break;
              default:
                e3 = e3.nodeName === `HTML` ? e3.ownerDocument.body : e3;
            }
            for (k = lm(e3.firstChild), ma = t3, A = true, ha = null, ga = true, n2 = So(t3, null, r3, n2), t3.child = n2; n2; ) n2.flags = n2.flags & -3 | 134221824, n2 = n2.sibling;
          } else {
            if (Sa(), r3 === i3) {
              t3 = ml(e3, t3, n2);
              break a;
            }
            R(e3, t3, r3, n2);
          }
          t3 = t3.child;
        }
        return t3;
      case 26:
        return Yc(e3, t3), e3 === null ? (n2 = Nm(t3.type, null, t3.pendingProps, null)) ? t3.memoizedState = n2 : A || (t3.stateNode = fp(t3.type, t3.pendingProps, Pe.current, t3)) : t3.memoizedState = Nm(t3.type, e3.memoizedProps, t3.pendingProps, e3.memoizedState), null;
      case 27:
        return Re(t3), e3 === null && A && (r3 = t3.stateNode = hm(t3.type, t3.pendingProps, Pe.current), ma = t3, ga = true, i3 = k, Sp(t3.type) ? (um = i3, k = lm(r3.firstChild)) : k = i3), R(e3, t3, t3.pendingProps.children, n2), Yc(e3, t3), e3 === null && (t3.flags |= 4194304), t3.child;
      case 5:
        return e3 === null && A && ((i3 = r3 = k) && (r3 = rm(r3, t3.type, t3.pendingProps, ga), r3 === null ? i3 = false : (t3.stateNode = r3, ma = t3, k = lm(r3.firstChild), ga = false, i3 = true)), i3 || va(t3)), Re(t3), i3 = t3.type, o3 = t3.pendingProps, s3 = e3 === null ? null : e3.memoizedProps, r3 = o3.children, pp(i3, o3) ? r3 = null : s3 !== null && pp(i3, s3) && (t3.flags |= 32), t3.memoizedState !== null && (i3 = os(e3, t3, ls, null, null, n2), sh._currentValue = i3), Yc(e3, t3), R(e3, t3, r3, n2), t3.child;
      case 6:
        return e3 === null && A && ((e3 = n2 = k) && (n2 = im(n2, t3.pendingProps, ga), n2 === null ? e3 = false : (t3.stateNode = n2, ma = t3, k = null, e3 = true)), e3 || va(t3)), null;
      case 13:
        return rl(e3, t3, n2);
      case 4:
        return Ie(t3, t3.stateNode.containerInfo), r3 = t3.pendingProps, e3 === null ? t3.child = xo(t3, null, r3, n2) : R(e3, t3, r3, n2), t3.child;
      case 11:
        return Bc(e3, t3, t3.type, t3.pendingProps, n2);
      case 7:
        return r3 = t3.pendingProps, Yc(e3, t3), R(e3, t3, r3, n2), t3.child;
      case 8:
        return R(e3, t3, t3.pendingProps.children, n2), t3.child;
      case 12:
        return R(e3, t3, t3.pendingProps.children, n2), t3.child;
      case 10:
        return pl(e3, t3, n2);
      case 9:
        return i3 = t3.type._context, r3 = t3.pendingProps.children, Pa(t3), i3 = Fa(i3), r3 = r3(i3), t3.flags |= 1, R(e3, t3, r3, n2), t3.child;
      case 14:
        return Vc(e3, t3, t3.type, t3.pendingProps, n2);
      case 15:
        return Hc(e3, t3, t3.type, t3.pendingProps, n2);
      case 19:
        return fl(e3, t3, n2);
      case 31:
        return Jc(e3, t3, n2);
      case 22:
        return Uc(e3, t3, n2, t3.pendingProps);
      case 24:
        return Pa(t3), r3 = Fa(j), e3 === null ? (i3 = to(), i3 === null && (i3 = G, o3 = Va(), i3.pooledCache = o3, o3.refCount++, o3 !== null && (i3.pooledCacheLanes |= n2), i3 = o3), t3.memoizedState = { parent: r3, cache: i3 }, wo(t3), Oa(t3, j, i3)) : ((e3.lanes & n2) !== 0 && (To(e3, t3), Mo(t3, null, null, n2), jo()), i3 = e3.memoizedState, o3 = t3.memoizedState, i3.parent === r3 ? (r3 = o3.cache, Oa(t3, j, r3), r3 !== i3.cache && ja(t3, [j], n2, true)) : (i3 = { parent: r3, cache: r3 }, t3.memoizedState = i3, t3.lanes === 0 && (t3.memoizedState = t3.updateQueue.baseState = i3), Oa(t3, j, r3))), R(e3, t3, t3.pendingProps.children, n2), t3.child;
      case 30:
        return t3.stateNode === null && (t3.stateNode = { autoName: null, paired: null, clones: null, ref: null }), r3 = t3.pendingProps, r3.name != null && r3.name !== `auto` ? t3.flags |= e3 === null ? 18882560 : 18874368 : A && da(t3), e3 !== null && e3.memoizedProps.name !== r3.name ? t3.flags |= 4194816 : Yc(e3, t3), R(e3, t3, r3.children, n2), t3.child;
      case 29:
        throw t3.pendingProps;
    }
    throw Error(a2(156, t3.tag));
  }
  function vl(e3) {
    e3.flags |= 4;
  }
  function yl(e3, t3, n2, r3, i3) {
    var a3;
    if ((a3 = !!(e3.mode & 32)) && (a3 = n2 === null ? Jm(t3, r3) : Jm(t3, r3) && (r3.src !== n2.src || r3.srcSet !== n2.srcSet)), a3) {
      if (e3.flags |= 16777216, (i3 & 335544128) === i3) {
        if (e3.stateNode.complete) e3.flags |= 8192;
        else if (Ud()) e3.flags |= 8192;
        else throw fo = so, ao;
      }
    } else e3.flags &= -16777217;
  }
  function bl(e3, t3) {
    if (t3.type !== `stylesheet` || t3.state.loading & 4) e3.flags &= -16777217;
    else if (e3.flags |= 16777216, !Ym(t3)) {
      if (Ud()) e3.flags |= 8192;
      else throw fo = so, ao;
    }
  }
  function xl(e3, t3) {
    t3 !== null && (e3.flags |= 4), e3.flags & 16384 && (t3 = e3.tag === 22 ? 536870912 : St(), e3.lanes |= t3, dd |= t3);
  }
  function Sl(e3, t3) {
    if (!A) switch (e3.tailMode) {
      case `visible`:
        break;
      case `collapsed`:
        for (var n2 = e3.tail, r3 = null; n2 !== null; ) n2.alternate !== null && (r3 = n2), n2 = n2.sibling;
        r3 === null ? t3 || e3.tail === null ? e3.tail = null : e3.tail.sibling = null : r3.sibling = null;
        break;
      default:
        for (t3 = e3.tail, n2 = null; t3 !== null; ) t3.alternate !== null && (n2 = t3), t3 = t3.sibling;
        n2 === null ? e3.tail = null : n2.sibling = null;
    }
  }
  function z(e3) {
    var t3 = e3.alternate !== null && e3.alternate.child === e3.child, n2 = 0, r3 = 0;
    if (t3) for (var i3 = e3.child; i3 !== null; ) n2 |= i3.lanes | i3.childLanes, r3 |= i3.subtreeFlags & 1206910976, r3 |= i3.flags & 1206910976, i3.return = e3, i3 = i3.sibling;
    else for (i3 = e3.child; i3 !== null; ) n2 |= i3.lanes | i3.childLanes, r3 |= i3.subtreeFlags, r3 |= i3.flags, i3.return = e3, i3 = i3.sibling;
    return e3.subtreeFlags |= r3, e3.childLanes = n2, t3;
  }
  function Cl(e3, t3, n2) {
    var r3 = t3.pendingProps;
    switch (fa(t3), t3.tag) {
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return z(t3), null;
      case 1:
        return z(t3), null;
      case 3:
        return n2 = t3.stateNode, r3 = null, e3 !== null && (r3 = e3.memoizedState.cache), t3.memoizedState.cache !== r3 && (t3.flags |= 2048), ka(j), Le(), n2.pendingContext && (n2.context = n2.pendingContext, n2.pendingContext = null), (e3 === null || e3.child === null) && (xa(t3) ? vl(t3) : e3 === null || e3.memoizedState.isDehydrated && !(t3.flags & 256) || (t3.flags |= 1024, Ca())), z(t3), null;
      case 26:
        var i3 = t3.type, o3 = t3.memoizedState;
        return e3 === null ? (vl(t3), o3 === null ? (z(t3), yl(t3, i3, null, r3, n2)) : (z(t3), bl(t3, o3))) : o3 ? o3 === e3.memoizedState ? (z(t3), t3.flags &= -16777217) : (vl(t3), z(t3), bl(t3, o3)) : (e3 = e3.memoizedProps, e3 !== r3 && vl(t3), z(t3), yl(t3, i3, e3, r3, n2)), null;
      case 27:
        if (ze(t3), n2 = Pe.current, i3 = t3.type, e3 !== null && t3.stateNode != null) e3.memoizedProps !== r3 && vl(t3);
        else {
          if (!r3) {
            if (t3.stateNode === null) throw Error(a2(166));
            return z(t3), t3.subtreeFlags &= -33554433, null;
          }
          e3 = Me.current, xa(t3) ? ya(t3, e3) : (e3 = hm(i3, r3, n2), t3.stateNode = e3, vl(t3));
        }
        return z(t3), t3.subtreeFlags &= -33554433, null;
      case 5:
        if (ze(t3), i3 = t3.type, e3 !== null && t3.stateNode != null) e3.memoizedProps !== r3 && vl(t3);
        else {
          if (!r3) {
            if (t3.stateNode === null) throw Error(a2(166));
            return z(t3), t3.subtreeFlags &= -33554433, null;
          }
          if (o3 = Me.current, xa(t3)) ya(t3, o3);
          else {
            var s3 = lp(Pe.current);
            switch (o3) {
              case 1:
                o3 = s3.createElementNS(`http://www.w3.org/2000/svg`, i3);
                break;
              case 2:
                o3 = s3.createElementNS(`http://www.w3.org/1998/Math/MathML`, i3);
                break;
              default:
                switch (i3) {
                  case `svg`:
                    o3 = s3.createElementNS(`http://www.w3.org/2000/svg`, i3);
                    break;
                  case `math`:
                    o3 = s3.createElementNS(`http://www.w3.org/1998/Math/MathML`, i3);
                    break;
                  case `script`:
                    o3 = s3.createElement(`div`), o3.innerHTML = `<script><\/script>`, o3 = o3.removeChild(o3.firstChild);
                    break;
                  case `select`:
                    o3 = typeof r3.is == `string` ? s3.createElement(`select`, { is: r3.is }) : s3.createElement(`select`), r3.multiple ? o3.multiple = true : r3.size && (o3.size = r3.size);
                    break;
                  default:
                    o3 = typeof r3.is == `string` ? s3.createElement(i3, { is: r3.is }) : s3.createElement(i3);
                }
            }
            o3[Pt] = t3, o3[Ft] = r3;
            a: for (s3 = t3.child; s3 !== null; ) {
              if (s3.tag === 5 || s3.tag === 6) o3.appendChild(s3.stateNode);
              else if (s3.tag !== 4 && s3.tag !== 27 && s3.child !== null) {
                s3.child.return = s3, s3 = s3.child;
                continue;
              }
              if (s3 === t3) break a;
              for (; s3.sibling === null; ) {
                if (s3.return === null || s3.return === t3) break a;
                s3 = s3.return;
              }
              s3.sibling.return = s3.return, s3 = s3.sibling;
            }
            t3.stateNode = o3;
            a: switch (np(o3, i3, r3), i3) {
              case `button`:
              case `input`:
              case `select`:
              case `textarea`:
                r3 = !!r3.autoFocus;
                break a;
              case `img`:
                r3 = true;
                break a;
              default:
                r3 = false;
            }
            r3 && vl(t3);
          }
        }
        return z(t3), t3.subtreeFlags &= -33554433, yl(t3, t3.type, e3 === null ? null : e3.memoizedProps, t3.pendingProps, n2), null;
      case 6:
        if (e3 && t3.stateNode != null) e3.memoizedProps !== r3 && vl(t3);
        else {
          if (typeof r3 != `string` && t3.stateNode === null) throw Error(a2(166));
          if (e3 = Pe.current, xa(t3)) {
            if (e3 = t3.stateNode, n2 = t3.memoizedProps, r3 = null, i3 = ma, i3 !== null) switch (i3.tag) {
              case 27:
              case 5:
                r3 = i3.memoizedProps;
            }
            e3[Pt] = t3, e3 = !!(e3.nodeValue === n2 || r3 !== null && true === r3.suppressHydrationWarning || ep(e3.nodeValue, n2)), e3 || va(t3, true);
          } else e3 = lp(e3).createTextNode(r3), e3[Pt] = t3, t3.stateNode = e3;
        }
        return z(t3), null;
      case 31:
        if (n2 = t3.memoizedState, e3 === null || e3.memoizedState !== null) {
          if (r3 = xa(t3), n2 !== null) {
            if (e3 === null) {
              if (!r3) throw Error(a2(318));
              if (e3 = t3.memoizedState, e3 = e3 === null ? null : e3.dehydrated, !e3) throw Error(a2(557));
              e3[Pt] = t3;
            } else Sa(), !(t3.flags & 128) && (t3.memoizedState = null), t3.flags |= 4;
            z(t3), e3 = false;
          } else n2 = Ca(), e3 !== null && e3.memoizedState !== null && (e3.memoizedState.hydrationErrors = n2), e3 = true;
          if (!e3) return t3.flags & 256 ? (Ko(t3), t3) : (Ko(t3), null);
          if (t3.flags & 128) throw Error(a2(558));
        }
        return z(t3), null;
      case 13:
        if (r3 = t3.memoizedState, e3 === null || e3.memoizedState !== null && e3.memoizedState.dehydrated !== null) {
          if (i3 = xa(t3), r3 !== null && r3.dehydrated !== null) {
            if (e3 === null) {
              if (!i3) throw Error(a2(318));
              if (i3 = t3.memoizedState, i3 = i3 === null ? null : i3.dehydrated, !i3) throw Error(a2(317));
              i3[Pt] = t3;
            } else Sa(), !(t3.flags & 128) && (t3.memoizedState = null), t3.flags |= 4;
            z(t3), i3 = false;
          } else i3 = Ca(), e3 !== null && e3.memoizedState !== null && (e3.memoizedState.hydrationErrors = i3), i3 = true;
          if (!i3) return t3.flags & 256 ? (Ko(t3), t3) : (Ko(t3), null);
        }
        return Ko(t3), t3.flags & 128 ? (t3.lanes = n2, t3) : (n2 = r3 !== null, e3 = e3 !== null && e3.memoizedState !== null, n2 && (r3 = t3.child, i3 = null, r3.alternate !== null && r3.alternate.memoizedState !== null && r3.alternate.memoizedState.cachePool !== null && (i3 = r3.alternate.memoizedState.cachePool.pool), o3 = null, r3.memoizedState !== null && r3.memoizedState.cachePool !== null && (o3 = r3.memoizedState.cachePool.pool), o3 !== i3 && (r3.flags |= 2048)), n2 !== e3 && n2 && (t3.child.flags |= 8192), xl(t3, t3.updateQueue), z(t3), null);
      case 4:
        return Le(), e3 === null && Wf(t3.stateNode.containerInfo), t3.flags |= 67108864, z(t3), null;
      case 10:
        return ka(t3.type), z(t3), null;
      case 19:
        if (Yo(t3), r3 = t3.memoizedState, r3 === null) return z(t3), null;
        if (i3 = !!(t3.flags & 128), o3 = r3.rendering, o3 === null) {
          if (i3) Sl(r3, false);
          else {
            if (Y !== 0 || e3 !== null && e3.flags & 128) for (e3 = t3.child; e3 !== null; ) {
              if (o3 = Xo(e3), o3 !== null) {
                for (t3.flags |= 128, Sl(r3, false), e3 = o3.updateQueue, t3.updateQueue = e3, xl(t3, e3), t3.subtreeFlags = 0, e3 = n2, n2 = t3.child; n2 !== null; ) Ki(n2, e3), n2 = n2.sibling;
                return Jo(t3, qo.current & 1 | 2), A && la(t3, r3.treeForkCount), t3.child;
              }
              e3 = e3.sibling;
            }
            r3.tail !== null && Qe() > _d && (t3.flags |= 128, i3 = true, Sl(r3, false), t3.lanes = 4194304);
          }
        } else {
          if (!i3) {
            if (e3 = Xo(o3), e3 !== null) {
              if (t3.flags |= 128, i3 = true, e3 = e3.updateQueue, t3.updateQueue = e3, xl(t3, e3), Sl(r3, true), r3.tail === null && r3.tailMode !== `collapsed` && r3.tailMode !== `visible` && !o3.alternate && !A) return z(t3), null;
            } else 2 * Qe() - r3.renderingStartTime > _d && n2 !== 536870912 && (t3.flags |= 128, i3 = true, Sl(r3, false), t3.lanes = 4194304);
          }
          r3.isBackwards ? (o3.sibling = t3.child, t3.child = o3) : (e3 = r3.last, e3 === null ? t3.child = o3 : e3.sibling = o3, r3.last = o3);
        }
        if (r3.tail !== null) {
          e3 = r3.tail;
          a: {
            for (n2 = e3; n2 !== null; ) {
              if (n2.alternate !== null) {
                n2 = false;
                break a;
              }
              n2 = n2.sibling;
            }
            n2 = true;
          }
          return r3.rendering = e3, r3.tail = e3.sibling, r3.renderingStartTime = Qe(), e3.sibling = null, o3 = qo.current, o3 = i3 ? o3 & 1 | 2 : o3 & 1, r3.tailMode === `visible` || r3.tailMode === `collapsed` || !n2 || A ? Jo(t3, o3) : (n2 = o3, E(Bo, t3), E(qo, n2), Vo === null && (Vo = t3)), A && la(t3, r3.treeForkCount), e3;
        }
        return z(t3), null;
      case 22:
      case 23:
        return Ko(t3), zo(), r3 = t3.memoizedState !== null, e3 === null ? r3 && (t3.flags |= 8192) : e3.memoizedState !== null !== r3 && (t3.flags |= 8192), r3 ? n2 & 536870912 && !(t3.flags & 128) && (z(t3), t3.subtreeFlags & 6 && (t3.flags |= 8192)) : z(t3), n2 = t3.updateQueue, n2 !== null && xl(t3, n2.retryQueue), n2 = null, e3 !== null && e3.memoizedState !== null && e3.memoizedState.cachePool !== null && (n2 = e3.memoizedState.cachePool.pool), r3 = null, t3.memoizedState !== null && t3.memoizedState.cachePool !== null && (r3 = t3.memoizedState.cachePool.pool), r3 !== n2 && (t3.flags |= 2048), e3 !== null && je(eo), null;
      case 24:
        return n2 = null, e3 !== null && (n2 = e3.memoizedState.cache), t3.memoizedState.cache !== n2 && (t3.flags |= 2048), ka(j), z(t3), null;
      case 25:
        return null;
      case 30:
        return t3.flags |= 33554432, z(t3), null;
    }
    throw Error(a2(156, t3.tag));
  }
  function wl(e3, t3) {
    switch (fa(t3), t3.tag) {
      case 1:
        return e3 = t3.flags, e3 & 65536 ? (t3.flags = e3 & -65537 | 128, t3) : null;
      case 3:
        return ka(j), Le(), e3 = t3.flags, e3 & 65536 && !(e3 & 128) ? (t3.flags = e3 & -65537 | 128, t3) : null;
      case 26:
      case 27:
      case 5:
        return ze(t3), null;
      case 31:
        if (t3.memoizedState !== null) {
          if (Ko(t3), t3.alternate === null) throw Error(a2(340));
          Sa();
        }
        return e3 = t3.flags, e3 & 65536 ? (t3.flags = e3 & -65537 | 128, t3) : null;
      case 13:
        if (Ko(t3), e3 = t3.memoizedState, e3 !== null && e3.dehydrated !== null) {
          if (t3.alternate === null) throw Error(a2(340));
          Sa();
        }
        return e3 = t3.flags, e3 & 65536 ? (t3.flags = e3 & -65537 | 128, t3) : null;
      case 19:
        return Yo(t3), e3 = t3.flags, e3 & 65536 ? (t3.flags = e3 & -65537 | 128, e3 = t3.memoizedState, e3 !== null && (e3.rendering = null, e3.tail = null), t3.flags |= 4, t3) : null;
      case 4:
        return Le(), null;
      case 10:
        return ka(t3.type), null;
      case 22:
      case 23:
        return Ko(t3), zo(), e3 !== null && je(eo), e3 = t3.flags, e3 & 65536 ? (t3.flags = e3 & -65537 | 128, t3) : null;
      case 24:
        return ka(j), null;
      case 25:
        return null;
      default:
        return null;
    }
  }
  function Tl(e3, t3) {
    switch (fa(t3), t3.tag) {
      case 3:
        ka(j), Le();
        break;
      case 26:
      case 27:
      case 5:
        ze(t3);
        break;
      case 4:
        Le();
        break;
      case 31:
        t3.memoizedState !== null && Ko(t3);
        break;
      case 13:
        Ko(t3);
        break;
      case 19:
        Yo(t3);
        break;
      case 10:
        ka(t3.type);
        break;
      case 22:
      case 23:
        Ko(t3), zo(), e3 !== null && je(eo);
        break;
      case 24:
        ka(j);
    }
  }
  function El(e3, t3) {
    try {
      var n2 = t3.updateQueue, r3 = n2 === null ? null : n2.lastEffect;
      if (r3 !== null) {
        var i3 = r3.next;
        n2 = i3;
        do {
          if ((n2.tag & e3) === e3) {
            r3 = void 0;
            var a3 = n2.create, o3 = n2.inst;
            r3 = a3(), o3.destroy = r3;
          }
          n2 = n2.next;
        } while (n2 !== i3);
      }
    } catch (e4) {
      Z(t3, t3.return, e4);
    }
  }
  function Dl(e3, t3, n2) {
    try {
      var r3 = t3.updateQueue, i3 = r3 === null ? null : r3.lastEffect;
      if (i3 !== null) {
        var a3 = i3.next;
        r3 = a3;
        do {
          if ((r3.tag & e3) === e3) {
            var o3 = r3.inst, s3 = o3.destroy;
            if (s3 !== void 0) {
              o3.destroy = void 0, i3 = t3;
              var c3 = n2, l3 = s3;
              try {
                l3();
              } catch (e4) {
                Z(i3, c3, e4);
              }
            }
          }
          r3 = r3.next;
        } while (r3 !== a3);
      }
    } catch (e4) {
      Z(t3, t3.return, e4);
    }
  }
  function Ol(e3) {
    var t3 = e3.updateQueue;
    if (t3 !== null) {
      var n2 = e3.stateNode;
      try {
        Po(t3, n2);
      } catch (t4) {
        Z(e3, e3.return, t4);
      }
    }
  }
  function kl(e3, t3, n2) {
    n2.props = kc(e3.type, e3.memoizedProps), n2.state = e3.memoizedState;
    try {
      n2.componentWillUnmount();
    } catch (n3) {
      Z(e3, t3, n3);
    }
  }
  function Al(e3, t3) {
    try {
      var n2 = e3.ref;
      if (n2 !== null) {
        switch (e3.tag) {
          case 26:
          case 27:
          case 5:
            var r3 = e3.stateNode;
            break;
          case 30:
            var i3 = e3.stateNode, a3 = Oi(e3.memoizedProps, i3);
            (i3.ref === null || i3.ref.name !== a3) && (i3.ref = Pp(a3)), r3 = i3.ref;
            break;
          case 7:
            if (e3.stateNode === null) {
              var o3 = new Fp(e3);
              p2(e3.child, false, Qp, o3, void 0, void 0), e3.stateNode = o3;
            }
            r3 = e3.stateNode;
            break;
          default:
            r3 = e3.stateNode;
        }
        typeof n2 == `function` ? e3.refCleanup = n2(r3) : n2.current = r3;
      }
    } catch (n3) {
      Z(e3, t3, n3);
    }
  }
  function jl(e3, t3) {
    var n2 = e3.ref, r3 = e3.refCleanup;
    if (n2 !== null) {
      if (typeof r3 == `function`) try {
        r3();
      } catch (n3) {
        Z(e3, t3, n3);
      } finally {
        e3.refCleanup = null, e3 = e3.alternate, e3 != null && (e3.refCleanup = null);
      }
      else if (typeof n2 == `function`) try {
        n2(null);
      } catch (n3) {
        Z(e3, t3, n3);
      }
      else n2.current = null;
    }
  }
  function Ml(e3, t3) {
    if ((e3.tag === 5 || e3.tag === 27 || e3.tag === 6) && e3.alternate === null && t3 !== null) for (var n2 = 0; n2 < t3.length; n2++) em(e3.stateNode, t3[n2]);
  }
  function Nl(e3) {
    for (var t3 = e3.return; t3 !== null && (Il(t3) && em(e3.stateNode, t3.stateNode), !Fl(t3)); ) t3 = t3.return;
  }
  function Pl(e3) {
    for (var t3 = e3.return; t3 !== null && (Il(t3) && tm(e3.stateNode, t3.stateNode), !Fl(t3)); ) t3 = t3.return;
  }
  function Fl(e3) {
    return e3.tag === 5 || e3.tag === 3 || e3.tag === 27;
  }
  function Il(e3) {
    return e3 && e3.tag === 7 && e3.stateNode !== null;
  }
  function Ll(e3) {
    var t3 = e3.type, n2 = e3.memoizedProps, r3 = e3.stateNode;
    try {
      a: switch (t3) {
        case `button`:
        case `input`:
        case `select`:
        case `textarea`:
          n2.autoFocus && r3.focus();
          break a;
        case `img`:
          n2.src ? r3.src = n2.src : n2.srcSet && (r3.srcset = n2.srcSet);
      }
    } catch (t4) {
      Z(e3, e3.return, t4);
    }
  }
  function Rl(e3, t3, n2) {
    try {
      var r3 = e3.stateNode;
      ip(r3, e3.type, n2, t3), r3[Ft] = t3;
    } catch (t4) {
      Z(e3, e3.return, t4);
    }
  }
  function zl(e3) {
    return e3.tag === 5 || e3.tag === 3 || e3.tag === 26 || e3.tag === 27 && Sp(e3.type) || e3.tag === 4;
  }
  function Bl(e3) {
    a: for (; ; ) {
      for (; e3.sibling === null; ) {
        if (e3.return === null || zl(e3.return)) return null;
        e3 = e3.return;
      }
      for (e3.sibling.return = e3.return, e3 = e3.sibling; e3.tag !== 5 && e3.tag !== 6 && e3.tag !== 18; ) {
        if (e3.tag === 27 && Sp(e3.type) || e3.flags & 2 || e3.child === null || e3.tag === 4) continue a;
        e3.child.return = e3, e3 = e3.child;
      }
      if (!(e3.flags & 2)) return e3.stateNode;
    }
  }
  function Vl(e3, t3, n2, r3) {
    var i3 = e3.tag;
    if (i3 === 5 || i3 === 6) i3 = e3.stateNode, t3 ? (n2.nodeType === 9 ? n2.body : n2.nodeName === `HTML` ? n2.ownerDocument.body : n2).insertBefore(i3, t3) : (t3 = n2.nodeType === 9 ? n2.body : n2.nodeName === `HTML` ? n2.ownerDocument.body : n2, t3.appendChild(i3), n2 = n2._reactRootContainer, n2 != null || t3.onclick !== null || (t3.onclick = kn)), Ml(e3, r3), O = true;
    else if (i3 !== 4 && (i3 === 27 && (Ml(e3, r3), r3 = null, Sp(e3.type) && (n2 = e3.stateNode, t3 = null)), e3 = e3.child, e3 !== null)) for (Vl(e3, t3, n2, r3), e3 = e3.sibling; e3 !== null; ) Vl(e3, t3, n2, r3), e3 = e3.sibling;
  }
  function Hl(e3, t3, n2, r3) {
    var i3 = e3.tag;
    if (i3 === 5 || i3 === 6) i3 = e3.stateNode, t3 ? n2.insertBefore(i3, t3) : n2.appendChild(i3), Ml(e3, r3), O = true;
    else if (i3 !== 4 && (i3 === 27 && (Ml(e3, r3), r3 = null, Sp(e3.type) && (n2 = e3.stateNode)), e3 = e3.child, e3 !== null)) for (Hl(e3, t3, n2, r3), e3 = e3.sibling; e3 !== null; ) Hl(e3, t3, n2, r3), e3 = e3.sibling;
  }
  function Ul(e3) {
    var t3 = e3.stateNode, n2 = e3.memoizedProps;
    try {
      for (var r3 = e3.type, i3 = t3.attributes; i3.length; ) t3.removeAttributeNode(i3[0]);
      np(t3, r3, n2), t3[Pt] = e3, t3[Ft] = n2;
    } catch (t4) {
      Z(e3, e3.return, t4);
    }
  }
  var Wl = false, Gl = null;
  function Kl(e3) {
    (e3.tag === 30 || e3.subtreeFlags & 33554432) && (Wl = true);
  }
  var ql = null;
  function Jl() {
    var e3 = ql;
    return ql = null, e3;
  }
  var Yl = 0;
  function Xl(e3, t3, n2, r3, i3) {
    return Yl = 0, Zl(e3.child, t3, n2, r3, i3);
  }
  function Zl(e3, t3, n2, r3, i3) {
    for (var a3 = false; e3 !== null; ) {
      if (e3.tag === 5) {
        var o3 = e3.stateNode;
        if (r3 !== null) {
          var s3 = Op(o3);
          r3.push(s3), s3.view && (a3 = true);
        } else a3 || Op(o3).view && (a3 = true);
        Wl = true, Tp(o3, Yl === 0 ? t3 : t3 + `_` + Yl, n2), Yl++;
      } else (e3.tag !== 22 || e3.memoizedState === null) && (e3.tag === 30 && i3 || Zl(e3.child, t3, n2, r3, i3) && (a3 = true));
      e3 = e3.sibling;
    }
    return a3;
  }
  function Ql(e3, t3) {
    for (; e3 !== null; ) e3.tag === 5 ? Ep(e3.stateNode, e3.memoizedProps) : (e3.tag !== 22 || e3.memoizedState === null) && (e3.tag === 30 && t3 || Ql(e3.child, t3)), e3 = e3.sibling;
  }
  function $l(e3) {
    if (e3.subtreeFlags & 18874368) for (e3 = e3.child; e3 !== null; ) {
      if ((e3.tag !== 22 || e3.memoizedState === null) && ($l(e3), e3.tag === 30 && e3.flags & 18874368 && e3.stateNode.paired)) {
        var t3 = e3.memoizedProps;
        if (t3.name == null || t3.name === `auto`) throw Error(a2(544));
        var n2 = t3.name;
        t3 = Ai(t3.default, t3.share), t3 !== `none` && (Xl(e3, n2, t3, null, false) || Ql(e3.child, false));
      }
      e3 = e3.sibling;
    }
  }
  function eu(e3, t3) {
    if (e3.tag === 30) {
      var n2 = e3.stateNode, r3 = e3.memoizedProps, i3 = Oi(r3, n2), a3 = Ai(r3.default, n2.paired ? r3.share : r3.enter);
      a3 === `none` ? $l(e3) : Xl(e3, i3, a3, null, false) ? ($l(e3), n2.paired || t3 || Nd(e3, r3.onEnter)) : Ql(e3.child, false);
    } else if (e3.subtreeFlags & 33554432) for (e3 = e3.child; e3 !== null; ) eu(e3, t3), e3 = e3.sibling;
    else $l(e3);
  }
  function tu(e3) {
    if (Gl !== null && Gl.size !== 0) {
      var t3 = Gl;
      if (e3.subtreeFlags & 18874368) for (e3 = e3.child; e3 !== null; ) {
        if (e3.tag !== 22 || e3.memoizedState === null) {
          if (e3.tag === 30 && e3.flags & 18874368) {
            var n2 = e3.memoizedProps, r3 = n2.name;
            if (r3 != null && r3 !== `auto`) {
              var i3 = t3.get(r3);
              if (i3 !== void 0) {
                var a3 = Ai(n2.default, n2.share);
                if (a3 !== `none` && (Xl(e3, r3, a3, null, false) ? (a3 = e3.stateNode, i3.paired = a3, a3.paired = i3, Nd(e3, n2.onShare)) : Ql(e3.child, false)), t3.delete(r3), t3.size === 0) break;
              }
            }
          }
          tu(e3);
        }
        e3 = e3.sibling;
      }
    }
  }
  function nu(e3) {
    if (e3.tag === 30) {
      var t3 = e3.memoizedProps, n2 = Oi(t3, e3.stateNode), r3 = Gl === null ? void 0 : Gl.get(n2), i3 = Ai(t3.default, r3 === void 0 ? t3.exit : t3.share);
      i3 !== `none` && (Xl(e3, n2, i3, null, false) ? r3 === void 0 ? Nd(e3, t3.onExit) : (i3 = e3.stateNode, r3.paired = i3, i3.paired = r3, Gl.delete(n2), Nd(e3, t3.onShare)) : Ql(e3.child, false)), Gl !== null && tu(e3);
    } else if (e3.subtreeFlags & 33554432) for (e3 = e3.child; e3 !== null; ) nu(e3), e3 = e3.sibling;
    else Gl !== null && tu(e3);
  }
  function ru(e3) {
    for (e3 = e3.child; e3 !== null; ) {
      if (e3.tag === 30) {
        var t3 = e3.memoizedProps, n2 = Oi(t3, e3.stateNode);
        t3 = Ai(t3.default, t3.update), e3.flags &= -5, t3 !== `none` && Xl(e3, n2, t3, e3.memoizedState = [], false);
      } else e3.subtreeFlags & 33554432 && ru(e3);
      e3 = e3.sibling;
    }
  }
  function iu(e3) {
    if (e3.subtreeFlags & 18874368) for (e3 = e3.child; e3 !== null; ) {
      if (e3.tag !== 22 || e3.memoizedState === null) {
        if (e3.tag === 30 && e3.flags & 18874368) {
          var t3 = e3.stateNode;
          t3.paired !== null && (t3.paired = null, Ql(e3.child, false));
        }
        iu(e3);
      }
      e3 = e3.sibling;
    }
  }
  function au(e3) {
    if (e3.tag === 30) e3.stateNode.paired = null, Ql(e3.child, false), iu(e3);
    else if (e3.subtreeFlags & 33554432) for (e3 = e3.child; e3 !== null; ) au(e3), e3 = e3.sibling;
    else iu(e3);
  }
  function ou(e3) {
    for (e3 = e3.child; e3 !== null; ) e3.tag === 30 ? Ql(e3.child, false) : e3.subtreeFlags & 33554432 && ou(e3), e3 = e3.sibling;
  }
  function su(e3, t3, n2, r3, i3, a3, o3) {
    for (var s3 = false; t3 !== null; ) {
      if (t3.tag === 5) {
        var c3 = t3.stateNode;
        if (a3 !== null && Yl < a3.length) {
          var l3 = a3[Yl], u3 = Op(c3);
          (l3.view || u3.view) && (s3 = true);
          var d3;
          if (d3 = !(e3.flags & 4)) {
            if (u3.clip) d3 = true;
            else {
              d3 = l3.rect;
              var f3 = u3.rect;
              d3 = d3.y !== f3.y || d3.x !== f3.x || d3.height !== f3.height || d3.width !== f3.width;
            }
          }
          d3 && (e3.flags |= 4), u3.abs ? u3 = !l3.abs : (l3 = l3.rect, u3 = u3.rect, u3 = l3.height !== u3.height || l3.width !== u3.width), u3 && (e3.flags |= 32);
        } else e3.flags |= 32;
        e3.flags & 4 && Tp(c3, Yl === 0 ? n2 : n2 + `_` + Yl, i3), s3 && e3.flags & 4 || (ql === null && (ql = []), ql.push(c3, Yl === 0 ? r3 : r3 + `_` + Yl, t3.memoizedProps)), Yl++;
      } else (t3.tag !== 22 || t3.memoizedState === null) && (t3.tag === 30 && o3 ? e3.flags |= t3.flags & 32 : su(e3, t3.child, n2, r3, i3, a3, o3) && (s3 = true));
      t3 = t3.sibling;
    }
    return s3;
  }
  function cu(e3, t3) {
    for (e3 = e3.child; e3 !== null; ) {
      if (e3.tag === 30) {
        var n2 = e3.memoizedProps, r3 = e3.stateNode, i3 = Oi(n2, r3), a3 = Ai(n2.default, n2.update);
        if (t3) {
          r3 = r3.clones;
          var o3 = r3 === null ? null : r3.map(kp);
        } else o3 = e3.memoizedState, e3.memoizedState = null;
        r3 = e3;
        var s3 = e3.child;
        Yl = 0, i3 = su(r3, s3, i3, i3, a3, o3, false), e3.flags & 4 && i3 && (t3 || Nd(e3, n2.onUpdate));
      } else e3.subtreeFlags & 33554432 && cu(e3, t3);
      e3 = e3.sibling;
    }
  }
  var B = false, V = false, lu = false, uu = false, du = typeof WeakSet == `function` ? WeakSet : Set, H = null, fu = false, pu = false, mu = false, hu = false;
  function gu(e3, t3, n2) {
    if (e3 = e3.containerInfo, sp = gh, e3 = ii(e3), ai(e3)) {
      if (`selectionStart` in e3) var r3 = { start: e3.selectionStart, end: e3.selectionEnd };
      else a: {
        r3 = (r3 = e3.ownerDocument) && r3.defaultView || window;
        var i3 = r3.getSelection && r3.getSelection();
        if (i3 && i3.rangeCount !== 0) {
          r3 = i3.anchorNode;
          var a3 = i3.anchorOffset, o3 = i3.focusNode;
          i3 = i3.focusOffset;
          try {
            r3.nodeType, o3.nodeType;
          } catch {
            r3 = null;
            break a;
          }
          var s3 = 0, c3 = -1, l3 = -1, u3 = 0, d3 = 0, f3 = e3, p3 = null;
          b: for (; ; ) {
            for (var m3; f3 !== r3 || a3 !== 0 && f3.nodeType !== 3 || (c3 = s3 + a3), f3 !== o3 || i3 !== 0 && f3.nodeType !== 3 || (l3 = s3 + i3), f3.nodeType === 3 && (s3 += f3.nodeValue.length), (m3 = f3.firstChild) !== null; ) p3 = f3, f3 = m3;
            for (; ; ) {
              if (f3 === e3) break b;
              if (p3 === r3 && ++u3 === a3 && (c3 = s3), p3 === o3 && ++d3 === i3 && (l3 = s3), (m3 = f3.nextSibling) !== null) break;
              f3 = p3, p3 = f3.parentNode;
            }
            f3 = m3;
          }
          r3 = c3 === -1 || l3 === -1 ? null : { start: c3, end: l3 };
        } else r3 = null;
      }
      r3 ||= { start: 0, end: 0 };
    } else r3 = null;
    for (cp = { focusedElem: e3, selectionRange: r3 }, gh = false, n2 = (n2 & 335544064) === n2, H = t3, t3 = n2 ? 9270 : 1024; H !== null; ) {
      if (e3 = H, n2 && (r3 = e3.deletions, r3 !== null)) for (a3 = 0; a3 < r3.length; a3++) n2 && nu(r3[a3]);
      if (e3.alternate === null && e3.flags & 2) n2 && Kl(e3), _u(n2);
      else {
        if (e3.tag === 22) {
          if (r3 = e3.alternate, e3.memoizedState !== null) {
            r3 !== null && r3.memoizedState === null && n2 && nu(r3), _u(n2);
            continue;
          }
          if (r3 !== null && r3.memoizedState !== null) {
            n2 && Kl(e3), _u(n2);
            continue;
          }
        }
        r3 = e3.child, (e3.subtreeFlags & t3) !== 0 && r3 !== null ? (r3.return = e3, H = r3) : (n2 && ru(e3), _u(n2));
      }
    }
    Gl = null;
  }
  function _u(e3) {
    for (; H !== null; ) {
      var t3 = H, n2 = e3, r3 = t3.alternate, i3 = t3.flags;
      switch (t3.tag) {
        case 0:
        case 11:
        case 15:
          break;
        case 1:
          if (i3 & 1024 && r3 !== null) {
            n2 = void 0, i3 = r3.memoizedProps, r3 = r3.memoizedState;
            var o3 = t3.stateNode;
            try {
              var s3 = kc(t3.type, i3);
              n2 = o3.getSnapshotBeforeUpdate(s3, r3), o3.__reactInternalSnapshotBeforeUpdate = n2;
            } catch (e4) {
              Z(t3, t3.return, e4);
            }
          }
          break;
        case 3:
          if (i3 & 1024) {
            if (r3 = t3.stateNode.containerInfo, n2 = r3.nodeType, n2 === 9) nm(r3);
            else if (n2 === 1) switch (r3.nodeName) {
              case `HEAD`:
              case `HTML`:
              case `BODY`:
                nm(r3);
                break;
              default:
                r3.textContent = ``;
            }
          }
          break;
        case 5:
        case 26:
        case 27:
        case 6:
        case 4:
        case 17:
          break;
        case 30:
          n2 && r3 !== null && (n2 = Oi(r3.memoizedProps, r3.stateNode), i3 = t3.memoizedProps, i3 = Ai(i3.default, i3.update), i3 !== `none` && Xl(r3, n2, i3, r3.memoizedState = [], true));
          break;
        default:
          if (i3 & 1024) throw Error(a2(163));
      }
      if (r3 = t3.sibling, r3 !== null) {
        r3.return = t3.return, H = r3;
        break;
      }
      H = t3.return;
    }
  }
  function vu(e3, t3, n2) {
    var r3 = n2.flags;
    switch (n2.tag) {
      case 0:
      case 11:
      case 15:
        Lu(e3, n2), r3 & 4 && El(5, n2);
        break;
      case 1:
        if (Lu(e3, n2), r3 & 4) {
          if (e3 = n2.stateNode, t3 === null) try {
            e3.componentDidMount();
          } catch (e4) {
            Z(n2, n2.return, e4);
          }
          else {
            var i3 = kc(n2.type, t3.memoizedProps);
            t3 = t3.memoizedState;
            try {
              e3.componentDidUpdate(i3, t3, e3.__reactInternalSnapshotBeforeUpdate);
            } catch (e4) {
              Z(n2, n2.return, e4);
            }
          }
        }
        r3 & 64 && Ol(n2), r3 & 512 && Al(n2, n2.return);
        break;
      case 3:
        if (Lu(e3, n2), r3 & 64 && (e3 = n2.updateQueue, e3 !== null)) {
          if (t3 = null, n2.child !== null) switch (n2.child.tag) {
            case 27:
            case 5:
              t3 = n2.child.stateNode;
              break;
            case 1:
              t3 = n2.child.stateNode;
          }
          try {
            Po(e3, t3);
          } catch (e4) {
            Z(n2, n2.return, e4);
          }
        }
        break;
      case 27:
        t3 === null && r3 & 4 && Ul(n2);
      case 26:
      case 5:
        Lu(e3, n2), t3 === null && r3 & 4 && Ll(n2), r3 & 512 && Al(n2, n2.return);
        break;
      case 12:
        Lu(e3, n2);
        break;
      case 31:
        Lu(e3, n2), r3 & 4 && Eu(e3, n2);
        break;
      case 13:
        Lu(e3, n2), r3 & 4 && Du(e3, n2), r3 & 64 && (e3 = n2.memoizedState, e3 !== null && (e3 = e3.dehydrated, e3 !== null && (n2 = _f.bind(null, n2), cm(e3, n2))));
        break;
      case 22:
        if (r3 = n2.memoizedState !== null || B, !r3) {
          var a3 = t3 !== null && t3.memoizedState !== null || V;
          t3 = B, i3 = V, B = r3, (V = a3) && !i3 ? (r3 = 2, n2.subtreeFlags & 8772 && (r3 |= 1), zu(e3, n2, r3)) : Lu(e3, n2), B = t3, V = i3;
        }
        break;
      case 30:
        Lu(e3, n2), r3 & 512 && Al(n2, n2.return);
        break;
      case 7:
        r3 & 512 && Al(n2, n2.return);
      default:
        Lu(e3, n2);
    }
  }
  function yu(e3, t3) {
    for (e3 = e3.child; e3 !== null; ) bu(e3, t3), e3 = e3.sibling;
  }
  function bu(e3, t3) {
    switch (e3.tag) {
      case 5:
      case 26:
        try {
          var n2 = e3.stateNode;
          if (t3) {
            var r3 = n2.style;
            typeof r3.setProperty == `function` ? r3.setProperty(`display`, `none`, `important`) : r3.display = `none`;
          } else {
            var i3 = e3.stateNode, a3 = e3.memoizedProps.style, o3 = a3 != null && a3.hasOwnProperty(`display`) ? a3.display : null;
            i3.style.display = o3 == null || typeof o3 == `boolean` ? `` : (`` + o3).trim();
          }
        } catch (t4) {
          Z(e3, e3.return, t4);
        }
        xu(e3, t3);
        break;
      case 6:
        try {
          e3.stateNode.nodeValue = t3 ? `` : e3.memoizedProps, O = true;
        } catch (t4) {
          Z(e3, e3.return, t4);
        }
        break;
      case 18:
        try {
          var s3 = e3.stateNode;
          t3 ? wp(s3, true) : wp(e3.stateNode, false);
        } catch (t4) {
          Z(e3, e3.return, t4);
        }
        break;
      case 22:
      case 23:
        e3.memoizedState === null && yu(e3, t3);
        break;
      default:
        yu(e3, t3);
    }
  }
  function xu(e3, t3) {
    if (e3.subtreeFlags & 67108864) for (e3 = e3.child; e3 !== null; ) {
      a: {
        var n2 = e3, r3 = t3;
        switch (n2.tag) {
          case 4:
            bu(n2, r3);
            break a;
          case 22:
            n2.memoizedState === null && xu(n2, r3);
            break a;
          default:
            xu(n2, r3);
        }
      }
      e3 = e3.sibling;
    }
  }
  function Su(e3) {
    var t3 = e3.alternate;
    t3 !== null && (e3.alternate = null, Su(t3)), e3.child = null, e3.deletions = null, e3.sibling = null, e3.tag === 5 && (t3 = e3.stateNode, t3 !== null && Ut(t3)), e3.stateNode = null, e3.return = null, e3.dependencies = null, e3.memoizedProps = null, e3.memoizedState = null, e3.pendingProps = null, e3.stateNode = null, e3.updateQueue = null;
  }
  var U = null, Cu = false;
  function wu(e3, t3, n2) {
    for (n2 = n2.child; n2 !== null; ) Tu(e3, t3, n2), n2 = n2.sibling;
  }
  function Tu(e3, t3, n2) {
    if (ct && typeof ct.onCommitFiberUnmount == `function`) try {
      ct.onCommitFiberUnmount(st, n2);
    } catch {
    }
    switch (n2.tag) {
      case 26:
        V || jl(n2, t3), wu(e3, t3, n2), n2.memoizedState ? n2.memoizedState.count-- : n2.stateNode && !V && (n2 = n2.stateNode, n2.parentNode.removeChild(n2));
        break;
      case 27:
        V || jl(n2, t3), Pl(n2);
        var r3 = U, i3 = Cu;
        Sp(n2.type) && (U = n2.stateNode, Cu = false), wu(e3, t3, n2), gm(n2.stateNode, n2.type, n2.memoizedProps), U = r3, Cu = i3;
        break;
      case 5:
        V || jl(n2, t3), Pl(n2);
      case 6:
        if (n2.tag === 6 && Pl(n2), r3 = U, i3 = Cu, U = null, wu(e3, t3, n2), U = r3, Cu = i3, U !== null) {
          if (Cu) try {
            (U.nodeType === 9 ? U.body : U.nodeName === `HTML` ? U.ownerDocument.body : U).removeChild(n2.stateNode), O = true;
          } catch (e4) {
            Z(n2, t3, e4);
          }
          else try {
            U.removeChild(n2.stateNode), O = true;
          } catch (e4) {
            Z(n2, t3, e4);
          }
        }
        break;
      case 18:
        U !== null && (Cu ? (e3 = U, Cp(e3.nodeType === 9 ? e3.body : e3.nodeName === `HTML` ? e3.ownerDocument.body : e3, n2.stateNode), Hh(e3)) : Cp(U, n2.stateNode));
        break;
      case 4:
        r3 = U, i3 = Cu, U = n2.stateNode.containerInfo, Cu = true, wu(e3, t3, n2), U = r3, Cu = i3;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        Dl(2, n2, t3), V || Dl(4, n2, t3), wu(e3, t3, n2);
        break;
      case 1:
        V || (jl(n2, t3), r3 = n2.stateNode, typeof r3.componentWillUnmount == `function` && kl(n2, t3, r3)), wu(e3, t3, n2);
        break;
      case 21:
        wu(e3, t3, n2);
        break;
      case 22:
        V = (r3 = V) || n2.memoizedState !== null, wu(e3, t3, n2), V = r3;
        break;
      case 30:
        jl(n2, t3), wu(e3, t3, n2);
        break;
      case 7:
        V || jl(n2, t3), wu(e3, t3, n2);
        break;
      default:
        wu(e3, t3, n2);
    }
  }
  function Eu(e3, t3) {
    if (t3.memoizedState === null && (e3 = t3.alternate, e3 !== null && (e3 = e3.memoizedState, e3 !== null))) {
      e3 = e3.dehydrated;
      try {
        Hh(e3);
      } catch (e4) {
        Z(t3, t3.return, e4);
      }
    }
  }
  function Du(e3, t3) {
    if (t3.memoizedState === null && (e3 = t3.alternate, e3 !== null && (e3 = e3.memoizedState, e3 !== null && (e3 = e3.dehydrated, e3 !== null)))) try {
      Hh(e3);
    } catch (e4) {
      Z(t3, t3.return, e4);
    }
  }
  function Ou(e3) {
    switch (e3.tag) {
      case 31:
      case 13:
      case 19:
        var t3 = e3.stateNode;
        return t3 === null && (t3 = e3.stateNode = new du()), t3;
      case 22:
        return e3 = e3.stateNode, t3 = e3._retryCache, t3 === null && (t3 = e3._retryCache = new du()), t3;
      default:
        throw Error(a2(435, e3.tag));
    }
  }
  function ku(e3, t3) {
    var n2 = Ou(e3);
    t3.forEach(function(t4) {
      if (!n2.has(t4)) {
        n2.add(t4);
        var r3 = vf.bind(null, e3, t4);
        t4.then(r3, r3);
      }
    });
  }
  function Au(e3, t3, n2) {
    var r3 = t3.deletions;
    if (r3 !== null) for (var i3 = 0; i3 < r3.length; i3++) {
      var o3 = r3[i3], s3 = e3, c3 = t3, l3 = c3;
      a: for (; l3 !== null; ) {
        switch (l3.tag) {
          case 27:
            if (Sp(l3.type)) {
              U = l3.stateNode, Cu = false;
              break a;
            }
            break;
          case 5:
            U = l3.stateNode, Cu = false;
            break a;
          case 3:
          case 4:
            U = l3.stateNode.containerInfo, Cu = true;
            break a;
        }
        l3 = l3.return;
      }
      if (U === null) throw Error(a2(160));
      Tu(s3, c3, o3), U = null, Cu = false, s3 = o3.alternate, s3 !== null && (s3.return = null), o3.return = null;
    }
    if (t3.subtreeFlags & 13886) for (t3 = t3.child; t3 !== null; ) Mu(t3, e3, n2), t3 = t3.sibling;
  }
  var ju = null;
  function Mu(e3, t3, n2) {
    var r3 = e3.alternate, i3 = e3.flags;
    switch (e3.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        if (i3 & 4 && (r3 = e3.updateQueue, r3 = r3 === null ? null : r3.events, r3 !== null)) for (var o3 = 0; o3 < r3.length; o3++) {
          var s3 = r3[o3];
          s3.ref.impl = s3.nextImpl;
        }
        Au(t3, e3, n2), Nu(e3), i3 & 4 && (Dl(3, e3, e3.return), El(3, e3), Dl(5, e3, e3.return));
        break;
      case 1:
        Au(t3, e3, n2), Nu(e3), i3 & 512 && (V || r3 === null || jl(r3, r3.return)), i3 & 64 && B && (e3 = e3.updateQueue, e3 !== null && (t3 = e3.callbacks, t3 !== null && (n2 = e3.shared.hiddenCallbacks, e3.shared.hiddenCallbacks = n2 === null ? t3 : n2.concat(t3))));
        break;
      case 26:
        if (o3 = ju, Au(t3, e3, n2), Nu(e3), i3 & 512 && (V || r3 === null || jl(r3, r3.return)), i3 & 4) {
          if (i3 = r3 === null ? null : r3.memoizedState, n2 = e3.memoizedState, r3 === null) {
            if (n2 === null) {
              if (e3.stateNode === null) {
                if (B) e3.stateNode = fp(e3.type, e3.memoizedProps, t3.containerInfo, e3);
                else {
                  a: {
                    t3 = e3.type, n2 = e3.memoizedProps, i3 = o3.ownerDocument || o3;
                    b: switch (t3) {
                      case `title`:
                        r3 = i3.getElementsByTagName(`title`)[0], (!r3 || r3[Vt] || r3[Pt] || r3.namespaceURI === `http://www.w3.org/2000/svg` || r3.hasAttribute(`itemprop`)) && (r3 = i3.createElement(t3), i3.head.insertBefore(r3, i3.querySelector(`head > title`))), np(r3, t3, n2), r3[Pt] = e3, D(r3), t3 = r3;
                        break a;
                      case `link`:
                        if (o3 = Gm(`link`, `href`, i3).get(t3 + (n2.href || ``))) {
                          for (s3 = 0; s3 < o3.length; s3++) if (r3 = o3[s3], r3.getAttribute(`href`) === (n2.href == null || n2.href === `` ? null : n2.href) && r3.getAttribute(`rel`) === (n2.rel == null ? null : n2.rel) && r3.getAttribute(`title`) === (n2.title == null ? null : n2.title) && r3.getAttribute(`crossorigin`) === (n2.crossOrigin == null ? null : n2.crossOrigin)) {
                            o3.splice(s3, 1);
                            break b;
                          }
                        }
                        r3 = i3.createElement(t3), np(r3, t3, n2), i3.head.appendChild(r3);
                        break;
                      case `meta`:
                        if (o3 = Gm(`meta`, `content`, i3).get(t3 + (n2.content || ``))) {
                          for (s3 = 0; s3 < o3.length; s3++) if (r3 = o3[s3], r3.getAttribute(`content`) === (n2.content == null ? null : `` + n2.content) && r3.getAttribute(`name`) === (n2.name == null ? null : n2.name) && r3.getAttribute(`property`) === (n2.property == null ? null : n2.property) && r3.getAttribute(`http-equiv`) === (n2.httpEquiv == null ? null : n2.httpEquiv) && r3.getAttribute(`charset`) === (n2.charSet == null ? null : n2.charSet)) {
                            o3.splice(s3, 1);
                            break b;
                          }
                        }
                        r3 = i3.createElement(t3), np(r3, t3, n2), i3.head.appendChild(r3);
                        break;
                      default:
                        throw Error(a2(468, t3));
                    }
                    r3[Pt] = e3, D(r3), t3 = r3;
                  }
                  e3.stateNode = t3;
                }
              } else B || Km(o3, e3.type, e3.stateNode);
            } else e3.stateNode = Bm(o3, n2, e3.memoizedProps);
          } else i3 === n2 ? n2 === null && e3.stateNode !== null && Rl(e3, e3.memoizedProps, r3.memoizedProps) : (i3 === null ? (t3 = r3.stateNode, t3 === null || V || t3.parentNode.removeChild(t3)) : i3.count--, n2 === null ? B || Km(o3, e3.type, e3.stateNode) : Bm(o3, n2, e3.memoizedProps));
        }
        break;
      case 27:
        Au(t3, e3, n2), Nu(e3), i3 & 512 && (V || r3 === null || jl(r3, r3.return)), r3 !== null && i3 & 4 && Rl(e3, e3.memoizedProps, r3.memoizedProps);
        break;
      case 5:
        if (o3 = lu, lu = false, Au(t3, e3, n2), lu = o3, Nu(e3), i3 & 512 && (V || r3 === null || jl(r3, r3.return)), e3.flags & 32) {
          t3 = e3.stateNode;
          try {
            xn(t3, ``), O = true;
          } catch (t4) {
            Z(e3, e3.return, t4);
          }
        }
        i3 & 4 && e3.stateNode != null && (t3 = e3.memoizedProps, Rl(e3, t3, r3 === null ? t3 : r3.memoizedProps)), i3 & 1024 && (uu = true);
        break;
      case 6:
        if (Au(t3, e3, n2), Nu(e3), i3 & 4) {
          if (e3.stateNode === null) throw Error(a2(162));
          t3 = e3.memoizedProps, n2 = e3.stateNode;
          try {
            n2.nodeValue = t3, O = true;
          } catch (t4) {
            Z(e3, e3.return, t4);
          }
        }
        break;
      case 3:
        if (O = false, Wm = null, o3 = ju, ju = bm(t3.containerInfo), Au(t3, e3, n2), ju = o3, Nu(e3), i3 & 4 && r3 !== null && r3.memoizedState.isDehydrated) try {
          Hh(t3.containerInfo);
        } catch (t4) {
          Z(e3, e3.return, t4);
        }
        uu && (uu = false, Pu(e3)), O = false;
        break;
      case 4:
        i3 = lu, lu = B, r3 = rn(), o3 = ju, ju = bm(e3.stateNode.containerInfo), Au(t3, e3, n2), Nu(e3), ju = o3, O && pu && (mu = true), O = r3, lu = i3;
        break;
      case 12:
        Au(t3, e3, n2), Nu(e3);
        break;
      case 31:
        Au(t3, e3, n2), Nu(e3), i3 & 4 && (t3 = e3.updateQueue, t3 !== null && (e3.updateQueue = null, ku(e3, t3)));
        break;
      case 13:
        Au(t3, e3, n2), Nu(e3), e3.child.flags & 8192 && e3.memoizedState !== null != (r3 !== null && r3.memoizedState !== null) && (hd = Qe()), i3 & 4 && (t3 = e3.updateQueue, t3 !== null && (e3.updateQueue = null, ku(e3, t3)));
        break;
      case 22:
        o3 = e3.memoizedState !== null, s3 = r3 !== null && r3.memoizedState !== null;
        var c3 = B, l3 = V, u3 = lu;
        B = c3 || o3, lu = u3 || o3, V = l3 || s3, Au(t3, e3, n2), V = l3, lu = u3, B = c3, Nu(e3), i3 & 8192 && (t3 = e3.stateNode, t3._visibility = o3 ? t3._visibility & -2 : t3._visibility | 1, !o3 || r3 === null || s3 || B || V || (t3 = s3 || V, n2 = B, r3 = V, B = o3 || B, V = t3, Ru(e3, 2), B = n2, V = r3), !o3 && lu || yu(e3, o3)), i3 & 4 && (t3 = e3.updateQueue, t3 !== null && (n2 = t3.retryQueue, n2 !== null && (t3.retryQueue = null, ku(e3, n2))));
        break;
      case 19:
        Au(t3, e3, n2), Nu(e3), i3 & 4 && (t3 = e3.updateQueue, t3 !== null && (e3.updateQueue = null, ku(e3, t3)));
        break;
      case 30:
        i3 & 512 && (V || r3 === null || jl(r3, r3.return)), i3 = rn(), o3 = pu, s3 = (n2 & 335544064) === n2, c3 = e3.memoizedProps, pu = s3 && Ai(c3.default, c3.update) !== `none`, Au(t3, e3, n2), Nu(e3), s3 && r3 !== null && O && (e3.flags |= 4), pu = o3, O = i3;
        break;
      case 21:
        break;
      case 7:
        i3 & 512 && (V || r3 === null || jl(r3, r3.return)), r3 && r3.stateNode !== null && (r3.stateNode._fragmentFiber = e3);
      default:
        Au(t3, e3, n2), Nu(e3);
    }
  }
  function Nu(e3) {
    var t3 = e3.flags;
    if (t3 & 2) {
      try {
        for (var n2, r3 = e3.return; r3 !== null; ) {
          if (zl(r3)) {
            n2 = r3;
            break;
          }
          r3 = r3.return;
        }
        r3 = null;
        for (var i3 = e3.return; i3 !== null; ) {
          if (Il(i3)) {
            var o3 = i3.stateNode;
            r3 === null ? r3 = [o3] : r3.push(o3);
          }
          if (Fl(i3)) break;
          i3 = i3.return;
        }
        var s3 = r3;
        if (n2 == null) throw Error(a2(160));
        switch (n2.tag) {
          case 27:
            var c3 = n2.stateNode;
            Hl(e3, Bl(e3), c3, s3);
            break;
          case 5:
            var l3 = n2.stateNode;
            n2.flags & 32 && (xn(l3, ``), n2.flags &= -33), Hl(e3, Bl(e3), l3, s3);
            break;
          case 3:
          case 4:
            var u3 = n2.stateNode.containerInfo;
            Vl(e3, Bl(e3), u3, s3);
            break;
          default:
            throw Error(a2(161));
        }
      } catch (t4) {
        Z(e3, e3.return, t4);
      }
      e3.flags &= -3;
    }
    t3 & 4096 && (e3.flags &= -4097);
  }
  function Pu(e3) {
    if (e3.subtreeFlags & 1024) for (e3 = e3.child; e3 !== null; ) {
      var t3 = e3;
      Pu(t3), t3.tag === 5 && t3.flags & 1024 && (t3 = t3.stateNode, gh = true, t3.reset(), gh = false), e3 = e3.sibling;
    }
  }
  function Fu(e3, t3) {
    if (t3.subtreeFlags & 9270) for (t3 = t3.child; t3 !== null; ) Iu(t3, e3), t3 = t3.sibling;
    else cu(t3, false);
  }
  function Iu(e3, t3) {
    var n2 = e3.alternate;
    if (n2 === null) eu(e3, false);
    else switch (e3.tag) {
      case 3:
        if (hu = fu = false, Jl(), Fu(t3, e3), !fu && !mu) {
          if (e3 = ql, e3 !== null) for (var r3 = 0; r3 < e3.length; r3 += 3) {
            n2 = e3[r3];
            var i3 = e3[r3 + 1];
            Ep(n2, e3[r3 + 2]), n2 = n2.ownerDocument.documentElement, n2 !== null && n2.animate({ opacity: [0, 0], pointerEvents: [`none`, `none`] }, { duration: 0, fill: `forwards`, pseudoElement: `::view-transition-group(` + i3 + `)` });
          }
          e3 = t3.containerInfo, e3 = e3.nodeType === 9 ? e3.documentElement : e3.ownerDocument.documentElement, e3 !== null && e3.style.viewTransitionName === `` && (e3.style.viewTransitionName = `none`, e3.animate({ opacity: [0, 0], pointerEvents: [`none`, `none`] }, { duration: 0, fill: `forwards`, pseudoElement: `::view-transition-group(root)` }), e3.animate({ width: [0, 0], height: [0, 0] }, { duration: 0, fill: `forwards`, pseudoElement: `::view-transition` })), hu = true;
        }
        ql = null;
        break;
      case 5:
        Fu(t3, e3);
        break;
      case 4:
        r3 = fu, fu = false, Fu(t3, e3), fu && (mu = true), fu = r3;
        break;
      case 22:
        e3.memoizedState === null && (n2.memoizedState === null ? Fu(t3, e3) : eu(e3, false));
        break;
      case 30:
        r3 = fu, i3 = Jl(), fu = false, Fu(t3, e3), fu && (e3.flags |= 4);
        var a3 = e3.memoizedProps, o3 = e3.stateNode;
        t3 = Oi(a3, o3), o3 = Oi(n2.memoizedProps, o3);
        var s3 = Ai(a3.default, a3.update);
        s3 === `none` ? t3 = false : (a3 = n2.memoizedState, n2.memoizedState = null, n2 = e3.child, Yl = 0, t3 = su(e3, n2, t3, o3, s3, a3, true), Yl !== (a3 === null ? 0 : a3.length) && (e3.flags |= 32)), e3.flags & 4 && t3 ? (Nd(e3, e3.memoizedProps.onUpdate), ql = i3) : i3 !== null && (i3.push.apply(i3, ql), ql = i3), fu = e3.flags & 32 ? true : r3;
        break;
      default:
        Fu(t3, e3);
    }
  }
  function Lu(e3, t3) {
    if (t3.subtreeFlags & 8772) for (t3 = t3.child; t3 !== null; ) vu(e3, t3.alternate, t3), t3 = t3.sibling;
  }
  function Ru(e3, t3) {
    for (e3 = e3.child; e3 !== null; ) {
      var n2 = e3, r3 = t3;
      switch (n2.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          Dl(4, n2, n2.return), Ru(n2, r3);
          break;
        case 1:
          jl(n2, n2.return);
          var i3 = n2.stateNode;
          typeof i3.componentWillUnmount == `function` && kl(n2, n2.return, i3), Ru(n2, r3);
          break;
        case 27:
          r3 & 2 && gm(n2.stateNode, n2.type, n2.memoizedProps);
        case 5:
          jl(n2, n2.return), n2.tag !== 5 && n2.tag !== 27 || Pl(n2), Ru(n2, r3);
          break;
        case 6:
          Pl(n2);
          break;
        case 26:
          jl(n2, n2.return), i3 = n2.stateNode, n2.memoizedState !== null || i3 === null || V || i3.parentNode.removeChild(i3), Ru(n2, r3);
          break;
        case 22:
          n2.memoizedState === null && Ru(n2, r3);
          break;
        case 30:
          jl(n2, n2.return), Ru(n2, r3);
          break;
        case 7:
          jl(n2, n2.return);
        default:
          Ru(n2, r3);
      }
      e3 = e3.sibling;
    }
  }
  function zu(e3, t3, n2) {
    for (n2 = t3.subtreeFlags & 8772 ? n2 : n2 & -2, t3 = t3.child; t3 !== null; ) {
      var r3 = t3.alternate, i3 = e3, a3 = t3, o3 = a3.flags, s3 = !!(n2 & 1);
      switch (a3.tag) {
        case 0:
        case 11:
        case 15:
          zu(i3, a3, n2), El(4, a3);
          break;
        case 1:
          if (zu(i3, a3, n2), r3 = a3, i3 = r3.stateNode, typeof i3.componentDidMount == `function`) try {
            i3.componentDidMount();
          } catch (e4) {
            Z(r3, r3.return, e4);
          }
          if (r3 = a3, i3 = r3.updateQueue, i3 !== null) {
            var c3 = r3.stateNode;
            try {
              var l3 = i3.shared.hiddenCallbacks;
              if (l3 !== null) for (i3.shared.hiddenCallbacks = null, i3 = 0; i3 < l3.length; i3++) No(l3[i3], c3);
            } catch (e4) {
              Z(r3, r3.return, e4);
            }
          }
          s3 && o3 & 64 && Ol(a3), Al(a3, a3.return);
          break;
        case 27:
          n2 & 2 && Ul(a3);
        case 5:
          a3.tag !== 5 && a3.tag !== 27 || Nl(a3), zu(i3, a3, n2), s3 && r3 === null && o3 & 4 && Ll(a3), Al(a3, a3.return);
          break;
        case 6:
          Nl(a3);
          break;
        case 26:
          c3 = a3.stateNode, a3.memoizedState !== null || c3 === null || B || Km(bm(c3.ownerDocument), a3.type, c3), zu(i3, a3, n2), s3 && r3 === null && o3 & 4 && Ll(a3), Al(a3, a3.return);
          break;
        case 12:
          zu(i3, a3, n2);
          break;
        case 31:
          zu(i3, a3, n2), s3 && o3 & 4 && Eu(i3, a3);
          break;
        case 13:
          zu(i3, a3, n2), s3 && o3 & 4 && Du(i3, a3);
          break;
        case 22:
          a3.memoizedState === null && zu(i3, a3, n2), Al(a3, a3.return);
          break;
        case 30:
          zu(i3, a3, n2), Al(a3, a3.return);
          break;
        case 7:
          Al(a3, a3.return);
        default:
          zu(i3, a3, n2);
      }
      t3 = t3.sibling;
    }
  }
  function Bu(e3, t3) {
    var n2 = null;
    e3 !== null && e3.memoizedState !== null && e3.memoizedState.cachePool !== null && (n2 = e3.memoizedState.cachePool.pool), e3 = null, t3.memoizedState !== null && t3.memoizedState.cachePool !== null && (e3 = t3.memoizedState.cachePool.pool), e3 !== n2 && (e3 != null && e3.refCount++, n2 != null && Ha(n2));
  }
  function Vu(e3, t3) {
    e3 = null, t3.alternate !== null && (e3 = t3.alternate.memoizedState.cache), t3 = t3.memoizedState.cache, t3 !== e3 && (t3.refCount++, e3 != null && Ha(e3));
  }
  function Hu(e3, t3, n2, r3) {
    var i3 = (n2 & 335544064) === n2;
    if (t3.subtreeFlags & (i3 ? 10262 : 10256)) for (t3 = t3.child; t3 !== null; ) Uu(e3, t3, n2, r3), t3 = t3.sibling;
    else i3 && ou(t3);
  }
  function Uu(e3, t3, n2, r3) {
    var i3 = (n2 & 335544064) === n2;
    i3 && t3.alternate === null && t3.return !== null && t3.return.alternate !== null && au(t3);
    var a3 = t3.flags;
    switch (t3.tag) {
      case 0:
      case 11:
      case 15:
        Hu(e3, t3, n2, r3), a3 & 2048 && El(9, t3);
        break;
      case 1:
        Hu(e3, t3, n2, r3);
        break;
      case 3:
        Hu(e3, t3, n2, r3), i3 && hu && (e3 = e3.containerInfo, e3 = e3.nodeType === 9 ? e3.body : e3.nodeName === `HTML` ? e3.ownerDocument.body : e3, e3.style.viewTransitionName === `root` && (e3.style.viewTransitionName = ``), e3 = e3.ownerDocument.documentElement, e3 !== null && e3.style.viewTransitionName === `none` && (e3.style.viewTransitionName = ``)), a3 & 2048 && (a3 = null, t3.alternate !== null && (a3 = t3.alternate.memoizedState.cache), t3 = t3.memoizedState.cache, t3 !== a3 && (t3.refCount++, a3 != null && Ha(a3)));
        break;
      case 12:
        if (a3 & 2048) {
          Hu(e3, t3, n2, r3), a3 = t3.stateNode;
          try {
            var o3 = t3.memoizedProps, s3 = o3.id, c3 = o3.onPostCommit;
            typeof c3 == `function` && c3(s3, t3.alternate === null ? `mount` : `update`, a3.passiveEffectDuration, -0);
          } catch (e4) {
            Z(t3, t3.return, e4);
          }
        } else Hu(e3, t3, n2, r3);
        break;
      case 31:
        Hu(e3, t3, n2, r3);
        break;
      case 13:
        Hu(e3, t3, n2, r3);
        break;
      case 23:
        break;
      case 22:
        o3 = t3.stateNode, s3 = t3.alternate, t3.memoizedState === null ? (i3 && s3 !== null && s3.memoizedState !== null && au(t3), o3._visibility & 2 ? Hu(e3, t3, n2, r3) : (o3._visibility |= 2, Wu(e3, t3, n2, r3, !!(t3.subtreeFlags & 10256) || false))) : (i3 && s3 !== null && s3.memoizedState === null && au(s3), o3._visibility & 2 ? Hu(e3, t3, n2, r3) : Gu(e3, t3)), a3 & 2048 && Bu(s3, t3);
        break;
      case 24:
        Hu(e3, t3, n2, r3), a3 & 2048 && Vu(t3.alternate, t3);
        break;
      case 30:
        i3 && (a3 = t3.alternate, a3 !== null && (Ql(a3.child, true), Ql(t3.child, true))), Hu(e3, t3, n2, r3);
        break;
      default:
        Hu(e3, t3, n2, r3);
    }
  }
  function Wu(e3, t3, n2, r3, i3) {
    for (i3 &&= !!(t3.subtreeFlags & 10256) || false, t3 = t3.child; t3 !== null; ) {
      var a3 = e3, o3 = t3, s3 = n2, c3 = r3, l3 = o3.flags;
      switch (o3.tag) {
        case 0:
        case 11:
        case 15:
          Wu(a3, o3, s3, c3, i3), El(8, o3);
          break;
        case 23:
          break;
        case 22:
          var u3 = o3.stateNode;
          o3.memoizedState === null ? (u3._visibility |= 2, Wu(a3, o3, s3, c3, i3)) : u3._visibility & 2 ? Wu(a3, o3, s3, c3, i3) : Gu(a3, o3), i3 && l3 & 2048 && Bu(o3.alternate, o3);
          break;
        case 24:
          Wu(a3, o3, s3, c3, i3), i3 && l3 & 2048 && Vu(o3.alternate, o3);
          break;
        default:
          Wu(a3, o3, s3, c3, i3);
      }
      t3 = t3.sibling;
    }
  }
  function Gu(e3, t3) {
    if (t3.subtreeFlags & 10256) for (t3 = t3.child; t3 !== null; ) {
      var n2 = e3, r3 = t3, i3 = r3.flags;
      switch (r3.tag) {
        case 22:
          Gu(n2, r3), i3 & 2048 && Bu(r3.alternate, r3);
          break;
        case 24:
          Gu(n2, r3), i3 & 2048 && Vu(r3.alternate, r3);
          break;
        default:
          Gu(n2, r3);
      }
      t3 = t3.sibling;
    }
  }
  var Ku = 8192;
  function qu(e3, t3, n2) {
    if (e3.subtreeFlags & Ku) for (e3 = e3.child; e3 !== null; ) Ju(e3, t3, n2), e3 = e3.sibling;
  }
  function Ju(e3, t3, n2) {
    switch (e3.tag) {
      case 26:
        qu(e3, t3, n2), e3.flags & Ku && (e3.memoizedState === null ? (e3 = e3.stateNode, (t3 & 335544128) === t3 && Zm(n2, e3)) : Qm(n2, ju, e3.memoizedState, e3.memoizedProps));
        break;
      case 5:
        qu(e3, t3, n2), e3.flags & Ku && (e3 = e3.stateNode, (t3 & 335544128) === t3 && Zm(n2, e3));
        break;
      case 3:
      case 4:
        var r3 = ju;
        ju = bm(e3.stateNode.containerInfo), qu(e3, t3, n2), ju = r3;
        break;
      case 22:
        e3.memoizedState === null && (r3 = e3.alternate, r3 !== null && r3.memoizedState !== null ? (r3 = Ku, Ku = 16777216, qu(e3, t3, n2), Ku = r3) : qu(e3, t3, n2));
        break;
      case 30:
        if ((e3.flags & Ku) !== 0 && (r3 = e3.memoizedProps.name, r3 != null && r3 !== `auto`)) {
          var i3 = e3.stateNode;
          i3.paired = null, Gl === null && (Gl = /* @__PURE__ */ new Map()), Gl.set(r3, i3);
        }
        qu(e3, t3, n2);
        break;
      default:
        qu(e3, t3, n2);
    }
  }
  function Yu(e3) {
    var t3 = e3.alternate;
    if (t3 !== null && (e3 = t3.child, e3 !== null)) {
      t3.child = null;
      do
        t3 = e3.sibling, e3.sibling = null, e3 = t3;
      while (e3 !== null);
    }
  }
  function Xu(e3) {
    var t3 = e3.deletions;
    if (e3.flags & 16) {
      if (t3 !== null) for (var n2 = 0; n2 < t3.length; n2++) {
        var r3 = t3[n2];
        H = r3, $u(r3, e3);
      }
      Yu(e3);
    }
    if (e3.subtreeFlags & 10256) for (e3 = e3.child; e3 !== null; ) Zu(e3), e3 = e3.sibling;
  }
  function Zu(e3) {
    switch (e3.tag) {
      case 0:
      case 11:
      case 15:
        Xu(e3), e3.flags & 2048 && Dl(9, e3, e3.return);
        break;
      case 3:
        Xu(e3);
        break;
      case 12:
        Xu(e3);
        break;
      case 22:
        var t3 = e3.stateNode;
        e3.memoizedState !== null && t3._visibility & 2 && (e3.return === null || e3.return.tag !== 13) ? (t3._visibility &= -3, Qu(e3)) : Xu(e3);
        break;
      default:
        Xu(e3);
    }
  }
  function Qu(e3) {
    var t3 = e3.deletions;
    if (e3.flags & 16) {
      if (t3 !== null) for (var n2 = 0; n2 < t3.length; n2++) {
        var r3 = t3[n2];
        H = r3, $u(r3, e3);
      }
      Yu(e3);
    }
    for (e3 = e3.child; e3 !== null; ) {
      switch (t3 = e3, t3.tag) {
        case 0:
        case 11:
        case 15:
          Dl(8, t3, t3.return), Qu(t3);
          break;
        case 22:
          n2 = t3.stateNode, n2._visibility & 2 && (n2._visibility &= -3, Qu(t3));
          break;
        default:
          Qu(t3);
      }
      e3 = e3.sibling;
    }
  }
  function $u(e3, t3) {
    for (; H !== null; ) {
      var n2 = H;
      switch (n2.tag) {
        case 0:
        case 11:
        case 15:
          Dl(8, n2, t3);
          break;
        case 23:
        case 22:
          if (n2.memoizedState !== null && n2.memoizedState.cachePool !== null) {
            var r3 = n2.memoizedState.cachePool.pool;
            r3 != null && r3.refCount++;
          }
          break;
        case 24:
          Ha(n2.memoizedState.cache);
      }
      if (r3 = n2.child, r3 !== null) r3.return = n2, H = r3;
      else a: for (n2 = e3; H !== null; ) {
        r3 = H;
        var i3 = r3.sibling, a3 = r3.return;
        if (Su(r3), r3 === n2) {
          H = null;
          break a;
        }
        if (i3 !== null) {
          i3.return = a3, H = i3;
          break a;
        }
        H = a3;
      }
    }
  }
  var ed = { getCacheForType: function(e3) {
    var t3 = Fa(j), n2 = t3.data.get(e3);
    return n2 === void 0 && (n2 = e3(), t3.data.set(e3, n2)), n2;
  }, cacheSignal: function() {
    return Fa(j).controller.signal;
  } }, td = typeof WeakMap == `function` ? WeakMap : Map, W = 0, G = null, K = null, q = 0, J = 0, nd = null, rd = false, id = false, ad = false, od = 0, Y = 0, sd = 0, cd = 0, ld = 0, ud = 0, dd = 0, fd = null, pd = null, md = false, hd = 0, gd = 0, _d = 1 / 0, vd = null, yd = null, X = 0, bd = null, xd = null, Sd = 0, Cd = 0, wd = null, Td = null, Ed = null, Dd = null, Od = null, kd = 0, Ad = null;
  function jd() {
    return W & 2 && q !== 0 ? q & -q : w.T === null ? jt() : Pf();
  }
  function Md() {
    if (ud === 0) {
      if (!(q & 536870912) || A) {
        var e3 = ht;
        ht <<= 1, !(ht & 3932160) && (ht = 262144), ud = e3;
      } else ud = 536870912;
    }
    return e3 = Bo.current, e3 !== null && (e3.flags |= 32), ud;
  }
  function Nd(e3, t3) {
    if (t3 != null) {
      var n2 = e3.stateNode, r3 = n2.ref;
      r3 === null && (r3 = n2.ref = Pp(Oi(e3.memoizedProps, n2))), Dd === null && (Dd = []), Dd.push(t3.bind(null, r3));
    }
  }
  function Pd(e3, t3, n2) {
    (e3 === G && (J === 2 || J === 9) || e3.cancelPendingCommit !== null) && (Vd(e3, 0), Rd(e3, q, ud, false)), wt(e3, n2), (!(W & 2) || e3 !== G) && (e3 === G && (!(W & 2) && (cd |= n2), Y === 4 && Rd(e3, q, ud, false)), Ef(e3));
  }
  function Fd(e3, t3, n2) {
    if (W & 6) throw Error(a2(327));
    var r3 = !n2 && !(t3 & 127) && (t3 & e3.expiredLanes) === 0 || yt(e3, t3), i3 = r3 ? Yd(e3, t3) : qd(e3, t3, true), o3 = r3;
    do {
      if (i3 === 0) {
        id && !r3 && Rd(e3, t3, 0, false);
        break;
      }
      if (n2 = e3.current.alternate, o3 && !Ld(n2)) {
        i3 = qd(e3, t3, false), o3 = false;
        continue;
      }
      if (i3 === 2) {
        if (o3 = t3, e3.errorRecoveryDisabledLanes & o3) var s3 = 0;
        else s3 = e3.pendingLanes & -536870913, s3 = s3 === 0 ? s3 & 536870912 ? 536870912 : 0 : s3;
        if (s3 !== 0) {
          t3 = s3;
          a: {
            var c3 = e3;
            i3 = fd;
            var l3 = c3.current.memoizedState.isDehydrated;
            if (l3 && (Vd(c3, s3).flags |= 256), s3 = qd(c3, s3, false), s3 !== 2 && s3 !== 6) {
              if (ad && !l3) {
                c3.errorRecoveryDisabledLanes |= o3, cd |= o3, i3 = 4;
                break a;
              }
              o3 = pd, pd = i3, o3 !== null && (pd === null ? pd = o3 : pd.push.apply(pd, o3));
            }
            i3 = s3;
          }
          if (o3 = false, i3 !== 2) continue;
        }
      }
      if (i3 === 1) {
        Vd(e3, 0), Rd(e3, t3, 0, true);
        break;
      }
      a: {
        switch (r3 = e3, o3 = i3, o3) {
          case 0:
          case 1:
            throw Error(a2(345));
          case 4:
            if ((t3 & 4194048) !== t3 && (t3 & 62914560) !== t3) break;
          case 6:
            Rd(r3, t3, ud, !rd);
            break a;
          case 2:
            pd = null;
            break;
          case 3:
          case 5:
            break;
          default:
            throw Error(a2(329));
        }
        if ((t3 & 62914560) === t3 && (i3 = hd + 300 - Qe(), 10 < i3)) {
          if (Rd(r3, t3, ud, !rd), vt(r3, 0, true) !== 0) break a;
          Sd = t3, r3.timeoutHandle = gp(Id.bind(null, r3, n2, pd, vd, md, t3, ud, cd, dd, rd, o3, `Throttled`, -0, 0), i3);
          break a;
        }
        Id(r3, n2, pd, vd, md, t3, ud, cd, dd, rd, o3, null, -0, 0);
      }
      break;
    } while (1);
    Ef(e3);
  }
  function Id(e3, t3, n2, r3, i3, a3, o3, s3, c3, l3, u3, d3, f3, p3) {
    e3.timeoutHandle = -1;
    var m3 = t3.subtreeFlags, h3 = (a3 & 335544064) === a3;
    if (d3 = null, (h3 || m3 & 8192 || (m3 & 16785408) == 16785408) && (d3 = { stylesheets: null, count: 0, imgCount: 0, imgBytes: 0, suspenseyImages: [], waitingForImages: true, waitingForViewTransition: false, unsuspend: kn }, Gl = null, Ju(t3, a3, d3), h3 && (m3 = d3, h3 = e3.containerInfo, h3 = (h3.nodeType === 9 ? h3 : h3.ownerDocument).__reactViewTransition, h3 != null && (m3.count++, m3.waitingForViewTransition = true, m3 = nh.bind(m3), h3.finished.then(m3, m3))), m3 = (a3 & 62914560) === a3 ? hd - Qe() : (a3 & 4194048) === a3 ? gd - Qe() : 0, m3 = eh(d3, m3), m3 !== null)) {
      Sd = a3, e3.cancelPendingCommit = m3(nf.bind(null, e3, t3, a3, n2, r3, i3, o3, s3, c3, l3, u3, d3, null, f3, p3)), Rd(e3, a3, o3, !l3);
      return;
    }
    nf(e3, t3, a3, n2, r3, i3, o3, s3, c3, l3, u3, d3);
  }
  function Ld(e3) {
    for (var t3 = e3; ; ) {
      var n2 = t3.tag;
      if ((n2 === 0 || n2 === 11 || n2 === 15) && t3.flags & 16384 && (n2 = t3.updateQueue, n2 !== null && (n2 = n2.stores, n2 !== null))) for (var r3 = 0; r3 < n2.length; r3++) {
        var i3 = n2[r3], a3 = i3.getSnapshot;
        i3 = i3.value;
        try {
          if (!Qr(a3(), i3)) return false;
        } catch {
          return false;
        }
      }
      if (n2 = t3.child, t3.subtreeFlags & 16384 && n2 !== null) n2.return = t3, t3 = n2;
      else {
        if (t3 === e3) break;
        for (; t3.sibling === null; ) {
          if (t3.return === null || t3.return === e3) return true;
          t3 = t3.return;
        }
        t3.sibling.return = t3.return, t3 = t3.sibling;
      }
    }
    return true;
  }
  function Rd(e3, t3, n2, r3) {
    t3 = bt(e3, t3), t3 &= ~ld, t3 &= ~cd, e3.suspendedLanes |= t3, e3.pingedLanes &= ~t3, r3 && (e3.warmLanes |= t3), r3 = e3.expirationTimes;
    for (var i3 = t3; 0 < i3; ) {
      var a3 = 31 - ut(i3), o3 = 1 << a3;
      r3[a3] = -1, i3 &= ~o3;
    }
    n2 !== 0 && Et(e3, n2, t3);
  }
  function zd() {
    return W & 6 ? true : (Df(0, false), false);
  }
  function Bd() {
    if (K !== null) {
      if (J === 0) var e3 = K.return;
      else e3 = K, Da = Ea = null, fs(e3), ho = null, go = 0, e3 = K;
      for (; e3 !== null; ) Tl(e3.alternate, e3), e3 = e3.return;
      K = null;
    }
  }
  function Vd(e3, t3) {
    var n2 = e3.timeoutHandle;
    return n2 !== -1 && (e3.timeoutHandle = -1, _p(n2)), n2 = e3.cancelPendingCommit, n2 !== null && (e3.cancelPendingCommit = null, n2()), Sd = 0, Bd(), G = e3, K = n2 = Gi(e3.current, null), q = t3, J = 0, nd = null, rd = false, id = yt(e3, t3), ad = false, dd = ud = ld = cd = sd = Y = 0, pd = fd = null, md = false, od = bt(e3, t3), Fi(), n2;
  }
  function Hd(e3, t3) {
    M = null, w.H = xc, t3 === io || t3 === oo ? (t3 = po(), J = 3) : t3 === ao ? (t3 = po(), J = 4) : J = t3 === zc ? 8 : typeof t3 == `object` && t3 && typeof t3.then == `function` ? 6 : 1, nd = t3, K === null && (Y = 1, Nc(e3, $i(t3, e3.current)));
  }
  function Ud() {
    var e3 = Bo.current;
    return e3 === null ? true : (q & 4194048) === q ? Vo === null : (q & 62914560) === q || q & 536870912 ? e3 === Vo : false;
  }
  function Wd() {
    var e3 = w.H;
    return w.H = xc, e3 === null ? xc : e3;
  }
  function Gd() {
    var e3 = w.A;
    return w.A = ed, e3;
  }
  function Kd() {
    Y = 4, rd || (q & 4194048) !== q && Bo.current !== null || (id = true), !(sd & 134217727) && !(cd & 134217727) || G === null || Rd(G, q, ud, false);
  }
  function qd(e3, t3, n2) {
    var r3 = W;
    W |= 2;
    var i3 = Wd(), a3 = Gd();
    (G !== e3 || q !== t3) && (vd = null, Vd(e3, t3)), t3 = false;
    var o3 = Y;
    a: do
      try {
        if (J !== 0 && K !== null) {
          var s3 = K, c3 = nd;
          switch (J) {
            case 8:
              Bd(), o3 = 6;
              break a;
            case 3:
            case 2:
            case 9:
            case 6:
              Bo.current === null && (t3 = true);
              var l3 = J;
              if (J = 0, nd = null, $d(e3, s3, c3, l3), n2 && id) {
                o3 = 0;
                break a;
              }
              break;
            default:
              l3 = J, J = 0, nd = null, $d(e3, s3, c3, l3);
          }
        }
        Jd(), o3 = Y;
        break;
      } catch (t4) {
        Hd(e3, t4);
      }
    while (1);
    return t3 && e3.shellSuspendCounter++, Da = Ea = null, W = r3, w.H = i3, w.A = a3, K === null && (G = null, q = 0, Fi()), o3;
  }
  function Jd() {
    for (; K !== null; ) Zd(K);
  }
  function Yd(e3, t3) {
    var n2 = W;
    W |= 2;
    var r3 = Wd(), i3 = Gd();
    G !== e3 || q !== t3 ? (vd = null, _d = Qe() + 500, Vd(e3, t3)) : id = yt(e3, t3);
    a: do
      try {
        if (J !== 0 && K !== null) {
          t3 = K;
          var o3 = nd;
          b: switch (J) {
            case 1:
              J = 0, nd = null, $d(e3, t3, o3, 1);
              break;
            case 2:
            case 9:
              if (co(o3)) {
                J = 0, nd = null, Qd(t3);
                break;
              }
              t3 = function() {
                J !== 2 && J !== 9 || G !== e3 || (J = 7), Ef(e3);
              }, o3.then(t3, t3);
              break a;
            case 3:
              J = 7;
              break a;
            case 4:
              J = 5;
              break a;
            case 7:
              co(o3) ? (J = 0, nd = null, Qd(t3)) : (J = 0, nd = null, $d(e3, t3, o3, 7));
              break;
            case 5:
              var s3 = null;
              switch (K.tag) {
                case 26:
                  s3 = K.memoizedState;
                case 5:
                case 27:
                  var c3 = K;
                  if (s3 ? Ym(s3) : c3.stateNode.complete) {
                    J = 0, nd = null;
                    var l3 = c3.sibling;
                    if (l3 !== null) K = l3;
                    else {
                      var u3 = c3.return;
                      u3 === null ? K = null : (K = u3, ef(u3));
                    }
                    break b;
                  }
              }
              J = 0, nd = null, $d(e3, t3, o3, 5);
              break;
            case 6:
              J = 0, nd = null, $d(e3, t3, o3, 6);
              break;
            case 8:
              Bd(), Y = 6;
              break a;
            default:
              throw Error(a2(462));
          }
        }
        Xd();
        break;
      } catch (t4) {
        Hd(e3, t4);
      }
    while (1);
    return Da = Ea = null, w.H = r3, w.A = i3, W = n2, K === null ? (G = null, q = 0, Fi(), Y) : 0;
  }
  function Xd() {
    for (; K !== null && !Xe(); ) Zd(K);
  }
  function Zd(e3) {
    var t3 = _l(e3.alternate, e3, od);
    e3.memoizedProps = e3.pendingProps, t3 === null ? ef(e3) : K = t3;
  }
  function Qd(e3) {
    var t3 = e3, n2 = t3.alternate;
    switch (t3.tag) {
      case 15:
      case 0:
        t3 = Zc(n2, t3, t3.pendingProps, t3.type, void 0, q);
        break;
      case 11:
        t3 = Zc(n2, t3, t3.pendingProps, t3.type.render, t3.ref, q);
        break;
      case 5:
        fs(t3);
        var r3 = t3;
        r3 === ma && (A ? (ba(r3), r3.tag === 5 && r3.stateNode != null && (k = r3.stateNode)) : (ba(r3), A = true));
      default:
        Tl(n2, t3), t3 = K = Ki(t3, od), t3 = _l(n2, t3, od);
    }
    e3.memoizedProps = e3.pendingProps, t3 === null ? ef(e3) : K = t3;
  }
  function $d(e3, t3, n2, r3) {
    Da = Ea = null, fs(t3), ho = null, go = 0;
    var i3 = t3.return;
    try {
      if (Rc(e3, i3, t3, n2, q)) {
        Y = 1, Nc(e3, $i(n2, e3.current)), K = null;
        return;
      }
    } catch (t4) {
      if (i3 !== null) throw K = i3, t4;
      Y = 1, Nc(e3, $i(n2, e3.current)), K = null;
      return;
    }
    t3.flags & 32768 ? (A || r3 === 1 ? e3 = true : id || q & 536870912 ? e3 = false : (rd = e3 = true, (r3 === 2 || r3 === 9 || r3 === 3 || r3 === 6) && (r3 = Bo.current, r3 !== null && r3.tag === 13 && (r3.flags |= 16384))), tf(t3, e3)) : ef(t3);
  }
  function ef(e3) {
    var t3 = e3;
    do {
      if (t3.flags & 32768) {
        tf(t3, rd);
        return;
      }
      e3 = t3.return;
      var n2 = Cl(t3.alternate, t3, od);
      if (n2 !== null) {
        K = n2;
        return;
      }
      if (t3 = t3.sibling, t3 !== null) {
        K = t3;
        return;
      }
      K = t3 = e3;
    } while (t3 !== null);
    Y === 0 && (Y = 5);
  }
  function tf(e3, t3) {
    do {
      var n2 = wl(e3.alternate, e3);
      if (n2 !== null) {
        n2.flags &= 32767, K = n2;
        return;
      }
      if (n2 = e3.return, n2 !== null && (n2.flags |= 32768, n2.subtreeFlags = 0, n2.deletions = null), !t3 && (e3 = e3.sibling, e3 !== null)) {
        K = e3;
        return;
      }
      K = e3 = n2;
    } while (e3 !== null);
    Y = 6, K = null;
  }
  function nf(e3, t3, n2, r3, i3, o3, s3, c3, l3, u3, d3, f3) {
    e3.cancelPendingCommit = null;
    do
      df();
    while (X !== 0);
    if (W & 6) throw Error(a2(327));
    if (t3 !== null) {
      if (t3 === e3.current) throw Error(a2(177));
      e3 === G && (K = G = null, q = 0), xd = t3, bd = e3, Sd = n2, wd = i3, Td = r3, rf(e3, t3, n2, s3, c3, l3, f3);
    }
  }
  function rf(e3, t3, n2, r3, i3, a3, o3) {
    var s3 = t3.lanes | t3.childLanes;
    if (Cd = s3, s3 |= Pi, Tt(e3, n2, s3, r3, i3, a3), Dd = null, (n2 & 335544064) === n2 ? (Od = Ga(e3), r3 = 10262) : (Od = null, r3 = 10256), (t3.subtreeFlags & r3) !== 0 || (t3.flags & r3) !== 0 ? (e3.callbackNode = null, e3.callbackPriority = 0, yf(nt, function() {
      return ff(), null;
    })) : (e3.callbackNode = null, e3.callbackPriority = 0), Wl = false, r3 = !!(t3.flags & 13878), t3.subtreeFlags & 13878 || r3) {
      r3 = w.T, w.T = null, i3 = T.p, T.p = 2, a3 = W, W |= 4;
      try {
        gu(e3, t3, n2);
      } finally {
        W = a3, T.p = i3, w.T = r3;
      }
    }
    X = 1, Wl ? Ed = Mp(o3, e3.containerInfo, Od, sf, cf, of, lf, ff, af, null, null) : (sf(), cf(), lf());
  }
  function af(e3) {
    if (X !== 0) {
      var t3 = bd.onRecoverableError;
      t3(e3, { componentStack: null });
    }
  }
  function of() {
    X === 3 && (X = 0, Iu(xd, bd), X = 4);
  }
  function sf() {
    if (X === 1) {
      X = 0;
      var e3 = bd, t3 = xd, n2 = Sd, r3 = !!(t3.flags & 13878);
      if (t3.subtreeFlags & 13878 || r3) {
        r3 = w.T, w.T = null;
        var i3 = T.p;
        T.p = 2;
        var a3 = W;
        W |= 4;
        try {
          pu = mu = false, Mu(t3, e3, n2), n2 = cp;
          var o3 = ii(e3.containerInfo), s3 = n2.focusedElem, c3 = n2.selectionRange;
          if (o3 !== s3 && s3 && s3.ownerDocument && ri(s3.ownerDocument.documentElement, s3)) {
            if (c3 !== null && ai(s3)) {
              var l3 = c3.start, u3 = c3.end;
              if (u3 === void 0 && (u3 = l3), `selectionStart` in s3) s3.selectionStart = l3, s3.selectionEnd = Math.min(u3, s3.value.length);
              else {
                var d3 = s3.ownerDocument || document, f3 = d3 && d3.defaultView || window;
                if (f3.getSelection) {
                  var p3 = f3.getSelection(), m3 = s3.textContent.length, h3 = Math.min(c3.start, m3), g3 = c3.end === void 0 ? h3 : Math.min(c3.end, m3);
                  !p3.extend && h3 > g3 && (o3 = g3, g3 = h3, h3 = o3);
                  var _3 = ni(s3, h3), v3 = ni(s3, g3);
                  if (_3 && v3 && (p3.rangeCount !== 1 || p3.anchorNode !== _3.node || p3.anchorOffset !== _3.offset || p3.focusNode !== v3.node || p3.focusOffset !== v3.offset)) {
                    var y3 = d3.createRange();
                    y3.setStart(_3.node, _3.offset), p3.removeAllRanges(), h3 > g3 ? (p3.addRange(y3), p3.extend(v3.node, v3.offset)) : (y3.setEnd(v3.node, v3.offset), p3.addRange(y3));
                  }
                }
              }
            }
            for (d3 = [], p3 = s3; p3 = p3.parentNode; ) p3.nodeType === 1 && d3.push({ element: p3, left: p3.scrollLeft, top: p3.scrollTop });
            for (typeof s3.focus == `function` && s3.focus(), s3 = 0; s3 < d3.length; s3++) {
              var b3 = d3[s3];
              b3.element.scrollLeft = b3.left, b3.element.scrollTop = b3.top;
            }
          }
          gh = !!sp, cp = sp = null;
        } finally {
          W = a3, T.p = i3, w.T = r3;
        }
      }
      e3.current = t3, X = 2;
    }
  }
  function cf() {
    if (X === 2) {
      X = 0;
      var e3 = bd, t3 = xd, n2 = !!(t3.flags & 8772);
      if (t3.subtreeFlags & 8772 || n2) {
        n2 = w.T, w.T = null;
        var r3 = T.p;
        T.p = 2;
        var i3 = W;
        W |= 4;
        try {
          vu(e3, t3.alternate, t3);
        } finally {
          W = i3, T.p = r3, w.T = n2;
        }
      }
      X = 3;
    }
  }
  function lf() {
    if (X === 4 || X === 3) {
      X = 0;
      var e3 = Ed;
      Ed = null, Ze();
      var t3 = bd, n2 = xd, r3 = Sd, i3 = Td, a3 = (r3 & 335544064) === r3 ? 10262 : 10256;
      if ((n2.subtreeFlags & a3) !== 0 || (n2.flags & a3) !== 0 ? X = 5 : (X = 0, xd = bd = null, uf(t3, t3.pendingLanes)), a3 = t3.pendingLanes, a3 === 0 && (yd = null), At(r3), n2 = n2.stateNode, ct && typeof ct.onCommitFiberRoot == `function`) try {
        ct.onCommitFiberRoot(st, n2, void 0, (n2.current.flags & 128) == 128);
      } catch {
      }
      if (i3 !== null) {
        n2 = w.T, a3 = T.p, T.p = 2, w.T = null;
        try {
          for (var o3 = t3.onRecoverableError, s3 = 0; s3 < i3.length; s3++) {
            var c3 = i3[s3];
            o3(c3.value, { componentStack: c3.stack });
          }
        } finally {
          w.T = n2, T.p = a3;
        }
      }
      if (i3 = Dd, o3 = Od, Od = null, i3 !== null && (Dd = null, o3 === null && (o3 = []), e3 !== null)) for (c3 = 0; c3 < i3.length; c3++) n2 = (0, i3[c3])(o3), n2 !== void 0 && e3.finished.finally(n2);
      Sd & 3 && df(), Ef(t3), a3 = t3.pendingLanes, r3 & 261930 && a3 & 42 ? t3 === Ad ? kd++ : (kd = 0, Ad = t3) : (kd = 0, Ad = null), Df(0, false);
    }
  }
  function uf(e3, t3) {
    (e3.pooledCacheLanes &= t3) === 0 && (t3 = e3.pooledCache, t3 != null && (e3.pooledCache = null, Ha(t3)));
  }
  function df() {
    return Ed !== null && (Ed.skipTransition(), Ed = null), sf(), cf(), lf(), ff();
  }
  function ff() {
    if (X !== 5) return false;
    var e3 = bd, t3 = Cd;
    Cd = 0;
    var n2 = At(Sd), r3 = w.T, i3 = T.p;
    try {
      T.p = 32 > n2 ? 32 : n2, w.T = null, n2 = wd, wd = null;
      var o3 = bd, s3 = Sd;
      if (X = 0, xd = bd = null, Sd = 0, W & 6) throw Error(a2(331));
      var c3 = W;
      if (W |= 4, Zu(o3.current), Uu(o3, o3.current, s3, n2), W = c3, Df(0, false), ct && typeof ct.onPostCommitFiberRoot == `function`) try {
        ct.onPostCommitFiberRoot(st, o3);
      } catch {
      }
      return true;
    } finally {
      T.p = i3, w.T = r3, uf(e3, t3);
    }
  }
  function pf(e3, t3, n2) {
    t3 = $i(n2, t3), t3 = Fc(e3.stateNode, t3, 2), e3 = Do(e3, t3, 2), e3 !== null && (wt(e3, 2), Ef(e3));
  }
  function Z(e3, t3, n2) {
    if (e3.tag === 3) pf(e3, e3, n2);
    else for (; t3 !== null; ) {
      if (t3.tag === 3) {
        pf(t3, e3, n2);
        break;
      }
      if (t3.tag === 1) {
        var r3 = t3.stateNode;
        if (typeof t3.type.getDerivedStateFromError == `function` || typeof r3.componentDidCatch == `function` && (yd === null || !yd.has(r3))) {
          e3 = $i(n2, e3), n2 = Ic(2), r3 = Do(t3, n2, 2), r3 !== null && (Lc(n2, r3, t3, e3), wt(r3, 2), Ef(r3));
          break;
        }
      }
      t3 = t3.return;
    }
  }
  function mf(e3, t3, n2) {
    var r3 = e3.pingCache;
    if (r3 === null) {
      r3 = e3.pingCache = new td();
      var i3 = /* @__PURE__ */ new Set();
      r3.set(t3, i3);
    } else i3 = r3.get(t3), i3 === void 0 && (i3 = /* @__PURE__ */ new Set(), r3.set(t3, i3));
    i3.has(n2) || (ad = true, i3.add(n2), e3 = hf.bind(null, e3, t3, n2), t3.then(e3, e3));
  }
  function hf(e3, t3, n2) {
    var r3 = e3.pingCache;
    r3 !== null && r3.delete(t3), e3.pingedLanes |= e3.suspendedLanes & n2, e3.warmLanes &= ~n2, G === e3 && (q & n2) === n2 && (Y === 4 || Y === 3 && (q & 62914560) === q && 300 > Qe() - hd ? W & 2 ? ld |= n2 : Vd(e3, 0) : ld |= n2, dd === q && (dd = 0)), Ef(e3);
  }
  function gf(e3, t3) {
    t3 === 0 && (t3 = St()), e3 = Ri(e3, t3), e3 !== null && (wt(e3, t3), Ef(e3));
  }
  function _f(e3) {
    var t3 = e3.memoizedState, n2 = 0;
    t3 !== null && (n2 = t3.retryLane), gf(e3, n2);
  }
  function vf(e3, t3) {
    var n2 = 0;
    switch (e3.tag) {
      case 31:
      case 13:
        var r3 = e3.stateNode, i3 = e3.memoizedState;
        i3 !== null && (n2 = i3.retryLane);
        break;
      case 19:
        r3 = e3.stateNode;
        break;
      case 22:
        r3 = e3.stateNode._retryCache;
        break;
      default:
        throw Error(a2(314));
    }
    r3 !== null && r3.delete(t3), gf(e3, n2);
  }
  function yf(e3, t3) {
    return Je(e3, t3);
  }
  var bf = null, xf = null, Sf = false, Cf = false, wf = false, Tf = 0;
  function Ef(e3) {
    e3 !== xf && e3.next === null && (xf === null ? bf = xf = e3 : xf = xf.next = e3), Cf = true, Sf || (Sf = true, Nf());
  }
  function Df(e3, t3) {
    if (!wf && Cf) {
      wf = true;
      do
        for (var n2 = false, r3 = bf; r3 !== null; ) {
          if (!t3) {
            if (e3 !== 0) {
              var i3 = r3.pendingLanes;
              if (i3 === 0) var a3 = 0;
              else {
                var o3 = r3.suspendedLanes, s3 = r3.pingedLanes;
                a3 = (1 << 31 - ut(42 | e3) + 1) - 1, a3 &= i3 & ~(o3 & ~s3), a3 = a3 & 201326741 ? a3 & 201326741 | 1 : a3 ? a3 | 2 : 0;
              }
              a3 !== 0 && (n2 = true, Mf(r3, a3));
            } else a3 = q, a3 = vt(r3, r3 === G ? a3 : 0, r3.cancelPendingCommit !== null || r3.timeoutHandle !== -1), !(a3 & 3) || yt(r3, a3) || (n2 = true, Mf(r3, a3));
          }
          r3 = r3.next;
        }
      while (n2);
      wf = false;
    }
  }
  function Of() {
    kf();
  }
  function kf() {
    Cf = Sf = false;
    var e3 = 0;
    Tf !== 0 && hp() && (e3 = Tf);
    for (var t3 = Qe(), n2 = null, r3 = bf; r3 !== null; ) {
      var i3 = r3.next, a3 = Af(r3, t3);
      a3 === 0 ? (r3.next = null, n2 === null ? bf = i3 : n2.next = i3, i3 === null && (xf = n2)) : (n2 = r3, (e3 !== 0 || a3 & 3) && (Cf = true)), r3 = i3;
    }
    X !== 0 && X !== 5 || Df(e3, false), Tf !== 0 && (Tf = 0);
  }
  function Af(e3, t3) {
    for (var n2 = e3.suspendedLanes, r3 = e3.pingedLanes, i3 = e3.expirationTimes, a3 = e3.pendingLanes & -62914561; 0 < a3; ) {
      var o3 = 31 - ut(a3), s3 = 1 << o3, c3 = i3[o3];
      c3 === -1 ? ((s3 & n2) === 0 || (s3 & r3) !== 0) && (i3[o3] = xt(s3, t3)) : c3 <= t3 && (e3.expiredLanes |= s3), a3 &= ~s3;
    }
    if (t3 = G, n2 = q, n2 = vt(e3, e3 === t3 ? n2 : 0, e3.cancelPendingCommit !== null || e3.timeoutHandle !== -1), r3 = e3.callbackNode, n2 === 0 || e3 === t3 && (J === 2 || J === 9) || e3.cancelPendingCommit !== null) return r3 !== null && r3 !== null && Ye(r3), e3.callbackNode = null, e3.callbackPriority = 0;
    if (!(n2 & 3) || yt(e3, n2)) {
      if (t3 = n2 & -n2, t3 === e3.callbackPriority) return t3;
      switch (r3 !== null && Ye(r3), At(n2)) {
        case 2:
        case 8:
          n2 = tt;
          break;
        case 32:
          n2 = nt;
          break;
        case 268435456:
          n2 = it;
          break;
        default:
          n2 = nt;
      }
      return r3 = jf.bind(null, e3), n2 = Je(n2, r3), e3.callbackPriority = t3, e3.callbackNode = n2, t3;
    }
    return r3 !== null && r3 !== null && Ye(r3), e3.callbackPriority = 2, e3.callbackNode = null, 2;
  }
  function jf(e3, t3) {
    if (X !== 0 && X !== 5) return e3.callbackNode = null, e3.callbackPriority = 0, null;
    var n2 = e3.callbackNode;
    if (df() && e3.callbackNode !== n2) return null;
    var r3 = q;
    return r3 = vt(e3, e3 === G ? r3 : 0, e3.cancelPendingCommit !== null || e3.timeoutHandle !== -1), r3 === 0 ? null : (Fd(e3, r3, t3), Af(e3, Qe()), e3.callbackNode != null && e3.callbackNode === n2 ? jf.bind(null, e3) : null);
  }
  function Mf(e3, t3) {
    if (df()) return null;
    Fd(e3, t3, true);
  }
  function Nf() {
    bp(function() {
      W & 6 ? Je(et, Of) : kf();
    });
  }
  function Pf() {
    if (Tf === 0) {
      var e3 = Ja;
      e3 === 0 && (e3 = mt, mt <<= 1, !(mt & 261888) && (mt = 256)), Tf = e3;
    }
    return Tf;
  }
  function Ff(e3) {
    return e3 == null || typeof e3 == `symbol` || typeof e3 == `boolean` ? null : typeof e3 == `function` ? e3 : On(e3);
  }
  function If(e3, t3, n2, r3, i3) {
    if (t3 === `submit` && n2 && n2.stateNode === i3) {
      var a3 = Ff((i3[Ft] || null).action), o3 = r3.submitter;
      o3 && (t3 = (t3 = o3[Ft] || null) ? Ff(t3.formAction) : o3.getAttribute(`formAction`), t3 !== null && (a3 = t3, o3 = null));
      var s3 = new Xn(`action`, `action`, null, r3, i3);
      e3.push({ event: s3, listeners: [{ instance: null, listener: function() {
        if (r3.defaultPrevented) {
          if (Tf !== 0) {
            var e4 = new FormData(i3, o3);
            sc(n2, { pending: true, data: e4, method: i3.method, action: a3 }, null, e4);
          }
        } else typeof a3 == `function` && (s3.preventDefault(), e4 = new FormData(i3, o3), sc(n2, { pending: true, data: e4, method: i3.method, action: a3 }, a3, e4));
      }, currentTarget: i3 }] });
    }
  }
  for (var Lf = 0; Lf < Ti.length; Lf++) {
    var Rf = Ti[Lf];
    Ei(Rf.toLowerCase(), `on` + (Rf[0].toUpperCase() + Rf.slice(1)));
  }
  Ei(_i, `onAnimationEnd`), Ei(vi, `onAnimationIteration`), Ei(yi, `onAnimationStart`), Ei(`dblclick`, `onDoubleClick`), Ei(`focusin`, `onFocus`), Ei(`focusout`, `onBlur`), Ei(bi, `onTransitionRun`), Ei(xi, `onTransitionStart`), Ei(Si, `onTransitionCancel`), Ei(Ci, `onTransitionEnd`), Qt(`onMouseEnter`, [`mouseout`, `mouseover`]), Qt(`onMouseLeave`, [`mouseout`, `mouseover`]), Qt(`onPointerEnter`, [`pointerout`, `pointerover`]), Qt(`onPointerLeave`, [`pointerout`, `pointerover`]), Zt(`onChange`, `change click focusin focusout input keydown keyup selectionchange`.split(` `)), Zt(`onSelect`, `focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(` `)), Zt(`onBeforeInput`, [`compositionend`, `keypress`, `textInput`, `paste`]), Zt(`onCompositionEnd`, `compositionend focusout keydown keypress keyup mousedown`.split(` `)), Zt(`onCompositionStart`, `compositionstart focusout keydown keypress keyup mousedown`.split(` `)), Zt(`onCompositionUpdate`, `compositionupdate focusout keydown keypress keyup mousedown`.split(` `));
  var zf = `abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(` `), Bf = new Set(`beforetoggle cancel close invalid load scroll scrollend toggle`.split(` `).concat(zf));
  function Vf(e3, t3) {
    t3 = !!(t3 & 4);
    for (var n2 = 0; n2 < e3.length; n2++) {
      var r3 = e3[n2], i3 = r3.event;
      r3 = r3.listeners;
      a: {
        var a3 = void 0;
        if (t3) for (var o3 = r3.length - 1; 0 <= o3; o3--) {
          var s3 = r3[o3], c3 = s3.instance, l3 = s3.currentTarget;
          if (s3 = s3.listener, c3 !== a3 && i3.isPropagationStopped()) break a;
          a3 = s3, i3.currentTarget = l3;
          try {
            a3(i3);
          } catch (e4) {
            ji(e4);
          }
          i3.currentTarget = null, a3 = c3;
        }
        else for (o3 = 0; o3 < r3.length; o3++) {
          if (s3 = r3[o3], c3 = s3.instance, l3 = s3.currentTarget, s3 = s3.listener, c3 !== a3 && i3.isPropagationStopped()) break a;
          a3 = s3, i3.currentTarget = l3;
          try {
            a3(i3);
          } catch (e4) {
            ji(e4);
          }
          i3.currentTarget = null, a3 = c3;
        }
      }
    }
  }
  function Q(e3, t3) {
    var n2 = t3[Lt];
    n2 === void 0 && (n2 = t3[Lt] = /* @__PURE__ */ new Set());
    var r3 = e3 + `__bubble`;
    n2.has(r3) || (Gf(t3, e3, 2, false), n2.add(r3));
  }
  function Hf(e3, t3, n2) {
    var r3 = 0;
    t3 && (r3 |= 4), Gf(n2, e3, r3, t3);
  }
  var Uf = `_reactListening` + Math.random().toString(36).slice(2);
  function Wf(e3) {
    if (!e3[Uf]) {
      e3[Uf] = true, Yt.forEach(function(t4) {
        t4 !== `selectionchange` && (Bf.has(t4) || Hf(t4, false, e3), Hf(t4, true, e3));
      });
      var t3 = e3.nodeType === 9 ? e3 : e3.ownerDocument;
      t3 === null || t3[Uf] || (t3[Uf] = true, Hf(`selectionchange`, false, t3));
    }
  }
  function Gf(e3, t3, n2, r3) {
    switch (Ch(t3)) {
      case 2:
        var i3 = _h;
        break;
      case 8:
        i3 = vh;
        break;
      default:
        i3 = yh;
    }
    n2 = i3.bind(null, t3, n2, e3), i3 = void 0, !zn || t3 !== `touchstart` && t3 !== `touchmove` && t3 !== `wheel` || (i3 = true), r3 ? i3 === void 0 ? e3.addEventListener(t3, n2, true) : e3.addEventListener(t3, n2, { capture: true, passive: i3 }) : i3 === void 0 ? e3.addEventListener(t3, n2, false) : e3.addEventListener(t3, n2, { passive: i3 });
  }
  function Kf(e3, t3, n2, r3, i3) {
    var a3 = r3;
    if (!(t3 & 1) && !(t3 & 2) && r3 !== null) a: for (; ; ) {
      if (r3 === null) return;
      var o3 = r3.tag;
      if (o3 === 3 || o3 === 4) {
        var c3 = r3.stateNode.containerInfo;
        if (c3 === i3) break;
        if (o3 === 4) for (o3 = r3.return; o3 !== null; ) {
          var l3 = o3.tag;
          if ((l3 === 3 || l3 === 4) && o3.stateNode.containerInfo === i3) return;
          o3 = o3.return;
        }
        for (; c3 !== null; ) {
          if (o3 = Wt(c3), o3 === null) return;
          if (l3 = o3.tag, l3 === 5 || l3 === 6 || l3 === 26 || l3 === 27) {
            r3 = a3 = o3;
            continue a;
          }
          c3 = c3.parentNode;
        }
      }
      r3 = r3.return;
    }
    In(function() {
      var r4 = a3, i4 = jn(n2), o4 = [];
      a: {
        var c4 = wi.get(e3);
        if (c4 !== void 0) {
          var l4 = Xn, u3 = e3;
          switch (e3) {
            case `keypress`:
              if (Gn(n2) === 0) break a;
            case `keydown`:
            case `keyup`:
              l4 = mr;
              break;
            case `focusin`:
              u3 = `focus`, l4 = ar;
              break;
            case `focusout`:
              u3 = `blur`, l4 = ar;
              break;
            case `beforeblur`:
            case `afterblur`:
              l4 = ar;
              break;
            case `click`:
              if (n2.button === 2) break a;
            case `auxclick`:
            case `dblclick`:
            case `mousedown`:
            case `mousemove`:
            case `mouseup`:
            case `mouseout`:
            case `mouseover`:
            case `contextmenu`:
              l4 = rr;
              break;
            case `drag`:
            case `dragend`:
            case `dragenter`:
            case `dragexit`:
            case `dragleave`:
            case `dragover`:
            case `dragstart`:
            case `drop`:
              l4 = ir;
              break;
            case `touchcancel`:
            case `touchend`:
            case `touchmove`:
            case `touchstart`:
              l4 = _r;
              break;
            case _i:
            case vi:
            case yi:
              l4 = or;
              break;
            case Ci:
              l4 = vr;
              break;
            case `scroll`:
            case `scrollend`:
              l4 = Qn;
              break;
            case `wheel`:
              l4 = yr;
              break;
            case `copy`:
            case `cut`:
            case `paste`:
              l4 = sr;
              break;
            case `gotpointercapture`:
            case `lostpointercapture`:
            case `pointercancel`:
            case `pointerdown`:
            case `pointermove`:
            case `pointerout`:
            case `pointerover`:
            case `pointerup`:
              l4 = hr;
              break;
            case `submit`:
              l4 = gr;
              break;
            case `toggle`:
            case `beforetoggle`:
              l4 = br;
          }
          var d3 = !!(t3 & 4), f3 = !d3 && (e3 === `scroll` || e3 === `scrollend`), p3 = d3 ? c4 === null ? null : c4 + `Capture` : c4;
          d3 = [];
          for (var m3 = r4, h3; m3 !== null; ) {
            var g3 = m3;
            if (h3 = g3.stateNode, g3 = g3.tag, g3 !== 5 && g3 !== 26 && g3 !== 27 || h3 === null || p3 === null || (g3 = Ln(m3, p3), g3 != null && d3.push(qf(m3, g3, h3))), f3) break;
            m3 = m3.return;
          }
          0 < d3.length && (c4 = new l4(c4, u3, null, n2, i4), o4.push({ event: c4, listeners: d3 }));
        }
      }
      if (!(t3 & 7)) {
        a: {
          if (l4 = e3 === `mouseover` || e3 === `pointerover`, c4 = e3 === `mouseout` || e3 === `pointerout`, l4 && n2 !== An && (u3 = n2.relatedTarget || n2.fromElement) && (Wt(u3) || u3[It])) break a;
          (c4 || l4) && (u3 = i4.window === i4 ? i4 : (l4 = i4.ownerDocument) ? l4.defaultView || l4.parentWindow : window, c4 ? (l4 = n2.relatedTarget || n2.toElement, c4 = r4, l4 = l4 ? Wt(l4) : null, l4 !== null && (f3 = s2(l4), d3 = l4.tag, l4 !== f3 || d3 !== 5 && d3 !== 27 && d3 !== 6) && (l4 = null)) : (c4 = null, l4 = r4), c4 !== l4 && (d3 = rr, g3 = `onMouseLeave`, p3 = `onMouseEnter`, m3 = `mouse`, (e3 === `pointerout` || e3 === `pointerover`) && (d3 = hr, g3 = `onPointerLeave`, p3 = `onPointerEnter`, m3 = `pointer`), f3 = c4 == null ? u3 : Kt(c4), h3 = l4 == null ? u3 : Kt(l4), u3 = new d3(g3, m3 + `leave`, c4, n2, i4), u3.target = f3, u3.relatedTarget = h3, g3 = null, Wt(i4) === r4 && (d3 = new d3(p3, m3 + `enter`, l4, n2, i4), d3.target = h3, d3.relatedTarget = f3, g3 = d3), f3 = g3, d3 = c4 && l4 ? re2(c4, l4, Yf) : null, c4 !== null && Xf(o4, u3, c4, d3, false), l4 !== null && f3 !== null && Xf(o4, f3, l4, d3, true)));
        }
        a: {
          if (c4 = r4 ? Kt(r4) : window, l4 = c4.nodeName && c4.nodeName.toLowerCase(), l4 === `select` || l4 === `input` && c4.type === `file`) var _3 = Br;
          else if (Pr(c4)) {
            if (Vr) _3 = Xr;
            else {
              _3 = Jr;
              var v3 = qr;
            }
          } else l4 = c4.nodeName, !l4 || l4.toLowerCase() !== `input` || c4.type !== `checkbox` && c4.type !== `radio` ? r4 && Tn(r4.elementType) && (_3 = Br) : _3 = Yr;
          if (_3 &&= _3(e3, r4)) {
            Fr(o4, _3, n2, i4);
            break a;
          }
          v3 && v3(e3, c4, r4);
        }
        switch (v3 = r4 ? Kt(r4) : window, e3) {
          case `focusin`:
            (Pr(v3) || v3.contentEditable === `true`) && (si = v3, ci = r4, li = null);
            break;
          case `focusout`:
            li = ci = si = null;
            break;
          case `mousedown`:
            ui = true;
            break;
          case `contextmenu`:
          case `mouseup`:
          case `dragend`:
            ui = false, di(o4, n2, i4);
            break;
          case `selectionchange`:
            if (oi) break;
          case `keydown`:
          case `keyup`:
            di(o4, n2, i4);
        }
        var y3;
        if (Sr) b: {
          switch (e3) {
            case `compositionstart`:
              var b3 = `onCompositionStart`;
              break b;
            case `compositionend`:
              b3 = `onCompositionEnd`;
              break b;
            case `compositionupdate`:
              b3 = `onCompositionUpdate`;
              break b;
          }
          b3 = void 0;
        }
        else Ar ? Or(e3, n2) && (b3 = `onCompositionEnd`) : e3 === `keydown` && n2.keyCode === 229 && (b3 = `onCompositionStart`);
        b3 && (Tr && n2.locale !== `ko` && (Ar || b3 !== `onCompositionStart` ? b3 === `onCompositionEnd` && Ar && (y3 = Wn()) : (Vn = i4, Hn = `value` in Vn ? Vn.value : Vn.textContent, Ar = true)), v3 = Jf(r4, b3), 0 < v3.length && (b3 = new cr(b3, e3, null, n2, i4), o4.push({ event: b3, listeners: v3 }), y3 ? b3.data = y3 : (y3 = kr(n2), y3 !== null && (b3.data = y3)))), (y3 = wr ? jr(e3, n2) : Mr(e3, n2)) && (b3 = Jf(r4, `onBeforeInput`), 0 < b3.length && (v3 = new cr(`onBeforeInput`, `beforeinput`, null, n2, i4), o4.push({ event: v3, listeners: b3 }), v3.data = y3)), If(o4, e3, r4, n2, i4);
      }
      Vf(o4, t3);
    });
  }
  function qf(e3, t3, n2) {
    return { instance: e3, listener: t3, currentTarget: n2 };
  }
  function Jf(e3, t3) {
    for (var n2 = t3 + `Capture`, r3 = []; e3 !== null; ) {
      var i3 = e3, a3 = i3.stateNode;
      if (i3 = i3.tag, i3 !== 5 && i3 !== 26 && i3 !== 27 || a3 === null || (i3 = Ln(e3, n2), i3 != null && r3.unshift(qf(e3, i3, a3)), i3 = Ln(e3, t3), i3 != null && r3.push(qf(e3, i3, a3))), e3.tag === 3) return r3;
      e3 = e3.return;
    }
    return [];
  }
  function Yf(e3) {
    if (e3 === null) return null;
    do
      e3 = e3.return;
    while (e3 && e3.tag !== 5 && e3.tag !== 27);
    return e3 || null;
  }
  function Xf(e3, t3, n2, r3, i3) {
    for (var a3 = t3._reactName, o3 = []; n2 !== null && n2 !== r3; ) {
      var s3 = n2, c3 = s3.alternate, l3 = s3.stateNode;
      if (s3 = s3.tag, c3 !== null && c3 === r3) break;
      s3 !== 5 && s3 !== 26 && s3 !== 27 || l3 === null || (c3 = l3, i3 ? (l3 = Ln(n2, a3), l3 != null && o3.unshift(qf(n2, l3, c3))) : i3 || (l3 = Ln(n2, a3), l3 != null && o3.push(qf(n2, l3, c3)))), n2 = n2.return;
    }
    o3.length !== 0 && e3.push({ event: t3, listeners: o3 });
  }
  var Zf = /\r\n?/g, Qf = /\u0000|\uFFFD/g;
  function $f(e3) {
    return (typeof e3 == `string` ? e3 : `` + e3).replace(Zf, `
`).replace(Qf, ``);
  }
  function ep(e3, t3) {
    return t3 = $f(t3), $f(e3) === t3;
  }
  function $(e3, t3, n2, r3, i3, o3) {
    switch (n2) {
      case `children`:
        if (typeof r3 == `string`) t3 === `body` || t3 === `textarea` && r3 === `` || xn(e3, r3);
        else if (typeof r3 == `number` || typeof r3 == `bigint`) t3 !== `body` && xn(e3, `` + r3);
        else return;
        break;
      case `className`:
        on(e3, `class`, r3);
        break;
      case `tabIndex`:
        on(e3, `tabindex`, r3);
        break;
      case `dir`:
      case `role`:
      case `viewBox`:
      case `width`:
      case `height`:
        on(e3, n2, r3);
        break;
      case `style`:
        wn(e3, r3, o3);
        return;
      case `data`:
        if (t3 !== `object`) {
          on(e3, `data`, r3);
          break;
        }
      case `src`:
      case `href`:
        if (r3 === `` && (t3 !== `a` || n2 !== `href`)) {
          e3.removeAttribute(n2);
          break;
        }
        if (r3 == null || typeof r3 == `function` || typeof r3 == `symbol` || typeof r3 == `boolean`) {
          e3.removeAttribute(n2);
          break;
        }
        r3 = On(r3), e3.setAttribute(n2, r3);
        break;
      case `action`:
      case `formAction`:
        if (typeof r3 == `function`) {
          e3.setAttribute(n2, `javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')`);
          break;
        }
        if (typeof o3 == `function` && (n2 === `formAction` ? (t3 !== `input` && $(e3, t3, `name`, i3.name, i3, null), $(e3, t3, `formEncType`, i3.formEncType, i3, null), $(e3, t3, `formMethod`, i3.formMethod, i3, null), $(e3, t3, `formTarget`, i3.formTarget, i3, null)) : ($(e3, t3, `encType`, i3.encType, i3, null), $(e3, t3, `method`, i3.method, i3, null), $(e3, t3, `target`, i3.target, i3, null))), r3 == null || typeof r3 == `symbol` || typeof r3 == `boolean`) {
          e3.removeAttribute(n2);
          break;
        }
        r3 = On(r3), e3.setAttribute(n2, r3);
        break;
      case `onClick`:
        r3 != null && (e3.onclick = kn);
        return;
      case `onScroll`:
        r3 != null && Q(`scroll`, e3);
        return;
      case `onScrollEnd`:
        r3 != null && Q(`scrollend`, e3);
        return;
      case `dangerouslySetInnerHTML`:
        if (r3 != null) {
          if (typeof r3 != `object` || !(`__html` in r3)) throw Error(a2(61));
          if (n2 = r3.__html, n2 != null) {
            if (i3.children != null) throw Error(a2(60));
            o3?.__html !== n2 && (e3.innerHTML = n2);
          }
        }
        break;
      case `multiple`:
        e3.multiple = r3 && typeof r3 != `function` && typeof r3 != `symbol`;
        break;
      case `muted`:
        e3.muted = r3 && typeof r3 != `function` && typeof r3 != `symbol`;
        break;
      case `suppressContentEditableWarning`:
      case `suppressHydrationWarning`:
      case `defaultValue`:
      case `defaultChecked`:
      case `innerHTML`:
      case `ref`:
        break;
      case `autoFocus`:
        break;
      case `xlinkHref`:
        if (r3 == null || typeof r3 == `function` || typeof r3 == `boolean` || typeof r3 == `symbol`) {
          e3.removeAttribute(`xlink:href`);
          break;
        }
        n2 = On(r3), e3.setAttributeNS(`http://www.w3.org/1999/xlink`, `xlink:href`, n2);
        break;
      case `contentEditable`:
      case `spellCheck`:
      case `draggable`:
      case `value`:
      case `autoReverse`:
      case `externalResourcesRequired`:
      case `focusable`:
      case `preserveAlpha`:
        r3 != null && typeof r3 != `function` && typeof r3 != `symbol` ? e3.setAttribute(n2, r3) : e3.removeAttribute(n2);
        break;
      case `inert`:
      case `allowFullScreen`:
      case `async`:
      case `autoPlay`:
      case `controls`:
      case `credentialless`:
      case `default`:
      case `defer`:
      case `disabled`:
      case `disablePictureInPicture`:
      case `disableRemotePlayback`:
      case `formNoValidate`:
      case `hidden`:
      case `loop`:
      case `noModule`:
      case `noValidate`:
      case `open`:
      case `playsInline`:
      case `readOnly`:
      case `required`:
      case `reversed`:
      case `scoped`:
      case `seamless`:
      case `itemScope`:
        r3 && typeof r3 != `function` && typeof r3 != `symbol` ? e3.setAttribute(n2, ``) : e3.removeAttribute(n2);
        break;
      case `capture`:
      case `download`:
        true === r3 ? e3.setAttribute(n2, ``) : false !== r3 && r3 != null && typeof r3 != `function` && typeof r3 != `symbol` ? e3.setAttribute(n2, r3) : e3.removeAttribute(n2);
        break;
      case `cols`:
      case `rows`:
      case `size`:
      case `span`:
        r3 != null && typeof r3 != `function` && typeof r3 != `symbol` && !isNaN(r3) && 1 <= r3 ? e3.setAttribute(n2, r3) : e3.removeAttribute(n2);
        break;
      case `rowSpan`:
      case `start`:
        r3 == null || typeof r3 == `function` || typeof r3 == `symbol` || isNaN(r3) ? e3.removeAttribute(n2) : e3.setAttribute(n2, r3);
        break;
      case `popover`:
        Q(`beforetoggle`, e3), Q(`toggle`, e3), an(e3, `popover`, r3);
        break;
      case `xlinkActuate`:
        sn(e3, `http://www.w3.org/1999/xlink`, `xlink:actuate`, r3);
        break;
      case `xlinkArcrole`:
        sn(e3, `http://www.w3.org/1999/xlink`, `xlink:arcrole`, r3);
        break;
      case `xlinkRole`:
        sn(e3, `http://www.w3.org/1999/xlink`, `xlink:role`, r3);
        break;
      case `xlinkShow`:
        sn(e3, `http://www.w3.org/1999/xlink`, `xlink:show`, r3);
        break;
      case `xlinkTitle`:
        sn(e3, `http://www.w3.org/1999/xlink`, `xlink:title`, r3);
        break;
      case `xlinkType`:
        sn(e3, `http://www.w3.org/1999/xlink`, `xlink:type`, r3);
        break;
      case `xmlBase`:
        sn(e3, `http://www.w3.org/XML/1998/namespace`, `xml:base`, r3);
        break;
      case `xmlLang`:
        sn(e3, `http://www.w3.org/XML/1998/namespace`, `xml:lang`, r3);
        break;
      case `xmlSpace`:
        sn(e3, `http://www.w3.org/XML/1998/namespace`, `xml:space`, r3);
        break;
      case `is`:
        an(e3, `is`, r3);
        break;
      case `innerText`:
      case `textContent`:
        return;
      default:
        if (!(2 < n2.length) || n2[0] !== `o` && n2[0] !== `O` || n2[1] !== `n` && n2[1] !== `N`) n2 = En.get(n2) || n2, an(e3, n2, r3);
        else return;
    }
    O = true;
  }
  function tp(e3, t3, n2, r3, i3, o3) {
    switch (n2) {
      case `style`:
        wn(e3, r3, o3);
        return;
      case `dangerouslySetInnerHTML`:
        if (r3 != null) {
          if (typeof r3 != `object` || !(`__html` in r3)) throw Error(a2(61));
          if (n2 = r3.__html, n2 != null) {
            if (i3.children != null) throw Error(a2(60));
            o3?.__html !== n2 && (e3.innerHTML = n2);
          }
        }
        break;
      case `children`:
        if (typeof r3 == `string`) xn(e3, r3);
        else if (typeof r3 == `number` || typeof r3 == `bigint`) xn(e3, `` + r3);
        else return;
        break;
      case `onScroll`:
        r3 != null && Q(`scroll`, e3);
        return;
      case `onScrollEnd`:
        r3 != null && Q(`scrollend`, e3);
        return;
      case `onClick`:
        r3 != null && (e3.onclick = kn);
        return;
      case `suppressContentEditableWarning`:
      case `suppressHydrationWarning`:
      case `innerHTML`:
      case `ref`:
        return;
      case `innerText`:
      case `textContent`:
        return;
      default:
        if (!Xt.hasOwnProperty(n2)) a: {
          if (n2[0] === `o` && n2[1] === `n` && (i3 = n2.endsWith(`Capture`), o3 = n2.slice(2, i3 ? n2.length - 7 : void 0), t3 = e3[Ft] || null, t3 = t3 == null ? null : t3[n2], typeof t3 == `function` && e3.removeEventListener(o3, t3, i3), typeof r3 == `function`)) {
            typeof t3 != `function` && t3 !== null && (n2 in e3 ? e3[n2] = null : e3.hasAttribute(n2) && e3.removeAttribute(n2)), e3.addEventListener(o3, r3, i3);
            break a;
          }
          O = true, n2 in e3 ? e3[n2] = r3 : true === r3 ? e3.setAttribute(n2, ``) : an(e3, n2, r3);
        }
        return;
    }
    O = true;
  }
  function np(e3, t3, n2) {
    switch (t3) {
      case `div`:
      case `span`:
      case `svg`:
      case `path`:
      case `a`:
      case `g`:
      case `p`:
      case `li`:
        break;
      case `img`:
        Q(`error`, e3), Q(`load`, e3);
        var r3 = false, i3 = false, o3;
        for (o3 in n2) if (n2.hasOwnProperty(o3)) {
          var s3 = n2[o3];
          if (s3 != null) switch (o3) {
            case `src`:
              r3 = true;
              break;
            case `srcSet`:
              i3 = true;
              break;
            case `children`:
            case `dangerouslySetInnerHTML`:
              throw Error(a2(137, t3));
            default:
              $(e3, t3, o3, s3, n2, null);
          }
        }
        i3 && $(e3, t3, `srcSet`, n2.srcSet, n2, null), r3 && $(e3, t3, `src`, n2.src, n2, null);
        return;
      case `input`:
        Q(`invalid`, e3);
        var c3 = o3 = s3 = i3 = null, l3 = null, u3 = null;
        for (r3 in n2) if (n2.hasOwnProperty(r3)) {
          var d3 = n2[r3];
          if (d3 != null) switch (r3) {
            case `name`:
              i3 = d3;
              break;
            case `type`:
              s3 = d3;
              break;
            case `checked`:
              l3 = d3;
              break;
            case `defaultChecked`:
              u3 = d3;
              break;
            case `value`:
              o3 = d3;
              break;
            case `defaultValue`:
              c3 = d3;
              break;
            case `children`:
            case `dangerouslySetInnerHTML`:
              if (d3 != null) throw Error(a2(137, t3));
              break;
            default:
              $(e3, t3, r3, d3, n2, null);
          }
        }
        gn(e3, o3, c3, l3, u3, s3, i3, false);
        return;
      case `select`:
        for (i3 in Q(`invalid`, e3), r3 = s3 = o3 = null, n2) if (n2.hasOwnProperty(i3) && (c3 = n2[i3], c3 != null)) switch (i3) {
          case `value`:
            o3 = c3;
            break;
          case `defaultValue`:
            s3 = c3;
            break;
          case `multiple`:
            r3 = c3;
          default:
            $(e3, t3, i3, c3, n2, null);
        }
        t3 = o3, n2 = s3, e3.multiple = !!r3, t3 == null ? n2 != null && vn(e3, !!r3, n2, true) : vn(e3, !!r3, t3, false);
        return;
      case `textarea`:
        for (s3 in Q(`invalid`, e3), o3 = i3 = r3 = null, n2) if (n2.hasOwnProperty(s3) && (c3 = n2[s3], c3 != null)) switch (s3) {
          case `value`:
            r3 = c3;
            break;
          case `defaultValue`:
            i3 = c3;
            break;
          case `children`:
            o3 = c3;
            break;
          case `dangerouslySetInnerHTML`:
            if (c3 != null) throw Error(a2(91));
            break;
          default:
            $(e3, t3, s3, c3, n2, null);
        }
        bn(e3, r3, i3, o3);
        return;
      case `option`:
        for (l3 in n2) if (n2.hasOwnProperty(l3) && (r3 = n2[l3], r3 != null)) switch (l3) {
          case `selected`:
            e3.selected = r3 && typeof r3 != `function` && typeof r3 != `symbol`;
            break;
          default:
            $(e3, t3, l3, r3, n2, null);
        }
        return;
      case `dialog`:
        Q(`beforetoggle`, e3), Q(`toggle`, e3), Q(`cancel`, e3), Q(`close`, e3);
        break;
      case `iframe`:
      case `object`:
        Q(`load`, e3);
        break;
      case `video`:
      case `audio`:
        for (r3 = 0; r3 < zf.length; r3++) Q(zf[r3], e3);
        break;
      case `image`:
        Q(`error`, e3), Q(`load`, e3);
        break;
      case `details`:
        Q(`toggle`, e3);
        break;
      case `embed`:
      case `source`:
      case `link`:
        Q(`error`, e3), Q(`load`, e3);
      case `area`:
      case `base`:
      case `br`:
      case `col`:
      case `hr`:
      case `keygen`:
      case `meta`:
      case `param`:
      case `track`:
      case `wbr`:
      case `menuitem`:
        for (u3 in n2) if (n2.hasOwnProperty(u3) && (r3 = n2[u3], r3 != null)) switch (u3) {
          case `children`:
          case `dangerouslySetInnerHTML`:
            throw Error(a2(137, t3));
          default:
            $(e3, t3, u3, r3, n2, null);
        }
        return;
      default:
        if (Tn(t3)) {
          for (d3 in n2) n2.hasOwnProperty(d3) && (r3 = n2[d3], r3 !== void 0 && tp(e3, t3, d3, r3, n2, void 0));
          return;
        }
    }
    for (c3 in n2) n2.hasOwnProperty(c3) && (r3 = n2[c3], r3 != null && $(e3, t3, c3, r3, n2, null));
  }
  var rp = {};
  function ip(e3, t3, n2, r3) {
    switch (t3) {
      case `div`:
      case `span`:
      case `svg`:
      case `path`:
      case `a`:
      case `g`:
      case `p`:
      case `li`:
        break;
      case `input`:
        var i3 = null, o3 = null, s3 = null, c3 = null, l3 = null, u3 = null, d3 = null;
        for (m3 in n2) {
          var f3 = n2[m3];
          if (n2.hasOwnProperty(m3) && f3 != null) switch (m3) {
            case `checked`:
              break;
            case `value`:
              break;
            case `defaultValue`:
              l3 = f3;
            default:
              r3.hasOwnProperty(m3) || $(e3, t3, m3, null, r3, f3);
          }
        }
        for (var p3 in r3) {
          var m3 = r3[p3];
          if (f3 = n2[p3], r3.hasOwnProperty(p3) && (m3 != null || f3 != null)) switch (p3) {
            case `type`:
              m3 !== f3 && (O = true), o3 = m3;
              break;
            case `name`:
              m3 !== f3 && (O = true), i3 = m3;
              break;
            case `checked`:
              m3 !== f3 && (O = true), u3 = m3;
              break;
            case `defaultChecked`:
              m3 !== f3 && (O = true), d3 = m3;
              break;
            case `value`:
              m3 !== f3 && (O = true), s3 = m3;
              break;
            case `defaultValue`:
              m3 !== f3 && (O = true), c3 = m3;
              break;
            case `children`:
            case `dangerouslySetInnerHTML`:
              if (m3 != null) throw Error(a2(137, t3));
              break;
            default:
              m3 !== f3 && $(e3, t3, p3, m3, r3, f3);
          }
        }
        hn(e3, s3, c3, l3, u3, d3, o3, i3);
        return;
      case `select`:
        for (o3 in m3 = s3 = c3 = p3 = null, n2) if (l3 = n2[o3], n2.hasOwnProperty(o3) && l3 != null) switch (o3) {
          case `value`:
            break;
          case `multiple`:
            m3 = l3;
          default:
            r3.hasOwnProperty(o3) || $(e3, t3, o3, null, r3, l3);
        }
        for (i3 in r3) if (o3 = r3[i3], l3 = n2[i3], r3.hasOwnProperty(i3) && (o3 != null || l3 != null)) switch (i3) {
          case `value`:
            o3 !== l3 && (O = true), p3 = o3;
            break;
          case `defaultValue`:
            o3 !== l3 && (O = true), c3 = o3;
            break;
          case `multiple`:
            o3 !== l3 && (O = true), s3 = o3;
          default:
            o3 !== l3 && $(e3, t3, i3, o3, r3, l3);
        }
        t3 = c3, n2 = s3, r3 = m3, p3 == null ? !!r3 != !!n2 && (t3 == null ? vn(e3, !!n2, n2 ? [] : ``, false) : vn(e3, !!n2, t3, true)) : vn(e3, !!n2, p3, false);
        return;
      case `textarea`:
        for (c3 in m3 = p3 = null, n2) if (i3 = n2[c3], n2.hasOwnProperty(c3) && i3 != null && !r3.hasOwnProperty(c3)) switch (c3) {
          case `value`:
            break;
          case `children`:
            break;
          default:
            $(e3, t3, c3, null, r3, i3);
        }
        for (s3 in r3) if (i3 = r3[s3], o3 = n2[s3], r3.hasOwnProperty(s3) && (i3 != null || o3 != null)) switch (s3) {
          case `value`:
            i3 !== o3 && (O = true), p3 = i3;
            break;
          case `defaultValue`:
            i3 !== o3 && (O = true), m3 = i3;
            break;
          case `children`:
            break;
          case `dangerouslySetInnerHTML`:
            if (i3 != null) throw Error(a2(91));
            break;
          default:
            i3 !== o3 && $(e3, t3, s3, i3, r3, o3);
        }
        yn(e3, p3, m3);
        return;
      case `option`:
        for (var h3 in n2) if (p3 = n2[h3], n2.hasOwnProperty(h3) && p3 != null && !r3.hasOwnProperty(h3)) switch (h3) {
          case `selected`:
            e3.selected = false;
            break;
          default:
            $(e3, t3, h3, null, r3, p3);
        }
        for (l3 in r3) if (p3 = r3[l3], m3 = n2[l3], r3.hasOwnProperty(l3) && p3 !== m3 && (p3 != null || m3 != null)) switch (l3) {
          case `selected`:
            p3 !== m3 && (O = true), e3.selected = p3 && typeof p3 != `function` && typeof p3 != `symbol`;
            break;
          default:
            $(e3, t3, l3, p3, r3, m3);
        }
        return;
      case `img`:
      case `link`:
      case `area`:
      case `base`:
      case `br`:
      case `col`:
      case `embed`:
      case `hr`:
      case `keygen`:
      case `meta`:
      case `param`:
      case `source`:
      case `track`:
      case `wbr`:
      case `menuitem`:
        for (var g3 in n2) p3 = n2[g3], n2.hasOwnProperty(g3) && p3 != null && !r3.hasOwnProperty(g3) && $(e3, t3, g3, null, r3, p3);
        for (u3 in r3) if (p3 = r3[u3], m3 = n2[u3], r3.hasOwnProperty(u3) && p3 !== m3 && (p3 != null || m3 != null)) switch (u3) {
          case `children`:
          case `dangerouslySetInnerHTML`:
            if (p3 != null) throw Error(a2(137, t3));
            break;
          default:
            $(e3, t3, u3, p3, r3, m3);
        }
        return;
      default:
        if (Tn(t3)) {
          for (var _3 in n2) p3 = n2[_3], n2.hasOwnProperty(_3) && p3 !== void 0 && !r3.hasOwnProperty(_3) && tp(e3, t3, _3, void 0, r3, p3);
          for (d3 in r3) p3 = r3[d3], m3 = n2[d3], !r3.hasOwnProperty(d3) || p3 === m3 || p3 === void 0 && m3 === void 0 || tp(e3, t3, d3, p3, r3, m3);
          return;
        }
    }
    for (var v3 in n2) p3 = n2[v3], n2.hasOwnProperty(v3) && p3 != null && !r3.hasOwnProperty(v3) && $(e3, t3, v3, null, r3, p3);
    for (f3 in r3) p3 = r3[f3], m3 = n2[f3], !r3.hasOwnProperty(f3) || p3 === m3 || p3 == null && m3 == null || $(e3, t3, f3, p3, r3, m3);
  }
  function ap(e3) {
    switch (e3) {
      case `css`:
      case `script`:
      case `font`:
      case `img`:
      case `image`:
      case `input`:
      case `link`:
        return true;
      default:
        return false;
    }
  }
  function op() {
    if (typeof performance.getEntriesByType == `function`) {
      for (var e3 = 0, t3 = 0, n2 = performance.getEntriesByType(`resource`), r3 = 0; r3 < n2.length; r3++) {
        var i3 = n2[r3], a3 = i3.transferSize, o3 = i3.initiatorType, s3 = i3.duration;
        if (a3 && s3 && ap(o3)) {
          for (o3 = 0, s3 = i3.responseEnd, r3 += 1; r3 < n2.length; r3++) {
            var c3 = n2[r3], l3 = c3.startTime;
            if (l3 > s3) break;
            var u3 = c3.transferSize, d3 = c3.initiatorType;
            u3 && ap(d3) && (c3 = c3.responseEnd, o3 += u3 * (c3 < s3 ? 1 : (s3 - l3) / (c3 - l3)));
          }
          if (--r3, t3 += 8 * (a3 + o3) / (i3.duration / 1e3), e3++, 10 < e3) break;
        }
      }
      if (0 < e3) return t3 / e3 / 1e6;
    }
    return navigator.connection && (e3 = navigator.connection.downlink, typeof e3 == `number`) ? e3 : 5;
  }
  var sp = null, cp = null;
  function lp(e3) {
    return e3.nodeType === 9 ? e3 : e3.ownerDocument;
  }
  function up(e3) {
    switch (e3) {
      case `http://www.w3.org/2000/svg`:
        return 1;
      case `http://www.w3.org/1998/Math/MathML`:
        return 2;
      default:
        return 0;
    }
  }
  function dp(e3, t3) {
    if (e3 === 0) switch (t3) {
      case `svg`:
        return 1;
      case `math`:
        return 2;
      default:
        return 0;
    }
    return e3 === 1 && t3 === `foreignObject` ? 0 : e3;
  }
  function fp(e3, t3, n2, r3) {
    return n2 = lp(n2).createElement(e3), n2[Pt] = r3, n2[Ft] = t3, np(n2, e3, t3), D(n2), n2;
  }
  function pp(e3, t3) {
    return e3 === `textarea` || e3 === `noscript` || typeof t3.children == `string` || typeof t3.children == `number` || typeof t3.children == `bigint` || typeof t3.dangerouslySetInnerHTML == `object` && t3.dangerouslySetInnerHTML !== null && t3.dangerouslySetInnerHTML.__html != null;
  }
  var mp = null;
  function hp() {
    var e3 = window.event;
    return e3 && e3.type === `popstate` ? e3 !== mp && (mp = e3, true) : (mp = null, false);
  }
  var gp = typeof setTimeout == `function` ? setTimeout : void 0, _p = typeof clearTimeout == `function` ? clearTimeout : void 0, vp = typeof Promise == `function` ? Promise : void 0, yp = typeof requestAnimationFrame == `function` ? requestAnimationFrame : gp, bp = typeof queueMicrotask == `function` ? queueMicrotask : vp === void 0 ? gp : function(e3) {
    return vp.resolve(null).then(e3).catch(xp);
  };
  function xp(e3) {
    setTimeout(function() {
      throw e3;
    });
  }
  function Sp(e3) {
    return e3 === `head`;
  }
  function Cp(e3, t3) {
    var n2 = t3, r3 = 0;
    do {
      var i3 = n2.nextSibling;
      if (e3.removeChild(n2), i3 && i3.nodeType === 8) {
        if (n2 = i3.data, n2 === `/$` || n2 === `/&`) {
          if (r3 === 0) {
            e3.removeChild(i3), Hh(t3);
            return;
          }
          r3--;
        } else if (n2 === `$` || n2 === `$?` || n2 === `$~` || n2 === `$!` || n2 === `&`) r3++;
        else if (n2 === `html`) _m(e3.ownerDocument.documentElement);
        else if (n2 === `head`) {
          n2 = e3.ownerDocument.head, _m(n2);
          for (var a3 = n2.firstChild; a3; ) {
            var o3 = a3.nextSibling, s3 = a3.nodeName;
            a3[Vt] || s3 === `SCRIPT` || s3 === `STYLE` || s3 === `LINK` && a3.rel.toLowerCase() === `stylesheet` || n2.removeChild(a3), a3 = o3;
          }
        } else n2 === `body` && _m(e3.ownerDocument.body);
      }
      n2 = i3;
    } while (n2);
    Hh(t3);
  }
  function wp(e3, t3) {
    var n2 = e3;
    e3 = 0;
    do {
      var r3 = n2.nextSibling;
      if (n2.nodeType === 1 ? t3 ? (n2._stashedDisplay = n2.style.display, n2.style.display = `none`) : (n2.style.display = n2._stashedDisplay || ``, n2.getAttribute(`style`) === `` && n2.removeAttribute(`style`)) : n2.nodeType === 3 && (t3 ? (n2._stashedText = n2.nodeValue, n2.nodeValue = ``) : n2.nodeValue = n2._stashedText || ``), r3 && r3.nodeType === 8) {
        if (n2 = r3.data, n2 === `/$`) {
          if (e3 === 0) break;
          e3--;
        } else n2 !== `$` && n2 !== `$?` && n2 !== `$~` && n2 !== `$!` || e3++;
      }
      n2 = r3;
    } while (n2);
  }
  function Tp(e3, t3, n2) {
    if (t3 = CSS.escape(t3) === t3 ? t3 : `r-` + btoa(t3).replace(/=/g, ``), e3.style.viewTransitionName = t3, n2 != null && (e3.style.viewTransitionClass = n2), n2 = getComputedStyle(e3), n2.display === `inline`) {
      if (t3 = e3.getClientRects(), t3.length === 1) var r3 = 1;
      else for (var i3 = r3 = 0; i3 < t3.length; i3++) {
        var a3 = t3[i3];
        0 < a3.width && 0 < a3.height && r3++;
      }
      r3 === 1 && (e3 = e3.style, e3.display = t3.length === 1 ? `inline-block` : `block`, e3.marginTop = `-` + n2.paddingTop, e3.marginBottom = `-` + n2.paddingBottom);
    }
  }
  function Ep(e3, t3) {
    e3 = e3.style, t3 = t3.style;
    var n2 = t3 == null ? null : t3.hasOwnProperty(`viewTransitionName`) ? t3.viewTransitionName : t3.hasOwnProperty(`view-transition-name`) ? t3[`view-transition-name`] : null;
    e3.viewTransitionName = n2 == null || typeof n2 == `boolean` ? `` : (`` + n2).trim(), n2 = t3 == null ? null : t3.hasOwnProperty(`viewTransitionClass`) ? t3.viewTransitionClass : t3.hasOwnProperty(`view-transition-class`) ? t3[`view-transition-class`] : null, e3.viewTransitionClass = n2 == null || typeof n2 == `boolean` ? `` : (`` + n2).trim(), e3.display === `inline-block` && (t3 == null ? e3.display = e3.margin = `` : (n2 = t3.display, e3.display = n2 == null || typeof n2 == `boolean` ? `` : n2, n2 = t3.margin, n2 == null ? (n2 = t3.hasOwnProperty(`marginTop`) ? t3.marginTop : t3[`margin-top`], e3.marginTop = n2 == null || typeof n2 == `boolean` ? `` : n2, t3 = t3.hasOwnProperty(`marginBottom`) ? t3.marginBottom : t3[`margin-bottom`], e3.marginBottom = t3 == null || typeof t3 == `boolean` ? `` : t3) : e3.margin = n2));
  }
  function Dp(e3, t3, n2) {
    return n2 = n2.ownerDocument.defaultView, { rect: e3, abs: t3.position === `absolute` || t3.position === `fixed`, clip: t3.clipPath !== `none` || t3.overflow !== `visible` || t3.filter !== `none` || t3.mask !== `none` || t3.mask !== `none` || t3.borderRadius !== `0px`, view: 0 <= e3.bottom && 0 <= e3.right && e3.top <= n2.innerHeight && e3.left <= n2.innerWidth };
  }
  function Op(e3) {
    return Dp(e3.getBoundingClientRect(), getComputedStyle(e3), e3);
  }
  function kp(e3) {
    var t3 = e3.getBoundingClientRect();
    t3 = new DOMRect(t3.x + 2e4, t3.y + 2e4, t3.width, t3.height);
    var n2 = getComputedStyle(e3);
    return Dp(t3, n2, e3);
  }
  function Ap(e3) {
    return e3.documentElement.clientHeight;
  }
  function jp(e3) {
    this.addEventListener(`load`, e3), this.addEventListener(`error`, e3);
  }
  function Mp(e3, t3, n2, r3, i3, a3, o3, s3, c3) {
    var l3 = t3.nodeType === 9 ? t3 : t3.ownerDocument;
    try {
      var u3 = l3.startViewTransition({ update: function() {
        var t4 = l3.defaultView, n3 = t4.navigation && t4.navigation.transition, o4 = l3.fonts.status;
        r3();
        var s4 = [];
        if (o4 === `loaded` && (Ap(l3), l3.fonts.status === `loading` && s4.push(l3.fonts.ready)), o4 = s4.length, e3 !== null) for (var c4 = e3.suspenseyImages, u4 = 0, d4 = 0; d4 < c4.length; d4++) {
          var f3 = c4[d4];
          if (!f3.complete) {
            var p3 = f3.getBoundingClientRect();
            if (0 < p3.bottom && 0 < p3.right && p3.top < t4.innerHeight && p3.left < t4.innerWidth) {
              if (u4 += Xm(f3), u4 > $m) {
                s4.length = o4;
                break;
              }
              f3 = new Promise(jp.bind(f3)), s4.push(f3);
            }
          }
        }
        if (0 < s4.length) return t4 = Promise.race([Promise.all(s4), new Promise(function(e4) {
          return setTimeout(e4, 500);
        })]).then(i3, i3), (n3 ? Promise.allSettled([n3.finished, t4]) : t4).then(a3, a3);
        if (i3(), n3) return n3.finished.then(a3, a3);
        a3();
      }, types: n2 });
      l3.__reactViewTransition = u3;
      var d3 = [];
      return u3.ready.then(function() {
        for (var e4 = l3.documentElement.getAnimations({ subtree: true }), t4 = 0; t4 < e4.length; t4++) {
          var n3 = e4[t4], r4 = n3.effect, i4 = r4.pseudoElement;
          if (i4 != null && i4.startsWith(`::view-transition`)) {
            d3.push(n3), n3 = r4.getKeyframes();
            for (var a4 = i4 = void 0, s4 = true, c4 = 0; c4 < n3.length; c4++) {
              var u4 = n3[c4], f3 = u4.width;
              if (i4 === void 0) i4 = f3;
              else if (i4 !== f3) {
                s4 = false;
                break;
              }
              if (f3 = u4.height, a4 === void 0) a4 = f3;
              else if (a4 !== f3) {
                s4 = false;
                break;
              }
              delete u4.width, delete u4.height, u4.transform === `none` && delete u4.transform;
            }
            s4 && i4 !== void 0 && a4 !== void 0 && (r4.setKeyframes(n3), s4 = getComputedStyle(r4.target, r4.pseudoElement), s4.width !== i4 || s4.height !== a4) && (s4 = n3[0], s4.width = i4, s4.height = a4, s4 = n3[n3.length - 1], s4.width = i4, s4.height = a4, r4.setKeyframes(n3));
          }
        }
        o3();
      }, function(e4) {
        l3.__reactViewTransition === u3 && (l3.__reactViewTransition = null);
        try {
          if (typeof e4 == `object` && e4) switch (e4.name) {
            case `InvalidStateError`:
              (e4.message === `View transition was skipped because document visibility state is hidden.` || e4.message === `Skipping view transition because document visibility state has become hidden.` || e4.message === `Skipping view transition because viewport size changed.` || e4.message === `Transition was aborted because of invalid state`) && (e4 = null);
          }
          e4 !== null && c3(e4);
        } finally {
          r3(), i3(), o3();
        }
      }), u3.finished.finally(function() {
        for (var e4 = 0; e4 < d3.length; e4++) d3[e4].cancel();
        l3.__reactViewTransition === u3 && (l3.__reactViewTransition = null), s3();
      }), u3;
    } catch {
      return r3(), i3(), o3(), null;
    }
  }
  function Np(e3, t3) {
    this._scope = document.documentElement, this._selector = `::view-transition-` + e3 + `(` + t3 + `)`;
  }
  Np.prototype.animate = function(e3, t3) {
    return t3 = typeof t3 == `number` ? { duration: t3 } : x2({}, t3), t3.pseudoElement = this._selector, this._scope.animate(e3, t3);
  }, Np.prototype.getAnimations = function() {
    for (var e3 = this._scope, t3 = this._selector, n2 = e3.getAnimations({ subtree: true }), r3 = [], i3 = 0; i3 < n2.length; i3++) {
      var a3 = n2[i3].effect;
      a3 !== null && a3.target === e3 && a3.pseudoElement === t3 && r3.push(n2[i3]);
    }
    return r3;
  }, Np.prototype.getComputedStyle = function() {
    return getComputedStyle(this._scope, this._selector);
  };
  function Pp(e3) {
    return { name: e3, group: new Np(`group`, e3), imagePair: new Np(`image-pair`, e3), old: new Np(`old`, e3), new: new Np(`new`, e3) };
  }
  function Fp(e3) {
    this._fragmentFiber = e3, this._observers = this._eventListeners = null;
  }
  Fp.prototype.addEventListener = function(e3, t3, n2) {
    var r3 = null, i3 = null;
    if (!(n2 != null && typeof n2 != `boolean` && (r3 = n2.signal || null, r3 !== null && r3.aborted))) {
      this._eventListeners === null && (this._eventListeners = []);
      var a3 = this._eventListeners;
      if (Bp(a3, e3, t3, n2) === -1) {
        var o3 = this, s3 = t3;
        n2 != null && typeof n2 != `boolean` && true === n2.once && (s3 = function(r4) {
          o3.removeEventListener(e3, t3, n2), typeof t3 == `function` ? t3.call(this, r4) : t3.handleEvent(r4);
        }), r3 !== null && (i3 = o3.removeEventListener.bind(o3, e3, t3, n2), r3.addEventListener(`abort`, i3, { once: true }), i3 = r3.removeEventListener.bind(r3, `abort`, i3)), r3 = Rp(n2), a3.push({ type: e3, listener: t3, optionsOrUseCapture: n2, attachedListener: s3, cleanup: i3 }), p2(this._fragmentFiber.child, false, Ip, e3, s3, r3);
      }
      this._eventListeners = a3;
    }
  };
  function Ip(e3, t3, n2, r3) {
    return v2(e3).addEventListener(t3, n2, r3), false;
  }
  Fp.prototype.removeEventListener = function(e3, t3, n2) {
    var r3 = this._eventListeners;
    if (r3 !== null && (t3 = Bp(r3, e3, t3, n2), t3 !== -1)) {
      var i3 = r3[t3];
      n2 = i3.attachedListener;
      var a3 = i3.cleanup;
      i3 = Rp(i3.optionsOrUseCapture), p2(this._fragmentFiber.child, false, Lp, e3, n2, i3), r3.splice(t3, 1), a3 !== null && a3();
    }
  };
  function Lp(e3, t3, n2, r3) {
    return v2(e3).removeEventListener(t3, n2, r3), false;
  }
  function Rp(e3) {
    return e3 != null && typeof e3 != `boolean` && (true === e3.once || e3.signal instanceof AbortSignal) ? { capture: e3.capture, passive: e3.passive } : e3;
  }
  function zp(e3) {
    return e3 == null ? `c=0` : typeof e3 == `boolean` ? `c=` + (e3 ? `1` : `0`) : `c=` + (e3.capture ? `1` : `0`);
  }
  function Bp(e3, t3, n2, r3) {
    if (e3.length === 0) return -1;
    r3 = zp(r3);
    for (var i3 = 0; i3 < e3.length; i3++) {
      var a3 = e3[i3];
      if (a3.type === t3 && a3.listener === n2 && zp(a3.optionsOrUseCapture) === r3) return i3;
    }
    return -1;
  }
  Fp.prototype.dispatchEvent = function(e3) {
    var t3 = m2(this._fragmentFiber);
    if (t3 === null) return true;
    t3 = v2(t3);
    var n2 = this._eventListeners;
    if (n2 !== null && 0 < n2.length || !e3.bubbles) {
      var r3 = t3.nodeType === 9 ? t3.createComment(``) : document.createTextNode(``);
      if (n2) for (var i3 = 0; i3 < n2.length; i3++) {
        var a3 = n2[i3];
        r3.addEventListener(a3.type, a3.attachedListener, Rp(a3.optionsOrUseCapture));
      }
      if (t3.appendChild(r3), e3 = r3.dispatchEvent(e3), n2) for (i3 = 0; i3 < n2.length; i3++) a3 = n2[i3], r3.removeEventListener(a3.type, a3.attachedListener, Rp(a3.optionsOrUseCapture));
      return t3.removeChild(r3), e3;
    }
    return t3.dispatchEvent(e3);
  }, Fp.prototype.focus = function(e3) {
    p2(this._fragmentFiber.child, true, Vp, e3, void 0, void 0);
  };
  function Vp(e3, t3) {
    return e3.tag !== 6 && (e3 = v2(e3), pm(e3, t3));
  }
  Fp.prototype.focusLast = function(e3) {
    var t3 = [];
    p2(this._fragmentFiber.child, true, Hp, t3, void 0, void 0);
    for (var n2 = t3.length - 1; 0 <= n2 && !Vp(t3[n2], e3); n2--) ;
  };
  function Hp(e3, t3) {
    return t3.push(e3), false;
  }
  Fp.prototype.blur = function() {
    var e3 = m2(this._fragmentFiber);
    e3 !== null && (e3 = v2(e3), e3 = lp(e3).activeElement, e3 !== null && p2(this._fragmentFiber.child, false, Up, e3, void 0, void 0));
  };
  function Up(e3, t3) {
    return e3.tag !== 6 && (e3 = v2(e3), e3 === t3 || e3.contains(t3) ? (t3.blur(), true) : false);
  }
  Fp.prototype.observeUsing = function(e3) {
    this._observers === null && (this._observers = /* @__PURE__ */ new Set()), this._observers.add(e3), p2(this._fragmentFiber.child, false, Wp, e3, void 0, void 0);
  };
  function Wp(e3, t3) {
    return e3.tag !== 6 && (e3 = v2(e3), t3.observe(e3), false);
  }
  Fp.prototype.unobserveUsing = function(e3) {
    var t3 = this._observers;
    if (t3 !== null && t3.has(e3)) {
      t3.delete(e3), p2(this._fragmentFiber.child, false, Gp, e3, void 0, void 0);
      for (var n2 = t3 = 0; n2 < Kp.length; n2++) {
        var r3 = Kp[n2];
        r3.fragmentInstance === this && r3.observer === e3 ? e3.unobserve(r3.instance) : Kp[t3++] = r3;
      }
      Kp.length = t3;
    }
  };
  function Gp(e3, t3) {
    return e3.tag !== 6 && (e3 = v2(e3), t3.unobserve(e3), false);
  }
  var Kp = [], qp = false;
  function Jp(e3, t3, n2) {
    Kp.push({ fragmentInstance: e3, observer: t3, instance: n2 }), qp || (qp = true, mm(function() {
      qp = false;
      var e4 = Kp;
      Kp = [];
      for (var t4 = 0; t4 < e4.length; t4++) {
        var n3 = e4[t4];
        n3.observer.unobserve(n3.instance);
      }
    }));
  }
  Fp.prototype.getClientRects = function() {
    var e3 = [];
    return p2(this._fragmentFiber.child, false, Yp, e3, void 0, void 0), e3;
  };
  function Yp(e3, t3) {
    if (e3.tag === 6) {
      e3 = e3.stateNode;
      var n2 = e3.ownerDocument.createRange();
      n2.selectNodeContents(e3), t3.push.apply(t3, n2.getClientRects());
    } else e3 = v2(e3), t3.push.apply(t3, e3.getClientRects());
    return false;
  }
  Fp.prototype.getRootNode = function(e3) {
    var t3 = m2(this._fragmentFiber);
    return t3 === null ? this : v2(t3).getRootNode(e3);
  }, Fp.prototype.compareDocumentPosition = function(e3) {
    var t3 = m2(this._fragmentFiber);
    if (t3 === null) return Node.DOCUMENT_POSITION_DISCONNECTED;
    var n2 = [];
    p2(this._fragmentFiber.child, false, Hp, n2, void 0, void 0);
    var r3 = v2(t3);
    if (n2.length === 0) {
      if (n2 = r3, h2(this._fragmentFiber)) {
        a: {
          for (t3 = this._fragmentFiber.return; t3 !== null; ) {
            if (t3.tag === 4) {
              t3 = t3.stateNode.containerInfo;
              break a;
            }
            if (t3.tag === 3 || t3.tag === 5 || t3.tag === 27) break;
            t3 = t3.return;
          }
          t3 = null;
        }
        t3 != null && (n2 = t3);
      }
      t3 = this._fragmentFiber;
      var i3 = r3 = n2.compareDocumentPosition(e3);
      return n2 === e3 ? i3 = Node.DOCUMENT_POSITION_CONTAINS : r3 & Node.DOCUMENT_POSITION_CONTAINED_BY && (n2 = g2(t3)[1], n2 === null ? i3 = Node.DOCUMENT_POSITION_PRECEDING : (e3 = v2(n2).compareDocumentPosition(e3), i3 = e3 === 0 || e3 & Node.DOCUMENT_POSITION_FOLLOWING ? Node.DOCUMENT_POSITION_FOLLOWING : Node.DOCUMENT_POSITION_PRECEDING)), i3 |= Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC;
    }
    t3 = v2(n2[0]), i3 = v2(n2[n2.length - 1]);
    var a3 = h2(this._fragmentFiber) ? t3.parentElement : r3;
    if (a3 == null) return Node.DOCUMENT_POSITION_DISCONNECTED;
    r3 = a3.compareDocumentPosition(t3) & Node.DOCUMENT_POSITION_CONTAINED_BY, a3 = a3.compareDocumentPosition(i3) & Node.DOCUMENT_POSITION_CONTAINED_BY;
    var o3 = t3.compareDocumentPosition(e3), s3 = i3.compareDocumentPosition(e3), c3 = o3 & Node.DOCUMENT_POSITION_CONTAINED_BY || s3 & Node.DOCUMENT_POSITION_CONTAINED_BY;
    return s3 = r3 && a3 && o3 & Node.DOCUMENT_POSITION_FOLLOWING && s3 & Node.DOCUMENT_POSITION_PRECEDING, t3 = r3 && t3 === e3 || a3 && i3 === e3 || c3 || s3 ? Node.DOCUMENT_POSITION_CONTAINED_BY : !r3 && t3 === e3 || !a3 && i3 === e3 ? Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC : o3, t3 & Node.DOCUMENT_POSITION_DISCONNECTED || t3 & Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC || Xp(t3, this._fragmentFiber, n2[0], n2[n2.length - 1], e3) ? t3 : Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC;
  };
  function Xp(e3, t3, n2, r3, i3) {
    var a3 = Wt(i3);
    if (e3 & Node.DOCUMENT_POSITION_CONTAINED_BY) {
      if (n2 = !!a3) a: {
        for (; a3 !== null; ) {
          if (a3.tag === 7 && (a3 === t3 || a3.alternate === t3)) {
            n2 = true;
            break a;
          }
          a3 = a3.return;
        }
        n2 = false;
      }
      return n2;
    }
    if (e3 & Node.DOCUMENT_POSITION_CONTAINS) {
      if (a3 === null) return a3 = i3.ownerDocument, i3 === a3 || i3 === a3.documentElement || i3 === a3.body;
      a: {
        for (a3 = t3, t3 = m2(t3); a3 !== null; ) {
          if (!(a3.tag !== 5 && a3.tag !== 3 && a3.tag !== 27 || a3 !== t3 && a3.alternate !== t3)) {
            a3 = true;
            break a;
          }
          a3 = a3.return;
        }
        a3 = false;
      }
      return a3;
    }
    return e3 & Node.DOCUMENT_POSITION_PRECEDING ? ((t3 = !!a3) && !(t3 = a3 === n2) && (t3 = re2(n2, a3, ne2), t3 === null ? t3 = false : (p2(t3, true, ee2, a3, n2), a3 = y2, y2 = null, t3 = a3 !== null)), t3) : e3 & Node.DOCUMENT_POSITION_FOLLOWING ? ((t3 = !!a3) && !(t3 = a3 === r3) && (t3 = re2(r3, a3, ne2), t3 === null ? t3 = false : (p2(t3, true, te2, a3, r3), a3 = y2, b2 = y2 = null, t3 = a3 !== null)), t3) : false;
  }
  function Zp(e3, t3) {
    var n2 = e3.ownerDocument.createRange();
    n2.selectNodeContents(e3), e3 = n2.getBoundingClientRect(), window.scrollTo(window.scrollX + e3.left, t3 ? window.scrollY + e3.top : window.scrollY + e3.bottom - window.innerHeight);
  }
  Fp.prototype.scrollIntoView = function(e3) {
    if (typeof e3 == `object`) throw Error(a2(566));
    var t3 = [];
    p2(this._fragmentFiber.child, false, Hp, t3, void 0, void 0);
    var n2 = false !== e3;
    if (t3.length === 0) {
      var r3 = g2(this._fragmentFiber);
      if (r3 = n2 ? r3[1] || r3[0] || m2(this._fragmentFiber) : r3[0] || r3[1], r3 === null) return;
      if (r3.tag === 6) {
        e3 = v2(r3), Zp(e3, n2);
        return;
      }
      if (r3 = v2(r3), r3.nodeType !== 9) {
        if (r3.nodeType === 11) {
          n2 = `host` in r3 ? r3.host : null, n2 !== null && n2.scrollIntoView(e3);
          return;
        }
        r3.scrollIntoView(e3);
      }
    }
    for (r3 = n2 ? t3.length - 1 : 0; r3 !== (n2 ? -1 : t3.length); ) {
      var i3 = t3[r3];
      i3.tag === 6 ? (i3 = v2(i3), Zp(i3, n2)) : v2(i3).scrollIntoView(e3), r3 += n2 ? -1 : 1;
    }
  };
  function Qp(e3, t3) {
    return e3 = v2(e3), $p(e3, t3), false;
  }
  function $p(e3, t3) {
    e3.reactFragments ??= /* @__PURE__ */ new Set(), e3.reactFragments.add(t3);
  }
  function em(e3, t3) {
    var n2 = t3._eventListeners;
    if (n2 !== null) for (var r3 = 0; r3 < n2.length; r3++) {
      var i3 = n2[r3];
      e3.addEventListener(i3.type, i3.attachedListener, Rp(i3.optionsOrUseCapture));
    }
    e3.nodeType !== 3 && (n2 = t3._observers, n2 !== null && n2.forEach(function(n3) {
      for (var r4 = 0, i4 = 0; i4 < Kp.length; i4++) {
        var a3 = Kp[i4];
        (a3.fragmentInstance !== t3 || a3.observer !== n3 || a3.instance !== e3) && (Kp[r4++] = a3);
      }
      Kp.length = r4, n3.observe(e3);
    }), $p(e3, t3));
  }
  function tm(e3, t3) {
    var n2 = t3._eventListeners;
    if (n2 !== null) for (var r3 = 0; r3 < n2.length; r3++) {
      var i3 = n2[r3];
      e3.removeEventListener(i3.type, i3.attachedListener, Rp(i3.optionsOrUseCapture));
    }
    e3.nodeType !== 3 && (n2 = t3._observers, n2 !== null && n2.forEach(function(n3) {
      typeof n3.rootMargin == `string` ? Jp(t3, n3, e3) : n3.unobserve(e3);
    }), e3.reactFragments != null && e3.reactFragments.delete(t3));
  }
  function nm(e3) {
    var t3 = e3.firstChild;
    for (t3 && t3.nodeType === 10 && (t3 = t3.nextSibling); t3; ) {
      var n2 = t3;
      switch (t3 = t3.nextSibling, n2.nodeName) {
        case `HTML`:
        case `HEAD`:
        case `BODY`:
          nm(n2), Ut(n2);
          continue;
        case `SCRIPT`:
        case `STYLE`:
          continue;
        case `LINK`:
          if (n2.rel.toLowerCase() === `stylesheet`) continue;
      }
      e3.removeChild(n2);
    }
  }
  function rm(e3, t3, n2, r3) {
    for (; e3.nodeType === 1; ) {
      var i3 = n2;
      if (e3.nodeName.toLowerCase() !== t3.toLowerCase()) {
        if (!r3 && (e3.nodeName !== `INPUT` || e3.type !== `hidden`)) break;
      } else if (!r3) {
        if (t3 === `input` && e3.type === `hidden`) {
          var a3 = i3.name == null ? null : `` + i3.name;
          if (i3.type === `hidden` && e3.getAttribute(`name`) === a3) return e3;
        } else return e3;
      } else if (!e3[Vt]) switch (t3) {
        case `meta`:
          if (!e3.hasAttribute(`itemprop`)) break;
          return e3;
        case `link`:
          if (a3 = e3.getAttribute(`rel`), a3 === `stylesheet` && e3.hasAttribute(`data-precedence`) || a3 !== i3.rel || e3.getAttribute(`href`) !== (i3.href == null || i3.href === `` ? null : i3.href) || e3.getAttribute(`crossorigin`) !== (i3.crossOrigin == null ? null : i3.crossOrigin) || e3.getAttribute(`title`) !== (i3.title == null ? null : i3.title)) break;
          return e3;
        case `style`:
          if (e3.hasAttribute(`data-precedence`)) break;
          return e3;
        case `script`:
          if (a3 = e3.getAttribute(`src`), (a3 !== (i3.src == null ? null : i3.src) || e3.getAttribute(`type`) !== (i3.type == null ? null : i3.type) || e3.getAttribute(`crossorigin`) !== (i3.crossOrigin == null ? null : i3.crossOrigin)) && a3 && e3.hasAttribute(`async`) && !e3.hasAttribute(`itemprop`)) break;
          return e3;
        default:
          return e3;
      }
      if (e3 = lm(e3.nextSibling), e3 === null) break;
    }
    return null;
  }
  function im(e3, t3, n2) {
    if (t3 === ``) return null;
    for (; e3.nodeType !== 3; ) if ((e3.nodeType !== 1 || e3.nodeName !== `INPUT` || e3.type !== `hidden`) && !n2 || (e3 = lm(e3.nextSibling), e3 === null)) return null;
    return e3;
  }
  function am(e3, t3) {
    for (; e3.nodeType !== 8; ) if ((e3.nodeType !== 1 || e3.nodeName !== `INPUT` || e3.type !== `hidden`) && !t3 || (e3 = lm(e3.nextSibling), e3 === null)) return null;
    return e3;
  }
  function om(e3) {
    return e3.data === `$?` || e3.data === `$~`;
  }
  function sm(e3) {
    return e3.data === `$!` || e3.data === `$?` && e3.ownerDocument.readyState !== `loading`;
  }
  function cm(e3, t3) {
    var n2 = e3.ownerDocument;
    if (e3.data === `$~`) e3._reactRetry = t3;
    else if (e3.data !== `$?` || n2.readyState !== `loading`) t3();
    else {
      var r3 = function() {
        t3(), n2.removeEventListener(`DOMContentLoaded`, r3);
      };
      n2.addEventListener(`DOMContentLoaded`, r3), e3._reactRetry = r3;
    }
  }
  function lm(e3) {
    for (; e3 != null; e3 = e3.nextSibling) {
      var t3 = e3.nodeType;
      if (t3 === 1 || t3 === 3) break;
      if (t3 === 8) {
        if (t3 = e3.data, t3 === `$` || t3 === `$!` || t3 === `$?` || t3 === `$~` || t3 === `&` || t3 === `F!` || t3 === `F`) break;
        if (t3 === `/$` || t3 === `/&`) return null;
      }
    }
    return e3;
  }
  var um = null;
  function dm(e3) {
    e3 = e3.nextSibling;
    for (var t3 = 0; e3; ) {
      if (e3.nodeType === 8) {
        var n2 = e3.data;
        if (n2 === `/$` || n2 === `/&`) {
          if (t3 === 0) return lm(e3.nextSibling);
          t3--;
        } else n2 !== `$` && n2 !== `$!` && n2 !== `$?` && n2 !== `$~` && n2 !== `&` || t3++;
      }
      e3 = e3.nextSibling;
    }
    return null;
  }
  function fm(e3) {
    e3 = e3.previousSibling;
    for (var t3 = 0; e3; ) {
      if (e3.nodeType === 8) {
        var n2 = e3.data;
        if (n2 === `$` || n2 === `$!` || n2 === `$?` || n2 === `$~` || n2 === `&`) {
          if (t3 === 0) return e3;
          t3--;
        } else n2 !== `/$` && n2 !== `/&` || t3++;
      }
      e3 = e3.previousSibling;
    }
    return null;
  }
  function pm(e3, t3) {
    function n2() {
      r3 = true;
    }
    if (e3.ownerDocument.activeElement === e3) return true;
    var r3 = false;
    try {
      e3.ownerDocument.addEventListener(`focus`, n2, true), (e3.focus || HTMLElement.prototype.focus).call(e3, t3);
    } finally {
      e3.ownerDocument.removeEventListener(`focus`, n2, true);
    }
    return r3;
  }
  function mm(e3) {
    yp(function() {
      yp(function(t3) {
        return e3(t3);
      });
    });
  }
  function hm(e3, t3, n2) {
    switch (t3 = lp(n2), e3) {
      case `html`:
        if (e3 = t3.documentElement, !e3) throw Error(a2(452));
        return e3;
      case `head`:
        if (e3 = t3.head, !e3) throw Error(a2(453));
        return e3;
      case `body`:
        if (e3 = t3.body, !e3) throw Error(a2(454));
        return e3;
      default:
        throw Error(a2(451));
    }
  }
  function gm(e3, t3, n2) {
    for (var r3 in n2) {
      var i3 = n2[r3];
      n2.hasOwnProperty(r3) && i3 != null && $(e3, t3, r3, null, rp, i3);
    }
    n2.dangerouslySetInnerHTML != null && (e3.textContent = ``), e3.onclick === kn && (e3.onclick = null), Ut(e3);
  }
  function _m(e3) {
    for (var t3 = e3.attributes; t3.length; ) e3.removeAttributeNode(t3[0]);
    Ut(e3);
  }
  var vm = /* @__PURE__ */ new Map(), ym = /* @__PURE__ */ new Set();
  function bm(e3) {
    if (typeof e3.getRootNode == `function`) {
      var t3 = e3.getRootNode();
      if (t3.nodeType === 9 || t3.nodeType === 11) return t3;
    }
    return e3.nodeType === 9 ? e3 : e3.ownerDocument;
  }
  var xm = T.d;
  T.d = { f: Sm, r: Cm, D: Em, C: Dm, L: Om, m: km, X: jm, S: Am, M: Mm };
  function Sm() {
    var e3 = xm.f(), t3 = zd();
    return e3 || t3;
  }
  function Cm(e3) {
    var t3 = Gt(e3);
    t3 !== null && t3.tag === 5 && t3.type === `form` ? lc(t3) : xm.r(e3);
  }
  var wm = typeof document > `u` ? null : document;
  function Tm(e3, t3, n2) {
    var r3 = wm;
    if (r3 && typeof t3 == `string` && t3) {
      var i3 = mn(t3);
      i3 = `link[rel="` + e3 + `"][href="` + i3 + `"]`, typeof n2 == `string` && (i3 += `[crossorigin="` + n2 + `"]`), ym.has(i3) || (ym.add(i3), e3 = { rel: e3, crossOrigin: n2, href: t3 }, r3.querySelector(i3) === null && (t3 = r3.createElement(`link`), np(t3, `link`, e3), D(t3), r3.head.appendChild(t3)));
    }
  }
  function Em(e3) {
    xm.D(e3), Tm(`dns-prefetch`, e3, null);
  }
  function Dm(e3, t3) {
    xm.C(e3, t3), Tm(`preconnect`, e3, t3);
  }
  function Om(e3, t3, n2) {
    xm.L(e3, t3, n2);
    var r3 = wm;
    if (r3 && e3 && t3) {
      var i3 = `link[rel="preload"][as="` + mn(t3) + `"]`;
      t3 === `image` && n2 && n2.imageSrcSet ? (i3 += `[imagesrcset="` + mn(n2.imageSrcSet) + `"]`, typeof n2.imageSizes == `string` && (i3 += `[imagesizes="` + mn(n2.imageSizes) + `"]`)) : i3 += `[href="` + mn(e3) + `"]`;
      var a3 = i3;
      switch (t3) {
        case `style`:
          a3 = Pm(e3);
          break;
        case `script`:
          a3 = Rm(e3);
      }
      if (!(vm.has(a3) || (e3 = x2({ rel: `preload`, href: t3 === `image` && n2 && n2.imageSrcSet ? void 0 : e3, as: t3 }, n2), vm.set(a3, e3), r3.querySelector(i3) !== null || t3 === `style` && r3.querySelector(Fm(a3)) || t3 === `script` && r3.querySelector(zm(a3))))) {
        var o3 = r3.createElement(`link`);
        np(o3, `link`, e3), t3 === `style` && (o3[Ht] = true, o3.onload = o3.onerror = function() {
          Jt(o3);
        }), D(o3), r3.head.appendChild(o3);
      }
    }
  }
  function km(e3, t3) {
    xm.m(e3, t3);
    var n2 = wm;
    if (n2 && e3) {
      var r3 = t3 && typeof t3.as == `string` ? t3.as : `script`, i3 = `link[rel="modulepreload"][as="` + mn(r3) + `"][href="` + mn(e3) + `"]`, a3 = i3;
      switch (r3) {
        case `audioworklet`:
        case `paintworklet`:
        case `serviceworker`:
        case `sharedworker`:
        case `worker`:
        case `script`:
          a3 = Rm(e3);
      }
      if (!vm.has(a3) && (e3 = x2({ rel: `modulepreload`, href: e3 }, t3), vm.set(a3, e3), n2.querySelector(i3) === null)) {
        switch (r3) {
          case `audioworklet`:
          case `paintworklet`:
          case `serviceworker`:
          case `sharedworker`:
          case `worker`:
          case `script`:
            if (n2.querySelector(zm(a3))) return;
        }
        r3 = n2.createElement(`link`), np(r3, `link`, e3), D(r3), n2.head.appendChild(r3);
      }
    }
  }
  function Am(e3, t3, n2) {
    xm.S(e3, t3, n2);
    var r3 = wm;
    if (r3 && e3) {
      var i3 = qt(r3).hoistableStyles, a3 = Pm(e3);
      t3 ||= `default`;
      var o3 = i3.get(a3);
      if (!o3) {
        var s3 = { loading: 0, preload: null };
        if (o3 = r3.querySelector(Fm(a3))) s3.loading = 5;
        else {
          e3 = x2({ rel: `stylesheet`, href: e3, "data-precedence": t3 }, n2), (n2 = vm.get(a3)) && Hm(e3, n2);
          var c3 = o3 = r3.createElement(`link`);
          D(c3), np(c3, `link`, e3), c3._p = new Promise(function(e4, t4) {
            c3.onload = e4, c3.onerror = t4;
          }), c3.addEventListener(`load`, function() {
            s3.loading |= 1;
          }), c3.addEventListener(`error`, function() {
            s3.loading |= 2;
          }), s3.loading |= 4, Vm(o3, t3, r3);
        }
        o3 = { type: `stylesheet`, instance: o3, count: 1, state: s3 }, i3.set(a3, o3);
      }
    }
  }
  function jm(e3, t3) {
    xm.X(e3, t3);
    var n2 = wm;
    if (n2 && e3) {
      var r3 = qt(n2).hoistableScripts, i3 = Rm(e3), a3 = r3.get(i3);
      a3 || (a3 = n2.querySelector(zm(i3)), a3 || (e3 = x2({ src: e3, async: true }, t3), (t3 = vm.get(i3)) && Um(e3, t3), a3 = n2.createElement(`script`), D(a3), np(a3, `link`, e3), n2.head.appendChild(a3)), a3 = { type: `script`, instance: a3, count: 1, state: null }, r3.set(i3, a3));
    }
  }
  function Mm(e3, t3) {
    xm.M(e3, t3);
    var n2 = wm;
    if (n2 && e3) {
      var r3 = qt(n2).hoistableScripts, i3 = Rm(e3), a3 = r3.get(i3);
      a3 || (a3 = n2.querySelector(zm(i3)), a3 || (e3 = x2({ src: e3, async: true, type: `module` }, t3), (t3 = vm.get(i3)) && Um(e3, t3), a3 = n2.createElement(`script`), D(a3), np(a3, `link`, e3), n2.head.appendChild(a3)), a3 = { type: `script`, instance: a3, count: 1, state: null }, r3.set(i3, a3));
    }
  }
  function Nm(e3, t3, n2, r3) {
    var i3 = (i3 = Pe.current) ? bm(i3) : null;
    if (!i3) throw Error(a2(446));
    switch (e3) {
      case `meta`:
      case `title`:
        return null;
      case `style`:
        return typeof n2.precedence == `string` && typeof n2.href == `string` ? (n2 = Pm(n2.href), t3 = qt(i3).hoistableStyles, r3 = t3.get(n2), r3 || (r3 = { type: `style`, instance: null, count: 0, state: null }, t3.set(n2, r3)), r3) : { type: `void`, instance: null, count: 0, state: null };
      case `link`:
        if (n2.rel === `stylesheet` && typeof n2.href == `string` && typeof n2.precedence == `string`) {
          e3 = Pm(n2.href);
          var o3 = qt(i3).hoistableStyles, s3 = o3.get(e3);
          if (s3 || (i3 = i3.ownerDocument || i3, s3 = { type: `stylesheet`, instance: null, count: 0, state: { loading: 0, preload: null } }, o3.set(e3, s3), (o3 = i3.querySelector(Fm(e3))) ? o3._p || (s3.instance = o3, s3.state.loading = 5) : (o3 = vm.get(e3), o3 || (o3 = { rel: `preload`, as: `style`, href: n2.href, crossOrigin: n2.crossOrigin, integrity: n2.integrity, media: n2.media, hrefLang: n2.hrefLang, referrerPolicy: n2.referrerPolicy }, vm.set(e3, o3)), Lm(i3, e3, o3, s3.state))), t3 && r3 === null) throw Error(a2(528, ``));
          return s3;
        }
        if (t3 && r3 !== null) throw Error(a2(529, ``));
        return null;
      case `script`:
        return t3 = n2.async, n2 = n2.src, typeof n2 == `string` && t3 && typeof t3 != `function` && typeof t3 != `symbol` ? (n2 = Rm(n2), t3 = qt(i3).hoistableScripts, r3 = t3.get(n2), r3 || (r3 = { type: `script`, instance: null, count: 0, state: null }, t3.set(n2, r3)), r3) : { type: `void`, instance: null, count: 0, state: null };
      default:
        throw Error(a2(444, e3));
    }
  }
  function Pm(e3) {
    return `href="` + mn(e3) + `"`;
  }
  function Fm(e3) {
    return `link[rel="stylesheet"][` + e3 + `]`;
  }
  function Im(e3) {
    return x2({}, e3, { "data-precedence": e3.precedence, precedence: null });
  }
  function Lm(e3, t3, n2, r3) {
    if (t3 = e3.querySelector(`link[rel="preload"][as="style"][` + t3 + `]`)) {
      if (true !== t3[Ht]) {
        r3.loading = 1;
        return;
      }
    } else t3 = e3.createElement(`link`), t3[Ht] = true, t3.onload = t3.onerror = Jt.bind(null, t3), np(t3, `link`, n2), D(t3), e3.head.appendChild(t3);
    r3.preload = t3, t3.addEventListener(`load`, function() {
      return r3.loading |= 1;
    }), t3.addEventListener(`error`, function() {
      return r3.loading |= 2;
    });
  }
  function Rm(e3) {
    return `[src="` + mn(e3) + `"]`;
  }
  function zm(e3) {
    return `script[async]` + e3;
  }
  function Bm(e3, t3, n2) {
    if (t3.count++, t3.instance === null) switch (t3.type) {
      case `style`:
        var r3 = e3.querySelector(`style[data-href~="` + mn(n2.href) + `"]`);
        if (r3) return t3.instance = r3, D(r3), r3;
        var i3 = x2({}, n2, { "data-href": n2.href, "data-precedence": n2.precedence, href: null, precedence: null });
        return r3 = (e3.ownerDocument || e3).createElement(`style`), D(r3), np(r3, `style`, i3), Vm(r3, n2.precedence, e3), t3.instance = r3;
      case `stylesheet`:
        i3 = Pm(n2.href);
        var o3 = e3.querySelector(Fm(i3));
        if (o3) return t3.state.loading |= 4, t3.instance = o3, D(o3), o3;
        r3 = Im(n2), (i3 = vm.get(i3)) && Hm(r3, i3), o3 = (e3.ownerDocument || e3).createElement(`link`), D(o3);
        var s3 = o3;
        return s3._p = new Promise(function(e4, t4) {
          s3.onload = e4, s3.onerror = t4;
        }), np(o3, `link`, r3), t3.state.loading |= 4, Vm(o3, n2.precedence, e3), t3.instance = o3;
      case `script`:
        return o3 = Rm(n2.src), (i3 = e3.querySelector(zm(o3))) ? (t3.instance = i3, D(i3), i3) : (r3 = n2, (i3 = vm.get(o3)) && (r3 = x2({}, n2), Um(r3, i3)), e3 = e3.ownerDocument || e3, i3 = e3.createElement(`script`), D(i3), np(i3, `link`, r3), e3.head.appendChild(i3), t3.instance = i3);
      case `void`:
        return null;
      default:
        throw Error(a2(443, t3.type));
    }
    else t3.type === `stylesheet` && !(t3.state.loading & 4) && (r3 = t3.instance, t3.state.loading |= 4, Vm(r3, n2.precedence, e3));
    return t3.instance;
  }
  function Vm(e3, t3, n2) {
    for (var r3 = n2.querySelectorAll(`link[rel="stylesheet"][data-precedence],style[data-precedence]`), i3 = r3.length ? r3[r3.length - 1] : null, a3 = i3, o3 = 0; o3 < r3.length; o3++) {
      var s3 = r3[o3];
      if (s3.dataset.precedence === t3) a3 = s3;
      else if (a3 !== i3) break;
    }
    a3 ? a3.parentNode.insertBefore(e3, a3.nextSibling) : (t3 = n2.nodeType === 9 ? n2.head : n2, t3.insertBefore(e3, t3.firstChild));
  }
  function Hm(e3, t3) {
    e3.crossOrigin ??= t3.crossOrigin, e3.referrerPolicy ??= t3.referrerPolicy, e3.title ??= t3.title;
  }
  function Um(e3, t3) {
    e3.crossOrigin ??= t3.crossOrigin, e3.referrerPolicy ??= t3.referrerPolicy, e3.integrity ??= t3.integrity;
  }
  var Wm = null;
  function Gm(e3, t3, n2) {
    if (Wm === null) {
      var r3 = /* @__PURE__ */ new Map(), i3 = Wm = /* @__PURE__ */ new Map();
      i3.set(n2, r3);
    } else i3 = Wm, r3 = i3.get(n2), r3 || (r3 = /* @__PURE__ */ new Map(), i3.set(n2, r3));
    if (r3.has(e3)) return r3;
    for (r3.set(e3, null), n2 = n2.getElementsByTagName(e3), i3 = 0; i3 < n2.length; i3++) {
      var a3 = n2[i3];
      if (!(a3[Vt] || a3[Pt] || e3 === `link` && a3.getAttribute(`rel`) === `stylesheet`) && a3.namespaceURI !== `http://www.w3.org/2000/svg`) {
        var o3 = a3.getAttribute(t3) || ``;
        o3 = e3 + o3;
        var s3 = r3.get(o3);
        s3 ? s3.push(a3) : r3.set(o3, [a3]);
      }
    }
    return r3;
  }
  function Km(e3, t3, n2) {
    e3 = e3.ownerDocument || e3, e3.head.insertBefore(n2, t3 === `title` ? e3.querySelector(`head > title`) : null);
  }
  function qm(e3, t3, n2) {
    if (n2 === 1 || t3.itemProp != null) return false;
    switch (e3) {
      case `meta`:
      case `title`:
        return true;
      case `style`:
        if (typeof t3.precedence != `string` || typeof t3.href != `string` || t3.href === ``) break;
        return true;
      case `link`:
        if (typeof t3.rel != `string` || typeof t3.href != `string` || t3.href === `` || t3.onLoad || t3.onError) break;
        switch (t3.rel) {
          case `stylesheet`:
            return e3 = t3.disabled, typeof t3.precedence == `string` && e3 == null;
          default:
            return true;
        }
      case `script`:
        if (t3.async && typeof t3.async != `function` && typeof t3.async != `symbol` && !t3.onLoad && !t3.onError && t3.src && typeof t3.src == `string`) return true;
    }
    return false;
  }
  function Jm(e3, t3) {
    return e3 === `img` && t3.src != null && t3.src !== `` && t3.onLoad == null && t3.loading !== `lazy`;
  }
  function Ym(e3) {
    return !(e3.type === `stylesheet` && !(e3.state.loading & 3));
  }
  function Xm(e3) {
    return (e3.width || 100) * (e3.height || 100) * (typeof devicePixelRatio == `number` ? devicePixelRatio : 1) * 0.25;
  }
  function Zm(e3, t3) {
    typeof t3.decode == `function` && (e3.imgCount++, t3.complete || (e3.imgBytes += Xm(t3), e3.suspenseyImages.push(t3)), e3 = rh.bind(e3), t3.decode().then(e3, e3));
  }
  function Qm(e3, t3, n2, r3) {
    if (n2.type === `stylesheet` && (typeof r3.media != `string` || false !== matchMedia(r3.media).matches) && !(n2.state.loading & 4)) {
      if (n2.instance === null) {
        var i3 = Pm(r3.href), a3 = t3.querySelector(Fm(i3));
        if (a3) {
          t3 = a3._p, typeof t3 == `object` && t3 && typeof t3.then == `function` && (e3.count++, e3 = nh.bind(e3), t3.then(e3, e3)), n2.state.loading |= 4, n2.instance = a3, D(a3);
          return;
        }
        a3 = t3.ownerDocument || t3, r3 = Im(r3), (i3 = vm.get(i3)) && Hm(r3, i3), a3 = a3.createElement(`link`), D(a3);
        var o3 = a3;
        o3._p = new Promise(function(e4, t4) {
          o3.onload = e4, o3.onerror = t4;
        }), np(a3, `link`, r3), n2.instance = a3;
      }
      e3.stylesheets === null && (e3.stylesheets = /* @__PURE__ */ new Map()), e3.stylesheets.set(n2, t3), (t3 = n2.state.preload) && !(n2.state.loading & 3) && (e3.count++, n2 = nh.bind(e3), t3.addEventListener(`load`, n2), t3.addEventListener(`error`, n2));
    }
  }
  var $m = 0;
  function eh(e3, t3) {
    return e3.stylesheets && e3.count === 0 && ah(e3, e3.stylesheets), 0 < e3.count || 0 < e3.imgCount ? function(n2) {
      var r3 = setTimeout(function() {
        if (e3.stylesheets && ah(e3, e3.stylesheets), e3.unsuspend) {
          var t4 = e3.unsuspend;
          e3.unsuspend = null, t4();
        }
      }, 6e4 + t3);
      0 < e3.imgBytes && $m === 0 && ($m = 62500 * op());
      var i3 = setTimeout(function() {
        if (e3.waitingForImages = false, e3.count === 0 && (e3.stylesheets && ah(e3, e3.stylesheets), e3.unsuspend)) {
          var t4 = e3.unsuspend;
          e3.unsuspend = null, t4();
        }
      }, (e3.imgBytes > $m ? 50 : 800) + t3);
      return e3.unsuspend = n2, function() {
        e3.unsuspend = null, clearTimeout(r3), clearTimeout(i3);
      };
    } : null;
  }
  function th(e3) {
    if (e3.count === 0 && (e3.imgCount === 0 || !e3.waitingForImages)) {
      if (e3.stylesheets) ah(e3, e3.stylesheets);
      else if (e3.unsuspend) {
        var t3 = e3.unsuspend;
        e3.unsuspend = null, t3();
      }
    }
  }
  function nh() {
    this.count--, th(this);
  }
  function rh() {
    this.imgCount--, th(this);
  }
  var ih = null;
  function ah(e3, t3) {
    e3.stylesheets = null, e3.unsuspend !== null && (e3.count++, ih = /* @__PURE__ */ new Map(), t3.forEach(oh, e3), ih = null, nh.call(e3));
  }
  function oh(e3, t3) {
    if (!(t3.state.loading & 4)) {
      var n2 = ih.get(e3);
      if (n2) var r3 = n2.get(null);
      else {
        n2 = /* @__PURE__ */ new Map(), ih.set(e3, n2);
        for (var i3 = e3.querySelectorAll(`link[data-precedence],style[data-precedence]`), a3 = 0; a3 < i3.length; a3++) {
          var o3 = i3[a3];
          (o3.nodeName === `LINK` || o3.getAttribute(`media`) !== `not all`) && (n2.set(o3.dataset.precedence, o3), r3 = o3);
        }
        r3 && n2.set(null, r3);
      }
      i3 = t3.instance, o3 = i3.getAttribute(`data-precedence`), a3 = n2.get(o3) || r3, a3 === r3 && n2.set(null, i3), n2.set(o3, i3), this.count++, r3 = nh.bind(this), i3.addEventListener(`load`, r3), i3.addEventListener(`error`, r3), a3 ? a3.parentNode.insertBefore(i3, a3.nextSibling) : (e3 = e3.nodeType === 9 ? e3.head : e3, e3.insertBefore(i3, e3.firstChild)), t3.state.loading |= 4;
    }
  }
  var sh = { $$typeof: S, Provider: null, Consumer: null, _currentValue: De, _currentValue2: De, _threadCount: 0 };
  function ch(e3, t3, n2, r3, i3, a3, o3, s3, c3) {
    this.tag = 1, this.containerInfo = e3, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = Ct(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Ct(0), this.hiddenUpdates = Ct(null), this.identifierPrefix = r3, this.onUncaughtError = i3, this.onCaughtError = a3, this.onRecoverableError = o3, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = c3, this.transitionTypes = null, this.incompleteTransitions = /* @__PURE__ */ new Map();
  }
  function lh(e3, t3, n2, r3, i3, a3, o3, s3, c3, l3, u3, d3) {
    return e3 = new ch(e3, t3, n2, o3, c3, l3, u3, d3, s3), t3 = 1, true === a3 && (t3 |= 24), a3 = Ui(3, null, null, t3), e3.current = a3, a3.stateNode = e3, t3 = Va(), t3.refCount++, e3.pooledCache = t3, t3.refCount++, a3.memoizedState = { element: r3, isDehydrated: n2, cache: t3 }, wo(a3), e3;
  }
  function uh(e3) {
    return e3 ? (e3 = Vi, e3) : Vi;
  }
  function dh(e3, t3, n2, r3, i3, a3) {
    i3 = uh(i3), r3.context === null ? r3.context = i3 : r3.pendingContext = i3, r3 = Eo(t3), r3.payload = { element: n2 }, a3 = a3 === void 0 ? null : a3, a3 !== null && (r3.callback = a3), n2 = Do(e3, r3, t3), n2 !== null && (Pd(n2, e3, t3), Oo(n2, e3, t3));
  }
  function fh(e3, t3) {
    if (e3 = e3.memoizedState, e3 !== null && e3.dehydrated !== null) {
      var n2 = e3.retryLane;
      e3.retryLane = n2 !== 0 && n2 < t3 ? n2 : t3;
    }
  }
  function ph(e3, t3) {
    fh(e3, t3), (e3 = e3.alternate) && fh(e3, t3);
  }
  function mh(e3) {
    if (e3.tag === 13 || e3.tag === 31) {
      var t3 = Ri(e3, 67108864);
      t3 !== null && Pd(t3, e3, 67108864), ph(e3, 67108864);
    }
  }
  function hh(e3) {
    if (e3.tag === 13 || e3.tag === 31) {
      var t3 = jd();
      t3 = kt(t3);
      var n2 = Ri(e3, t3);
      n2 !== null && Pd(n2, e3, t3), ph(e3, t3);
    }
  }
  var gh = true;
  function _h(e3, t3, n2, r3) {
    var i3 = w.T;
    w.T = null;
    var a3 = T.p;
    try {
      T.p = 2, yh(e3, t3, n2, r3);
    } finally {
      T.p = a3, w.T = i3;
    }
  }
  function vh(e3, t3, n2, r3) {
    var i3 = w.T;
    w.T = null;
    var a3 = T.p;
    try {
      T.p = 8, yh(e3, t3, n2, r3);
    } finally {
      T.p = a3, w.T = i3;
    }
  }
  function yh(e3, t3, n2, r3) {
    if (gh) {
      var i3 = bh(r3);
      if (i3 === null) Kf(e3, t3, r3, xh, n2), Mh(e3, r3);
      else if (Ph(i3, e3, t3, n2, r3)) r3.stopPropagation();
      else if (Mh(e3, r3), t3 & 4 && -1 < jh.indexOf(e3)) {
        for (; i3 !== null; ) {
          var a3 = Gt(i3);
          if (a3 !== null) switch (a3.tag) {
            case 3:
              if (a3 = a3.stateNode, a3.current.memoizedState.isDehydrated) {
                var o3 = _t(a3.pendingLanes);
                if (o3 !== 0) {
                  var s3 = a3;
                  for (s3.pendingLanes |= 2, s3.entangledLanes |= 2; o3; ) {
                    var c3 = 1 << 31 - ut(o3);
                    s3.entanglements[1] |= c3, o3 &= ~c3;
                  }
                  Ef(a3), !(W & 6) && (_d = Qe() + 500, Df(0, false));
                }
              }
              break;
            case 31:
            case 13:
              s3 = Ri(a3, 2), s3 !== null && Pd(s3, a3, 2), zd(), ph(a3, 2);
          }
          if (a3 = bh(r3), a3 === null && Kf(e3, t3, r3, xh, n2), a3 === i3) break;
          i3 = a3;
        }
        i3 !== null && r3.stopPropagation();
      } else Kf(e3, t3, r3, null, n2);
    }
  }
  function bh(e3) {
    return e3 = jn(e3), Sh(e3);
  }
  var xh = null;
  function Sh(e3) {
    if (xh = null, e3 = Wt(e3), e3 !== null) {
      var t3 = s2(e3);
      if (t3 === null) e3 = null;
      else {
        var n2 = t3.tag;
        if (n2 === 13) {
          if (e3 = c2(t3), e3 !== null) return e3;
          e3 = null;
        } else if (n2 === 31) {
          if (e3 = l2(t3), e3 !== null) return e3;
          e3 = null;
        } else if (n2 === 3) {
          if (t3.stateNode.current.memoizedState.isDehydrated) return t3.tag === 3 ? t3.stateNode.containerInfo : null;
          e3 = null;
        } else t3 !== e3 && (e3 = null);
      }
    }
    return xh = e3, null;
  }
  function Ch(e3) {
    switch (e3) {
      case `beforetoggle`:
      case `cancel`:
      case `click`:
      case `close`:
      case `contextmenu`:
      case `copy`:
      case `cut`:
      case `auxclick`:
      case `dblclick`:
      case `dragend`:
      case `dragstart`:
      case `drop`:
      case `focusin`:
      case `focusout`:
      case `input`:
      case `invalid`:
      case `keydown`:
      case `keypress`:
      case `keyup`:
      case `mousedown`:
      case `mouseup`:
      case `paste`:
      case `pause`:
      case `play`:
      case `pointercancel`:
      case `pointerdown`:
      case `pointerup`:
      case `ratechange`:
      case `reset`:
      case `seeked`:
      case `submit`:
      case `toggle`:
      case `touchcancel`:
      case `touchend`:
      case `touchstart`:
      case `volumechange`:
      case `change`:
      case `selectionchange`:
      case `textInput`:
      case `compositionstart`:
      case `compositionend`:
      case `compositionupdate`:
      case `beforeblur`:
      case `afterblur`:
      case `beforeinput`:
      case `blur`:
      case `fullscreenchange`:
      case `fullscreenerror`:
      case `focus`:
      case `hashchange`:
      case `popstate`:
      case `select`:
      case `selectstart`:
        return 2;
      case `drag`:
      case `dragenter`:
      case `dragexit`:
      case `dragleave`:
      case `dragover`:
      case `mousemove`:
      case `mouseout`:
      case `mouseover`:
      case `pointermove`:
      case `pointerout`:
      case `pointerover`:
      case `resize`:
      case `scroll`:
      case `touchmove`:
      case `wheel`:
      case `mouseenter`:
      case `mouseleave`:
      case `pointerenter`:
      case `pointerleave`:
        return 8;
      case `message`:
        switch ($e()) {
          case et:
            return 2;
          case tt:
            return 8;
          case nt:
          case rt:
            return 32;
          case it:
            return 268435456;
          default:
            return 32;
        }
      default:
        return 32;
    }
  }
  var wh = false, Th = null, Eh = null, Dh = null, Oh = /* @__PURE__ */ new Map(), kh = /* @__PURE__ */ new Map(), Ah = [], jh = `mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset`.split(` `);
  function Mh(e3, t3) {
    switch (e3) {
      case `focusin`:
      case `focusout`:
        Th = null;
        break;
      case `dragenter`:
      case `dragleave`:
        Eh = null;
        break;
      case `mouseover`:
      case `mouseout`:
        Dh = null;
        break;
      case `pointerover`:
      case `pointerout`:
        Oh.delete(t3.pointerId);
        break;
      case `gotpointercapture`:
      case `lostpointercapture`:
        kh.delete(t3.pointerId);
    }
  }
  function Nh(e3, t3, n2, r3, i3, a3) {
    return e3 === null || e3.nativeEvent !== a3 ? (e3 = { blockedOn: t3, domEventName: n2, eventSystemFlags: r3, nativeEvent: a3, targetContainers: [i3] }, t3 !== null && (t3 = Gt(t3), t3 !== null && mh(t3)), e3) : (e3.eventSystemFlags |= r3, t3 = e3.targetContainers, i3 !== null && t3.indexOf(i3) === -1 && t3.push(i3), e3);
  }
  function Ph(e3, t3, n2, r3, i3) {
    switch (t3) {
      case `focusin`:
        return Th = Nh(Th, e3, t3, n2, r3, i3), true;
      case `dragenter`:
        return Eh = Nh(Eh, e3, t3, n2, r3, i3), true;
      case `mouseover`:
        return Dh = Nh(Dh, e3, t3, n2, r3, i3), true;
      case `pointerover`:
        var a3 = i3.pointerId;
        return Oh.set(a3, Nh(Oh.get(a3) || null, e3, t3, n2, r3, i3)), true;
      case `gotpointercapture`:
        return a3 = i3.pointerId, kh.set(a3, Nh(kh.get(a3) || null, e3, t3, n2, r3, i3)), true;
    }
    return false;
  }
  function Fh(e3) {
    var t3 = Wt(e3.target);
    if (t3 !== null) {
      var n2 = s2(t3);
      if (n2 !== null) {
        if (t3 = n2.tag, t3 === 13) {
          if (t3 = c2(n2), t3 !== null) {
            e3.blockedOn = t3, Mt(e3.priority, function() {
              hh(n2);
            });
            return;
          }
        } else if (t3 === 31) {
          if (t3 = l2(n2), t3 !== null) {
            e3.blockedOn = t3, Mt(e3.priority, function() {
              hh(n2);
            });
            return;
          }
        } else if (t3 === 3 && n2.stateNode.current.memoizedState.isDehydrated) {
          e3.blockedOn = n2.tag === 3 ? n2.stateNode.containerInfo : null;
          return;
        }
      }
    }
    e3.blockedOn = null;
  }
  function Ih(e3) {
    if (e3.blockedOn !== null) return false;
    for (var t3 = e3.targetContainers; 0 < t3.length; ) {
      var n2 = bh(e3.nativeEvent);
      if (n2 === null) {
        n2 = e3.nativeEvent;
        var r3 = new n2.constructor(n2.type, n2);
        An = r3, n2.target.dispatchEvent(r3), An = null;
      } else return t3 = Gt(n2), t3 !== null && mh(t3), e3.blockedOn = n2, false;
      t3.shift();
    }
    return true;
  }
  function Lh(e3, t3, n2) {
    Ih(e3) && n2.delete(t3);
  }
  function Rh() {
    wh = false, Th !== null && Ih(Th) && (Th = null), Eh !== null && Ih(Eh) && (Eh = null), Dh !== null && Ih(Dh) && (Dh = null), Oh.forEach(Lh), kh.forEach(Lh);
  }
  function zh(e3, n2) {
    e3.blockedOn === n2 && (e3.blockedOn = null, wh || (wh = true, t2.unstable_scheduleCallback(t2.unstable_NormalPriority, Rh)));
  }
  var Bh = null;
  function Vh(e3) {
    Bh !== e3 && (Bh = e3, t2.unstable_scheduleCallback(t2.unstable_NormalPriority, function() {
      Bh === e3 && (Bh = null);
      for (var t3 = 0; t3 < e3.length; t3 += 3) {
        var n2 = e3[t3], r3 = e3[t3 + 1], i3 = e3[t3 + 2];
        if (typeof r3 != `function`) {
          if (Sh(r3 || n2) === null) continue;
          break;
        }
        var a3 = Gt(n2);
        a3 !== null && (e3.splice(t3, 3), t3 -= 3, sc(a3, { pending: true, data: i3, method: n2.method, action: r3 }, r3, i3));
      }
    }));
  }
  function Hh(e3) {
    function t3(t4) {
      return zh(t4, e3);
    }
    Th !== null && zh(Th, e3), Eh !== null && zh(Eh, e3), Dh !== null && zh(Dh, e3), Oh.forEach(t3), kh.forEach(t3);
    for (var n2 = 0; n2 < Ah.length; n2++) {
      var r3 = Ah[n2];
      r3.blockedOn === e3 && (r3.blockedOn = null);
    }
    for (; 0 < Ah.length && (n2 = Ah[0], n2.blockedOn === null); ) Fh(n2), n2.blockedOn === null && Ah.shift();
    if (n2 = (e3.ownerDocument || e3).$$reactFormReplay, n2 != null) for (r3 = 0; r3 < n2.length; r3 += 3) {
      var i3 = n2[r3], a3 = n2[r3 + 1], o3 = i3[Ft] || null;
      if (typeof a3 == `function`) o3 || Vh(n2);
      else if (o3) {
        var s3 = null;
        if (a3 && a3.hasAttribute(`formAction`)) {
          if (i3 = a3, o3 = a3[Ft] || null) s3 = o3.formAction;
          else if (Sh(i3) !== null) continue;
        } else s3 = o3.action;
        typeof s3 == `function` ? n2[r3 + 1] = s3 : (n2.splice(r3, 3), r3 -= 3), Vh(n2);
      }
    }
  }
  function Uh() {
    function e3(e4) {
      e4.canIntercept && e4.info === `react-transition` && e4.intercept({ handler: function() {
        return new Promise(function(e5) {
          return i3 = e5;
        });
      }, focusReset: `manual`, scroll: `manual` });
    }
    function t3() {
      i3 !== null && (i3(), i3 = null), r3 || setTimeout(n2, 20);
    }
    function n2() {
      if (!r3 && !navigation.transition) {
        var e4 = navigation.currentEntry;
        e4 && e4.url != null && navigation.navigate(e4.url, { state: e4.getState(), info: `react-transition`, history: `replace` });
      }
    }
    if (typeof navigation == `object`) {
      var r3 = false, i3 = null;
      return navigation.addEventListener(`navigate`, e3), navigation.addEventListener(`navigatesuccess`, t3), navigation.addEventListener(`navigateerror`, t3), setTimeout(n2, 100), function() {
        r3 = true, navigation.removeEventListener(`navigate`, e3), navigation.removeEventListener(`navigatesuccess`, t3), navigation.removeEventListener(`navigateerror`, t3), i3 !== null && (i3(), i3 = null);
      };
    }
  }
  function Wh(e3) {
    this._internalRoot = e3;
  }
  Gh.prototype.render = Wh.prototype.render = function(e3) {
    var t3 = this._internalRoot;
    if (t3 === null) throw Error(a2(409));
    var n2 = t3.current;
    dh(n2, jd(), e3, t3, null, null);
  }, Gh.prototype.unmount = Wh.prototype.unmount = function() {
    var e3 = this._internalRoot;
    if (e3 !== null) {
      this._internalRoot = null;
      var t3 = e3.containerInfo;
      dh(e3.current, 2, null, e3, null, null), zd(), t3[It] = null;
    }
  };
  function Gh(e3) {
    this._internalRoot = e3;
  }
  Gh.prototype.unstable_scheduleHydration = function(e3) {
    if (e3) {
      var t3 = jt();
      e3 = { blockedOn: null, target: e3, priority: t3 };
      for (var n2 = 0; n2 < Ah.length && t3 !== 0 && t3 < Ah[n2].priority; n2++) ;
      Ah.splice(n2, 0, e3), n2 === 0 && Fh(e3);
    }
  };
  var Kh = r2.version;
  if (Kh !== `19.3.0`) throw Error(a2(527, Kh, `19.3.0`));
  T.findDOMNode = function(e3) {
    var t3 = e3._reactInternals;
    if (t3 === void 0) throw typeof e3.render == `function` ? Error(a2(188)) : (e3 = Object.keys(e3).join(`,`), Error(a2(268, e3)));
    return e3 = d2(t3), e3 = e3 === null ? null : f2(e3), e3 = e3 === null ? null : e3.stateNode, e3;
  };
  var qh = { bundleType: 0, version: `19.3.0`, rendererPackageName: `react-dom`, currentDispatcherRef: w, reconcilerVersion: `19.3.0` };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < `u`) {
    var Jh = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Jh.isDisabled && Jh.supportsFiber) try {
      st = Jh.inject(qh), ct = Jh;
    } catch {
    }
  }
  e2.createRoot = function(e3, t3) {
    if (!o2(e3)) throw Error(a2(299));
    var n2 = false, r3 = ``, i3 = Ac, s3 = jc, c3 = Mc;
    return t3 != null && (true === t3.unstable_strictMode && (n2 = true), t3.identifierPrefix !== void 0 && (r3 = t3.identifierPrefix), t3.onUncaughtError !== void 0 && (i3 = t3.onUncaughtError), t3.onCaughtError !== void 0 && (s3 = t3.onCaughtError), t3.onRecoverableError !== void 0 && (c3 = t3.onRecoverableError)), t3 = lh(e3, 1, false, null, null, n2, r3, null, i3, s3, c3, Uh), e3[It] = t3.current, Wf(e3), new Wh(t3);
  };
})), ue = e(((e2, t2) => {
  function n2() {
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < `u` && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE == `function`) try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n2);
    } catch (e3) {
      console.error(e3);
    }
  }
  n2(), t2.exports = le();
}));
export {
  n as a,
  re as i,
  ce as n,
  ie as r,
  ue as t
};
