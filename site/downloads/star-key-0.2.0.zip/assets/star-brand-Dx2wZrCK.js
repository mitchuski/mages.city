import { i as e } from "./rolldown-runtime-Dd_uD5pT.js";
import { a as t, i as n, r } from "./theme-pbhxFgxu.js";
var i = e(t(), 1), a = r();
function o({ active: e2 }) {
  let t2 = (0, i.useRef)(null), r2 = (0, i.useRef)(null);
  return (0, i.useEffect)(() => {
    if (t2.current) return r2.current = n(t2.current, { interactive: false }), () => r2.current?.destroy();
  }, []), (0, i.useEffect)(() => {
    r2.current?.setLayers(e2 ? { field: { level: 1 }, sword: { level: 1 }, mage: { level: 1 }, routes: { level: 0.6 }, core: { level: 1 } } : { field: { level: 0.8 }, sword: { level: 0.6, next: true }, mage: { level: 0.6, next: true } });
  }, [e2]), (0, a.jsx)(`canvas`, { ref: t2, role: `img`, "aria-label": e2 ? `Star \xB7 VTA selected locally` : `Star \xB7 no VTA selected`, style: { width: 72, height: 72, display: `block` } });
}
function s() {
  chrome.windows.create({ url: chrome.runtime.getURL(`confirm.html?kind=join`), type: `popup`, width: 520, height: 600 }), window.close();
}
function c({ active: e2 = false }) {
  return (0, a.jsxs)(`header`, { className: `star-brand`, children: [(0, a.jsx)(`div`, { className: e2 ? `star-mini is-active` : `star-mini`, children: (0, a.jsx)(o, { active: e2 }) }), (0, a.jsxs)(`div`, { children: [(0, a.jsx)(`div`, { className: `star-wordmark`, children: `star key` }), (0, a.jsx)(`p`, { children: e2 ? `VTA selected \xB7 your chosen perspective` : `Your boundaries. Your chosen perspective.` })] }), (0, a.jsx)(`a`, { href: `star.html`, target: `_blank`, rel: `noreferrer`, "aria-label": `Inspect and prepare a selected City Key reading`, title: `Inspect a reading before sharing`, children: `\u{1F4E4}` }), (0, a.jsx)(`a`, { href: `hold.html`, target: `_blank`, rel: `noreferrer`, "aria-label": `What the Star holds \u2014 verify a Hold locally`, title: `What the Star holds`, children: `\u{1FAAC}` }), (0, a.jsx)(`button`, { onClick: s, "aria-label": `Join a community \u2014 paste its DID or scan its code`, title: `Join a community`, children: `\u{1F91D}` }), (0, a.jsx)(`button`, { onClick: () => window.close(), "aria-label": `Close Star`, title: `Close Star`, children: `\u2715` })] });
}
export {
  c as t
};
