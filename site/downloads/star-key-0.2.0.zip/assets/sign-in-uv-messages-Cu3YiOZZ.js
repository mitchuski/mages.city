import { t as e } from "./ed25519-CV189T12.js";
import { a as t, i as n, n as r, o as i } from "./verify-DUO6YZuM.js";
function a(e2) {
  let t2 = ``;
  for (let n2 = 0; n2 < e2.length; n2++) t2 += String.fromCharCode(e2[n2] ?? 0);
  return btoa(t2).replaceAll(`+`, `-`).replaceAll(`/`, `_`).replace(/=+$/, ``);
}
var o = /^[A-Za-z0-9_-]*$/;
function s(e2) {
  if (!o.test(e2)) throw Error(`base64urlToBytes: input is not unpadded base64url`);
  if (e2.length % 4 == 1) throw Error(`base64urlToBytes: invalid base64url length`);
  let t2 = (e2 + (e2.length % 4 == 2 ? `==` : e2.length % 4 == 3 ? `=` : ``)).replaceAll(`-`, `+`).replaceAll(`_`, `/`), n2 = atob(t2), r2 = new Uint8Array(n2.length);
  for (let e3 = 0; e3 < n2.length; e3++) r2[e3] = n2.charCodeAt(e3);
  if (a(r2) !== e2) throw Error(`base64urlToBytes: non-canonical base64url encoding`);
  return r2;
}
var c = class extends Error {
  code;
  status;
  details;
  suggestion;
  constructor(e2, t2, n2 = {}) {
    super(t2), this.name = `VtaClientError`, this.code = e2, n2.status !== void 0 && (this.status = n2.status), n2.details !== void 0 && (this.details = n2.details), n2.suggestion !== void 0 && (this.suggestion = n2.suggestion);
  }
}, l = [`e.p.msg.unauthorized`, `e.p.msg.forbidden`, `e.p.msg.notfound`, `e.p.msg.conflict`, `e.p.msg.rate_limited`, `e.p.msg.bad_request`, `e.p.msg.internal`];
function u(e2, t2) {
  return e2 && l.includes(e2) ? e2 : t2 === 401 ? `e.p.msg.unauthorized` : t2 === 403 ? `e.p.msg.forbidden` : t2 === 404 ? `e.p.msg.notfound` : t2 === 409 ? `e.p.msg.conflict` : t2 === 429 ? `e.p.msg.rate_limited` : t2 >= 500 ? `e.p.msg.internal` : `e.p.msg.bad_request`;
}
function d(e2, t2, n2 = ``) {
  let r2 = e2, i2 = u(r2?.error?.code, t2), a2 = r2?.error?.message ?? `${t2} ${n2}`.trim(), o2 = { status: t2 };
  return r2?.error?.details !== void 0 && (o2.details = r2.error.details), r2?.error?.suggestion !== void 0 && (o2.suggestion = r2.error.suggestion), new c(i2, a2, o2);
}
var f = `x-rate-limit-source`, p = [`vta`, `vtc`, `mediator`, `did-host`], m = 31536e3, ee = 128;
function h(e2, t2) {
  if (e2 === null) return;
  let n2 = e2.trim();
  if (/^\d+$/.test(n2)) return Math.min(Number(n2), m);
  let r2 = Date.parse(n2);
  if (!Number.isNaN(r2)) return Math.min(Math.max(0, Math.ceil((r2 - t2) / 1e3)), m);
}
function te(e2, t2, n2 = Date.now()) {
  let r2 = t2 ?? {}, i2 = r2.error === `rate_limited`, a2 = e2.get(f)?.trim().toLowerCase(), o2 = { source: p.includes(a2 ?? ``) ? a2 : i2 ? `vta` : `upstream` };
  i2 && typeof r2.limiter == `string` && r2.limiter !== `` && (o2.limiter = r2.limiter.slice(0, ee));
  let s2 = h(e2.get(`retry-after`), n2) ?? h(e2.get(`x-ratelimit-after`), n2) ?? (i2 && typeof r2.retryAfterSecs == `number` && r2.retryAfterSecs >= 0 ? Math.min(Math.ceil(r2.retryAfterSecs), m) : void 0);
  return s2 !== void 0 && (o2.retryAfterSecs = s2), o2;
}
var g = { vta: `the agent`, vtc: `the VTC`, mediator: `the mediator`, "did-host": `the DID host`, upstream: `something in front of the agent (a CDN or proxy), not the agent's own limiter` };
function ne(e2, t2, n2 = Date.now()) {
  let r2 = te(e2.headers, t2, n2);
  return new c(`e.p.msg.rate_limited`, `rate limited by ${r2.limiter !== void 0 && r2.source !== `upstream` ? `${g[r2.source]}'s \`${r2.limiter}\` limiter` : g[r2.source]}${r2.retryAfterSecs === void 0 ? `` : ` \u2014 retry after ${r2.retryAfterSecs} s`}`, { status: e2.status, details: { rateLimit: r2 } });
}
var re = `not_found`, ie = `conflict`;
function _(e2) {
  let t2 = e2?.details?.details;
  return typeof t2?.reason == `string` ? t2.reason : void 0;
}
var ae = [`malformedRequest`, `unsupportedType`, `unsupportedVersion`, `expired`, `proofRequired`, `proofInvalid`, `permissionDenied`, `wrongRecipient`, `identityMismatch`, `idConflict`, `cancelled`, `taskFailed`, `unavailable`, `internalError`], oe = { malformed_request: `malformedRequest`, unsupported_type: `unsupportedType`, unsupported_version: `unsupportedVersion`, proof_required: `proofRequired`, proof_invalid: `proofInvalid`, permission_denied: `permissionDenied`, wrong_recipient: `wrongRecipient`, identity_mismatch: `identityMismatch`, id_conflict: `idConflict`, canceled: `cancelled`, task_failed: `taskFailed`, internal_error: `internalError` }, v = new Set(ae);
function y(e2) {
  return v.has(e2) ? e2 : oe[e2] ?? e2;
}
function se(e2) {
  return v.has(y(e2));
}
var ce = `https://trusttasks.org/spec/`, le = [`auth/step-up/approve-response`, `task-consent/decision`, `confirm/response`, `auth/oob/grant`];
function b(e2) {
  if (typeof e2 != `string` || !e2.startsWith(ce) || e2.includes(`#`)) return `authentication`;
  let t2 = e2.slice(28), n2 = /^(.+)\/(\d+)\.(\d+)$/.exec(t2);
  return n2 && le.includes(n2[1]) ? `assertionMethod` : `authentication`;
}
var ue = 6e4;
async function x({ envelope: r2, signing: a2, proofPurpose: o2 = `assertionMethod`, clockSkewMs: s2 = ue }) {
  let c2 = { type: `DataIntegrityProof`, cryptosuite: `eddsa-jcs-2022`, verificationMethod: a2.kid, created: new Date(Date.now() - s2).toISOString(), proofPurpose: o2 }, l2 = { ...r2 };
  delete l2.proof;
  let u2 = await i(t(c2)), d2 = await i(t(l2)), f2 = new Uint8Array(u2.length + d2.length);
  f2.set(u2, 0), f2.set(d2, u2.length);
  let p2 = e.sign(f2, a2.privateKey);
  if (p2.length !== 64) throw Error(`unexpected Ed25519 signature length: ${p2.length} bytes`);
  return c2.proofValue = `z` + n(p2), r2.proof = c2, r2;
}
var de = `https://trusttasks.org/spec/vta/passkey-vms/enroll-challenge/0.1`, fe = `https://trusttasks.org/spec/vta/passkey-vms/enroll-submit/0.1`, pe = `https://trusttasks.org/spec/vta/passkey-vms/list/0.1`, me = `https://trusttasks.org/spec/vta/passkey-vms/revoke/0.1`, he = `https://trusttasks.org/binding/didcomm/0.1/envelope`, ge = `https://trusttasks.org/binding/tsp/0.1/envelope`;
function S(e2) {
  return typeof e2 == `string` && /^https:\/\/trusttasks\.org\/spec\/trust-task-error\/0\.\d+$/.test(e2);
}
var _e = { enrollChallenge: de, enrollSubmit: fe, list: pe, revoke: me };
function C(e2, t2, n2 = {}) {
  return { id: n2.id ?? globalThis.crypto.randomUUID(), type: e2, ...n2.issuer === void 0 ? {} : { issuer: n2.issuer }, ...n2.recipient === void 0 ? {} : { recipient: n2.recipient }, ...n2.threadId === void 0 ? {} : { threadId: n2.threadId }, issuedAt: n2.issuedAt ?? (/* @__PURE__ */ new Date()).toISOString(), ...n2.expiresAt === void 0 ? {} : { expiresAt: n2.expiresAt }, payload: t2 };
}
async function ve(e2, t2, n2) {
  if (n2 !== void 0 && t2.did !== n2) throw new c(`e.client.identity`, `${e2.type}: signed as ${t2.did} but sent as ${n2}. A DIDComm or TSP document must be sent by its signer`);
  if (e2.issuer !== void 0 && e2.issuer !== t2.did) throw new c(`e.client.identity`, `${e2.type}: envelope issuer ${e2.issuer} is not the signing identity ${t2.did}`);
  if (e2.issuer === void 0 && (e2.issuer = t2.did), e2.id ||= globalThis.crypto.randomUUID(), e2.issuedAt ||= (/* @__PURE__ */ new Date()).toISOString(), !e2.recipient) throw new c(`e.client.identity`, `${e2.type}: the document names no recipient. A signed document with no audience is replayable at any other party, and the consumer refuses it`);
  await t2.sign(e2, { proofPurpose: b(e2.type) });
}
function ye(e2) {
  return { did: e2.did, sign: async (t2, n2) => {
    await x({ envelope: t2, signing: e2, proofPurpose: n2?.proofPurpose ?? b(t2.type) });
  } };
}
function be(e2) {
  return `sign` in e2 ? e2 : ye(e2);
}
async function xe(e2, t2, n2 = {}) {
  if (S(e2.type)) return;
  let i2 = n2.proofPurpose ?? `authentication`, a2 = await r(e2, i2 === `any` ? {} : { expectedProofPurpose: i2 });
  if (!a2.verified) throw new c(`e.client.parse`, `the reply from ${t2} is unsigned or its proof does not verify (${a2.reason ?? `no reason given`}). An unsigned answer is bytes, not evidence`);
  if (a2.signer !== t2) throw new c(`e.client.parse`, `the reply claiming to come from ${t2} is signed by ${a2.signer}. The proof verifies, which means somebody really signed it \u2014 just not the agent this channel is talking to`);
}
function Se(e2, t2 = {}) {
  if (S(e2.type)) {
    let t3 = e2.payload ?? {};
    throw new c(w(t3.code), t3.message ?? t3.code ?? `trust-task error`, { details: t3 });
  }
  if (t2.expectedResponseType !== void 0 && e2.type !== t2.expectedResponseType) throw new c(`e.client.parse`, `${t2.operationLabel ?? t2.expectedResponseType}: unexpected response type ${e2.type ?? `(none)`} \u2014 ${JSON.stringify(e2)}`);
  return e2.payload ?? {};
}
function w(e2) {
  let t2 = e2 ?? ``, n2 = y(t2);
  switch (se(n2) ? n2 : y(t2.slice(t2.lastIndexOf(`:`) + 1))) {
    case `permissionDenied`:
      return `e.p.msg.forbidden`;
    case `idConflict`:
      return `e.p.msg.conflict`;
    case `internalError`:
    case `unavailable`:
      return `e.p.msg.internal`;
    default:
      return `e.p.msg.bad_request`;
  }
}
var T = `https://trusttasks.org/spec/vault/sign-trust-task/0.2`, E = `https://trusttasks.org/spec/vault/sign-trust-task/0.2#response`;
async function D(e2, t2) {
  let n2 = C(T, { entryId: t2.entryId, unsignedEnvelope: t2.unsignedEnvelope }, { issuer: t2.holder.did, recipient: t2.service.did });
  return { signedEnvelope: (await e2.send(n2, { expectedResponseType: E, operationLabel: `vault/sign-trust-task/0.2` })).signedEnvelope };
}
var Ce = `https://trusttasks.org/spec/task-consent/decision/0.2`, O = `https://trusttasks.org/spec/device/heartbeat/0.2`, k = `https://trusttasks.org/spec/device/heartbeat/0.2#response`, A = `https://trusttasks.org/spec/device/register/0.2`, j = `https://trusttasks.org/spec/device/register/0.2#response`, we = `org.openvtc.uv-consent`, M = `org.openvtc.uv-key`, Te = `org.openvtc.uv-key-change`, N = `org.openvtc.uv-approvers`;
async function Ee(e2, t2) {
  let { signedEnvelope: n2 } = await D(e2, { holder: t2.holder, service: t2.service, entryId: t2.entryId, unsignedEnvelope: t2.unsignedIdentify });
  return n2;
}
function De(e2) {
  return new TextEncoder().encode(e2);
}
async function Oe(e2) {
  return x({ envelope: C(Ce, { challenge: e2.payloadDigest, payloadDigest: e2.payloadDigest, decision: `approve` }, { issuer: e2.uvKey.did, recipient: e2.vtaDid }), signing: e2.uvKey, proofPurpose: `assertionMethod` });
}
async function ke(e2, t2) {
  let n2 = C(T, { entryId: t2.entryId, unsignedEnvelope: t2.unsignedGrant, ...t2.consent ? { ext: { [we]: t2.consent } } : {} }, { issuer: t2.holder.did, recipient: t2.service.did });
  return (await e2.send(n2, { expectedResponseType: E, operationLabel: `vault/sign-trust-task/0.2 (auth/oob/grant)` })).signedEnvelope;
}
function Ae(e2) {
  return { kind: `prfSealedKey`, did: e2, hardwareBacked: false, biometricGated: false };
}
function je(e2) {
  return { kind: `vtaPin`, salt: a(e2.salt), iterations: e2.iterations, verifier: a(e2.verifier), hardwareBacked: false, biometricGated: false };
}
function Me(e2) {
  return { kind: `remoteApprover`, approver: e2, hardwareBacked: false, biometricGated: false };
}
var Ne = `oobNotEnrolledDevice`, Pe = `oobDeviceDisabled`, Fe = `oobNoUvKey`, Ie = `oobUvInvalid`, Le = `oobUvPinWrong`, Re = `oobUvLocked`, ze = `oobUvPending`, Be = `oobUvDeclined`, Ve = `oobUvExpired`;
function He(e2) {
  return P(e2)?.code;
}
function P(e2) {
  let t2 = e2?.details?.details, n2 = t2?.code;
  if (typeof n2 == `string` && n2.startsWith(`oob`)) return { code: n2, ...F(t2) };
}
function F(e2) {
  let t2 = (e3) => typeof e3 == `number` && Number.isFinite(e3) ? e3 : void 0, n2 = {}, r2 = t2(e2.attemptsRemaining), i2 = t2(e2.lockedUntil), a2 = t2(e2.expiresAt);
  return r2 !== void 0 && (n2.attemptsRemaining = r2), i2 !== void 0 && (n2.lockedUntil = i2), typeof e2.matchCode == `string` && (n2.matchCode = e2.matchCode), a2 !== void 0 && (n2.expiresAt = a2), n2;
}
var I = `uvPinWrong`, L = `uvKeyLocked`, R = `uvKeyChangeProofRequired`, z = `uvKeyChangeProofInvalid`, B = `uvApproverNotPermitted`, Ue = /* @__PURE__ */ new Set([I, L, R, z]);
function We(e2) {
  let t2 = e2, n2 = t2?.details?.details ?? {};
  for (let e3 of [n2.code, t2?.details?.code]) {
    if (typeof e3 != `string`) continue;
    let t3 = e3.slice(e3.lastIndexOf(`:`) + 1);
    if (Ue.has(t3)) return { code: t3, ...F(n2) };
  }
  if (typeof t2?.message == `string` && t2.message.includes(`uvApproverNotPermitted`)) return { code: B };
}
async function Ge(e2, t2) {
  let n2 = { [M]: t2.enrolment, ...t2.changeProof ? { [Te]: { pinProof: t2.changeProof } } : {} }, r2 = { issuer: t2.holder.did, recipient: t2.service.did };
  try {
    let t3 = { ext: n2 };
    await e2.send(C(O, t3, r2), { expectedResponseType: k, operationLabel: `device/heartbeat/0.2 (uv-key)` });
    return;
  } catch (e3) {
    if (_(e3) !== `not_found`) throw e3;
  }
  let i2 = { consumerKind: { kind: `companion`, formFactor: `browser` }, displayName: t2.displayName, ext: { [M]: t2.enrolment } };
  await e2.send(C(A, i2, r2), { expectedResponseType: j, operationLabel: `device/register/0.2 (uv-key)` });
}
async function V(e2, t2, n2, r2) {
  let i2 = Object.keys(n2).length ? { ext: n2 } : {}, a2 = (await e2.send(C(O, i2, { issuer: t2.holder.did, recipient: t2.service.did }), { expectedResponseType: k, operationLabel: `device/heartbeat/0.2 (${r2})` }))?.ext;
  return a2 && typeof a2 == `object` ? a2 : {};
}
function Ke(e2) {
  let t2 = e2[M];
  if (!t2 || typeof t2 != `object` || typeof t2.kind != `string`) return;
  let n2 = (e3) => typeof e3 == `string` ? e3 : void 0, r2 = (e3) => typeof e3 == `number` && Number.isFinite(e3) ? e3 : void 0, i2 = { kind: t2.kind }, a2 = [[`salt`, n2(t2.salt)], [`iterations`, r2(t2.iterations)], [`failedAttempts`, r2(t2.failedAttempts)], [`lockedUntil`, r2(t2.lockedUntil)], [`approver`, n2(t2.approver)], [`did`, n2(t2.did)]];
  for (let [e3, t3] of a2) t3 !== void 0 && (i2[e3] = t3);
  return i2;
}
async function qe(e2, t2) {
  return Ke(await V(e2, t2, {}, `uv-key summary`));
}
async function Je(e2, t2) {
  let n2 = (await V(e2, t2, { [N]: {} }, `uv-approvers`))[N]?.approvers, r2 = [];
  for (let e3 of Array.isArray(n2) ? n2 : []) {
    let t3 = e3;
    typeof t3?.did == `string` && t3.did.startsWith(`did:`) && r2.push({ did: t3.did, ...typeof t3.displayName == `string` ? { displayName: t3.displayName } : {}, ...typeof t3.formFactor == `string` ? { formFactor: t3.formFactor } : {} });
  }
  return r2;
}
var Ye = `org.agentprivacy.myterms`, Xe = `mcnp-draft-01/vtc-join/1`, H = `https://customercommons.org/agreements/`, U = `deliver the service the person asked for, and use their data for that`, W = `first-party analytics (measuring its own service)`, G = `first-party tracking across its own pages and sessions`, K = `first-party profiling (building a picture of the person)`, q = `sharing anonymised data with third parties`, J = `sharing the person's data with third parties`, Y = [{ code: `SD-BASE-DP`, title: `Service delivery, with data portability`, meaning: `Use my data only to deliver the service, and give it back to me when I ask.`, permitted: [U], prohibited: [W, G, K, q, J], obligations: [`give the person their data back in a usable form on request`], url: `${H}SD-BASE-DP` }, { code: `SD-BASE`, title: `Service delivery only`, meaning: `Use my data only to deliver the service. No analytics, tracking, profiling or sharing.`, permitted: [U], prohibited: [W, G, K, q, J], obligations: [], url: `${H}SD-BASE` }, { code: `SD-BASE-A`, title: `Service delivery, with first-party analytics`, meaning: `Deliver the service and measure it. No tracking, profiling or sharing.`, permitted: [U, W], prohibited: [G, K, q, J], obligations: [], url: `${H}SD-BASE-A` }, { code: `SD-BASE-AT`, title: `Service delivery, with analytics and tracking`, meaning: `Deliver the service, measure it and track me across its own pages. No profiling or sharing.`, permitted: [U, W, G], prohibited: [K, q, J], obligations: [], url: `${H}SD-BASE-AT` }, { code: `SD-BASE-ATP`, title: `Service delivery, with analytics, tracking and profiling`, meaning: `Deliver the service, measure it, track me and build a picture of me. No sharing.`, permitted: [U, W, G, K], prohibited: [q, J], obligations: [], url: `${H}SD-BASE-ATP` }, { code: `SD-BASE-ATP-S3P`, title: `Service delivery, with analytics, tracking, profiling and anonymised sharing`, meaning: `Everything above, and anonymised data may be shared with third parties.`, permitted: [U, W, G, K, q], prohibited: [J], obligations: [], url: `${H}SD-BASE-ATP-S3P` }];
function X(e2) {
  if (typeof e2 == `string`) return Y.find((t2) => t2.code === e2);
}
function Z(e2) {
  let t2 = Y.findIndex((t3) => t3.code === e2);
  return t2 < 0 ? 1 / 0 : t2;
}
function Ze(e2) {
  let t2 = e2?.service;
  if (Array.isArray(t2)) for (let e3 of t2) {
    let t3 = e3?.type;
    if (!(t3 === `MyTerms` || Array.isArray(t3) && t3.includes(`MyTerms`))) continue;
    let n2 = e3.serviceEndpoint, r2 = typeof n2 == `string` ? n2 : typeof n2?.uri == `string` ? n2.uri : void 0;
    if (r2) try {
      let e4 = new URL(r2);
      if (e4.protocol === `https:`) return e4.toString();
    } catch {
    }
  }
}
var Q = class extends Error {
  code = `myterms/configuration-invalid`;
};
function Qe(e2, t2) {
  let n2 = (e3) => new Q(`MyTerms configuration at ${t2}: ${e3}`);
  if (!e2 || typeof e2 != `object`) throw n2(`not an object`);
  let r2 = e2.agreements;
  if (!Array.isArray(r2)) throw n2(`no agreements`);
  let i2 = [], a2 = [];
  for (let e3 of r2) {
    let t3 = typeof e3 == `string` ? e3 : e3?.code;
    typeof t3 == `string` && t3.trim() !== `` && (X(t3) ? i2.includes(t3) || i2.push(t3) : a2.includes(t3) || a2.push(t3));
  }
  i2.sort((e3, t3) => Z(e3) - Z(t3));
  let o2 = e2.counterOffer, s2 = e2.agreementsUrl;
  return { endpoint: t2, accepts: i2, unknown: a2, ...typeof o2 == `string` && i2.includes(o2) ? { counterOffer: o2 } : {}, ...typeof s2 == `string` && /^https:\/\//.test(s2) ? { agreementsUrl: s2 } : {} };
}
async function $e(e2, t2 = {}) {
  let n2 = await (t2.fetch ?? globalThis.fetch)(e2, { method: `GET`, headers: { accept: `application/json` }, redirect: `error`, signal: AbortSignal.timeout(t2.timeoutMs ?? 1e4) });
  if (!n2.ok) throw new Q(`MyTerms configuration at ${e2}: HTTP ${n2.status}`);
  return Qe(await n2.json(), e2);
}
function et(e2) {
  let t2 = typeof e2 == `string` ? [e2] : Array.isArray(e2) ? e2 : [], n2 = [];
  for (let e3 of t2) {
    let t3 = X(e3)?.code;
    t3 && !n2.includes(t3) && n2.push(t3);
  }
  return n2;
}
function tt(e2, t2) {
  if (!t2) return { ok: false, reason: `not-offered` };
  if (t2.accepts.length === 0) return { ok: false, reason: `no-match` };
  let n2 = et(e2), r2 = n2.find((e3) => t2.accepts.includes(e3));
  return r2 ? { ok: true, code: r2, counter: false } : { ok: true, code: t2.counterOffer ?? t2.accepts[0], counter: true, ...n2[0] ? { declined: n2[0] } : {} };
}
function nt(e2, t2, n2, r2) {
  let i2 = X(n2);
  if (!i2) throw Error(`not a roster agreement: ${n2}`);
  return { version: `1`, profile: Xe, references: [{ code: i2.code, url: i2.url }], agreementId: globalThis.crypto.randomUUID(), created: Math.floor(r2 / 1e3), ids: [e2, t2], permitted: [...i2.permitted], prohibited: [...i2.prohibited], obligations: [...i2.obligations], validRoles: [`first-party`, `second-party`] };
}
function rt(e2) {
  return { [Ye]: { version: `1`, agreement: e2 } };
}
var $ = `Your phone can't approve for this browser yet. Connect the OpenVTC app on your phone to the same agent, then ask an administrator of the agent to make that phone this browser's approver.`, it = { [I]: `Wrong PIN.`, [L]: `Too many wrong PINs. Try again later.`, [R]: `Your agent needs your current PIN to change how this browser approves.`, [z]: `Your agent couldn't read the PIN check. Try again.`, [B]: $ };
export {
  d as $,
  ke as A,
  w as B,
  Je as C,
  De as D,
  Me as E,
  k as F,
  he as G,
  ve as H,
  O as I,
  x as J,
  ge as K,
  D as L,
  je as M,
  j as N,
  He as O,
  A as P,
  c as Q,
  be as R,
  Ge as S,
  qe as T,
  xe as U,
  Se as V,
  _e as W,
  ie as X,
  b as Y,
  re as Z,
  Re as _,
  $e as a,
  Oe as b,
  et as c,
  Pe as d,
  ne as et,
  Ne as f,
  Ie as g,
  Ve as h,
  nt as i,
  Ee as j,
  P as k,
  tt as l,
  Be as m,
  $ as n,
  s as nt,
  Ze as o,
  Fe as p,
  S as q,
  Y as r,
  a as rt,
  rt as s,
  it as t,
  _ as tt,
  X as u,
  ze as v,
  Ae as w,
  We as x,
  Le as y,
  C as z
};
