import { i as e } from "./rolldown-runtime-Dd_uD5pT.js";
import { t } from "./star-brand-Dx2wZrCK.js";
import { a as n, r, t as i } from "./theme-pbhxFgxu.js";
import { n as a } from "./verify-DUO6YZuM.js";
var o = e(n(), 1), s = i(), c = `agentprivacy.star-hold/1`, l = `star-key/hold@0.1`, u = { "trust-task/eddsa-jcs-2022": `di`, "vc/eddsa-jcs-2022": `di`, "agentprivacy.vta/1": `vta`, "agentprivacy.vrc/1": `vrc`, "vc/ecdsa-secp256k1-2019": `declared`, "vc/ed25519-2020": `declared`, "webauthn-assertion": `declared` };
function d(e2) {
  if (e2 === null) return `null`;
  if (e2 === true) return `true`;
  if (e2 === false) return `false`;
  if (typeof e2 == `number`) {
    if (!Number.isFinite(e2)) throw Error(`JCS rejects non-finite numbers`);
    return Object.is(e2, -0) ? `0` : String(e2);
  }
  if (typeof e2 == `string`) return f(e2);
  if (Array.isArray(e2)) return `[` + e2.map(d).join(`,`) + `]`;
  if (typeof e2 == `object`) {
    let t2 = e2;
    return `{` + Object.keys(t2).sort().map((e3) => f(e3) + `:` + d(t2[e3])).join(`,`) + `}`;
  }
  throw Error(`JCS cannot encode value of type ${typeof e2}`);
}
function f(e2) {
  let t2 = `"`;
  for (let n2 = 0; n2 < e2.length; n2++) {
    let r2 = e2.charCodeAt(n2);
    t2 += r2 === 34 ? `\\"` : r2 === 92 ? `\\\\` : r2 === 8 ? `\\b` : r2 === 12 ? `\\f` : r2 === 10 ? `\\n` : r2 === 13 ? `\\r` : r2 === 9 ? `\\t` : r2 < 32 ? `\\u` + r2.toString(16).padStart(4, `0`) : e2[n2];
  }
  return t2 + `"`;
}
function p(e2) {
  if (typeof e2 != `object` || !e2) return JSON.stringify(e2);
  if (Array.isArray(e2)) return `[` + e2.map(p).join(`,`) + `]`;
  let t2 = e2;
  return `{` + Object.keys(t2).sort().map((e3) => JSON.stringify(e3) + `:` + p(t2[e3])).join(`,`) + `}`;
}
var m = new TextEncoder(), h = (e2) => [...new Uint8Array(e2)].map((e3) => e3.toString(16).padStart(2, `0`)).join(``), g = (e2) => new Uint8Array((e2.match(/../g) ?? []).map((e3) => parseInt(e3, 16))), _ = async (e2) => h(await crypto.subtle.digest(`SHA-256`, typeof e2 == `string` ? m.encode(e2) : new Uint8Array(e2))), v = async (e2) => {
  let t2 = { ...e2 };
  return delete t2.kappa, `sha256:` + await _(p(t2));
}, y = async (e2) => `sha256:` + await _(e2), b = (e2, t2) => typeof e2 == `string` && RegExp(`^[0-9a-f]{${t2}}$`, `i`).test(e2);
function x(e2) {
  let t2 = e2.envelope.replace(/-/g, `+`).replace(/_/g, `/`), n2 = atob(t2 + `=`.repeat((4 - t2.length % 4) % 4));
  return Uint8Array.from(n2, (e3) => e3.charCodeAt(0));
}
async function S(e2) {
  let t2 = [...e2].sort();
  if (!t2.length) return null;
  for (; t2.length > 1; ) {
    let e3 = [];
    for (let n2 = 0; n2 < t2.length; n2 += 2) {
      let r2 = t2[n2], i2 = t2[n2 + 1];
      e3.push(i2 === void 0 ? r2 : `sha256:` + await _(r2 + `|` + i2));
    }
    t2 = e3;
  }
  return t2[0] ?? null;
}
async function C(e2, t2, n2) {
  try {
    let r2 = await crypto.subtle.importKey(`raw`, g(e2), { name: `Ed25519` }, false, [`verify`]);
    return await crypto.subtle.verify({ name: `Ed25519` }, r2, n2, t2);
  } catch {
    return false;
  }
}
var w = `123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz`;
function T(e2) {
  let t2 = 0n;
  for (let n3 of e2) t2 = t2 * 256n + BigInt(n3);
  let n2 = ``;
  for (; t2 > 0n; ) n2 = w[Number(t2 % 58n)] + n2, t2 /= 58n;
  for (let t3 of e2) {
    if (t3 !== 0) break;
    n2 = `1` + n2;
  }
  return n2;
}
var E = (e2) => `did:key:z` + T(new Uint8Array([237, 1, ...g(e2)])), D = (e2) => e2 + `#` + e2.slice(8);
async function O(e2) {
  if (e2.kind !== `agentprivacy.vta/1`) return { state: `unsupported`, reason: `not an agentprivacy.vta/1 record`, signer: null, verificationMethod: null, sigBytes: null, payloadBytes: null };
  let t2 = e2.publicKeyHex, n2 = e2.sig;
  if (!b(t2, 64) || !b(n2, 128)) return { state: `invalid`, reason: `record shape`, signer: null, verificationMethod: null, sigBytes: null, payloadBytes: null };
  let r2 = E(t2);
  if (typeof e2.did == `string` && e2.did !== r2) return { state: `invalid`, reason: `did does not derive from publicKeyHex`, signer: r2, verificationMethod: D(r2), sigBytes: 64, payloadBytes: null };
  let i2 = m.encode(p({ kind: e2.kind, publicKeyHex: t2, kappa: e2.kappa, prior: e2.prior ?? null, at: e2.at, walks: e2.walks ?? 0, vrcs: e2.vrcs ?? [] })), a2 = await C(t2, i2, g(n2));
  return { state: a2 ? `valid` : `invalid`, reason: a2 ? null : `signature verification failed`, signer: r2, verificationMethod: D(r2), sigBytes: 64, payloadBytes: i2.length };
}
async function k(e2) {
  if (e2.kind !== `agentprivacy.vrc/1`) return { state: `unsupported`, reason: `not an agentprivacy.vrc/1 record`, signer: null, verificationMethod: null, sigBytes: null, payloadBytes: null };
  let t2 = e2.parties;
  if (!Array.isArray(t2) || t2.length !== 2 || !t2.every((e3) => b(e3, 64)) || !b(e2.sigA, 128) || !b(e2.sigB, 128)) return { state: `invalid`, reason: `record shape`, signer: null, verificationMethod: null, sigBytes: null, payloadBytes: null };
  let [n2, r2] = t2, i2 = m.encode(p({ kind: e2.kind, parties: t2, intersection: e2.intersection, proverb: e2.proverb, issued: e2.issued })), a2 = await C(n2, i2, g(e2.sigA)), o2 = await C(r2, i2, g(e2.sigB));
  return { state: a2 && o2 ? `valid` : `invalid`, reason: a2 && o2 ? null : `signature verification failed`, signer: E(n2) + `,` + E(r2), verificationMethod: null, sigBytes: 128, payloadBytes: i2.length };
}
async function A(e2) {
  let t2 = e2.proof, n2 = typeof t2?.verificationMethod == `string` ? t2.verificationMethod : null;
  if (t2 && (t2.type !== `DataIntegrityProof` || t2.cryptosuite !== `eddsa-jcs-2022`)) return { state: `unsupported`, reason: `unsupported proof suite: ${String(t2.type)}/${String(t2.cryptosuite)}`, signer: null, verificationMethod: n2, sigBytes: null, payloadBytes: null };
  let r2 = n2 ? n2.slice(0, n2.indexOf(`#`)) : null, i2 = await a(e2);
  if (i2.verified) {
    let t3 = { ...e2 };
    return delete t3.proof, { state: `valid`, reason: null, signer: i2.signer ?? r2, verificationMethod: n2, sigBytes: 64, payloadBytes: m.encode(d(t3)).length };
  }
  return { state: /resolution failed/.test(i2.reason ?? ``) && r2 && !r2.startsWith(`did:key:`) ? `unavailable` : `invalid`, reason: i2.reason ?? `signature verification failed`, signer: i2.signer ?? r2, verificationMethod: n2, sigBytes: null, payloadBytes: null };
}
async function j(e2, t2) {
  let n2 = u[e2], r2 = (e3) => ({ alg: e3?.sigBytes ? `ed25519` : null, sigBytes: e3?.sigBytes ?? null, payloadBytes: e3?.payloadBytes ?? null, envelopeBytes: t2.length });
  if (!n2) return { state: `unsupported`, reason: `unknown profile ${e2}`, signer: null, verificationMethod: null, signed: r2(null) };
  if (n2 === `declared`) return { state: `unsupported`, reason: `profile ${e2} is declared, not verified by ${l}`, signer: null, verificationMethod: null, signed: r2(null) };
  let i2;
  try {
    i2 = JSON.parse(new TextDecoder().decode(t2));
  } catch {
    return { state: `invalid`, reason: `envelope is not JSON`, signer: null, verificationMethod: null, signed: r2(null) };
  }
  let a2 = n2 === `di` ? await A(i2) : n2 === `vta` ? await O(i2) : await k(i2);
  return { state: a2.state, reason: a2.reason, signer: a2.signer, verificationMethod: a2.verificationMethod, signed: r2(a2) };
}
var M = (e2) => m.encode(p({ kind: e2.kind, bearer: e2.bearer, kappa: e2.kappa, root: e2.root, count: e2.count, at: e2.at }));
async function N(e2, { key: t2 = null, now: n2 = /* @__PURE__ */ new Date() } = {}) {
  let r2 = [], i2 = (e3, t3) => (e3 || r2.push(t3), e3);
  i2(e2?.kind === c, `kind`), i2(b(e2?.bearerPublicKeyHex, 64) && e2?.bearer === E(e2.bearerPublicKeyHex), `bearer did does not derive from bearerPublicKeyHex`);
  let a2 = Array.isArray(e2?.items) ? e2.items : [];
  i2(a2.length > 0, `items`);
  let o2 = b(e2?.sig, 128) && b(e2?.bearerPublicKeyHex, 64) && await C(e2.bearerPublicKeyHex, M(e2), g(e2.sig));
  i2(o2, `bearer signature over {kind,bearer,kappa,root,count,at} does not verify`);
  let s2 = true;
  for (let e3 of a2) (typeof e3?.envelope != `string` || await y(x(e3)) !== e3.ref) && (s2 = false);
  i2(s2, `an item ref does not re-derive from its retained bytes`);
  let l2 = await S(a2.map((e3) => e3.ref)), u2 = l2 === e2?.root;
  i2(u2, `root does not re-derive from item refs`), i2(e2?.count === a2.length, `count`);
  let d2 = [];
  for (let e3 of a2) {
    let t3 = await j(e3.profile, x(e3));
    d2.push({ ref: e3.ref, profile: e3.profile, role: e3.role, state: t3.state, reason: t3.reason, signer: t3.signer, signed: t3.signed });
  }
  let f2 = null;
  if (t2) {
    let n3 = t2.holds;
    f2 = await v(t2) === e2?.kappa && (n3 == null || n3.root === e2.root && n3.count === e2.count), i2(f2, `the Hold does not belong to this key (\u03BA or holds{root,count} differ)`);
  }
  let p2 = a2.reduce((e3, t3) => e3 + (t3?.signed?.envelopeBytes ?? 0), 0);
  return { ok: r2.length === 0, bearerSig: o2, root: { derived: l2, stamped: e2?.root ?? null, matches: u2 }, refsMatch: s2, keyChecked: !!t2, keyMatches: f2, items: d2, allValid: d2.length > 0 && d2.every((e3) => e3.state === `valid`), budget: { bytes: e2?.budget?.bytes ?? null, used: p2, fits: e2?.budget?.bytes == null ? null : p2 <= e2.budget.bytes }, checkedAt: n2.toISOString(), why: r2 };
}
function P(e2) {
  return { kind: `agentprivacy.star-hold-projection/1`, bearer: e2.bearer, kappa: e2.kappa, root: e2.root, count: e2.count, at: e2.at, sig: e2.sig, items: e2.items.map((e3) => ({ ref: e3.ref, profile: e3.profile, role: e3.role, signed: e3.signed, verification: { state: e3.verification.state } })) };
}
var F = (e2) => !!e2 && typeof e2 == `object` && !Array.isArray(e2);
function I(e2) {
  if (e2.length > 4194304) throw Error(`Choose a Hold smaller than 4 MiB.`);
  let t2;
  try {
    t2 = JSON.parse(e2);
  } catch {
    throw Error(`The file is not valid JSON.`);
  }
  if (!F(t2)) throw Error(`Expected a Hold object.`);
  if (t2.kind === `agentprivacy.star-hold/1`) return { hold: t2, key: null, source: `hold` };
  if (t2.schema === `star-hold-fixture/1`) {
    if (!F(t2.hold) || t2.hold.kind !== `agentprivacy.star-hold/1`) throw Error(`The fixture carries no Hold of kind ` + c + `.`);
    return { hold: t2.hold, key: F(t2.key) ? t2.key : null, source: `fixture` };
  }
  throw Error(`Not a Star Hold (kind ` + c + `) or a star-hold-fixture/1.`);
}
function L(e2) {
  if (e2.length > 1048576) throw Error(`Choose a key smaller than 1 MiB.`);
  let t2;
  try {
    t2 = JSON.parse(e2);
  } catch {
    throw Error(`The key is not valid JSON.`);
  }
  if (!F(t2) || t2.version !== 1) throw Error(`Expected a City Key v1.`);
  return t2;
}
var R = r(), z = (e2, t2 = 18) => e2 ? e2.length > t2 * 2 ? e2.slice(0, t2) + `\u2026` + e2.slice(-8) : e2 : `\u2014`, B = { valid: `valid`, invalid: `INVALID`, unsupported: `unsupported`, unavailable: `unavailable`, "not-checked": `not checked` };
function V() {
  let e2 = (0, o.useRef)(0), [n2, r2] = (0, o.useState)(null), [i2, a2] = (0, o.useState)(null), [s2, c2] = (0, o.useState)(null), [l2, u2] = (0, o.useState)(null), [d2, f2] = (0, o.useState)(``), [p2, m2] = (0, o.useState)(``);
  async function h2(t2, n3) {
    let r3 = ++e2.current;
    u2(null), f2(``);
    try {
      let i3 = await N(t2, { key: n3 });
      if (r3 !== e2.current) return;
      u2(i3), m2(i3.ok ? `Verified locally. Nothing was sent anywhere.` : `Something did not verify \u2014 read the findings.`);
    } catch (t3) {
      r3 === e2.current && m2(t3 instanceof Error ? t3.message : `The Hold could not be verified.`);
    }
  }
  async function g2(e3) {
    if (e3) try {
      let t2 = I(await e3.text());
      r2(t2.hold), c2(t2.source);
      let n3 = t2.key ?? i2;
      t2.key && a2(t2.key), m2(``), await h2(t2.hold, n3);
    } catch (e4) {
      m2(e4 instanceof Error ? e4.message : `The file could not be read.`);
    }
  }
  async function _2(e3) {
    if (e3) try {
      let t2 = L(await e3.text());
      a2(t2), m2(``), n2 && await h2(n2, t2);
    } catch (e4) {
      m2(e4 instanceof Error ? e4.message : `The key could not be read.`);
    }
  }
  function v2() {
    e2.current++, r2(null), a2(null), c2(null), u2(null), f2(``), m2(`Cleared.`);
  }
  function y2() {
    if (!d2) return;
    let e3 = URL.createObjectURL(new Blob([d2], { type: `application/json` })), t2 = document.createElement(`a`);
    t2.href = e3, t2.download = `star-hold-projection.json`, t2.click(), setTimeout(() => URL.revokeObjectURL(e3), 1e3);
  }
  let b2 = l2?.budget.bytes ? Math.min(100, Math.round(l2.budget.used / l2.budget.bytes * 100)) : 0;
  return (0, R.jsxs)(R.Fragment, { children: [(0, R.jsx)(t, {}), (0, R.jsxs)(`main`, { className: `star-reading`, children: [(0, R.jsx)(`p`, { className: `star-kicker`, children: `WHAT THE STAR HOLDS` }), (0, R.jsx)(`h1`, { children: `Hold what was signed with you.` }), (0, R.jsx)(`p`, { children: `Choose a Hold file. Every item is re-verified here, the refs and the root re-derived, the bearer's signature checked. The key carries only the root and the count; the items stay in this file.` }), (0, R.jsxs)(`div`, { className: `star-grid`, children: [(0, R.jsxs)(`section`, { className: `star-card`, children: [(0, R.jsxs)(`label`, { children: [`Choose a Hold JSON (or the reference fixture)`, (0, R.jsx)(`input`, { "aria-label": `Choose a Hold JSON`, type: `file`, accept: `.json,application/json`, onChange: (e3) => {
    g2(e3.target.files?.[0]), e3.target.value = ``;
  } })] }), (0, R.jsxs)(`label`, { children: [`Optionally, the City Key it belongs to`, (0, R.jsx)(`input`, { "aria-label": `Choose the City Key JSON`, type: `file`, accept: `.json,application/json`, onChange: (e3) => {
    _2(e3.target.files?.[0]), e3.target.value = ``;
  } })] }), (0, R.jsx)(`p`, { role: `status`, children: p2 }), n2 && (0, R.jsxs)(`p`, { className: `star-small`, children: [`Source: `, s2 === `fixture` ? `reference fixture (key included)` : `a bare Hold`, ` \xB7 bearer `, (0, R.jsx)(`code`, { children: z(n2.bearer, 14) }), ` \xB7 \u03BA `, (0, R.jsx)(`code`, { children: z(n2.kappa, 14) }), ` \xB7 at `, n2.at] }), (0, R.jsx)(`button`, { onClick: v2, children: `Clear` })] }), l2 && (0, R.jsxs)(`section`, { className: `star-card`, children: [(0, R.jsx)(`h2`, { children: l2.ok ? `Holds` : `Does not hold` }), (0, R.jsxs)(`p`, { className: `star-small`, children: [`root `, l2.root.matches ? `matches` : `MISMATCH`, ` \xB7 `, (0, R.jsx)(`code`, { children: z(l2.root.derived, 12) }), l2.root.stamped && !l2.root.matches ? (0, R.jsxs)(R.Fragment, { children: [` (stamped `, (0, R.jsx)(`code`, { children: z(l2.root.stamped, 12) }), `)`] }) : null, (0, R.jsx)(`br`, {}), `count `, n2?.count, ` \xB7 refs `, l2.refsMatch ? `match` : `MISMATCH`, ` \xB7 bearer signature `, l2.bearerSig ? `ok` : `FAILED`, ` \xB7 key `, l2.keyChecked ? l2.keyMatches ? `matches holds{root,count}` : `DISAGREES` : `not given`] }), (0, R.jsxs)(`label`, { className: `star-small`, children: [`Budget \xB7 `, l2.budget.used.toLocaleString(), ` of `, l2.budget.bytes?.toLocaleString() ?? `?`, ` bytes`, l2.budget.fits === false ? ` \xB7 OVER` : ``, (0, R.jsx)(`progress`, { max: 100, value: b2, "aria-label": `Hold budget used`, style: { display: `block`, width: `100%` } })] }), (0, R.jsxs)(`table`, { className: `hold-table`, children: [(0, R.jsx)(`thead`, { children: (0, R.jsxs)(`tr`, { children: [(0, R.jsx)(`th`, { children: `item` }), (0, R.jsx)(`th`, { children: `profile` }), (0, R.jsx)(`th`, { children: `role` }), (0, R.jsx)(`th`, { children: `state` }), (0, R.jsx)(`th`, { children: `bytes` }), (0, R.jsx)(`th`, { children: `signer` })] }) }), (0, R.jsx)(`tbody`, { children: l2.items.map((e3) => (0, R.jsxs)(`tr`, { className: `hold-` + e3.state, children: [(0, R.jsx)(`td`, { children: (0, R.jsx)(`code`, { children: z(e3.ref, 8) }) }), (0, R.jsx)(`td`, { children: e3.profile }), (0, R.jsx)(`td`, { children: e3.role }), (0, R.jsxs)(`td`, { children: [B[e3.state], e3.reason ? (0, R.jsxs)(`span`, { className: `star-small`, children: [` \xB7 `, e3.reason] }) : null] }), (0, R.jsx)(`td`, { children: e3.signed.envelopeBytes.toLocaleString() }), (0, R.jsx)(`td`, { children: (0, R.jsx)(`code`, { children: z(e3.signer, 10) }) })] }, e3.ref)) })] }), l2.why.length > 0 && (0, R.jsx)(`ul`, { className: `star-small`, children: l2.why.map((e3, t2) => (0, R.jsx)(`li`, { children: e3 }, t2)) }), (0, R.jsxs)(`p`, { className: `star-small`, children: [l2.allValid ? `Every item is valid.` : `Not every item is valid; states are listed, never averaged.`, ` Checked `, l2.checkedAt, `.`] }), (0, R.jsx)(`button`, { onClick: () => {
    n2 && f2(JSON.stringify(P(n2), null, 2));
  }, children: `Project \xB7 counts and states only` }), d2 && (0, R.jsxs)(R.Fragment, { children: [(0, R.jsx)(`pre`, { children: d2 }), (0, R.jsx)(`button`, { onClick: y2, children: `Download projection` })] }), (0, R.jsx)(`p`, { className: `star-small`, children: `A projection is linkable, not permission. Presenting to a community (k vouches under its root) is not available yet; the runtime says exactly what is missing.` })] })] }), (0, R.jsxs)(`nav`, { children: [(0, R.jsx)(`a`, { href: `star.html`, children: `Read your City Key` }), (0, R.jsx)(`a`, { href: `https://soulbis.com/guide/#hold`, target: `_blank`, rel: `noreferrer`, children: `What the Star holds \u2197` }), (0, R.jsx)(`a`, { href: `https://github.com/mitchuski/agentprivacy-mcp/tree/main/fixtures/star-hold-conformance`, target: `_blank`, rel: `noreferrer`, children: `Conformance pack \u2197` })] }), (0, R.jsx)(`p`, { className: `star-small`, children: `Verifier star-key/hold@0.1 \xB7 the OpenVTC Data Integrity suite through the wallet's own verifier, the agentprivacy record and the bilateral VRC through WebCrypto; declared suites report unsupported, never valid.` })] })] });
}
(0, s.createRoot)(document.getElementById(`root`)).render((0, R.jsx)(V, {}));
