import { i as e } from "./rolldown-runtime-Dd_uD5pT.js";
import { a as t, i as n, r, t as i } from "./theme-pbhxFgxu.js";
import { C as a, E as o, I as s, M as c, N as l, S as u, T as d, _ as f, a as p, b as m, c as h, d as g, g as _, h as v, i as y, j as b, k as x, m as S, n as C, p as w, r as T, s as E, t as D, v as O, w as k, x as A, y as j, z as M } from "./host-permissions-TPtLahe0.js";
import { c as N, r as P, t as F } from "./sign-in-uv-messages-Cu3YiOZZ.js";
import { S as I } from "./didcomm-D5nXYRy6.js";
import { a as L, c as R, m as z, n as B, r as ee, u as te } from "./grant-command-Cj-mgMRw.js";
import { Kt as ne, Mt as re, Nt as V, Ot as ie, Pt as H, Rt as U, St as ae, Wt as oe, Y as W, Yt as G, bt as se, ct as ce, ht as le, jt as K, kt as ue, lt as de, mt as fe, pt as pe, q as me, ut as he, wt as ge, xt as _e, yt as ve } from "./bridge-protocol-DoEW6v30.js";
import { c as q, i as ye, n as be, r as xe, s as Se } from "./vault-panel-CoLPCGvg.js";
var J = e(t(), 1), Ce = i(), Y = r();
function we({ value: e2, onChange: t2, compact: n2 = false }) {
  let r2 = N(e2), i2 = P.map((e3) => e3.code).filter((e3) => !r2.includes(e3)), a2 = [...r2, ...i2], o2 = (e3, n3) => {
    let i3 = r2.indexOf(e3), a3 = i3 + n3;
    if (i3 < 0 || a3 < 0 || a3 >= r2.length) return;
    let o3 = [...r2];
    o3.splice(i3, 1), o3.splice(a3, 0, e3), t2(o3);
  }, s2 = (e3, n3) => {
    t2(n3 ? [...r2, e3] : r2.filter((t3) => t3 !== e3));
  }, c2 = n2 ? 12 : 13;
  return (0, Y.jsx)(`ol`, { "data-testid": `terms-chooser`, style: { margin: 0, padding: 0, listStyle: `none`, display: `grid`, gap: n2 ? 4 : 8 }, children: a2.map((e3) => {
    let t3 = P.find((t4) => t4.code === e3), i3 = r2.indexOf(e3), a3 = i3 >= 0;
    return (0, Y.jsxs)(`li`, { "data-testid": `terms-choice`, "data-code": e3, style: { display: `grid`, gridTemplateColumns: `auto minmax(0, 1fr) auto`, gap: 10, alignItems: `start`, opacity: a3 ? 1 : 0.7 }, children: [(0, Y.jsx)(`input`, { type: `checkbox`, "aria-label": `Present ${e3}`, checked: a3, onChange: (t4) => s2(e3, t4.target.checked), style: { margin: `3px 0 0` } }), (0, Y.jsxs)(`div`, { style: { minWidth: 0, fontSize: c2, lineHeight: 1.45 }, children: [(0, Y.jsxs)(`div`, { children: [a3 ? (0, Y.jsxs)(`span`, { style: { opacity: 0.7 }, children: [i3 + 1, `. `] }) : null, (0, Y.jsx)(`code`, { children: e3 }), ` \u2014 `, t3.title] }), !n2 && (0, Y.jsx)(`div`, { style: { opacity: 0.7 }, children: t3.meaning })] }), (0, Y.jsxs)(`div`, { style: { display: `flex`, gap: 4, visibility: a3 ? `visible` : `hidden` }, children: [(0, Y.jsx)(`button`, { type: `button`, "aria-label": `Move ${e3} up`, disabled: i3 <= 0, onClick: () => o2(e3, -1), style: { font: `inherit`, padding: `0 6px` }, children: `\u2191` }), (0, Y.jsx)(`button`, { type: `button`, "aria-label": `Move ${e3} down`, disabled: i3 < 0 || i3 >= r2.length - 1, onClick: () => o2(e3, 1), style: { font: `inherit`, padding: `0 6px` }, children: `\u2193` })] })] }, e3);
  }) });
}
var Te = `pending-onboard-vta-did`, Ee = { padding: 12, display: `grid`, gap: 8 }, X = { fontFamily: `var(--w-mono)`, fontSize: M.sm, wordBreak: `break-all` };
function De({ onCancel: e2, standalone: t2 = false } = {}) {
  let n2 = ye((e3) => e3.setConnection), [r2, i2] = (0, J.useState)(``), [a2, u2] = (0, J.useState)(`context`), [f2, m2] = (0, J.useState)(``), [h2, g2] = (0, J.useState)(false), [_2, v2] = (0, J.useState)(false), [y2, x2] = (0, J.useState)(null), [C2, w2] = (0, J.useState)(null), [E2, O2] = (0, J.useState)(false), [k2, A2] = (0, J.useState)(null), [j2, N2] = (0, J.useState)(null), [P2, F2] = (0, J.useState)(false), [I2, L2] = (0, J.useState)(false), [R2, te2] = (0, J.useState)(null), [ne2, re2] = (0, J.useState)(null), [V2, ie2] = (0, J.useState)(false), [H2, U2] = (0, J.useState)(``), [ae2, oe2] = (0, J.useState)(null), [W2, G2] = (0, J.useState)(false), [se2, le2] = (0, J.useState)(null), K2 = f2.trim(), ue2 = a2 === `unrestricted` && h2, fe2 = a2 === `context`;
  (0, J.useEffect)(() => {
    (async () => {
      let e3 = (await chrome.storage.session.get(Te))[Te];
      if (typeof e3 != `string` || !e3) return;
      await chrome.storage.session.remove(Te), i2(e3);
      let t3 = z(e3);
      t3 && await T(t3) && me2(e3);
    })();
  }, []), (0, J.useEffect)(() => {
    let e3 = (e4) => {
      let t3 = e4;
      t3?.type === `vta-wallet/onboard-progress` && t3.stage && re2(t3.stage);
    };
    return chrome.runtime.onMessage.addListener(e3), () => chrome.runtime.onMessage.removeListener(e3);
  }, []);
  async function me2(e3) {
    let t3 = (e3 ?? r2).trim();
    O2(true), w2(null), ie2(false), U2(``), F2(false), te2(null);
    try {
      let e4 = d(t3) ? o(t3) : null, n3 = e4 ? e4.authority : z(t3);
      if (n3 && !await p(n3)) {
        w2(`The wallet needs access to ${D(n3)} to look this up. Click Continue again and approve the prompt.`);
        return;
      }
      let r3 = t3;
      if (e4) {
        L2(true);
        try {
          let e5 = await chrome.runtime.sendMessage({ type: pe, name: t3 });
          if (!e5.ok) {
            w2(e5.error);
            return;
          }
          r3 = e5.result.did, te2({ name: e5.result.name.replace(/^https?:\/\//, ``), did: r3 });
        } finally {
          L2(false);
        }
      }
      let i3 = z(r3);
      if (i3 && i3 !== n3 && !await p(i3)) {
        w2(`The wallet needs access to ${D(i3)} to reach this agent. Click Continue again and approve the prompt.`);
        return;
      }
      let s2 = await chrome.runtime.sendMessage({ type: he, vtaDid: r3, adminScope: a2, ...fe2 && K2 ? { context: K2 } : {}, ...a2 === `context` && _2 ? { personaHolder: true } : {} });
      if (!s2.ok) throw Error(s2.error);
      x2(s2.result), a2 === `unrestricted` && ge2();
    } catch (e4) {
      w2(e4 instanceof Error ? e4.message : String(e4));
    } finally {
      O2(false);
    }
  }
  async function ge2() {
    N2(null);
    try {
      let e3 = await chrome.runtime.sendMessage({ type: de });
      if (!e3.ok) {
        N2(e3.error);
        return;
      }
      A2(e3.result.contexts), e3.result.contexts.length === 1 && !f2 && m2(e3.result.contexts[0].id);
    } catch (e3) {
      N2(e3 instanceof Error ? e3.message : String(e3));
    }
  }
  async function _e2(i3) {
    O2(true), w2(null);
    let o2 = i3 ?? K2;
    if (!o2) {
      O2(false), w2(`Pick where this wallet should keep its settings first.`);
      return;
    }
    let s2 = H2.trim();
    re2(`resolving-agent`);
    try {
      let i4 = await chrome.runtime.sendMessage({ type: ce, context: o2, adminScope: a2, ...ue2 ? { createIfMissing: true } : {}, ...s2 ? { mediatorDid: s2 } : {} });
      if (!i4.ok) {
        if (i4.code === `wallet/mediator-required`) {
          ie2(true), w2(null);
          return;
        }
        throw Error(i4.error);
      }
      x2(null);
      let c2 = { vtaDid: r2.trim(), holderDid: i4.result.holderDid, role: i4.result.role, homeContext: i4.result.context, agentScope: i4.result.adminScope, ...y2?.restBaseUrl ? { restBaseUrl: y2.restBaseUrl } : {}, ...y2?.mediatorDid ? { mediatorDid: y2.mediatorDid } : {}, connectedAt: Date.now() };
      if (n2(c2), !t2 && !e2) return;
      i4.result.secretEncrypted ? e2?.() : oe2({ vtaDid: c2.vtaDid, holderDid: c2.holderDid });
    } catch (e3) {
      w2(e3 instanceof Error ? e3.message : String(e3));
    } finally {
      O2(false), re2(null);
    }
  }
  function ve2() {
    y2 && (navigator.clipboard.writeText(y2.command), F2(true));
  }
  function q2() {
    oe2(null), le2(null), e2?.();
  }
  async function be2(e3) {
    G2(true), le2(null);
    try {
      await b(e3.vtaDid), q2();
    } catch (e4) {
      le2(e4 instanceof Error ? e4.message : String(e4));
    } finally {
      G2(false);
    }
  }
  if (ae2) return (0, Y.jsxs)(`div`, { style: Ee, children: [(0, Y.jsx)(`h3`, { style: { margin: 0 }, children: `Wallet onboarded \u2713` }), (0, Y.jsxs)(`small`, { children: [`Your wallet's long-term identity is now `, (0, Y.jsx)(`code`, { style: X, children: ae2.holderDid }), (0, Y.jsx)(S, { value: ae2.holderDid }), `.`] }), (0, Y.jsxs)(`small`, { style: { color: `var(--w-muted)` }, children: [`It's currently stored on this device `, (0, Y.jsx)(`strong`, { children: `without encryption` }), `. Anyone with access to your browser profile can read the key. Encrypt it with your platform authenticator (Touch ID, Windows Hello, hardware key) so an exfiltrated profile can't recover it.`] }), (0, Y.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 8, padding: `8px 0` }, children: [(0, Y.jsx)(`button`, { onClick: () => void be2(ae2), disabled: W2, style: { background: `var(--w-accent)`, color: `var(--w-accent-ink)`, border: `none`, padding: `10px 16px`, borderRadius: 6, fontWeight: 600, fontSize: 13, cursor: W2 ? `default` : `pointer`, flex: 1 }, children: W2 ? `Encrypting\u2026` : `\u{1F510} Encrypt with authenticator` }), (0, Y.jsx)(`span`, { style: { fontSize: 10, fontWeight: 600, color: `var(--w-accent)`, background: `var(--w-accent-soft)`, padding: `2px 6px`, borderRadius: 3, textTransform: `uppercase`, letterSpacing: 0.4 }, title: `Recommended for any wallet you'll use for more than testing`, children: `Recommended` })] }), (0, Y.jsx)(`small`, { style: { color: `var(--w-warn)` }, children: `Heads up: if you lose access to this authenticator without first disabling encryption, the wallet becomes unrecoverable \u2014 the seed is bound to that authenticator's PRF output and can't be retrieved from the browser alone.` }), se2 && (0, Y.jsxs)(`small`, { style: { color: `var(--w-danger)` }, children: [`Couldn't encrypt: `, se2, `. You can retry below, or skip and enable later.`] }), (0, Y.jsx)(`div`, { style: { textAlign: `center`, marginTop: 4 }, children: (0, Y.jsx)(`button`, { onClick: q2, disabled: W2, style: { background: `transparent`, border: `none`, color: `var(--w-muted)`, fontSize: 11, textDecoration: `underline`, cursor: W2 ? `default` : `pointer`, padding: 0 }, children: `Skip for now (leave wallet unencrypted)` }) })] });
  if (y2) {
    let e3 = y2.command;
    return (0, Y.jsxs)(`div`, { style: Ee, children: [(0, Y.jsx)(`h3`, { style: { margin: 0 }, children: `Grant this wallet` }), (0, Y.jsx)(`small`, { children: a2 === `unrestricted` ? (0, Y.jsxs)(Y.Fragment, { children: [`This grants the wallet `, (0, Y.jsx)(`strong`, { children: `the whole agent` }), ` \u2014 it will be able to administer every context, including ones made later.`] }) : (0, Y.jsxs)(Y.Fragment, { children: [`This grants the wallet `, (0, Y.jsx)(`strong`, { children: `one context` }), `:`, ` `, (0, Y.jsx)(`code`, { style: X, children: K2 }), `. It won't be able to see the others.`] }) }), B(a2, _2) && (0, Y.jsxs)(`small`, { children: [`It also grants `, (0, Y.jsx)(`strong`, { children: `your own identity` }), ` \u2014 the attributes and faces above every context (`, (0, Y.jsx)(`code`, { style: X, children: `persona-holder` }), `). No role includes it, so the command names it.`] }), ee(a2, _2) && (0, Y.jsx)(`small`, { style: { color: l.muted }, children: `You'll need to be running this as someone who already has the whole agent \u2014 an admin scoped to one context can't hand out more than they hold.` }), P2 ? (0, Y.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 10, flexWrap: `wrap`, fontSize: M.sm, color: l.muted }, children: [(0, Y.jsx)(`span`, { style: { color: l.ok, fontWeight: 620 }, children: `\u2713 Command copied` }), (0, Y.jsx)(`span`, { children: `Run it as an existing admin, then continue below.` }), (0, Y.jsx)(`button`, { onClick: () => F2(false), style: c(`quiet`), children: `Show again` })] }) : (0, Y.jsxs)(Y.Fragment, { children: [(0, Y.jsx)(`small`, { children: `Run this once as an existing admin (grants a one-time ephemeral key the wallet rotates away on connect):` }), (0, Y.jsx)(`button`, { onClick: ve2, title: `Copy to clipboard`, style: { ...X, display: `block`, width: `100%`, textAlign: `left`, background: l.accentSoft, border: `1px solid ${l.accent}`, padding: `10px 12px`, borderRadius: `var(--w-r-sm)`, cursor: `pointer`, color: l.text }, children: e3 }), (0, Y.jsx)(`div`, { children: (0, Y.jsx)(`button`, { onClick: ve2, style: c(`primary`), children: `Copy command` }) })] }), (0, Y.jsxs)(`small`, { children: [`Transport:`, ` `, y2.mediatorDid ? `DIDComm (authcrypt)` : y2.restBaseUrl ? `REST` : `none`] }), V2 && (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 6, padding: 10, borderLeft: `2px solid ${l.warn}`, background: l.warnSoft, borderRadius: `0 var(--w-r-sm) var(--w-r-sm) 0` }, children: [(0, Y.jsx)(`strong`, { style: { fontSize: M.sm }, children: `This VTA doesn't publish a mediator` }), (0, Y.jsx)(`small`, { style: { color: l.muted, lineHeight: 1.5 }, children: `Onboarding routes through a mediator, and this VTA's record doesn't name one. Enter the mediator it uses \u2014 whoever operates the VTA will have given you the address.` }), (0, Y.jsx)(`input`, { placeholder: `did:webvh:\u2026`, value: H2, onChange: (e4) => U2(e4.target.value), style: X, "aria-label": `Mediator DID` })] }), a2 === `unrestricted` && (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 7, padding: 11, borderLeft: `2px solid ${l.accent}`, background: l.accentSoft, borderRadius: `0 var(--w-r-sm) var(--w-r-sm) 0` }, children: [(0, Y.jsx)(`strong`, { style: { fontSize: M.sm }, children: `Where should this wallet keep its settings?` }), (0, Y.jsx)(`small`, { style: { color: l.muted, lineHeight: 1.5 }, children: `Even managing the whole agent, the wallet's own identity and settings live in one context. Everything it stores for itself goes here.` }), k2 && k2.length > 0 ? (0, Y.jsx)(`div`, { style: { display: `grid`, gap: 4 }, children: k2.map((e4) => (0, Y.jsxs)(`button`, { onClick: () => m2(e4.id), style: { textAlign: `left`, ...f2 === e4.id ? { borderColor: l.accent, background: l.raised } : {} }, children: [(0, Y.jsx)(`span`, { style: X, children: e4.id }), e4.name && e4.name !== e4.id && (0, Y.jsxs)(`span`, { style: { color: l.muted }, children: [` \u2014 `, e4.name] })] }, e4.id)) }) : (0, Y.jsxs)(Y.Fragment, { children: [(0, Y.jsx)(`input`, { placeholder: `ctx_\u2026 (e.g. swordsman, mage)`, value: f2, onChange: (e4) => m2(e4.target.value), "aria-label": `Home context`, style: { ...X, width: `100%` } }), (0, Y.jsx)(`small`, { style: { color: l.muted }, children: k2?.length === 0 ? `This agent has no contexts yet \u2014 name one and tick below to create it.` : `Run the command above first, then Refresh to pick from the agent's own list.` })] }), (0, Y.jsxs)(`div`, { style: { display: `flex`, gap: 8, alignItems: `center`, flexWrap: `wrap` }, children: [(0, Y.jsx)(`button`, { onClick: () => void ge2(), style: c(`quiet`), children: `Refresh list` }), (0, Y.jsxs)(`label`, { style: { fontSize: M.xs, display: `flex`, gap: 6, alignItems: `center` }, children: [(0, Y.jsx)(`input`, { type: `checkbox`, checked: h2, onChange: (e4) => g2(e4.target.checked), style: { width: `auto`, padding: 0 } }), `Create it if it doesn't exist`] })] }), j2 && (0, Y.jsxs)(`small`, { style: { color: l.muted }, children: [`Couldn't read the agent's contexts: `, j2] })] }), (0, Y.jsx)(`button`, { onClick: () => void _e2(), disabled: E2 || !K2 || V2 && H2.trim() === ``, style: { ...c(P2 ? `primary` : `default`), ...E2 || !K2 || V2 && H2.trim() === `` ? { opacity: 0.5, cursor: `default` } : {} }, children: E2 ? `Connecting\u2026` : V2 ? `Connect via this mediator` : `I've run it \u2014 Connect` }), (0, Y.jsx)(`button`, { onClick: () => x2(null), disabled: E2, style: c(), children: `Cancel` }), ne2 && (0, Y.jsx)(Oe, { stage: ne2 }), C2 && (0, Y.jsx)(`small`, { style: { color: l.danger }, children: C2 })] });
  }
  return (0, Y.jsxs)(`div`, { style: Ee, children: [e2 && (0, Y.jsx)(`button`, { onClick: e2, style: { background: `transparent`, border: `none`, color: `var(--w-accent)`, fontSize: 11, cursor: `pointer`, padding: 0, textAlign: `left`, justifySelf: `start` }, children: `\u2190 Back to current VTA` }), (e2 || t2) && (0, Y.jsx)(`h3`, { style: { margin: 0, fontSize: M.md }, children: e2 ? `Add another trust agent` : `Connect to a VTA` }), (0, Y.jsxs)(`label`, { style: { display: `grid`, gap: 5 }, children: [(0, Y.jsx)(`span`, { style: { fontSize: M.sm, fontWeight: 600 }, children: `Agent address` }), (0, Y.jsxs)(`span`, { style: { fontSize: M.xs, color: l.muted }, children: [`A name like `, (0, Y.jsx)(`code`, { children: `webvh.mages.city/@swordsman` }), ` or `, (0, Y.jsx)(`code`, { children: `webvh.mages.city/@mage` }), `, or the full `, (0, Y.jsx)(`code`, { children: `did:webvh:\u2026` })] }), (0, Y.jsx)(`input`, { placeholder: `webvh.mages.city/@mage`, value: r2, onChange: (e3) => i2(e3.target.value), "aria-label": `Agent address`, style: { ...X, width: `100%` } }), r2.trim() !== `` && (0, Y.jsx)(`span`, { style: { fontSize: M.xs, color: l.faint }, children: d(r2) ? o(r2) ? `Reads as an agent name \u2014 the wallet will look up the DID behind it.` : `Looks like a name but isn't valid. Expected host/@name.` : r2.trim().startsWith(`did:`) ? `Reads as a DID.` : `Expected an agent name (host/@name) or a DID.` })] }), R2 && (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 3, padding: `9px 12px`, borderLeft: `2px solid ${l.ok}`, background: l.okSoft, borderRadius: `0 var(--w-r-sm) var(--w-r-sm) 0` }, children: [(0, Y.jsxs)(`span`, { style: { fontSize: M.sm, fontWeight: 620 }, children: [R2.name, ` is confirmed`] }), (0, Y.jsx)(`span`, { style: { fontSize: M.xs, color: l.muted }, children: `That DID's own record claims this name. Connecting to:` }), (0, Y.jsxs)(`span`, { children: [(0, Y.jsx)(`code`, { style: { ...X, fontSize: M.xs }, children: R2.did }), (0, Y.jsx)(S, { value: R2.did })] })] }), (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 8 }, children: [(0, Y.jsx)(`span`, { style: { ...s }, children: `What this wallet will do` }), (0, Y.jsxs)(`label`, { style: { fontSize: M.sm, display: `flex`, gap: 8, alignItems: `flex-start` }, children: [(0, Y.jsx)(`input`, { type: `radio`, name: `admin-scope`, checked: a2 === `context`, onChange: () => {
    u2(`context`), g2(false);
  }, style: { width: `auto`, padding: 0, marginTop: 3 } }), (0, Y.jsxs)(`span`, { children: [`Work inside one context`, (0, Y.jsxs)(`span`, { style: { color: l.muted }, children: [` `, `\u2014 act as yourself in a single context. It can't see the others.`] })] })] }), (0, Y.jsxs)(`label`, { style: { fontSize: M.sm, display: `flex`, gap: 8, alignItems: `flex-start` }, children: [(0, Y.jsx)(`input`, { type: `radio`, name: `admin-scope`, checked: a2 === `unrestricted`, onChange: () => u2(`unrestricted`), style: { width: `auto`, padding: 0, marginTop: 3 } }), (0, Y.jsxs)(`span`, { children: [`Manage the whole agent`, (0, Y.jsxs)(`span`, { style: { color: l.muted }, children: [` `, `\u2014 administer every context from the management console. Needs someone who already has the whole agent to grant it.`] })] })] }), a2 === `context` && (0, Y.jsxs)(`label`, { style: { fontSize: M.sm, display: `flex`, gap: 8, alignItems: `flex-start`, marginTop: 4 }, children: [(0, Y.jsx)(`input`, { type: `checkbox`, checked: _2, onChange: (e3) => v2(e3.target.checked), style: { width: `auto`, padding: 0, marginTop: 3 } }), (0, Y.jsxs)(`span`, { children: [`Also manage your own identity`, (0, Y.jsxs)(`span`, { style: { color: l.muted }, children: [` `, `\u2014 your attributes and faces, which sit above every context. Only someone who has the whole agent can grant this.`] })] })] }), fe2 ? (0, Y.jsxs)(`label`, { style: { display: `grid`, gap: 5, marginTop: 4 }, children: [(0, Y.jsx)(`span`, { style: { fontSize: M.sm, fontWeight: 600 }, children: `Which context?` }), (0, Y.jsx)(`span`, { style: { fontSize: M.xs, color: l.muted }, children: `Where this wallet acts, and where it keeps its own settings. You'll name the same one in the command on the next screen.` }), (0, Y.jsx)(`input`, { placeholder: `ctx_\u2026 (e.g. swordsman, mage)`, value: f2, onChange: (e3) => m2(e3.target.value), "aria-label": `Home context`, style: { ...X, width: `100%` } })] }) : (0, Y.jsx)(`small`, { style: { color: l.faint, marginTop: 2 }, children: `You'll pick where the wallet keeps its own settings on the next screen, from this agent's own list of contexts.` })] }), (0, Y.jsx)(`div`, { children: (0, Y.jsx)(`button`, { onClick: () => void me2(), disabled: !r2.trim() || E2 || fe2 && !K2, style: { ...c(`primary`), ...!r2.trim() || E2 || fe2 && !K2 ? { opacity: 0.5, cursor: `default` } : {} }, children: I2 ? `Looking up the name\u2026` : E2 ? `Resolving\u2026` : `Continue` }) }), C2 && (0, Y.jsx)(`small`, { style: { color: l.danger }, children: C2 })] });
}
function Oe({ stage: e2 }) {
  let t2 = { "resolving-agent": `Looking up your agent`, "connecting-mediator": `Opening a secure channel`, provisioning: `Asking the agent for your identity`, "installing-identity": `Saving it to this browser` }, n2 = me.indexOf(e2);
  return (0, Y.jsx)(`div`, { style: { display: `grid`, gap: 7, padding: `11px 13px`, background: l.accentSoft, borderRadius: `var(--w-r-sm)` }, "aria-live": `polite`, children: me.map((e3, r2) => {
    let i2 = r2 < n2, a2 = r2 === n2;
    return (0, Y.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 9, fontSize: M.sm, color: i2 ? l.muted : a2 ? l.text : l.faint, fontWeight: a2 ? 620 : 400 }, children: [(0, Y.jsx)(`span`, { "aria-hidden": true, style: { width: 14, textAlign: `center`, color: i2 ? l.ok : a2 ? l.accent : l.faint }, children: i2 ? `\u2713` : a2 ? `\u25CB` : `\xB7` }), t2[e3], a2 && (0, Y.jsx)(`span`, { style: { color: l.muted, fontWeight: 400 }, children: `\u2026` })] }, e3);
  }) });
}
var ke = [`field`, `sword`, `mage`, `routes`], Ae = [`the field`, `\u2694\uFE0F the Swordsman`, `\u{1F9D9} the Mage`, `the routes`];
function je({ steps: e2 }) {
  let t2 = (0, J.useRef)(null), r2 = (0, J.useRef)(null), [i2, a2] = (0, J.useState)(true), o2 = e2.filter((e3) => e3 === `done`).length, s2 = e2.length > 0 && o2 === e2.length, c2 = e2.indexOf(`now`), u2 = e2.join(`,`);
  return (0, J.useEffect)(() => {
    if (t2.current) return r2.current = n(t2.current, { onSpinChange: a2 }), a2(r2.current.isSpinning()), () => r2.current?.destroy();
  }, []), (0, J.useEffect)(() => {
    let t3 = {};
    ke.forEach((n2, r3) => {
      let i3 = e2[r3] ?? `pending`;
      t3[n2] = i3 === `done` ? { level: 1 } : i3 === `now` ? { level: 0.7, next: true } : { level: 0 };
    }), t3.core = { level: +!!s2 }, r2.current?.setLayers(t3);
  }, [u2, s2]), (0, Y.jsxs)(`figure`, { style: { margin: 0, display: `grid`, justifyItems: `center`, gap: 6 }, children: [(0, Y.jsx)(`canvas`, { ref: t2, role: `img`, "aria-label": `Star setup: ${o2} of ${e2.length} steps formed. Drag to turn; click to pause.`, style: { width: 200, height: 200, display: `block` } }), (0, Y.jsxs)(`figcaption`, { style: { fontSize: M.xs, color: l.muted, textAlign: `center`, maxWidth: `30ch` }, children: [s2 ? `The star is whole.` : c2 >= 0 ? `Next: ${Ae[c2]} \xB7 ${o2} of ${e2.length} formed` : `${o2} of ${e2.length} formed`, ` \xB7 `, (0, Y.jsx)(`button`, { type: `button`, onClick: () => r2.current?.setSpinning(!i2), "aria-pressed": !i2, style: { background: `none`, border: 0, padding: 0, font: `inherit`, color: l.accent, cursor: `pointer` }, children: i2 ? `pause` : `turn` })] })] });
}
function Me(e2) {
  let [t2, n2] = (0, J.useState)({}), r2 = e2.filter(Boolean).join(`|`);
  return (0, J.useEffect)(() => {
    let e3 = r2.split(`|`).filter(Boolean);
    if (e3.length === 0) {
      n2({});
      return;
    }
    let t3 = false;
    return Promise.all(e3.map(async (e4) => {
      try {
        let t4 = await chrome.runtime.sendMessage({ type: ie, did: e4 });
        if (!t4.ok || !t4.result.resolved) return null;
        let n3 = k(t4.result.alsoKnownAs)[0];
        return n3 ? [e4, n3] : null;
      } catch {
        return null;
      }
    })).then((e4) => {
      t3 || n2(Object.fromEntries(e4.filter((e5) => e5 !== null)));
    }), () => {
      t3 = true;
    };
  }, [r2]), t2;
}
var Ne = [`TSP`, `DIDComm`, `REST`];
function Pe(e2, t2) {
  return t2 === `TSP` ? !!e2.tspMediatorDid : t2 === `DIDComm` ? !!e2.mediatorDid : !!e2.restBaseUrl;
}
function Fe(e2) {
  return Ne.filter((t2) => Pe(e2, t2));
}
function Ie(e2, t2, n2 = {}) {
  for (let r2 of Ne) if (Pe(e2, r2) && (r2 !== `TSP` || t2) && n2[r2]?.state !== `down`) return r2;
}
function Le(e2, t2 = {}) {
  return Fe(e2).filter((e3) => t2[e3]?.state === `down`);
}
function Re(e2 = {}) {
  return Ne.some((t2) => {
    let n2 = e2[t2]?.state;
    return n2 === `up` || n2 === `down`;
  });
}
var ze = { health: {}, sessions: [] };
function Be(e2, t2) {
  let [n2, r2] = (0, J.useState)(ze);
  return (0, J.useEffect)(() => {
    if (!e2) {
      r2(ze);
      return;
    }
    let n3 = true, i2 = async () => {
      try {
        let t3 = await chrome.runtime.sendMessage({ type: ve });
        if (!n3) return;
        r2(t3?.ok ? { health: t3.result.byVta[e2] ?? {}, sessions: t3.result.sessions.filter((t4) => t4.vtaDid === e2) } : ze);
      } catch {
        n3 && r2(ze);
      }
    };
    i2();
    let a2 = t2 ? setInterval(() => void i2(), t2) : void 0;
    return () => {
      n3 = false, a2 !== void 0 && clearInterval(a2);
    };
  }, [e2, t2]), n2;
}
var Ve = class extends Error {
  type;
  constructor(e2) {
    super(`The wallet's background service didn't respond to "${e2}". It may have been restarted, or the extension may need reloading at chrome://extensions.`), this.type = e2, this.name = `NoBackgroundResponse`;
  }
};
async function Z(e2) {
  let t2 = await chrome.runtime.sendMessage(e2);
  if (t2 == null) throw new Ve(e2.type);
  return t2;
}
function He({ n: e2, state: t2, title: n2, children: r2, last: i2 = false }) {
  let a2 = { width: 26, height: 26, borderRadius: `50%`, display: `grid`, placeItems: `center`, fontSize: M.xs, fontWeight: 700, fontVariantNumeric: `tabular-nums`, border: `1px solid ${l.line}`, background: l.raised, color: l.faint, position: `relative`, zIndex: 1, ...t2 === `done` ? { background: l.ok, borderColor: l.ok, color: l.ground } : {}, ...t2 === `now` ? { background: l.accent, borderColor: l.accent, color: l.accentInk } : {} };
  return (0, Y.jsxs)(`div`, { style: { display: `grid`, gridTemplateColumns: `26px 1fr`, gap: `0 14px`, paddingBottom: i2 ? 0 : 22, position: `relative` }, children: [!i2 && (0, Y.jsx)(`span`, { "aria-hidden": true, style: { position: `absolute`, left: 12.5, top: 26, bottom: 0, width: 1, background: l.line } }), (0, Y.jsx)(`span`, { style: a2, children: t2 === `done` ? `\u2713` : e2 }), (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 7, minWidth: 0 }, children: [(0, Y.jsx)(`div`, { style: { fontWeight: 620, fontSize: M.base, color: t2 === `pending` ? l.faint : l.text, paddingTop: 3 }, children: n2 }), r2] })] });
}
function Ue() {
  let e2 = xe(), [t2, n2] = (0, J.useState)(``), [r2, i2] = (0, J.useState)(``), [a2, o2] = (0, J.useState)(false), [s2, c2] = (0, J.useState)(``), [d2, h2] = (0, J.useState)(false), [g2, y2] = (0, J.useState)(null), [x2, S2] = (0, J.useState)(false), [C2, w2] = (0, J.useState)(true), [E2, O2] = (0, J.useState)(null), k2 = (0, J.useCallback)(async () => {
    let t3 = await K(), r3 = e2 ? re(t3, e2.vtaDid)?.did : void 0;
    n2(r3 ?? ``), i2(r3 ?? ``), o2(t3.encryptHolderSecret === true), w2(t3.preferTsp !== false), c2(await Se() ?? ``);
  }, [e2]);
  (0, J.useEffect)(() => {
    k2();
  }, [k2, e2?.vtaDid]);
  let j2 = e2 ? z(e2.vtaDid) : void 0, N2 = (0, J.useCallback)(async () => {
    if (!j2) {
      O2(null);
      return;
    }
    O2(await T(j2));
  }, [j2]);
  (0, J.useEffect)(() => {
    N2();
    let e3 = () => void N2();
    return chrome.permissions.onAdded.addListener(e3), chrome.permissions.onRemoved.addListener(e3), () => {
      chrome.permissions.onAdded.removeListener(e3), chrome.permissions.onRemoved.removeListener(e3);
    };
  }, [N2]);
  async function P2() {
    j2 && (await p(j2), await N2());
  }
  let F2 = !!e2, I2 = e2?.mediatorDid, L2 = Me([e2?.vtaDid, I2, r2 || void 0]), { health: R2 } = Be(e2?.vtaDid), B2 = e2 ? Ie(e2, C2, R2) : void 0, ee2 = Re(R2), te2 = e2 ? Le(e2, R2) : [];
  async function ne2() {
    if (e2) {
      h2(true), y2(null);
      try {
        await b(e2.vtaDid), await k2(), y2(`Wallet locked. You'll be asked for your passkey once per browser session.`);
      } catch (e3) {
        y2(e3 instanceof Error ? e3.message : String(e3));
      } finally {
        h2(false);
      }
    }
  }
  async function ie2() {
    h2(true), y2(null);
    try {
      if (!e2) throw Error(`no active agent to set a relay for`);
      await V(e2.vtaDid, { did: t2.trim(), source: `operator` }), i2(t2.trim()), S2(false), c2(await Se() ?? ``), await Z({ type: fe }), y2(`Saved. Your wallet is now listening on the new relay.`);
    } catch (e3) {
      y2(e3 instanceof Error ? e3.message : String(e3));
    } finally {
      h2(false);
    }
  }
  let H2 = t2.trim() !== r2;
  return (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 16 }, children: [(0, Y.jsxs)(A, { title: F2 ? `Your wallet is set up` : `Set up your wallet`, description: F2 ? `Everything below is already done. Come back here to turn the passkey lock on or off.` : `Four steps. The order matters \u2014 each one depends on the last.`, children: [(0, Y.jsx)(je, { steps: [F2 ? `done` : `now`, F2 ? `done` : `pending`, F2 ? a2 ? `done` : `now` : `pending`, F2 ? `done` : `pending`] }), (0, Y.jsxs)(`div`, { style: { display: `grid`, marginTop: 4 }, children: [(0, Y.jsx)(He, { n: 1, state: F2 ? `done` : `now`, title: `Your trust agent`, children: e2 ? (0, Y.jsxs)(Y.Fragment, { children: [(0, Y.jsx)(`div`, { style: { fontSize: M.sm, color: l.muted }, children: `The service that issues and manages your credentials.` }), E2 === false && j2 && (0, Y.jsxs)(m, { tone: `danger`, children: [(0, Y.jsxs)(`strong`, { children: [`The wallet can't reach `, D(j2), ` right now.`] }), ` `, `Access to that site was withdrawn \u2014 most often by switching Chrome's Site access to \u201COn specific sites\u201D. Your wallet and its credentials are untouched; it just cannot talk to your agent until you allow it again.`, (0, Y.jsx)(`div`, { style: { marginTop: 8 }, children: (0, Y.jsxs)(v, { kind: `primary`, onClick: () => void P2(), children: [`Allow access to `, D(j2)] }) })] }), (0, Y.jsx)(f, { value: e2.vtaDid, verified: true, ...L2[e2.vtaDid] ? { agentName: L2[e2.vtaDid] } : {} }), (0, Y.jsx)(We, { connection: e2 })] }) : (0, Y.jsx)(`div`, { style: { fontSize: M.sm, color: l.muted, maxWidth: `78ch` }, children: `Paste your agent's address below. Chrome will ask permission for its host \u2014 the wallet reaches only hosts you approve, one at a time.` }) }), (0, Y.jsx)(He, { n: 2, state: F2 ? `done` : `pending`, title: `How to reach it`, children: F2 ? I2 ? (0, Y.jsxs)(Y.Fragment, { children: [(0, Y.jsxs)(`div`, { style: { fontSize: M.sm, color: l.muted }, children: [`Read from the agent's own record \u2014 nothing to enter.`, B2 && (0, Y.jsxs)(Y.Fragment, { children: [` `, `Messages`, ` `, ee2 ? `travel` : `should travel`, ` over`, ` `, (0, Y.jsx)(`strong`, { style: { color: l.text }, children: B2 }), `.`] })] }), te2.map((e3) => (0, Y.jsxs)(`div`, { style: { fontSize: M.sm, color: l.muted, borderLeft: `2px solid ${l.warn}`, paddingLeft: 8 }, children: [(0, Y.jsxs)(`strong`, { style: { color: l.text }, children: [e3, ` unavailable.`] }), ` `, R2[e3]?.detail ?? `The channel could not be opened.`] }, e3)), (0, Y.jsx)(`div`, { style: { display: `flex`, gap: 10, alignItems: `center`, flexWrap: `wrap` }, children: (0, Y.jsx)(f, { value: I2, verified: true, ...L2[I2] ? { agentName: L2[I2] } : {}, suffix: (0, Y.jsx)(u, { tone: `ok`, children: `Resolved` }) }) })] }) : (0, Y.jsx)(`div`, { style: { fontSize: M.sm, color: l.muted }, children: `Reached over REST \u2014 this agent publishes no mediator.` }) : (0, Y.jsx)(`div`, { style: { fontSize: M.sm, color: l.faint, maxWidth: `78ch` }, children: `Usually automatic. If your agent doesn't publish a mediator, you'll be asked for one.` }) }), (0, Y.jsxs)(He, { n: 3, state: F2 ? a2 ? `done` : `now` : `pending`, title: `Lock your wallet with a passkey`, children: [(0, Y.jsx)(`div`, { style: { fontSize: M.sm, color: F2 ? l.muted : l.faint, maxWidth: `78ch` }, children: `Locks the wallet behind Touch ID, Windows Hello, or a security key. Without it, anyone who can use this browser can use your wallet.` }), F2 && !a2 && (0, Y.jsxs)(Y.Fragment, { children: [(0, Y.jsxs)(m, { tone: `accent`, children: [(0, Y.jsx)(`strong`, { children: `If you lose your passkey:` }), ` you won't be able to unlock this wallet any more. Nothing important is lost \u2014 your credentials are kept by your trust agent, not in this browser. You'd set the wallet up again and reconnect, and the sites you use would need reconnecting too.`] }), (0, Y.jsx)(`div`, { children: (0, Y.jsx)(v, { kind: `primary`, disabled: d2, onClick: () => void ne2(), children: d2 ? `Working\u2026` : `Turn on` }) })] }), a2 && (0, Y.jsx)(u, { tone: `ok`, children: `On` })] }), (0, Y.jsxs)(He, { n: 4, state: F2 ? `done` : `pending`, title: `Message routing`, last: true, children: [(0, Y.jsx)(`div`, { style: { fontSize: M.sm, color: F2 ? l.muted : l.faint, maxWidth: `78ch` }, children: `Set up from your agent when you connected \u2014 one relay per agent, carrying messages in both directions, which is what almost every deployment wants.` }), F2 && (0, Y.jsxs)(Y.Fragment, { children: [r2 ? (0, Y.jsxs)(`div`, { style: { fontSize: M.xs, color: l.muted, marginTop: 2 }, children: [`This agent reaches you via`, ` `, (0, Y.jsx)(f, { value: r2, ...L2[r2] ? { agentName: L2[r2] } : {} }), I2 && r2 !== I2 && (0, Y.jsx)(Y.Fragment, { children: ` \u2014 not your agent's own relay.` })] }) : (0, Y.jsxs)(m, { tone: `danger`, children: [(0, Y.jsx)(`strong`, { children: `This agent can't reach you.` }), ` No relay is set for it, so its consent requests and approvals will never arrive. Reconnect to it to pick one up automatically, or set one below.`] }), s2 && (0, Y.jsxs)(`div`, { style: { fontSize: M.xs, color: l.muted, marginTop: 2 }, children: [`Your wallet address: `, (0, Y.jsx)(_, { value: s2, size: M.xs })] }), x2 ? (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 8, marginTop: 4 }, children: [(0, Y.jsxs)(m, { tone: `warn`, children: [(0, Y.jsx)(`strong`, { children: `Only change this if you run more than one relay.` }), ` This sets the relay for `, (0, Y.jsx)(`em`, { children: `this agent only` }), ` \u2014 your other agents keep theirs. Your wallet address stays the same, but an agent pushes through the relay it knows: point this somewhere the agent doesn't use and its messages will keep arriving where you aren't listening.`] }), (0, Y.jsx)(`input`, { value: t2, onChange: (e3) => n2(e3.target.value), placeholder: `did:webvh:\u2026`, "aria-label": `Inbox mediator DID`, style: { fontFamily: `var(--w-mono)`, fontSize: M.sm, width: `100%` } }), (0, Y.jsxs)(`div`, { style: { display: `flex`, gap: 8 }, children: [(0, Y.jsx)(v, { kind: H2 ? `danger` : `default`, disabled: d2 || !H2, onClick: () => void ie2(), children: d2 ? `Working\u2026` : `Change inbox` }), (0, Y.jsx)(v, { kind: `quiet`, onClick: () => {
    n2(r2), S2(false);
  }, children: `Cancel` })] })] }) : (0, Y.jsx)(`div`, { children: (0, Y.jsx)(v, { kind: `quiet`, onClick: () => S2(true), children: `Change routing (advanced)` }) })] })] })] }), g2 && (0, Y.jsx)(`div`, { style: { fontSize: M.sm, color: g2.includes(`fail`) ? l.danger : l.ok }, children: g2 })] }), F2 ? (0, Y.jsx)(Ge, {}) : (0, Y.jsx)(A, { children: (0, Y.jsx)(De, {}) })] });
}
function We({ connection: e2 }) {
  let t2 = e2.agentScope, n2 = e2.homeContext;
  return !t2 && !n2 ? (0, Y.jsx)(`div`, { style: { fontSize: M.xs, color: l.faint }, children: `Reach and home context weren't recorded when this wallet connected. Reconnecting to this agent records them.` }) : (0, Y.jsxs)(`div`, { style: { display: `flex`, gap: 10, alignItems: `center`, flexWrap: `wrap` }, children: [t2 && (0, Y.jsx)(u, { tone: t2 === `unrestricted` ? `warn` : `ok`, children: t2 === `unrestricted` ? `Manages the whole agent` : `Works in one context` }), (0, Y.jsxs)(`span`, { style: { fontSize: M.xs, color: l.muted }, children: [`Settings kept in`, ` `, n2 ? (0, Y.jsx)(`code`, { style: { fontFamily: `var(--w-mono)` }, children: n2 }) : (0, Y.jsx)(`em`, { children: `a context this wallet wasn't told the name of` })] })] });
}
function Ge() {
  let [e2, t2] = (0, J.useState)(false);
  return e2 ? (0, Y.jsx)(A, { children: (0, Y.jsx)(De, { onCancel: () => t2(false), standalone: true }) }) : (0, Y.jsx)(`div`, { children: (0, Y.jsx)(v, { kind: `quiet`, onClick: () => t2(true), children: `+ Connect another trust agent` }) });
}
var Ke = `trusted-site:`;
function qe(e2) {
  return `${Ke}${e2}`;
}
async function Je(e2) {
  await chrome.storage.local.remove(qe(e2));
}
async function Ye() {
  let e2 = await chrome.storage.local.get(null);
  return Object.entries(e2).filter(([e3]) => e3.startsWith(Ke)).map(([, e3]) => e3).sort((e3, t2) => t2.trustedAt - e3.trustedAt);
}
function Xe(e2, t2, n2) {
  let r2 = [];
  return e2 && r2.push(`host:${n2(e2)}`), t2 && r2.push(`did:${t2}`), r2;
}
function Ze(e2, t2) {
  return e2.origin ? t2(e2.origin) : e2.rpDid ? e2.rpDid : e2.entry?.label ?? e2.key;
}
function Qe(e2) {
  let t2 = Date.parse(e2.entry?.lastUsedAt ?? e2.entry?.updatedAt ?? ``);
  return Number.isFinite(t2) ? t2 : e2.trusted?.trustedAt ?? 0;
}
function $e(e2, t2, n2) {
  let r2 = [], i2 = /* @__PURE__ */ new Map(), a2 = (e3, t3) => {
    let a3 = e3.map((e4) => i2.get(e4)).find((e4) => e4 !== void 0) ?? r2.length, o2 = r2[a3], s2 = t3.origin ?? o2?.origin, c2 = t3.rpDid ?? o2?.rpDid, l2 = t3.principalDid ?? o2?.principalDid, u2 = { key: o2?.key ?? e3[0] ?? `row-${a3}`, ...s2 ? { origin: s2 } : {}, ...c2 ? { rpDid: c2 } : {}, ...l2 ? { principalDid: l2 } : {}, ...t3.entry ?? o2?.entry ? { entry: t3.entry ?? o2?.entry } : {}, ...t3.trusted ?? o2?.trusted ? { trusted: t3.trusted ?? o2?.trusted } : {} };
    r2[a3] = u2;
    for (let t4 of [...e3, ...Xe(u2.origin, u2.rpDid, n2)]) i2.set(t4, a3);
  };
  for (let t3 of e2) {
    let e3 = t3.targets.find((e4) => e4.kind === `webOrigin`), r3 = t3.targets.find((e4) => e4.kind === `did`), i3 = e3?.kind === `webOrigin` ? e3.origin : void 0, o2 = r3?.kind === `did` ? r3.did : void 0, s2 = Xe(i3, o2, n2);
    a2(s2.length > 0 ? s2 : [`entry:${t3.id}`], { ...i3 ? { origin: i3 } : {}, ...o2 ? { rpDid: o2 } : {}, ...t3.principalDid ? { principalDid: t3.principalDid } : {}, entry: t3 });
  }
  for (let e3 of t2) a2(Xe(e3.origin, e3.rpDid, n2), { origin: e3.origin, ...e3.rpDid ? { rpDid: e3.rpDid } : {}, trusted: e3 });
  return r2.sort((e3, t3) => Qe(t3) - Qe(e3));
}
function et(e2) {
  let t2 = /* @__PURE__ */ new Map();
  for (let n2 of e2) n2.principalDid && t2.set(n2.principalDid, (t2.get(n2.principalDid) ?? 0) + 1);
  return t2;
}
var tt = 252, nt = 84, rt = 16, it = [0, 1, 2].map((e2) => rt + e2 * 368), at = 1020, ot = { self: { stroke: l.accent, fill: l.accentSoft, accent: l.accent }, agent: { stroke: l.ok, fill: l.okSoft, accent: l.ok }, mediator: { stroke: l.line, fill: l.surface, accent: l.muted }, approver: { stroke: l.warn, fill: l.warnSoft, accent: l.warn }, rp: { stroke: l.line, fill: l.surface, accent: l.muted }, entry: { stroke: l.line, fill: l.raised, accent: l.faint } };
function st(e2, t2 = 34) {
  return e2.length <= t2 ? e2 : `${e2.slice(0, t2 - 8)}\u2026${e2.slice(-6)}`;
}
function ct(e2, t2) {
  return e2.length <= t2 ? e2 : `${e2.slice(0, t2 - 1)}\u2026`;
}
function lt({ node: e2, x: t2, y: n2, selected: r2, onSelect: i2 }) {
  let a2 = ot[e2.tone];
  return (0, Y.jsxs)(`g`, { onClick: () => i2(e2.id), style: { cursor: `pointer` }, tabIndex: 0, role: `button`, "aria-pressed": r2, "aria-label": `${e2.role}: ${e2.label ?? e2.did ?? `unknown`}`, onKeyDown: (t3) => {
    (t3.key === `Enter` || t3.key === ` `) && (t3.preventDefault(), i2(e2.id));
  }, children: [(0, Y.jsx)(`rect`, { x: t2, y: n2, width: tt, height: nt, rx: 9, fill: a2.fill, stroke: a2.stroke, strokeWidth: r2 ? 2.4 : 1.2 }), (0, Y.jsx)(`text`, { x: t2 + 14, y: n2 + 20, fontSize: 9.5, fill: a2.accent, letterSpacing: `0.08em`, fontWeight: 700, children: e2.role.toUpperCase() }), (0, Y.jsx)(`text`, { x: t2 + 14, y: n2 + 39, fontSize: 12.5, fill: l.text, fontWeight: 640, children: ct(e2.label ?? `\u2014`, 30) }), e2.did && (0, Y.jsx)(`text`, { x: t2 + 14, y: n2 + 56, fontSize: 9.5, fill: l.muted, fontFamily: `var(--w-mono)`, children: st(e2.did) }), e2.detail && (0, Y.jsx)(`text`, { x: t2 + 14, y: n2 + 72, fontSize: 9.5, fill: l.faint, children: ct(e2.detail, 42) })] });
}
function ut({ x1: e2, y1: t2, x2: n2, y2: r2, dashed: i2 }) {
  return (0, Y.jsx)(`line`, { x1: e2, y1: t2, x2: n2, y2: r2, stroke: l.line, strokeWidth: 1.4, strokeDasharray: i2 ? `4 3` : void 0, markerEnd: `url(#tg-arrow)` });
}
function dt({ x1: e2, y1: t2, x2: n2, y2: r2, label: i2 }) {
  if (!i2) return null;
  let a2 = (e2 + n2) / 2, o2 = (t2 + r2) / 2, s2 = i2.length * 5.9 + 12;
  return (0, Y.jsxs)(`g`, { children: [(0, Y.jsx)(`rect`, { x: a2 - s2 / 2, y: o2 - 8.5, width: s2, height: 17, rx: 5, fill: l.ground }), (0, Y.jsx)(`text`, { x: a2, y: o2 + 3.5, fontSize: 9.5, fill: l.muted, textAnchor: `middle`, children: i2 })] });
}
function ft({ nodes: e2, edges: t2, positions: n2, height: r2, selectedId: i2, onSelect: a2, groups: o2 = [] }) {
  let s2 = (e3) => {
    let t3 = e3.members.map((e4) => n2[e4]).filter((e4) => !!e4);
    if (t3.length === 0) return null;
    let r3 = t3.map((e4) => it[e4.col] ?? 0), i3 = t3.map((e4) => e4.row), a3 = Math.min(...r3) - 14, o3 = Math.min(...i3) - 14 - 12;
    return { x: a3, y: o3, w: Math.max(...r3) + tt + 14 - a3, h: Math.max(...i3) + nt + 14 - o3 };
  }, c2 = (e3) => {
    let t3 = n2[e3];
    if (t3) return { x: it[t3.col] ?? 0, y: t3.row, w: tt, h: nt };
    let r3 = o2.find((t4) => t4.id === e3);
    if (r3) {
      let e4 = s2(r3);
      if (e4) return { x: e4.x, y: e4.y, w: e4.w, h: e4.h };
    }
    return null;
  }, u2 = t2.filter((e3) => {
    let t3 = c2(e3.from), n3 = c2(e3.to);
    return t3 && n3 && (t3.y !== n3.y || t3.h !== n3.h);
  }), d2 = t2.map((e3) => {
    let t3 = c2(e3.from), n3 = c2(e3.to);
    if (!t3 || !n3) return null;
    if (t3.y === n3.y && t3.h === n3.h) {
      let r4 = t3.x < n3.x;
      return { x1: r4 ? t3.x + t3.w : t3.x, y1: t3.y + t3.h / 2, x2: r4 ? n3.x - 4 : n3.x + n3.w + 4, y2: n3.y + n3.h / 2, label: e3.label, dashed: e3.dashed };
    }
    let r3 = u2.filter((t4) => t4.from === e3.from), i3 = r3.indexOf(e3), a3 = r3.length > 1 ? (i3 + 1) / (r3.length + 1) : 0.5, o3 = t3.y > n3.y;
    return { x1: t3.x + t3.w * a3, y1: o3 ? t3.y : t3.y + t3.h, x2: n3.x + n3.w / 2, y2: o3 ? n3.y + n3.h + 4 : n3.y - 4, label: e3.label, dashed: e3.dashed };
  }).filter((e3) => e3 !== null);
  return (0, Y.jsx)(`div`, { style: { overflowX: `auto` }, children: (0, Y.jsxs)(`svg`, { viewBox: `0 0 ${at} ${r2}`, style: { width: `100%`, maxWidth: at, minWidth: 860, display: `block` }, role: `img`, "aria-label": `Diagram of the wallet's connections`, children: [(0, Y.jsx)(`defs`, { children: (0, Y.jsx)(`marker`, { id: `tg-arrow`, viewBox: `0 0 8 8`, refX: `7`, refY: `4`, markerWidth: `6`, markerHeight: `6`, orient: `auto`, children: (0, Y.jsx)(`path`, { d: `M0 0 L8 4 L0 8 z`, fill: l.line }) }) }), o2.map((e3) => {
    let t3 = s2(e3);
    return t3 ? (0, Y.jsxs)(`g`, { children: [(0, Y.jsx)(`rect`, { x: t3.x, y: t3.y, width: t3.w, height: t3.h, rx: 12, fill: `none`, stroke: l.line, strokeWidth: 1, strokeDasharray: `5 4` }), (0, Y.jsx)(`text`, { x: t3.x + 12, y: t3.y + 14, fontSize: 9.5, fill: l.faint, letterSpacing: `0.08em`, fontWeight: 700, children: e3.label.toUpperCase() })] }, e3.id) : null;
  }), d2.map((e3, t3) => (0, Y.jsx)(ut, { ...e3 }, t3)), e2.map((e3) => {
    let t3 = c2(e3.id);
    return t3 ? (0, Y.jsx)(lt, { node: e3, x: t3.x, y: t3.y, selected: i2 === e3.id, onSelect: a2 }, e3.id) : null;
  }), d2.map((e3, t3) => (0, Y.jsx)(dt, { ...e3 }, t3))] }) });
}
function Q(e2, t2) {
  if (!e2) return;
  let n2 = t2[e2];
  return n2 ? a(n2) : x(e2);
}
M.xs, l.faint;
var pt = 52, mt = 58, ht = 40, gt = 108, _t = 250;
function vt({ title: e2, teaser: t2, summary: n2, lanes: r2, steps: i2, benefitsTitle: a2, benefits: o2 }) {
  let [s2, c2] = (0, J.useState)(false), [u2, d2] = (0, J.useState)(null), f2 = (e3) => {
    let t3 = r2.findIndex((t4) => t4.id === e3);
    return gt + Math.max(t3, 0) * _t;
  }, p2 = gt + _t * (r2.length - 1) + 52;
  if (!s2) return (0, Y.jsx)(A, { title: e2, description: t2, children: (0, Y.jsx)(`div`, { children: (0, Y.jsx)(v, { onClick: () => c2(true), children: `Show me` }) }) });
  let m2 = pt + i2.length * mt + 30;
  return (0, Y.jsxs)(A, { title: e2, description: n2, children: [(0, Y.jsx)(`div`, { style: { overflowX: `auto` }, children: (0, Y.jsxs)(`svg`, { viewBox: `0 0 ${p2} ${m2}`, style: { width: `100%`, maxWidth: p2, minWidth: 760, display: `block` }, role: `img`, "aria-label": `Sequence diagram: ${e2}`, children: [(0, Y.jsx)(`defs`, { children: (0, Y.jsx)(`marker`, { id: `sf-arrow`, viewBox: `0 0 8 8`, refX: `7`, refY: `4`, markerWidth: `6`, markerHeight: `6`, orient: `auto`, children: (0, Y.jsx)(`path`, { d: `M0 0 L8 4 L0 8 z`, fill: l.muted }) }) }), r2.map((e3) => {
    let t3 = f2(e3.id);
    return (0, Y.jsxs)(`g`, { children: [(0, Y.jsx)(`text`, { x: t3, y: 18, fontSize: 11, fontWeight: 700, fill: l.text, textAnchor: `middle`, children: e3.label }), (0, Y.jsx)(`line`, { x1: t3, y1: 28, x2: t3, y2: m2 - 12, stroke: l.line, strokeWidth: 1, strokeDasharray: `3 4` })] }, e3.id);
  }), i2.map((e3, t3) => {
    let n3 = pt + t3 * mt, r3 = f2(e3.from), i3 = f2(e3.to), a3 = u2 === e3.n, o3 = e3.emphasis ? l.accent : l.muted, s3 = e3.self ? r3 - 46 : Math.min(Math.max((r3 + i3) / 2, 70 + e3.text.length * 5.9 / 2), p2 - 16 - e3.text.length * 5.9 / 2);
    return (0, Y.jsxs)(`g`, { onClick: () => d2(a3 ? null : e3.n), style: { cursor: `pointer` }, tabIndex: 0, role: `button`, "aria-pressed": a3, "aria-label": `Step ${e3.n}: ${e3.text}`, onKeyDown: (t4) => {
      (t4.key === `Enter` || t4.key === ` `) && (t4.preventDefault(), d2(a3 ? null : e3.n));
    }, children: [(0, Y.jsx)(`rect`, { x: 0, y: n3 - 22, width: p2, height: 52, fill: `transparent` }), a3 && (0, Y.jsx)(`rect`, { x: 0, y: n3 - 22, width: p2, height: 52, rx: 6, fill: l.accentSoft }), e3.self ? (0, Y.jsx)(`path`, { d: `M ${r3} ${n3 - 6} q 34 0 34 12 q 0 12 -34 12`, fill: `none`, stroke: o3, strokeWidth: 1.4, markerEnd: `url(#sf-arrow)` }) : (0, Y.jsx)(`line`, { x1: r3, y1: n3 + 6, x2: i3 + (i3 > r3 ? -6 : 6), y2: n3 + 6, stroke: o3, strokeWidth: 1.4, markerEnd: `url(#sf-arrow)` }), (0, Y.jsx)(`circle`, { cx: ht, cy: n3 + 2, r: 12, fill: o3 }), (0, Y.jsx)(`text`, { x: ht, y: n3 + 6.5, fontSize: 13, fontWeight: 700, fill: l.ground, textAnchor: `middle`, children: e3.n }), (0, Y.jsx)(`text`, { x: s3, y: n3 - 4, fontSize: 11, fill: e3.emphasis ? l.accent : l.text, fontWeight: e3.emphasis ? 640 : 400, textAnchor: e3.self ? `end` : `middle`, children: e3.text })] }, e3.n);
  })] }) }), u2 !== null && (0, Y.jsxs)(`div`, { style: { borderLeft: `2px solid ${l.accent}`, background: l.accentSoft, padding: `10px 13px`, borderRadius: `0 var(--w-r-sm) var(--w-r-sm) 0`, fontSize: M.sm, lineHeight: 1.55 }, children: [(0, Y.jsxs)(`strong`, { children: [`Step `, u2, `.`] }), ` `, i2.find((e3) => e3.n === u2)?.detail] }), (0, Y.jsx)(`h3`, { style: { margin: `8px 0 0`, fontSize: M.base, fontWeight: 640 }, children: a2 }), (0, Y.jsx)(`div`, { style: { display: `grid`, gap: 10 }, children: o2.map((e3) => (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 2 }, children: [(0, Y.jsx)(`div`, { style: { fontSize: M.sm, fontWeight: 620 }, children: e3.title }), (0, Y.jsx)(`div`, { style: { fontSize: M.sm, color: l.muted, lineHeight: 1.55, maxWidth: `78ch` }, children: e3.body })] }, e3.title)) }), (0, Y.jsx)(`div`, { children: (0, Y.jsx)(v, { kind: `quiet`, onClick: () => c2(false), children: `Hide` }) })] });
}
var yt = [{ id: `you`, label: `You` }, { id: `wallet`, label: `This wallet` }, { id: `agent`, label: `Your agent` }, { id: `site`, label: `The website` }], bt = [{ n: 1, from: `you`, to: `site`, text: `You click \u201CSign in\u201D`, detail: `The page calls window.vtaWallet.login({ rpDid, baseUrl }).` }, { n: 2, from: `site`, to: `wallet`, text: `The site asks your wallet to prove who you are`, detail: `It sends its own DID as the audience, plus a one-time challenge from its /auth/challenge endpoint.` }, { n: 3, from: `wallet`, to: `you`, text: `Your wallet asks you first`, detail: `A consent window names the site and the identity it is asking for. Nothing proceeds without your approval \u2014 a page cannot sign you in quietly.`, emphasis: true }, { n: 4, from: `wallet`, to: `agent`, text: `Your wallet asks your agent to sign \u2014 as your identity for that site`, detail: `The vault entry for the site names the identity to use (its principalDid). That is not your wallet's own address: each site gets its own identity. The agent holds the signing keys and the browser never does.` }, { n: 5, from: `agent`, to: `wallet`, text: `Your agent signs it and sends it back`, detail: `A SIOPv2 id_token signed by that site's identity, carrying the site's challenge so it cannot be replayed elsewhere.` }, { n: 6, from: `wallet`, to: `site`, text: `Your wallet hands the pass to the site`, detail: `Posted to the site's auth endpoint as a bearer token.` }, { n: 7, from: `site`, to: `site`, self: true, text: `The site checks the signature by itself`, detail: `It resolves your published DID document and verifies the signature against the key in it. It never contacts your agent \u2014 so nobody is told where you sign in.`, emphasis: true }], xt = [{ title: `No password exists`, body: `There is nothing to reuse across sites, nothing to leak in a breach, and nothing a fake page can phish out of you.` }, { title: `The site never holds a secret of yours`, body: `It gets a one-time pass that only works there. If the site is breached tomorrow, there is nothing of yours in it to steal.` }, { title: `Your keys stay with your agent`, body: `The browser asks for a signature; it never holds the key that makes one. A compromised browser cannot walk off with your identity.` }, { title: `A different identity for every site`, body: `A site sees an identity you use only there \u2014 never your wallet's own address \u2014 so sites cannot work out they are dealing with the same person. Reuse the same identity across two sites and they can; the Network view says which ones do.` }, { title: `Nobody watches where you go`, body: `The site verifies you from your public record, without calling your agent \u2014 so no service accumulates a log of every place you sign in.` }, { title: `You approve each sign-in`, body: `Every request names the site asking. Approval is a human step by design, not a setting that can be left on.` }];
function St() {
  return (0, Y.jsx)(vt, { title: `How signing in works`, teaser: `A one-page walkthrough of what happens between clicking \u201CSign in\u201D and being let in \u2014 and why it is safer than a password.`, summary: `Seven steps, every time. Select a step for the technical detail.`, lanes: yt, steps: bt, benefitsTitle: `Why this is better than a password`, benefits: xt });
}
var Ct = [{ id: `site`, label: `A site` }, { id: `wallet`, label: `This wallet` }, { id: `agent`, label: `Your agent` }, { id: `approver`, label: `Your approver` }], wt = [{ n: 1, from: `site`, to: `wallet`, text: `A site asks for something to be done`, detail: `The relying party proposes a task type and a payload \u2014 nothing else. It is treated as untrusted: it may be malicious or XSS'd, and it never supplies anything a human reads as the basis of a decision.` }, { n: 2, from: `wallet`, to: `agent`, text: `Your wallet passes it on, and says where it came from`, detail: `task/propose, carrying this device's id. The origin is taken from the browser's own view of the sender, not from anything the page put in the message body.` }, { n: 3, from: `agent`, to: `agent`, self: true, text: `Your agent works out what would actually change`, detail: `It validates the request, checks policy, loads the current state, and dry-runs the task to produce the real list of effects. Then it pins that state and takes a digest of the exact payload. The site is never allowed to do this: only the code about to run knows what it will do.`, emphasis: true }, { n: 4, from: `agent`, to: `site`, text: `It answers straight away: not yet, this needs approval`, detail: `A consentRequired outcome, relayed back through your wallet. The request does not hang waiting for a human \u2014 the site gets an answer immediately and shows a match code, a short code derived from the payload digest.` }, { n: 5, from: `agent`, to: `approver`, text: `At the same time, it asks your approver to approve`, detail: `Concurrent with step 4, not after it: the wallet fires the approval request alongside answering the site, so a slow human never delays the site's reply. Signed by your agent, carrying the effects, the payload digest, the origin and a single-use challenge. It reaches your approver in this browser directly, or on another device through the approver's mediator inbox.` }, { n: 6, from: `approver`, to: `approver`, self: true, text: `You check the code matches, and approve`, detail: `Your approver renders the agent's description \u2014 not the site's \u2014 and shows the same match code the site is showing. Comparing them is how you confirm the thing you are approving is the thing that was asked for. Your authenticator then releases the signing key for this one decision.`, emphasis: true }, { n: 7, from: `approver`, to: `agent`, text: `Your approval goes back, signed`, detail: `A consent decision carrying the same challenge and the same payload digest, signed by the approver's key. Your agent replies accepted or refused \u2014 a refusal means a human agreed to something that then did not happen, which the wallet logs rather than silently dropping.` }, { n: 8, from: `site`, to: `agent`, text: `The site asks again \u2014 this time the approval is used up`, detail: `The re-submit consumes the single-use grant. It travels the same road as the first request, through your wallet, which stamps the attested origin again. This is why the first call could return immediately: approval is a separate errand, not a held-open request, so it can take minutes or happen on another device without anything hanging.` }, { n: 9, from: `agent`, to: `site`, text: `Your agent re-checks everything, does it, and answers`, detail: `It re-verifies the digest and pinned state, then re-evaluates policy and device enrolment before executing \u2014 re-checking at the moment of execution is what makes revoking a device stop approvals already in flight. The result is relayed back through your wallet to the page.`, emphasis: true }], Tt = [{ title: `The site cannot authorise anything`, body: `It proposes; your agent decides. A compromised page can ask for something outrageous and get no further than the approval prompt you are about to read.` }, { title: `You approve what actually happens`, body: `The description you read is written by the thing about to run the task, not by whoever asked for it. Your approval is bound to that exact payload by a digest, so nothing can be swapped afterwards.` }, { title: `Asking and approving are different identities`, body: `The identity that requests cannot approve. A hijacked browser session can propose a destructive task and still not sign it off.` }, { title: `Approval can happen somewhere else`, body: `The device that proposes need not be the device that approves \u2014 a request made in this browser can be approved on your phone.` }, { title: `Nothing hangs waiting for you`, body: `The site is told immediately that approval is needed, rather than being left on a held-open request. That is what lets an approval take minutes, or happen on a different device, without the page timing out.` }, { title: `Revoking a device works immediately`, body: `Policy and enrolment are re-checked at the moment of execution, not just when the request was made, so approvals already in flight from a revoked device stop working.` }];
function Et() {
  return (0, Y.jsx)(vt, { title: `How approvals work`, teaser: `When a site asks your agent to actually change something \u2014 publish a record, rotate a key \u2014 this is what stands between the request and it happening.`, summary: `Nine steps, in two rounds: the site is told approval is needed, then asks again once you have given it. Select a step for the technical detail.`, lanes: Ct, steps: wt, benefitsTitle: `What this protects you from`, benefits: Tt });
}
var Dt = { pass: `PASS`, fail: `FAIL`, warn: `WARN`, skip: `SKIP` };
function Ot(e2) {
  return e2.some((e3) => e3.status === `fail`) ? `fail` : e2.some((e3) => e3.status === `warn`) ? `warn` : e2.some((e3) => e3.status === `pass`) ? `pass` : `skip`;
}
function kt(e2) {
  switch (Ot(e2.checks)) {
    case `fail`:
      return `Something in the chain is broken \u2014 the failing checks below say which link and what to change.`;
    case `warn`:
      return `Reachable, but not everything this wallet needs is running.`;
    case `pass`:
      return `Every check passed.`;
    default:
      return `Nothing to check.`;
  }
}
function At(e2) {
  let t2 = [];
  t2.push(`VTA wallet connection self-test`), t2.push(`Generated: ${e2.generatedAt}`), t2.push(`Trust agent: ${e2.vtaDid}`), t2.push(`Wallet origin: ${e2.extensionOrigin}`), t2.push(``), t2.push(kt(e2)), t2.push(``);
  for (let n2 of e2.checks) t2.push(`[${Dt[n2.status]}] ${n2.label}`), t2.push(`       ${n2.detail}`), n2.code && t2.push(`       code: ${n2.code}`), n2.remediation && t2.push(`       fix: ${n2.remediation}`);
  return t2.join(`
`);
}
var jt = { pass: `ok`, fail: `danger`, warn: `warn`, skip: `off` };
function Mt({ vtaDid: e2 }) {
  let [t2, n2] = (0, J.useState)(null), [r2, i2] = (0, J.useState)(false), [a2, o2] = (0, J.useState)(null), [s2, c2] = (0, J.useState)(false);
  async function d2() {
    if (e2) {
      i2(true), o2(null), c2(false);
      try {
        let t3 = await chrome.runtime.sendMessage({ type: le, vtaDid: e2 });
        t3.ok ? n2(t3.result) : o2(t3.error);
      } catch (e3) {
        o2(e3 instanceof Error ? e3.message : String(e3));
      } finally {
        i2(false);
      }
    }
  }
  async function f2() {
    if (t2) try {
      await navigator.clipboard.writeText(At(t2)), c2(true);
    } catch {
    }
  }
  return (0, Y.jsxs)(A, { title: `Connection self-test`, description: `Checks the chain this wallet depends on, from the wallet's own origin \u2014 which is the only place the answer is true.`, children: [(0, Y.jsxs)(`div`, { style: { display: `flex`, gap: 8, alignItems: `center`, flexWrap: `wrap` }, children: [(0, Y.jsx)(v, { onClick: d2, disabled: r2 || !e2, kind: `primary`, children: r2 ? `Running\u2026` : `Run checks` }), t2 && (0, Y.jsx)(v, { onClick: f2, kind: `quiet`, children: s2 ? `Copied` : `Copy report` }), !e2 && (0, Y.jsx)(`span`, { style: { fontSize: M.sm, color: l.muted }, children: `Connect a trust agent first.` })] }), a2 && (0, Y.jsx)(`div`, { style: { fontSize: M.sm, color: l.danger }, children: a2 }), t2 && (0, Y.jsxs)(Y.Fragment, { children: [(0, Y.jsxs)(`div`, { style: { fontSize: M.sm, color: l.muted }, children: [kt(t2), ` `, Ot(t2.checks) === `fail` && (0, Y.jsxs)(Y.Fragment, { children: [`Most of these are fixed by whoever runs the service, not from this browser \u2014 use `, (0, Y.jsx)(`strong`, { style: { color: l.text }, children: `Copy report` }), ` and send it to them.`] })] }), (0, Y.jsx)(`div`, { style: { display: `grid`, gap: 8 }, children: t2.checks.map((e3) => (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 4, padding: `8px 10px`, border: `1px solid ${l.line}`, borderRadius: 8 }, children: [(0, Y.jsxs)(`div`, { style: { display: `flex`, gap: 8, alignItems: `center` }, children: [(0, Y.jsx)(u, { tone: jt[e3.status], children: e3.status }), (0, Y.jsx)(`span`, { style: { fontSize: M.sm, color: l.text }, children: e3.label })] }), (0, Y.jsx)(`div`, { style: { fontSize: M.sm, color: l.muted }, children: e3.detail }), e3.remediation && (0, Y.jsxs)(`div`, { style: { fontSize: M.sm, color: l.muted }, children: [(0, Y.jsx)(`strong`, { style: { color: l.text }, children: `Fix:` }), ` `, e3.remediation] }), e3.code && (0, Y.jsx)(`div`, { style: { fontSize: M.xs, color: l.faint, fontFamily: `ui-monospace, monospace` }, children: e3.code })] }, e3.id)) }), (0, Y.jsxs)(`div`, { style: { fontSize: M.xs, color: l.muted }, children: [`This wallet's origin:`, ` `, (0, Y.jsx)(`code`, { style: { color: l.text }, children: t2.extensionOrigin })] })] })] });
}
function Nt() {
  let e2 = xe(), [t2, n2] = (0, J.useState)(``), [r2, i2] = (0, J.useState)(null), [a2, o2] = (0, J.useState)(true), [s2, c2] = (0, J.useState)(false), [d2, f2] = (0, J.useState)([]), [p2, m2] = (0, J.useState)(null), [h2, g2] = (0, J.useState)([]);
  (0, J.useEffect)(() => {
    (async () => {
      let e3 = await K();
      o2(e3.preferTsp !== false), c2(!!e3.encryptHolderSecret), n2(await Se() ?? ``), f2(await Ye());
      let t3 = await q();
      t3 && i2(await R(new G(), t3));
      try {
        let e4 = await chrome.runtime.sendMessage({ type: ge });
        e4.ok && g2(e4.result.entries);
      } catch {
      }
    })();
  }, [e2?.vtaDid]);
  let v2 = e2?.mediatorDid ?? e2?.tspMediatorDid, y2 = Me([e2?.vtaDid, v2, r2 ?? void 0, ...d2.slice(0, 3).map((e3) => e3.rpDid), ...h2.slice(0, 6).map((e3) => e3.principalDid)]), { health: b2 } = Be(e2?.vtaDid), x2 = e2 ? Ie(e2, a2, b2) : void 0;
  if (!e2) return (0, Y.jsx)(A, { title: `Network`, description: `A picture of who your wallet talks to.`, children: (0, Y.jsx)(O, { children: `Nothing to draw yet \u2014 connect a trust agent under Setup first.` }) });
  let S2 = [{ id: `self`, role: `Operating identity`, label: `Your wallet`, ...t2 ? { did: t2 } : {}, detail: s2 ? `locked with a passkey` : `not locked`, tone: `self`, facts: [{ label: `Wallet address`, value: t2 || `not minted yet` }, { label: `Shown to sites?`, value: `no \u2014 each site sees its own identity from your vault, never this address` }, { label: `Passkey lock`, value: s2 ? `on` : `off` }, { label: `Extension version`, value: chrome.runtime.getManifest().version }, { label: `Talks to`, value: `your agent, its mediator, and pages you visit` }, { label: `What it does`, value: `requests and operates \u2014 it can ask your agent to act, but cannot approve` }, { label: `Paired with`, value: `your approval identity, which can approve but never requests` }] }, { id: `agent`, role: `Trust agent`, ...Q(e2.vtaDid, y2) ? { label: Q(e2.vtaDid, y2) } : {}, did: e2.vtaDid, detail: `role: ${e2.role}`, tone: `agent`, facts: [{ label: `DID`, value: e2.vtaDid }, { label: `Your role`, value: e2.role }, { label: Re(b2) ? `Transport in use` : `Transport expected`, value: x2 ?? `none usable` }, { label: `Advertises`, value: Fe(e2).join(`, `) || `nothing` }, ...Le(e2, b2).length > 0 ? [{ label: `Unavailable`, value: Le(e2, b2).map((e3) => `${e3} \u2014 ${b2[e3]?.detail ?? `could not be opened`}`).join(` `) }] : [], { label: `REST endpoint`, value: e2.restBaseUrl ?? `not advertised` }, { label: `Connected`, value: new Date(e2.connectedAt).toLocaleString() }] }], C2 = [], w2 = r2 ? 116 : 8, T2 = w2 + 138, E2 = { self: { col: 0, row: w2 }, agent: { col: 2, row: w2 } };
  v2 ? (S2.push({ id: `mediator`, role: `Mediator`, ...Q(v2, y2) ? { label: Q(v2, y2) } : {}, did: v2, detail: `relays messages both ways`, tone: `mediator`, facts: [{ label: `Carries`, value: x2 ?? `nothing right now` }, { label: `Also your inbox`, value: `relying parties send confirm requests to you through it` }] }), E2.mediator = { col: 1, row: w2 }, C2.push({ from: `self`, to: `mediator`, label: `inbox` }), C2.push({ from: `mediator`, to: `agent`, ...x2 ? { label: x2 } : {} })) : (E2.agent = { col: 1, row: w2 }, C2.push({ from: `self`, to: `agent`, ...x2 ? { label: x2 } : {} })), r2 && (S2.push({ id: `approver`, role: `Approval identity`, ...Q(r2, y2) ? { label: Q(r2, y2) } : { label: `Separate identity` }, did: r2, detail: `signs approvals, per gesture`, tone: `approver`, facts: [{ label: `DID`, value: r2 }, { label: `What it does`, value: `approves only \u2014 it never requests anything, so a stolen request cannot approve itself` }, { label: `Paired with`, value: `your operating identity above, which requests but cannot approve` }, { label: `Stored`, value: `in this browser, encrypted with your passkey \u2014 unlike your logins, which live at the agent` }, { label: `Key release`, value: `your authenticator, once per approval` }, { label: `Receives`, value: `approval requests from your agent, routed through your inbox mediator` }, { label: `Register it`, value: `must be in the agent's approver set and ACL to count` }] }), E2.approver = { col: 0, row: 8 }, C2.push({ from: v2 ? `mediator` : `agent`, to: `approver`, label: `approval requests`, dashed: true }));
  let k2 = $e(h2, d2, D), j2 = et(k2), N2 = k2.slice(0, 4), P2 = k2.slice(4), F2 = [], I2 = [];
  if (N2.forEach((e3, t3) => {
    let n3 = T2 + t3 * 100, r3 = `rp-${t3}`, i3 = Ze(e3, D), a3 = e3.rpDid && i3 === e3.rpDid ? Q(e3.rpDid, y2) ?? i3 : i3;
    if (e3.entry) {
      let t4 = `${r3}-entry`, i4 = e3.principalDid ? Q(e3.principalDid, y2) : void 0;
      S2.push({ id: t4, role: `Login entry`, label: e3.entry.label || e3.entry.id, ...e3.principalDid ? { did: e3.principalDid } : {}, detail: i4 ? `you appear as ${i4}` : e3.entry.secretKind, tone: `entry`, facts: [{ label: `Entry`, value: e3.entry.label || e3.entry.id }, { label: `Sign-in method`, value: e3.entry.secretKind }, { label: `Workspace`, value: e3.entry.contextId }, { label: `Identity presented`, value: e3.principalDid ?? `none attached` }, { label: `Last used`, value: e3.entry.lastUsedAt ?? `not yet` }, { label: `Stored`, value: `in your trust agent, not in this browser \u2014 a new browser sees it too` }] }), E2[t4] = { col: 2, row: n3 }, I2.push(t4), C2.push({ from: t4, to: r3, label: `signs you in to` });
    }
    S2.push({ id: r3, role: `Site`, label: a3, ...e3.rpDid ? { did: e3.rpDid } : {}, detail: e3.trusted ? `acts without asking` : `prompts every time`, tone: `rp`, facts: [{ label: `Site`, value: e3.origin ?? `reached by DID, not a URL` }, { label: `Its own identity`, value: e3.rpDid ?? `none recorded` }, { label: `You appear as`, value: e3.principalDid ?? `nothing yet \u2014 no login entry names an identity` }, { label: `Identity reuse`, value: (() => {
      if (!e3.principalDid) return `no identity attached yet`;
      let t4 = j2.get(e3.principalDid) ?? 1;
      return t4 > 1 ? `also used on ${t4 - 1} other site${t4 > 2 ? `s` : ``} \u2014 those sites could work out you are the same person` : `used only here, so this site cannot be correlated with the others`;
    })() }, { label: `Acts without asking`, value: e3.trusted ? `yes, since ${new Date(e3.trusted.trustedAt).toLocaleDateString()}` : `no \u2014 it prompts every time` }, { label: `Never contacts`, value: `your trust agent \u2014 it verifies you by resolving your DID document` }] }), E2[r3] = { col: 0, row: n3 }, F2.push(r3);
  }), P2.length > 0) {
    let e3 = `rp-more`;
    S2.push({ id: e3, role: `More sites`, label: `+${P2.length} more`, detail: `select to list them`, tone: `rp`, facts: [{ label: `Not drawn`, value: `showing the 4 most recently used so the shape stays readable` }, ...P2.map((e4) => ({ label: Ze(e4, D), value: e4.principalDid ?? e4.origin ?? `no identity attached` }))] }), E2[e3] = { col: 0, row: T2 + N2.length * 100 }, F2.push(e3);
  }
  let L2 = [...F2.length > 0 ? [{ id: `rp-group`, label: `Sites you sign in to`, members: F2 }] : [], ...I2.length > 0 ? [{ id: `login-group`, label: `Your logins, kept by your agent`, members: I2 }] : []];
  F2.length > 0 && (C2.push({ from: `rp-group`, to: `self`, label: `in the page` }), v2 && C2.push({ from: `rp-group`, to: `mediator`, label: `confirm requests`, dashed: true })), I2.length > 0 && C2.push({ from: `agent`, to: `login-group`, label: `stores your logins`, dashed: true });
  let z2 = S2.find((e3) => e3.id === p2), B2 = Math.max(N2.length + +!!P2.length, I2.length), ee2 = B2 > 0 ? T2 + B2 * 100 + 16 : w2 + 100;
  return (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 16 }, children: [(0, Y.jsxs)(A, { title: `Network`, description: `Everything your wallet is currently wired to, and how messages travel. Useful when something isn't working and you need to see which hop is missing.`, children: [(0, Y.jsx)(ft, { nodes: S2, edges: C2, positions: E2, groups: L2, height: ee2, ...p2 ? { selectedId: p2 } : {}, onSelect: (e3) => m2((t3) => t3 === e3 ? null : e3) }), (0, Y.jsx)(`div`, { style: { fontSize: M.xs, color: l.faint }, children: `Select any box for its details.` }), (0, Y.jsx)(`div`, { style: { fontSize: M.xs, color: l.muted, lineHeight: 1.55, maxWidth: `78ch` }, children: `Two identities live in this browser and neither can do the other's job: the operating identity asks your agent to act, the approval identity signs off on it. A compromised browser session can request things and still not approve them. Sites sit under the browser because that is the only thing they talk to; your logins sit under the agent because that is where they are kept.` }), P2.length > 0 && (0, Y.jsxs)(`div`, { style: { fontSize: M.xs, color: l.faint }, children: [N2.length, ` most recently used of `, k2.length, ` sites shown. The full list lives under Vault and Sites.`] })] }), z2 && (0, Y.jsxs)(A, { title: z2.role, children: [(0, Y.jsxs)(`div`, { style: { display: `flex`, alignItems: `baseline`, gap: 10, flexWrap: `wrap` }, children: [(0, Y.jsx)(`strong`, { style: { fontSize: M.md }, children: z2.label ?? `\u2014` }), z2.did && (0, Y.jsx)(_, { value: z2.did, size: M.xs })] }), (0, Y.jsx)(`dl`, { style: { display: `grid`, gridTemplateColumns: `auto 1fr`, gap: `8px 18px`, margin: 0, fontSize: M.sm }, children: (z2.facts ?? []).map((e3) => (0, Y.jsx)($, { label: e3.label, children: (0, Y.jsx)(`span`, { style: { fontFamily: e3.value.startsWith(`did:`) ? `var(--w-mono)` : void 0 }, children: e3.value }) }, e3.label)) })] }), (0, Y.jsx)(St, {}), (0, Y.jsx)(Et, {}), (0, Y.jsx)(Mt, { vtaDid: e2.vtaDid }), (0, Y.jsx)(A, { title: `Details`, description: `The same facts as text, for pasting into a bug report.`, children: (0, Y.jsxs)(`dl`, { style: { display: `grid`, gridTemplateColumns: `auto 1fr`, gap: `8px 18px`, margin: 0, fontSize: M.sm }, children: [(0, Y.jsx)($, { label: Re(b2) ? `Transport in use` : `Transport expected`, children: x2 ? (0, Y.jsx)(u, { tone: Re(b2) ? `ok` : `off`, children: x2 }) : (0, Y.jsx)(u, { tone: `warn`, children: `none usable` }) }), (0, Y.jsx)($, { label: `Advertised`, children: Fe(e2).join(`, `) || `none` }), Le(e2, b2).map((e3) => (0, Y.jsxs)($, { label: `${e3} unavailable`, children: [b2[e3]?.detail ?? `could not be opened`, b2[e3]?.code ? ` (${b2[e3].code})` : ``] }, e3)), (0, Y.jsx)($, { label: `Prefer TSP`, children: a2 ? `on` : `off` }), (0, Y.jsx)($, { label: `Wallet locked`, children: s2 ? `yes` : `no` }), (0, Y.jsx)($, { label: `Your wallet address`, children: t2 ? (0, Y.jsx)(_, { value: t2, size: M.xs }) : `\u2014` }), (0, Y.jsx)($, { label: `Trust agent`, children: (0, Y.jsx)(_, { value: e2.vtaDid, size: M.xs }) }), (0, Y.jsx)($, { label: `Mediator`, children: v2 ? (0, Y.jsx)(_, { value: v2, size: M.xs }) : `none \u2014 reached directly` }), (0, Y.jsx)($, { label: `Approver identity`, children: r2 ? (0, Y.jsx)(_, { value: r2, size: M.xs }) : `none created` }), (0, Y.jsx)($, { label: `Connected since`, children: new Date(e2.connectedAt).toLocaleString() }), (0, Y.jsx)($, { label: `Extension version`, children: chrome.runtime.getManifest().version })] }) })] });
}
function $({ label: e2, children: t2 }) {
  return (0, Y.jsxs)(Y.Fragment, { children: [(0, Y.jsx)(`dt`, { style: { color: l.muted, whiteSpace: `nowrap` }, children: e2 }), (0, Y.jsx)(`dd`, { style: { margin: 0, minWidth: 0, wordBreak: `break-word` }, children: t2 })] });
}
function Pt(e2, t2, n2) {
  let r2 = /* @__PURE__ */ new Map();
  for (let t3 of e2) {
    let e3 = n2(t3.origin);
    r2.set(e3, { ...r2.get(e3), host: e3, trusted: t3 });
  }
  for (let e3 of t2) {
    let t3 = n2(e3);
    r2.set(t3, { ...r2.get(t3), host: t3, grantedPattern: e3 });
  }
  return [...r2.values()].sort((e3, t3) => {
    let n3 = e3.trusted?.trustedAt ?? 0, r3 = t3.trusted?.trustedAt ?? 0;
    return n3 === r3 ? e3.host.localeCompare(t3.host) : r3 - n3;
  });
}
function Ft(e2, t2 = Date.now()) {
  let n2 = Math.floor((t2 - e2) / 864e5);
  if (n2 <= 0) return `today`;
  if (n2 === 1) return `yesterday`;
  if (n2 < 30) return `${n2} days ago`;
  let r2 = Math.floor(n2 / 30);
  return r2 === 1 ? `a month ago` : `${r2} months ago`;
}
function It() {
  let [e2, t2] = (0, J.useState)(null), [n2, r2] = (0, J.useState)(false), [i2, a2] = (0, J.useState)(null), o2 = (0, J.useCallback)(async () => {
    let [e3, n3, i3] = await Promise.all([Ye(), y(), C()]);
    t2(Pt(e3, n3, D)), r2(i3);
  }, []);
  (0, J.useEffect)(() => {
    o2();
    let e3 = () => void o2();
    return chrome.permissions.onAdded.addListener(e3), chrome.permissions.onRemoved.addListener(e3), () => {
      chrome.permissions.onAdded.removeListener(e3), chrome.permissions.onRemoved.removeListener(e3);
    };
  }, [o2]);
  async function s2(e3) {
    if (e3.trusted) {
      a2(e3.host);
      try {
        await Je(e3.trusted.origin), await o2();
      } finally {
        a2(null);
      }
    }
  }
  async function c2(e3) {
    if (e3.grantedPattern) {
      a2(e3.host);
      try {
        await E(e3.grantedPattern), await o2();
      } finally {
        a2(null);
      }
    }
  }
  return (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 16 }, children: [(0, Y.jsx)(A, { title: `Sites`, description: `Everything this wallet is allowed to do, per site. Revoking is safe \u2014 nothing breaks permanently, you'll just be asked again next time.`, children: (0, Y.jsxs)(`div`, { style: { display: `grid`, gridTemplateColumns: `repeat(auto-fit, minmax(240px, 1fr))`, gap: 10 }, children: [(0, Y.jsx)(Lt, { edge: l.accent, title: `Can act without asking`, body: `You ticked \u201CRemember this site\u201D. It can sign you in and read vault entries with no prompt.` }), (0, Y.jsx)(Lt, { edge: l.ok, title: `Wallet can reach it`, body: `You granted access to this host, so the wallet can make requests to it and run the page provider there.` })] }) }), n2 && (0, Y.jsxs)(m, { tone: `warn`, children: [(0, Y.jsx)(`strong`, { children: `This wallet currently holds access to every site.` }), ` Per-site grants below don't limit anything while that is true. Remove the blanket permission from `, (0, Y.jsx)(`code`, { children: `chrome://extensions` }), ` \u2192 Site access to get one-site-at-a-time control back.`] }), (0, Y.jsx)(A, { children: e2 === null ? (0, Y.jsx)(O, { children: `Loading\u2026` }) : e2.length === 0 ? (0, Y.jsx)(O, { children: `No sites yet. They appear here once you connect to a trust agent or sign in to a site from your vault.` }) : (0, Y.jsx)(`div`, { style: { overflowX: `auto` }, children: (0, Y.jsxs)(`table`, { style: { width: `100%`, borderCollapse: `collapse`, fontSize: M.sm }, children: [(0, Y.jsx)(`thead`, { children: (0, Y.jsxs)(`tr`, { children: [(0, Y.jsx)(Rt, { style: { width: `42%` }, children: `Site` }), (0, Y.jsx)(Rt, { children: `Can act without asking` }), (0, Y.jsx)(Rt, { children: `Wallet can reach it` }), (0, Y.jsx)(Rt, { style: { textAlign: `right` }, children: (0, Y.jsx)(`span`, { style: { position: `absolute`, left: -9999 }, children: `Actions` }) })] }) }), (0, Y.jsx)(`tbody`, { children: e2.map((e3) => (0, Y.jsxs)(`tr`, { children: [(0, Y.jsxs)(zt, { children: [(0, Y.jsx)(`div`, { style: { fontFamily: `var(--w-mono)`, wordBreak: `break-all` }, children: e3.host }), e3.trusted && (0, Y.jsxs)(`div`, { style: { fontSize: M.xs, color: l.muted, marginTop: 2 }, children: [`Connected `, Ft(e3.trusted.trustedAt)] })] }), (0, Y.jsx)(zt, { children: e3.trusted ? (0, Y.jsx)(u, { tone: `accent`, children: `Yes` }) : (0, Y.jsx)(u, { tone: `off`, children: `Not set` }) }), (0, Y.jsx)(zt, { children: e3.grantedPattern ? (0, Y.jsx)(u, { tone: `ok`, children: `Granted` }) : (0, Y.jsx)(u, { tone: `off`, children: `Not granted` }) }), (0, Y.jsxs)(zt, { style: { textAlign: `right`, whiteSpace: `nowrap` }, children: [e3.trusted && (0, Y.jsx)(v, { kind: `danger`, disabled: i2 === e3.host, onClick: () => void s2(e3), title: `Stop ${e3.host} acting without a prompt`, children: `Disconnect` }), e3.grantedPattern && (0, Y.jsx)(v, { kind: `danger`, disabled: i2 === e3.host, onClick: () => void c2(e3), title: `Stop the wallet reaching ${e3.host}`, children: `Revoke access` })] })] }, e3.host)) })] }) }) })] });
}
function Lt({ edge: e2, title: t2, body: n2 }) {
  return (0, Y.jsxs)(`div`, { style: { borderLeft: `2px solid ${e2}`, border: `1px solid ${l.line}`, borderLeftColor: e2, borderLeftWidth: 2, borderRadius: `var(--w-r-sm)`, padding: `10px 13px`, background: l.ground }, children: [(0, Y.jsx)(`div`, { style: { fontWeight: 620, fontSize: M.sm, marginBottom: 3 }, children: t2 }), (0, Y.jsx)(`div`, { style: { fontSize: M.xs, color: l.muted, lineHeight: 1.5 }, children: n2 })] });
}
function Rt({ children: e2, style: t2 }) {
  return (0, Y.jsx)(`th`, { style: { textAlign: `left`, fontSize: `10.5px`, textTransform: `uppercase`, letterSpacing: `0.08em`, color: l.faint, fontWeight: 650, padding: `0 12px 9px 0`, borderBottom: `1px solid ${l.line}`, position: `relative`, ...t2 }, children: e2 });
}
function zt({ children: e2, style: t2 }) {
  return (0, Y.jsx)(`td`, { style: { padding: `12px 12px 12px 0`, borderBottom: `1px solid ${l.lineSoft}`, verticalAlign: `middle`, ...t2 }, children: e2 });
}
async function Bt() {
  let { prfOutput: e2 } = await g(chrome.runtime.id), t2 = I(e2), n2 = await Z({ type: _e, prfOutputB64u: t2 });
  if (!n2.ok) throw Error(n2.error);
  let r2 = await q();
  if (r2) try {
    await Z({ type: se, prfOutputB64u: t2, vtaDid: r2 });
  } catch {
  }
}
function Vt() {
  let [e2, t2] = (0, J.useState)(false), [n2, r2] = (0, J.useState)(false), [i2, a2] = (0, J.useState)(null), o2 = (0, J.useCallback)(async () => {
    try {
      let e3 = await Z({ type: ue });
      t2(e3.ok ? e3.result.encrypted && !e3.result.unlocked : false);
    } catch {
      t2(false);
    }
  }, []);
  if ((0, J.useEffect)(() => {
    o2();
    let e3 = setInterval(() => void o2(), 5e3);
    return () => clearInterval(e3);
  }, [o2]), !e2) return null;
  async function s2() {
    r2(true), a2(null);
    try {
      await Bt(), await o2();
    } catch (e3) {
      a2(e3 instanceof h && e3.reason === `cancelled` ? `Cancelled. Click Unlock to try again.` : e3 instanceof Error ? e3.message : String(e3));
    } finally {
      r2(false);
    }
  }
  return (0, Y.jsx)(`div`, { style: { marginBottom: 16 }, children: (0, Y.jsxs)(m, { tone: `warn`, children: [(0, Y.jsx)(`strong`, { children: `Your wallet is locked.` }), ` Settings are readable, but anything that uses your identity \u2014 the vault, connecting, approving \u2014 will fail until you unlock with your passkey.`, (0, Y.jsxs)(`div`, { style: { marginTop: 8, display: `flex`, gap: 10, alignItems: `center` }, children: [(0, Y.jsx)(v, { kind: `primary`, disabled: n2, onClick: () => void s2(), children: n2 ? `Waiting for your passkey\u2026` : `Unlock` }), i2 && (0, Y.jsx)(`span`, { style: { fontSize: M.sm, color: l.danger }, children: i2 })] })] }) });
}
var Ht = { setup: `M7 1.5 12 3.6v3.5c0 2.5-2 4.4-5 5.4-3-1-5-2.9-5-5.4V3.6z`, network: `M2.6 7h3.2m2.4 0h3.2`, vault: `M2 3h10v2.4H2zm0 4.3h10v2.4H2zm0 4.3h10V14H2z`, sites: `M7 1.2a5.8 5.8 0 100 11.6A5.8 5.8 0 007 1.2zm0 1.2c1 0 2.1 1.9 2.1 4.6S8 11.6 7 11.6 4.9 9.7 4.9 7 6 2.4 7 2.4zM1.6 7h10.8`, advanced: `M2 4h5m2.6 0H12M2 10h2.6M7.2 10H12` }, Ut = [{ id: `setup`, label: `Setup` }, { id: `network`, label: `Network` }, { id: `vault`, label: `Vault` }, { id: `sites`, label: `Sites` }, { id: `advanced`, label: `Advanced` }];
function Wt({ pane: e2, active: t2 }) {
  let n2 = e2 === `sites` || e2 === `advanced` || e2 === `network`;
  return (0, Y.jsxs)(`svg`, { width: `14`, height: `14`, viewBox: `0 0 14 14`, "aria-hidden": true, style: { flex: `none` }, children: [(0, Y.jsx)(`path`, { d: Ht[e2], fill: n2 ? `none` : t2 ? l.accent : l.faint, stroke: n2 ? t2 ? l.accent : l.faint : `none`, strokeWidth: n2 ? 1.3 : 0, strokeLinecap: `round` }), e2 === `network` && (0, Y.jsxs)(Y.Fragment, { children: [(0, Y.jsx)(`circle`, { cx: `1.6`, cy: `7`, r: `1.4`, fill: t2 ? l.accent : l.faint, stroke: `none` }), (0, Y.jsx)(`circle`, { cx: `7`, cy: `7`, r: `1.4`, fill: t2 ? l.accent : l.faint, stroke: `none` }), (0, Y.jsx)(`circle`, { cx: `12.4`, cy: `7`, r: `1.4`, fill: t2 ? l.accent : l.faint, stroke: `none` })] }), e2 === `advanced` && (0, Y.jsxs)(Y.Fragment, { children: [(0, Y.jsx)(`circle`, { cx: `8.2`, cy: `4`, r: `1.5`, fill: `none`, stroke: t2 ? l.accent : l.faint, strokeWidth: `1.3` }), (0, Y.jsx)(`circle`, { cx: `5.8`, cy: `10`, r: `1.5`, fill: `none`, stroke: t2 ? l.accent : l.faint, strokeWidth: `1.3` })] })] });
}
function Gt() {
  let e2 = location.hash.replace(/^#/, ``);
  return Ut.some((t2) => t2.id === e2) ? e2 : `setup`;
}
function Kt({ advanced: e2, vault: t2 }) {
  let [n2, r2] = (0, J.useState)(Gt), i2 = xe(), [a2, o2] = (0, J.useState)(true), { health: s2, sessions: c2 } = Be(i2?.vtaDid), d2 = c2.find((e3) => e3.isInbox)?.state ?? `closed`, [f2, p2] = (0, J.useState)({ minted: false, running: false });
  (0, J.useEffect)(() => {
    K().then((e3) => o2(e3.preferTsp !== false));
  }, []), (0, J.useEffect)(() => {
    let e3 = async () => {
      let e4 = await Z({ type: W }).catch(() => null);
      e4?.ok && p2({ minted: e4.result.minted, running: e4.result.running });
    };
    e3();
    let t3 = setInterval(() => void e3(), 5e3);
    return () => clearInterval(t3);
  }, []), (0, J.useEffect)(() => {
    let e3 = () => r2(Gt());
    return window.addEventListener(`hashchange`, e3), () => window.removeEventListener(`hashchange`, e3);
  }, []);
  function m2(e3) {
    location.hash = e3, r2(e3);
  }
  return (0, Y.jsxs)(`div`, { style: { display: `grid`, gridTemplateColumns: `208px minmax(0, 1fr)`, alignItems: `start`, gap: 28 }, children: [(0, Y.jsxs)(`nav`, { "aria-label": `Wallet sections`, style: { position: `sticky`, top: 28, display: `grid`, gap: 3, alignContent: `start` }, children: [(0, Y.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 9, padding: `0 8px 16px` }, children: [(0, Y.jsx)(j, {}), (0, Y.jsx)(`span`, { style: { fontWeight: 640, letterSpacing: `-0.01em` }, children: `Star \xB7 trust` })] }), Ut.map((e3) => {
    let t3 = e3.id === n2;
    return (0, Y.jsxs)(`button`, { onClick: () => m2(e3.id), "aria-current": t3 ? `page` : void 0, style: { display: `flex`, alignItems: `center`, gap: 10, padding: `7px 9px`, borderRadius: `var(--w-r-sm)`, border: `1px solid transparent`, background: t3 ? l.accentSoft : `transparent`, color: t3 ? l.text : l.muted, fontWeight: t3 ? 600 : 400, fontSize: M.base, textAlign: `left`, cursor: `pointer`, width: `100%` }, children: [(0, Y.jsx)(Wt, { pane: e3.id, active: t3 }), e3.label] }, e3.id);
  }), (0, Y.jsx)(`button`, { onClick: () => void chrome.tabs.create({ url: chrome.runtime.getURL(`manager.html`) }), style: { display: `flex`, alignItems: `center`, gap: 10, marginTop: 10, padding: `7px 9px`, borderRadius: `var(--w-r-sm)`, border: `1px solid ${l.line}`, background: `transparent`, color: l.muted, fontSize: M.base, textAlign: `left`, cursor: `pointer`, width: `100%` }, children: `Manage agent\xA0\u2197` }), (0, Y.jsxs)(`div`, { style: { marginTop: 14, padding: `12px 8px 0`, borderTop: `1px solid ${l.line}`, display: `grid`, gap: 12 }, children: [(0, Y.jsx)(qt, { label: `Operating`, pill: i2 ? (0, Y.jsx)(u, { tone: `ok`, children: `Connected` }) : (0, Y.jsx)(u, { tone: `off`, children: `Not connected` }), note: i2 ? (() => {
    let e3 = Ie(i2, a2, s2);
    return e3 ? `over ${e3}` : `no usable transport`;
  })() : `no agent yet`, warn: !!i2 && !Ie(i2, a2, s2) }), (0, Y.jsx)(qt, { label: `Inbox`, pill: i2 ? d2 === `live` ? (0, Y.jsx)(u, { tone: `ok`, children: `Live` }) : d2 === `connecting` ? (0, Y.jsx)(u, { tone: `warn`, children: `Connecting` }) : (0, Y.jsx)(u, { tone: `warn`, children: `Offline` }) : (0, Y.jsx)(u, { tone: `off`, children: `\u2014` }), note: i2 ? d2 === `live` ? `can receive requests` : d2 === `connecting` ? `opening a mediator session` : `nothing can reach this wallet` : `no agent yet`, warn: !!i2 && d2 !== `live` && d2 !== `connecting` }), (0, Y.jsx)(qt, { label: `Approval`, pill: f2.minted ? f2.running ? (0, Y.jsx)(u, { tone: `ok`, children: `Listening` }) : (0, Y.jsx)(u, { tone: `off`, children: `Ready` }) : (0, Y.jsx)(u, { tone: `off`, children: `Not set up` }), note: f2.minted ? f2.running ? `can receive remote requests` : `prompts for this browser only` : `no approver identity` })] })] }), (0, Y.jsxs)(`main`, { style: { minWidth: 0 }, children: [(0, Y.jsx)(Vt, {}), n2 === `setup` && (0, Y.jsx)(Ue, {}), n2 === `network` && (0, Y.jsx)(Nt, {}), n2 === `vault` && t2, n2 === `sites` && (0, Y.jsx)(It, {}), n2 === `advanced` && e2] })] });
}
function qt({ label: e2, pill: t2, note: n2, warn: r2 = false }) {
  return (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 4, justifyItems: `start` }, children: [(0, Y.jsx)(`span`, { style: { fontSize: M.xs, textTransform: `uppercase`, letterSpacing: `0.09em`, fontWeight: 650, color: l.faint }, children: e2 }), t2, (0, Y.jsx)(`span`, { style: { fontSize: M.xs, color: r2 ? l.warn : l.muted, lineHeight: 1.4 }, children: n2 })] });
}
var Jt = 6, Yt = (e2) => Z({ type: ae, ...e2 }), Xt = { prfSealedKey: `Passkey`, vtaPin: `PIN`, remoteApprover: `Your phone` }, Zt = { marginTop: 16, padding: 14, border: `1px solid var(--w-line)`, borderRadius: 8, background: `var(--w-surface)` }, Qt = { width: `100%`, boxSizing: `border-box`, padding: `7px 10px`, background: `var(--w-ground)`, color: `var(--w-text)`, border: `1px solid var(--w-line)`, borderRadius: 6, fontSize: 13 }, $t = { padding: `6px 12px`, background: `none`, color: `var(--w-accent)`, border: `1px solid var(--w-line)`, borderRadius: 6, cursor: `pointer`, fontSize: 12, fontWeight: 600 };
function en(e2) {
  if (e2.code === `uvPinWrong`) {
    let t2 = e2.attemptsRemaining;
    return t2 === void 0 ? `Wrong PIN.` : `Wrong PIN. ${t2 === 1 ? `1 try` : `${t2} tries`} left before it locks.`;
  }
  return e2.code === `uvKeyLocked` ? e2.lockedUntil === void 0 ? `Too many wrong PINs. Try again later.` : `Too many wrong PINs. Locked until ${new Date(e2.lockedUntil).toLocaleString()}.` : (e2.code && F[e2.code]) ?? e2.error;
}
function tn({ send: e2 = Yt }) {
  let [t2, n2] = (0, J.useState)(), [r2, i2] = (0, J.useState)(), [a2, o2] = (0, J.useState)(), [s2, c2] = (0, J.useState)(``), [l2, u2] = (0, J.useState)(``), [d2, f2] = (0, J.useState)(``), [p2, m2] = (0, J.useState)(``), [h2, g2] = (0, J.useState)(false), [_2, v2] = (0, J.useState)();
  (0, J.useEffect)(() => {
    (async () => {
      let t3 = await e2({ op: `status` }).catch((e3) => ({ ok: false, error: e3 instanceof Error ? e3.message : String(e3) }));
      t3.ok && t3.result.op === `status` ? n2(t3.result.agents) : t3.ok || i2(t3.error);
    })();
  }, [e2]);
  let y2 = () => {
    c2(``), u2(``), f2(``), m2(``);
  }, b2 = async (t3) => {
    if (y2(), v2(void 0), o2(t3), t3.to !== `remoteApprover`) return;
    let n3 = await e2({ op: `approvers`, vtaDid: t3.vtaDid }).catch((e3) => ({ ok: false, error: e3 instanceof Error ? e3.message : String(e3) })), r3 = n3.ok && n3.result.op === `approvers` ? n3.result.approvers : [];
    r3.length === 1 && m2(r3[0].did), o2({ ...t3, approvers: r3, ...n3.ok ? {} : { error: n3.error } });
  }, x2 = async (t3) => {
    if (!a2) return;
    let r3 = t3.method === `vtaPin`, i3 = a2.to === `vtaPin` ? { op: `use-pin`, vtaDid: t3.vtaDid, newPin: l2, ...r3 ? { currentPin: s2 } : {} } : { op: `use-phone`, vtaDid: t3.vtaDid, approver: p2, ...r3 ? { currentPin: s2 } : {} };
    y2(), g2(true), v2(void 0);
    try {
      let t4 = await e2(i3);
      if (!t4.ok) {
        v2({ tone: `danger`, text: en(t4) });
        return;
      }
      if (t4.result.op === `use-pin` || t4.result.op === `use-phone`) {
        let e3 = t4.result.agent;
        n2((t5) => t5?.map((t6) => t6.vtaDid === e3.vtaDid ? e3 : t6)), v2({ tone: `ok`, text: a2.to === `vtaPin` ? r3 ? `PIN changed.` : `PIN set.` : `Your phone approves sign-ins now.` }), o2(void 0);
      }
    } catch (e3) {
      v2({ tone: `danger`, text: e3 instanceof Error ? e3.message : String(e3) });
    } finally {
      g2(false);
    }
  };
  return (0, Y.jsxs)(`div`, { style: Zt, "data-testid": `sign-in-approval`, children: [(0, Y.jsx)(`strong`, { style: { fontSize: 14, color: `var(--w-text)` }, children: `Sign-in approval` }), (0, Y.jsx)(`div`, { style: { marginTop: 8, fontSize: 12, color: `var(--w-muted)`, lineHeight: 1.5 }, children: `How this browser approves a website sign-in at each of your agents: a passkey, a PIN your agent checks, or your phone. Without a passkey that works here, choose a PIN or your phone.` }), r2 && (0, Y.jsx)(`div`, { style: { marginTop: 8, fontSize: 12, color: `var(--w-danger)` }, children: r2 }), t2?.length === 0 && (0, Y.jsx)(`div`, { style: { marginTop: 8, fontSize: 12, color: `var(--w-muted)` }, children: `Connect to an agent first.` }), t2?.map((e3) => {
    let t3 = a2?.vtaDid === e3.vtaDid ? a2 : void 0, n3 = e3.method === `vtaPin`, r3 = l2.normalize(`NFC`).length >= Jt && l2 === d2, i3 = !h2 && (!n3 || s2.length > 0) && (t3?.to === `vtaPin` ? r3 : p2.length > 0);
    return (0, Y.jsxs)(`div`, { "data-testid": `uv-agent`, style: { marginTop: 12, paddingTop: 10, borderTop: `1px solid var(--w-line)` }, children: [(0, Y.jsx)(`code`, { style: { fontSize: 11, color: `var(--w-muted)`, wordBreak: `break-all` }, children: e3.vtaDid }), (0, Y.jsxs)(`div`, { "data-testid": `uv-method`, style: { marginTop: 4, fontSize: 13, color: `var(--w-text)` }, children: [e3.method ? Xt[e3.method] : `Not set up. Your first sign-in approval sets it up.`, e3.approver && (0, Y.jsx)(`code`, { style: { marginLeft: 6, fontSize: 11, color: `var(--w-muted)`, wordBreak: `break-all` }, children: e3.approver })] }), !t3 && (0, Y.jsxs)(`div`, { style: { display: `flex`, gap: 8, marginTop: 8, flexWrap: `wrap` }, children: [(0, Y.jsx)(`button`, { type: `button`, "data-testid": `uv-to-pin`, style: $t, onClick: () => void b2({ vtaDid: e3.vtaDid, to: `vtaPin` }), children: n3 ? `Change PIN` : `Switch to PIN` }), e3.method !== `remoteApprover` && (0, Y.jsx)(`button`, { type: `button`, "data-testid": `uv-to-phone`, style: $t, onClick: () => void b2({ vtaDid: e3.vtaDid, to: `remoteApprover` }), children: `Switch to phone approval` })] }), t3 && (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 6, marginTop: 8, maxWidth: 360 }, children: [n3 && (0, Y.jsx)(`input`, { type: `password`, "data-testid": `current-pin`, placeholder: `Current PIN`, autoComplete: `off`, style: Qt, value: s2, onChange: (e4) => c2(e4.target.value) }), t3.to === `vtaPin` ? (0, Y.jsxs)(Y.Fragment, { children: [(0, Y.jsx)(`input`, { type: `password`, "data-testid": `new-pin`, placeholder: `New PIN (${Jt} or more characters)`, autoComplete: `off`, style: Qt, value: l2, onChange: (e4) => u2(e4.target.value) }), (0, Y.jsx)(`input`, { type: `password`, "data-testid": `new-pin-again`, placeholder: `New PIN again`, autoComplete: `off`, style: Qt, value: d2, onChange: (e4) => f2(e4.target.value) }), d2.length > 0 && l2 !== d2 && (0, Y.jsx)(`small`, { style: { color: `var(--w-danger)` }, children: `The two PINs don't match.` })] }) : t3.approvers === void 0 ? (0, Y.jsx)(`small`, { style: { color: `var(--w-muted)` }, children: `Asking your agent for your phone\u2026` }) : t3.approvers.length === 0 ? (0, Y.jsxs)(`small`, { "data-testid": `no-phones`, style: { color: `var(--w-warn)`, lineHeight: 1.5 }, children: [`Your phone can't approve for this browser yet. Connect the OpenVTC app on your phone to the same agent, then ask an administrator of the agent to make that phone this browser's approver.`, t3.error ? ` (${t3.error})` : ``] }) : t3.approvers.map((t4) => (0, Y.jsxs)(`label`, { style: { display: `flex`, gap: 8, alignItems: `center`, fontSize: 13 }, children: [(0, Y.jsx)(`input`, { type: `radio`, name: `approver-${e3.vtaDid}`, "data-testid": `approver`, checked: p2 === t4.did, onChange: () => m2(t4.did) }), (0, Y.jsxs)(`span`, { children: [t4.displayName ?? `Phone`, ` `, (0, Y.jsx)(`code`, { style: { fontSize: 11, color: `var(--w-muted)` }, children: t4.did })] })] }, t4.did)), (0, Y.jsxs)(`div`, { style: { display: `flex`, gap: 8, marginTop: 4 }, children: [(0, Y.jsx)(`button`, { type: `button`, "data-testid": `uv-save`, disabled: !i3, style: { ...$t, opacity: i3 ? 1 : 0.5 }, onClick: () => void x2(e3), children: h2 ? `Working\u2026` : t3.to === `vtaPin` ? `Save PIN` : `Use this phone` }), (0, Y.jsx)(`button`, { type: `button`, "data-testid": `uv-cancel`, style: $t, onClick: () => {
      y2(), o2(void 0);
    }, children: `Cancel` })] })] })] }, e3.vtaDid);
  }), _2 && (0, Y.jsx)(`div`, { "data-testid": `uv-status`, style: { marginTop: 10, fontSize: 12, color: _2.tone === `ok` ? `var(--w-ok)` : `var(--w-danger)` }, children: _2.text })] });
}
var nn = { width: `100%`, boxSizing: `border-box`, padding: `8px 10px`, background: `var(--w-ground)`, color: `var(--w-text)`, border: `1px solid var(--w-line)`, borderRadius: 6, fontFamily: `ui-monospace, monospace`, fontSize: 13 }, rn = { fontSize: 13, color: `var(--w-muted)`, marginTop: 14 };
function an() {
  let [e2, t2] = (0, J.useState)(``), [n2, r2] = (0, J.useState)(``), [i2, a2] = (0, J.useState)(``), [o2, s2] = (0, J.useState)(``), [c2, l2] = (0, J.useState)(``), [u2, d2] = (0, J.useState)(``), [f2, p2] = (0, J.useState)(false), [m2, h2] = (0, J.useState)(false), [_2, v2] = (0, J.useState)(false), [y2, x2] = (0, J.useState)([]), [C2, w2] = (0, J.useState)(null), [T2, E2] = (0, J.useState)(false), [D2, O2] = (0, J.useState)(false), [k2, A2] = (0, J.useState)(null), [j2, M2] = (0, J.useState)(false);
  (0, J.useEffect)(() => {
    (async () => {
      let e3 = await K();
      t2(e3.defaultStepUpVtaDid ?? ``), r2(e3.defaultStepUpVtaMediatorDid ?? ``), a2((e3.enrolledExecutorDids ?? []).join(`
`)), s2(e3.pushGatewayUrl ?? ``), l2(e3.pushGatewayVapidPublicKey ?? ``), p2(!!e3.encryptHolderSecret), v2(!!e3.preferTsp), x2(e3.myTermsOffers ?? []), d2(await Se() ?? ``);
      let n3 = await q();
      n3 && w2(await R(new G(), n3));
    })();
  }, []);
  async function N2() {
    E2(true), A2(null);
    try {
      let e3 = await q();
      if (!e3) {
        A2(`No active VTA \u2014 connect to a VTA first, then create the approver.`);
        return;
      }
      let { prfOutput: t3 } = await g(chrome.runtime.id), n3 = new G(), r3 = await te(n3, { vtaDid: e3, secretWrap: new L(t3) });
      w2(r3.did), A2(`Approver identity created. Register its DID in the VTA's approver set + ACL.`);
    } catch (e3) {
      let t3 = e3 instanceof Error ? e3.message : String(e3);
      A2(`Error: ${t3}`);
    } finally {
      E2(false);
    }
  }
  let P2 = (0, J.useCallback)(async () => {
    let e3 = await Z({ type: W }).catch(() => null);
    e3?.ok && (O2(e3.result.running), e3.result.approverDid && w2(e3.result.approverDid));
  }, []);
  (0, J.useEffect)(() => {
    P2();
    let e3 = setInterval(() => void P2(), 5e3);
    return () => clearInterval(e3);
  }, [P2]);
  async function F2() {
    E2(true), A2(null);
    try {
      let e3 = await q();
      if (!e3) {
        A2(`No active VTA \u2014 connect first.`);
        return;
      }
      let { prfOutput: t3 } = await g(chrome.runtime.id), n3 = await Z({ type: se, prfOutputB64u: I(t3), vtaDid: e3 });
      n3.ok ? (A2(`Approver unlocked \u2014 its inbox is now listening for approvals.`), await P2()) : A2(`Error: ${n3.error}`);
    } catch (e3) {
      let t3 = e3 instanceof Error ? e3.message : String(e3);
      A2(`Error: ${t3}`);
    } finally {
      E2(false);
    }
  }
  async function z2(e3) {
    h2(true), A2(null);
    try {
      if (!e3 && f2 && !window.confirm(`Disable wallet encryption?

Your Ed25519 root secret will be re-saved as plaintext. Anyone with origin-scoped storage access (a malicious extension, an XSS in this extension's pages, device-level exfil) can read it without your authenticator.

Proceed?`)) {
        h2(false);
        return;
      }
      let t3 = new G(), n3 = await oe(t3);
      if (n3.length === 0) {
        A2(`Connect to a VTA first: there is no wallet on this device to encrypt yet.`);
        return;
      }
      if (e3) {
        for (let e4 of n3) e4.wrapAlgorithm === `passthrough` && await b(e4.vtaDid);
        await H({ encryptHolderSecret: true }), p2(true), A2(`Encryption enabled \u2014 tap your authenticator on each cold start to unlock the wallet.`);
      } else {
        let { prfOutput: e4 } = await g(chrome.runtime.id);
        await U.seedCachedKeyFromPrfOutput(e4);
        let r3 = new U(chrome.runtime.id);
        for (let e5 of n3) e5.wrapAlgorithm !== `passthrough` && await ne(t3, { vtaDid: e5.vtaDid, fromWrap: r3 });
        await U.unenroll(), await H({ encryptHolderSecret: false }), p2(false), A2(`Encryption disabled \u2014 wallet secret re-saved as plaintext.`);
      }
    } catch (e4) {
      let t3 = e4 instanceof Error ? e4.message : String(e4);
      A2(`Error: ${t3}`);
    } finally {
      h2(false);
    }
  }
  async function B2() {
    M2(true), A2(null);
    try {
      await H({ ...e2.trim() ? { defaultStepUpVtaDid: e2.trim() } : {}, ...n2.trim() ? { defaultStepUpVtaMediatorDid: n2.trim() } : {}, enrolledExecutorDids: i2.split(`
`).map((e3) => e3.trim()).filter((e3) => e3.length > 0), ...o2.trim() ? { pushGatewayUrl: o2.trim() } : {}, ...c2.trim() ? { pushGatewayVapidPublicKey: c2.trim() } : {} }), d2(await Se() ?? ``), A2(`Saved.`);
    } catch (e3) {
      A2(`Error: ${e3 instanceof Error ? e3.message : String(e3)}`);
    } finally {
      M2(false);
    }
  }
  return (0, Y.jsxs)(`div`, { style: { display: `grid`, gap: 4 }, children: [(0, Y.jsx)(`h1`, { style: { margin: `0 0 4px`, fontSize: 20 }, children: `Advanced` }), (0, Y.jsxs)(`div`, { style: { fontSize: 13, color: `var(--w-muted)`, maxWidth: `64ch`, lineHeight: 1.55 }, children: [`Everything here is optional \u2014 the wallet works without any of it. Your inbox and the passkey lock live under `, (0, Y.jsx)(`strong`, { children: `Setup` }), `.`] }), (0, Y.jsxs)(`div`, { style: { fontSize: 13, color: `var(--w-muted)`, marginTop: 6 }, children: [`Current wallet DID:`, ` `, (0, Y.jsx)(`code`, { style: { wordBreak: `break-all`, color: `var(--w-text)` }, children: u2 || `\u2014` })] }), (0, Y.jsx)(`label`, { style: rn, children: `Default step-up VTA DID (optional)` }), (0, Y.jsx)(`input`, { style: nn, value: e2, placeholder: `did:webvh:\u2026`, onChange: (e3) => t2(e3.target.value) }), (0, Y.jsx)(`label`, { style: rn, children: `Default step-up VTA mediator DID (optional)` }), (0, Y.jsx)(`input`, { style: nn, value: n2, placeholder: `did:webvh:\u2026`, onChange: (e3) => r2(e3.target.value) }), (0, Y.jsx)(`label`, { style: rn, children: `Enrolled executor DIDs (optional \u2014 one per line)` }), (0, Y.jsx)(`textarea`, { style: { ...nn, minHeight: 64, resize: `vertical` }, value: i2, placeholder: `did:webvh:\u2026 (e.g. a DID-hosting control plane)`, onChange: (e3) => a2(e3.target.value) }), (0, Y.jsx)(`small`, { style: { color: `var(--w-muted)`, marginTop: 4 }, children: `Executors beyond your onboarded VTA(s) whose signed approval requests (task consent, step-up) this wallet will render. Requests signed by anyone not enrolled are dropped without prompting.` }), (0, Y.jsx)(`label`, { style: rn, children: `Push gateway URL (optional \u2014 Web Push test)` }), (0, Y.jsx)(`input`, { style: nn, value: o2, placeholder: `https://gateway.example`, onChange: (e3) => s2(e3.target.value) }), (0, Y.jsx)(`label`, { style: rn, children: `Push gateway VAPID public key (optional)` }), (0, Y.jsx)(`input`, { style: nn, value: c2, placeholder: `base64url P-256 public key`, onChange: (e3) => l2(e3.target.value) }), (0, Y.jsxs)(`small`, { style: { color: `var(--w-muted)`, marginTop: 4 }, children: [`Set both to enable Web Push wake-up: the wallet subscribes with this VAPID key, registers with the gateway (`, (0, Y.jsx)(`code`, { children: `push/register` }), `), and conveys the handle to the active VTA (`, (0, Y.jsx)(`code`, { children: `device/set-wake` }), `). Leave blank to keep push off.`] }), (0, Y.jsxs)(`div`, { style: { marginTop: 22, padding: 14, border: `1px solid var(--w-line)`, borderRadius: 8, background: `var(--w-surface)` }, children: [(0, Y.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 10 }, children: [(0, Y.jsx)(`input`, { id: `encryptHolderSecret`, type: `checkbox`, checked: f2, disabled: m2, onChange: (e3) => void z2(e3.target.checked), style: { transform: `scale(1.2)` } }), (0, Y.jsxs)(`label`, { htmlFor: `encryptHolderSecret`, style: { fontSize: 14, color: `var(--w-text)` }, children: [`Encrypt wallet at rest (WebAuthn / passkey)`, m2 && (0, Y.jsx)(`span`, { style: { marginLeft: 8, color: `var(--w-muted)`, fontSize: 12 }, children: `working\u2026` })] })] }), (0, Y.jsxs)(`div`, { style: { marginTop: 10, fontSize: 12, color: `var(--w-muted)`, lineHeight: 1.5 }, children: [`Wraps the Ed25519 root secret with an AES key derived from a WebAuthn PRF credential on your authenticator (Touch ID, Windows Hello, FIDO2 key). Without this, the secret lives plaintext in IndexedDB.`, (0, Y.jsx)(`br`, {}), (0, Y.jsx)(`strong`, { children: `If you lose your passkey:` }), ` you won't be able to unlock this wallet again, but nothing important is lost \u2014 your credentials are kept by your trust agent, not in this browser. You'd set the wallet up again and reconnect, and the sites you use would need reconnecting too. You'll be asked for your passkey once per browser session.`, ` `, f2 ? `Toggle off to revert.` : ``] })] }), (0, Y.jsxs)(`div`, { style: { marginTop: 16, padding: 14, border: `1px solid var(--w-line)`, borderRadius: 8, background: `var(--w-surface)` }, children: [(0, Y.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 8 }, children: [(0, Y.jsx)(`span`, { "aria-hidden": true, style: { fontSize: 16 }, children: `\u{1F6E1}\uFE0F` }), (0, Y.jsx)(`strong`, { style: { fontSize: 14, color: `var(--w-text)` }, children: `Approver identity (biometric approval)` })] }), (0, Y.jsxs)(`div`, { style: { marginTop: 10, fontSize: 12, color: `var(--w-muted)`, lineHeight: 1.5 }, children: [`A second, distinct identity this browser uses to `, (0, Y.jsx)(`em`, { children: `approve` }), ` tasks \u2014 separate from the working identity that `, (0, Y.jsx)(`em`, { children: `requests` }), ` them. Its signing key is released only by your authenticator, per approval. Create it here, then register the DID below in the VTA's`, ` `, (0, Y.jsx)(`code`, { children: `approver_set` }), ` and ACL (as a context admin) so its approvals confer authority.`] }), C2 ? (0, Y.jsx)(`div`, { style: { marginTop: 10, fontSize: 12, color: `var(--w-ok)`, lineHeight: 1.5, background: `var(--w-ok-soft)`, border: `1px solid var(--w-ok-soft)`, borderRadius: 6, padding: `8px 10px` }, children: D2 ? (0, Y.jsxs)(Y.Fragment, { children: [`Listening. Approvals for tasks proposed on `, (0, Y.jsx)(`em`, { children: `other` }), ` devices reach you here, and a task started in this browser prompts you directly.`] }) : (0, Y.jsxs)(Y.Fragment, { children: [`Ready. A task started in this browser prompts you automatically. Unlock the wallet \u2014 or use the button below \u2014 to also receive approvals for tasks proposed on a `, (0, Y.jsx)(`em`, { children: `different` }), ` device.`] }) }) : null, C2 ? (0, Y.jsxs)(`div`, { style: { marginTop: 12 }, children: [(0, Y.jsx)(`div`, { style: { fontSize: 11, color: `var(--w-muted)`, marginBottom: 4 }, children: `Approver DID (active VTA)` }), (0, Y.jsx)(`code`, { style: { display: `block`, wordBreak: `break-all`, color: `var(--w-accent)`, background: `var(--w-accent-soft)`, border: `1px solid var(--w-accent-soft)`, borderRadius: 6, padding: `8px 10px`, fontSize: 12 }, children: C2 }), (0, Y.jsxs)(`div`, { style: { display: `flex`, gap: 8, marginTop: 8, flexWrap: `wrap` }, children: [(0, Y.jsx)(`button`, { type: `button`, onClick: () => void navigator.clipboard.writeText(C2), style: { padding: `6px 12px`, background: `none`, color: `var(--w-accent)`, border: `1px solid var(--w-line)`, borderRadius: 6, cursor: `pointer`, fontSize: 12, fontWeight: 600 }, children: `Copy DID` }), (0, Y.jsx)(S, { value: C2, size: 16 }), D2 ? (0, Y.jsxs)(`span`, { style: { display: `inline-flex`, alignItems: `center`, gap: 7, padding: `6px 12px`, borderRadius: 999, background: `var(--w-ok-soft)`, color: `var(--w-ok)`, fontSize: 12, fontWeight: 700 }, children: [(0, Y.jsx)(`span`, { "aria-hidden": true, children: `\u25CF` }), ` Approver is running`] }) : (0, Y.jsx)(`button`, { type: `button`, onClick: () => void F2(), disabled: T2, style: { padding: `6px 14px`, background: `var(--w-accent)`, color: `var(--w-accent-ink)`, border: `none`, borderRadius: 6, cursor: T2 ? `not-allowed` : `pointer`, fontSize: 12, fontWeight: 700, opacity: T2 ? 0.6 : 1 }, children: T2 ? `Working\u2026` : `Start approving (unlock)` })] })] }) : (0, Y.jsx)(`button`, { type: `button`, onClick: () => void N2(), disabled: T2 || !f2, style: { marginTop: 12, padding: `9px 16px`, background: f2 ? `var(--w-accent)` : `var(--w-raised)`, color: `var(--w-accent-ink)`, border: `none`, borderRadius: 6, cursor: T2 || !f2 ? `not-allowed` : `pointer`, fontSize: 13, fontWeight: 700, opacity: T2 ? 0.6 : 1 }, children: T2 ? `Creating\u2026` : `Create approver identity` }), !f2 && !C2 && (0, Y.jsx)(`div`, { style: { marginTop: 8, fontSize: 12, color: `var(--w-warn)` }, children: `Enable \u201CEncrypt wallet at rest\u201D above first \u2014 it enrolls the authenticator the approver key reuses.` })] }), (0, Y.jsx)(tn, {}), (0, Y.jsxs)(`div`, { style: { marginTop: 22, padding: 14, border: `1px solid var(--w-line)`, borderRadius: 8, background: `var(--w-surface)` }, children: [(0, Y.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 10 }, children: [(0, Y.jsx)(`input`, { id: `preferTsp`, type: `checkbox`, checked: _2, onChange: (e3) => {
    let t3 = e3.target.checked;
    v2(t3), H({ preferTsp: t3 });
  }, style: { transform: `scale(1.2)` } }), (0, Y.jsx)(`label`, { htmlFor: `preferTsp`, style: { fontSize: 14, color: `var(--w-text)` }, children: `Prefer TSP transport` })] }), (0, Y.jsxs)(`div`, { style: { marginTop: 10, fontSize: 12, color: `var(--w-muted)`, lineHeight: 1.5 }, children: [`When a VTA advertises a `, (0, Y.jsx)(`code`, { children: `TSPTransport` }), ` service, route trust tasks over TSP first (TSP > DIDComm > REST). TSP shares the same mediator socket as DIDComm and falls back to DIDComm if it can't connect. `, (0, Y.jsx)(`strong`, { children: `On by default.` }), ` Turn off to pin a VTA to DIDComm/REST if a particular mediator's TSP delivery misbehaves.`] })] }), (0, Y.jsxs)(`div`, { "data-testid": `myterms`, style: { marginTop: 22, padding: 14, border: `1px solid var(--w-line)`, borderRadius: 8, background: `var(--w-surface)` }, children: [(0, Y.jsx)(`div`, { style: { fontSize: 14, color: `var(--w-text)` }, children: `Your terms (MyTerms, IEEE 7012)` }), (0, Y.jsx)(`div`, { style: { margin: `6px 0 10px`, fontSize: 12, color: `var(--w-muted)`, lineHeight: 1.5 }, children: `Tick the agreements you are willing to present at a community's door and put them in your order. The first one a community accepts is proffered; with none accepted, its counter-offer is shown instead. The roster is Customer Commons'; this wallet carries a mirror and invents none. The same choice, with each community's switch and your records, is in the console under Agreements.` }), (0, Y.jsx)(we, { compact: true, value: y2, onChange: (e3) => {
    x2(e3), H({ myTermsOffers: e3 });
  } }), (0, Y.jsxs)(`div`, { style: { marginTop: 10, fontSize: 12, color: `var(--w-muted)`, lineHeight: 1.5 }, children: [`When you join a community whose DID document names a `, (0, Y.jsx)(`code`, { children: `MyTerms` }), ` service, the join screen shows the agreement it will take. The agreement rides inside your signed request. Nothing is sent to a community on its own.`] })] }), (0, Y.jsx)(`button`, { onClick: B2, disabled: j2, style: { marginTop: 18, padding: `10px 16px`, background: `var(--w-accent)`, color: `var(--w-accent-ink)`, border: `none`, borderRadius: 6, cursor: j2 ? `default` : `pointer`, fontSize: 14, justifySelf: `start` }, children: j2 ? `Working\u2026` : `Save settings` }), k2 && (0, Y.jsx)(`small`, { style: { marginTop: 8, color: k2.startsWith(`Error`) ? `var(--w-danger)` : `var(--w-ok)` }, children: k2 })] });
}
function on() {
  return (0, Y.jsx)(Kt, { advanced: (0, Y.jsx)(an, {}), vault: (0, Y.jsx)(sn, {}) });
}
function sn() {
  return (0, Y.jsx)(`div`, { style: { display: `grid`, gap: 16 }, children: (0, Y.jsx)(be, {}) });
}
w(document);
var cn = document.getElementById(`root`);
cn && (0, Ce.createRoot)(cn).render((0, Y.jsx)(J.StrictMode, { children: (0, Y.jsx)(on, {}) }));
