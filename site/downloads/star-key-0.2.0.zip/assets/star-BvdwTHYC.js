import { i as e } from "./rolldown-runtime-Dd_uD5pT.js";
import { t } from "./star-brand-Dx2wZrCK.js";
import { a as n, r, t as i } from "./theme-pbhxFgxu.js";
function a(e2) {
  if (e2 === null || typeof e2 == `boolean` || typeof e2 == `string` || typeof e2 == `number` && Number.isFinite(e2)) return JSON.stringify(e2);
  if (Array.isArray(e2)) return `[` + e2.map(a).join(`,`) + `]`;
  if (e2 && typeof e2 == `object` && Object.getPrototypeOf(e2) === Object.prototype) {
    let t2 = e2;
    return `{` + Object.keys(t2).sort().map((e3) => JSON.stringify(e3) + `:` + a(t2[e3])).join(`,`) + `}`;
  }
  throw Error(`Only finite JSON values can be addressed.`);
}
async function o(e2) {
  let t2 = await crypto.subtle.digest(`SHA-256`, new Uint8Array(e2));
  return `sha256:` + [...new Uint8Array(t2)].map((e3) => e3.toString(16).padStart(2, `0`)).join(``);
}
async function s(e2) {
  if (!e2 || typeof e2 != `object` || Array.isArray(e2)) throw Error(`A Star reading is required.`);
  let t2 = e2;
  if (t2.schema !== `star-reading/0.1` || t2.authority !== `unverified-import` || t2.sourceVersion !== 1) throw Error(`Unsupported Star reading.`);
  if (Object.keys(t2).some((e3) => ![`schema`, `authority`, `sourceVersion`, `name`, `palette`, `lit`].includes(e3))) throw Error(`Unexpected fields: export the selected Star reading first.`);
  if (typeof t2.name != `string` || !t2.name.trim() || t2.name.length > 200) throw Error(`Invalid reading name.`);
  let n2 = t2.palette;
  if (!n2 || Object.keys(n2).sort().join(`,`) !== `cool,mage,sword,warm` || Object.values(n2).some((e3) => typeof e3 != `string` || !/^#[0-9a-f]{6}$/i.test(e3))) throw Error(`Invalid palette.`);
  if (!Array.isArray(t2.lit) || t2.lit.length > 64 || t2.lit.some((e3) => !Number.isInteger(e3) || e3 < 0 || e3 > 63)) throw Error(`Invalid vertices.`);
  let r2 = new TextEncoder().encode(a(e2));
  return { schema: `star-registry-entry/1`, profile: `agentprivacy-json-sorted/1`, kappa: await o(r2), content: JSON.parse(new TextDecoder().decode(r2)) };
}
var c = e(n(), 1), l = i();
function u(e2) {
  if (!e2 || typeof e2 != `object` || Array.isArray(e2)) throw Error(`Choose a City Key JSON object.`);
  let t2 = e2;
  if (t2.version !== 1) throw Error(`Only City Key version 1 is supported in this experiment.`);
  if (typeof t2.name != `string` || !t2.name.trim() || t2.name.length > 200) throw Error(`The key needs a name of 1\u2013200 characters.`);
  let n2 = t2.palette, r2 = {};
  for (let e3 of [`cool`, `warm`, `sword`, `mage`]) {
    let t3 = n2?.[e3];
    if (typeof t3 != `string` || !/^#[0-9a-f]{6}$/i.test(t3)) throw Error(`Palette colours must be six-digit hex values.`);
    r2[e3] = t3;
  }
  if (t2.lit !== void 0 && (!Array.isArray(t2.lit) || t2.lit.length > 64 || t2.lit.some((e3) => !Number.isInteger(e3) || e3 < 0 || e3 > 63))) throw Error(`Lit vertices must be integers from 0 to 63, with at most 64 entries.`);
  return { schema: `star-reading/0.1`, authority: `unverified-import`, sourceVersion: 1, name: t2.name.trim(), palette: r2, lit: [...new Set(t2.lit ?? [])].sort((e3, t3) => e3 - t3) };
}
function d(e2, t2) {
  return JSON.stringify({ ...e2, lit: t2 ? [...e2.lit] : [] });
}
var f = /* @__PURE__ */ new Set([`name`, `version`, `palette`, `lit`, `descriptions`, `focus`, `walks`, `packets`, `identity`, `did`, `kappa`, `prior`, `trace`, `figures`, `geometry`, `receipts`, `credentials`]);
function p(e2) {
  let t2 = e2 && typeof e2 == `object` && !Array.isArray(e2) ? e2 : {}, n2 = (e3) => Array.isArray(e3) ? e3.length : e3 && typeof e3 == `object` ? Object.keys(e3).length : 0, r2 = (e3) => e3 != null && e3 !== ``, i2 = t2.packets;
  return { descriptions: n2(t2.descriptions), lit: n2(t2.lit), focus: n2(t2.focus), walks: n2(t2.walks), packets: typeof i2?.count == `number` ? i2.count : n2(i2), receipts: n2(t2.receipts), credentials: n2(t2.credentials), identity: r2(t2.identity), did: r2(t2.did), kappa: r2(t2.kappa), prior: r2(t2.prior), trace: r2(t2.trace), figures: r2(t2.figures), geometry: r2(t2.geometry), other: Object.keys(t2).filter((e3) => !f.has(e3)).sort() };
}
var m = r();
function h() {
  let e2 = (0, c.useRef)(0), [n2, r2] = (0, c.useState)(null), [i2, a2] = (0, c.useState)(null), [o2, l2] = (0, c.useState)(false), [f2, h2] = (0, c.useState)(``), [g, _] = (0, c.useState)(``), [v, y] = (0, c.useState)(``);
  async function b(t2) {
    let n3 = ++e2.current;
    if (r2(null), _(``), h2(``), y(``), l2(false), a2(null), t2) try {
      if (t2.size > 1048576) throw Error(`Choose a key smaller than 1 MiB.`);
      let i3 = JSON.parse(await t2.text()), o3 = u(i3);
      if (n3 !== e2.current) return;
      r2(o3), a2(p(i3)), y(`Local reading prepared. No identity or relationship has been verified.`);
    } catch (t3) {
      if (n3 !== e2.current) return;
      y(t3 instanceof Error ? t3.message : `The key could not be read.`);
    }
  }
  function x() {
    if (!f2) return;
    let e3 = URL.createObjectURL(new Blob([f2], { type: `application/json` })), t2 = document.createElement(`a`);
    t2.href = e3, t2.download = `star-registry-entry.json`, t2.click(), setTimeout(() => URL.revokeObjectURL(e3), 1e3);
  }
  return (0, m.jsxs)(m.Fragment, { children: [(0, m.jsx)(t, {}), (0, m.jsxs)(`main`, { className: `star-reading`, children: [(0, m.jsx)(`p`, { className: `star-kicker`, children: `THE JOURNEY YOU CHOOSE TO CARRY` }), (0, m.jsx)(`h1`, { children: `Read your City Key.` }), (0, m.jsx)(`p`, { children: `Inspect a selected local reading before it travels. Your original key remains with you.` }), (0, m.jsxs)(`div`, { className: `star-grid`, children: [(0, m.jsxs)(`section`, { children: [(0, m.jsx)(`img`, { className: `star-art`, src: `star-manifold.svg`, alt: `Editorial Star manifold; not a verified rendering of the imported key` }), (0, m.jsx)(`p`, { className: `star-small`, children: `The Star is the model\u2019s visual language. This artwork is illustrative; mapping a verified encounter is a later integration.` })] }), (0, m.jsxs)(`section`, { className: `star-card`, children: [(0, m.jsxs)(`label`, { children: [`Choose City Key JSON`, (0, m.jsx)(`input`, { "aria-label": `Choose City Key JSON`, type: `file`, accept: `.json,application/json`, onChange: (e3) => {
    b(e3.target.files?.[0]), e3.target.value = ``;
  } })] }), n2 && (0, m.jsxs)(m.Fragment, { children: [(0, m.jsx)(`h2`, { children: n2.name }), (0, m.jsxs)(`p`, { children: [n2.lit.length, ` claimed vertices \xB7 unverified import`] }), (0, m.jsx)(`p`, { className: `star-small`, children: `This reading includes only the name, palette and selected vertex list. Private fields, descriptions, identity, credentials and evidence are not copied.` }), i2 && (0, m.jsxs)(`details`, { className: `star-small`, children: [(0, m.jsx)(`summary`, { children: `Accessible past \xB7 what stays behind` }), (0, m.jsxs)(`p`, { children: [`This reading carries: name \xB7 palette`, o2 ? ` \xB7 ${n2.lit.length} claimed vertices` : ``, `.`] }), (0, m.jsxs)(`p`, { children: [`The retained key still holds: `, [i2.kappa ? `\u03BA` : null, i2.prior ? `prior \u03BA (lineage)` : null, i2.walks ? `${i2.walks} walks` : null, i2.packets ? `${i2.packets} packets` : null, i2.descriptions ? `${i2.descriptions} descriptions` : null, i2.focus ? `${i2.focus} focus entries` : null, i2.identity ? `identity` : null, i2.did ? `did` : null, i2.trace ? `trace` : null, i2.figures ? `figures` : null, i2.geometry ? `geometry` : null, i2.receipts ? `${i2.receipts} receipts` : null, i2.credentials ? `${i2.credentials} credentials` : null].filter(Boolean).join(` \xB7 `) || `nothing beyond this reading`, i2.other.length ? ` \xB7 other fields: ${i2.other.join(`, `)}` : ``, `. Counts only; no value is shown or exported.`] }), (0, m.jsx)(`p`, { children: `A reader holding the retained key, or the City's logs, can reconstruct lineage this reading omits. Provenance needs a declared reader and an explicit access basis; decide whether lineage references are disclosable before export.` })] }), (0, m.jsxs)(`label`, { children: [(0, m.jsx)(`input`, { type: `checkbox`, checked: o2, onChange: (t2) => {
    e2.current++, l2(t2.target.checked), _(``), h2(``);
  } }), ` Include claimed vertices in the export`] }), (0, m.jsx)(`button`, { onClick: async () => {
    let t2 = ++e2.current;
    try {
      let r3 = await s(JSON.parse(d(n2, o2)));
      if (t2 !== e2.current) return;
      _(r3.kappa), h2(JSON.stringify(r3, null, 2)), y(`Content address derived locally. Ready for your selected UOR registry.`);
    } catch (n3) {
      t2 === e2.current && y(n3 instanceof Error ? n3.message : `Addressing failed`);
    }
  }, children: `Address selected reading \xB7 \u03BA` })] }), (0, m.jsx)(`button`, { disabled: true, children: `Create ZK proof \xB7 coming soon` }), (0, m.jsx)(`p`, { className: `star-small`, children: `Compression is compact JSON, not encryption or proof. The registry entry wraps the selected reading. Register it with scripts/star-registry.mjs; the adapter uploads canonical bytes and verifies the read-back. It does not replace a City Key or issue a credential.` }), g && (0, m.jsxs)(`p`, { className: `star-small`, style: { overflowWrap: `anywhere` }, children: [`\u03BA \xB7 `, g, (0, m.jsx)(`br`, {}), `Canonical JSON \xB7 SHA-256 \xB7 content address, not an identity anchor`] }), f2 && (0, m.jsxs)(m.Fragment, { children: [(0, m.jsx)(`pre`, { children: f2 }), (0, m.jsx)(`button`, { onClick: x, children: `Download registry entry` })] }), (0, m.jsx)(`p`, { role: `status`, children: v }), (0, m.jsx)(`button`, { onClick: () => {
    e2.current++, r2(null), a2(null), _(``), h2(``), y(`Local reading cleared.`);
  }, children: `Clear reading` })] })] }), (0, m.jsxs)(`nav`, { children: [(0, m.jsx)(`a`, { href: `options.html#setup`, children: `VTA setup` }), (0, m.jsx)(`a`, { href: `https://agentprivacy.ai/city`, target: `_blank`, rel: `noreferrer`, children: `Your City Key \u2197` }), (0, m.jsx)(`a`, { href: `https://soulbis.com/star`, target: `_blank`, rel: `noreferrer`, children: `Open Soulbis Star \u2197` }), (0, m.jsx)(`a`, { href: `https://mages.city/`, target: `_blank`, rel: `noreferrer`, children: `Mages City \u2197` })] }), (0, m.jsx)(`p`, { className: `star-small`, children: `Star experiment on OpenVTC \xB7 all protocol names and upstream attribution retained. No data from this page is persisted or transmitted automatically.` })] })] });
}
(0, l.createRoot)(document.getElementById(`root`)).render((0, m.jsx)(h, {}));
