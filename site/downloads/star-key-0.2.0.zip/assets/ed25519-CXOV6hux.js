import { t as e } from "./ed25519-CV189T12.js";
export {
  e as ed25519
};
