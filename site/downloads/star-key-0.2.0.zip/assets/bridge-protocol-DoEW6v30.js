import { S as e, t, x as n } from "./didcomm-D5nXYRy6.js";
import { n as r, t as i } from "./ed25519-CV189T12.js";
var a = class {
  dbName;
  storeName;
  dbPromise = null;
  constructor(e2) {
    this.dbName = e2?.dbName ?? `pnm`, this.storeName = e2?.storeName ?? `kv`;
  }
  async get(e2) {
    let t3 = await this.openDb();
    return new Promise((n2, r2) => {
      let i2 = t3.transaction(this.storeName, `readonly`).objectStore(this.storeName).get(e2);
      i2.onsuccess = () => n2(i2.result), i2.onerror = () => r2(i2.error);
    });
  }
  async put(e2, t3) {
    let n2 = await this.openDb();
    await new Promise((r2, i2) => {
      let a2 = n2.transaction(this.storeName, `readwrite`);
      a2.objectStore(this.storeName).put(t3, e2), a2.oncomplete = () => r2(), a2.onerror = () => i2(a2.error);
    });
  }
  async delete(e2) {
    let t3 = await this.openDb();
    await new Promise((n2, r2) => {
      let i2 = t3.transaction(this.storeName, `readwrite`);
      i2.objectStore(this.storeName).delete(e2), i2.oncomplete = () => n2(), i2.onerror = () => r2(i2.error);
    });
  }
  async keys(e2) {
    let t3 = await this.openDb(), n2 = e2 === void 0 ? void 0 : IDBKeyRange.bound(e2, e2 + `\uFFFF`, false, false);
    return new Promise((e3, r2) => {
      let i2 = t3.transaction(this.storeName, `readonly`).objectStore(this.storeName), a2 = n2 === void 0 ? i2.getAllKeys() : i2.getAllKeys(n2);
      a2.onsuccess = () => e3(a2.result.map(String)), a2.onerror = () => r2(a2.error);
    });
  }
  openDb() {
    return this.dbPromise ||= new Promise((e2, t3) => {
      let n2 = indexedDB.open(this.dbName, 1);
      n2.onupgradeneeded = () => {
        let e3 = n2.result;
        e3.objectStoreNames.contains(this.storeName) || e3.createObjectStore(this.storeName);
      }, n2.onsuccess = () => e2(n2.result), n2.onerror = () => t3(n2.error);
    }), this.dbPromise;
  }
}, o = class {
  algorithm = `passthrough`;
  async wrap(t3) {
    return { algorithm: this.algorithm, ciphertextB64u: e(t3), ivB64u: ``, params: {} };
  }
  async unwrap(e2) {
    return n(e2.ciphertextB64u);
  }
};
async function s(e2, t3) {
  if (t3) {
    let n2 = await t3.wrap(e2);
    if (n2) return n2;
    throw Error(`SecretWrap '${t3.algorithm}' declined to wrap (operator cancelled?)`);
  }
  return new o().wrap(e2);
}
async function c(e2, t3) {
  if (e2.algorithm === `passthrough`) return new o().unwrap(e2);
  if (!t3 || t3.algorithm !== e2.algorithm) throw Error(`wallet is wrapped with '${e2.algorithm}' but no matching SecretWrap was supplied`);
  let n2 = await t3.unwrap(e2);
  if (!n2) throw Error(`SecretWrap '${t3.algorithm}' declined to unwrap (operator cancelled?)`);
  return n2;
}
var l = `pnm/holder-identity/v3`, u = `pnm/holder-identity/v4`, d = `pnm/holder-identity/v4/`;
function f(e2) {
  return d + e2;
}
async function p(e2) {
  let t3 = await e2.get(u);
  return t3 ? (await e2.put(f(t3.vtaDid), t3), await e2.delete(u), t3) : null;
}
function m(n2, a2, o2, s2) {
  let c2 = i.getPublicKey(n2), l2 = i.utils.toMontgomerySecret(n2), u2 = r.getPublicKey(l2), d2 = { did: a2, kid: o2, privateKey: n2, publicKey: c2 };
  return { identity: t.fromSecretJwk({ did: a2, kid: s2, jwk: { kty: `OKP`, crv: `X25519`, x: e(u2), d: e(l2) } }), signing: d2 };
}
var h = class extends Error {
  constructor() {
    super(`no persisted holder identity \u2014 onboard with a VTA`), this.name = `NoHolderError`;
  }
}, g = class extends Error {
  previousDid;
  constructor(e2) {
    super(`pre-v4 holder identity (${e2}) \u2014 re-onboard required: this build expects a VTA-minted holder DID. Connect to a VTA to mint a fresh identity.`), this.name = `RequiresReonboardError`, this.previousDid = e2;
  }
};
async function _(e2, t3) {
  let n2 = await e2.get(f(t3.vtaDid));
  if (!n2) {
    let r3 = await p(e2);
    r3 && r3.vtaDid === t3.vtaDid && (n2 = r3);
  }
  if (n2) return { ...m(await c(n2.wrappedSecret, t3.secretWrap), n2.did, n2.signingKid, n2.keyAgreementKid), freshlyMinted: false };
  let r2 = await e2.get(l);
  throw r2 ? new g(r2.did) : new h();
}
async function v(e2, t3) {
  if (t3.edSeed.length !== 32) throw Error(`installVtaMintedHolder: edSeed must be 32 bytes (got ${t3.edSeed.length})`);
  let n2 = await s(t3.edSeed, t3.secretWrap), r2 = { did: t3.did, signingKid: t3.signingKid, keyAgreementKid: t3.keyAgreementKid, wrappedSecret: n2, vtaDid: t3.vtaDid, ...t3.vtaUrl ? { vtaUrl: t3.vtaUrl } : {}, schemaVersion: 4 };
  return await e2.put(f(t3.vtaDid), r2), await e2.delete(l), await e2.delete(u), { ...m(t3.edSeed, t3.did, t3.signingKid, t3.keyAgreementKid), freshlyMinted: true };
}
async function y(e2, t3) {
  let n2 = await e2.get(f(t3.vtaDid));
  if (!n2) {
    let r3 = await p(e2);
    r3 && r3.vtaDid === t3.vtaDid && (n2 = r3);
  }
  if (!n2) throw Error(`no persisted v4 holder identity to re-wrap for ${t3.vtaDid}`);
  let r2 = await c(n2.wrappedSecret, t3.fromWrap), i2 = await s(r2, t3.toWrap), a2 = { did: n2.did, signingKid: n2.signingKid, keyAgreementKid: n2.keyAgreementKid, wrappedSecret: i2, vtaDid: n2.vtaDid, ...n2.vtaUrl ? { vtaUrl: n2.vtaUrl } : {}, schemaVersion: 4 };
  return await e2.put(f(n2.vtaDid), a2), { ...m(r2, n2.did, n2.signingKid, n2.keyAgreementKid), freshlyMinted: false };
}
async function b(e2, t3) {
  if (await p(e2), t3 !== void 0) {
    let n3 = await e2.get(f(t3));
    if (n3) return { kind: `v4`, did: n3.did, vtaDid: n3.vtaDid, wrapAlgorithm: n3.wrappedSecret.algorithm };
  } else {
    let t4 = await e2.keys(d);
    if (t4.length > 0) {
      let n3 = await e2.get(t4[0]);
      if (n3) return { kind: `v4`, did: n3.did, vtaDid: n3.vtaDid, wrapAlgorithm: n3.wrappedSecret.algorithm };
    }
  }
  let n2 = await e2.get(l);
  return n2 ? { kind: `v3`, did: n2.did } : { kind: `none` };
}
async function x(e2) {
  await p(e2);
  let t3 = await e2.keys(d), n2 = [];
  for (let r2 of t3) {
    let t4 = await e2.get(r2);
    t4 && n2.push({ vtaDid: t4.vtaDid, did: t4.did, wrapAlgorithm: t4.wrappedSecret.algorithm });
  }
  return n2;
}
async function S(e2, t3) {
  await e2.delete(f(t3));
}
function C(e2, t3 = {}) {
  let n2 = t3.what ?? `URL`, r2;
  try {
    r2 = new URL(e2);
  } catch {
    throw Error(`${n2} ${JSON.stringify(e2)} is not a URL, so nothing was sent to it`);
  }
  let i2 = O(r2.hostname), a2 = t3.allowLoopback === true && w(i2);
  if (r2.protocol !== `https:` && !(a2 && r2.protocol === `http:`)) throw Error(`${n2} ${r2.href} is ${r2.protocol} \u2014 it must be https, so nothing was sent to it`);
  if (r2.username !== `` || r2.password !== ``) throw Error(`${n2} carries a username or password in the URL, which hides the host it would actually reach (${i2}), so nothing was sent to it`);
  if (a2) return r2;
  if (!T(r2.hostname)) throw Error(`${n2}'s host ${i2} is not a public internet host, so nothing was sent to it`);
  return r2;
}
function w(e2) {
  let t3 = O(e2);
  if (t3 === `localhost` || t3.endsWith(`.localhost`) || t3 === `::1`) return true;
  let n2 = A(t3);
  return n2 !== null && n2[0] === 127;
}
function T(e2) {
  let t3 = O(e2);
  if (t3 === ``) return false;
  if (e2.startsWith(`[`)) return k(t3);
  let n2 = A(t3);
  return n2 ? !te(j(n2)) : !D(t3);
}
var E = [`localhost`, `local`, `internal`, `home.arpa`];
function D(e2) {
  return !e2.includes(`.`) || E.some((t3) => e2 === t3 || e2.endsWith(`.${t3}`));
}
function O(e2) {
  let t3 = e2.toLowerCase();
  return t3.startsWith(`[`) && t3.endsWith(`]`) ? t3.slice(1, -1) : t3.replace(/\.+$/, ``);
}
var ee = [[`0.0.0.0`, 8], [`10.0.0.0`, 8], [`100.64.0.0`, 10], [`127.0.0.0`, 8], [`169.254.0.0`, 16], [`172.16.0.0`, 12], [`192.0.0.0`, 24], [`192.0.2.0`, 24], [`192.168.0.0`, 16], [`198.18.0.0`, 15], [`198.51.100.0`, 24], [`203.0.113.0`, 24], [`224.0.0.0`, 4], [`240.0.0.0`, 4]];
function te(e2) {
  return ee.some(([t3, n2]) => {
    let r2 = A(t3);
    if (!r2) return false;
    let i2 = 32 - n2;
    return e2 >>> i2 == j(r2) >>> i2;
  });
}
function k(e2) {
  if (e2.includes(`.`)) return false;
  let t3 = (t4) => {
    let n3 = e2.split(`:`)[t4] ?? ``, r2 = Number.parseInt(n3, 16);
    return Number.isFinite(r2) ? r2 : 0;
  }, n2 = e2.startsWith(`::`) ? 0 : t3(0);
  if (n2 < 8192 || n2 > 16383 || n2 === 8194) return false;
  if (n2 === 8193) {
    let e3 = t3(1);
    if (e3 < 512 || e3 === 3512) return false;
  }
  return !(n2 === 16383 && t3(1) < 4096);
}
function A(e2) {
  let t3 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(e2);
  if (!t3) return null;
  let n2 = [];
  for (let e3 of t3.slice(1)) {
    if (e3.length > 1 && e3.startsWith(`0`)) return null;
    let t4 = Number(e3);
    if (t4 > 255) return null;
    n2.push(t4);
  }
  return n2;
}
function j(e2) {
  return ((e2[0] ?? 0) << 24 >>> 0) + ((e2[1] ?? 0) << 16) + ((e2[2] ?? 0) << 8) + (e2[3] ?? 0);
}
var M = `webauthn-prf-aes-gcm`, N = `pnm/holder-prf/credentialId`, P = `pnm/holder-prf/salt`, F = class extends Error {
  constructor() {
    super(`wallet is locked: unlock via popup before retrying`), this.name = `WalletLockedError`;
  }
};
function I(e2) {
  let t3 = e2.getClientExtensionResults().prf, n2 = t3?.results?.first;
  return n2 ? { kind: `output`, prfOutput: new Uint8Array(n2) } : t3?.enabled === true ? { kind: `needs-assertion` } : { kind: `unsupported` };
}
var L = class extends Error {
  constructor(e2) {
    super(e2), this.name = `PrfUnavailableError`;
  }
}, R = `This passkey can't protect the wallet: it doesn't support the PRF (hmac-secret) extension. Use a security key such as a YubiKey 5 or Nitrokey 3 with a PIN set, or choose your phone in the browser's passkey dialog.`, z = `This browser doesn't offer the passkey PRF extension the wallet needs. Update Chrome or Chromium (116 or later), or use another browser.`;
async function B() {
  let e2 = globalThis.PublicKeyCredential;
  if (typeof e2?.getClientCapabilities == `function`) try {
    let t3 = (await e2.getClientCapabilities())[`extension:prf`];
    return typeof t3 == `boolean` ? t3 : void 0;
  } catch {
    return;
  }
}
var V = `The passkey answered without the wallet's key. Use the same security key or phone the wallet was set up with, with its PIN or biometric; a key that was reset no longer holds the passkey.`;
function H() {
  return new a();
}
var U = null, W = null, G = class t2 {
  rpId;
  algorithm = M;
  constructor(e2) {
    this.rpId = e2;
  }
  async wrap(t3) {
    let n2 = await this.enrollOrLoadCredential();
    if (!n2) return null;
    let r2 = await this.deriveAesKey(n2.prfOutput);
    U = r2, W = n2.prfOutput;
    let i2 = crypto.getRandomValues(new Uint8Array(12)), a2 = new Uint8Array(await crypto.subtle.encrypt({ name: `AES-GCM`, iv: i2 }, r2, t3));
    return { algorithm: this.algorithm, ciphertextB64u: e(a2), ivB64u: e(i2), params: { credentialId: n2.credentialId, prfSalt: e(n2.prfSalt) } };
  }
  async unwrap(e2) {
    let t3 = e2.params;
    if (!t3.credentialId || !t3.prfSalt) throw Error(`webauthn-prf-wrap: missing credentialId or prfSalt in record`);
    if (!U) throw new F();
    let r2 = n(e2.ivB64u), i2 = n(e2.ciphertextB64u), a2 = await crypto.subtle.decrypt({ name: `AES-GCM`, iv: r2 }, U, i2);
    return new Uint8Array(a2);
  }
  static lock() {
    U = null, W = null;
  }
  static consumeLastEnrolledPrfOutput() {
    let e2 = W;
    return W = null, e2;
  }
  static isUnlocked() {
    return U !== null;
  }
  static async seedCachedKeyFromPrfOutput(e2) {
    U = await new t2(``).deriveAesKey(e2);
  }
  static async unenroll() {
    U = null, W = null;
    let e2 = H();
    await e2.delete(N), await e2.delete(P);
  }
  async enrollOrLoadCredential() {
    let t3 = H(), r2 = await t3.get(N), i2 = await t3.get(P);
    if (r2 && i2) {
      let e2 = n(i2), t4 = await this.assertPrfOutput(r2, e2);
      return t4 ? { credentialId: r2, prfSalt: e2, prfOutput: t4 } : null;
    }
    if (await B() === false) throw new L(z);
    let a2 = crypto.getRandomValues(new Uint8Array(32)), o2 = crypto.getRandomValues(new Uint8Array(32)), s2 = crypto.getRandomValues(new Uint8Array(16)), c2 = await navigator.credentials.create({ publicKey: { rp: { id: this.rpId, name: `OpenVTC Wallet` }, user: { id: s2, name: `wallet@openvtc`, displayName: `OpenVTC Wallet` }, challenge: o2, pubKeyCredParams: [{ type: `public-key`, alg: -8 }, { type: `public-key`, alg: -7 }, { type: `public-key`, alg: -257 }], authenticatorSelection: { residentKey: `required`, userVerification: `required` }, extensions: { prf: { eval: { first: a2 } } } } });
    if (!c2) return null;
    let l2 = e(new Uint8Array(c2.rawId)), u2 = I(c2);
    if (u2.kind === `unsupported`) throw new L(R);
    let d2 = u2.kind === `output` ? u2.prfOutput : await this.assertPrfOutput(l2, a2);
    return d2 ? (await t3.put(N, l2), await t3.put(P, e(a2)), { credentialId: l2, prfSalt: a2, prfOutput: d2 }) : null;
  }
  async assertPrfOutput(e2, t3) {
    let r2 = crypto.getRandomValues(new Uint8Array(32)), i2 = n(e2), a2 = await navigator.credentials.get({ publicKey: { rpId: this.rpId, challenge: r2, allowCredentials: [{ type: `public-key`, id: i2 }], userVerification: `required`, extensions: { prf: { eval: { first: t3 } } } } });
    if (!a2) return null;
    let o2 = a2.getClientExtensionResults().prf?.results?.first;
    if (!o2) throw Error(V);
    return new Uint8Array(o2);
  }
  async unlockAesKey(e2, t3) {
    let r2 = crypto.getRandomValues(new Uint8Array(32)), i2 = n(e2), a2 = await navigator.credentials.get({ publicKey: { rpId: this.rpId, challenge: r2, allowCredentials: [{ type: `public-key`, id: i2 }], userVerification: `required`, extensions: { prf: { eval: { first: t3 } } } } });
    if (!a2) return null;
    let o2 = a2.getClientExtensionResults().prf?.results?.first;
    if (!o2) throw Error(V);
    return this.deriveAesKey(new Uint8Array(o2));
  }
  async deriveAesKey(e2) {
    let t3 = await crypto.subtle.importKey(`raw`, e2, { name: `HKDF` }, false, [`deriveKey`]);
    return crypto.subtle.deriveKey({ name: `HKDF`, hash: `SHA-256`, salt: new Uint8Array(), info: new TextEncoder().encode(`pnm/holder-secret/aes-gcm/v1`) }, t3, { name: `AES-GCM`, length: 256 }, false, [`encrypt`, `decrypt`]);
  }
}, K = `pnm/settings/v1`;
function q(e2) {
  let t3 = {};
  for (let [n2, r2] of Object.entries(e2)) {
    let e3 = r2;
    e3 && typeof e3.did == `string` && e3.did && (e3.source === `agent` || e3.source === `operator`) && (t3[n2] = { did: e3.did, source: e3.source });
  }
  return t3;
}
async function J() {
  return await new a().get(K) ?? {};
}
async function Y() {
  let e2 = await J(), t3 = typeof e2?.encryptHolderSecret == `boolean` && e2.encryptHolderSecret;
  return { ...e2?.inboxes ? { inboxes: q(e2.inboxes) } : {}, ...e2?.mediatorDid ? { mediatorDid: e2.mediatorDid } : {}, ...e2?.mediatorDidSource === `agent` || e2?.mediatorDidSource === `operator` ? { mediatorDidSource: e2.mediatorDidSource } : {}, ...e2?.defaultStepUpVtaDid ? { defaultStepUpVtaDid: e2.defaultStepUpVtaDid } : {}, ...e2?.defaultStepUpVtaMediatorDid ? { defaultStepUpVtaMediatorDid: e2.defaultStepUpVtaMediatorDid } : {}, ...Array.isArray(e2?.enrolledExecutorDids) ? { enrolledExecutorDids: e2.enrolledExecutorDids.filter((e3) => typeof e3 == `string` && e3.length > 0) } : {}, encryptHolderSecret: t3, preferTsp: typeof e2?.preferTsp != `boolean` || e2.preferTsp, ...Array.isArray(e2?.myTermsOffers) && e2.myTermsOffers.some((e3) => typeof e3 == `string` && e3 !== ``) ? { myTermsOffers: e2.myTermsOffers.filter((e3) => typeof e3 == `string` && e3 !== ``) } : {}, ...e2?.pushGatewayUrl ? { pushGatewayUrl: e2.pushGatewayUrl } : {}, ...e2?.pushGatewayVapidPublicKey ? { pushGatewayVapidPublicKey: e2.pushGatewayVapidPublicKey } : {} };
}
async function X(e2) {
  e2.pushGatewayUrl !== void 0 && C(e2.pushGatewayUrl, { what: `push gateway URL` });
  let t3 = await J();
  await new a().put(K, { ...t3, ...e2 });
}
function Z(e2, t3) {
  return e2.inboxes?.[t3];
}
async function Q(e2, t3) {
  let n2 = await J();
  await new a().put(K, { ...n2, inboxes: { ...n2.inboxes ?? {}, [e2]: t3 } });
}
async function ne(e2) {
  let t3 = await J(), n2 = { ...t3.inboxes ?? {} };
  delete n2[e2], await new a().put(K, { ...t3, inboxes: n2 });
}
var re = `vta-wallet/emit-wallet-event`, ie = `vta-wallet/notify`, ae = `vta-wallet/consent-result`, oe = `vta-wallet/task-consent`, se = `pnm/consent-keepalive`, ce = `vta-wallet/step-up-consent`, le = `vta-wallet/verify-rp-did`, ue = `vta-wallet/lock-wallet`, de = `vta-wallet/approver-state`, fe = `vta-wallet/resolve-agent-name`, pe = `vta-wallet/onboard-prepare`, me = `vta-wallet/onboard-connect`, he = `vta-wallet/holder-state`, ge = `vta-wallet/onboard-contexts`, _e = `wallet/mediator-required`, ve = `wallet/inbox-not-configured`, ye = `vta-wallet/onboard-progress`, be = [`resolving-agent`, `connecting-mediator`, `provisioning`, `installing-identity`], xe = `vta-wallet/unlock-prf`, Se = `vta-wallet/unlock-approver`, Ce = `vta-wallet/lock-state`, we = `vta-wallet/forget-holder-record`, Te = `vta-wallet/restart-inbox`, Ee = `vta-wallet/refresh-vta-transports`, De = `vta-wallet/list-contexts`, Oe = `vta-wallet/create-context`, ke = `vta-wallet/list-dids`, Ae = `vta-wallet/derive-signing-key-id`, je = `vta-wallet/vault-list`, Me = `vta-wallet/transport-health`, Ne = `vta-wallet/run-diagnostics`, Pe = `vta-wallet/vault-upsert`, Fe = `vta-wallet/vault-delete`, Ie = `vta-wallet/vault-release`, Le = `vta-wallet/vault-proxy-login`, Re = `offscreen`, ze = `offscreen/didcomm-login`, Be = `offscreen/step-up-vta`, Ve = `offscreen/lock-wallet`, He = `offscreen/start-inbound`, Ue = `offscreen/get-status`, We = `offscreen/transport-health`, Ge = `offscreen/run-diagnostics`, Ke = `offscreen/onboard-prepare`, qe = `offscreen/onboard-connect`, Je = `offscreen/holder-state`, Ye = `offscreen/unlock-prf`, Xe = `offscreen/approver-state`, Ze = `offscreen/unlock-approver`, Qe = `offscreen/forget-holder-record`, $e = `offscreen/lock-state`, et = `offscreen/refresh-vta-transports`, tt = `offscreen/list-contexts`, nt = `offscreen/list-dids`, rt = `offscreen/create-context`, it = `offscreen/derive-signing-key-id`, at = `offscreen/set-wake`, ot = `offscreen/sign-trust-task`, st = `offscreen/step-up-approver`, ct = `offscreen/verify-did`, lt = `offscreen/vault-list`, ut = `offscreen/request-task`, dt = `offscreen/vault-upsert`, ft = `offscreen/vault-delete`, pt = `offscreen/vault-release`, mt = `offscreen/vault-proxy-login`, ht = `offscreen/onboard-contexts`, gt = `offscreen/rest-login`, _t = `pnm/offscreen-disclosure-step-up`, vt = `vta-wallet/disclosure-step-up-consent`, yt = `offscreen/mediator`, $ = `vta-wallet/mediator-monitor`, bt = `vta-wallet/join-community`, xt = `offscreen/sign-in-page-number`, St = `vta-wallet/sign-in-step`, Ct = `offscreen/sign-in-step`, wt = `vta-wallet/uv-settings`, Tt = `offscreen/uv-settings`, Et = `offscreen/room-host-endpoint`, Dt = `offscreen/rooms-page`, Ot = `offscreen/directory-page`, kt = `vta-wallet/room-files`, At = `offscreen/room-offers`;
export {
  vt as $,
  Ct as A,
  ne as At,
  ft as B,
  m as Bt,
  gt as C,
  Fe as Ct,
  Ge as D,
  Pe as Dt,
  At as E,
  Ie as Et,
  Re as F,
  z as Ft,
  ct as G,
  _ as Gt,
  mt as H,
  b as Ht,
  We as I,
  V as It,
  kt as J,
  s as Jt,
  $e as K,
  y as Kt,
  Ze as L,
  L as Lt,
  He as M,
  Z as Mt,
  st as N,
  Q as Nt,
  at as O,
  le as Ot,
  Be as P,
  X as Pt,
  Ae as Q,
  Ye as R,
  G as Rt,
  ut as S,
  wt as St,
  Et as T,
  Le as Tt,
  pt as U,
  v as Ut,
  lt as V,
  S as Vt,
  dt as W,
  x as Wt,
  ae as X,
  de as Y,
  a as Yt,
  Oe as Z,
  yt as _,
  ce as _t,
  Xe as a,
  ke as at,
  Ke as b,
  Se as bt,
  ze as c,
  me as ct,
  Qe as d,
  ye as dt,
  re as et,
  Ue as f,
  Ee as ft,
  Ve as g,
  St as gt,
  nt as h,
  Ne as ht,
  _e as i,
  De as it,
  ot as j,
  Y as jt,
  xt as k,
  Ce as kt,
  Ot as l,
  ge as lt,
  tt as m,
  Te as mt,
  ve as n,
  he as nt,
  rt as o,
  ue as ot,
  Je as p,
  fe as pt,
  be as q,
  c as qt,
  $ as r,
  bt as rt,
  it as s,
  ie as st,
  se as t,
  we as tt,
  _t as u,
  pe as ut,
  qe as v,
  oe as vt,
  Dt as w,
  je as wt,
  et as x,
  xe as xt,
  ht as y,
  Me as yt,
  Tt as z,
  B as zt
};
