import { i as e, n as t, r as n } from "./rolldown-runtime-Dd_uD5pT.js";
import { A as r, C as i, D as a, E as o, F as s, I as c, M as l, N as u, O as d, S as f, T as p, _ as m, a as h, b as g, c as _, d as v, f as y, g as b, h as x, i as S, j as C, k as w, l as ee, m as te, n as ne, o as T, p as E, r as re, s as D, u as ie, v as O, w as ae, x as oe, y as se } from "./ed25519-CV189T12.js";
let A, N, To, L, Eo, ma, Ai, ue, Te, go, bo, Wt, Oo, So, cn, vo, Co, po, _o, F, j, R;
let __tla = (async () => {
  var k = `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_`;
  A = function(e2) {
    let t2 = e2 instanceof Uint8Array ? e2 : new Uint8Array(e2 instanceof ArrayBuffer ? e2 : new Uint8Array(e2)), n2 = ``, r2 = 0;
    for (; r2 + 2 < t2.length; r2 += 3) {
      let e3 = t2[r2] << 16 | t2[r2 + 1] << 8 | t2[r2 + 2];
      n2 += k[e3 >> 18 & 63] + k[e3 >> 12 & 63] + k[e3 >> 6 & 63] + k[e3 & 63];
    }
    let i2 = t2.length - r2;
    if (i2 === 1) {
      let e3 = t2[r2] << 16;
      n2 += k[e3 >> 18 & 63] + k[e3 >> 12 & 63];
    } else if (i2 === 2) {
      let e3 = t2[r2] << 16 | t2[r2 + 1] << 8;
      n2 += k[e3 >> 18 & 63] + k[e3 >> 12 & 63] + k[e3 >> 6 & 63];
    }
    return n2;
  };
  j = function(e2) {
    if (typeof e2 != `string`) throw TypeError(`base64url.decode expects a string, got ${typeof e2}`);
    let t2 = e2.replace(/[+]/g, `-`).replace(/[/]/g, `_`).replace(/=+$/, ``);
    if (t2.length % 4 == 1) throw Error(`base64url.decode: invalid length (${t2.length} chars; %4 === 1)`);
    let n2 = new Uint8Array(Math.floor(t2.length * 3 / 4)), r2 = 0, i2 = 0, a2 = 0;
    for (let e3 = 0; e3 < t2.length; e3++) {
      let o2 = M[t2.charCodeAt(e3)];
      if (o2 === void 0) throw Error(`base64url.decode: invalid character ${JSON.stringify(t2[e3])} at position ${e3}`);
      i2 = i2 << 6 | o2, a2 += 6, a2 >= 8 && (a2 -= 8, n2[r2++] = i2 >> a2 & 255);
    }
    return n2.subarray(0, r2);
  };
  let M, ce;
  M = (() => {
    let e2 = Array(128);
    for (let t2 = 0; t2 < 64; t2++) e2[k.charCodeAt(t2)] = t2;
    return e2;
  })();
  ce = `123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz`;
  N = Object.freeze({
    ED25519_PUB: new Uint8Array([
      237,
      1
    ]),
    X25519_PUB: new Uint8Array([
      236,
      1
    ]),
    P256_PUB: new Uint8Array([
      128,
      36
    ]),
    SECP256K1_PUB: new Uint8Array([
      231,
      1
    ])
  });
  function P(e2) {
    if (e2.length === 0) return ``;
    let t2 = 0;
    for (; t2 < e2.length && e2[t2] === 0; ) t2++;
    let n2 = [];
    for (let r3 = t2; r3 < e2.length; r3++) {
      let t3 = e2[r3];
      for (let e3 = 0; e3 < n2.length; e3++) t3 += n2[e3] << 8, n2[e3] = t3 % 58, t3 = t3 / 58 | 0;
      for (; t3 > 0; ) n2.push(t3 % 58), t3 = t3 / 58 | 0;
    }
    let r2 = ``;
    for (let e3 = 0; e3 < t2; e3++) r2 += `1`;
    for (let e3 = n2.length - 1; e3 >= 0; e3--) r2 += ce[n2[e3]];
    return r2;
  }
  F = function(e2) {
    if (typeof e2 != `string`) throw TypeError(`base58btcDecode expects a string`);
    let t2 = 0;
    for (; t2 < e2.length && e2[t2] === `1`; ) t2++;
    let n2 = [];
    for (let r3 = t2; r3 < e2.length; r3++) {
      let t3 = I[e2.charCodeAt(r3)];
      if (t3 === void 0) throw Error(`base58btcDecode: invalid char ${JSON.stringify(e2[r3])} at ${r3}`);
      for (let e3 = 0; e3 < n2.length; e3++) t3 += n2[e3] * 58, n2[e3] = t3 & 255, t3 >>= 8;
      for (; t3 > 0; ) n2.push(t3 & 255), t3 >>= 8;
    }
    let r2 = new Uint8Array(t2 + n2.length);
    for (let e3 = n2.length - 1, i2 = t2; e3 >= 0; e3--, i2++) r2[i2] = n2[e3];
    return r2;
  };
  var I = (() => {
    let e2 = Array(128);
    for (let t2 = 0; t2 < 58; t2++) e2[ce.charCodeAt(t2)] = t2;
    return e2;
  })();
  L = function(e2, t2) {
    let n2 = new Uint8Array(e2.length + t2.length);
    return n2.set(e2, 0), n2.set(t2, e2.length), `z` + P(n2);
  };
  R = function(e2) {
    if (typeof e2 != `string` || !e2.startsWith(`z`)) throw Error(`multikey: must be base58btc multibase (starts with 'z')`);
    let t2 = F(e2.slice(1)), n2 = 0;
    for (let e3 = 0; e3 < t2.length && (n2++, t2[e3] & 128); e3++) ;
    return {
      codec: t2.slice(0, n2),
      key: t2.slice(n2)
    };
  };
  let le, de, z, fe, pe;
  le = class {
    oHash;
    iHash;
    blockLen;
    outputLen;
    canXOF = false;
    finished = false;
    destroyed = false;
    constructor(e2, t2) {
      if (u(e2), C(t2, void 0, `key`), this.iHash = e2.create(), typeof this.iHash.update != `function`) throw Error(`expected Hash instance`);
      this.blockLen = this.iHash.blockLen, this.outputLen = this.iHash.outputLen;
      let n2 = this.blockLen, r2 = new Uint8Array(n2);
      r2.set(t2.length > n2 ? e2.create().update(t2).digest() : t2);
      for (let e3 = 0; e3 < r2.length; e3++) r2[e3] ^= 54;
      this.iHash.update(r2), this.oHash = e2.create();
      for (let e3 = 0; e3 < r2.length; e3++) r2[e3] ^= 106;
      this.oHash.update(r2), c(r2);
    }
    update(e2) {
      return l(this), this.iHash.update(e2), this;
    }
    digestInto(e2) {
      l(this), s(e2, this), this.finished = true;
      let t2 = e2.subarray(0, this.outputLen);
      this.iHash.digestInto(t2), this.oHash.update(t2), this.oHash.digestInto(t2), this.destroy();
    }
    digest() {
      let e2 = new Uint8Array(this.oHash.outputLen);
      return this.digestInto(e2), e2;
    }
    _cloneInto(e2) {
      e2 ||= Object.create(Object.getPrototypeOf(this), {});
      let { oHash: t2, iHash: n2, finished: r2, destroyed: i2, blockLen: a2, outputLen: o2, canXOF: s2 } = this;
      return e2 = e2, e2.finished = r2, e2.destroyed = i2, e2.blockLen = a2, e2.outputLen = o2, e2.canXOF = s2, e2.oHash = t2._cloneInto(e2.oHash), e2.iHash = n2._cloneInto(e2.iHash), e2;
    }
    clone() {
      return this._cloneInto();
    }
    destroy() {
      this.destroyed = true, this.oHash.destroy(), this.iHash.destroy();
    }
  };
  ue = (() => {
    let e2 = ((e3, t2, n2) => new le(e3, t2).update(n2).digest());
    return e2.create = (e3, t2) => new le(e3, t2), e2;
  })();
  de = BigInt(0);
  z = {
    Err: class extends Error {
      constructor(e2 = ``) {
        super(e2);
      }
    },
    _tlv: {
      encode: (e2, t2) => {
        let { Err: n2 } = z;
        if (m(e2, `tag`), e2 < 0 || e2 > 255) throw new n2(`tlv.encode: wrong tag`);
        if (O(t2, `data`), t2.length & 1) throw new n2(`tlv.encode: unpadded data`);
        let r2 = t2.length / 2, i2 = a(r2);
        if (i2.length / 2 & 128) throw new n2(`tlv.encode: long form length too big`);
        let o2 = r2 > 127 ? a(i2.length / 2 | 128) : ``;
        return a(e2) + o2 + i2 + t2;
      },
      decode(e2, t2) {
        let { Err: n2 } = z;
        t2 = b(t2, void 0, `DER data`);
        let r2 = 0;
        if (e2 < 0 || e2 > 255) throw new n2(`tlv.decode: wrong tag`);
        if (t2.length < 2 || t2[r2++] !== e2) throw new n2(`tlv.decode: wrong tlv`);
        let i2 = t2[r2++], a2 = !!(i2 & 128), o2 = 0;
        if (!a2) o2 = i2;
        else {
          let e3 = i2 & 127;
          if (!e3) throw new n2(`tlv.decode(long): indefinite length not supported`);
          if (e3 > 4) throw new n2(`tlv.decode(long): byte length is too big`);
          let a3 = t2.subarray(r2, r2 + e3);
          if (a3.length !== e3) throw new n2(`tlv.decode: length bytes not complete`);
          if (a3[0] === 0) throw new n2(`tlv.decode(long): zero leftmost byte`);
          for (let e4 of a3) o2 = o2 << 8 | e4;
          if (r2 += e3, o2 < 128) throw new n2(`tlv.decode(long): not minimal encoding`);
        }
        let s2 = t2.subarray(r2, r2 + o2);
        if (s2.length !== o2) throw new n2(`tlv.decode: wrong value length`);
        return {
          v: s2,
          l: t2.subarray(r2 + o2)
        };
      }
    },
    _int: {
      encode(e2) {
        let { Err: t2 } = z;
        if (te(e2), e2 < de) throw new t2(`integer: negative integers are not allowed`);
        let n2 = a(e2);
        if (Number.parseInt(n2[0], 16) & 8 && (n2 = `00` + n2), n2.length & 1) throw new t2(`unexpected DER parsing assertion: unpadded hex`);
        return n2;
      },
      decode(e2) {
        let { Err: t2 } = z;
        if (e2.length < 1) throw new t2(`invalid signature integer: empty`);
        if (e2[0] & 128) throw new t2(`invalid signature integer: negative`);
        if (e2.length > 1 && e2[0] === 0 && !(e2[1] & 128)) throw new t2(`invalid signature integer: unnecessary leading zero`);
        return f(e2);
      }
    },
    toSig(e2, t2) {
      let { Err: n2, _int: r2, _tlv: i2 } = z;
      if (t2 !== void 0 && (m(t2, `maxScalarBytes`), t2 < 1)) throw new n2(`invalid signature: maxScalarBytes must be positive`);
      let a2 = b(e2, void 0, `signature`), { v: o2, l: s2 } = i2.decode(48, a2);
      if (s2.length) throw new n2(`invalid signature: left bytes after parsing`);
      let { v: c2, l: l2 } = i2.decode(2, o2), { v: u2, l: d2 } = i2.decode(2, l2);
      if (d2.length) throw new n2(`invalid signature: left bytes after parsing`);
      if (t2 !== void 0 && (c2.length > t2 || u2.length > t2)) throw new n2(`invalid signature: integer too large`);
      return {
        r: r2.decode(c2),
        s: r2.decode(u2)
      };
    },
    hexFromSig(e2) {
      let { _tlv: t2, _int: n2 } = z;
      w(e2, {
        r: `bigint`,
        s: `bigint`
      }, {}, `sig`);
      let r2 = t2.encode(2, n2.encode(e2.r)) + t2.encode(2, n2.encode(e2.s));
      return t2.encode(48, r2);
    }
  };
  fe = (Object.freeze(z._tlv), Object.freeze(z._int), Object.freeze(z));
  pe = (e2, t2) => (e2 + (e2 >= 0 ? t2 : -t2) / _e) / t2;
  function me(e2, t2, n2) {
    E(`scalar`, e2, B, n2);
    let [[r2, i2], [a2, o2]] = t2, s2 = pe(o2 * e2, n2), c2 = pe(-i2 * e2, n2), l2 = e2 - s2 * r2 - c2 * a2, u2 = -s2 * i2 - c2 * o2, d2 = l2 < B, f2 = u2 < B;
    d2 && (l2 = -l2), f2 && (u2 = -u2);
    let p2 = g(Math.ceil(se(n2) / 2)) + V;
    if (l2 < B || l2 >= p2 || u2 < B || u2 >= p2) throw Error(`splitScalar (endomorphism): failed for k`);
    return {
      k1neg: d2,
      k1: l2,
      k2neg: f2,
      k2: u2
    };
  }
  function he(e2) {
    if (![
      `compact`,
      `recovered`,
      `der`
    ].includes(e2)) throw Error(`Signature format must be "compact", "recovered", or "der"`);
    return e2;
  }
  function ge(e2, t2) {
    w(e2);
    let n2 = {};
    for (let r2 of Object.keys(t2)) n2[r2] = e2[r2] === void 0 ? t2[r2] : e2[r2];
    return x(n2.lowS, `lowS`), x(n2.prehash, `prehash`), n2.format !== void 0 && he(n2.format), n2;
  }
  var B = BigInt(0), V = BigInt(1), _e = BigInt(2), ve = BigInt(3), ye = BigInt(4);
  function be(e2, t2 = {}) {
    let n2 = S(`weierstrass`, e2, t2), r2 = n2.Fp, a2 = n2.Fn, o2 = n2.CURVE, { h: s2, n: c2 } = o2;
    w(t2, {}, {
      allowInfinityPoint: `boolean`,
      clearCofactor: `function`,
      isTorsionFree: `function`,
      fromBytes: `function`,
      toBytes: `function`,
      endo: `object`,
      randomBytes: `function`
    });
    let { endo: l2, allowInfinityPoint: u2, clearCofactor: f2, isTorsionFree: m2, fromBytes: h2, toBytes: g2 } = t2, _2 = t2.randomBytes === void 0 ? d : t2.randomBytes;
    if (l2 && (!r2.is0(o2.a) || typeof l2.beta != `bigint` || !Array.isArray(l2.basises))) throw Error(`invalid endo: expected "beta": bigint and "basises": array`);
    let v2 = l2 ? {
      beta: l2.beta,
      basises: l2.basises.map((e3) => [
        ...e3
      ])
    } : void 0, y2 = Se(r2, a2);
    function C2() {
      if (!r2.isOdd) throw Error(`compression is not supported: Field does not have .isOdd()`);
    }
    function ee2(e3, t3, n3) {
      if (t3.is0()) {
        if (!u2) throw Error(`bad point: ZERO`);
        return Uint8Array.of(0);
      }
      let { x: a3, y: o3 } = t3.toAffine(), s3 = r2.toBytes(a3);
      if (x(n3, `isCompressed`), n3) {
        C2();
        let e4 = !r2.isOdd(o3);
        return i(xe(e4), s3);
      }
      return i(Uint8Array.of(4), s3, r2.toBytes(o3));
    }
    function te2(e3) {
      b(e3, void 0, `Point`);
      let { publicKey: t3, publicKeyUncompressed: n3 } = y2, i2 = e3.length, a3 = e3[0], o3 = e3.subarray(1);
      if (u2 && i2 === 1 && a3 === 0) return {
        x: r2.ZERO,
        y: r2.ZERO
      };
      if (i2 === t3 && (a3 === 2 || a3 === 3)) {
        let e4 = r2.fromBytes(o3);
        if (!r2.isValid(e4)) throw Error(`bad point: is not on curve, wrong x`);
        let t4 = ae2(e4), n4;
        try {
          n4 = r2.sqrt(t4);
        } catch (e5) {
          let t5 = e5 instanceof Error ? `: ` + e5.message : ``;
          throw Error(`bad point: is not on curve, sqrt error` + t5);
        }
        C2();
        let i3 = r2.isOdd(n4);
        return (a3 & 1) == 1 !== i3 && (n4 = r2.neg(n4)), {
          x: e4,
          y: n4
        };
      }
      if (i2 === n3 && a3 === 4) {
        let e4 = r2.BYTES, t4 = r2.fromBytes(o3.subarray(0, e4)), n4 = r2.fromBytes(o3.subarray(e4, e4 * 2));
        if (!se2(t4, n4)) throw Error(`bad point: is not on curve`);
        return {
          x: t4,
          y: n4
        };
      }
      throw Error(`bad point: got length ${i2}, expected compressed=${t3} or uncompressed=${n3}`);
    }
    let ne2 = g2 === void 0 ? ee2 : g2, E2 = h2 === void 0 ? te2 : h2, ie2 = r2.mul(o2.b, ve), O2 = r2.is0(o2.a) ? (e3) => r2.ZERO : (e3) => r2.mul(o2.a, e3);
    function ae2(e3) {
      let t3 = r2.sqr(e3), n3 = r2.mul(t3, e3);
      return r2.add(r2.add(n3, r2.mul(e3, o2.a)), o2.b);
    }
    function se2(e3, t3) {
      let n3 = r2.sqr(t3), i2 = ae2(e3);
      return r2.eql(n3, i2);
    }
    if (!se2(o2.Gx, o2.Gy)) throw Error(`bad curve params: generator point`);
    let k2 = r2.mul(r2.pow(o2.a, ve), ye), A2 = r2.mul(r2.sqr(o2.b), BigInt(27));
    if (r2.is0(r2.add(k2, A2))) throw Error(`bad curve params: a or b`);
    function j2(e3, t3, n3 = false) {
      if (!r2.isValid(t3) || n3 && r2.is0(t3)) throw Error(`bad point coordinate ${e3}`);
      return typeof t3 == `object` && t3 ? r2.create(t3) : t3;
    }
    function M2(e3) {
      if (!(e3 instanceof F2)) throw Error(`Weierstrass Point expected`);
    }
    function ce2(e3) {
      if (!v2 || !v2.basises) throw Error(`no endo`);
      return me(e3, v2.basises, a2.ORDER);
    }
    function N2(e3, t3, n3, i2) {
      if (!a2.isValid(i2)) throw RangeError(`invalid scalar: out of range`);
      if (v2) {
        let { k1neg: a3, k1: o3, k2neg: s3, k2: c3 } = ce2(i2), l3 = new F2(r2.mul(n3.X, v2.beta), n3.Y, n3.Z);
        e3.push(a3 ? n3.negate() : n3, s3 ? l3.negate() : l3), t3.push(o3, c3);
      } else e3.push(n3), t3.push(i2);
    }
    let P2 = /* @__PURE__ */ new WeakSet();
    class F2 {
      static BASE = new F2(o2.Gx, o2.Gy, r2.ONE);
      static ZERO = new F2(r2.ZERO, r2.ONE, r2.ZERO);
      static Fp = r2;
      static Fn = a2;
      X;
      Y;
      Z;
      constructor(e3, t3, n3) {
        this.X = j2(`x`, e3), this.Y = j2(`y`, t3, true), this.Z = j2(`z`, n3), Object.freeze(this);
      }
      static CURVE() {
        return o2;
      }
      static fromAffine(e3) {
        let { x: t3, y: n3 } = e3 || {};
        if (!e3 || !r2.isValid(t3) || !r2.isValid(n3)) throw Error(`invalid affine point`);
        if (e3 instanceof F2) throw Error(`projective point not allowed`);
        return r2.is0(t3) && r2.is0(n3) ? F2.ZERO : new F2(t3, n3, r2.ONE);
      }
      static fromBytes(e3) {
        let t3 = F2.fromAffine(E2(b(e3, void 0, `point`)));
        return t3.assertValidity(), t3;
      }
      static fromHex(e3) {
        return F2.fromBytes(p(e3));
      }
      get x() {
        return this.toAffine().x;
      }
      get y() {
        return this.toAffine().y;
      }
      precompute(e3 = 6, t3 = true) {
        return L2.setWindowSize(this, e3), t3 || this.multiply(ve), this;
      }
      assertValidity() {
        let e3 = this;
        if (e3.is0()) {
          if (u2 && r2.is0(e3.X) && r2.eql(e3.Y, r2.ONE) && r2.is0(e3.Z)) return;
          throw Error(`bad point: ZERO`);
        }
        if (P2.has(e3)) return;
        let { x: t3, y: n3 } = e3.toAffine();
        if (!r2.isValid(t3) || !r2.isValid(n3)) throw Error(`bad point: x or y not field elements`);
        if (!se2(t3, n3)) throw Error(`bad point: equation left != right`);
        if (!e3.isTorsionFree()) throw Error(`bad point: not in prime-order subgroup`);
        P2.add(e3);
      }
      hasEvenY() {
        let { y: e3 } = this.toAffine();
        if (!r2.isOdd) throw Error(`Field doesn't support isOdd`);
        return !r2.isOdd(e3);
      }
      equals(e3) {
        M2(e3);
        let { X: t3, Y: n3, Z: i2 } = this, { X: a3, Y: o3, Z: s3 } = e3, c3 = r2.eql(r2.mul(t3, s3), r2.mul(a3, i2)), l3 = r2.eql(r2.mul(n3, s3), r2.mul(o3, i2));
        return c3 && l3;
      }
      negate() {
        return new F2(this.X, r2.neg(this.Y), this.Z);
      }
      double() {
        let { X: e3, Y: t3, Z: n3 } = this, i2 = r2.ZERO, a3 = r2.ZERO, o3 = r2.ZERO, s3 = r2.mul(e3, e3), c3 = r2.mul(t3, t3), l3 = r2.mul(n3, n3), u3 = r2.mul(e3, t3);
        return u3 = r2.add(u3, u3), o3 = r2.mul(e3, n3), o3 = r2.add(o3, o3), i2 = O2(o3), a3 = r2.mul(ie2, l3), a3 = r2.add(i2, a3), i2 = r2.sub(c3, a3), a3 = r2.add(c3, a3), a3 = r2.mul(i2, a3), i2 = r2.mul(u3, i2), o3 = r2.mul(ie2, o3), l3 = O2(l3), u3 = r2.sub(s3, l3), u3 = O2(u3), u3 = r2.add(u3, o3), o3 = r2.add(s3, s3), s3 = r2.add(o3, s3), s3 = r2.add(s3, l3), s3 = r2.mul(s3, u3), a3 = r2.add(a3, s3), l3 = r2.mul(t3, n3), l3 = r2.add(l3, l3), s3 = r2.mul(l3, u3), i2 = r2.sub(i2, s3), o3 = r2.mul(l3, c3), o3 = r2.add(o3, o3), o3 = r2.add(o3, o3), new F2(i2, a3, o3);
      }
      add(e3) {
        M2(e3);
        let { X: t3, Y: n3, Z: i2 } = this, { X: a3, Y: o3, Z: s3 } = e3, c3 = r2.ZERO, l3 = r2.ZERO, u3 = r2.ZERO, d2 = r2.mul(t3, a3), f3 = r2.mul(n3, o3), p2 = r2.mul(i2, s3), m3 = r2.add(t3, n3), h3 = r2.add(a3, o3);
        m3 = r2.mul(m3, h3), h3 = r2.add(d2, f3), m3 = r2.sub(m3, h3), h3 = r2.add(t3, i2);
        let g3 = r2.add(a3, s3);
        return h3 = r2.mul(h3, g3), g3 = r2.add(d2, p2), h3 = r2.sub(h3, g3), g3 = r2.add(n3, i2), c3 = r2.add(o3, s3), g3 = r2.mul(g3, c3), c3 = r2.add(f3, p2), g3 = r2.sub(g3, c3), u3 = O2(h3), c3 = r2.mul(ie2, p2), u3 = r2.add(c3, u3), c3 = r2.sub(f3, u3), u3 = r2.add(f3, u3), l3 = r2.mul(c3, u3), f3 = r2.add(d2, d2), f3 = r2.add(f3, d2), p2 = O2(p2), h3 = r2.mul(ie2, h3), f3 = r2.add(f3, p2), p2 = r2.sub(d2, p2), p2 = O2(p2), h3 = r2.add(h3, p2), d2 = r2.mul(f3, h3), l3 = r2.add(l3, d2), d2 = r2.mul(g3, h3), c3 = r2.mul(m3, c3), c3 = r2.sub(c3, d2), d2 = r2.mul(m3, f3), u3 = r2.mul(g3, u3), u3 = r2.add(u3, d2), new F2(c3, l3, u3);
      }
      subtract(e3) {
        return M2(e3), this.add(e3.negate());
      }
      is0() {
        return this.equals(F2.ZERO);
      }
      multiply(e3) {
        if (!a2.isValidNot0(e3)) throw RangeError(`invalid scalar: out of range`);
        let { p: t3, f: n3 } = L2.mulSecret(this, e3, s2, I2);
        return I2([
          t3,
          n3
        ])[0];
      }
      multiplyUnsafe(e3) {
        let t3 = this, n3 = e3;
        if (!a2.isValid(n3)) throw RangeError(`invalid scalar: out of range`);
        if (n3 === B || t3.is0()) return F2.ZERO;
        if (n3 === V) return t3;
        if (L2.hasWindowSize(this)) return L2.mulUnsafe(t3, n3, I2);
        let r3 = [], i2 = [];
        return N2(r3, i2, t3, n3), T(F2, r3, i2);
      }
      mulAddUnsafe(e3, t3, n3) {
        M2(t3);
        let r3 = [], i2 = [];
        return N2(r3, i2, this, e3), N2(r3, i2, t3, n3), T(F2, r3, i2);
      }
      toAffine(e3) {
        let t3 = this, n3 = e3;
        if (n3 != null && !r2.isValid(n3)) throw RangeError(`"invertedZ" expected valid field element`);
        let { X: i2, Y: a3, Z: o3 } = t3;
        if (r2.eql(o3, r2.ONE)) return {
          x: i2,
          y: a3
        };
        let s3 = t3.is0();
        n3 ??= s3 ? r2.ONE : r2.inv(o3);
        let c3 = r2.mul(i2, n3), l3 = r2.mul(a3, n3), u3 = r2.mul(o3, n3);
        if (s3) return {
          x: r2.ZERO,
          y: r2.ZERO
        };
        if (!r2.eql(u3, r2.ONE)) throw Error(`invZ was invalid`);
        return {
          x: c3,
          y: l3
        };
      }
      isTorsionFree() {
        return s2 === V ? true : m2 ? m2(F2, this) : L2.mulUnsafe(this, c2).is0();
      }
      clearCofactor() {
        return s2 === V ? this : f2 ? f2(F2, this) : this.multiplyUnsafe(s2);
      }
      isSmallOrder() {
        return s2 === V ? this.is0() : this.clearCofactor().is0();
      }
      toBytes(e3 = true) {
        return x(e3, `isCompressed`), this.assertValidity(), ne2(F2, this, e3);
      }
      toHex(e3 = true) {
        return oe(this.toBytes(e3));
      }
      toString() {
        return `<Point ${this.is0() ? `ZERO` : this.toHex()}>`;
      }
    }
    let I2 = (e3) => D(F2, e3), L2 = new re(F2, _2);
    return L2.bits >= 6 && F2.BASE.precompute(6), Object.freeze(F2.prototype), Object.freeze(F2), F2;
  }
  function xe(e2) {
    return Uint8Array.of(e2 ? 2 : 3);
  }
  function Se(e2, t2) {
    return {
      secretKey: t2.BYTES,
      publicKey: 1 + e2.BYTES,
      publicKeyUncompressed: 1 + 2 * e2.BYTES,
      publicKeyHasPrefix: true,
      signature: 2 * t2.BYTES
    };
  }
  function Ce(e2, t2 = {}) {
    ee(e2);
    let { Fn: n2 } = e2, r2 = t2.randomBytes === void 0 ? d : t2.randomBytes, i2 = Object.assign(Se(e2.Fp, n2), {
      seed: Math.max(ie(n2.ORDER), 16)
    });
    function a2(e3) {
      try {
        let t3 = n2.fromBytes(e3);
        return n2.isValidNot0(t3);
      } catch {
        return false;
      }
    }
    function s2(t3, n3) {
      let { publicKey: r3, publicKeyUncompressed: a3 } = i2;
      try {
        let i3 = t3.length;
        return n3 === true && i3 !== r3 || n3 === false && i3 !== a3 ? false : !e2.fromBytes(t3).is0();
      } catch {
        return false;
      }
    }
    function c2(e3) {
      return e3 = e3 === void 0 ? r2(i2.seed) : e3, y(b(e3, i2.seed, `seed`), n2.ORDER);
    }
    function l2(t3, r3 = true) {
      return e2.BASE.multiply(n2.fromBytes(t3)).toBytes(r3);
    }
    function u2(e3) {
      let { secretKey: t3, publicKey: r3, publicKeyUncompressed: a3 } = i2, s3 = n2._lengths;
      if (!o(e3)) return;
      let c3 = b(e3, void 0, `key`).length, l3 = c3 === r3 || c3 === a3, u3 = c3 === t3 || !!s3?.includes(c3);
      if (!(l3 && u3)) return l3;
    }
    function f2(t3, r3, i3 = true) {
      if (u2(t3) === true) throw Error(`first arg must be private key`);
      if (u2(r3) === false) throw Error(`second arg must be public key`);
      let a3 = n2.fromBytes(t3), o2 = e2.fromBytes(r3);
      if (o2.is0()) throw Error(`invalid public key: point at infinity`);
      return o2.multiply(a3).toBytes(i3);
    }
    let p2 = {
      isValidSecretKey: a2,
      isValidPublicKey: s2,
      randomSecretKey: c2
    }, m2 = h(c2, l2);
    return Object.freeze(p2), Object.freeze(i2), Object.freeze({
      getPublicKey: l2,
      getSharedSecret: f2,
      keygen: m2,
      Point: e2,
      utils: p2,
      lengths: i2
    });
  }
  function we(e2, t2, n2 = {}) {
    ee(e2);
    let r2 = t2;
    u(r2), w(n2, {}, {
      hmac: `function`,
      lowS: `boolean`,
      randomBytes: `function`,
      bits2int: `function`,
      bits2int_modN: `function`
    });
    let a2 = Object.assign({}, n2), s2 = a2.randomBytes === void 0 ? d : a2.randomBytes, c2 = a2.hmac === void 0 ? (e3, t3) => ue(r2, e3, t3) : a2.hmac, { Fp: l2, Fn: m2 } = e2, { ORDER: h2, BITS: x2 } = m2, S2 = ie(h2), C2 = _(s2, S2), { keygen: te2, getPublicKey: ne2, getSharedSecret: T2, utils: re2, lengths: D2 } = Ce(e2, a2), O2 = {
      prehash: true,
      lowS: typeof a2.lowS != `boolean` || a2.lowS,
      format: `compact`,
      extraEntropy: false
    }, se2 = h2 * _e + V < l2.ORDER;
    function k2(e3) {
      return e3 > h2 >> V;
    }
    function A2(e3, t3) {
      if (!m2.isValidNot0(t3)) throw Error(`invalid signature ${e3}: out of range 1..Point.Fn.ORDER`);
      return t3;
    }
    function j2() {
      if (!l2.isOdd) throw Error(`Field doesn't support isOdd`);
    }
    function M2(e3, t3, n3) {
      return j2(), (e3 === n3 ? 0 : 2) | Number(l2.isOdd(t3));
    }
    function ce2() {
      if (se2) throw Error(`"recovered" sig type is not supported for cofactor >2 curves`);
    }
    function N2(e3, t3) {
      he(t3);
      let n3 = D2.signature, r3 = t3 === `compact` ? n3 : t3 === `recovered` ? n3 + 1 : void 0;
      return b(e3, r3);
    }
    class P2 {
      r;
      s;
      recovery;
      constructor(e3, t3, n3) {
        if (this.r = A2(`r`, e3), this.s = A2(`s`, t3), n3 != null) {
          if (ce2(), ![
            0,
            1,
            2,
            3
          ].includes(n3)) throw Error(`invalid recovery id`);
          this.recovery = n3;
        }
        Object.freeze(this);
      }
      static fromBytes(e3, t3 = O2.format) {
        N2(e3, t3);
        let n3;
        if (t3 === `der`) {
          if (e3.length > 2 * m2.BYTES + 16) throw new fe.Err(`invalid signature: DER signature too long`);
          let { r: t4, s: n4 } = fe.toSig(b(e3), m2.BYTES + 1);
          return new P2(t4, n4);
        }
        t3 === `recovered` && (n3 = e3[0], t3 = `compact`, e3 = e3.subarray(1));
        let r3 = D2.signature / 2, i2 = e3.subarray(0, r3), a3 = e3.subarray(r3, r3 * 2);
        return new P2(m2.fromBytes(i2), m2.fromBytes(a3), n3);
      }
      static fromHex(e3, t3) {
        return this.fromBytes(p(e3), t3);
      }
      assertRecovery() {
        let { recovery: e3 } = this;
        if (e3 == null) throw Error(`invalid recovery id: must be present`);
        return e3;
      }
      addRecoveryBit(e3) {
        return new P2(this.r, this.s, e3);
      }
      recoverPublicKey(t3) {
        let { r: n3, s: r3 } = this, a3 = this.assertRecovery(), o2 = a3 === 2 || a3 === 3 ? n3 + h2 : n3;
        if (!l2.isValid(o2)) throw Error(`invalid recovery id: sig.r+curve.n != R.x`);
        let s3 = l2.toBytes(o2), c3 = e2.fromBytes(i(xe(!(a3 & 1)), s3)), u2 = m2.inv(o2), d2 = I2(b(t3, void 0, `msgHash`)), f2 = m2.create(-d2 * u2), p2 = m2.create(r3 * u2), g2 = e2.BASE.mulAddUnsafe(f2, c3, p2);
        if (g2.is0()) throw Error(`invalid recovery: point at infinify`);
        return g2.assertValidity(), g2;
      }
      hasHighS() {
        return k2(this.s);
      }
      toBytes(e3 = O2.format) {
        if (he(e3), e3 === `der`) return p(fe.hexFromSig(this));
        let { r: t3, s: n3 } = this, r3 = m2.toBytes(t3), a3 = m2.toBytes(n3);
        return e3 === `recovered` ? (ce2(), i(Uint8Array.of(this.assertRecovery()), r3, a3)) : i(r3, a3);
      }
      toHex(e3) {
        return oe(this.toBytes(e3));
      }
    }
    Object.freeze(P2.prototype), Object.freeze(P2);
    let F2 = a2.bits2int === void 0 ? function(e3) {
      if (e3.length > 8192) throw Error(`input is too large`);
      let t3 = f(e3), n3 = e3.length * 8 - x2;
      return n3 > 0 ? t3 >> BigInt(n3) : t3;
    } : a2.bits2int, I2 = a2.bits2int_modN === void 0 ? function(e3) {
      return m2.create(F2(e3));
    } : a2.bits2int_modN, L2 = g(x2);
    function R2(e3) {
      return E(`num < 2^` + x2, e3, B, L2), m2.toBytes(e3);
    }
    function le2(e3, t3) {
      return b(e3, void 0, `message`), t3 ? b(r2(e3), void 0, `prehashed message`) : e3;
    }
    function de2(t3, n3, r3) {
      let { lowS: a3, prehash: o2, extraEntropy: c3 } = ge(r3, O2);
      t3 = le2(t3, o2);
      let l3 = I2(t3), u2 = m2.fromBytes(n3);
      if (!m2.isValidNot0(u2)) throw Error(`invalid private key`);
      let d2 = [
        R2(u2),
        R2(l3)
      ];
      if (c3 != null && c3 !== false) {
        let e3 = c3 === true ? s2(D2.secretKey) : c3;
        d2.push(b(e3, void 0, `extraEntropy`));
      }
      let p2 = i(...d2), g2 = l3;
      function _2(t4) {
        let n4 = F2(t4);
        if (!m2.isValidNot0(n4)) return;
        let r4 = e2.BASE.multiply(n4).toAffine(), i2 = m2.create(r4.x);
        if (i2 === B) return;
        let o3;
        if (C2 !== void 0) {
          let e3 = f(y(C2(S2), h2)), t5 = m2.inv(m2.mul(e3, n4)), r5 = m2.mul(e3, g2), a4 = m2.mul(e3, u2);
          o3 = m2.create(t5 * m2.create(r5 + a4 * i2));
        } else {
          let e3 = v(n4, h2);
          o3 = m2.create(e3 * m2.create(g2 + i2 * u2));
        }
        if (o3 === B) return;
        let s3 = M2(r4.x, r4.y, i2), c4 = o3;
        return a3 && k2(o3) && (c4 = m2.neg(o3), s3 ^= 1), new P2(i2, c4, se2 ? void 0 : s3);
      }
      return {
        seed: p2,
        k2sig: _2
      };
    }
    function z2(e3, t3, n3 = {}) {
      let { seed: i2, k2sig: a3 } = de2(e3, t3, n3);
      return ae(r2.outputLen, m2.BYTES, c2)(i2, a3).toBytes(n3.format);
    }
    function pe2(t3, n3, r3, i2 = {}) {
      let { lowS: a3, prehash: s3, format: c3 } = ge(i2, O2);
      if (r3 = b(r3, void 0, `publicKey`), n3 = le2(n3, s3), !o(t3)) {
        let e3 = t3 instanceof P2 ? `, use sig.toBytes()` : ``;
        throw Error(`verify expects Uint8Array signature` + e3);
      }
      N2(t3, c3);
      try {
        let i3 = P2.fromBytes(t3, c3), o2 = e2.fromBytes(r3);
        if (o2.is0() || a3 && i3.hasHighS()) return false;
        let { r: s4, s: l3 } = i3, u2 = I2(n3), d2 = m2.inv(l3), f2 = m2.create(u2 * d2), p2 = m2.create(s4 * d2), h3 = e2.BASE.mulAddUnsafe(f2, o2, p2);
        if (h3.is0()) return false;
        let g2 = h3.toAffine();
        return !(m2.create(g2.x) !== s4 || c3 === `recovered` && i3.recovery !== M2(g2.x, g2.y, s4));
      } catch {
        return false;
      }
    }
    function me2(e3, t3, n3 = {}) {
      let { prehash: r3 } = ge(n3, O2);
      return t3 = le2(t3, r3), P2.fromBytes(e3, `recovered`).recoverPublicKey(t3).toBytes();
    }
    return Object.freeze({
      keygen: te2,
      getPublicKey: ne2,
      getSharedSecret: T2,
      utils: re2,
      lengths: D2,
      Point: e2,
      sign: z2,
      verify: pe2,
      recoverPublicKey: me2,
      Signature: P2,
      hash: r2
    });
  }
  let Ee, De, Oe;
  Te = we(be({
    p: BigInt(`0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff`),
    n: BigInt(`0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551`),
    h: BigInt(1),
    a: BigInt(`0xffffffff00000001000000000000000000000000fffffffffffffffffffffffc`),
    b: BigInt(`0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b`),
    Gx: BigInt(`0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296`),
    Gy: BigInt(`0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5`)
  }), r);
  Ee = t({
    generateKeyPair: () => ke,
    pointCoordinates: () => Me,
    pointFromCoordinates: () => Ne,
    publicKeyFrom: () => Ae,
    sharedSecret: () => je
  });
  De = 65;
  Oe = 32;
  function ke() {
    let e2 = Te.utils.randomSecretKey();
    return {
      privateKey: e2,
      publicKey: Te.getPublicKey(e2, false)
    };
  }
  function Ae(e2) {
    if (!(e2 instanceof Uint8Array) || e2.length !== Oe) throw TypeError(`P-256 privateKey must be 32 bytes`);
    return Te.getPublicKey(e2, false);
  }
  function je(e2, t2) {
    if (!(e2 instanceof Uint8Array) || e2.length !== Oe) throw TypeError(`P-256 privateKey must be 32 bytes`);
    if (!(t2 instanceof Uint8Array)) throw TypeError(`P-256 peerPublicKey must be a Uint8Array`);
    return Te.getSharedSecret(e2, t2, true).slice(1, 33);
  }
  function Me(e2) {
    if (!(e2 instanceof Uint8Array) || e2.length !== De || e2[0] !== 4) throw TypeError(`P-256 public key must be a 65-byte uncompressed SEC1 point (0x04 prefix)`);
    return {
      x: e2.slice(1, 33),
      y: e2.slice(33)
    };
  }
  function Ne(e2, t2) {
    if (!(e2 instanceof Uint8Array) || e2.length !== Oe) throw TypeError(`P-256 x-coordinate must be 32 bytes`);
    if (!(t2 instanceof Uint8Array) || t2.length !== Oe) throw TypeError(`P-256 y-coordinate must be 32 bytes`);
    let n2 = new Uint8Array(De);
    return n2[0] = 4, n2.set(e2, 1), n2.set(t2, 33), Te.Point.fromBytes(n2), n2;
  }
  var Pe = /* @__PURE__ */ new Set([
    `X25519`,
    `Ed25519`
  ]), Fe = /* @__PURE__ */ new Set([
    `P-256`
  ]);
  function H(e2, t2, n2) {
    if (Fe.has(e2)) {
      let { x: r3, y: i2 } = Me(t2), a2 = {
        kty: `EC`,
        crv: e2,
        x: A(r3),
        y: A(i2)
      };
      return n2 && (a2.kid = n2), a2;
    }
    if (ze(e2), t2.length !== 32) throw Error(`jwk: ${e2} public key must be 32 bytes, got ${t2.length}`);
    let r2 = {
      kty: `OKP`,
      crv: e2,
      x: A(t2)
    };
    return n2 && (r2.kid = n2), r2;
  }
  function Ie(e2, t2, n2, r2) {
    let i2 = H(e2, n2, r2);
    if (t2.length !== 32) throw Error(`jwk: ${e2} private key must be 32 bytes, got ${t2.length}`);
    return {
      ...i2,
      d: A(t2)
    };
  }
  function U(e2) {
    return Be(e2), e2.crv;
  }
  function Le(e2) {
    if (Be(e2), e2.kty === `EC`) {
      let t3 = j(e2.x), n2 = j(e2.y);
      if (t3.length !== 32 || n2.length !== 32) throw Error(`jwk: ${e2.crv} JWK 'x'/'y' must each decode to 32 bytes`);
      return Ne(t3, n2);
    }
    let t2 = j(e2.x);
    if (t2.length !== 32) throw Error(`jwk: ${e2.crv} JWK 'x' must decode to 32 bytes, got ${t2.length}`);
    return t2;
  }
  function Re(e2) {
    if (Be(e2), !e2.d) throw Error(`jwk: JWK has no 'd' \u2014 this is a public-only key`);
    let t2 = j(e2.d);
    if (t2.length !== 32) throw Error(`jwk: ${e2.crv} JWK 'd' must decode to 32 bytes, got ${t2.length}`);
    return t2;
  }
  function ze(e2) {
    if (!Pe.has(e2)) throw Error(`jwk: unsupported OKP curve: ${e2}. Expected one of ${[
      ...Pe
    ].join(`, `)}`);
  }
  function Be(e2) {
    if (!e2 || typeof e2 != `object`) throw TypeError(`jwk: JWK must be an object`);
    if (e2.kty === `OKP`) {
      if (ze(e2.crv), typeof e2.x != `string`) throw Error(`jwk: OKP JWK 'x' must be a string`);
      return;
    }
    if (e2.kty === `EC`) {
      if (!Fe.has(e2.crv)) throw Error(`jwk: unsupported EC curve: ${e2.crv}. Expected one of ${[
        ...Fe
      ].join(`, `)}`);
      if (typeof e2.x != `string` || typeof e2.y != `string`) throw Error(`jwk: EC JWK 'x' and 'y' must be strings`);
      return;
    }
    throw Error(`jwk: JWK kty must be 'OKP' or 'EC', got ${JSON.stringify(e2.kty)}`);
  }
  var Ve = 32;
  async function He(e2, { alg: t2, apu: n2, apv: r2, suppPrivInfo: i2, legacyRawSuppPrivInfo: a2 = false }, o2) {
    if (!(e2 instanceof Uint8Array)) throw TypeError(`ConcatKDF: Z must be Uint8Array`);
    if (typeof t2 != `string` || t2.length === 0) throw TypeError(`ConcatKDF: alg must be a non-empty string`);
    if (!(n2 instanceof Uint8Array) || !(r2 instanceof Uint8Array)) throw TypeError(`ConcatKDF: apu and apv must be Uint8Array`);
    if (i2 !== void 0 && !(i2 instanceof Uint8Array)) throw TypeError(`ConcatKDF: suppPrivInfo must be Uint8Array if provided`);
    if (typeof o2 != `number` || o2 <= 0 || o2 % 8 != 0 || o2 > 4096) throw Error(`ConcatKDF: keyDataLenBits must be a positive multiple of 8 \u2264 4096; got ${o2}`);
    let s2 = o2 / 8, c2 = new TextEncoder().encode(t2), l2 = i2 ? a2 ? i2 : We(i2) : new Uint8Array(), u2 = Ge(We(c2), We(n2), We(r2), Ue(o2), l2), d2 = Math.ceil(s2 / Ve), f2 = new Uint8Array(d2 * Ve);
    for (let t3 = 1; t3 <= d2; t3++) {
      let n3 = Ge(Ue(t3), e2, u2), r3 = await crypto.subtle.digest(`SHA-256`, n3);
      f2.set(new Uint8Array(r3), (t3 - 1) * Ve);
    }
    return f2.subarray(0, s2);
  }
  function Ue(e2) {
    if (!Number.isInteger(e2) || e2 < 0 || e2 > 4294967295) throw RangeError(`uint32be: out of range: ${e2}`);
    let t2 = new Uint8Array(4);
    return t2[0] = e2 >>> 24 & 255, t2[1] = e2 >>> 16 & 255, t2[2] = e2 >>> 8 & 255, t2[3] = e2 & 255, t2;
  }
  function We(e2) {
    let t2 = new Uint8Array(4 + e2.length);
    return t2.set(Ue(e2.length), 0), t2.set(e2, 4), t2;
  }
  function Ge(...e2) {
    let t2 = 0;
    for (let n3 of e2) t2 += n3.length;
    let n2 = new Uint8Array(t2), r2 = 0;
    for (let t3 of e2) n2.set(t3, r2), r2 += t3.length;
    return n2;
  }
  var Ke = t({
    generateKeyPair: () => qe,
    publicKeyFrom: () => Je,
    sharedSecret: () => Ye
  });
  function qe() {
    let { secretKey: e2, publicKey: t2 } = ne.keygen();
    return {
      privateKey: e2,
      publicKey: t2
    };
  }
  function Je(e2) {
    if (!(e2 instanceof Uint8Array) || e2.length !== 32) throw TypeError(`X25519 privateKey must be 32 bytes`);
    return ne.getPublicKey(e2);
  }
  function Ye(e2, t2) {
    if (!(e2 instanceof Uint8Array) || e2.length !== 32) throw TypeError(`X25519 privateKey must be 32 bytes`);
    if (!(t2 instanceof Uint8Array) || t2.length !== 32) throw TypeError(`X25519 peerPublicKey must be 32 bytes`);
    return ne.getSharedSecret(e2, t2);
  }
  var Xe = `X25519`, Ze = `P-256`, Qe = {
    [Xe]: Ke,
    [Ze]: Ee
  };
  function $e(e2) {
    let t2 = Qe[e2];
    if (!t2) throw Error(`key-agreement: unsupported curve ${JSON.stringify(e2)}; supported: ${Object.keys(Qe).join(`, `)}`);
    return t2;
  }
  function et(e2) {
    return Object.prototype.hasOwnProperty.call(Qe, e2);
  }
  function tt(e2) {
    return $e(e2).generateKeyPair();
  }
  function nt(e2, t2, n2) {
    return $e(e2).sharedSecret(t2, n2);
  }
  async function rt({ ephemeralPrivate: e2, senderPrivate: t2, recipientPublic: n2, alg: r2, apu: i2, apv: a2, ccTag: o2, crv: s2 = `X25519`, legacy: c2 = false }) {
    return He(at(nt(s2, e2, n2), nt(s2, t2, n2)), {
      alg: r2,
      apu: i2,
      apv: a2,
      suppPrivInfo: o2,
      legacyRawSuppPrivInfo: c2
    }, 256);
  }
  async function it({ recipientPrivate: e2, ephemeralPublic: t2, senderPublic: n2, alg: r2, apu: i2, apv: a2, ccTag: o2, crv: s2 = `X25519`, legacy: c2 = false }) {
    return He(at(nt(s2, e2, t2), nt(s2, e2, n2)), {
      alg: r2,
      apu: i2,
      apv: a2,
      suppPrivInfo: o2,
      legacyRawSuppPrivInfo: c2
    }, 256);
  }
  function at(e2, t2) {
    let n2 = new Uint8Array(e2.length + t2.length);
    return n2.set(e2, 0), n2.set(t2, e2.length), n2;
  }
  async function ot({ recipientPrivate: e2, ephemeralPublic: t2, alg: n2, apu: r2, apv: i2, crv: a2 = `X25519` }) {
    return He(nt(a2, e2, t2), {
      alg: n2,
      apu: r2,
      apv: i2
    }, 256);
  }
  async function st(e2, t2) {
    dt(`kek`, e2, 32), dt(`cek`, t2);
    let n2 = await lt(e2, [
      `wrapKey`
    ]), r2 = await ut(t2), i2 = await crypto.subtle.wrapKey(`raw`, r2, n2, `AES-KW`);
    return new Uint8Array(i2);
  }
  async function ct(e2, t2) {
    dt(`kek`, e2, 32), dt(`wrapped`, t2);
    let n2 = await lt(e2, [
      `unwrapKey`
    ]), r2 = await crypto.subtle.unwrapKey(`raw`, t2, n2, `AES-KW`, {
      name: `HMAC`,
      hash: `SHA-256`,
      length: (t2.length - 8) * 8
    }, true, [
      `sign`,
      `verify`
    ]), i2 = await crypto.subtle.exportKey(`raw`, r2);
    return new Uint8Array(i2);
  }
  async function lt(e2, t2) {
    return crypto.subtle.importKey(`raw`, e2, {
      name: `AES-KW`,
      length: 256
    }, false, t2);
  }
  async function ut(e2) {
    return crypto.subtle.importKey(`raw`, e2, {
      name: `HMAC`,
      hash: `SHA-256`,
      length: e2.length * 8
    }, true, [
      `sign`,
      `verify`
    ]);
  }
  function dt(e2, t2, n2) {
    if (!(t2 instanceof Uint8Array)) throw TypeError(`${e2} must be Uint8Array`);
    if (n2 !== void 0 && t2.length !== n2) throw Error(`${e2} must be ${n2} bytes, got ${t2.length}`);
  }
  var ft = 64, pt = 16, mt = 32;
  async function ht({ cek: e2, iv: t2, aad: n2, plaintext: r2 }) {
    W(`cek`, e2, ft), W(`iv`, t2, pt), W(`aad`, n2), W(`plaintext`, r2);
    let i2 = e2.subarray(0, 32), a2 = await vt(e2.subarray(32, 64), t2, r2);
    return {
      ciphertext: a2,
      tag: await bt(i2, n2, t2, a2)
    };
  }
  async function gt({ cek: e2, iv: t2, aad: n2, ciphertext: r2, tag: i2 }) {
    W(`cek`, e2, ft), W(`iv`, t2, pt), W(`aad`, n2), W(`ciphertext`, r2), W(`tag`, i2, mt);
    let a2 = e2.subarray(0, 32), o2 = e2.subarray(32, 64);
    if (!Ct(await bt(a2, n2, t2, r2), i2)) throw Error(`A256CBC-HS512: authentication tag mismatch`);
    return yt(o2, t2, r2);
  }
  function _t() {
    let e2 = new Uint8Array(ft), t2 = new Uint8Array(pt);
    return crypto.getRandomValues(e2), crypto.getRandomValues(t2), {
      cek: e2,
      iv: t2
    };
  }
  async function vt(e2, t2, n2) {
    let r2 = await crypto.subtle.importKey(`raw`, e2, {
      name: `AES-CBC`,
      length: 256
    }, false, [
      `encrypt`
    ]), i2 = await crypto.subtle.encrypt({
      name: `AES-CBC`,
      iv: t2
    }, r2, n2);
    return new Uint8Array(i2);
  }
  async function yt(e2, t2, n2) {
    let r2 = await crypto.subtle.importKey(`raw`, e2, {
      name: `AES-CBC`,
      length: 256
    }, false, [
      `decrypt`
    ]), i2 = await crypto.subtle.decrypt({
      name: `AES-CBC`,
      iv: t2
    }, r2, n2);
    return new Uint8Array(i2);
  }
  async function bt(e2, t2, n2, r2) {
    let i2 = St(t2, n2, r2, xt(t2.length)), a2 = await crypto.subtle.importKey(`raw`, e2, {
      name: `HMAC`,
      hash: `SHA-512`
    }, false, [
      `sign`
    ]);
    return new Uint8Array(await crypto.subtle.sign(`HMAC`, a2, i2)).subarray(0, mt);
  }
  function xt(e2) {
    let t2 = BigInt(e2) * 8n, n2 = new Uint8Array(8);
    for (let e3 = 7; e3 >= 0; e3--) n2[e3] = Number(t2 >> BigInt((7 - e3) * 8)) & 255;
    return n2;
  }
  function St(...e2) {
    let t2 = 0;
    for (let n3 of e2) t2 += n3.length;
    let n2 = new Uint8Array(t2), r2 = 0;
    for (let t3 of e2) n2.set(t3, r2), r2 += t3.length;
    return n2;
  }
  function Ct(e2, t2) {
    if (e2.length !== t2.length) return false;
    let n2 = 0;
    for (let r2 = 0; r2 < e2.length; r2++) n2 |= e2[r2] ^ t2[r2];
    return n2 === 0;
  }
  function W(e2, t2, n2) {
    if (!(t2 instanceof Uint8Array)) throw TypeError(`a256cbc-hs512: ${e2} must be Uint8Array`);
    if (n2 !== void 0 && t2.length !== n2) throw Error(`a256cbc-hs512: ${e2} must be ${n2} bytes, got ${t2.length}`);
  }
  var wt = `ECDH-1PU+A256KW`, Tt = `A256CBC-HS512`, Et = `application/didcomm-encrypted+json`;
  async function Dt({ message: e2, sender: t2, recipient: n2 }) {
    if (!t2?.kid || !t2?.privateJwk) throw TypeError(`pack: sender.{kid, privateJwk} required`);
    if (!n2?.kid || !n2?.publicJwk) throw TypeError(`pack: recipient.{kid, publicJwk} required`);
    let r2 = U(n2.publicJwk);
    if (!et(r2)) throw Error(`pack: recipient key curve ${JSON.stringify(r2)} is not a supported key-agreement curve`);
    if (U(t2.privateJwk) !== r2) throw Error(`pack: sender key curve (${U(t2.privateJwk)}) must match recipient curve (${r2}) for ECDH-1PU`);
    let i2 = Re(t2.privateJwk), a2 = Le(n2.publicJwk), o2 = tt(r2), { cek: s2, iv: c2 } = _t(), l2 = new TextEncoder().encode(t2.kid), u2 = await Ot(new TextEncoder().encode(n2.kid)), d2 = {
      typ: Et,
      alg: wt,
      enc: Tt,
      apu: A(l2),
      apv: A(u2),
      skid: t2.kid,
      epk: H(r2, o2.publicKey)
    }, f2 = JSON.stringify(d2), p2 = A(new TextEncoder().encode(f2)), m2 = new TextEncoder().encode(JSON.stringify(e2)), { ciphertext: h2, tag: g2 } = await ht({
      cek: s2,
      iv: c2,
      aad: new TextEncoder().encode(p2),
      plaintext: m2
    }), _2 = await rt({
      ephemeralPrivate: o2.privateKey,
      senderPrivate: i2,
      recipientPublic: a2,
      alg: wt,
      apu: l2,
      apv: u2,
      ccTag: g2,
      crv: r2
    }), v2 = await st(_2, s2), y2 = {
      protected: p2,
      recipients: [
        {
          header: {
            kid: n2.kid
          },
          encrypted_key: A(v2)
        }
      ],
      iv: A(c2),
      ciphertext: A(h2),
      tag: A(g2)
    };
    return s2.fill(0), _2.fill(0), JSON.stringify(y2);
  }
  async function Ot(e2) {
    let t2 = await crypto.subtle.digest(`SHA-256`, e2);
    return new Uint8Array(t2);
  }
  var kt = `ECDH-1PU+A256KW`, At = `ECDH-ES+A256KW`, jt = `A256CBC-HS512`, Mt = `E_SENDER_MISMATCH`;
  function Nt(e2) {
    return String(e2).split(`#`)[0];
  }
  var Pt = class extends Error {
    constructor(e2, { senderDid: t2, claimedFrom: n2 }) {
      super(e2), this.name = `SenderMismatchError`, this.code = Mt, this.senderDid = t2, this.claimedFrom = n2;
    }
  };
  async function Ft(e2, t2, n2) {
    if (typeof e2 != `string`) throw TypeError(`unpack: jweJson must be a string`);
    if (!t2?.kid || !t2?.privateJwk) throw TypeError(`unpack: recipient.{kid, privateJwk} required`);
    let r2;
    try {
      r2 = JSON.parse(e2);
    } catch (e3) {
      throw Error(`unpack: not a JSON document: ${e3.message}`);
    }
    Lt(r2);
    let i2 = r2.protected, a2 = j(i2), o2;
    try {
      o2 = JSON.parse(new TextDecoder().decode(a2));
    } catch (e3) {
      throw Error(`unpack: protected header not JSON: ${e3.message}`);
    }
    let s2 = o2.alg === kt, c2 = o2.alg === At;
    if (!s2 && !c2) throw Error(`unpack: unsupported alg ${JSON.stringify(o2.alg)}; expected ${kt} or ${At}`);
    if (o2.enc !== jt) throw Error(`unpack: unsupported enc ${JSON.stringify(o2.enc)}; expected ${jt}`);
    let l2 = It(o2.epk);
    if (s2 && !o2.skid) throw Error(`unpack: authcrypt protected header missing skid`);
    if (s2 && !n2?.publicJwk) throw TypeError(`unpack: sender.publicJwk required for authcrypt`);
    let u2 = r2.recipients.find((e3) => e3?.header?.kid === t2.kid);
    if (!u2) throw Error(`unpack: no recipients[] entry for kid ${JSON.stringify(t2.kid)}`);
    if (!u2.encrypted_key) throw Error(`unpack: matched recipients[] entry has no encrypted_key`);
    let d2 = j(r2.iv), f2 = j(r2.ciphertext), p2 = j(r2.tag), m2 = new TextEncoder().encode(i2);
    if (U(t2.privateJwk) !== l2) throw Error(`unpack: recipient key curve (${U(t2.privateJwk)}) does not match epk curve (${l2})`);
    let h2 = Re(t2.privateJwk), g2 = Le(o2.epk), _2 = o2.apu ? j(o2.apu) : new Uint8Array(), v2 = o2.apv ? j(o2.apv) : new Uint8Array(), y2 = j(u2.encrypted_key), b2, x2 = false;
    if (s2) {
      let e3 = new TextDecoder().decode(_2);
      if (e3 !== o2.skid) throw Error(`unpack: authcrypt apu (${JSON.stringify(e3)}) does not match skid (${JSON.stringify(o2.skid)})`);
      if (U(n2.publicJwk) !== l2) throw Error(`unpack: sender key curve (${U(n2.publicJwk)}) does not match epk curve (${l2})`);
      let t3 = {
        recipientPrivate: h2,
        ephemeralPublic: g2,
        senderPublic: Le(n2.publicJwk),
        alg: kt,
        apu: _2,
        apv: v2,
        ccTag: p2,
        crv: l2
      }, r3 = await it(t3);
      try {
        b2 = await ct(r3, y2);
      } catch {
        let e4 = await it({
          ...t3,
          legacy: true
        });
        try {
          b2 = await ct(e4, y2), x2 = true;
        } finally {
          e4.fill(0);
        }
      } finally {
        r3.fill(0);
      }
    } else {
      let e3 = await ot({
        recipientPrivate: h2,
        ephemeralPublic: g2,
        alg: At,
        apu: _2,
        apv: v2,
        crv: l2
      });
      try {
        b2 = await ct(e3, y2);
      } finally {
        e3.fill(0);
      }
    }
    let S2;
    try {
      S2 = await gt({
        cek: b2,
        iv: d2,
        aad: m2,
        ciphertext: f2,
        tag: p2
      });
    } catch (e3) {
      throw Error(`unpack: A256CBC-HS512 decrypt failed: ${e3.message}`);
    } finally {
      b2.fill(0);
    }
    let C2;
    try {
      C2 = JSON.parse(new TextDecoder().decode(S2));
    } catch (e3) {
      throw Error(`unpack: plaintext not JSON: ${e3.message}`);
    }
    if (typeof C2 != `object` || !C2 || Array.isArray(C2)) throw Error(`unpack: plaintext is not a JSON object`);
    let w2 = null;
    if (s2 && (w2 = Nt(o2.skid), !w2.startsWith(`did:`) || typeof C2.from != `string` || C2.from !== w2)) throw new Pt(`unpack: authcrypt from (${JSON.stringify(C2.from)}) is not the DID of skid (${JSON.stringify(o2.skid)})`, {
      senderDid: w2,
      claimedFrom: C2.from
    });
    return {
      message: C2,
      senderKid: s2 ? o2.skid : null,
      senderDid: w2,
      authenticated: s2,
      legacyKekUsed: x2
    };
  }
  function It(e2) {
    if (!e2 || typeof e2 != `object`) throw Error(`unpack: protected header missing epk`);
    if (e2.kty === `OKP` && e2.crv === `X25519`) return `X25519`;
    if (e2.kty === `EC` && e2.crv === `P-256`) return `P-256`;
    throw Error(`unpack: unsupported epk ${JSON.stringify({
      kty: e2.kty,
      crv: e2.crv
    })}; expected OKP/X25519 or EC/P-256`);
  }
  function Lt(e2) {
    if (!e2 || typeof e2 != `object`) throw Error(`unpack: JWE must be a JSON object`);
    for (let t2 of [
      `protected`,
      `recipients`,
      `iv`,
      `ciphertext`,
      `tag`
    ]) if (e2[t2] === void 0) throw Error(`unpack: JWE missing field ${JSON.stringify(t2)}`);
    if (!Array.isArray(e2.recipients) || e2.recipients.length === 0) throw Error(`unpack: recipients must be a non-empty array`);
  }
  var Rt = t({
    ed25519PublicKeyToX25519: () => Jt,
    resolve: () => Wt
  }), zt = N.ED25519_PUB, Bt = N.X25519_PUB, Vt = N.P256_PUB, Ht = N.SECP256K1_PUB, Ut = (1n << 255n) - 19n;
  Wt = function(e2) {
    if (typeof e2 != `string`) throw TypeError(`did:key resolve: input must be a string`);
    if (!e2.startsWith(`did:key:`)) throw Error(`did:key resolve: identifier must start with "did:key:" (got ${JSON.stringify(e2.slice(0, 32))}\u2026)`);
    let t2 = e2.slice(8);
    if (!t2.startsWith(`z`)) throw Error(`did:key resolve: only base58btc (z-prefix) is supported`);
    let { codec: n2, key: r2 } = R(t2);
    if ($t(n2, zt)) return en(r2, 32, `Ed25519`), {
      didDocument: Gt(e2, t2, r2),
      didResolutionMetadata: {
        contentType: `application/did+ld+json`
      },
      didDocumentMetadata: {}
    };
    if ($t(n2, Bt)) return en(r2, 32, `X25519`), {
      didDocument: Kt(e2, t2),
      didResolutionMetadata: {
        contentType: `application/did+ld+json`
      },
      didDocumentMetadata: {}
    };
    if ($t(n2, Vt)) return en(r2, 33, `P-256`), {
      didDocument: qt(e2, t2),
      didResolutionMetadata: {
        contentType: `application/did+ld+json`
      },
      didDocumentMetadata: {}
    };
    if ($t(n2, Ht)) return en(r2, 33, `secp256k1`), {
      didDocument: qt(e2, t2),
      didResolutionMetadata: {
        contentType: `application/did+ld+json`
      },
      didDocumentMetadata: {}
    };
    throw Error(`did:key resolve: unsupported multicodec ${tn(n2)}; supported: Ed25519(0xed01), X25519(0xec01), P-256(0x8024), secp256k1(0xe701)`);
  };
  function Gt(e2, t2, n2) {
    let r2 = `${e2}#${t2}`, i2 = L(Bt, Jt(n2)), a2 = `${e2}#${i2}`;
    return {
      "@context": [
        `https://www.w3.org/ns/did/v1`,
        `https://w3id.org/security/multikey/v1`
      ],
      id: e2,
      verificationMethod: [
        {
          id: r2,
          type: `Multikey`,
          controller: e2,
          publicKeyMultibase: t2
        },
        {
          id: a2,
          type: `Multikey`,
          controller: e2,
          publicKeyMultibase: i2
        }
      ],
      authentication: [
        r2
      ],
      assertionMethod: [
        r2
      ],
      capabilityDelegation: [
        r2
      ],
      capabilityInvocation: [
        r2
      ],
      keyAgreement: [
        a2
      ]
    };
  }
  function Kt(e2, t2) {
    let n2 = `${e2}#${t2}`;
    return {
      "@context": [
        `https://www.w3.org/ns/did/v1`,
        `https://w3id.org/security/multikey/v1`
      ],
      id: e2,
      verificationMethod: [
        {
          id: n2,
          type: `Multikey`,
          controller: e2,
          publicKeyMultibase: t2
        }
      ],
      keyAgreement: [
        n2
      ]
    };
  }
  function qt(e2, t2) {
    let n2 = `${e2}#${t2}`;
    return {
      "@context": [
        `https://www.w3.org/ns/did/v1`,
        `https://w3id.org/security/multikey/v1`
      ],
      id: e2,
      verificationMethod: [
        {
          id: n2,
          type: `Multikey`,
          controller: e2,
          publicKeyMultibase: t2
        }
      ],
      authentication: [
        n2
      ],
      assertionMethod: [
        n2
      ],
      capabilityDelegation: [
        n2
      ],
      capabilityInvocation: [
        n2
      ]
    };
  }
  function Jt(e2) {
    if (!(e2 instanceof Uint8Array) || e2.length !== 32) throw TypeError(`ed25519PublicKeyToX25519: input must be 32 bytes`);
    let t2 = new Uint8Array(e2);
    t2[31] &= 127;
    let n2 = Yt(t2), r2 = Ut, i2 = 1n, a2 = (i2 + n2) % r2, o2 = (i2 - n2) % r2;
    return Xt(a2 * Zt(o2 < 0n ? o2 + r2 : o2, r2) % r2);
  }
  function Yt(e2) {
    let t2 = 0n;
    for (let n2 = e2.length - 1; n2 >= 0; n2--) t2 = t2 << 8n | BigInt(e2[n2]);
    return t2;
  }
  function Xt(e2) {
    let t2 = new Uint8Array(32);
    for (let n2 = 0; n2 < 32; n2++) t2[n2] = Number(e2 & 255n), e2 >>= 8n;
    return t2;
  }
  function Zt(e2, t2) {
    return Qt(e2, t2 - 2n, t2);
  }
  function Qt(e2, t2, n2) {
    let r2 = 1n;
    e2 %= n2, e2 < 0n && (e2 += n2);
    let i2 = t2;
    for (; i2 > 0n; ) i2 & 1n && (r2 = r2 * e2 % n2), i2 >>= 1n, e2 = e2 * e2 % n2;
    return r2;
  }
  function $t(e2, t2) {
    if (e2.length !== t2.length) return false;
    for (let n2 = 0; n2 < e2.length; n2++) if (e2[n2] !== t2[n2]) return false;
    return true;
  }
  function en(e2, t2, n2) {
    if (e2.length !== t2) throw Error(`did:key resolve: ${n2} key must be ${t2} bytes, got ${e2.length}`);
  }
  function tn(e2) {
    return `0x` + Array.from(e2).map((e3) => e3.toString(16).padStart(2, `0`)).join(``);
  }
  let nn, rn, an, on, sn;
  nn = (function() {
    let e2 = typeof document < `u` && document.createElement(`link`).relList;
    return e2 && e2.supports && e2.supports(`modulepreload`) ? `modulepreload` : `preload`;
  })();
  rn = function(e2) {
    return `/` + e2;
  };
  an = {};
  on = function(e2) {
    return e2.pathname.endsWith(`.css`);
  };
  sn = function(e2, t2, n2) {
    if (t2 in e2) return e2[t2];
    let r2 = n2();
    if (!r2) {
      e2[t2] = void 0;
      return;
    }
    let i2 = r2.then(() => {
      e2[t2] = void 0;
    }, (n3) => {
      throw e2[t2] = void 0, n3;
    });
    return e2[t2] = i2, i2;
  };
  cn = function(e2, t2, n2) {
    let r2 = Promise.resolve();
    if (t2 && t2.length > 0) {
      let o2 = function(e4) {
        return Promise.all(e4.map((e5) => Promise.resolve(e5).then((e6) => ({
          status: `fulfilled`,
          value: e6
        }), (e6) => ({
          status: `rejected`,
          reason: e6
        }))));
      }, s2 = function(e4) {
        return import.meta.resolve ? new URL(import.meta.resolve(e4)) : new URL(e4, import.meta.url);
      };
      let e3, i3 = document.querySelector(`meta[property=csp-nonce]`), a2 = i3?.nonce || i3?.getAttribute(`nonce`);
      r2 = o2(t2.map((t3) => {
        t3 = rn(t3, n2);
        let r3 = s2(t3), i4 = on(r3);
        return sn(an, r3.href, () => {
          if (e3 === void 0) {
            e3 = {
              all: /* @__PURE__ */ new Set(),
              styles: /* @__PURE__ */ new Set()
            };
            let t5 = document.getElementsByTagName(`link`);
            for (let n3 = t5.length - 1; n3 >= 0; n3--) {
              let r4 = t5[n3];
              e3.all.add(r4.href), r4.rel === `stylesheet` && e3.styles.add(r4.href);
            }
          }
          if ((i4 ? e3.styles : e3.all).has(r3.href)) return;
          let t4 = document.createElement(`link`);
          if (t4.rel = i4 ? `stylesheet` : nn, i4 || (t4.as = `script`), t4.crossOrigin = ``, t4.href = r3.href, a2 && t4.setAttribute(`nonce`, a2), document.head.appendChild(t4), i4) return new Promise((e4, n3) => {
            t4.addEventListener(`load`, e4), t4.addEventListener(`error`, () => n3(Error(`Unable to preload CSS for ${r3}`)));
          });
        });
      }).filter((e4) => e4 !== void 0));
    }
    function i2(e3) {
      let t3 = new Event(`vite:preloadError`, {
        cancelable: true
      });
      if (t3.payload = e3, window.dispatchEvent(t3), !t3.defaultPrevented) throw e3;
    }
    return r2.then((t3) => {
      for (let e3 of t3 || []) e3.status === `rejected` && i2(e3.reason);
      return e2().catch(i2);
    });
  };
  ((e2) => typeof n < `u` ? n : typeof Proxy < `u` ? new Proxy(e2, {
    get: (e3, t2) => (typeof n < `u` ? n : e3)[t2]
  }) : e2)(function(e2) {
    if (typeof n < `u`) return n.apply(this, arguments);
    throw Error(`Dynamic require of "` + e2 + `" is not supported`);
  });
  var ln = (e2) => Array.from(e2).map((e3) => e3.toString(16).padStart(2, `0`)).join(``), un = (e2, t2) => {
    if (!hn.isBrowser) return Buffer.from(e2, t2);
    if (t2 === `base64`) {
      let t3 = atob(e2);
      return new Uint8Array(t3.length).map((e3, n2) => t3.charCodeAt(n2));
    }
    return new TextEncoder().encode(e2);
  }, dn = (e2, t2) => {
    if (!hn.isBrowser) return Buffer.from(e2).toString(t2);
    if (t2 === `hex`) return ln(e2);
    if (t2 === `base64`) {
      let t3 = String.fromCharCode(...e2);
      return btoa(t3);
    }
    return new TextDecoder().decode(e2);
  }, fn = (...e2) => {
    if (!hn.isBrowser) return Buffer.concat(e2);
    let t2 = e2.reduce((e3, t3) => e3 + t3.length, 0), n2 = new Uint8Array(t2), r2 = 0;
    for (let t3 of e2) n2.set(t3, r2), r2 += t3.length;
    return n2;
  }, pn = typeof window < `u`, mn = (e2) => {
    if (!pn) try {
      return {}[e2];
    } catch {
      return;
    }
  }, hn = {
    getEnvValue: mn,
    isBrowser: pn,
    isTestEnvironment: mn(`NODE_ENV`) === `test`,
    logResolves: mn(`LOG_RESOLVES`) === `true`,
    getVerificationMethods: () => {
      let e2 = mn(`DID_VERIFICATION_METHODS`);
      if (!e2) return [];
      try {
        let t2 = un(e2, `base64`);
        return JSON.parse(dn(t2));
      } catch {
        return [];
      }
    }
  }, G = `{SCID}`, gn = `webvh`, _n = `did:webvh:1.0`, K = {
    scid: `scid`,
    method: `method`,
    portable: `portable`,
    updateKeys: `updateKeys`,
    nextKeyHashes: `nextKeyHashes`,
    witness: `witness`,
    watchers: `watchers`,
    ttl: `ttl`
  }, vn = `relativeRef`, yn = `LinkedVerifiablePresentation`, bn = `https://identity.foundation/linked-vp/contexts/v1`, xn = `https://w3id.org/security#INVALID_CONTROLLED_IDENTIFIER_DOCUMENT_ID`, Sn = `https://w3id.org/security#NOT_FOUND`, Cn;
  ((e2) => {
    e2.NotFound = `notFound`, e2.InvalidDid = `invalidDid`, e2.LegacyNotFound = `NOT_FOUND`, e2.LegacyInvalidDid = `INVALID_DID`, e2.InvalidDidUrl = `INVALID_DID_URL`, e2.InvalidOptions = `INVALID_OPTIONS`, e2.RepresentationNotSupported = `REPRESENTATION_NOT_SUPPORTED`, e2.MethodNotSupported = `METHOD_NOT_SUPPORTED`, e2.UnsupportedPublicKeyType = `UNSUPPORTED_PUBLIC_KEY_TYPE`, e2.LegacyInvalidDidDocument = `INVALID_DID_DOCUMENT`, e2.InvalidPublicKey = `INVALID_PUBLIC_KEY`, e2.InvalidPublicKeyLength = `INVALID_PUBLIC_KEY_LENGTH`, e2.InvalidPublicKeyType = `INVALID_PUBLIC_KEY_TYPE`, e2.InternalError = `INTERNAL_ERROR`;
  })(Cn ||= {});
  var wn = `$`;
  function Tn(e2, t2) {
    var n2 = ``, r2 = t2 && t2.include, i2 = t2 && t2.exclude;
    i2 && typeof i2 == `string` && (i2 = [
      i2
    ]), r2 && r2.sort();
    var a2 = /* @__PURE__ */ new WeakMap(), o2 = t2 && t2.allowCircular, s2 = t2 && t2.filterUndefined, c2 = t2 && t2.undefinedInArrayToNull;
    return l2(e2, wn), n2;
    function l2(e3, t3) {
      if (typeof e3 != `object` || !e3 || e3.toJSON != null) n2 += JSON.stringify(e3);
      else if (Array.isArray(e3)) {
        var u2 = a2.get(e3);
        if (u2 !== void 0 && t3.startsWith(u2)) {
          if (!o2) throw Error(`Circular reference detected`);
          n2 += `"[Circular:` + u2 + `]"`;
          return;
        }
        a2.set(e3, t3), n2 += `[`;
        var d2 = false;
        e3.forEach(function(e4, r3) {
          d2 && (n2 += `,`), d2 = true, c2 && e4 === void 0 && (e4 = null), l2(e4, t3 + `[` + r3 + `]`);
        }), n2 += `]`;
      } else {
        var u2 = a2.get(e3);
        if (u2 !== void 0 && t3.startsWith(u2)) {
          if (!o2) throw Error(`Circular reference detected`);
          n2 += `"[Circular:` + u2 + `]"`;
          return;
        }
        a2.set(e3, t3), n2 += `{`;
        var f2 = false, p2 = function(r3) {
          i2 && i2.includes(r3) || (f2 && (n2 += `,`), f2 = true, n2 += JSON.stringify(r3), n2 += `:`, l2(e3[r3], t3 + `.` + r3));
        };
        if (t3 === wn && r2) r2.forEach(function(t4) {
          e3.hasOwnProperty(t4) && p2(t4);
        });
        else {
          var m2 = Object.keys(e3);
          s2 && (m2 = m2.filter(function(t4) {
            return e3[t4] !== void 0;
          })), m2.sort(), m2.forEach(function(e4) {
            p2(e4);
          });
        }
        n2 += `}`;
      }
    }
  }
  function En(e2, t2) {
    return Tn(e2, t2);
  }
  var Dn = (e2, t2) => {
    if (e2 === null) return null;
    let n2 = typeof e2;
    if (n2 === `undefined`) throw Error(`Canonicalization input contains undefined in array position`);
    if (n2 === `function` || n2 === `symbol` || n2 === `bigint`) throw Error(`Canonicalization input contains unsupported type: ${n2}`);
    if (n2 === `number` && !Number.isFinite(e2)) throw Error(`Canonicalization input contains non-finite number`);
    if (n2 !== `object`) return e2;
    let r2 = e2;
    if (t2.has(r2)) throw Error(`Canonicalization input contains circular references`);
    if (Array.isArray(r2)) {
      let e3 = [];
      t2.set(r2, e3);
      for (let n3 of r2) e3.push(Dn(n3, t2));
      return e3;
    }
    let i2 = {};
    t2.set(r2, i2);
    for (let [e3, n3] of Object.entries(r2)) typeof n3 < `u` && (i2[e3] = Dn(n3, t2));
    return i2;
  }, On = (e2, t2) => {
    if (e2 === null) return;
    let n2 = typeof e2;
    if (n2 === `undefined`) throw Error(`Canonicalization input contains undefined`);
    if (n2 === `function` || n2 === `symbol` || n2 === `bigint`) throw Error(`Canonicalization input contains unsupported type: ${n2}`);
    if (n2 === `number` && !Number.isFinite(e2)) throw Error(`Canonicalization input contains non-finite number`);
    if (n2 !== `object`) return;
    let r2 = e2;
    if (t2.has(r2)) throw Error(`Canonicalization input contains circular references`);
    if (t2.add(r2), Array.isArray(r2)) {
      for (let e3 of r2) On(e3, t2);
      return;
    }
    for (let e3 of Object.values(r2)) On(e3, t2);
  };
  function kn(e2) {
    On(e2, /* @__PURE__ */ new WeakSet());
  }
  var An = (e2) => {
    let t2 = Dn(e2, /* @__PURE__ */ new WeakMap());
    return kn(t2), En(t2, {
      allowCircular: false,
      filterUndefined: true,
      undefinedInArrayToNull: false
    });
  };
  function jn(e2) {
    return e2 instanceof Uint8Array || ArrayBuffer.isView(e2) && e2.constructor.name === `Uint8Array` && `BYTES_PER_ELEMENT` in e2 && e2.BYTES_PER_ELEMENT === 1;
  }
  function Mn(e2, t2, n2 = ``) {
    let r2 = jn(e2), i2 = e2?.length, a2 = t2 !== void 0;
    if (!r2 || a2 && i2 !== t2) {
      let o2 = n2 && `"${n2}" `, s2 = a2 ? ` of length ${t2}` : ``, c2 = r2 ? `length=${i2}` : `type=${typeof e2}`, l2 = o2 + `expected Uint8Array` + s2 + `, got ` + c2;
      throw r2 ? RangeError(l2) : TypeError(l2);
    }
    return e2;
  }
  function Nn(e2, t2 = true) {
    if (e2.destroyed) throw Error(`Hash instance has been destroyed`);
    if (t2 && e2.finished) throw Error(`Hash#digest() has already been called`);
  }
  function Pn(e2, t2) {
    Mn(e2, void 0, `digestInto() output`);
    let n2 = t2.outputLen;
    if (e2.length < n2) throw RangeError(`"digestInto() output" expected to be of length >=` + n2);
  }
  function Fn(...e2) {
    for (let t2 = 0; t2 < e2.length; t2++) e2[t2].fill(0);
  }
  function In(e2) {
    return new DataView(e2.buffer, e2.byteOffset, e2.byteLength);
  }
  function q(e2, t2) {
    return e2 << 32 - t2 | e2 >>> t2;
  }
  function Ln(e2, t2 = {}) {
    let n2 = (t3, n3) => e2(n3).update(t3).digest(), r2 = e2(void 0);
    return n2.outputLen = r2.outputLen, n2.blockLen = r2.blockLen, n2.canXOF = r2.canXOF, n2.create = (t3) => e2(t3), Object.assign(n2, t2), Object.freeze(n2);
  }
  var Rn = (e2) => ({
    oid: Uint8Array.from([
      6,
      9,
      96,
      134,
      72,
      1,
      101,
      3,
      4,
      2,
      e2
    ])
  });
  function zn(e2, t2, n2) {
    return e2 & t2 ^ ~e2 & n2;
  }
  function Bn(e2, t2, n2) {
    return e2 & t2 ^ e2 & n2 ^ t2 & n2;
  }
  var Vn = class {
    blockLen;
    outputLen;
    canXOF = false;
    padOffset;
    isLE;
    buffer;
    view;
    finished = false;
    length = 0;
    pos = 0;
    destroyed = false;
    constructor(e2, t2, n2, r2) {
      this.blockLen = e2, this.outputLen = t2, this.padOffset = n2, this.isLE = r2, this.buffer = new Uint8Array(e2), this.view = In(this.buffer);
    }
    update(e2) {
      Nn(this), Mn(e2);
      let { view: t2, buffer: n2, blockLen: r2 } = this, i2 = e2.length;
      for (let a2 = 0; a2 < i2; ) {
        let o2 = Math.min(r2 - this.pos, i2 - a2);
        if (o2 === r2) {
          let t3 = In(e2);
          for (; r2 <= i2 - a2; a2 += r2) this.process(t3, a2);
          continue;
        }
        n2.set(e2.subarray(a2, a2 + o2), this.pos), this.pos += o2, a2 += o2, this.pos === r2 && (this.process(t2, 0), this.pos = 0);
      }
      return this.length += e2.length, this.roundClean(), this;
    }
    digestInto(e2) {
      Nn(this), Pn(e2, this), this.finished = true;
      let { buffer: t2, view: n2, blockLen: r2, isLE: i2 } = this, { pos: a2 } = this;
      t2[a2++] = 128, Fn(this.buffer.subarray(a2)), this.padOffset > r2 - a2 && (this.process(n2, 0), a2 = 0);
      for (let e3 = a2; e3 < r2; e3++) t2[e3] = 0;
      n2.setBigUint64(r2 - 8, BigInt(this.length * 8), i2), this.process(n2, 0);
      let o2 = In(e2), s2 = this.outputLen;
      if (s2 % 4) throw Error(`_sha2: outputLen must be aligned to 32bit`);
      let c2 = s2 / 4, l2 = this.get();
      if (c2 > l2.length) throw Error(`_sha2: outputLen bigger than state`);
      for (let e3 = 0; e3 < c2; e3++) o2.setUint32(4 * e3, l2[e3], i2);
    }
    digest() {
      let { buffer: e2, outputLen: t2 } = this;
      this.digestInto(e2);
      let n2 = e2.slice(0, t2);
      return this.destroy(), n2;
    }
    _cloneInto(e2) {
      e2 ||= new this.constructor(), e2.set(...this.get());
      let { blockLen: t2, buffer: n2, length: r2, finished: i2, destroyed: a2, pos: o2 } = this;
      return e2.destroyed = a2, e2.finished = i2, e2.length = r2, e2.pos = o2, r2 % t2 && e2.buffer.set(n2), e2;
    }
    clone() {
      return this._cloneInto();
    }
  }, J = Uint32Array.from([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]);
  Uint32Array.from([
    3238371032,
    914150663,
    812702999,
    4144912697,
    4290775857,
    1750603025,
    1694076839,
    3204075428
  ]), Uint32Array.from([
    3418070365,
    3238371032,
    1654270250,
    914150663,
    2438529370,
    812702999,
    355462360,
    4144912697,
    1731405415,
    4290775857,
    2394180231,
    1750603025,
    3675008525,
    1694076839,
    1203062813,
    3204075428
  ]), Uint32Array.from([
    1779033703,
    4089235720,
    3144134277,
    2227873595,
    1013904242,
    4271175723,
    2773480762,
    1595750129,
    1359893119,
    2917565137,
    2600822924,
    725511199,
    528734635,
    4215389547,
    1541459225,
    327033209
  ]);
  var Hn = BigInt(4294967295), Un = BigInt(32);
  function Wn(e2, t2 = false) {
    return t2 ? {
      h: Number(e2 & Hn),
      l: Number(e2 >> Un & Hn)
    } : {
      h: Number(e2 >> Un & Hn) | 0,
      l: Number(e2 & Hn) | 0
    };
  }
  function Gn(e2, t2 = false) {
    let n2 = e2.length, r2 = new Uint32Array(n2), i2 = new Uint32Array(n2);
    for (let a2 = 0; a2 < n2; a2++) {
      let { h: n3, l: o2 } = Wn(e2[a2], t2);
      [r2[a2], i2[a2]] = [
        n3,
        o2
      ];
    }
    return [
      r2,
      i2
    ];
  }
  var Kn = Uint32Array.from([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]), Y = new Uint32Array(64), qn = class extends Vn {
    constructor(e2) {
      super(64, e2, 8, false);
    }
    get() {
      let { A: e2, B: t2, C: n2, D: r2, E: i2, F: a2, G: o2, H: s2 } = this;
      return [
        e2,
        t2,
        n2,
        r2,
        i2,
        a2,
        o2,
        s2
      ];
    }
    set(e2, t2, n2, r2, i2, a2, o2, s2) {
      this.A = e2 | 0, this.B = t2 | 0, this.C = n2 | 0, this.D = r2 | 0, this.E = i2 | 0, this.F = a2 | 0, this.G = o2 | 0, this.H = s2 | 0;
    }
    process(e2, t2) {
      for (let n3 = 0; n3 < 16; n3++, t2 += 4) Y[n3] = e2.getUint32(t2, false);
      for (let e3 = 16; e3 < 64; e3++) {
        let t3 = Y[e3 - 15], n3 = Y[e3 - 2], r3 = q(t3, 7) ^ q(t3, 18) ^ t3 >>> 3, i3 = q(n3, 17) ^ q(n3, 19) ^ n3 >>> 10;
        Y[e3] = i3 + Y[e3 - 7] + r3 + Y[e3 - 16] | 0;
      }
      let { A: n2, B: r2, C: i2, D: a2, E: o2, F: s2, G: c2, H: l2 } = this;
      for (let e3 = 0; e3 < 64; e3++) {
        let t3 = q(o2, 6) ^ q(o2, 11) ^ q(o2, 25), u2 = l2 + t3 + zn(o2, s2, c2) + Kn[e3] + Y[e3] | 0, d2 = (q(n2, 2) ^ q(n2, 13) ^ q(n2, 22)) + Bn(n2, r2, i2) | 0;
        l2 = c2, c2 = s2, s2 = o2, o2 = a2 + u2 | 0, a2 = i2, i2 = r2, r2 = n2, n2 = u2 + d2 | 0;
      }
      n2 = n2 + this.A | 0, r2 = r2 + this.B | 0, i2 = i2 + this.C | 0, a2 = a2 + this.D | 0, o2 = o2 + this.E | 0, s2 = s2 + this.F | 0, c2 = c2 + this.G | 0, l2 = l2 + this.H | 0, this.set(n2, r2, i2, a2, o2, s2, c2, l2);
    }
    roundClean() {
      Fn(Y);
    }
    destroy() {
      this.destroyed = true, this.set(0, 0, 0, 0, 0, 0, 0, 0), Fn(this.buffer);
    }
  }, Jn = class extends qn {
    A = J[0] | 0;
    B = J[1] | 0;
    C = J[2] | 0;
    D = J[3] | 0;
    E = J[4] | 0;
    F = J[5] | 0;
    G = J[6] | 0;
    H = J[7] | 0;
    constructor() {
      super(32);
    }
  }, Yn = Gn(`0x428a2f98d728ae22.0x7137449123ef65cd.0xb5c0fbcfec4d3b2f.0xe9b5dba58189dbbc.0x3956c25bf348b538.0x59f111f1b605d019.0x923f82a4af194f9b.0xab1c5ed5da6d8118.0xd807aa98a3030242.0x12835b0145706fbe.0x243185be4ee4b28c.0x550c7dc3d5ffb4e2.0x72be5d74f27b896f.0x80deb1fe3b1696b1.0x9bdc06a725c71235.0xc19bf174cf692694.0xe49b69c19ef14ad2.0xefbe4786384f25e3.0x0fc19dc68b8cd5b5.0x240ca1cc77ac9c65.0x2de92c6f592b0275.0x4a7484aa6ea6e483.0x5cb0a9dcbd41fbd4.0x76f988da831153b5.0x983e5152ee66dfab.0xa831c66d2db43210.0xb00327c898fb213f.0xbf597fc7beef0ee4.0xc6e00bf33da88fc2.0xd5a79147930aa725.0x06ca6351e003826f.0x142929670a0e6e70.0x27b70a8546d22ffc.0x2e1b21385c26c926.0x4d2c6dfc5ac42aed.0x53380d139d95b3df.0x650a73548baf63de.0x766a0abb3c77b2a8.0x81c2c92e47edaee6.0x92722c851482353b.0xa2bfe8a14cf10364.0xa81a664bbc423001.0xc24b8b70d0f89791.0xc76c51a30654be30.0xd192e819d6ef5218.0xd69906245565a910.0xf40e35855771202a.0x106aa07032bbd1b8.0x19a4c116b8d2d0c8.0x1e376c085141ab53.0x2748774cdf8eeb99.0x34b0bcb5e19b48a8.0x391c0cb3c5c95a63.0x4ed8aa4ae3418acb.0x5b9cca4f7763e373.0x682e6ff3d6b2b8a3.0x748f82ee5defb2fc.0x78a5636f43172f60.0x84c87814a1f0ab72.0x8cc702081a6439ec.0x90befffa23631e28.0xa4506cebde82bde9.0xbef9a3f7b2c67915.0xc67178f2e372532b.0xca273eceea26619c.0xd186b8c721c0c207.0xeada7dd6cde0eb1e.0xf57d4f7fee6ed178.0x06f067aa72176fba.0x0a637dc5a2c898a6.0x113f9804bef90dae.0x1b710b35131c471b.0x28db77f523047d84.0x32caab7b40c72493.0x3c9ebe0a15c9bebc.0x431d67c49c100d4c.0x4cc5d4becb3e42b6.0x597f299cfc657e2a.0x5fcb6fab3ad6faec.0x6c44198c4a475817`.split(`.`).map((e2) => BigInt(e2)));
  Yn[0], Yn[1], Uint32Array.from([
    2352822216,
    424955298,
    1944164710,
    2312950998,
    502970286,
    855612546,
    1738396948,
    1479516111,
    258812777,
    2077511080,
    2011393907,
    79989058,
    1067287976,
    1780299464,
    286451373,
    2446758561
  ]), Uint32Array.from([
    573645204,
    4230739756,
    2673172387,
    3360449730,
    596883563,
    1867755857,
    2520282905,
    1497426621,
    2519219938,
    2827943907,
    3193839141,
    1401305490,
    721525244,
    746961066,
    246885852,
    2177182882
  ]);
  var Xn = Ln(() => new Jn(), Rn(1)), Zn = new TextEncoder();
  async function Qn(e2) {
    return Xn(Zn.encode(e2));
  }
  var $n;
  ((e2) => {
    e2.BASE64URL_NO_PAD = `u`, e2.BASE58_BTC = `z`;
  })($n ||= {});
  var er = {
    u: `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_`,
    z: `123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz`
  };
  function tr(e2) {
    let t2 = e2.length % 4 == 0 ? 0 : 4 - e2.length % 4, n2 = e2.replace(/-/g, `+`).replace(/_/g, `/`) + `=`.repeat(t2), r2 = atob(n2), i2 = new Uint8Array(r2.length);
    for (let e3 = 0; e3 < r2.length; e3++) i2[e3] = r2.charCodeAt(e3);
    return i2;
  }
  function nr(e2) {
    let t2 = er.z, n2 = 0;
    for (let t3 = 0; t3 < e2.length && e2[t3] === 0; t3++) n2++;
    let r2 = 0n;
    for (let t3 = 0; t3 < e2.length; t3++) r2 = r2 * 256n + BigInt(e2[t3]);
    let i2 = ``;
    for (; r2 > 0n; ) {
      let e3 = Number(r2 % 58n);
      r2 /= 58n, i2 = t2[e3] + i2;
    }
    return `1`.repeat(n2) + i2;
  }
  function rr(e2) {
    let t2 = er.z, n2 = 0;
    for (let t3 = 0; t3 < e2.length && e2[t3] === `1`; t3++) n2++;
    let r2 = 0n;
    for (let i3 = n2; i3 < e2.length; i3++) {
      let n3 = e2[i3], a2 = t2.indexOf(n3);
      if (a2 === -1) throw Error(`Invalid Base58 character: ${n3}`);
      r2 = r2 * 58n + BigInt(a2);
    }
    let i2 = [];
    for (; r2 > 0n; ) i2.unshift(Number(r2 % 256n)), r2 /= 256n;
    return new Uint8Array([
      ...Array(n2).fill(0),
      ...i2
    ]);
  }
  function ir(e2) {
    if (!e2 || e2.length < 2) throw Error(`Invalid multibase string: too short`);
    let t2 = e2[0], n2 = e2.slice(1), r2;
    switch (t2) {
      case `u`:
        r2 = tr(n2);
        break;
      case `z`:
        r2 = rr(n2);
        break;
      default:
        throw Error(`Unsupported multibase encoding prefix: ${t2}`);
    }
    return {
      bytes: r2,
      encoding: t2
    };
  }
  var ar;
  ((e2) => {
    e2[e2.SHA2_256 = 18] = `SHA2_256`, e2[e2.SHA2_384 = 32] = `SHA2_384`, e2[e2.SHA3_256 = 22] = `SHA3_256`, e2[e2.SHA3_384 = 21] = `SHA3_384`;
  })(ar ||= {});
  var or = {
    18: 32,
    32: 48,
    22: 32,
    21: 48
  };
  function sr(e2) {
    let t2 = [];
    for (; e2 >= 128; ) t2.push(e2 & 127 | 128), e2 >>>= 7;
    return t2.push(e2 & 127), new Uint8Array(t2);
  }
  function cr(e2, t2 = 0) {
    let n2 = 0, r2 = 0, i2 = 0, a2 = 0;
    do {
      if (t2 + i2 >= e2.length) throw Error(`Invalid varint: buffer too short`);
      a2 = e2[t2 + i2], n2 |= (a2 & 127) << r2, r2 += 7, i2++;
    } while (a2 & 128);
    return {
      value: n2,
      bytesRead: i2
    };
  }
  function lr(e2, t2) {
    let n2 = or[t2];
    if (e2.length !== n2) throw Error(`Invalid digest length for algorithm ${t2.toString(16)}: expected ${n2}, got ${e2.length}`);
    let r2 = sr(t2), i2 = sr(e2.length), a2 = new Uint8Array(r2.length + i2.length + e2.length);
    return a2.set(r2, 0), a2.set(i2, r2.length), a2.set(e2, r2.length + i2.length), a2;
  }
  function ur(e2) {
    if (e2.length < 2) throw Error(`Invalid multihash: too short`);
    let { value: t2, bytesRead: n2 } = cr(e2, 0), { value: r2, bytesRead: i2 } = cr(e2, n2), a2 = n2 + i2;
    if (e2.length - a2 < r2) throw Error(`Invalid multihash: digest too short, expected ${r2} bytes`);
    let o2 = e2.slice(a2, a2 + r2);
    if (!Object.values(ar).includes(t2)) throw Error(`Unsupported multihash algorithm: 0x${t2.toString(16)}`);
    let s2 = or[t2];
    if (r2 !== s2) throw Error(`Invalid digest length for algorithm 0x${t2.toString(16)}: expected ${s2}, got ${r2}`);
    return {
      algorithm: t2,
      digestLength: r2,
      digest: o2
    };
  }
  function dr(e2) {
    if (!e2.witnesses || !Array.isArray(e2.witnesses) || e2.witnesses.length === 0) throw Error(`Witness list cannot be empty`);
    if (!e2.threshold || parseInt(e2.threshold.toString(), 10) < 1 || parseInt(e2.threshold.toString(), 10) > e2.witnesses.length) throw Error(`Witness threshold must be between 1 and the number of witnesses`);
    let t2 = /* @__PURE__ */ new Set();
    for (let n2 of e2.witnesses) {
      let e3 = (() => {
        try {
          return Lr(n2.id);
        } catch {
          throw Error(`Witness DIDs must be did:key format`);
        }
      })(), r2 = ir(e3.keyMultibase).bytes;
      if (r2.length < 2 || r2[0] !== 237 || r2[1] !== 1) throw Error(`Witness DID key type must be Ed25519 (multicodec 0xed01): ${n2.id}`);
      if (t2.has(e3.did)) throw Error(`Duplicate witness id: ${n2.id}`);
      t2.add(e3.did);
    }
  }
  async function fr(e2, t2, n2, r2) {
    if (!r2) throw Error(`Verifier implementation is required`);
    let i2 = 0, a2 = /* @__PURE__ */ new Set(), o2 = new Map((n2.witnesses ?? []).map((e3) => [
      Lr(e3.id).did,
      e3
    ]));
    for (let e3 of t2) for (let t3 of e3.proof) try {
      if (t3.type !== `DataIntegrityProof`) throw Error(`Invalid witness proof type`);
      if (t3.proofPurpose !== `assertionMethod`) throw Error(`Invalid witness proof purpose`);
      if (t3.cryptosuite !== `eddsa-jcs-2022`) throw Error(`Invalid witness proof cryptosuite`);
      let n3 = Rr(t3.verificationMethod), s2 = o2.get(n3.did);
      if (!s2 || a2.has(s2.id)) continue;
      let c2 = await hi(t3.verificationMethod);
      if (!c2?.publicKeyMultibase) throw Error(`Verification Method ${t3.verificationMethod} not found`);
      let l2 = ir(c2.publicKeyMultibase).bytes;
      if (l2.length !== 34) throw Error(`Invalid public key length ${l2.length} (should be 34 bytes)`);
      let { proofValue: u2, ...d2 } = t3, f2 = An({
        versionId: e3.versionId
      }), p2 = An(d2), m2 = await Qn(f2), h2 = fn(await Qn(p2), m2), g2 = ir(u2).bytes;
      if (!await r2.verify(g2, h2, l2.slice(2))) throw Error(`Invalid witness proof signature`);
      i2++, a2.add(s2.id);
    } catch (n3) {
      let r3 = n3 instanceof Error ? n3.message : String(n3);
      console.warn(`Ignoring invalid witness proof for version ${e3.versionId} (verificationMethod: ${t3.verificationMethod}): ${r3}`);
    }
    return i2;
  }
  var pr = (e2, t2) => {
    let n2 = Rr(e2);
    return t2.some((e3) => e3 === n2.keyMultibase);
  }, mr = async (e2, t2, n2, r2, i2) => {
    if (!i2) throw Error(`Verifier implementation is required`);
    let { proof: a2, ...o2 } = e2;
    if (!a2) throw Error(`Missing proof in DID log entry`);
    Array.isArray(a2) || (a2 = [
      a2
    ]), n2?.witnesses && n2.witnesses.length > 0 && (r2 || dr(n2));
    for (let e3 = 0; e3 < a2.length; e3++) {
      let n3 = a2[e3];
      if (!n3.verificationMethod.startsWith(`did:key:`)) throw Error(`Unsupported verification method for DID log entry authorization: ${n3.verificationMethod}`);
      if (!pr(n3.verificationMethod, t2)) throw Error(`Key ${n3.verificationMethod} is not authorized to update.`);
      if (n3.type !== `DataIntegrityProof`) throw Error(`Unknown proof type ${n3.type}`);
      if (n3.proofPurpose !== `assertionMethod`) throw Error(`Invalid proof purpose '${n3.proofPurpose}' for DID log entry proof. Expected 'assertionMethod'.`);
      if (n3.cryptosuite !== `eddsa-jcs-2022`) throw Error(`Unknown cryptosuite ${n3.cryptosuite}`);
      let r3 = await hi(n3.verificationMethod);
      if (!r3?.publicKeyMultibase) throw Error(`Verification Method ${n3.verificationMethod} not found`);
      let s2 = ir(r3.publicKeyMultibase).bytes;
      if (s2[0] !== 237 || s2[1] !== 1) throw Error(`multiKey doesn't include ed25519 header (0xed01)`);
      let { proofValue: c2, ...l2 } = n3, u2 = ir(c2).bytes, d2 = await Qn(An(o2)), f2 = fn(await Qn(An(l2)), d2);
      if (!await i2.verify(u2, f2, s2.slice(2))) throw Error(`Proof ${e3} failed verification (proofValue: ${c2})`);
    }
    return true;
  }, hr = (e2, t2) => e2 === t2, gr = async (e2, t2) => {
    if (t2.length > 0) for (let n2 of e2) {
      let e3 = await mi(n2);
      if (!t2.includes(e3)) throw Error(`Invalid update key ${e3}. Not found in nextKeyHashes ${t2}`);
    }
    return true;
  }, _r = (e2) => {
    try {
      let { algorithm: t2 } = ur(rr(e2));
      if (t2 !== 18) throw Error(`SCID multihash algorithm must be SHA-256 (0x12), but got 0x${t2.toString(16)}`);
    } catch (e3) {
      throw e3 instanceof Error && e3.message.includes(`SCID multihash algorithm`) ? e3 : Error(`Invalid SCID format: ${e3 instanceof Error ? e3.message : String(e3)}`);
    }
  }, vr = async (e2, t2) => (_r(e2), e2 === await li(t2)), yr = `did:${gn}:0.5`, br = (e2) => {
    if (!e2) throw Error(`DID document id is missing`);
    return e2;
  }, xr = async (e2, t2 = {}) => {
    if (t2.verificationMethod && (t2.versionNumber || t2.versionId)) throw Error(`Cannot specify both verificationMethod and version number/id`);
    let n2 = e2.map((e3) => Z(e3)), r2 = n2[0].parameters.method;
    if (r2 !== yr) throw Error(`'${r2}' protocol unknown.`);
    let i2 = {}, a2 = ``, o2 = {
      versionId: ``,
      created: ``,
      updated: ``,
      previousLogEntryHash: ``,
      scid: ``,
      prerotation: false,
      portable: false,
      nextKeyHashes: [],
      deactivated: false,
      updateKeys: [],
      witness: void 0,
      watchers: null
    }, s2 = ``, c2 = 0, l2 = null, u2 = null, d2 = null, f2 = null;
    try {
      for (; c2 < n2.length; ) {
        let { versionId: e3, versionTime: r3, parameters: p3, state: m3, proof: h2 } = n2[c2], [g2, _2] = e3.split(`-`);
        if (parseInt(g2, 10) !== c2 + 1) throw Error(`version '${g2}' in log doesn't match expected '${c2 + 1}'.`);
        o2.versionId = e3, o2.updated = r3;
        let v2 = m3;
        if (g2 === `1`) {
          o2.created = r3, v2 = m3, s2 = br(v2.id).split(`:`).at(-1) ?? ``, o2.scid = p3.scid, o2.portable = p3.portable ?? o2.portable, o2.updateKeys = p3.updateKeys, o2.nextKeyHashes = p3.nextKeyHashes || [], o2.prerotation = o2.nextKeyHashes.length > 0, o2.witness = p3.witness || o2.witness, o2.watchers = p3.watchers ?? null, o2.nextKeyHashes = p3.nextKeyHashes ?? [];
          let e4 = {
            versionId: G,
            versionTime: o2.created,
            parameters: Q(p3, o2.scid, G),
            state: Q(v2, o2.scid, G)
          }, n3 = await pi(e4);
          if (o2.previousLogEntryHash = n3, !await vr(o2.scid, n3)) throw Error(`SCID '${o2.scid}' not derived from logEntryHash '${n3}'`);
          let i3 = Q(e4, G, o2.scid), a3 = await pi(i3);
          if (!await mr({
            ...i3,
            versionId: `1-${a3}`,
            proof: h2
          }, o2.updateKeys, o2.witness, false, t2.verifier)) throw Error(`version ${o2.versionId} failed verification of the proof.`);
        } else {
          let r4 = br(v2.id).split(`:`).at(-1) ?? ``;
          if (!o2.portable && r4 !== s2) throw Error(`Cannot move DID: portability is disabled`);
          r4 !== s2 && (s2 = r4);
          let i3 = o2.prerotation ? p3.updateKeys : o2.updateKeys;
          if (!await mr(n2[c2], i3, o2.witness, false, t2.verifier)) throw Error(`version ${o2.versionId} failed verification of the proof.`);
          if (!hr(`${c2 + 1}-${_2}`, e3)) throw Error(`Hash chain broken at '${o2.versionId}'`);
          o2.prerotation && await gr(p3.updateKeys ?? [], o2.nextKeyHashes ?? []), p3.updateKeys && (o2.updateKeys = p3.updateKeys), p3.deactivated === true && (o2.deactivated = true), p3.nextKeyHashes ? (o2.nextKeyHashes = p3.nextKeyHashes, o2.prerotation = true) : (o2.nextKeyHashes = [], o2.prerotation = false);
          let a3 = p3;
          `witness` in p3 ? o2.witness = p3.witness : a3.witnesses && (o2.witness = {
            witnesses: a3.witnesses,
            threshold: a3.witnessThreshold || a3.witnesses.length.toString()
          }), `watchers` in p3 && (o2.watchers = p3.watchers ?? null);
        }
        i2 = Z(v2), a2 = br(i2.id), i2.service = Array.isArray(i2.service) ? i2.service : [];
        let y2 = $r(a2);
        if (i2.service.some((e4) => e4.id === `#files`) || i2.service.push({
          id: `#files`,
          type: `relativeRef`,
          serviceEndpoint: y2
        }), i2.service.some((e4) => e4.id === `#whois`) || i2.service.push({
          "@context": `https://identity.foundation/linked-vp/contexts/v1`,
          id: `#whois`,
          type: `LinkedVerifiablePresentation`,
          serviceEndpoint: `${y2}/whois.vp`
        }), t2.verificationMethod && gi(i2, t2.verificationMethod) && (l2 || (l2 = Z(i2), u2 = {
          ...o2
        })), (t2.versionNumber === parseInt(g2, 10) || t2.versionId === o2.versionId) && (l2 || (l2 = Z(i2), u2 = {
          ...o2
        })), t2.versionTime && t2.versionTime > new Date(o2.updated) && (n2[c2 + 1] && t2.versionTime < new Date(n2[c2 + 1].versionTime) ? l2 || (l2 = Z(i2), u2 = {
          ...o2
        }) : n2[c2 + 1] || l2 || (l2 = Z(i2), u2 = {
          ...o2
        })), o2.witness && c2 === n2.length - 1) {
          t2.witnessProofs ||= await _i(a2);
          let e4 = t2.witnessProofs.filter((e5) => e5.versionId === o2.versionId), r4 = await fr(n2[c2], e4, o2.witness, t2.verifier);
          if (r4 < parseInt((o2.witness.threshold ?? 0).toString(), 10)) throw Error(`Witness threshold not met for version ${o2.versionId}: got ${r4}, need ${o2.witness.threshold}`);
        }
        d2 = Z(i2), f2 = {
          ...o2
        }, c2++;
      }
    } catch (e3) {
      if (!l2) throw e3;
    }
    if (!d2 || !f2) throw Error(`DID log is invalid`);
    let p2 = l2 || d2, m2 = u2 || f2;
    return m2.latestVersionId = f2.versionId, m2.witness && (m2.witness.threshold = m2.witness.threshold?.toString() || `0`), {
      did: br(p2.id),
      doc: p2,
      meta: m2
    };
  }, Sr = RegExp(`^(?<year>\\d{4})-(?<month>(?:0[1-9]|1[0-2]))-(?<day>(?:(?<=\\d{4}-(?:01|03|05|07|08|10|12)-)(?:0[1-9]|[12]\\d|3[01])|(?<=\\d{4}-(?:04|06|09|11)-)(?:0[1-9]|[12]\\d|30)|(?<=\\d{4}-02-)(?:0[1-9]|1\\d|2[0-8])|(?<=((?:\\d{2}(?:0[48]|[2468][048]|[13579][26]))|(?:(?:[02468][048]|[13579][26])00))-02-)29))T(?<hour>(?:[01]\\d|2[0-3])):(?<minute>[0-5]\\d):(?<second>[0-5]\\d)(?:\\.(?<millisecond>\\d{1,3}))?(?<timezone>Z|(?:\\+(?:(?:0\\d|1[0-3]):[0-5]\\d|14:00)|-(?:(?:0\\d|1[01]):[0-5]\\d|12:00)))$`);
  function Cr(e2, t2) {
    let n2 = Sr.exec(e2), r2 = new Date(e2);
    if (!n2 || Number.isNaN(r2.getTime())) throw Error(`${t2} must be a valid UTC ISO8601 timestamp`);
    let i2 = n2.groups?.timezone;
    if (i2 && i2 !== `Z` && i2 !== `+00:00`) throw Error(`${t2} must be in UTC (Z or +00:00), found ${i2}`);
    return r2;
  }
  var X = (e2, t2) => Object.hasOwn(e2, t2), wr = 3e5, Tr = (e2) => {
    if (!e2) throw Error(`DID document id is missing`);
    return e2;
  }, Er = (e2, t2) => {
    let n2 = e2.indexOf(`-`), r2 = e2.lastIndexOf(`-`);
    if (n2 === -1 || n2 !== r2) throw Error(`versionId '${e2}' must contain exactly one '-' separator`);
    let i2 = e2.slice(0, n2), a2 = e2.slice(n2 + 1);
    if (!/^\d+$/.test(i2)) throw Error(`versionId '${e2}' must have a numeric version prefix`);
    if (a2.length === 0) throw Error(`versionId '${e2}' must have a non-empty hash component`);
    let o2 = Number(i2);
    if (o2 !== t2) throw Error(`version '${i2}' in log doesn't match expected '${t2}'.`);
    return {
      version: i2,
      versionNumber: o2,
      entryHash: a2
    };
  }, Dr = async (e2, t2 = {}) => {
    if (t2.verificationMethod && (t2.versionNumber || t2.versionId)) throw Error(`Cannot specify both verificationMethod and version number/id`);
    let n2 = e2.map((e3) => Z(e3));
    if (n2.length === 0) throw Error(`Log identity binding check failed: no entries to process`);
    let r2 = n2[0]?.parameters?.method;
    if (r2 !== _n) throw Error(`'${r2}' is not a supported method version.`);
    let i2 = ``, a2 = null, o2 = null, s2 = null, c2 = null, l2 = null, u2 = {
      versionId: ``,
      created: ``,
      updated: ``,
      deactivated: false,
      portable: false,
      scid: ``,
      updateKeys: [],
      nextKeyHashes: [],
      prerotation: false,
      witness: void 0,
      watchers: null
    }, d2 = null, f2 = null, p2 = 0, m2 = t2.versionNumber !== void 0 || t2.versionId !== void 0 || t2.versionTime !== void 0 || t2.verificationMethod !== void 0, h2 = 0, g2 = ``, _2, v2 = _n, y2 = [], b2 = false;
    try {
      for (; p2 < n2.length; ) {
        let { versionId: e3, versionTime: r3, parameters: m3, state: b3, proof: x2 } = n2[p2], { version: S2, versionNumber: C2, entryHash: w2 } = Er(e3, p2 + 1), ee2 = u2.witness ? Z(u2.witness) : void 0;
        if (u2.versionId = e3, !r3) throw Error(`version '${S2}' is missing versionTime`);
        let te2 = Cr(r3, `version '${S2}' versionTime`);
        if (_2 && te2.getTime() <= _2.getTime()) throw Error(`versionTime for version '${S2}' must be greater than previous entry time`);
        let ne2 = Date.now() + wr;
        if (te2.getTime() > ne2) throw Error(`versionTime for version '${S2}' must not be more than 5 minutes in the future`);
        _2 = te2, u2.updated = r3;
        let T2 = b3, E2 = Zr(Tr(T2.id), `version '${S2}' state.id`);
        if (S2 === `1`) {
          if (u2.created = r3, T2 = b3, g2 = E2.locationKey, u2.scid = m3.scid, t2.scid && t2.scid !== u2.scid) throw Error(`SCID in DID '${t2.scid}' does not match SCID in log '${u2.scid}'`);
          u2.portable = m3.portable ?? u2.portable, u2.updateKeys = m3.updateKeys, u2.nextKeyHashes = m3.nextKeyHashes || [], u2.prerotation = u2.nextKeyHashes.length > 0, u2.witness = m3.witness || u2.witness, u2.watchers = m3.watchers ?? null;
          let e4 = {
            versionId: G,
            versionTime: u2.created,
            parameters: Q(m3, u2.scid, G),
            state: Q(T2, u2.scid, G)
          }, n3 = await pi(e4);
          if (u2.previousLogEntryHash = n3, !await vr(u2.scid, n3)) throw Error(`SCID '${u2.scid}' not derived from logEntryHash '${n3}'`);
          if (E2.scid !== u2.scid) throw Error(`SCID in state.id '${E2.scid}' does not match SCID in log '${u2.scid}'`);
          let i3 = Q(e4, G, u2.scid), a3 = await pi(i3);
          if (!await mr({
            ...i3,
            versionId: `1-${a3}`,
            proof: x2
          }, u2.updateKeys, u2.witness, false, t2.verifier)) throw Error(`version ${u2.versionId} failed verification of the proof.`);
        } else {
          if (X(m3, K.method)) {
            let e5 = m3.method;
            if (e5 !== v2) throw Error(`version '${S2}' has unsupported or downgraded method '${e5}'; expected '${v2}'`);
          }
          if (X(m3, K.scid)) throw Error(`version '${S2}' must not contain SCID parameter`);
          if (m3.portable === true && !u2.portable) throw Error(`version '${S2}' cannot set portable: true; portability can only be enabled in the first entry`);
          if (X(m3, K.portable) && m3.portable === false && (u2.portable = false), E2.scid !== u2.scid) throw Error(`SCID in state.id '${E2.scid}' does not match SCID in log '${u2.scid}'`);
          let e4 = E2.locationKey;
          if (!u2.portable && e4 !== g2) throw Error(`Cannot move DID: portability is disabled`);
          e4 !== g2 && (g2 = e4);
          let { proof: r4, ...i3 } = n2[p2];
          if (!hr(await pi({
            ...i3,
            versionId: n2[p2 - 1].versionId
          }), w2)) throw Error(`Hash chain broken at '${u2.versionId}'`);
          let a3 = u2.prerotation ? m3.updateKeys : u2.updateKeys;
          if (!await mr(n2[p2], a3, u2.witness, false, t2.verifier)) throw Error(`version ${u2.versionId} failed verification of the proof.`);
          u2.prerotation && await gr(m3.updateKeys ?? [], u2.nextKeyHashes ?? []), X(m3, K.updateKeys) && (u2.updateKeys = m3.updateKeys ?? []), m3.deactivated === true && (u2.deactivated = true), X(m3, K.nextKeyHashes) && (u2.nextKeyHashes = m3.nextKeyHashes ?? [], u2.prerotation = u2.nextKeyHashes.length > 0);
          let o3 = m3;
          X(m3, K.witness) ? u2.witness = m3.witness : o3.witnesses && (u2.witness = {
            witnesses: o3.witnesses,
            threshold: o3.witnessThreshold || o3.witnesses.length
          }), u2.witness?.witnesses?.length && dr(u2.witness), X(m3, K.watchers) && (u2.watchers = m3.watchers ?? null);
        }
        let re2 = Ar(ee2, m3, u2.witness);
        re2 && y2.push({
          targetVersionId: u2.versionId,
          targetVersionNumber: C2,
          witness: re2
        }), a2 = Z(T2), i2 = Tr(a2.id), t2.requestedDid && i2 === t2.requestedDid && h2++, a2.service = Array.isArray(a2.service) ? a2.service : [];
        let D2 = $r(i2);
        oi(a2.service, `files`, i2) || a2.service.push({
          id: `#files`,
          type: vn,
          serviceEndpoint: D2
        }), oi(a2.service, `whois`, i2) || a2.service.push({
          "@context": bn,
          id: `#whois`,
          type: yn,
          serviceEndpoint: `${D2}/whois.vp`
        }), t2.verificationMethod && gi(a2, t2.verificationMethod) && (o2 || (o2 = Z(a2), s2 = i2, d2 = {
          ...u2
        })), (t2.versionNumber === C2 || t2.versionId === u2.versionId) && (o2 || (o2 = Z(a2), s2 = i2, d2 = {
          ...u2
        })), t2.versionTime && t2.versionTime > new Date(u2.updated) && (n2[p2 + 1] && t2.versionTime < new Date(n2[p2 + 1].versionTime) ? o2 || (o2 = Z(a2), s2 = i2, d2 = {
          ...u2
        }) : n2[p2 + 1] || o2 || (o2 = Z(a2), s2 = i2, d2 = {
          ...u2
        })), c2 = Z(a2), l2 = i2, f2 = {
          ...u2
        }, p2++;
      }
      if (t2.requestedDid && h2 === 0) throw Error(`Requested DID '${t2.requestedDid}' does not match state.id in any valid log version`);
      if (y2.length > 0) {
        t2.witnessProofs ||= await _i(i2);
        let e3 = new Map(n2.map((e4, t3) => [
          e4.versionId,
          t3 + 1
        ]));
        for (let r3 of y2) {
          let i3 = (t2.witnessProofs ?? []).filter((t3) => {
            let n3 = e3.get(t3.versionId);
            return n3 !== void 0 && n3 >= r3.targetVersionNumber;
          }), a3 = await fr(n2[r3.targetVersionNumber - 1], i3, r3.witness, t2.verifier);
          if (a3 < parseInt((r3.witness.threshold ?? 0).toString(), 10)) throw b2 = true, Error(`Witness threshold not met for version ${r3.targetVersionId}: got ${a3}, need ${r3.witness.threshold}`);
        }
      }
    } catch (e3) {
      if (!o2) throw e3;
      if (d2 && (!m2 || b2)) {
        let t3 = e3 instanceof Error ? e3.message : String(e3);
        d2.error = `invalidDid`, d2.problemDetails = {
          type: xn,
          title: `The resolved DID is invalid.`,
          detail: t3
        };
      }
    }
    if (!o2) {
      if (m2) {
        if (!f2 || !l2) throw Error(`DID resolution failed: No valid result available for explicit selector`);
        return {
          did: l2,
          doc: null,
          meta: {
            ...f2,
            error: `notFound`,
            problemDetails: {
              type: Sn,
              title: `The requested DID version was not found.`,
              detail: `The supplied explicit version selector did not match any entry in the DID log.`
            }
          }
        };
      }
      d2 = f2, s2 = l2, d2 && (!d2.deactivated || m2) && (o2 = c2);
    }
    if (!d2) throw Error(`DID resolution failed: No valid metadata found`);
    if (!s2) throw Error(`DID resolution failed: No valid identifier found`);
    if (d2.deactivated && !m2) return {
      did: s2,
      doc: null,
      meta: d2
    };
    if (!o2) throw Error(`DID resolution failed: No valid document found`);
    return {
      did: s2,
      doc: o2,
      meta: d2
    };
  }, Or = (e2) => {
    if (`witness` in e2) return e2.witness ?? {};
    if (e2.witnesses) {
      let t2 = e2;
      return {
        witnesses: t2.witnesses,
        threshold: t2.witnessThreshold || t2.witnesses.length
      };
    }
  }, kr = (e2) => !e2?.witnesses || e2.witnesses.length === 0 ? false : parseInt((e2.threshold ?? 0).toString(), 10) > 0, Ar = (e2, t2, n2) => {
    let r2 = Or(t2);
    if (kr(e2)) return Z(e2);
    if (r2 !== void 0 && kr(n2)) return Z(n2);
  }, jr = `1.0`;
  function Mr(e2) {
    if (!e2) return jr;
    let t2 = e2.match(/^did:webvh:(\d+\.\d+)$/);
    return t2 ? t2[1] : jr;
  }
  function Nr(e2) {
    return e2 && e2.length > 0 && e2[0].parameters?.method ? Mr(e2[0].parameters.method) : jr;
  }
  var Pr = async (e2, t2 = {}) => {
    if (Nr(e2) === `0.5`) {
      let n3 = await xr(e2, t2);
      return ci(n3.did, e2), n3;
    }
    let n2 = await Dr(e2, t2);
    return ci(n2.did, e2), n2;
  }, Fr = `did:key:`;
  function Ir(e2) {
    if (!e2) throw Error(`Malformed did:key identifier`);
    try {
      ir(e2);
    } catch (e3) {
      let t2 = e3 instanceof Error ? e3.message : String(e3);
      throw Error(`Malformed did:key identifier: ${t2}`);
    }
  }
  function Lr(e2) {
    if (typeof e2 != `string`) throw Error(`did:key DID must be a string`);
    let t2 = e2.match(/^did:key:([^#/?]+)$/);
    if (!t2) throw Error(`Malformed did:key DID`);
    let n2 = t2[1];
    return Ir(n2), {
      did: `${Fr}${n2}`,
      keyMultibase: n2
    };
  }
  function Rr(e2) {
    if (typeof e2 != `string`) throw Error(`did:key verificationMethod must be a string`);
    if (e2.startsWith(`#`)) throw Error(`did:key verificationMethod must be an absolute DID URL`);
    let t2 = e2.match(/^did:key:([^#/?]+)(?:#([^#/?]+))?$/);
    if (!t2) throw Error(`Malformed did:key verificationMethod`);
    let n2 = Lr(`${Fr}${t2[1]}`), r2 = t2[2];
    if (r2 && r2 !== n2.keyMultibase) throw Error(`did:key verificationMethod fragment must equal body multibase. Expected fragment '${n2.keyMultibase}' but got '${r2}'`);
    return {
      did: n2.did,
      fragment: r2,
      keyMultibase: n2.keyMultibase
    };
  }
  function zr(e2) {
    if (/^\d+\.\d+\.\d+\.\d+$/.test(e2)) return true;
    let t2 = e2.replace(/^\[|\]$/g, ``);
    return !!/^[0-9a-f:]+$/i.test(t2);
  }
  function Br(e2) {
    return e2.includes(`%25`);
  }
  function Vr(e2) {
    return e2.includes(`#`) || e2.includes(`?`);
  }
  function Hr(e2) {
    try {
      return decodeURIComponent(e2);
    } catch {
      throw Error(`Invalid percent-encoding in host: ${e2}`);
    }
  }
  function Ur(e2) {
    let t2 = parseInt(e2, 10);
    if (Number.isNaN(t2) || t2 <= 0 || t2 > 65535) throw Error(`Invalid port number: ${e2}`);
    return t2;
  }
  function Wr(e2) {
    return e2.length > 0 ? e2 : void 0;
  }
  function Gr(e2, t2) {
    return t2 ? `${e2}%3A${t2}` : e2;
  }
  function Kr(e2, t2, n2 = []) {
    return {
      canonicalHost: e2,
      canonicalPort: t2,
      didDomainComponent: Gr(e2, t2),
      paths: Wr(n2)
    };
  }
  function qr(e2) {
    if (!e2.includes(`:`)) return {
      host: e2
    };
    let t2 = e2.split(`:`);
    if (t2.length !== 2) throw Error(`Invalid host:port format`);
    return {
      host: t2[0],
      port: Ur(t2[1])
    };
  }
  function Jr(e2) {
    let t2 = /%3a/i;
    if (!t2.test(e2)) return {
      host: e2
    };
    let n2 = e2.split(t2);
    if (n2.length !== 2) throw Error(`Invalid pre-encoded port separator`);
    let [r2, i2] = n2;
    return {
      host: r2,
      port: Ur(i2)
    };
  }
  function Yr(e2, t2) {
    for (let n2 of e2) {
      let e3;
      try {
        e3 = decodeURIComponent(n2);
      } catch {
        throw Error(`${t2} contains invalid percent-encoding in path segment '${n2}'`);
      }
      if (e3 === `.` || e3 === `..`) throw Error(`${t2} must not contain dot-segments`);
      if (e3.includes(`/`)) throw Error(`${t2} must not contain decoded slash within a single path segment`);
      if (e3.includes(`\\`)) throw Error(`${t2} must not contain decoded backslash within a path segment`);
      if (e3.includes(`\0`)) throw Error(`${t2} must not contain decoded NUL character within a path segment`);
      if (e3 !== e3.trim()) throw Error(`${t2} must not contain leading or trailing whitespace in decoded path segment`);
    }
  }
  function Xr(e2) {
    if (!e2 || typeof e2 != `string`) throw Error(`Address input must be a non-empty string`);
    if (Vr(e2) && !e2.startsWith(`http://`) && !e2.startsWith(`https://`)) throw Error(`Address input must not include query or fragment components`);
    if (e2.startsWith(`did:webvh:`)) {
      let t3 = e2.substring(10).split(`:`);
      if (t3.length < 2) throw Error(`Invalid did:webvh identifier: must contain SCID (or {SCID} placeholder) and domain`);
      let n3 = t3[1], r3 = t3.slice(2);
      if (Vr(n3) || r3.some((e3) => Vr(e3))) throw Error(`did:webvh identifier must not include query or fragment components`);
      if (Yr(r3, `did:webvh identifier`), Br(n3)) throw Error(`Domain is double-encoded (detected %25)`);
      let i2 = Jr(n3), a2 = Hr(i2.host), o2 = i2.port;
      if (zr(a2)) throw Error(`IP addresses are not allowed as hosts`);
      return Kr(a2, o2, r3);
    }
    if (e2.startsWith(`https://`) || e2.startsWith(`http://`)) try {
      let t3 = new URL(e2);
      if (t3.protocol === `http:`) throw Error(`HTTP is not allowed; use HTTPS`);
      if (t3.hash || t3.search) throw Error(`URL input must not include query or fragment components`);
      let n3 = t3.hostname, r3 = t3.port ? parseInt(t3.port, 10) : void 0;
      if (zr(n3)) throw Error(`IP addresses are not allowed as hosts`);
      let i2 = t3.pathname && t3.pathname !== `/` ? t3.pathname.split(`/`).filter((e3) => e3.length > 0) : [];
      return Yr(i2, `URL pathname`), Kr(n3, r3, i2);
    } catch (e3) {
      let t3 = e3 instanceof Error ? e3.message : String(e3);
      throw t3.includes(`not allowed`) ? e3 : Error(`Invalid URL: ${t3}`);
    }
    if (Br(e2)) throw Error(`Domain is double-encoded (detected %25)`);
    if (Vr(e2)) throw Error(`Domain input must not include query or fragment components`);
    let t2 = /%3a/i.test(e2) ? Jr(e2) : qr(e2), n2 = Hr(t2.host), r2 = t2.port;
    if (zr(n2)) throw Error(`IP addresses are not allowed as hosts`);
    return Kr(n2, r2);
  }
  function Zr(e2, t2) {
    let n2 = Xr(e2), r2 = e2.split(`:`);
    if (r2.length < 4 || r2[0] !== `did` || r2[1] !== gn) throw Error(`${t2} must be a valid did:webvh identifier`);
    let i2 = r2[2];
    if (!i2) throw Error(`${t2} must include SCID segment`);
    let a2 = n2.paths?.length ? `${n2.didDomainComponent}:${n2.paths.join(`:`)}` : n2.didDomainComponent;
    return {
      scid: i2,
      didDomainComponent: n2.didDomainComponent,
      paths: n2.paths,
      locationKey: a2
    };
  }
  var Qr = (e2) => {
    try {
      return new URL(`https://${e2}`).hostname;
    } catch {
      return e2;
    }
  }, $r = (e2) => {
    if (Vr(e2)) throw Error(`did:webvh identifier must not include query or fragment components`);
    let t2 = Xr(e2), n2 = Qr(t2.canonicalHost.normalize(`NFC`)), r2 = t2.canonicalPort ? `${n2}:${t2.canonicalPort}` : n2, i2 = t2.paths?.join(`/`) ?? ``;
    return `https://${r2}${i2 ? `/${i2}` : ``}`;
  }, ei = (e2) => {
    let t2 = $r(e2);
    return t2.indexOf(`/`, t2.indexOf(`://`) + 3) === -1 ? `${t2}/.well-known/did.jsonl` : `${t2}/did.jsonl`;
  }, ti = typeof process < `u` && typeof window > `u` && !!(process.versions?.node || process.versions?.bun), ni = [
    `node`,
    `fs`
  ].join(`:`), ri = null, ii = null, ai = async () => {
    if (!ti) throw Error(`Filesystem access is not available in this environment (React Native, browser, or failed Node.js import)`);
    return ri || ii || (ii = (async () => {
      let t2 = globalThis.require;
      if (typeof t2 == `function`) {
        try {
          let e2 = t2(ni);
          return ri = e2, e2;
        } catch {
        }
        try {
          let e2 = t2(`fs`);
          return ri = e2, e2;
        } catch {
        }
      }
      try {
        let e2 = await cn(() => import(ni).then(async (m2) => {
          await m2.__tla;
          return m2;
        }), []);
        return ri = e2, e2;
      } catch {
      }
      try {
        let t3 = await cn(() => import("./__vite-browser-external-CKnVkMRn.js").then(async (m2) => {
          await m2.__tla;
          return m2;
        }).then((t4) => e(t4.default, 1)), []);
        return ri = t3, t3;
      } catch {
      }
      try {
        let t3 = await cn(() => import("./__vite-browser-external-CKnVkMRn.js").then(async (m2) => {
          await m2.__tla;
          return m2;
        }).then((t4) => e(t4.default, 1)), []);
        return ri = t3, t3;
      } catch {
      }
      throw Error(`Filesystem access is not available in this environment (unable to load fs)`);
    })(), ii);
  };
  function oi(e2, t2, n2) {
    let r2 = `#${t2}`, i2 = `${n2}#${t2}`;
    return e2.some((e3) => {
      let t3 = e3.id || ``;
      return t3 === r2 || t3 === i2;
    });
  }
  var si = async (e2, t2) => {
    let n2 = await ai();
    try {
      let r2 = e2.substring(0, e2.lastIndexOf(`/`));
      r2 && !n2.existsSync(r2) && n2.mkdirSync(r2, {
        recursive: true
      }), n2.writeFileSync(e2, `${JSON.stringify(t2[0])}
`);
      for (let r3 = 1; r3 < t2.length; r3++) n2.appendFileSync(e2, `${JSON.stringify(t2[r3])}
`);
    } catch (e3) {
      throw console.error(`Error writing log to disk:`, e3), e3;
    }
  }, ci = async (e2, t2) => {
    if (hn.isTestEnvironment) try {
      await si(`./test/logs/${e2.replace(/[^a-zA-Z0-9]+/g, `_`)}.jsonl`, t2);
    } catch (e3) {
      console.error(`Error writing test log:`, e3);
    }
  };
  function Z(e2) {
    if (typeof e2 != `object` || !e2) return e2;
    if (e2 instanceof Date) return new Date(e2.getTime());
    if (Array.isArray(e2)) return e2.map((e3) => Z(e3));
    let t2 = {};
    for (let [n2, r2] of Object.entries(e2)) t2[n2] = Z(r2);
    return t2;
  }
  var li = async (e2) => e2, ui = /* @__PURE__ */ new Map();
  function di(e2) {
    try {
      let t2 = JSON.stringify(e2);
      return ui.get(t2);
    } catch {
      return;
    }
  }
  function fi(e2, t2) {
    try {
      let n2 = JSON.stringify(e2);
      ui.set(n2, t2);
    } catch {
    }
  }
  async function pi(e2) {
    let t2 = di(e2);
    if (t2) return t2;
    let n2 = await Qn(An(e2)), r2 = nr(lr(new Uint8Array(n2), 18));
    return fi(e2, r2), r2;
  }
  var mi = async (e2) => {
    let t2 = await Qn(e2);
    return nr(lr(new Uint8Array(t2), 18));
  }, hi = async (e2) => {
    try {
      if (e2.startsWith(`did:key:`)) return {
        publicKeyMultibase: Rr(e2).keyMultibase
      };
      if (e2.startsWith(`did:webvh:`)) {
        let t2 = ei(e2.split(`#`)[0]), { doc: n2 } = await Pr((await (await fetch(t2)).text()).trim().split(`
`).map((e3) => JSON.parse(e3)), {
          verificationMethod: e2
        });
        if (!n2) throw Error(`Verification method ${e2} not found`);
        return gi(n2, e2);
      }
      throw Error(`Verification method ${e2} not found`);
    } catch {
      throw Error(`Error resolving VM ${e2}`);
    }
  }, gi = (e2, t2) => {
    if (e2.verificationMethod?.some((e3) => e3.id === t2)) return e2.verificationMethod.find((e3) => e3.id === t2) ?? null;
    for (let n2 of [
      `authentication`,
      `assertionMethod`,
      `keyAgreement`,
      `capabilityInvocation`,
      `capabilityDelegation`
    ]) {
      let r2 = e2[n2];
      if (Array.isArray(r2) && r2.some((e3) => typeof e3 != `object` || !e3 ? false : e3.id === t2)) {
        let e3 = r2.find((e4) => typeof e4 != `object` || !e4 ? false : e4.id === t2);
        if (e3 && typeof e3 == `object`) return e3;
      }
    }
    return null;
  };
  async function _i(e2) {
    try {
      let t2 = ei(e2).replace(`did.jsonl`, `did-witness.json`), n2 = await fetch(t2);
      return n2.ok ? await n2.json() : [];
    } catch (e3) {
      return console.error(`Error fetching witness proofs:`, e3), [];
    }
  }
  function Q(e2, t2, n2) {
    if (typeof e2 == `string`) return e2.replaceAll(t2, n2);
    if (Array.isArray(e2)) return e2.map((e3) => Q(e3, t2, n2));
    if (e2 && typeof e2 == `object`) {
      let r2 = {};
      for (let [i2, a2] of Object.entries(e2)) r2[i2] = Q(a2, t2, n2);
      return r2;
    }
    return e2;
  }
  var vi = `E_BLOCKED_ENDPOINT`, $ = class extends Error {
    constructor(e2, { reason: t2, url: n2, host: r2, label: i2 } = {}) {
      super(e2), this.name = `BlockedEndpointError`, this.code = vi, this.reason = t2, this.url = n2, this.host = r2, this.label = i2;
    }
  }, yi = [
    [
      `0.0.0.0`,
      8
    ],
    [
      `10.0.0.0`,
      8
    ],
    [
      `100.64.0.0`,
      10
    ],
    [
      `127.0.0.0`,
      8
    ],
    [
      `169.254.0.0`,
      16
    ],
    [
      `172.16.0.0`,
      12
    ],
    [
      `192.0.0.0`,
      24
    ],
    [
      `192.0.2.0`,
      24
    ],
    [
      `192.168.0.0`,
      16
    ],
    [
      `198.18.0.0`,
      15
    ],
    [
      `198.51.100.0`,
      24
    ],
    [
      `203.0.113.0`,
      24
    ],
    [
      `224.0.0.0`,
      4
    ],
    [
      `240.0.0.0`,
      4
    ]
  ].map(([e2, t2]) => [
    wi(Ci(e2)),
    t2
  ]);
  function bi(e2) {
    if (typeof e2 != `string`) throw TypeError(`net-guard: isBlockedIp expects a string`);
    let t2 = Ci(e2);
    if (t2) return xi(wi(t2));
    let n2 = Ti(e2);
    return !n2 || Si(n2);
  }
  function xi(e2) {
    for (let [t2, n2] of yi) {
      let r2 = 32 - n2;
      if (e2 >>> r2 == t2 >>> r2) return true;
    }
    return false;
  }
  function Si(e2) {
    let t2 = (t3, n3) => e2.slice(t3, n3).every((e3) => e3 === 0), n2 = (e3, t3) => xi((e3 << 16 >>> 0) + t3);
    return t2(0, 6) || t2(0, 5) && e2[5] === 65535 || t2(0, 4) && e2[4] === 65535 && e2[5] === 0 || e2[0] === 100 && e2[1] === 65435 && t2(2, 6) ? n2(e2[6], e2[7]) : e2[0] === 100 && e2[1] === 65435 && e2[2] === 1 ? true : e2[0] === 8194 ? n2(e2[1], e2[2]) : e2[0] === 8193 && e2[1] < 512 || e2[0] === 8193 && e2[1] === 3512 || e2[0] === 16383 && !(e2[1] & 61440) || (e2[0] & 57344) != 8192;
  }
  function Ci(e2) {
    let t2 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(e2);
    if (!t2) return null;
    let n2 = [];
    for (let e3 = 1; e3 <= 4; e3++) {
      if (t2[e3].length > 1 && t2[e3][0] === `0`) return null;
      let r2 = Number(t2[e3]);
      if (r2 > 255) return null;
      n2.push(r2);
    }
    return n2;
  }
  function wi([e2, t2, n2, r2]) {
    return (e2 << 24 >>> 0) + (t2 << 16) + (n2 << 8) + r2;
  }
  function Ti(e2) {
    let t2 = e2;
    if (t2.startsWith(`[`) && t2.endsWith(`]`) && (t2 = t2.slice(1, -1)), !/^[0-9A-Fa-f:.]+$/.test(t2)) return null;
    let n2 = t2.lastIndexOf(`:`);
    if (n2 === -1) return null;
    let r2 = [];
    if (t2.includes(`.`)) {
      let e3 = Ci(t2.slice(n2 + 1));
      if (!e3) return null;
      r2 = [
        e3[0] << 8 | e3[1],
        e3[2] << 8 | e3[3]
      ], t2 = t2.slice(0, n2 + 1), t2.endsWith(`::`) || (t2 = t2.slice(0, -1));
    }
    let i2 = 8 - r2.length, a2 = (e3) => {
      if (e3 === ``) return [];
      let t3 = [];
      for (let n3 of e3.split(`:`)) {
        if (!/^[0-9A-Fa-f]{1,4}$/.test(n3)) return null;
        t3.push(parseInt(n3, 16));
      }
      return t3;
    }, o2 = t2.indexOf(`::`);
    if (o2 === -1) {
      let e3 = a2(t2);
      return !e3 || e3.length !== i2 ? null : [
        ...e3,
        ...r2
      ];
    }
    if (o2 !== t2.lastIndexOf(`::`)) return null;
    let s2 = a2(t2.slice(0, o2)), c2 = a2(t2.slice(o2 + 2));
    if (!s2 || !c2) return null;
    let l2 = i2 - s2.length - c2.length;
    return l2 < 1 ? null : [
      ...s2,
      ...Array(l2).fill(0),
      ...c2,
      ...r2
    ];
  }
  var Ei = /* @__PURE__ */ new Set([
    `https:`,
    `wss:`,
    `http:`,
    `ws:`
  ]), Di = {
    "https:": `http:`,
    "wss:": `ws:`
  }, Oi = [
    `.localhost`,
    `.local`,
    `.internal`,
    `.home.arpa`
  ];
  function ki(e2, t2 = {}) {
    let { label: n2 = `endpoint`, allowPrivate: r2 = false } = t2 ?? {}, i2 = ji(t2?.schemes, t2?.allowInsecure), a2 = Mi(t2?.allowHosts), o2;
    try {
      if (typeof e2 != `string` && !(e2 instanceof URL)) throw Error(`not a URL`);
      o2 = new URL(String(e2));
    } catch {
      throw new $(`net-guard: ${n2} endpoint is not a valid absolute URL`, {
        reason: `invalid_url`,
        label: n2
      });
    }
    let s2 = Ii(o2), c2 = (e3, t3, r3) => new $(`net-guard: ${n2} endpoint ${s2} refused: ${t3}`, {
      reason: e3,
      url: s2,
      host: r3,
      label: n2
    });
    if (!i2.has(o2.protocol)) {
      let e3 = Object.values(Di).includes(o2.protocol) ? ` (plaintext transport needs allowInsecure)` : ``;
      throw c2(`scheme`, `scheme ${o2.protocol} is not allowed${e3}`);
    }
    if (o2.username !== `` || o2.password !== ``) throw c2(`userinfo`, `credentials in the URL are not allowed`);
    let l2 = o2.hostname.startsWith(`[`), u2 = Fi(o2.hostname);
    if (u2 === ``) throw new $(`net-guard: ${n2} endpoint has no host`, {
      reason: `invalid_url`,
      label: n2
    });
    if (!r2) {
      if (l2 || Ci(u2)) {
        if (bi(u2)) throw c2(`private_address`, `${u2} is not a public address (set allowPrivate for local development)`, u2);
      } else if (Pi(u2)) throw c2(`private_name`, `${u2} is a local-only name (set allowPrivate for local development)`, u2);
    }
    if (a2 && !Ni(u2, a2)) throw c2(`not_allowlisted`, `${u2} is not in allowHosts`, u2);
    return o2;
  }
  Ai = function(e2, t2 = {}) {
    let n2 = e2 ?? globalThis.fetch;
    if (typeof n2 != `function`) throw TypeError(`net-guard: guardedFetch needs a fetch implementation`);
    ji(t2?.schemes, t2?.allowInsecure), Mi(t2?.allowHosts);
    let r2 = t2?.label ?? `endpoint`;
    return async function(e3, i2) {
      let a2 = ki(typeof e3 == `string` || e3 instanceof URL ? e3 : e3?.url, t2), o2 = await n2(e3, {
        ...i2 ?? {},
        redirect: `manual`
      });
      if (o2?.type === `opaqueredirect` || o2?.status >= 300 && o2?.status < 400) {
        try {
          await o2.body?.cancel?.();
        } catch {
        }
        let e4 = Ii(a2), t3 = new $(`net-guard: ${r2} endpoint ${e4} answered with a redirect${o2.status ? ` (${o2.status})` : ``}; redirects are not followed`, {
          reason: `redirect`,
          url: e4,
          host: Fi(a2.hostname),
          label: r2
        });
        throw t3.status = o2.status, t3;
      }
      return o2;
    };
  };
  function ji(e2, t2) {
    let n2 = e2 ?? [
      `https:`,
      `wss:`
    ];
    if (!Array.isArray(n2) || n2.length === 0) throw TypeError(`net-guard: schemes must be a non-empty array`);
    let r2 = /* @__PURE__ */ new Set();
    for (let e3 of n2) {
      if (typeof e3 != `string`) throw TypeError(`net-guard: schemes entries must be strings`);
      let n3 = e3.toLowerCase().endsWith(`:`) ? e3.toLowerCase() : `${e3.toLowerCase()}:`;
      if (!Ei.has(n3)) throw TypeError(`net-guard: unsupported scheme ${JSON.stringify(e3)} (use https:, wss:, http: or ws:)`);
      r2.add(n3), t2 && Di[n3] && r2.add(Di[n3]);
    }
    return r2;
  }
  function Mi(e2) {
    if (e2 == null) return null;
    if (!Array.isArray(e2)) throw TypeError(`net-guard: allowHosts must be an array of host names, or null`);
    return e2.map((e3) => {
      if (typeof e3 != `string`) throw TypeError(`net-guard: allowHosts entries must be strings`);
      let t2 = () => TypeError(`net-guard: invalid allowHosts entry ${JSON.stringify(e3)} (host names only, no scheme, port or path)`), n2 = e3.trim().toLowerCase(), r2 = n2.startsWith(`*.`), i2 = r2 ? n2.slice(2) : n2;
      if (i2 === `` || /[/@?#\s*]/.test(i2)) throw t2();
      let a2 = i2;
      if (!i2.startsWith(`[`) && i2.includes(`:`)) {
        if (!Ti(i2)) throw t2();
        a2 = `[${i2}]`;
      }
      let o2;
      try {
        let e4 = new URL(`https://${a2}/`);
        if (e4.port !== ``) throw t2();
        o2 = Fi(e4.hostname);
      } catch {
        throw t2();
      }
      return r2 ? {
        suffix: `.${o2}`
      } : {
        exact: o2
      };
    });
  }
  function Ni(e2, t2) {
    return t2.some((t3) => t3.exact === void 0 ? e2.length > t3.suffix.length && e2.endsWith(t3.suffix) : e2 === t3.exact);
  }
  function Pi(e2) {
    return !e2.includes(`.`) || Oi.some((t2) => e2.endsWith(t2));
  }
  function Fi(e2) {
    let t2 = e2.toLowerCase();
    return t2.startsWith(`[`) && t2.endsWith(`]`) ? t2.slice(1, -1) : t2.replace(/\.+$/, ``);
  }
  function Ii(e2) {
    return `${e2.protocol}//${e2.host}${e2.pathname}`;
  }
  var Li = t({
    DEFAULT_WEBVH_TIMEOUT_MS: () => Ri,
    resolve: () => Ui,
    resolveLog: () => Wi,
    webvhLogUrl: () => Hi
  }), Ri = 1e4, zi = `did:webvh log`, Bi = `did:webvh witness file`, Vi = `did:webvh proof verification method`;
  function Hi(e2, t2 = {}) {
    let n2 = t2?.label ?? zi, r2 = typeof e2 == `string` ? e2.split(`:`) : [], i2 = () => Error(`did:webvh resolve: ${JSON.stringify(String(e2).slice(0, 80))} is not a usable did:webvh identifier`);
    if (r2.length < 4 || r2[0] !== `did` || r2[1] !== `webvh` || !r2[2] || !r2[3]) throw i2();
    let [a2, ...o2] = decodeURIComponent(r2.slice(3).join(`/`)).split(`/`), s2 = decodeURIComponent(a2).split(`:`);
    if (s2.length > 2 || !s2[0]) throw i2();
    let c2 = s2[0].normalize(`NFC`).toLowerCase(), l2 = s2[1], u2 = t2?.allowPrivate === true, d2 = u2 && (c2 === `localhost` || t2?.allowInsecure === true);
    if (!u2 && c2.includes(`localhost`)) throw new $(`net-guard: ${n2} host ${c2} refused: a did:webvh host containing "localhost" is local-only (set allowPrivate for local development)`, {
      reason: `private_name`,
      host: c2,
      label: n2
    });
    let f2 = l2 ? `${c2}:${l2}` : c2, p2 = o2.filter((e3) => e3 !== ``).join(`/`), m2 = `${d2 ? `http` : `https`}://${f2}${p2 ? `/${p2}` : ``}`;
    return ki(p2 ? `${m2}/did.jsonl` : `${m2}/.well-known/did.jsonl`, {
      ...t2,
      label: n2,
      schemes: [
        `https:`
      ],
      allowInsecure: d2
    });
  }
  async function Ui(e2, t2 = {}) {
    if (typeof e2 != `string`) throw TypeError(`did:webvh resolve: input must be a string`);
    if (!e2.startsWith(`did:webvh:`)) throw Error(`did:webvh resolve: identifier must start with "did:webvh:"`);
    let n2 = Ki(t2), r2 = Hi(e2, {
      ...n2,
      label: zi
    }), i2 = r2.protocol === `http:`, a2 = Ai(t2.fetch ?? globalThis.fetch, {
      ...n2,
      label: zi,
      schemes: [
        `https:`
      ],
      allowInsecure: i2
    }), o2 = Xi(await qi(a2, r2, t2, zi), r2), s2 = Zi(o2) ? await Yi(a2, r2, t2) : [];
    return $i(o2, s2, n2), ea(await Pr(o2, {
      verifier: t2.verifier ?? await Gi(),
      witnessProofs: s2,
      scid: e2.split(`:`)[2]
    }));
  }
  async function Wi(e2, t2 = {}) {
    let n2 = Ki(t2), r2 = t2.witnessProofs ?? [];
    if (!Array.isArray(r2)) throw TypeError(`did:webvh resolveLog: witnessProofs must be an array`);
    if (r2.length === 0 && Zi(e2)) throw Error("did:webvh resolveLog: this log declares witnesses \u2014 pass `witnessProofs`, or use resolve(did), which fetches did-witness.json through the egress guard");
    $i(e2, r2, n2);
    let i2 = {
      verifier: t2.verifier ?? await Gi(),
      witnessProofs: r2
    };
    return t2.scid && (i2.scid = t2.scid), ea(await Pr(e2, i2));
  }
  async function Gi() {
    let { ed25519: e2 } = await cn(async () => {
      let { ed25519: e3 } = await import("./ed25519-CXOV6hux.js").then(async (m2) => {
        await m2.__tla;
        return m2;
      });
      return {
        ed25519: e3
      };
    }, []);
    return {
      async verify(t2, n2, r2) {
        return e2.verify(t2, n2, r2);
      }
    };
  }
  function Ki(e2) {
    let t2 = e2?.netPolicy;
    if (t2 != null && typeof t2 != `object`) throw TypeError(`did:webvh: netPolicy must be an object`);
    return {
      allowInsecure: !!t2?.allowInsecure,
      allowPrivate: !!t2?.allowPrivate,
      allowHosts: t2?.allowHosts ?? null
    };
  }
  async function qi(e2, t2, n2, r2) {
    let i2 = n2?.timeoutMs ?? 1e4, a2 = {
      method: `GET`,
      redirect: `manual`
    };
    i2 > 0 && typeof AbortSignal?.timeout == `function` && (a2.signal = AbortSignal.timeout(i2));
    let o2;
    try {
      o2 = await e2(t2.href, a2);
    } catch (e3) {
      throw e3 instanceof $ ? e3 : Error(`did:webvh resolve failed: ${r2} ${t2.href} \u2014 ${e3?.message ?? e3}`);
    }
    if (!o2?.ok) {
      let e3 = Error(`did:webvh resolve failed: ${r2} ${t2.href} \u2014 HTTP ${o2?.status}`);
      throw e3.status = o2?.status, e3;
    }
    return o2.text();
  }
  function Ji(e2) {
    return new URL(e2.href.replace(/did\.jsonl$/, `did-witness.json`));
  }
  async function Yi(e2, t2, n2) {
    let r2;
    try {
      r2 = await qi(e2, Ji(t2), n2, Bi);
    } catch (e3) {
      if (e3 instanceof $) throw e3;
      return [];
    }
    try {
      let e3 = JSON.parse(r2);
      return Array.isArray(e3) ? e3 : [];
    } catch {
      return [];
    }
  }
  function Xi(e2, t2) {
    let n2 = e2.trim();
    if (!n2) throw Error(`did:webvh resolve failed: empty DID log at ${t2.href}`);
    let r2 = [];
    for (let e3 of n2.split(/\r?\n/)) if (e3.trim()) try {
      r2.push(JSON.parse(e3));
    } catch (e4) {
      throw Error(`did:webvh resolve failed: DID log at ${t2.href} has a line that is not JSON \u2014 ${e4.message}`);
    }
    return r2;
  }
  function Zi(e2) {
    for (let t2 of Array.isArray(e2) ? e2 : []) {
      let e3 = t2?.parameters;
      if (Array.isArray(e3?.witness?.witnesses) && e3.witness.witnesses.length > 0 || Array.isArray(e3?.witnesses) && e3.witnesses.length > 0) return true;
    }
    return false;
  }
  function Qi(e2, t2) {
    let n2 = /* @__PURE__ */ new Set(), r2 = (e3) => {
      let t3 = Array.isArray(e3) ? e3 : e3 ? [
        e3
      ] : [];
      for (let e4 of t3) {
        let t4 = e4?.verificationMethod;
        typeof t4 == `string` && t4.startsWith(`did:webvh:`) && n2.add(t4.split(`#`)[0]);
      }
    };
    for (let t3 of Array.isArray(e2) ? e2 : []) r2(t3?.proof);
    for (let e3 of Array.isArray(t2) ? t2 : []) r2(e3?.proof);
    return [
      ...n2
    ];
  }
  function $i(e2, t2, n2) {
    for (let r2 of Qi(e2, t2)) Hi(r2, {
      ...n2,
      label: Vi
    });
  }
  function ea(e2) {
    let t2 = e2?.meta?.error;
    if (t2) {
      let n2 = e2?.meta?.problemDetails?.detail;
      throw Error(`did:webvh resolve failed: ${t2}${n2 ? ` \u2014 ${n2}` : ``}`);
    }
    if (!e2?.doc || typeof e2.doc != `object`) throw Error(`did:webvh resolve: resolver returned no DID document (and no error) \u2014 the log may be empty or unreachable`);
    return {
      didDocument: e2.doc,
      didResolutionMetadata: {
        contentType: `application/did+ld+json`
      },
      didDocumentMetadata: e2.meta ?? {}
    };
  }
  var ta = t({
    resolve: () => oa
  }), na = `did:peer:`, ra = {
    A: `assertionMethod`,
    E: `keyAgreement`,
    V: `authentication`,
    I: `capabilityInvocation`,
    D: `capabilityDelegation`
  }, ia = {
    t: `type`,
    s: `serviceEndpoint`,
    r: `routingKeys`,
    a: `accept`
  }, aa = {
    dm: `DIDCommMessaging`
  };
  function oa(e2) {
    if (typeof e2 != `string`) throw TypeError(`did:peer resolve: input must be a string`);
    if (!e2.startsWith(na)) throw Error(`did:peer resolve: identifier must start with "did:peer:" (got ${JSON.stringify(e2.slice(0, 32))}\u2026)`);
    let t2 = e2.slice(9), n2 = t2[0];
    if (n2 !== `2`) throw Error(`did:peer resolve: only numalgo 2 is supported (got numalgo ${JSON.stringify(n2)})`);
    let r2 = t2.slice(1).split(`.`);
    if (r2.length < 2 || r2[0] !== ``) throw Error(`did:peer resolve: malformed numalgo-2 identifier (expected '.'-prefixed elements)`);
    let i2 = [], a2 = {
      authentication: [],
      assertionMethod: [],
      keyAgreement: [],
      capabilityInvocation: [],
      capabilityDelegation: []
    }, o2 = [], s2 = 0, c2 = 0;
    for (let t3 = 1; t3 < r2.length; t3++) {
      let n3 = r2[t3];
      if (n3.length < 2) throw Error(`did:peer resolve: empty element at position ${t3}`);
      let l3 = n3[0], u2 = n3.slice(1);
      if (l3 === `S`) {
        for (let t4 of sa(u2, e2, () => c2++)) o2.push(t4);
        continue;
      }
      let d2 = ra[l3];
      if (!d2) throw Error(`did:peer resolve: unknown purpose code ${JSON.stringify(l3)} at position ${t3}`);
      R(u2), s2 += 1;
      let f2 = `${e2}#key-${s2}`;
      i2.push({
        id: f2,
        type: `Multikey`,
        controller: e2,
        publicKeyMultibase: u2
      }), a2[d2].push(f2);
    }
    let l2 = {
      "@context": [
        `https://www.w3.org/ns/did/v1`,
        `https://w3id.org/security/multikey/v1`
      ],
      id: e2,
      verificationMethod: i2
    };
    for (let [e3, t3] of Object.entries(a2)) t3.length > 0 && (l2[e3] = t3);
    return o2.length > 0 && (l2.service = o2), {
      didDocument: l2,
      didResolutionMetadata: {
        contentType: `application/did+ld+json`
      },
      didDocumentMetadata: {}
    };
  }
  function sa(e2, t2, n2) {
    let r2;
    try {
      r2 = JSON.parse(new TextDecoder().decode(j(e2)));
    } catch (e3) {
      throw Error(`did:peer resolve: service element is not base64url JSON: ${e3.message}`);
    }
    return (Array.isArray(r2) ? r2 : [
      r2
    ]).map((e3) => {
      let r3 = ca(e3);
      if (!r3.id) {
        let e4 = n2();
        r3.id = e4 === 0 ? `${t2}#service` : `${t2}#service-${e4}`;
      }
      return r3;
    });
  }
  function ca(e2) {
    if (!e2 || typeof e2 != `object`) throw Error(`did:peer resolve: service element must be a JSON object`);
    let t2 = {};
    for (let [n2, r2] of Object.entries(e2)) {
      let e3 = ia[n2] ?? n2;
      t2[e3] = e3 === `type` && typeof r2 == `string` ? aa[r2] ?? r2 : r2;
    }
    return t2;
  }
  var la = Object.freeze({
    key: Rt,
    webvh: Li,
    peer: ta
  }), ua = 3e5, da = /* @__PURE__ */ new Set([
    `key`,
    `peer`
  ]);
  function fa(e2 = {}, { cacheTtlMs: t2 = ua, maxEntries: n2 = 500 } = {}) {
    let r2 = {
      ...la,
      ...e2
    }, i2 = /* @__PURE__ */ new Map(), a2 = /* @__PURE__ */ new Map(), o2 = t2;
    if (!Number.isFinite(n2) || n2 < 0) throw TypeError(`resolver: maxEntries must be a non-negative number`);
    let s2 = n2;
    async function c2(e3, t3) {
      let n3 = ha(e3), i3 = r2[n3];
      if (!i3) {
        let e4 = Object.keys(r2).sort().join(`, `);
        throw Error(`resolver: no handler for method "${n3}"; supported: ${e4}`);
      }
      return i3.resolve(e3, t3);
    }
    function l2(e3) {
      return !!(e3 && e3.didDocument && !e3.didResolutionMetadata?.error);
    }
    function u2(e3) {
      for (let [t3, n3] of i2) {
        if (i2.size < s2) return;
        n3.expires <= e3 && i2.delete(t3);
      }
      for (; i2.size >= s2; ) {
        let e4 = i2.keys().next();
        if (e4.done) return;
        i2.delete(e4.value);
      }
    }
    function d2(e3, t3) {
      let n3 = Date.now();
      u2(n3), i2.set(e3, {
        expires: n3 + o2,
        result: t3
      });
    }
    async function f2(e3, t3) {
      let n3 = ha(e3);
      if (o2 <= 0 || s2 === 0 || da.has(n3)) return c2(e3, t3);
      let r3 = Date.now(), u3 = i2.get(e3);
      if (u3) {
        if (u3.expires > r3) return i2.delete(e3), i2.set(e3, u3), u3.result;
        i2.delete(e3);
      }
      let f3 = a2.get(e3);
      return f3 || (f3 = c2(e3, t3).then((t4) => (l2(t4) && d2(e3, t4), a2.delete(e3), t4)).catch((t4) => {
        throw a2.delete(e3), t4;
      }), a2.set(e3, f3)), f3;
    }
    return {
      resolve: f2,
      clearCache() {
        i2.clear();
      },
      invalidate(e3) {
        i2.delete(e3);
      },
      setCacheTtl(e3) {
        o2 = e3, o2 <= 0 && i2.clear();
      },
      size() {
        return i2.size;
      }
    };
  }
  var pa = fa();
  ma = function(e2, t2) {
    return pa.resolve(e2, t2);
  };
  function ha(e2) {
    if (typeof e2 != `string`) throw TypeError(`resolver: DID must be a string`);
    if (!e2.startsWith(`did:`)) throw Error(`resolver: not a DID (no "did:" prefix): ${JSON.stringify(e2.slice(0, 32))}`);
    let t2 = e2.slice(4), n2 = t2.indexOf(`:`);
    if (n2 < 0) throw Error(`resolver: DID missing method-specific identifier: ${JSON.stringify(e2)}`);
    return t2.slice(0, n2);
  }
  var ga = `https://didcomm.org/routing/2.0/forward`;
  function _a({ next: e2, from: t2, mediatorDid: n2, innerJwe: r2 }) {
    ya(`next`, e2);
    let i2 = t2 != null;
    if (i2 !== (n2 != null)) throw TypeError("buildForward: pass both `from` and `mediatorDid`, or neither");
    i2 && (ya(`from`, t2), ya(`mediatorDid`, n2));
    let a2;
    if (typeof r2 == `string`) try {
      a2 = JSON.parse(r2);
    } catch (e3) {
      throw Error(`buildForward: innerJwe is not valid JSON: ${e3.message}`);
    }
    else if (r2 && typeof r2 == `object`) a2 = r2;
    else throw TypeError(`buildForward: innerJwe must be a JWE JSON string or object`);
    let o2 = {
      id: `urn:uuid:${va()}`,
      typ: `application/didcomm-plain+json`,
      type: ga,
      body: {
        next: e2
      },
      attachments: [
        {
          data: {
            json: a2
          }
        }
      ]
    };
    return i2 && (o2.from = t2, o2.to = [
      n2
    ]), o2;
  }
  function va() {
    if (typeof crypto < `u` && typeof crypto.randomUUID == `function`) return crypto.randomUUID();
    let e2 = new Uint8Array(16);
    crypto.getRandomValues(e2), e2[6] = e2[6] & 15 | 64, e2[8] = e2[8] & 63 | 128;
    let t2 = Array.from(e2).map((e3) => e3.toString(16).padStart(2, `0`)).join(``);
    return `${t2.slice(0, 8)}-${t2.slice(8, 12)}-${t2.slice(12, 16)}-${t2.slice(16, 20)}-${t2.slice(20)}`;
  }
  function ya(e2, t2) {
    if (typeof t2 != `string` || t2.length === 0) throw TypeError(`buildForward: ${e2} must be a non-empty string`);
  }
  var ba = `https://affinidi.com/atm/1.0/authenticate`;
  async function xa({ mediatorDid: e2, clientDid: t2, clientX25519Private: n2, clientX25519Public: r2, clientKid: i2, fetch: a2, netPolicy: o2, allowInsecure: s2, resolve: c2 }) {
    Pa(`mediatorDid`, e2), Pa(`clientDid`, t2), Fa(`clientX25519Private`, n2, 32), Fa(`clientX25519Public`, r2, 32);
    let l2 = a2 ?? globalThis.fetch;
    if (typeof l2 != `function`) throw Error(`mediator-auth: no fetch implementation available`);
    let u2 = wa(o2, s2), d2 = {
      netPolicy: u2
    };
    c2 && (d2.resolve = c2);
    let f2 = await Sa(e2, d2), p2 = i2 ?? Oa(t2, r2), m2 = Ai(l2, {
      ...u2,
      label: `mediator auth`,
      schemes: [
        `https:`
      ]
    }), h2 = await ka(m2, `${f2.authEndpoint}/challenge`, {
      did: t2
    }), g2 = h2?.data?.challenge, _2 = h2?.data?.session_id ?? h2?.sessionId;
    if (!g2 || !_2) throw Ma(`mediator-auth: challenge response missing challenge or session_id`, h2);
    let v2 = Math.floor(Date.now() / 1e3), y2 = {
      id: `urn:uuid:${Na()}`,
      typ: `application/didcomm-plain+json`,
      type: ba,
      from: t2,
      to: [
        e2
      ],
      created_time: v2,
      expires_time: v2 + 300,
      body: {
        challenge: g2,
        session_id: _2
      }
    }, b2 = Ie(`X25519`, n2, r2), x2 = H(`X25519`, f2.x25519Pub), S2 = await Dt({
      message: y2,
      sender: {
        kid: p2,
        privateJwk: b2
      },
      recipient: {
        kid: f2.kid,
        publicJwk: x2
      }
    }), C2 = await Aa(m2, f2.authEndpoint, S2, `application/json`), w2 = C2?.data;
    if (!w2?.access_token) throw Ma(`mediator-auth: authenticate response missing access_token`, C2);
    return {
      accessToken: w2.access_token,
      accessExpiresAt: w2.access_expires_at,
      refreshToken: w2.refresh_token,
      refreshExpiresAt: w2.refresh_expires_at,
      sessionId: C2.sessionId,
      mediator: f2
    };
  }
  async function Sa(e2, { allowInsecure: t2, netPolicy: n2, resolve: r2 = ma } = {}) {
    let { didDocument: i2 } = await r2(e2);
    if (!i2 || typeof i2 != `object`) throw Error(`mediator-auth: could not resolve mediator DID ${e2}`);
    return Ca(i2, e2, {
      allowInsecure: t2,
      netPolicy: n2
    });
  }
  function Ca(e2, t2, { allowInsecure: n2, netPolicy: r2 } = {}) {
    let i2 = wa(r2, n2);
    if (!e2 || typeof e2 != `object`) throw Error(`mediator-auth: invalid DID document for ${t2}`);
    let a2 = Array.isArray(e2.service) ? e2.service : [], o2 = a2.find((e3) => Ea(e3, `DIDCommMessaging`)), s2, c2;
    if (o2) {
      let e3 = Da(o2.serviceEndpoint);
      for (let t3 of e3) {
        let e4 = typeof t3 == `string` ? t3 : t3?.uri;
        typeof e4 == `string` && (e4.startsWith(`ws://`) || e4.startsWith(`wss://`) ? c2 = e4 : (e4.startsWith(`http://`) || e4.startsWith(`https://`)) && (s2 = e4));
      }
    }
    let l2 = a2.find((e3) => Ea(e3, `Authentication`)), u2;
    if (l2 && typeof l2.serviceEndpoint == `string` ? u2 = l2.serviceEndpoint : s2 && (u2 = `${s2.replace(/\/+$/, ``)}/authenticate`), !s2) throw Error(`mediator-auth: ${t2} has no REST DIDCommMessaging endpoint`);
    if (!u2) throw Error(`mediator-auth: ${t2} has no resolvable authenticate endpoint`);
    if (!i2.allowInsecure) {
      for (let [e3, n3] of [
        [
          `REST`,
          s2
        ],
        [
          `auth`,
          u2
        ],
        [
          `WebSocket`,
          c2
        ]
      ]) if (typeof n3 == `string` && (n3.startsWith(`http://`) || n3.startsWith(`ws://`))) throw Error(`mediator-auth: ${t2} advertises an insecure ${e3} endpoint (${n3}); pass { netPolicy: { allowInsecure: true } } to permit it`);
    }
    for (let [e3, t3, n3] of [
      [
        `REST`,
        s2,
        `https:`
      ],
      [
        `auth`,
        u2,
        `https:`
      ],
      [
        `WebSocket`,
        c2,
        `wss:`
      ]
    ]) typeof t3 == `string` && ki(t3, {
      ...i2,
      label: `mediator ${e3}`,
      schemes: [
        n3
      ]
    });
    let { kid: d2, x25519Pub: f2 } = Ta(e2, t2);
    return {
      did: t2,
      restEndpoint: s2.replace(/\/+$/, ``),
      wsEndpoint: c2 ?? null,
      authEndpoint: u2,
      kid: d2,
      x25519Pub: f2
    };
  }
  function wa(e2, t2) {
    if (e2 != null && typeof e2 != `object`) throw TypeError(`mediator-auth: netPolicy must be an object`);
    return {
      allowInsecure: !!(e2?.allowInsecure ?? t2 ?? false),
      allowPrivate: !!(e2?.allowPrivate ?? false),
      allowHosts: e2?.allowHosts ?? null
    };
  }
  function Ta(e2, t2) {
    let n2 = e2.keyAgreement;
    if (!n2 || n2.length === 0) throw Error(`mediator-auth: ${t2} has no keyAgreement entries`);
    let r2 = n2[0];
    if (typeof r2 == `string`) {
      let t3 = (e2.verificationMethod ?? []).find((e3) => e3.id === r2);
      if (!t3) throw Error(`mediator-auth: keyAgreement ref ${r2} not resolvable`);
      r2 = t3;
    }
    if (!r2.publicKeyMultibase) throw Error(`mediator-auth: keyAgreement entry has no publicKeyMultibase`);
    let { codec: i2, key: a2 } = R(r2.publicKeyMultibase);
    if (i2[0] !== 236 || i2[1] !== 1) throw Error(`mediator-auth: keyAgreement not X25519 (multicodec 0x${i2[0].toString(16)}${i2[1].toString(16)})`);
    return {
      kid: r2.id,
      x25519Pub: a2
    };
  }
  function Ea(e2, t2) {
    let n2 = e2?.type;
    return typeof n2 == `string` ? n2 === t2 : Array.isArray(n2) ? n2.includes(t2) : false;
  }
  function Da(e2) {
    return Array.isArray(e2) ? e2 : e2 == null ? [] : [
      e2
    ];
  }
  function Oa(e2, t2) {
    return `${e2}#${L(N.X25519_PUB, t2)}`;
  }
  async function ka(e2, t2, n2) {
    return ja(await e2(t2, {
      method: `POST`,
      headers: {
        "content-type": `application/json`
      },
      body: JSON.stringify(n2),
      redirect: `manual`
    }), t2);
  }
  async function Aa(e2, t2, n2, r2) {
    return ja(await e2(t2, {
      method: `POST`,
      headers: {
        "content-type": r2
      },
      body: n2,
      redirect: `manual`
    }), t2);
  }
  async function ja(e2, t2) {
    let n2 = await e2.text();
    if (!e2.ok) throw Ma(`mediator-auth: ${e2.status} from ${t2}`, n2, e2.status);
    try {
      return JSON.parse(n2);
    } catch {
      throw Ma(`mediator-auth: ${t2} returned a non-JSON body`, n2, e2.status);
    }
  }
  function Ma(e2, t2, n2) {
    let r2 = Error(e2);
    return n2 !== void 0 && (r2.status = n2), r2.body = t2, r2;
  }
  function Na() {
    if (typeof crypto < `u` && typeof crypto.randomUUID == `function`) return crypto.randomUUID();
    let e2 = new Uint8Array(16);
    crypto.getRandomValues(e2), e2[6] = e2[6] & 15 | 64, e2[8] = e2[8] & 63 | 128;
    let t2 = Array.from(e2).map((e3) => e3.toString(16).padStart(2, `0`)).join(``);
    return `${t2.slice(0, 8)}-${t2.slice(8, 12)}-${t2.slice(12, 16)}-${t2.slice(16, 20)}-${t2.slice(20)}`;
  }
  function Pa(e2, t2) {
    if (typeof t2 != `string` || t2.length === 0) throw TypeError(`mediator-auth: ${e2} must be a non-empty string`);
  }
  function Fa(e2, t2, n2) {
    if (!(t2 instanceof Uint8Array)) throw TypeError(`mediator-auth: ${e2} must be Uint8Array`);
    if (n2 !== void 0 && t2.length !== n2) throw Error(`mediator-auth: ${e2} must be ${n2} bytes, got ${t2.length}`);
  }
  var Ia = [
    `--E`,
    `-E`
  ];
  function La(e2) {
    return typeof e2 == `string` && Ia.some((t2) => e2.startsWith(t2));
  }
  var Ra = `https://didcomm.org/messagepickup/3.0/live-delivery-change`, za = `https://didcomm.org/messagepickup/3.0/messages-received`, Ba = `https://didcomm.org/report-problem/2.0/problem-report`, Va = `didcomm`;
  function Ha(e2) {
    switch (e2) {
      case void 0:
      case null:
        return `no close code (the implementation passed no close event)`;
      case 1e3:
        return `normal closure`;
      case 1001:
        return `endpoint going away`;
      case 1002:
        return `protocol error \u2014 likely a subprotocol mismatch (the mediator must echo a Sec-WebSocket-Protocol)`;
      case 1005:
        return `no status received`;
      case 1006:
        return `abnormal closure \u2014 no close frame was sent. The HTTP upgrade was most likely refused outright (401/403/426), or a TLS/DNS/network failure occurred, or a reverse proxy is not configured to pass WebSocket upgrades on this path. If REST auth succeeds but the WS gives 1006, suspect a 401/403 on the upgrade (stale/expired bearer, or the client DID is not in the MEDIATOR's ACL \u2014 distinct from the VTA's ACL) or a proxy that strips the Upgrade header`;
      case 1008:
        return `policy violation \u2014 the mediator rejected the connection. Re-authenticate to the mediator, and confirm the client DID is permitted by the MEDIATOR's ACL (updating the target VTA's ACL does NOT change the mediator's gate)`;
      case 1011:
        return `mediator internal error \u2014 check mediator logs`;
      case 1015:
        return `TLS handshake failure \u2014 certificate/SNI/protocol problem reaching the wss endpoint`;
      default:
        return e2 >= 4e3 ? `application-specific close code ${e2} \u2014 see mediator logs` : `close code ${e2}`;
    }
  }
  function Ua(e2) {
    typeof console < `u` && typeof console.warn == `function` && console.warn(e2?.message ?? e2);
  }
  function Wa(e2) {
    if (typeof e2 != `string`) return null;
    let t2 = e2.split(`.`);
    if (t2.length < 2) return null;
    try {
      let e3 = JSON.parse(new TextDecoder().decode(j(t2[1])));
      return typeof e3.exp == `number` ? e3.exp : null;
    } catch {
      return null;
    }
  }
  var Ga = 256, Ka = 1024;
  function qa({ from: e2, mediatorDid: t2, live: n2 = true }) {
    let r2 = Math.floor(Date.now() / 1e3);
    return {
      id: `urn:uuid:${oo()}`,
      typ: `application/didcomm-plain+json`,
      type: Ra,
      from: e2,
      to: [
        t2
      ],
      created_time: r2,
      expires_time: r2 + 300,
      return_route: `all`,
      body: {
        live_delivery: n2
      }
    };
  }
  function Ja({ from: e2, mediatorDid: t2, messageIds: n2 }) {
    let r2 = Math.floor(Date.now() / 1e3);
    return {
      id: `urn:uuid:${oo()}`,
      typ: `application/didcomm-plain+json`,
      type: za,
      from: e2,
      to: [
        t2
      ],
      created_time: r2,
      expires_time: r2 + 300,
      return_route: `all`,
      body: {
        message_id_list: n2
      }
    };
  }
  function Ya(e2) {
    let t2;
    try {
      t2 = JSON.parse(e2);
    } catch {
      return null;
    }
    if (!t2 || typeof t2.protected != `string`) return null;
    try {
      let e3 = JSON.parse(new TextDecoder().decode(j(t2.protected)));
      return typeof e3.skid == `string` ? e3.skid : null;
    } catch {
      return null;
    }
  }
  var Xa = `E_UNAUTHENTICATED_FRAME`, Za = /* @__PURE__ */ new Set([
    Mt,
    Xa
  ]);
  function Qa(e2, t2) {
    return typeof t2 == `string` && t2.startsWith(`#`) ? `${e2}${t2}` : t2;
  }
  function $a(e2, t2, n2) {
    return (Array.isArray(e2) ? e2 : e2 ? [
      e2
    ] : []).find((e3) => e3?.publicJwk && Qa(t2, e3.kid) === n2);
  }
  async function eo(e2, { recipient: t2, senderKeys: n2, resolveSender: r2 }) {
    let i2 = Ya(e2);
    if (!i2) throw Error(`mediator-transport: inbound frame has no skid (anoncrypt not supported)`);
    let a2 = Nt(i2), o2 = $a(n2.get(a2), a2, i2);
    if (!o2 && typeof r2 == `function` && (o2 = $a(await r2(a2, i2), a2, i2)), !o2) throw Error(`mediator-transport: no key ${i2} for sender ${a2}`);
    let s2 = await Ft(e2, t2, o2);
    if (!s2.authenticated) {
      let e3 = Error(`mediator-transport: inbound frame is not sender-authenticated`);
      throw e3.code = Xa, e3;
    }
    return s2;
  }
  var to = class {
    constructor({ mediator: e2, mediatorJwt: t2, client: n2, senderKeys: r2, resolveSender: i2, WebSocketImpl: a2, onMessage: o2, onMediatorMessage: s2, onTspFrame: c2, onClose: l2, onError: u2, connectTimeoutMs: d2, netPolicy: f2 }) {
      if (!e2?.wsEndpoint) throw Error(`MediatorSession: mediator.wsEndpoint required (mediator advertises no wss endpoint)`);
      if (f2 != null && typeof f2 != `object`) throw TypeError(`MediatorSession: netPolicy must be an object`);
      if (this._wsPolicy = {
        allowInsecure: !!f2?.allowInsecure,
        allowPrivate: !!f2?.allowPrivate,
        allowHosts: f2?.allowHosts ?? null,
        label: `mediator WebSocket`,
        schemes: [
          `wss:`
        ]
      }, ki(e2.wsEndpoint, this._wsPolicy), this.mediator = e2, this.mediatorJwt = t2, this.connectTimeoutMs = d2 ?? 15e3, this.client = n2, this.senderKeys = r2 ?? /* @__PURE__ */ new Map(), this.resolveSender = i2, this.onMessage = o2, this.onMediatorMessage = s2, this.onTspFrame = c2, this.onClose = l2, this.onError = u2 ?? Ua, this._userClosed = false, this.WebSocketImpl = a2 ?? globalThis.WebSocket, typeof this.WebSocketImpl != `function`) throw Error(`MediatorSession: no WebSocket implementation available`);
      this.senderKeys.set(e2.did, {
        kid: e2.kid,
        publicJwk: H(`X25519`, e2.x25519Pub)
      }), this.ws = null, this._inbox = [], this._waiters = [], this._seen = /* @__PURE__ */ new Set();
    }
    get _recipient() {
      return {
        kid: this.client.kid,
        privateJwk: Ie(`X25519`, this.client.privateKey, this.client.publicKey)
      };
    }
    async connect() {
      await this._openSocket();
      let e2 = await Dt({
        message: qa({
          from: this.client.did,
          mediatorDid: this.mediator.did
        }),
        sender: {
          kid: this.client.kid,
          privateJwk: Ie(`X25519`, this.client.privateKey, this.client.publicKey)
        },
        recipient: {
          kid: this.mediator.kid,
          publicJwk: H(`X25519`, this.mediator.x25519Pub)
        }
      });
      this.ws.send(e2);
    }
    _openSocket() {
      return new Promise((e2, t2) => {
        let n2 = false, r2 = false, i2 = null, a2 = (e3, t3) => !n2 && (n2 = true, i2 && clearTimeout(i2), e3(t3), true);
        ki(this.mediator.wsEndpoint, this._wsPolicy);
        let o2 = new this.WebSocketImpl(this.mediator.wsEndpoint, [
          `bearer.${this.mediatorJwt}`,
          Va
        ]);
        this.ws = o2, this.connectTimeoutMs > 0 && (i2 = setTimeout(() => {
          a2(t2, this._connectError({
            reason: `no open/close within ${this.connectTimeoutMs}ms`,
            hint: `the upgrade was silently dropped \u2014 a reverse proxy or firewall not configured to pass WebSocket upgrades on this path will hang rather than reject`
          }));
          try {
            o2.close();
          } catch {
          }
        }, this.connectTimeoutMs)), o2.onopen = () => a2(e2), o2.onmessage = (e3) => this._onFrame(e3.data), o2.onerror = () => {
          if (r2 = true, n2) for (let e3 of this._waiters.splice(0)) clearTimeout(e3.timer), e3.reject(Error(`mediator-transport: WebSocket error`));
        }, o2.onclose = (e3) => {
          let n3 = e3?.code, i3 = e3?.reason;
          if (!a2(t2, this._connectError({
            code: n3,
            reason: i3,
            sawError: r2,
            hint: Ha(n3)
          }))) {
            for (let e4 of this._waiters.splice(0)) clearTimeout(e4.timer), e4.reject(Error(`mediator-transport: WebSocket closed`));
            if (!this._userClosed && this.onClose) try {
              this.onClose();
            } catch {
            }
          }
        };
      });
    }
    _connectError({ code: e2, reason: t2, sawError: n2, hint: r2 }) {
      let i2 = [
        `mediator-transport: WebSocket failed to open`
      ];
      e2 == null ? n2 && i2.push(`(error before close \u2014 no code provided by the browser)`) : i2.push(`(close code ${e2}${t2 ? ` "${t2}"` : ``})`), r2 && i2.push(`\u2014 ${r2}`);
      let a2 = Wa(this.mediatorJwt);
      if (a2 != null) {
        let e3 = a2 * 1e3, t3 = e3 - this._nowMs();
        t3 <= 0 && i2.push(`\u2014 bearer token is already EXPIRED (exp ${new Date(e3).toISOString()}, ${Math.round(-t3 / 1e3)}s ago); re-authenticate, and check client/mediator clock skew`);
      }
      let o2 = Error(i2.join(` `));
      return o2.code = e2, o2.reason = t2, o2.endpoint = this.mediator.wsEndpoint, o2;
    }
    _nowMs() {
      return (/* @__PURE__ */ new Date()).getTime();
    }
    _reportFrameError(e2, t2, n2) {
      let r2 = typeof n2 == `string` ? `${n2.slice(0, 12)}\u2026(${n2.length}b)` : `n/a`;
      try {
        this.onError(Error(`mediator-transport: failed to ${e2} [frame ${r2}]: ${t2?.message ?? t2}`), {
          stage: e2,
          cause: t2,
          frameFingerprint: r2
        });
      } catch {
      }
    }
    send(e2) {
      if (!this.ws) throw Error(`mediator-transport: not connected`);
      this.ws.send(e2);
    }
    sendBinary(e2) {
      if (!this.ws) throw Error(`mediator-transport: not connected`);
      this.ws.send(e2);
    }
    async _onFrame(e2) {
      let t2;
      try {
        t2 = typeof e2 == `string` ? e2 : new TextDecoder().decode(e2);
      } catch (e3) {
        this._reportFrameError(`decode inbound frame bytes`, e3, null);
        return;
      }
      if (La(t2)) {
        let e3;
        try {
          e3 = j(t2);
        } catch (e4) {
          this._reportFrameError(`decode inbound TSP frame`, e4, t2);
          return;
        }
        await this._dispatchTspFrame(e3, t2);
        return;
      }
      let n2;
      try {
        n2 = await eo(t2, {
          recipient: this._recipient,
          senderKeys: this.senderKeys,
          resolveSender: this.resolveSender
        });
      } catch (e3) {
        if (Za.has(e3?.code) && Ya(t2)?.split(`#`)[0] !== this.mediator.did) {
          this._reportFrameError(`accept inbound frame (refused and dropped)`, e3, t2);
          let n3 = await so(t2);
          this._markSeen(n3), this._ackReceived(n3);
          return;
        }
        this._reportFrameError(`unpack inbound frame`, e3, t2);
        return;
      }
      try {
        await this._dispatchFrame(n2, t2);
      } catch (e3) {
        this._reportFrameError(`dispatch inbound message`, e3, t2);
      }
    }
    async _dispatchTspFrame(e2, t2) {
      if (!this.onTspFrame) return;
      let n2 = await so(t2);
      if (this._seen.has(n2)) {
        this._ackReceived(n2);
        return;
      }
      try {
        await this.onTspFrame(e2);
      } catch (e3) {
        this._reportFrameError(`dispatch inbound TSP frame`, e3, t2);
        return;
      }
      this._markSeen(n2), this._ackReceived(n2);
    }
    async _dispatchFrame(e2, t2) {
      let n2 = e2.senderDid ?? null, r2 = n2 === this.mediator.did, i2 = n2 && (!r2 || ao(e2.message)) ? await so(t2) : null;
      if (i2 && this._seen.has(i2)) {
        this._ackReceived(i2);
        return;
      }
      await this._deliver(e2), i2 && (this._markSeen(i2), this._ackReceived(i2));
    }
    async _deliver(e2) {
      let t2 = e2.message;
      if (typeof e2.senderDid != `string` || typeof e2.senderKid != `string`) throw Error(`mediator-transport: inbound message has no authenticated sender`);
      let n2 = Object.freeze({
        did: e2.senderDid,
        kid: e2.senderKid
      }), r2 = io(t2), i2 = this._waiters.findIndex((e3) => e3.thid === r2 && ro(e3.from, n2));
      if (i2 >= 0) {
        let [e3] = this._waiters.splice(i2, 1);
        clearTimeout(e3.timer), e3.resolve({
          message: t2,
          sender: n2
        });
        return;
      }
      let a2 = n2.did === this.mediator.did, o2 = a2 && this.onMediatorMessage ? this.onMediatorMessage : this.onMessage;
      if (a2 && t2.thid == null && t2.pthid == null || (this._inbox.push({
        thid: r2,
        message: t2,
        sender: n2
      }), this._inbox.length > Ga && this._inbox.shift()), o2) try {
        await o2(t2, r2, n2);
      } catch {
      }
    }
    _markSeen(e2) {
      this._seen.add(e2), this._seen.size > Ka && this._seen.delete(this._seen.values().next().value);
    }
    async _ackReceived(e2) {
      let t2 = Array.isArray(e2) ? e2 : [
        e2
      ];
      if (t2.length !== 0) try {
        if (!this.ws || this.ws.readyState !== 1) return;
        let e3 = await Dt({
          message: Ja({
            from: this.client.did,
            mediatorDid: this.mediator.did,
            messageIds: t2
          }),
          sender: {
            kid: this.client.kid,
            privateJwk: Ie(`X25519`, this.client.privateKey, this.client.publicKey)
          },
          recipient: {
            kid: this.mediator.kid,
            publicJwk: H(`X25519`, this.mediator.x25519Pub)
          }
        });
        this.ws.send(e3);
      } catch {
      }
    }
    waitFor(e2, t2, n2 = {}) {
      let r2 = no(n2?.from), i2 = this._inbox.findIndex((t3) => t3.thid === e2 && ro(r2, t3.sender));
      if (i2 >= 0) {
        let [e3] = this._inbox.splice(i2, 1);
        return Promise.resolve({
          message: e3.message,
          sender: e3.sender
        });
      }
      return new Promise((n3, i3) => {
        let a2 = setTimeout(() => {
          let t3 = this._waiters.findIndex((e3) => e3.timer === a2);
          t3 >= 0 && this._waiters.splice(t3, 1), i3(Error(`mediator-transport: timeout waiting for response (thid ${e2})`));
        }, t2);
        this._waiters.push({
          thid: e2,
          from: r2,
          resolve: n3,
          reject: i3,
          timer: a2
        });
      });
    }
    get isOpen() {
      return !!this.ws && this.ws.readyState === 1;
    }
    close() {
      this._userClosed = true;
      for (let e2 of this._waiters.splice(0)) clearTimeout(e2.timer), e2.reject(Error(`mediator-transport: session closed`));
      try {
        this.ws?.close();
      } catch {
      }
      this.ws = null;
    }
  };
  function no(e2) {
    if (e2 == null) return null;
    let t2 = typeof e2 == `string` ? [
      e2
    ] : Array.from(e2);
    if (t2.length === 0 || t2.some((e3) => typeof e3 != `string` || e3.length === 0)) throw TypeError("mediator-transport: waitFor `from` must be a DID or a non-empty list of DIDs");
    return t2;
  }
  function ro(e2, t2) {
    return e2 === null || e2.includes(t2.did);
  }
  function io(e2) {
    return e2.thid == null ? e2.type === Ba && e2.pthid != null ? e2.pthid : e2.id : e2.thid;
  }
  function ao(e2) {
    return e2.type === `https://trusttasks.org/binding/didcomm/0.1/envelope` && e2.thid != null;
  }
  function oo() {
    if (typeof crypto < `u` && typeof crypto.randomUUID == `function`) return crypto.randomUUID();
    let e2 = new Uint8Array(16);
    crypto.getRandomValues(e2), e2[6] = e2[6] & 15 | 64, e2[8] = e2[8] & 63 | 128;
    let t2 = Array.from(e2).map((e3) => e3.toString(16).padStart(2, `0`)).join(``);
    return `${t2.slice(0, 8)}-${t2.slice(8, 12)}-${t2.slice(12, 16)}-${t2.slice(16, 20)}-${t2.slice(20)}`;
  }
  async function so(e2) {
    let t2 = new TextEncoder().encode(e2), n2 = await crypto.subtle.digest(`SHA-256`, t2);
    return Array.from(new Uint8Array(n2)).map((e3) => e3.toString(16).padStart(2, `0`)).join(``);
  }
  async function co(e2, { netPolicy: t2 } = {}) {
    let { didDocument: n2 } = await ma(e2, {
      netPolicy: t2
    });
    if (!n2 || typeof n2 != `object`) throw Error(`vta-didcomm: could not resolve a DID document for ${e2}`);
    let r2 = n2.keyAgreement;
    if (!r2 || r2.length === 0) throw Error(`vta-didcomm: ${e2} has no keyAgreement entries`);
    let i2 = r2[0];
    if (typeof i2 == `string`) {
      let e3 = (n2.verificationMethod ?? []).find((e4) => e4.id === i2);
      if (!e3) throw Error(`vta-didcomm: keyAgreement ref ${i2} not resolvable`);
      i2 = e3;
    }
    if (!i2.publicKeyMultibase) throw Error(`vta-didcomm: keyAgreement entry has no publicKeyMultibase`);
    let { codec: a2, key: o2 } = R(i2.publicKeyMultibase);
    if (a2[0] !== 236 || a2[1] !== 1) throw Error(`vta-didcomm: keyAgreement not X25519 (multicodec 0x${a2[0].toString(16)}${a2[1].toString(16)})`);
    return {
      kid: i2.id,
      x25519Pub: o2
    };
  }
  async function lo(e2, t2, { netPolicy: n2 } = {}) {
    let { didDocument: r2 } = await ma(e2, {
      netPolicy: n2
    });
    if (!r2 || typeof r2 != `object`) throw Error(`vta-didcomm: could not resolve a DID document for ${e2}`);
    let i2 = (t3) => typeof t3 == `string` && t3.startsWith(`#`) ? `${e2}${t3}` : t3, a2 = r2.verificationMethod ?? [], o2;
    for (let e3 of r2.keyAgreement ?? []) if (i2(typeof e3 == `string` ? e3 : e3?.id) === t2) {
      o2 = typeof e3 == `string` ? a2.find((e4) => i2(e4.id) === t2) : e3;
      break;
    }
    if (!o2) throw Error(`vta-didcomm: ${e2} lists no keyAgreement key ${t2}`);
    if (!o2.publicKeyMultibase) throw Error(`vta-didcomm: keyAgreement entry has no publicKeyMultibase`);
    let { codec: s2, key: c2 } = R(o2.publicKeyMultibase);
    if (s2[0] !== 236 || s2[1] !== 1) throw Error(`vta-didcomm: keyAgreement key is not X25519`);
    return {
      kid: t2,
      x25519Pub: c2
    };
  }
  var uo = /* @__PURE__ */ new WeakMap();
  function fo(e2) {
    let t2 = uo.get(e2);
    if (!t2) throw Error(`Identity has been disposed`);
    return t2;
  }
  po = class e2 {
    did;
    kid;
    constructor(e3, t2, n2) {
      this.did = e3, this.kid = t2, uo.set(this, {
        kid: t2,
        privateJwk: n2
      });
    }
    static generate(t2) {
      let { privateKey: n2, publicKey: r2 } = qe(), i2 = Ie(`X25519`, n2, r2);
      return new e2(t2, `${t2}#key-1`, {
        kty: `OKP`,
        crv: `X25519`,
        x: i2.x,
        d: i2.d
      });
    }
    static fromSecretJwk(t2) {
      if (!t2.jwk.d) throw TypeError(`Identity.fromSecretJwk: jwk.d (private scalar) required`);
      return new e2(t2.did, t2.kid, {
        ...t2.jwk
      });
    }
    publicJwk() {
      let { privateJwk: e3 } = fo(this), t2 = {
        kty: e3.kty,
        crv: e3.crv,
        x: e3.x
      };
      return e3.y !== void 0 && (t2.y = e3.y), {
        kid: this.kid,
        jwk: t2
      };
    }
    secretJwk() {
      let { privateJwk: e3 } = fo(this);
      return {
        did: this.did,
        kid: this.kid,
        jwk: {
          ...e3
        }
      };
    }
    dispose() {
      uo.delete(this);
    }
  };
  function mo(e2) {
    return e2.id ? e2 : {
      ...e2,
      id: globalThis.crypto.randomUUID()
    };
  }
  function ho(e2) {
    let t2 = e2[0];
    if (e2.length !== 1 || !t2) throw Error(`DIDComm facade packs to exactly one recipient, got ${e2.length}`);
    return t2;
  }
  go = function(e2, t2, n2) {
    let r2 = fo(t2), i2 = ho(n2);
    return Dt({
      message: JSON.parse(e2),
      sender: {
        kid: r2.kid,
        privateJwk: r2.privateJwk
      },
      recipient: {
        kid: i2.kid,
        publicJwk: i2.jwk
      }
    });
  };
  _o = function(e2, t2, n2, r2) {
    return JSON.stringify(_a({
      next: e2,
      from: t2,
      mediatorDid: n2,
      innerJwe: r2
    }));
  };
  vo = function(e2, t2, n2) {
    let r2 = fo(t2), i2 = ho(n2);
    return Dt({
      message: mo(e2),
      sender: {
        kid: r2.kid,
        privateJwk: r2.privateJwk
      },
      recipient: {
        kid: i2.kid,
        publicJwk: i2.jwk
      }
    });
  };
  function yo(e2, t2) {
    try {
      let n2 = JSON.parse(e2).recipients ?? [];
      if (n2.some((e3) => e3?.header?.kid === t2)) return t2;
      let r2 = n2.length === 1 ? n2[0]?.header?.kid : void 0;
      if (typeof r2 == `string`) return r2;
    } catch {
    }
    return t2;
  }
  bo = async function(e2, t2) {
    let n2 = fo(t2), r2 = yo(e2.input, n2.kid), i2 = await Ft(e2.input, {
      kid: r2,
      privateJwk: n2.privateJwk
    }, e2.sender_public_jwk ? {
      publicJwk: e2.sender_public_jwk
    } : void 0), a2 = {
      kind: `encrypted`,
      message: i2.message,
      authenticated: i2.authenticated,
      recipient_kid: r2
    };
    return i2.senderKid && (a2.sender_kid = i2.senderKid), i2.senderDid && (a2.sender_did = i2.senderDid), a2;
  };
  function xo(e2) {
    return {
      kty: `OKP`,
      crv: `X25519`,
      x: H(`X25519`, e2).x
    };
  }
  So = async function(e2) {
    let { kid: t2, x25519Pub: n2 } = await co(e2);
    return {
      did: e2,
      keyAgreementKid: t2,
      keyAgreementPublicJwk: xo(n2)
    };
  };
  Co = async function(e2, t2 = {}) {
    let n2 = await Sa(e2, {
      ...t2.netPolicy ? {
        netPolicy: t2.netPolicy
      } : {},
      ...t2.resolve ? {
        resolve: t2.resolve
      } : {}
    });
    if (!n2.wsEndpoint) throw Error(`mediator ${e2} advertises no WebSocket endpoint for live delivery`);
    return {
      did: n2.did,
      keyAgreementKid: n2.kid,
      keyAgreementPublicJwk: xo(n2.x25519Pub),
      websocketUrl: n2.wsEndpoint,
      restEndpoint: n2.restEndpoint,
      authEndpoint: n2.authEndpoint
    };
  };
  function wo(e2) {
    if (Array.isArray(e2)) return e2[0]?.uri;
    if (e2 && typeof e2 == `object`) return e2.uri;
    if (typeof e2 == `string`) return e2;
  }
  To = async function(e2) {
    let t2 = await ma(e2, {});
    if (!t2.didDocument) throw Error(`could not resolve DID document for ${e2}`);
    return t2.didDocument;
  };
  Eo = async function(e2) {
    let t2 = (await ma(e2, {})).didDocument?.service ?? [], n2 = {};
    for (let e3 of t2) {
      let t3 = (e3.id ?? ``).split(`#`)[1];
      if ((t3 === `vta-rest` || e3.type === `VTARest`) && typeof e3.serviceEndpoint == `string` && (n2.rest = {
        baseUrl: e3.serviceEndpoint
      }), t3 === `vta-didcomm` || e3.type === `DIDCommMessaging`) {
        let r2 = wo(e3.serviceEndpoint);
        r2 && (t3 === `vta-didcomm` || !n2.didcomm) && (n2.didcomm = {
          mediatorDid: r2
        });
      }
      if (e3.type === `TSPTransport`) {
        let t4 = wo(e3.serviceEndpoint);
        t4 && !n2.tsp && (n2.tsp = {
          mediatorDid: t4
        });
      }
    }
    return n2;
  };
  var Do = xa;
  Oo = async function(e2) {
    let t2 = fo(e2.holder).privateJwk, n2 = Re(t2), r2 = Le(t2), i2 = await Do({
      mediatorDid: e2.mediatorDid,
      clientDid: e2.holder.did,
      clientX25519Private: n2,
      clientX25519Public: r2,
      clientKid: e2.holder.kid,
      ...e2.netPolicy ? {
        netPolicy: e2.netPolicy
      } : {},
      ...e2.resolve ? {
        resolve: e2.resolve
      } : {},
      ...e2.fetch ? {
        fetch: e2.fetch
      } : {}
    }), a2 = await So(e2.vtaDid), o2 = /* @__PURE__ */ new Map([
      [
        e2.vtaDid,
        {
          kid: a2.keyAgreementKid,
          publicJwk: a2.keyAgreementPublicJwk
        }
      ]
    ]), s2 = [], c2, l2 = /* @__PURE__ */ new Set(), u2 = (e3) => {
      for (; s2.length; ) {
        let t3 = s2.shift();
        clearTimeout(t3.timer), t3.reject(e3);
      }
    }, d2 = new to({
      mediator: i2.mediator,
      mediatorJwt: i2.accessToken,
      client: {
        did: e2.holder.did,
        kid: e2.holder.kid,
        privateKey: n2,
        publicKey: r2
      },
      senderKeys: o2,
      resolveSender: async (e3, t3) => {
        let n3 = await lo(e3, t3);
        return {
          kid: n3.kid,
          publicJwk: xo(n3.x25519Pub)
        };
      },
      onTspFrame: async (e3) => {
        for (let t3 = 0; t3 < s2.length; t3++) {
          let n3 = s2[t3], r3 = false;
          try {
            r3 = await n3.claims(e3);
          } catch {
            r3 = false;
          }
          if (r3) {
            s2.splice(t3, 1), clearTimeout(n3.timer), n3.resolve(e3);
            return;
          }
        }
        c2 && await c2(e3);
      },
      onMediatorMessage: (e3) => {
        for (let t3 of l2) try {
          t3(e3);
        } catch (e4) {
          console.warn(`[mediator] a mediator-frame listener threw:`, e4);
        }
      },
      ...e2.netPolicy ? {
        netPolicy: e2.netPolicy
      } : {},
      ...e2.onClose ? {
        onClose: e2.onClose
      } : {},
      ...e2.webSocketImpl ? {
        WebSocketImpl: e2.webSocketImpl
      } : {}
    });
    await d2.connect();
    let f2 = d2;
    return {
      send: (e3) => d2.send(e3),
      waitFor: async (t3, n3, r3) => {
        try {
          let { message: e3 } = await d2.waitFor(t3, n3, r3?.from ? {
            from: r3.from
          } : {});
          return e3;
        } catch (t4) {
          throw /timeout waiting for response/.test(t4.message) && e2.onReplyTimeout?.(), t4;
        }
      },
      sendBinary: (e3) => d2.sendBinary(e3),
      awaitTspFrame: (t3, n3) => new Promise((r3, i3) => {
        let a3 = {
          resolve: r3,
          reject: i3,
          claims: n3,
          timer: setTimeout(() => {
            let t4 = s2.indexOf(a3);
            t4 >= 0 && s2.splice(t4, 1), i3(Error(`timed out awaiting reply frame`)), e2.onReplyTimeout?.();
          }, t3)
        };
        s2.push(a3);
      }),
      close: () => {
        u2(Error(`mediator session closed`)), d2.close();
      },
      get isOpen() {
        return f2.isOpen;
      },
      expiresAt: typeof i2.accessExpiresAt == `number` ? i2.accessExpiresAt * 1e3 : void 0,
      onInbound: (e3) => {
        d2.onMessage = e3;
      },
      onInboundTsp: (e3) => {
        c2 = e3;
      },
      onMediatorFrame: (e3) => (l2.add(e3), () => {
        l2.delete(e3);
      }),
      vta: a2,
      mediator: {
        did: i2.mediator.did,
        keyAgreementKid: i2.mediator.kid,
        keyAgreementPublicJwk: xo(i2.mediator.x25519Pub)
      }
    };
  };
})();
export {
  A as S,
  N as _,
  __tla,
  To as a,
  L as b,
  Eo as c,
  ma as d,
  Ai as f,
  ue as g,
  Te as h,
  go as i,
  bo as l,
  Wt as m,
  Oo as n,
  So as o,
  cn as p,
  vo as r,
  Co as s,
  po as t,
  _o as u,
  F as v,
  j as x,
  R as y
};
