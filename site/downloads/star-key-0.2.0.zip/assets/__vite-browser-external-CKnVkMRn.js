import { t as e } from "./rolldown-runtime-Dd_uD5pT.js";
var t = e(((e2, t2) => {
  t2.exports = {};
}));
var stdin_default = t();
export {
  stdin_default as default
};
