import { i as e } from "./rolldown-runtime-Dd_uD5pT.js";
import { a as t, r as n } from "./theme-pbhxFgxu.js";
import { m as r, z as i } from "./host-permissions-TPtLahe0.js";
import { Ct as a, Et as o, Q as s, Tt as c, Z as l, at as u, it as d, wt as f } from "./bridge-protocol-DoEW6v30.js";
async function p() {
  return m((await chrome.storage.local.get(`pnm-connection/v3`))[`pnm-connection/v3`]);
}
function m(e2) {
  if (typeof e2 != `string`) return null;
  try {
    return JSON.parse(e2).state?.connections?.activeVtaDid ?? null;
  } catch {
    return null;
  }
}
async function h() {
  let e2 = (await chrome.storage.local.get(`pnm-connection/v3`))[`pnm-connection/v3`];
  if (typeof e2 != `string`) return null;
  try {
    let t2 = JSON.parse(e2).state?.connections;
    return t2?.activeVtaDid ? t2.vtas?.[t2.activeVtaDid]?.holderDid ?? null : null;
  } catch {
    return null;
  }
}
var g = e(t(), 1), _ = (e2) => {
  let t2, n2 = /* @__PURE__ */ new Set(), r2 = (e3, r3) => {
    let i3 = typeof e3 == `function` ? e3(t2) : e3;
    if (!Object.is(i3, t2)) {
      let e4 = t2;
      t2 = r3 ?? (typeof i3 != `object` || !i3) ? i3 : Object.assign({}, t2, i3), n2.forEach((n3) => n3(t2, e4));
    }
  }, i2 = () => t2, a2 = { setState: r2, getState: i2, getInitialState: () => o2, subscribe: (e3) => (n2.add(e3), () => n2.delete(e3)) }, o2 = t2 = e2(r2, i2, a2);
  return a2;
}, v = ((e2) => e2 ? _(e2) : _), y = (e2) => e2;
function b(e2, t2 = y) {
  let n2 = g.useSyncExternalStore(e2.subscribe, g.useCallback(() => t2(e2.getState()), [e2, t2]), g.useCallback(() => t2(e2.getInitialState()), [e2, t2]));
  return g.useDebugValue(n2), n2;
}
var x = (e2) => {
  let t2 = v(e2), n2 = (e3) => b(t2, e3);
  return Object.assign(n2, t2), n2;
}, S = ((e2) => e2 ? x(e2) : x);
function C(e2, t2) {
  let n2;
  try {
    n2 = e2();
  } catch {
    return;
  }
  return { getItem: (e3) => {
    let r2 = (e4) => e4 === null ? null : JSON.parse(e4, t2?.reviver), i2 = n2.getItem(e3) ?? null;
    return i2 instanceof Promise ? i2.then(r2) : r2(i2);
  }, setItem: (e3, r2) => n2.setItem(e3, JSON.stringify(r2, t2?.replacer)), removeItem: (e3) => n2.removeItem(e3) };
}
var w = (e2) => (t2) => {
  try {
    let n2 = e2(t2);
    return n2 instanceof Promise ? n2 : { then(e3) {
      return w(e3)(n2);
    }, catch(e3) {
      return this;
    } };
  } catch (e3) {
    return { then(e4) {
      return this;
    }, catch(t3) {
      return w(t3)(e3);
    } };
  }
}, T = (e2, t2) => (n2, r2, i2) => {
  let a2 = { storage: C(() => window.localStorage), partialize: (e3) => e3, version: 0, merge: (e3, t3) => ({ ...t3, ...e3 }), ...t2 }, o2 = false, s2 = 0, c2 = /* @__PURE__ */ new Set(), l2 = /* @__PURE__ */ new Set(), u2 = a2.storage;
  if (!u2) return e2((...e3) => {
    console.warn(`[zustand persist middleware] Unable to update item '${a2.name}', the given storage is currently unavailable.`), n2(...e3);
  }, r2, i2);
  let d2 = () => {
    let e3 = a2.partialize({ ...r2() });
    return u2.setItem(a2.name, { state: e3, version: a2.version });
  }, f2 = i2.setState;
  i2.setState = (e3, t3) => (f2(e3, t3), d2());
  let p2 = e2((...e3) => (n2(...e3), d2()), r2, i2);
  i2.getInitialState = () => p2;
  let m2, h2 = () => {
    if (!u2) return;
    let e3 = ++s2;
    o2 = false, c2.forEach((e4) => e4(r2() ?? p2));
    let t3 = a2.onRehydrateStorage?.call(a2, r2() ?? p2) || void 0;
    return w(u2.getItem.bind(u2))(a2.name).then((e4) => {
      if (e4) {
        if (typeof e4.version == `number` && e4.version !== a2.version) {
          if (a2.migrate) {
            let t4 = a2.migrate(e4.state, e4.version);
            return t4 instanceof Promise ? t4.then((e5) => [true, e5]) : [true, t4];
          }
          console.error(`State loaded from storage couldn't be migrated since no migrate function was provided`);
        } else return [false, e4.state];
      }
      return [false, void 0];
    }).then((t4) => {
      if (e3 !== s2) return;
      let [i3, o3] = t4;
      if (m2 = a2.merge(o3, r2() ?? p2), n2(m2, true), i3) return d2();
    }).then(() => {
      e3 === s2 && (t3?.(r2(), void 0), m2 = r2(), o2 = true, l2.forEach((e4) => e4(m2)));
    }).catch((n3) => {
      e3 === s2 && t3?.(void 0, n3);
    });
  };
  return i2.persist = { setOptions: (e3) => {
    a2 = { ...a2, ...e3 }, e3.storage && (u2 = e3.storage);
  }, clearStorage: () => {
    ++s2, u2?.removeItem(a2.name);
  }, getOptions: () => a2, rehydrate: () => h2(), hasHydrated: () => o2, onHydrate: (e3) => (c2.add(e3), () => {
    c2.delete(e3);
  }), onFinishHydration: (e3) => (l2.add(e3), () => {
    l2.delete(e3);
  }) }, a2.skipHydration || h2(), m2 || p2;
};
function E(e2, t2) {
  let { restBaseUrl: n2, mediatorDid: r2, tspMediatorDid: i2, ...a2 } = e2;
  return { ...a2, ...t2.restBaseUrl ? { restBaseUrl: t2.restBaseUrl } : {}, ...t2.mediatorDid ? { mediatorDid: t2.mediatorDid } : {}, ...t2.tspMediatorDid ? { tspMediatorDid: t2.tspMediatorDid } : {} };
}
var D = `pnm-connection/v3`, O, k = { getItem: (e2) => new Promise((t2) => {
  chrome.storage.local.get(e2, (n2) => {
    let r2 = n2[e2];
    t2(typeof r2 == `string` ? r2 : null);
  });
}), setItem: (e2, t2) => new Promise((n2) => {
  e2 === D && (O = t2), chrome.storage.local.set({ [e2]: t2 }, () => n2());
}), removeItem: (e2) => new Promise((t2) => {
  chrome.storage.local.remove(e2, () => t2());
}) }, A = S()(T((e2) => ({ connections: { activeVtaDid: null, vtas: {} }, setConnection: (t2) => e2((e3) => ({ connections: { activeVtaDid: t2.vtaDid, vtas: { ...e3.connections.vtas, [t2.vtaDid]: t2 } } })), clearConnection: () => e2((e3) => ({ connections: { activeVtaDid: null, vtas: e3.connections.vtas } })), forgetVta: (t2) => e2((e3) => {
  let { [t2]: n2, ...r2 } = e3.connections.vtas, i2 = e3.connections.activeVtaDid;
  return e3.connections.activeVtaDid === t2 && (i2 = Object.keys(r2)[0] ?? null), { connections: { activeVtaDid: i2, vtas: r2 } };
}), activateVta: (t2) => e2((e3) => e3.connections.vtas[t2] ? { connections: { ...e3.connections, activeVtaDid: t2 } } : e3) }), { name: D, storage: C(() => k), version: 3, migrate: (e2, t2) => {
  if (t2 === 3) return e2;
  let n2 = e2?.connection;
  return n2 && typeof n2.vtaDid == `string` ? { connections: { activeVtaDid: n2.vtaDid, vtas: { [n2.vtaDid]: n2 } } } : { connections: { activeVtaDid: null, vtas: {} } };
}, partialize: (e2) => ({ connections: e2.connections }) }));
typeof chrome < `u` && chrome.storage?.onChanged?.addListener((e2, t2) => {
  if (t2 !== `local`) return;
  let n2 = e2[D];
  n2 && n2.newValue !== O && A.persist.rehydrate();
});
function j() {
  return A((e2) => {
    let { activeVtaDid: t2, vtas: n2 } = e2.connections;
    return t2 === null ? null : n2[t2] ?? null;
  });
}
var M = S()((e2) => ({ state: null, setLockState: (t2) => e2({ state: t2 }) })), N = n(), P = { fontFamily: `var(--w-mono)`, fontSize: i.sm, wordBreak: `break-all` };
function F() {
  let [e2, t2] = (0, g.useState)(null), [n2, i2] = (0, g.useState)(false), [s2, l2] = (0, g.useState)(false), [u2, d2] = (0, g.useState)(null), [p2, m2] = (0, g.useState)(false), [h2, _2] = (0, g.useState)(null), [v2, y2] = (0, g.useState)(null), [b2, x2] = (0, g.useState)(`all`);
  (0, g.useEffect)(() => {
    if (!h2) return;
    let e3 = h2.expiresAtMs - Date.now();
    if (e3 <= 0) {
      _2(null);
      return;
    }
    let t3 = setTimeout(() => _2(null), e3);
    return () => clearTimeout(t3);
  }, [h2]), (0, g.useEffect)(() => {
    if (!v2) return;
    let e3 = v2.expiresAtMs - Date.now();
    if (e3 <= 0) {
      y2(null);
      return;
    }
    let t3 = setTimeout(() => y2(null), e3);
    return () => clearTimeout(t3);
  }, [v2]);
  async function S2() {
    l2(true), d2(null);
    try {
      let e3 = await chrome.runtime.sendMessage({ type: f });
      if (!e3.ok) throw Error(e3.error);
      t2(e3.result.entries), i2(e3.result.truncated);
    } catch (e3) {
      d2(e3 instanceof Error ? e3.message : String(e3)), t2(null);
    } finally {
      l2(false);
    }
  }
  async function C2(e3) {
    l2(true), d2(null);
    try {
      let t3 = await chrome.runtime.sendMessage({ type: a, id: e3.id, expectedVersion: e3.version });
      if (!t3.ok) throw Error(t3.error);
      await S2();
    } catch (e4) {
      d2(e4 instanceof Error ? e4.message : String(e4));
    } finally {
      l2(false);
    }
  }
  async function w2(e3) {
    _2(null), l2(true), d2(null);
    try {
      let t3 = await chrome.runtime.sendMessage({ type: o, entryId: e3.id });
      if (!t3.ok) throw Error(t3.error);
      _2({ entryId: e3.id, secret: t3.result.secret, expiresAtMs: Date.now() + t3.result.ttlSeconds * 1e3 });
    } catch (e4) {
      d2(e4 instanceof Error ? e4.message : String(e4));
    } finally {
      l2(false);
    }
  }
  async function T2(e3) {
    y2(null), _2(null), l2(true), d2(null);
    try {
      let t3 = await chrome.runtime.sendMessage({ type: c, entryId: e3.id });
      if (!t3.ok) throw Error(t3.error);
      let n3 = Date.parse(t3.result.expiresAt), r2 = Number.isFinite(n3) ? n3 : Date.now() + 6e4;
      y2({ entryId: e3.id, sessionBlob: t3.result.sessionBlob, expiresAtMs: r2 });
    } catch (e4) {
      d2(e4 instanceof Error ? e4.message : String(e4));
    } finally {
      l2(false);
    }
  }
  let E2 = e2 ? b2 === `all` ? e2 : e2.filter((e3) => e3.contextId === b2) : null, D2 = e2 ? Array.from(new Set(e2.map((e3) => e3.contextId))).sort() : [];
  return (0, N.jsxs)(`div`, { style: { marginTop: 12, padding: 8, background: `var(--w-raised)`, borderRadius: 6 }, children: [(0, N.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, justifyContent: `space-between` }, children: [(0, N.jsx)(`strong`, { style: { fontSize: 13 }, children: `Vault` }), (0, N.jsxs)(`div`, { style: { display: `flex`, gap: 6 }, children: [e2 && e2.length > 0 && (0, N.jsx)(`button`, { onClick: () => m2((e3) => !e3), disabled: s2, style: { fontSize: 11 }, children: p2 ? `Cancel` : `+ Add` }), (0, N.jsx)(`button`, { onClick: () => void S2(), disabled: s2, style: { fontSize: 11 }, children: s2 ? `\u2026` : e2 ? `Refresh` : `Load entries` })] })] }), e2 && D2.length > 1 && (0, N.jsxs)(`div`, { style: { marginTop: 6, fontSize: 11 }, children: [(0, N.jsx)(`label`, { style: { color: `var(--w-muted)` }, children: `Context: ` }), (0, N.jsxs)(`select`, { value: b2, onChange: (e3) => x2(e3.target.value), style: { fontSize: 11 }, children: [(0, N.jsxs)(`option`, { value: `all`, children: [`All (`, e2.length, `)`] }), D2.map((t3) => {
    let n3 = e2.filter((e3) => e3.contextId === t3).length;
    return (0, N.jsxs)(`option`, { value: t3, children: [t3, ` (`, n3, `)`] }, t3);
  })] })] }), p2 && (0, N.jsx)(I, { contexts: D2, busy: s2, onCancel: () => m2(false), onSubmit: async (e3) => {
    l2(true), d2(null);
    try {
      let t3 = await chrome.runtime.sendMessage({ type: `vta-wallet/vault-upsert`, contextId: e3.contextId, targets: e3.targets, label: e3.label, secretKind: e3.secretKind, secret: e3.secret });
      if (!t3.ok) throw Error(t3.error);
      m2(false), await S2();
    } catch (e4) {
      d2(e4 instanceof Error ? e4.message : String(e4));
    } finally {
      l2(false);
    }
  } }), u2 && (0, N.jsx)(`small`, { style: { color: `var(--w-danger)`, display: `block`, marginTop: 6 }, children: u2 }), e2 && e2.length === 0 && (0, N.jsxs)(`div`, { style: { marginTop: 6 }, children: [(0, N.jsx)(`small`, { style: { color: `var(--w-muted)`, display: `block` }, children: `No vault entries yet.` }), (0, N.jsx)(`button`, { onClick: () => m2(true), style: { marginTop: 6, fontSize: 11 }, children: `+ Add your first entry` })] }), E2 && E2.length > 0 && (0, N.jsxs)(`ul`, { style: { listStyle: `none`, padding: 0, margin: `8px 0 0 0` }, children: [E2.map((e3) => (0, N.jsxs)(`li`, { style: { padding: `6px 0`, borderTop: `1px solid var(--w-line)`, display: `grid`, gap: 2 }, children: [(0, N.jsx)(`div`, { style: { fontSize: 12, fontWeight: 600 }, children: e3.label }), (0, N.jsxs)(`div`, { style: { fontSize: 11, color: `var(--w-muted)` }, children: [(0, N.jsx)(H, { kind: e3.secretKind }), ` \xB7 `, (0, N.jsx)(`span`, { style: P, children: U(e3.targets) })] }), (0, N.jsxs)(`div`, { style: { fontSize: 10, color: `var(--w-muted)` }, children: [(0, N.jsx)(V, { ctx: e3.contextId }), e3.lastUsedAt && (0, N.jsxs)(N.Fragment, { children: [` \xB7 last used `, W(e3.lastUsedAt)] }), e3.breachedAt && (0, N.jsxs)(N.Fragment, { children: [` \xB7 `, (0, N.jsx)(`span`, { style: { color: `var(--w-danger)` }, children: `\u26A0 breached` })] })] }), e3.principalDid && (0, N.jsxs)(`div`, { style: { fontSize: 10, color: `var(--w-muted)` }, title: `DID the VTA will act AS when you click Use`, children: [`acts as: `, (0, N.jsx)(`code`, { style: P, children: e3.principalDid }), (0, N.jsx)(r, { value: e3.principalDid }), (0, N.jsx)(B, { text: e3.principalDid })] }), h2?.entryId === e3.id ? (0, N.jsx)(L, { secret: h2.secret, expiresAtMs: h2.expiresAtMs, onDismiss: () => _2(null) }) : v2?.entryId === e3.id ? (0, N.jsx)(R, { sessionBlob: v2.sessionBlob, expiresAtMs: v2.expiresAtMs, onDismiss: () => y2(null) }) : (0, N.jsxs)(`div`, { style: { display: `flex`, gap: 6, marginTop: 4 }, children: [e3.secretKind === `didSelfIssued` && (0, N.jsx)(`button`, { onClick: () => void T2(e3), disabled: s2, style: { fontSize: 11 }, title: `VTA mints a SIOP id_token on your behalf \u2014 long-term key never leaves the VTA`, children: `\u{1F511} Use` }), (0, N.jsx)(`button`, { onClick: () => void w2(e3), disabled: s2, style: { fontSize: 11 }, children: `\u{1F513} Reveal` }), (0, N.jsx)(`button`, { onClick: () => {
    confirm(`Delete "${e3.label}"? This cannot be undone.`) && C2(e3);
  }, disabled: s2, style: { fontSize: 11, color: `var(--w-danger)` }, children: `Delete` })] })] }, e3.id)), n2 && (0, N.jsx)(`li`, { style: { padding: `6px 0`, fontSize: 11, color: `var(--w-muted)` }, children: `\u2026 truncated. Pagination lands when the vault grows past ~100 entries.` })] })] });
}
function I({ contexts: e2, busy: t2, onCancel: n2, onSubmit: r2 }) {
  let [i2, a2] = (0, g.useState)(`password`), [o2, c2] = (0, g.useState)(``), [f2, p2] = (0, g.useState)(e2[0] ?? ``), [m2, h2] = (0, g.useState)(``), _2 = `__new__`, [v2, y2] = (0, g.useState)(null), [b2, x2] = (0, g.useState)(null), [S2, C2] = (0, g.useState)(``), [w2, T2] = (0, g.useState)(``), [E2, D2] = (0, g.useState)(``), [O2, k2] = (0, g.useState)(false), [A2, j2] = (0, g.useState)(null);
  (0, g.useEffect)(() => {
    (async () => {
      let e3 = await chrome.runtime.sendMessage({ type: d });
      e3.ok ? (y2(e3.result.contexts), e3.result.contexts.length > 0 && !e3.result.contexts.find((e4) => e4.id === f2) && p2(e3.result.contexts[0].id)) : x2(e3.error);
    })();
  }, []);
  let [M2, F2] = (0, g.useState)(``), [I2, L2] = (0, g.useState)(``), [R2, z2] = (0, g.useState)(``), [B2, V2] = (0, g.useState)(false), [H2, U2] = (0, g.useState)(``), [W2, G] = (0, g.useState)(``), [K, q] = (0, g.useState)(``), [J, ee] = (0, g.useState)(null), [te, ne] = (0, g.useState)(false), [re, Y] = (0, g.useState)(null), [X, Z] = (0, g.useState)([]), [ie, Q] = (0, g.useState)(null), [$, ae] = (0, g.useState)(false);
  async function oe(e3) {
    ae(true), Q(null), Z([]);
    try {
      let t3 = await chrome.runtime.sendMessage({ type: s, did: e3 });
      if (!t3.ok) {
        Q(t3.error);
        return;
      }
      if (t3.result.error) {
        Q(t3.result.error);
        return;
      }
      let n3 = t3.result.candidates;
      Z(n3), n3.length === 1 && q(n3[0]);
    } finally {
      ae(false);
    }
  }
  (0, g.useEffect)(() => {
    if (i2 !== `didSelfIssued`) return;
    if (ee(null), G(``), q(``), Z([]), Q(null), !f2 || f2 === _2) {
      Y(null);
      return;
    }
    let e3 = false;
    return ne(true), Y(null), (async () => {
      try {
        let t3 = await chrome.runtime.sendMessage({ type: u, contextId: f2 });
        if (e3) return;
        if (!t3.ok) {
          Y(t3.error);
          return;
        }
        if (ee(t3.result.dids), t3.result.dids.length === 1) {
          let e4 = t3.result.dids[0].did;
          G(e4), oe(e4);
        }
      } finally {
        e3 || ne(false);
      }
    })(), () => {
      e3 = true;
    };
  }, [i2, f2]);
  let se = o2.trim() && f2.trim() && M2.trim() && R2.length > 0, ce = o2.trim() && f2.trim() && H2.trim() && W2.trim() && K.trim(), le = i2 === `password` ? se : ce;
  async function ue() {
    k2(true), j2(null);
    try {
      let e3 = S2.trim();
      if (!e3) {
        j2(`context id is required`);
        return;
      }
      let t3 = await chrome.runtime.sendMessage({ type: l, id: e3, ...w2.trim() ? { name: w2.trim() } : {}, ...E2.trim() ? { description: E2.trim() } : {} });
      if (!t3.ok) {
        j2(t3.error);
        return;
      }
      let n3 = t3.result;
      y2((e4) => e4 ? [...e4, n3] : [n3]), p2(n3.id), C2(``), T2(``), D2(``);
    } finally {
      k2(false);
    }
  }
  function de() {
    if (i2 === `password`) {
      let e4 = { kind: `password`, password: R2, ...I2 ? { username: I2 } : {}, ...m2 ? { secureNotes: m2 } : {} };
      return { label: o2, contextId: f2, targets: [{ kind: `webOrigin`, origin: M2 }], secretKind: `password`, secret: e4 };
    }
    let e3 = { kind: `didSelfIssued`, did: W2.trim(), signingKeyId: K.trim(), ...m2 ? { secureNotes: m2 } : {} };
    return { label: o2, contextId: f2, targets: [{ kind: `did`, did: H2.trim() }], secretKind: `didSelfIssued`, secret: e3 };
  }
  return (0, N.jsxs)(`div`, { style: { marginTop: 8, padding: 8, background: `var(--w-surface)`, border: `1px solid var(--w-line)`, borderRadius: 4, display: `grid`, gap: 6, fontSize: 11 }, children: [(0, N.jsx)(`strong`, { style: { fontSize: 12 }, children: i2 === `password` ? `New password entry` : `New did-self-issued entry` }), (0, N.jsxs)(`label`, { style: { display: `grid`, gap: 2 }, children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Secret kind` }), (0, N.jsxs)(`select`, { value: i2, onChange: (e3) => a2(e3.target.value), style: { fontSize: 11 }, children: [(0, N.jsx)(`option`, { value: `password`, children: `password` }), (0, N.jsx)(`option`, { value: `didSelfIssued`, children: `did-self-issued` })] })] }), (0, N.jsxs)(`label`, { style: { display: `grid`, gap: 2 }, children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Label` }), (0, N.jsx)(`input`, { value: o2, onChange: (e3) => c2(e3.target.value), placeholder: i2 === `password` ? `Work GitHub` : `Work persona` })] }), (0, N.jsxs)(`label`, { style: { display: `grid`, gap: 2 }, children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Context` }), v2 ? (0, N.jsxs)(`select`, { value: f2 === `` && v2.length === 0 ? _2 : f2, onChange: (e3) => p2(e3.target.value), style: P, children: [v2.map((e3) => (0, N.jsx)(`option`, { value: e3.id, children: e3.id === e3.name ? e3.id : `${e3.id} \u2014 ${e3.name}` }, e3.id)), (0, N.jsx)(`option`, { value: _2, children: `+ New context\u2026` })] }) : (0, N.jsx)(`input`, { value: f2, onChange: (e3) => p2(e3.target.value), placeholder: `ctx_\u2026`, style: P }), b2 && (0, N.jsxs)(`small`, { style: { color: `var(--w-danger)` }, children: [`Couldn't fetch contexts: `, b2] })] }), f2 === _2 && (0, N.jsxs)(`div`, { style: { display: `grid`, gap: 6, paddingLeft: 8, borderLeft: `2px solid var(--w-line)` }, children: [(0, N.jsx)(`small`, { style: { color: `var(--w-muted)` }, children: `Create a new context on the VTA (requires super-admin grant).` }), (0, N.jsx)(`input`, { placeholder: `id (e.g. work)`, value: S2, onChange: (e3) => C2(e3.target.value), style: P }), (0, N.jsx)(`input`, { placeholder: `name (optional \u2014 defaults to id)`, value: w2, onChange: (e3) => T2(e3.target.value) }), (0, N.jsx)(`input`, { placeholder: `description (optional)`, value: E2, onChange: (e3) => D2(e3.target.value) }), (0, N.jsx)(`button`, { onClick: () => void ue(), disabled: O2 || !S2.trim(), children: O2 ? `Creating\u2026` : `Create context` }), A2 && (0, N.jsx)(`small`, { style: { color: `var(--w-danger)` }, children: A2 })] }), i2 === `password` && (0, N.jsxs)(N.Fragment, { children: [(0, N.jsxs)(`label`, { style: { display: `grid`, gap: 2 }, children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Site origin` }), (0, N.jsx)(`input`, { value: M2, onChange: (e3) => F2(e3.target.value), placeholder: `https://github.com`, style: P })] }), (0, N.jsxs)(`label`, { style: { display: `grid`, gap: 2 }, children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Username` }), (0, N.jsx)(`input`, { value: I2, onChange: (e3) => L2(e3.target.value) })] }), (0, N.jsxs)(`label`, { style: { display: `grid`, gap: 2 }, children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Password` }), (0, N.jsxs)(`div`, { style: { display: `flex`, gap: 4 }, children: [(0, N.jsx)(`input`, { type: B2 ? `text` : `password`, value: R2, onChange: (e3) => z2(e3.target.value), style: { flex: 1 } }), (0, N.jsx)(`button`, { type: `button`, onClick: () => V2((e3) => !e3), style: { fontSize: 10 }, children: B2 ? `Hide` : `Show` })] })] })] }), i2 === `didSelfIssued` && (0, N.jsxs)(N.Fragment, { children: [(0, N.jsxs)(`label`, { style: { display: `grid`, gap: 2 }, children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Relying party DID (target)` }), (0, N.jsx)(`input`, { value: H2, onChange: (e3) => U2(e3.target.value), placeholder: `did:webvh:\u2026`, style: P })] }), (0, N.jsxs)(`label`, { style: { display: `grid`, gap: 2 }, children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Persona DID (iss / sub)` }), te ? (0, N.jsxs)(`small`, { style: { color: `var(--w-muted)` }, children: [`Loading DIDs for \u201C`, f2, `\u201D\u2026`] }) : re ? (0, N.jsxs)(`small`, { style: { color: `var(--w-danger)` }, children: [`Couldn't list DIDs: `, re] }) : J && J.length > 0 ? (0, N.jsxs)(`select`, { value: W2, onChange: (e3) => {
    let t3 = e3.target.value;
    G(t3), q(``), Z([]), Q(null), t3 && oe(t3);
  }, style: P, children: [(0, N.jsx)(`option`, { value: ``, children: `\u2014 select a DID \u2014` }), J.map((e3) => (0, N.jsx)(`option`, { value: e3.did, children: e3.did }, e3.did))] }) : (0, N.jsx)(`small`, { style: { color: `var(--w-danger)` }, children: f2 === _2 ? `Pick a context above to see its DIDs.` : `Context \u201C${f2}\u201D has no DIDs \u2014 mint one on the VTA first.` }), (0, N.jsx)(`small`, { style: { color: `var(--w-muted)` }, children: `The entry signs id_tokens as this persona; the VTA holds its signing key.` })] }), (0, N.jsxs)(`label`, { style: { display: `grid`, gap: 2 }, children: [(0, N.jsxs)(`span`, { style: { color: `var(--w-muted)` }, children: [`Signing key id`, ` `, (0, N.jsx)(`em`, { style: { color: `var(--w-muted)` }, children: `(optional \u2014 auto-derived from DID)` })] }), (0, N.jsx)(`input`, { value: K, onChange: (e3) => q(e3.target.value), placeholder: `did:webvh:\u2026#key-0`, style: P }), $ && (0, N.jsx)(`small`, { style: { color: `var(--w-muted)` }, children: `Resolving DID to derive key id\u2026` }), !$ && X.length === 1 && K === X[0] && (0, N.jsx)(`small`, { style: { color: `var(--w-ok)` }, children: `Auto-derived from persona DID.` }), !$ && X.length > 1 && (0, N.jsxs)(`div`, { style: { display: `grid`, gap: 4 }, children: [(0, N.jsxs)(`small`, { style: { color: `var(--w-warn)` }, children: [`Persona DID has `, X.length, ` authentication keys \u2014 pick one:`] }), X.map((e3) => (0, N.jsx)(`button`, { onClick: () => q(e3), style: { textAlign: `left`, ...P, background: K === e3 ? `var(--w-ok-soft)` : void 0 }, children: e3 }, e3))] }), !$ && ie && (0, N.jsxs)(`small`, { style: { color: `var(--w-danger)` }, children: [`Couldn't derive from DID: `, ie, `. Enter key id manually.`] }), (0, N.jsx)(`small`, { style: { color: `var(--w-muted)` }, children: `Must reference a key the VTA's keystore can resolve.` })] })] }), (0, N.jsxs)(`label`, { style: { display: `grid`, gap: 2 }, children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Notes (optional)` }), (0, N.jsx)(`input`, { value: m2, onChange: (e3) => h2(e3.target.value) })] }), (0, N.jsxs)(`div`, { style: { display: `flex`, gap: 6, position: `sticky`, bottom: 0, margin: `4px -8px -8px`, padding: 8, background: `var(--w-surface)`, borderTop: `1px solid var(--w-line-soft)`, borderRadius: `0 0 3px 3px` }, children: [(0, N.jsx)(`button`, { onClick: () => void r2(de()), disabled: !le || t2, children: t2 ? `Saving\u2026` : `Save` }), (0, N.jsx)(`button`, { onClick: n2, disabled: t2, children: `Cancel` })] })] });
}
function L({ secret: e2, expiresAtMs: t2, onDismiss: n2 }) {
  let [r2, i2] = (0, g.useState)(Math.max(0, Math.round((t2 - Date.now()) / 1e3)));
  return (0, g.useEffect)(() => {
    let e3 = setInterval(() => {
      let e4 = Math.max(0, Math.round((t2 - Date.now()) / 1e3));
      i2(e4);
    }, 1e3);
    return () => clearInterval(e3);
  }, [t2]), (0, N.jsxs)(`div`, { style: { marginTop: 4, padding: 6, background: `var(--w-warn-soft)`, border: `1px solid var(--w-warn)`, borderRadius: 4, display: `grid`, gap: 4, fontSize: 11 }, children: [e2.kind === `password` && (0, N.jsxs)(N.Fragment, { children: [e2.username && (0, N.jsxs)(`div`, { children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Username:` }), ` `, (0, N.jsx)(`code`, { style: P, children: e2.username }), (0, N.jsx)(B, { text: e2.username })] }), e2.password && (0, N.jsxs)(`div`, { children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Password:` }), ` `, (0, N.jsx)(`code`, { style: P, children: e2.password }), (0, N.jsx)(B, { text: e2.password })] }), e2.secureNotes && (0, N.jsxs)(`div`, { children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Notes:` }), ` `, (0, N.jsx)(`span`, { children: e2.secureNotes })] })] }), e2.kind !== `password` && (0, N.jsxs)(`div`, { style: { color: `var(--w-muted)` }, children: [`Cleartext displayed for kind `, (0, N.jsx)(`code`, { children: e2.kind }), `. M2A.6 renders only password entries; other kinds show below as raw JSON until per-kind UI lands.`, (0, N.jsx)(`pre`, { style: { ...P, background: `var(--w-raised)`, padding: 4, overflow: `auto` }, children: JSON.stringify(e2, null, 2) })] }), (0, N.jsxs)(`div`, { style: { display: `flex`, justifyContent: `space-between`, color: `var(--w-muted)` }, children: [(0, N.jsxs)(`span`, { children: [`Auto-clears in `, r2, `s`] }), (0, N.jsx)(`button`, { onClick: n2, style: { fontSize: 10 }, children: `Dismiss` })] })] });
}
function R({ sessionBlob: e2, expiresAtMs: t2, onDismiss: n2 }) {
  let [r2, i2] = (0, g.useState)(Math.max(0, Math.round((t2 - Date.now()) / 1e3)));
  (0, g.useEffect)(() => {
    let e3 = setInterval(() => {
      let e4 = Math.max(0, Math.round((t2 - Date.now()) / 1e3));
      i2(e4);
    }, 1e3);
    return () => clearInterval(e3);
  }, [t2]);
  let a2 = e2.headers?.find((e3) => e3.name.toLowerCase() === `authorization`), o2 = e2.headers?.length ?? 0;
  function s2() {
    e2.bindOrigin && chrome.tabs.create({ url: e2.bindOrigin });
  }
  return (0, N.jsxs)(`div`, { style: { marginTop: 4, padding: 6, background: `var(--w-ok-soft)`, border: `1px solid var(--w-ok)`, borderRadius: 4, display: `grid`, gap: 4, fontSize: 11 }, children: [(0, N.jsxs)(`div`, { style: { display: `flex`, justifyContent: `space-between` }, children: [(0, N.jsx)(`strong`, { style: { color: `var(--w-ok)` }, children: `\u2713 Session ready` }), (0, N.jsxs)(`span`, { style: { color: `var(--w-muted)`, fontSize: 10 }, children: [`expires in `, r2, `s`] })] }), e2.bindOrigin && (0, N.jsxs)(`div`, { children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Bound origin:` }), ` `, (0, N.jsx)(`code`, { style: P, children: e2.bindOrigin })] }), (0, N.jsxs)(`div`, { children: [(0, N.jsx)(`span`, { style: { color: `var(--w-muted)` }, children: `Session id:` }), ` `, (0, N.jsxs)(`code`, { style: P, children: [e2.sessionId.slice(0, 12), `\u2026`] })] }), (0, N.jsxs)(`div`, { style: { color: `var(--w-muted)`, fontSize: 10 }, children: [o2, ` header`, o2 === 1 ? `` : `s`, e2.refreshHint && (0, N.jsxs)(N.Fragment, { children: [` \xB7 refresh: `, e2.refreshHint] })] }), a2 && (0, N.jsxs)(`div`, { children: [(0, N.jsxs)(`span`, { style: { color: `var(--w-muted)` }, children: [a2.name, `:`] }), ` `, (0, N.jsx)(`code`, { style: P, title: `redacted preview \u2014 copy below for full value`, children: z(a2.value) }), (0, N.jsx)(B, { text: a2.value })] }), (0, N.jsxs)(`div`, { style: { display: `flex`, gap: 6, marginTop: 4 }, children: [e2.bindOrigin && (0, N.jsx)(`button`, { onClick: s2, style: { fontSize: 10 }, children: `Open site` }), (0, N.jsx)(`button`, { onClick: n2, style: { fontSize: 10 }, children: `Dismiss` })] })] });
}
function z(e2) {
  let t2 = /^(\s*Bearer\s+)(.+)$/i.exec(e2);
  if (!t2 || !t2[1] || !t2[2]) return e2.length > 24 ? `${e2.slice(0, 12)}\u2026` : e2;
  let n2 = t2[1], r2 = t2[2];
  return r2.length <= 20 ? `${n2}${r2}` : `${n2}${r2.slice(0, 8)}\u2026${r2.slice(-8)}`;
}
function B({ text: e2 }) {
  let [t2, n2] = (0, g.useState)(false);
  return (0, N.jsx)(`button`, { onClick: () => {
    navigator.clipboard.writeText(e2), n2(true), setTimeout(() => n2(false), 1500);
  }, style: { fontSize: 10, marginLeft: 6 }, title: `Copy to clipboard`, children: t2 ? `\u2713` : `Copy` });
}
function V({ ctx: e2 }) {
  return (0, N.jsx)(`span`, { style: { display: `inline-block`, padding: `0 4px`, background: `var(--w-accent-soft)`, color: `var(--w-accent)`, borderRadius: 3, fontSize: 10, fontWeight: 600, marginRight: 4 }, title: `Context: ${e2}`, children: e2 });
}
function H({ kind: e2 }) {
  return (0, N.jsx)(`span`, { style: { display: `inline-block`, padding: `1px 6px`, background: e2 === `password` ? `var(--w-ok)` : e2 === `passkey` ? `var(--w-accent)` : e2 === `oauthTokens` ? `var(--w-warn)` : `var(--w-muted)`, color: `var(--w-accent-ink)`, borderRadius: 3, fontSize: 10, fontWeight: 600 }, children: e2 });
}
function U(e2) {
  if (e2.length === 0) return `\u2014`;
  let t2 = e2[0];
  if (!t2) return `\u2014`;
  let n2 = e2.length > 1 ? ` (+${e2.length - 1})` : ``;
  switch (t2.kind) {
    case `webOrigin`:
      return t2.origin + n2;
    case `did`:
      return t2.did + n2;
    case `iosApp`:
      return `ios:${t2.bundleId}${n2}`;
    case `androidApp`:
      return `android:${t2.packageName}${n2}`;
  }
}
function W(e2) {
  let t2 = new Date(e2);
  return Number.isNaN(t2.getTime()) ? e2 : t2.toLocaleDateString();
}
export {
  M as a,
  p as c,
  A as i,
  F as n,
  E as o,
  j as r,
  h as s,
  B as t
};
