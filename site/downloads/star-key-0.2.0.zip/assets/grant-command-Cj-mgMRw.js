import { S as e, _ as t, b as n, d as r, x as i } from "./didcomm-D5nXYRy6.js";
import { n as a, t as o } from "./ed25519-CV189T12.js";
import { Bt as s, Jt as c, qt as l } from "./bridge-protocol-DoEW6v30.js";
function u(e2) {
  return e2.startsWith(`did:webvh:`) ? `webvh` : e2.startsWith(`did:peer:`) ? `peer` : e2.startsWith(`did:key:`) ? `key` : `unknown`;
}
function d(e2) {
  if (e2.startsWith(`did:webvh:`)) return e2.split(`:`)[3];
}
var f = (e2) => r(e2, {});
async function p(e2, t2 = {}) {
  let n2 = u(e2), r2 = n2 === `webvh` ? d(e2) : void 0, i2 = { did: e2, method: n2, resolved: false, ...r2 ? { domain: r2 } : {} };
  if (n2 === `unknown`) return { ...i2, error: `Unrecognised DID method` };
  try {
    n2 === `webvh` && _(e2);
    let r3 = await (t2.resolveDid ?? f)(e2), a2 = r3.didResolutionMetadata?.error;
    if (a2) return { ...i2, error: a2 };
    if (!r3.didDocument?.id) return { ...i2, error: `Resolver returned no DID document` };
    let o2 = r3.didDocument.alsoKnownAs, s2 = Array.isArray(o2) ? o2.filter((e3) => typeof e3 == `string`) : void 0;
    return { ...i2, resolved: true, ...s2 && s2.length > 0 ? { alsoKnownAs: s2 } : {} };
  } catch (e3) {
    return { ...i2, error: e3 instanceof Error ? e3.message : String(e3) };
  }
}
var m = `E_BLOCKED_ENDPOINT`, h = class extends Error {
  code = m;
  reason;
  host;
  constructor(e2, t2, n2) {
    super(e2), this.name = `BlockedEndpointError`, this.reason = t2, this.host = n2;
  }
};
function g(e2) {
  return e2 instanceof Error && e2.code === `E_BLOCKED_ENDPOINT`;
}
function _(e2) {
  let t2 = d(e2), n2 = () => new h(`the DID's host ${JSON.stringify(t2 ?? ``)} is not a valid host name, so it was not contacted`, `invalid_url`);
  if (!t2) throw n2();
  let r2;
  try {
    r2 = decodeURIComponent(t2).normalize(`NFC`);
  } catch {
    throw n2();
  }
  if (r2 === `` || /[/\\@?#%\s]/.test(r2)) throw n2();
  let i2;
  try {
    i2 = new URL(`https://${r2}/`);
  } catch {
    throw n2();
  }
  if (i2.username !== `` || i2.password !== `` || i2.pathname !== `/`) throw n2();
  let a2 = i2.hostname.startsWith(`[`), o2 = b(i2.hostname);
  if (o2 === ``) throw n2();
  if (a2 || T(o2)) {
    if (S(o2)) throw new h(`the DID's host ${o2}${a2 || r2.toLowerCase().startsWith(o2) ? `` : ` (written ${r2})`} is not a public internet address, so it was not contacted`, `private_address`, o2);
    return;
  }
  if (y(o2)) throw new h(`the DID's host ${o2} is a local-network name, not a public internet host, so it was not contacted`, `private_name`, o2);
}
var v = [`localhost`, `local`, `internal`, `home.arpa`];
function y(e2) {
  return !e2.includes(`.`) || v.some((t2) => e2 === t2 || e2.endsWith(`.${t2}`));
}
function b(e2) {
  let t2 = e2.toLowerCase();
  return t2.startsWith(`[`) && t2.endsWith(`]`) ? t2.slice(1, -1) : t2.replace(/\.+$/, ``);
}
var x = [[`0.0.0.0`, 8], [`10.0.0.0`, 8], [`100.64.0.0`, 10], [`127.0.0.0`, 8], [`169.254.0.0`, 16], [`172.16.0.0`, 12], [`192.0.0.0`, 24], [`192.0.2.0`, 24], [`192.168.0.0`, 16], [`198.18.0.0`, 15], [`198.51.100.0`, 24], [`203.0.113.0`, 24], [`224.0.0.0`, 4], [`240.0.0.0`, 4]].map(([e2, t2]) => [E(T(e2)), t2]);
function S(e2) {
  let t2 = T(e2);
  if (t2) return C(E(t2));
  let n2 = D(e2);
  return !n2 || w(n2);
}
function C(e2) {
  return x.some(([t2, n2]) => {
    let r2 = 32 - n2;
    return e2 >>> r2 == t2 >>> r2;
  });
}
function w(e2) {
  let t2 = (t3) => e2[t3] ?? 0, n2 = (t3, n3) => e2.slice(t3, n3).every((e3) => e3 === 0), r2 = (e3, t3) => C((e3 << 16 >>> 0) + t3);
  return n2(0, 6) || n2(0, 5) && t2(5) === 65535 || n2(0, 4) && t2(4) === 65535 && t2(5) === 0 || t2(0) === 100 && t2(1) === 65435 && n2(2, 6) ? r2(t2(6), t2(7)) : t2(0) === 100 && t2(1) === 65435 && t2(2) === 1 ? true : t2(0) === 8194 ? r2(t2(1), t2(2)) : t2(0) === 8193 && t2(1) < 512 || t2(0) === 8193 && t2(1) === 3512 || t2(0) === 16383 && !(t2(1) & 61440) || (t2(0) & 57344) != 8192;
}
function T(e2) {
  let t2 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(e2);
  if (!t2) return null;
  let n2 = [];
  for (let e3 of t2.slice(1)) {
    if (e3.length > 1 && e3.startsWith(`0`)) return null;
    let t3 = Number(e3);
    if (t3 > 255) return null;
    n2.push(t3);
  }
  return n2;
}
function E([e2, t2, n2, r2]) {
  return (e2 << 24 >>> 0) + (t2 << 16) + (n2 << 8) + r2;
}
function D(e2) {
  let t2 = e2;
  if (t2.startsWith(`[`) && t2.endsWith(`]`) && (t2 = t2.slice(1, -1)), !/^[0-9A-Fa-f:.]+$/.test(t2)) return null;
  let n2 = t2.lastIndexOf(`:`);
  if (n2 === -1) return null;
  let r2 = [];
  if (t2.includes(`.`)) {
    let e3 = T(t2.slice(n2 + 1));
    if (!e3) return null;
    r2 = [e3[0] << 8 | e3[1], e3[2] << 8 | e3[3]], t2 = t2.slice(0, n2 + 1), t2.endsWith(`::`) || (t2 = t2.slice(0, -1));
  }
  let i2 = 8 - r2.length, a2 = (e3) => {
    if (e3 === ``) return [];
    let t3 = [];
    for (let n3 of e3.split(`:`)) {
      if (!/^[0-9A-Fa-f]{1,4}$/.test(n3)) return null;
      t3.push(parseInt(n3, 16));
    }
    return t3;
  }, o2 = t2.indexOf(`::`);
  if (o2 === -1) {
    let e3 = a2(t2);
    return !e3 || e3.length !== i2 ? null : [...e3, ...r2];
  }
  if (o2 !== t2.lastIndexOf(`::`)) return null;
  let s2 = a2(t2.slice(0, o2)), c2 = a2(t2.slice(o2 + 2));
  if (!s2 || !c2) return null;
  let l2 = i2 - s2.length - c2.length;
  return l2 < 1 ? null : [...s2, ...Array(l2).fill(0), ...c2, ...r2];
}
var O = `pnm/approver-identity/v1/`;
function k(e2) {
  return O + e2;
}
function A(e2) {
  let r2 = o.getPublicKey(e2), i2 = a.getPublicKey(o.utils.toMontgomerySecret(e2)), s2 = n(t.ED25519_PUB, r2), c2 = n(t.X25519_PUB, i2), l2 = `did:key:${s2}`;
  return { did: l2, signingKid: `${l2}#${s2}`, keyAgreementKid: `${l2}#${c2}` };
}
async function j(e2, t2) {
  if (await e2.get(k(t2.vtaDid))) throw Error(`approver identity already exists for ${t2.vtaDid}`);
  let n2 = o.utils.randomSecretKey(), r2 = A(n2), i2 = await c(n2, t2.secretWrap), a2 = { ...r2, wrappedSecret: i2, vtaDid: t2.vtaDid, schemaVersion: 1 };
  return await e2.put(k(t2.vtaDid), a2), { ...s(n2, r2.did, r2.signingKid, r2.keyAgreementKid), did: r2.did };
}
async function M(e2, t2) {
  let n2 = await e2.get(k(t2.vtaDid));
  if (!n2) return null;
  let r2 = await l(n2.wrappedSecret, t2.secretWrap);
  return { ...s(r2, n2.did, n2.signingKid, n2.keyAgreementKid), did: n2.did };
}
async function N(e2, t2) {
  return (await e2.get(k(t2)))?.did ?? null;
}
var P = `pnm/approver-secret/aes-gcm/v1`, F = `webauthn-prf-aes-gcm/approver`, I = `pnm/sign-in-uv-secret/aes-gcm/v1`, L = `webauthn-prf-aes-gcm/sign-in-uv`;
async function R(e2, t2) {
  let n2 = await crypto.subtle.importKey(`raw`, e2, `HKDF`, false, [`deriveKey`]);
  return crypto.subtle.deriveKey({ name: `HKDF`, hash: `SHA-256`, salt: new Uint8Array(), info: new TextEncoder().encode(t2) }, n2, { name: `AES-GCM`, length: 256 }, false, [`encrypt`, `decrypt`]);
}
var z = class {
  prfOutput;
  constructor(e2) {
    this.prfOutput = e2;
  }
  async wrap(t2) {
    let n2 = await R(this.prfOutput, this.info), r2 = crypto.getRandomValues(new Uint8Array(12)), i2 = new Uint8Array(await crypto.subtle.encrypt({ name: `AES-GCM`, iv: r2 }, n2, t2));
    return { algorithm: this.algorithm, ciphertextB64u: e(i2), ivB64u: e(r2), params: {} };
  }
  async unwrap(e2) {
    let t2 = await R(this.prfOutput, this.info), n2 = await crypto.subtle.decrypt({ name: `AES-GCM`, iv: i(e2.ivB64u) }, t2, i(e2.ciphertextB64u));
    return new Uint8Array(n2);
  }
}, B = class extends z {
  algorithm = F;
  info = P;
}, V = class extends z {
  algorithm = L;
  info = I;
}, H = `persona-holder`;
function U(e2, t2) {
  return e2 === `unrestricted` || t2 === true;
}
function W({ ephemeralDid: e2, adminScope: t2, context: n2, personaHolder: r2 }) {
  let i2 = `pnm acl create --did ${e2} --role admin`, a2 = U(t2, r2) ? ` --capabilities ${H}` : ``;
  if (t2 === `unrestricted`) return `${i2}${a2} --expires 1h --handoff`;
  let o2 = n2?.trim();
  if (!o2) throw Error(`a context-scoped grant needs the context it is scoped to \u2014 without it the command would grant the whole agent`);
  return `${i2} --contexts ${o2}${a2} --expires 1h --handoff`;
}
function G(e2, t2) {
  return U(e2, t2);
}
export {
  B as a,
  N as c,
  _ as d,
  g as f,
  p as h,
  F as i,
  M as l,
  d as m,
  U as n,
  L as o,
  u as p,
  G as r,
  V as s,
  W as t,
  j as u
};
