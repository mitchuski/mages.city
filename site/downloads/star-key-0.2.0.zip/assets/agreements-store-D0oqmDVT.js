import { u as e } from "./sign-in-uv-messages-Cu3YiOZZ.js";
import { r as t } from "./verify-DUO6YZuM.js";
var n = (e2) => Object.freeze(e2());
function r(e2) {
  return e2 instanceof Uint8Array || ArrayBuffer.isView(e2) && e2.constructor.name === `Uint8Array` && `BYTES_PER_ELEMENT` in e2 && e2.BYTES_PER_ELEMENT === 1;
}
function i(e2) {
  if (!r(e2)) throw TypeError(`Uint8Array expected`);
}
function a(e2, t2) {
  if (typeof t2 != `string`) throw TypeError(`${e2}: string expected`);
  return true;
}
function o(e2, t2 = `number`) {
  if (typeof e2 != `number`) throw TypeError(`${t2}: expected number, got ${typeof e2}`);
  if (!Number.isSafeInteger(e2)) throw RangeError(`${t2}: expected safe integer, got ${e2}`);
}
function s(...e2) {
  let t2 = (e3) => e3, n2 = (e3, t3) => (n3) => e3(t3(n3));
  return { encode: e2.map((e3) => e3.encode).reduceRight(n2, t2), decode: e2.map((e3) => e3.decode).reduce(n2, t2) };
}
var c = (() => {
  let e2 = [];
  for (let t2 = 0; t2 < 40; t2++) e2.push(2 ** t2);
  return e2;
})(), l = (() => {
  try {
    let e2 = new TextDecoder();
    return e2.decode(Uint8Array.of(65, 48, 43, 127)) === `A0+\x7F` ? e2 : void 0;
  } catch {
    return;
  }
})(), u = 8192;
function d(e2) {
  let t2 = e2.length;
  if (l !== void 0 && t2 >= 12) return l.decode(e2);
  if (t2 <= u) return String.fromCharCode.apply(null, e2);
  let n2 = ``;
  for (let r2 = 0; r2 < t2; r2 += u) n2 += String.fromCharCode.apply(null, e2.subarray(r2, r2 + u));
  return n2;
}
function f(e2) {
  if (o(e2), e2 <= 0 || e2 > 8) throw RangeError(`radix2: bits should be in (0..8]`);
  let t2 = c[e2] - 1;
  return { encode: (n2) => {
    i(n2);
    let r2 = n2.length, a2 = new Uint8Array(Math.ceil(r2 * 8 / e2)), o2 = 0, s2 = 0, c2 = 0;
    for (let i2 = 0; i2 < r2; ) for (i2 + 2 < r2 ? (o2 = o2 << 24 | n2[i2] << 16 | n2[i2 + 1] << 8 | n2[i2 + 2], s2 += 24, i2 += 3) : (o2 = (o2 << 8 | n2[i2]) & 65535, s2 += 8, i2++); s2 -= e2, a2[c2++] = o2 >> s2 & t2, !(s2 < e2); ) ;
    return s2 > 0 && (a2[c2] = o2 << e2 - s2 & t2), a2;
  }, decode: (t3) => {
    let n2 = t3.length, r2 = new Uint8Array(Math.floor(n2 * e2 / 8)), i2 = 0, a2 = 0, o2 = 0;
    for (let s2 = 0; s2 < n2; s2++) for (i2 = (i2 << e2 | t3[s2]) & 65535, a2 += e2; a2 >= 8; a2 -= 8) r2[o2++] = i2 >> a2 - 8 & 255;
    if (i2 = i2 << 8 - a2 & 255, a2 >= e2) throw Error(`Excess padding`);
    if (i2 > 0) throw Error(`Non-zero padding: ${i2}`);
    return r2;
  } };
}
function p(e2, t2) {
  let n2 = e2.length;
  if (n2 > 128) throw Error(`alphabet: max 128 letters`);
  let r2 = new Uint8Array(n2), i2 = new Int8Array(128).fill(-1);
  for (let t3 = 0; t3 < n2; t3++) {
    let n3 = e2.charCodeAt(t3);
    if (e2.codePointAt(t3) !== n3 || n3 > 127) throw Error(`alphabet: single-char ASCII letters only`);
    r2[t3] = n3, i2[n3] = t3;
  }
  if (t2 !== void 0) for (let e3 of Object.keys(t2)) {
    let n3 = e3.charCodeAt(0), r3 = i2[t2[e3].charCodeAt(0)];
    if (e3.length !== 1 || n3 > 127 || r3 === void 0 || r3 === -1) throw Error(`alphabet: invalid alias ${e3}`);
    i2[n3] = r3;
  }
  return { encode: (e3) => {
    let t3 = new Uint8Array(e3.length);
    for (let n3 = 0; n3 < e3.length; n3++) {
      let i3 = e3[n3], a2 = r2[i3];
      if (a2 === void 0) throw Error(`alphabet.encode: invalid digit ${i3}`);
      t3[n3] = a2;
    }
    return d(t3);
  }, decode: (t3) => {
    a(`decode`, t3);
    let n3 = t3.length, r3 = new Uint8Array(n3);
    for (let a2 = 0; a2 < n3; a2++) {
      let n4 = t3.charCodeAt(a2), o2 = n4 < 128 ? i2[n4] : -1;
      if (o2 === -1) throw Error(`Unknown letter "${t3[a2]}". Allowed: ${e2}`);
      r3[a2] = o2;
    }
    return r3;
  } };
}
function m(e2, t2 = `=`) {
  return o(e2), a(`padding`, t2), { encode(n2) {
    for (; n2.length * e2 % 8; ) n2 += t2;
    return n2;
  }, decode(n2) {
    a(`decode`, n2);
    let r2 = n2.length;
    if (r2 * e2 % 8) throw Error(`padding: invalid length`);
    for (; r2 > 0 && n2[r2 - 1] === t2; r2--) if ((r2 - 1) * e2 % 8 == 0) throw Error(`padding: excess padding`);
    return n2.slice(0, r2);
  } };
}
var h = n(() => s(f(5), p(`ABCDEFGHIJKLMNOPQRSTUVWXYZ234567`))), g = typeof Uint8Array.from([]).toBase64 == `function` && typeof Uint8Array.fromBase64 == `function`, _ = /[\t\n\f\r ]/, v = (e2, t2) => {
  a(`base64`, e2);
  let n2 = t2 ? `base64url` : `base64`;
  if (e2.length > 0 && _.test(e2)) throw Error(`invalid base64`);
  return Uint8Array.fromBase64(e2, { alphabet: n2, lastChunkHandling: `strict` });
}, y = n(() => s(f(6), p(`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/`), m(6))), ee = n(() => g ? { encode(e2) {
  return i(e2), e2.toBase64();
}, decode(e2) {
  return v(e2, false);
} } : y), te = n(() => s(f(6), p(`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/`))), b = n(() => s(f(6), p(`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_`))), x = 656356768, S = 65536, C = 2048, w = 4096, T = (e2, t2) => ({ encode: (n2) => {
  i(n2);
  let r2 = n2.length;
  if (r2 === 0) return new Uint8Array();
  if (r2 >= S) throw Error(`invalid length`);
  let a2 = 0;
  for (; a2 < r2 - 1 && n2[a2] === 0; ) a2++;
  let o2 = Math.ceil(r2 / 2), s2 = new Uint16Array(o2), c2 = r2 & 1;
  c2 && (s2[0] = n2[0]);
  for (let e3 = c2, t3 = c2; e3 < r2; e3 += 2, t3++) s2[t3] = n2[e3] << 8 | n2[e3 + 1];
  let l2 = [], u2 = 0;
  for (; u2 < o2; ) {
    let e3 = 0;
    for (let n3 = u2; n3 < o2; n3++) {
      let r3 = e3 * 65536 + s2[n3], i2 = Math.floor(r3 / t2);
      e3 = r3 - i2 * t2, s2[n3] = i2, i2 === 0 && n3 === u2 && u2++;
    }
    l2.push(e3);
  }
  let d2 = l2.length - 1, f2 = d2 * 5;
  for (let t3 = l2[d2]; f2++, !(t3 < e2); t3 = Math.floor(t3 / e2)) ;
  let p2 = new Uint8Array(a2 + f2), m2 = p2.length - 1;
  for (let t3 = 0; t3 < d2; t3++) {
    let n3 = l2[t3];
    for (let t4 = 0; t4 < 5; t4++) p2[m2--] = n3 % e2, n3 = Math.floor(n3 / e2);
  }
  for (let t3 = l2[d2]; m2 >= a2; t3 = Math.floor(t3 / e2)) p2[m2--] = t3 % e2;
  return p2;
}, decode: (t3) => {
  i(t3);
  let n2 = t3.length;
  if (n2 === 0) return new Uint8Array();
  if (n2 >= S) throw Error(`invalid length`);
  let r2 = 0;
  for (; r2 < n2 - 1 && t3[r2] === 0; ) r2++;
  let a2 = new Uint16Array(Math.ceil(n2 * 6 / 16) + 1), o2 = 0, s2 = 0, c2 = n2 % 5 || 5;
  for (; s2 < n2; ) {
    let n3 = 0, r3 = 1;
    for (let i3 = s2 + c2; s2 < i3; s2++) {
      let i4 = t3[s2];
      if (i4 >= e2) throw Error(`invalid integer: ${i4}`);
      n3 = n3 * e2 + i4, r3 *= e2;
    }
    c2 = 5;
    let i2 = n3;
    for (let e3 = 0; e3 < o2; e3++) {
      let t4 = a2[e3] * r3 + i2;
      i2 = Math.floor(t4 / 65536), a2[e3] = t4 - i2 * 65536;
    }
    for (; i2 > 0; i2 = Math.floor(i2 / 65536)) a2[o2++] = i2 % 65536;
  }
  let l2 = o2 === 0 ? 1 : o2 * 2 - (a2[o2 - 1] < 256), u2 = new Uint8Array(r2 + l2), d2 = u2.length - 1;
  for (let e3 = 0; e3 < o2; e3++) {
    let t4 = a2[e3];
    u2[d2--] = t4 & 255, d2 >= r2 && (u2[d2--] = t4 >> 8);
  }
  return u2;
} }), E = (e2, t2) => {
  let n2 = p(t2);
  return { encode(t3) {
    if (i(t3), t3.length > C) throw Error(`invalid length`);
    return n2.encode(e2.encode(t3));
  }, decode(t3) {
    if (a(`baseN.decode`, t3), t3.length > w) throw Error(`invalid length`);
    return e2.decode(n2.decode(t3));
  } };
}, D = T(58, x), O = (e2) => E(D, e2), k = n(() => O(`123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz`)), A = Uint8Array.of(18, 32), j = class extends Error {
  constructor(e2) {
    super(e2), this.name = `DigestMultibaseError`;
  }
};
function M(e2) {
  if (e2.length % 2 != 0) throw new j(`base16 digest has an odd length`);
  let t2 = new Uint8Array(e2.length / 2);
  for (let n2 = 0; n2 < t2.length; n2++) {
    let r2 = Number.parseInt(e2.slice(n2 * 2, n2 * 2 + 2), 16);
    if (Number.isNaN(r2)) throw new j(`base16 digest has a non-hex character`);
    t2[n2] = r2;
  }
  return t2;
}
function N(e2) {
  let n2 = e2[0], r2 = e2.slice(1);
  if (!n2 || !r2) throw new j(`digest is empty`);
  try {
    switch (n2) {
      case `z`:
        return t(r2);
      case `u`:
        return b.decode(r2.replace(/=+$/, ``));
      case `m`:
        return te.decode(r2.replace(/=+$/, ``));
      case `b`:
        return h.decode(r2.replace(/=+$/, ``).toUpperCase());
      case `f`:
      case `F`:
        return M(r2.toLowerCase());
      default:
        throw new j(`unsupported multibase prefix: ${n2}`);
    }
  } catch (e3) {
    throw e3 instanceof j ? e3 : new j(`digest is not valid multibase: ${e3 instanceof Error ? e3.message : String(e3)}`);
  }
}
function P(e2) {
  let t2 = N(e2);
  if (t2.length < A.length || t2[0] !== A[0] || t2[1] !== A[1]) throw new j(`payloadDigest is not a sha2-256 multihash`);
  let n2 = t2.subarray(A.length);
  if (n2.length !== 32) throw new j(`sha2-256 multihash carries ${n2.length} bytes, expected 32`);
  return n2;
}
function F(e2) {
  let t2 = P(e2), n2 = ``;
  for (let e3 = 0; e3 < 3; e3++) n2 += t2[e3].toString(16).padStart(2, `0`);
  return n2.slice(0, 6);
}
function I(e2) {
  return e2 === `allow` ? `agreed` : e2 === `deny` ? `declined` : `proffered`;
}
function L(t2) {
  let n2 = e(t2.code);
  return { id: t2.agreementId, kind: `myterms`, vtaDid: t2.vtaDid, holder: t2.applicantDid, counterparty: t2.communityDid, site: t2.host, terms: { code: t2.code, title: n2?.title ?? t2.code, url: n2?.url ?? `` }, reached: { requestId: t2.requestId, requestDigest: t2.requestDigest, replyDigest: t2.replyDigest, at: t2.at }, status: I(t2.effect), effect: t2.effect, via: `join-request` };
}
function R(e2) {
  if (!e2 || typeof e2 != `object`) return false;
  let t2 = e2;
  return typeof t2.id == `string` && t2.kind === `myterms` && typeof t2.vtaDid == `string` && typeof t2.holder == `string` && typeof t2.counterparty == `string` && typeof t2.site == `string` && !!t2.terms && typeof t2.terms.code == `string` && !!t2.reached && typeof t2.reached.at == `number` && (t2.status === `proffered` || t2.status === `agreed` || t2.status === `declined`);
}
var z = `room-consent:`;
function ne(e2, t2, n2) {
  let r2 = new Set(t2);
  if (r2.has(n2)) return r2.delete(n2), r2;
  let i2 = e2.find((e3) => e3.key === n2);
  if (!i2) return r2;
  for (let t3 of e2) t3.roomId === i2.roomId && r2.delete(t3.key);
  return r2.add(n2), r2;
}
function B(e2) {
  return `Share ${e2 === 1 ? `1 room` : `${e2} rooms`}`;
}
function V(e2, t2) {
  let n2 = /* @__PURE__ */ new Set();
  for (let r2 of e2) r2.secretKind === `didSelfIssued` && typeof r2.principalDid == `string` && r2.principalDid.startsWith(`did:`) && r2.principalDid !== t2 && r2.targets.some((e3) => e3.kind === `did` && e3.did === t2) && n2.add(r2.principalDid);
  return [...n2];
}
var H = `noRoomOffers`;
function U(e2) {
  let t2 = /* @__PURE__ */ new Map();
  for (let n2 of e2) {
    if (n2.secretKind !== `didSelfIssued`) continue;
    let e3 = n2.principalDid;
    if (typeof e3 == `string` && e3.startsWith(`did:`)) for (let r2 of n2.targets) r2.kind === `did` && typeof r2.did == `string` && r2.did.startsWith(`did:`) && r2.did !== e3 && (t2.has(r2.did) || t2.set(r2.did, /* @__PURE__ */ new Set()), t2.get(r2.did).add(e3));
  }
  return [...t2].map(([e3, t3]) => ({ communityDid: e3, members: [...t3] }));
}
function W(e2, t2, n2) {
  return n2 !== t2 && e2.some((e3) => e3.communityDid === t2 && e3.members.includes(n2));
}
function G(e2) {
  return typeof e2 == `string` ? [...e2.trim()].slice(0, 200).join(``) : ``;
}
var K = 1e3;
function q(e2) {
  if (typeof e2 != `string`) return;
  let t2 = [...e2.trim()].slice(0, K).join(``);
  return t2 === `` ? void 0 : t2;
}
function J(e2) {
  return e2 === `open` ? `The room is open: accepting records that you took up the offer. Your agent stores the room's membership and authority credentials, so you can read and write there as this identity.` : `Your agent stores the room's membership and authority credentials, makes a key package for you, and joins the room's encrypted group with the Welcome the community sends back. Its members will see this identity join. The room's keys stay in your agent.`;
}
var Y = { "domain-linkage": `checking the website belongs to the community`, join: `join (recording the service in your vault)`, "join-manifest": `asking the community what it requires to join`, "join-sign": `your agent signing the join request`, "join-submit": `sending the join request to the community`, claim: `claim (sending the code to the community)`, identify: `identify (your agent signing who you are)`, prove: `prove (sending the number to the community)`, "grant-digest": `preparing the approval`, "enrol-uv": `enrolling this browser's sign-in approval key at your agent`, grant: `grant (your agent signing the decision)`, respond: `respond (sending the decision to the community)` }, X = { community: `the community`, vta: `your agent`, wallet: `this wallet (a reply did not check out)` }, Z = { "domain-not-linked": `The website doesn't publish a DID Configuration that links it to the community's DID, so nothing was sent to it.`, "unsupported-vid": `The code names a kind of identifier this wallet can't check yet. An update may add it.` };
function Q(e2) {
  switch (e2.reason) {
    case `no-portal-service`:
      return e2.unusable ? `This service's DID document lists a sign-in portal (a SignInPortal service), but its endpoint isn't usable: it must be an https URL on a public host name, with no port or credentials. Ask its operator to fix it.` : `This service's DID document doesn't list a sign-in portal (a SignInPortal service). Ask its operator to add one.`;
    case `no-common-transport`:
      return e2.unusable ? `This service's DID document lists a Trust-Task endpoint (a TrustTaskHTTPS service), but its endpoint isn't usable: it must be an https URL on a public host name, with no port or credentials. Ask its operator to fix it.` : `This service's DID document doesn't list a Trust-Task endpoint (a TrustTaskHTTPS service), so the wallet has nowhere to send the sign-in. Ask its operator to add one.`;
    case `wrong-origin`:
      return e2.pageOrigin ? `This page (${e2.pageOrigin}) isn't the service's sign-in page (${e2.portalOrigin}). Start sign-in from ${e2.portalOrigin}, or ask the operator to point the SignInPortal service at this page.` : `The wallet couldn't tell which page this code came from, so it couldn't confirm it is the service's sign-in page (${e2.portalOrigin}).`;
    case `did-document-unverified`:
      return `The wallet couldn't fetch or verify this service's DID document. Check that the DID below is published and its log verifies, and that its host is a public name on the default https port.`;
    case `unsupported-vid`:
      return e2.method ? `This wallet can't resolve ${e2.method} DIDs yet, so it can't check this service. An update may add it.` : Z[`unsupported-vid`];
    case `from-not-allowed`:
      return `Sign-in doesn't accept ${e2.method ? `a ${e2.method} DID` : `this kind of DID`} as the service's identifier. The service needs a DID that can list a sign-in portal, such as did:webvh.`;
    case `domain-not-linked`:
      return `The website (${e2.portalOrigin}) doesn't publish a DID Configuration that links it to the community's DID, so nothing was sent to it. Its operator needs to serve /.well-known/did-configuration.json with a Domain Linkage credential for the DID below.`;
  }
}
function re(e2) {
  if (e2.kind === `refused`) {
    if (!e2.detail) return [];
    let t3 = [[`Code`, e2.detail.reason]], n3 = Q(e2.detail);
    return n3 && t3.push([`Meaning`, n3]), e2.detail.did && t3.push([`DID`, e2.detail.did]), t3;
  }
  let t2 = [[`Code`, e2.code]], n2 = (e2.detail && Q(e2.detail)) ?? Z[e2.code];
  return n2 && t2.push([`Meaning`, n2]), e2.cause && e2.cause !== e2.code && t2.push([`Cause`, e2.cause]), e2.stage && t2.push([`Step`, Y[e2.stage] ?? e2.stage]), e2.party && t2.push([`Refused by`, X[e2.party] ?? e2.party]), e2.detail?.did && t2.push([`DID`, e2.detail.did]), t2;
}
function ie(e2) {
  return typeof e2 == `string` && /^[A-Za-z][A-Za-z0-9_.:/-]{0,79}$/.test(e2) ? e2 : void 0;
}
var ae = `agreements:`, oe = `agreement-prefs:`;
async function $(e2) {
  let t2 = `${ae}${e2.vtaDid}`, n2 = (await chrome.storage.local.get(t2))[t2], r2 = Array.isArray(n2) ? n2 : [];
  r2.push(e2), await chrome.storage.local.set({ [t2]: r2.slice(-200) });
}
async function se(e2) {
  let t2 = `${oe}${e2}`, n2 = (await chrome.storage.local.get(t2))[t2];
  if (!n2 || typeof n2 != `object` || Array.isArray(n2)) return {};
  let r2 = {};
  for (let [e3, t3] of Object.entries(n2)) {
    let n3 = t3?.terms, i2 = t3?.offer;
    typeof n3 == `boolean` && (r2[e3] = { terms: n3, ...typeof i2 == `string` && i2 !== `` ? { offer: i2 } : {} });
  }
  return r2;
}
async function ce(e2, t2) {
  return (await se(e2))[t2];
}
async function le() {
  let e2 = await chrome.storage.local.get(null), t2 = [];
  for (let [n2, r2] of Object.entries(e2)) n2.startsWith(`agreements:`) && Array.isArray(r2) && t2.push(...r2.filter(R));
  return t2;
}
function ue(e2, t2) {
  let n2 = t2.host?.toLowerCase();
  return e2.filter((e3) => n2 !== void 0 && e3.site.toLowerCase() === n2 || t2.counterparty !== void 0 && e3.counterparty === t2.counterparty).sort((e3, t3) => t3.reached.at - e3.reached.at);
}
export {
  L as _,
  re as a,
  k as b,
  J as c,
  G as d,
  U as f,
  ne as g,
  B as h,
  le as i,
  W as l,
  V as m,
  ue as n,
  ie as o,
  z as p,
  $ as r,
  H as s,
  ce as t,
  q as u,
  N as v,
  ee as x,
  F as y
};
