import { _ as e, a as t, m as n, y as r } from "./didcomm-D5nXYRy6.js";
import { t as i } from "./ed25519-CV189T12.js";
function a(e2) {
  let t2 = /* @__PURE__ */ new WeakSet();
  return n2(e2);
  function n2(e3) {
    if (e3 === null) return `null`;
    if (e3 === true) return `true`;
    if (e3 === false) return `false`;
    if (typeof e3 == `number`) {
      if (!Number.isFinite(e3)) throw Error(`JCS rejects non-finite numbers`);
      return Object.is(e3, -0) ? `0` : String(e3);
    }
    if (typeof e3 == `string`) return r2(e3);
    if (Array.isArray(e3)) {
      if (t2.has(e3)) throw Error(`circular reference in JCS input`);
      t2.add(e3);
      let r3 = `[` + e3.map(n2).join(`,`) + `]`;
      return t2.delete(e3), r3;
    }
    if (typeof e3 == `object` && e3) {
      if (t2.has(e3)) throw Error(`circular reference in JCS input`);
      t2.add(e3);
      let i2 = e3, a2 = Object.keys(i2).sort().map((e4) => r2(e4) + `:` + n2(i2[e4]));
      return t2.delete(e3), `{` + a2.join(`,`) + `}`;
    }
    throw Error(`JCS cannot encode value of type ${typeof e3}`);
  }
  function r2(e3) {
    let t3 = `"`;
    for (let n3 = 0; n3 < e3.length; n3++) {
      let r3 = e3.charCodeAt(n3);
      t3 += r3 === 34 ? `\\"` : r3 === 92 ? `\\\\` : r3 === 8 ? `\\b` : r3 === 12 ? `\\f` : r3 === 10 ? `\\n` : r3 === 13 ? `\\r` : r3 === 9 ? `\\t` : r3 < 32 ? `\\u` + r3.toString(16).padStart(4, `0`) : e3[n3];
    }
    return t3 + `"`;
  }
}
var o = `123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz`;
function s(e2) {
  let t2 = 0;
  for (; t2 < e2.length && e2[t2] === 0; ) t2++;
  let n2 = [];
  for (let t3 = 0; t3 < e2.length; t3++) {
    let r3 = e2[t3];
    for (let e3 = 0; e3 < n2.length; e3++) r3 += n2[e3] << 8, n2[e3] = r3 % 58, r3 = r3 / 58 | 0;
    for (; r3 > 0; ) n2.push(r3 % 58), r3 = r3 / 58 | 0;
  }
  let r2 = ``;
  for (let e3 = 0; e3 < t2; e3++) r2 += `1`;
  for (let e3 = n2.length - 1; e3 >= 0; e3--) r2 += o[n2[e3]];
  return r2;
}
function c(e2) {
  let t2 = 0;
  for (; t2 < e2.length && e2[t2] === `1`; ) t2++;
  let n2 = [];
  for (let t3 = 0; t3 < e2.length; t3++) {
    let r3 = e2[t3], i2 = o.indexOf(r3);
    if (i2 === -1) throw Error(`invalid base58btc character: ${r3}`);
    let a2 = i2;
    for (let e3 = 0; e3 < n2.length; e3++) a2 += n2[e3] * 58, n2[e3] = a2 & 255, a2 >>= 8;
    for (; a2 > 0; ) n2.push(a2 & 255), a2 >>= 8;
  }
  let r2 = new Uint8Array(t2 + n2.length);
  for (let e3 = 0; e3 < n2.length; e3++) r2[t2 + n2.length - 1 - e3] = n2[e3];
  return r2;
}
async function l(e2) {
  let t2 = new TextEncoder().encode(e2);
  return new Uint8Array(await crypto.subtle.digest(`SHA-256`, t2));
}
var u = e.ED25519_PUB;
async function d(e2, t2 = {}) {
  let n2 = e2.proof;
  if (!n2 || typeof n2 != `object`) return { verified: false, reason: `no proof` };
  if (n2.type !== `DataIntegrityProof` || n2.cryptosuite !== `eddsa-jcs-2022`) return { verified: false, reason: `unsupported proof suite: ${n2.type}/${n2.cryptosuite}` };
  if (t2.expectedProofPurpose && n2.proofPurpose !== t2.expectedProofPurpose) return { verified: false, reason: `proofPurpose ${n2.proofPurpose} != ${t2.expectedProofPurpose}` };
  let r2 = n2.verificationMethod;
  if (typeof r2 != `string` || !r2.includes(`#`)) return { verified: false, reason: `missing/invalid verificationMethod` };
  if (typeof n2.proofValue != `string` || !n2.proofValue.startsWith(`z`)) return { verified: false, reason: `missing/invalid proofValue (expected multibase 'z')` };
  let o2 = r2.slice(0, r2.indexOf(`#`)), s2, u2;
  try {
    ({ key: s2, doc: u2 } = await p(r2, o2, t2.resolveDid));
  } catch (e3) {
    return { verified: false, signer: o2, reason: `verificationMethod resolution failed: ${e3 instanceof Error ? e3.message : String(e3)}` };
  }
  if (t2.expectedProofPurpose && !f(u2, r2, t2.expectedProofPurpose)) return { verified: false, signer: o2, reason: `${r2} is not listed under ${t2.expectedProofPurpose} in the DID document of ${o2}` };
  let d2 = { ...n2 };
  delete d2.proofValue;
  let m = { ...e2 };
  delete m.proof;
  let h = await l(a(d2)), g = await l(a(m)), _ = new Uint8Array(h.length + g.length);
  _.set(h, 0), _.set(g, h.length);
  let v = c(n2.proofValue.slice(1));
  return v.length === 64 ? i.verify(v, _, s2) ? { verified: true, signer: o2 } : { verified: false, signer: o2, reason: `signature verification failed` } : { verified: false, signer: o2, reason: `unexpected signature length: ${v.length}` };
}
function f(e2, t2, n2) {
  let r2 = t2.indexOf(`#`), i2 = r2 >= 0 ? t2.slice(r2) : void 0, a2 = (e3) => typeof e3 == `string` && (e3 === t2 || i2 !== void 0 && e3 === i2), o2 = e2[n2];
  return Array.isArray(o2) ? o2.some((e3) => typeof e3 == `string` ? a2(e3) : typeof e3 == `object` && !!e3 && a2(e3.id)) : false;
}
async function p(e2, i2, a2) {
  let o2 = i2.startsWith(`did:key:`) ? n(i2).didDocument : await (a2 ?? t)(i2), s2 = o2.verificationMethod ?? [], c2 = s2.find((t2) => t2.id === e2) ?? s2.find((t2) => t2.id.endsWith(e2.slice(e2.indexOf(`#`))));
  if (!c2?.publicKeyMultibase) throw Error(`verificationMethod ${e2} not found or missing publicKeyMultibase`);
  let { codec: l2, key: d2 } = r(c2.publicKeyMultibase);
  if (l2[0] !== u[0] || l2[1] !== u[1]) throw Error(`verificationMethod key is not Ed25519`);
  return { key: d2, doc: o2 };
}
export {
  a,
  s as i,
  d as n,
  l as o,
  c as r,
  f as t
};
