var e = BigInt(2 ** 32 - 1), t = BigInt(32);
function n(n2, r2 = false) {
  return r2 ? { h: Number(n2 & e), l: Number(n2 >> t & e) } : { h: Number(n2 >> t & e) | 0, l: Number(n2 & e) | 0 };
}
function r(e2, t2 = false) {
  let r2 = e2.length, i2 = new Uint32Array(r2), a2 = new Uint32Array(r2);
  for (let o2 = 0; o2 < r2; o2++) {
    let { h: r3, l: s2 } = n(e2[o2], t2);
    [i2[o2], a2[o2]] = [r3, s2];
  }
  return [i2, a2];
}
var i = (e2) => e2 / 2 ** 32 | 0, a = (e2) => e2 >>> 0;
function o(e2, t2, n2, r2) {
  let o2 = i(n2), s2 = a(n2);
  e2.setUint32(t2, r2 ? s2 : o2, r2), e2.setUint32(t2 + 4, r2 ? o2 : s2, r2);
}
var s = (e2, t2, n2) => e2 >>> n2, c = (e2, t2, n2) => e2 << 32 - n2 | t2 >>> n2, l = (e2, t2, n2) => e2 >>> n2 | t2 << 32 - n2, u = (e2, t2, n2) => e2 << 32 - n2 | t2 >>> n2, d = (e2, t2, n2) => e2 << 64 - n2 | t2 >>> n2 - 32, f = (e2, t2, n2) => e2 >>> n2 - 32 | t2 << 64 - n2;
function p(e2, t2, n2, r2) {
  let i2 = (t2 >>> 0) + (r2 >>> 0);
  return { h: e2 + n2 + (i2 / 2 ** 32 | 0) | 0, l: i2 | 0 };
}
var m = (e2, t2, n2) => (e2 >>> 0) + (t2 >>> 0) + (n2 >>> 0), h = (e2, t2, n2, r2) => t2 + n2 + r2 + (e2 / 2 ** 32 | 0) | 0, g = (e2, t2, n2, r2) => (e2 >>> 0) + (t2 >>> 0) + (n2 >>> 0) + (r2 >>> 0), _ = (e2, t2, n2, r2, i2) => t2 + n2 + r2 + i2 + (e2 / 2 ** 32 | 0) | 0, v = (e2, t2, n2, r2, i2) => (e2 >>> 0) + (t2 >>> 0) + (n2 >>> 0) + (r2 >>> 0) + (i2 >>> 0), y = (e2, t2, n2, r2, i2, a2) => t2 + n2 + r2 + i2 + a2 + (e2 / 2 ** 32 | 0) | 0;
function b(e2) {
  return e2 instanceof Uint8Array || ArrayBuffer.isView(e2) && e2.constructor.name === `Uint8Array` && `BYTES_PER_ELEMENT` in e2 && e2.BYTES_PER_ELEMENT === 1;
}
var x = (e2) => e2 ? `"${e2}" ` : ``;
function S(e2, t2 = ``) {
  if (typeof e2 != `number`) throw TypeError(x(t2) + `expected number, got ` + typeof e2);
  if (!Number.isSafeInteger(e2) || e2 < 0) throw RangeError(x(t2) + `expected integer >= 0, got ` + e2);
  return e2;
}
function C(e2, t2, n2 = ``) {
  if (b(e2) && (t2 === void 0 || e2.length === t2)) return e2;
  t2 !== void 0 && S(t2, `length`);
  let r2 = b(e2), i2 = t2 === void 0 ? `` : ` of length ${t2}`, a2 = r2 ? `length=${e2.length}` : `type=${typeof e2}`, o2 = x(n2) + `expected Uint8Array` + i2 + `, got ` + a2;
  throw r2 ? RangeError(o2) : TypeError(o2);
}
function w(e2) {
  if (typeof e2 != `function` || typeof e2.create != `function`) throw TypeError(`expected hash wrapped by utils.createHasher`);
  if (S(e2.outputLen), S(e2.blockLen), e2.outputLen < 1 || e2.blockLen < 1) throw Error(`hash blockLen / outputLen must be >= 1`);
}
var T = (e2, t2) => {
  if (typeof e2 != `object` || !e2 || Array.isArray(e2)) throw TypeError((t2 === `object` ? `` : `"${t2}" `) + `expected object, got type=` + typeof e2);
}, E = (e2, t2) => {
  T(e2, t2);
  let n2 = Object.getPrototypeOf(e2);
  if (n2 !== Object.prototype && n2 !== null) throw TypeError(`"${t2}" expected plain object`);
  if (Object.hasOwn(e2, `__proto__`)) throw TypeError(`"${t2}.__proto__" is not allowed`);
};
function D(e2, t2 = true) {
  if (e2.destroyed) throw Error(`hash was destroyed`);
  if (t2 && e2.finished) throw Error(`digest() was already called`);
}
function O(e2, t2) {
  C(e2, void 0, `output`);
  let n2 = t2.outputLen;
  if (!(e2.length >= n2)) throw RangeError(`"output" expected length >= ` + n2);
}
function k(...e2) {
  for (let t2 = 0; t2 < e2.length; t2++) e2[t2].fill(0);
}
function A(e2) {
  return new DataView(e2.buffer, e2.byteOffset, e2.byteLength);
}
function j(e2, t2) {
  return e2 << 32 - t2 | e2 >>> t2;
}
var ee = typeof Uint8Array.from([]).toHex == `function` && typeof Uint8Array.fromHex == `function`, te = Array.from({ length: 256 }, (e2, t2) => t2.toString(16).padStart(2, `0`));
function ne(e2) {
  if (C(e2), ee) return e2.toHex();
  let t2 = ``;
  for (let n2 = 0; n2 < e2.length; n2++) t2 += te[e2[n2]];
  return t2;
}
function re(e2) {
  return e2 >= 48 && e2 <= 57 ? e2 - 48 : e2 >= 65 && e2 <= 70 ? e2 - 55 : e2 >= 97 && e2 <= 102 ? e2 - 87 : void 0;
}
function ie(e2) {
  if (typeof e2 != `string`) throw TypeError(`hex string expected, got ` + typeof e2);
  if (ee) try {
    return Uint8Array.fromHex(e2);
  } catch (e3) {
    throw e3 instanceof SyntaxError ? RangeError(e3.message) : e3;
  }
  let t2 = e2.length, n2 = t2 / 2;
  if (t2 % 2) throw RangeError(`hex string expected, got unpadded hex of length ` + t2);
  let r2 = new Uint8Array(n2);
  for (let t3 = 0, i2 = 0; t3 < n2; t3++, i2 += 2) {
    let n3 = re(e2.charCodeAt(i2)), a2 = re(e2.charCodeAt(i2 + 1));
    if (n3 === void 0 || a2 === void 0) {
      let t4 = e2[i2] + e2[i2 + 1];
      throw RangeError(`hex string expected, got non-hex character "` + t4 + `" at index ` + i2);
    }
    r2[t3] = n3 * 16 + a2;
  }
  return r2;
}
function ae(...e2) {
  let t2 = 0;
  for (let n3 = 0; n3 < e2.length; n3++) {
    let r2 = e2[n3];
    C(r2), t2 += r2.length;
  }
  let n2 = new Uint8Array(t2);
  for (let t3 = 0, r2 = 0; t3 < e2.length; t3++) {
    let i2 = e2[t3];
    n2.set(i2, r2), r2 += i2.length;
  }
  return n2;
}
function oe(e2, t2, n2 = `opts`) {
  return E(e2, `defaults`), t2 !== void 0 && E(t2, n2), Object.assign(/* @__PURE__ */ Object.create(null), e2, t2);
}
function se(e2, t2 = {}) {
  if (typeof e2 != `function`) throw TypeError(`"hashCons" expected function, got type=` + typeof e2);
  t2 = oe({}, t2, `info`);
  let n2 = (t3, n3) => e2(n3).update(t3).digest(), r2 = e2(void 0);
  return n2.outputLen = r2.outputLen, n2.blockLen = r2.blockLen, n2.canXOF = r2.canXOF, n2.create = (t3) => e2(t3), Object.assign(n2, t2), Object.freeze(n2);
}
function ce(e2 = 32) {
  S(e2, `bytesLength`);
  let t2 = typeof globalThis == `object` ? globalThis.crypto : null;
  if (typeof t2?.getRandomValues != `function`) throw Error(`crypto.getRandomValues must be defined`);
  if (e2 > 65536) throw RangeError(`"bytesLength" expected <= 65536, got ${e2}`);
  return t2.getRandomValues(new Uint8Array(e2));
}
var le = (e2) => ({ oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, e2]) });
function ue(e2, t2, n2) {
  return e2 & t2 ^ ~e2 & n2;
}
function de(e2, t2, n2) {
  return e2 & t2 ^ e2 & n2 ^ t2 & n2;
}
var fe = class {
  blockLen;
  outputLen;
  canXOF = false;
  padOffset;
  isLE;
  buffer;
  view;
  finished = false;
  length = 0;
  pos = 0;
  destroyed = false;
  constructor(e2, t2, n2, r2) {
    this.blockLen = e2, this.outputLen = t2, this.padOffset = n2, this.isLE = r2, this.buffer = new Uint8Array(e2), this.view = A(this.buffer);
  }
  update(e2) {
    D(this), C(e2);
    let { view: t2, buffer: n2, blockLen: r2 } = this, i2 = e2.length, a2 = false;
    for (let o2 = 0; o2 < i2; ) {
      let s2 = Math.min(r2 - this.pos, i2 - o2);
      if (s2 === r2) {
        let t3 = A(e2);
        for (; r2 <= i2 - o2; o2 += r2) this.process(t3, o2);
        a2 = true;
        continue;
      }
      n2.set(o2 === 0 && s2 === i2 ? e2 : e2.subarray(o2, o2 + s2), this.pos), this.pos += s2, o2 += s2, this.pos === r2 && (this.process(t2, 0), this.pos = 0, a2 = true);
    }
    return this.length += e2.length, a2 && this.roundClean(), this;
  }
  digestInto(e2) {
    D(this), O(e2, this), this.finished = true;
    let { buffer: t2, view: n2, blockLen: r2, isLE: i2 } = this, { pos: a2 } = this;
    t2[a2++] = 128, t2.fill(0, a2), this.padOffset > r2 - a2 && (this.process(n2, 0), t2.fill(0)), o(n2, r2 - 8, this.length * 8, i2), this.process(n2, 0), this.roundClean();
    let s2 = e2 === t2 ? n2 : A(e2), c2 = this.outputLen, l2 = c2 / 4, u2 = this.get();
    if (c2 % 4 || l2 > u2.length) throw Error(`invalid outputLen`);
    for (let e3 = 0; e3 < l2; e3++) s2.setUint32(4 * e3, u2[e3], i2);
  }
  digest() {
    let { buffer: e2, outputLen: t2 } = this;
    this.digestInto(e2);
    let n2 = e2.slice(0, t2);
    return this.destroy(), n2;
  }
  _cloneIntoMeta(e2) {
    let { buffer: t2, length: n2, finished: r2, destroyed: i2, pos: a2 } = this;
    return e2.destroyed = i2, e2.finished = r2, e2.length = n2, e2.pos = a2, a2 && e2.buffer.set(t2), e2;
  }
  clone() {
    return this._cloneInto();
  }
}, pe = Uint32Array.from([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]), me = Uint32Array.from([1779033703, 4089235720, 3144134277, 2227873595, 1013904242, 4271175723, 2773480762, 1595750129, 1359893119, 2917565137, 2600822924, 725511199, 528734635, 4215389547, 1541459225, 327033209]), he = Uint32Array.from([1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298]), M = new Uint32Array(64), ge = class extends fe {
  A = 0;
  B = 0;
  C = 0;
  D = 0;
  E = 0;
  F = 0;
  G = 0;
  H = 0;
  constructor(e2, t2) {
    super(64, e2, 8, false), this.A = t2[0] | 0, this.B = t2[1] | 0, this.C = t2[2] | 0, this.D = t2[3] | 0, this.E = t2[4] | 0, this.F = t2[5] | 0, this.G = t2[6] | 0, this.H = t2[7] | 0;
  }
  get() {
    let { A: e2, B: t2, C: n2, D: r2, E: i2, F: a2, G: o2, H: s2 } = this;
    return [e2, t2, n2, r2, i2, a2, o2, s2];
  }
  set(e2, t2, n2, r2, i2, a2, o2, s2) {
    this.A = e2 | 0, this.B = t2 | 0, this.C = n2 | 0, this.D = r2 | 0, this.E = i2 | 0, this.F = a2 | 0, this.G = o2 | 0, this.H = s2 | 0;
  }
  _cloneInto(e2) {
    return (e2 ||= new this.constructor()).set(...this.get()), this._cloneIntoMeta(e2);
  }
  process(e2, t2) {
    for (let n3 = 0; n3 < 16; n3++, t2 += 4) M[n3] = e2.getUint32(t2, false);
    for (let e3 = 16; e3 < 64; e3++) {
      let t3 = M[e3 - 15], n3 = M[e3 - 2], r3 = j(t3, 7) ^ j(t3, 18) ^ t3 >>> 3, i3 = j(n3, 17) ^ j(n3, 19) ^ n3 >>> 10;
      M[e3] = i3 + M[e3 - 7] + r3 + M[e3 - 16] | 0;
    }
    let { A: n2, B: r2, C: i2, D: a2, E: o2, F: s2, G: c2, H: l2 } = this;
    for (let e3 = 0; e3 < 64; e3++) {
      let t3 = j(o2, 6) ^ j(o2, 11) ^ j(o2, 25), u2 = l2 + t3 + ue(o2, s2, c2) + he[e3] + M[e3] | 0, d2 = (j(n2, 2) ^ j(n2, 13) ^ j(n2, 22)) + de(n2, r2, i2) | 0;
      l2 = c2, c2 = s2, s2 = o2, o2 = a2 + u2 | 0, a2 = i2, i2 = r2, r2 = n2, n2 = u2 + d2 | 0;
    }
    n2 = n2 + this.A | 0, r2 = r2 + this.B | 0, i2 = i2 + this.C | 0, a2 = a2 + this.D | 0, o2 = o2 + this.E | 0, s2 = s2 + this.F | 0, c2 = c2 + this.G | 0, l2 = l2 + this.H | 0, this.set(n2, r2, i2, a2, o2, s2, c2, l2);
  }
  roundClean() {
    k(M);
  }
  destroy() {
    this.destroyed = true, this.set(0, 0, 0, 0, 0, 0, 0, 0), k(this.buffer);
  }
}, _e = class extends ge {
  constructor() {
    super(32, pe);
  }
}, ve = r(`0x428a2f98d728ae22.0x7137449123ef65cd.0xb5c0fbcfec4d3b2f.0xe9b5dba58189dbbc.0x3956c25bf348b538.0x59f111f1b605d019.0x923f82a4af194f9b.0xab1c5ed5da6d8118.0xd807aa98a3030242.0x12835b0145706fbe.0x243185be4ee4b28c.0x550c7dc3d5ffb4e2.0x72be5d74f27b896f.0x80deb1fe3b1696b1.0x9bdc06a725c71235.0xc19bf174cf692694.0xe49b69c19ef14ad2.0xefbe4786384f25e3.0x0fc19dc68b8cd5b5.0x240ca1cc77ac9c65.0x2de92c6f592b0275.0x4a7484aa6ea6e483.0x5cb0a9dcbd41fbd4.0x76f988da831153b5.0x983e5152ee66dfab.0xa831c66d2db43210.0xb00327c898fb213f.0xbf597fc7beef0ee4.0xc6e00bf33da88fc2.0xd5a79147930aa725.0x06ca6351e003826f.0x142929670a0e6e70.0x27b70a8546d22ffc.0x2e1b21385c26c926.0x4d2c6dfc5ac42aed.0x53380d139d95b3df.0x650a73548baf63de.0x766a0abb3c77b2a8.0x81c2c92e47edaee6.0x92722c851482353b.0xa2bfe8a14cf10364.0xa81a664bbc423001.0xc24b8b70d0f89791.0xc76c51a30654be30.0xd192e819d6ef5218.0xd69906245565a910.0xf40e35855771202a.0x106aa07032bbd1b8.0x19a4c116b8d2d0c8.0x1e376c085141ab53.0x2748774cdf8eeb99.0x34b0bcb5e19b48a8.0x391c0cb3c5c95a63.0x4ed8aa4ae3418acb.0x5b9cca4f7763e373.0x682e6ff3d6b2b8a3.0x748f82ee5defb2fc.0x78a5636f43172f60.0x84c87814a1f0ab72.0x8cc702081a6439ec.0x90befffa23631e28.0xa4506cebde82bde9.0xbef9a3f7b2c67915.0xc67178f2e372532b.0xca273eceea26619c.0xd186b8c721c0c207.0xeada7dd6cde0eb1e.0xf57d4f7fee6ed178.0x06f067aa72176fba.0x0a637dc5a2c898a6.0x113f9804bef90dae.0x1b710b35131c471b.0x28db77f523047d84.0x32caab7b40c72493.0x3c9ebe0a15c9bebc.0x431d67c49c100d4c.0x4cc5d4becb3e42b6.0x597f299cfc657e2a.0x5fcb6fab3ad6faec.0x6c44198c4a475817`.split(`.`).map((e2) => BigInt(e2))), ye = ve[0], be = ve[1], N = new Uint32Array(80), P = new Uint32Array(80), xe = class extends fe {
  Ah = 0;
  Al = 0;
  Bh = 0;
  Bl = 0;
  Ch = 0;
  Cl = 0;
  Dh = 0;
  Dl = 0;
  Eh = 0;
  El = 0;
  Fh = 0;
  Fl = 0;
  Gh = 0;
  Gl = 0;
  Hh = 0;
  Hl = 0;
  constructor(e2, t2) {
    super(128, e2, 16, false), this.Ah = t2[0] | 0, this.Al = t2[1] | 0, this.Bh = t2[2] | 0, this.Bl = t2[3] | 0, this.Ch = t2[4] | 0, this.Cl = t2[5] | 0, this.Dh = t2[6] | 0, this.Dl = t2[7] | 0, this.Eh = t2[8] | 0, this.El = t2[9] | 0, this.Fh = t2[10] | 0, this.Fl = t2[11] | 0, this.Gh = t2[12] | 0, this.Gl = t2[13] | 0, this.Hh = t2[14] | 0, this.Hl = t2[15] | 0;
  }
  get() {
    let { Ah: e2, Al: t2, Bh: n2, Bl: r2, Ch: i2, Cl: a2, Dh: o2, Dl: s2, Eh: c2, El: l2, Fh: u2, Fl: d2, Gh: f2, Gl: p2, Hh: m2, Hl: h2 } = this;
    return [e2, t2, n2, r2, i2, a2, o2, s2, c2, l2, u2, d2, f2, p2, m2, h2];
  }
  set(e2, t2, n2, r2, i2, a2, o2, s2, c2, l2, u2, d2, f2, p2, m2, h2) {
    this.Ah = e2 | 0, this.Al = t2 | 0, this.Bh = n2 | 0, this.Bl = r2 | 0, this.Ch = i2 | 0, this.Cl = a2 | 0, this.Dh = o2 | 0, this.Dl = s2 | 0, this.Eh = c2 | 0, this.El = l2 | 0, this.Fh = u2 | 0, this.Fl = d2 | 0, this.Gh = f2 | 0, this.Gl = p2 | 0, this.Hh = m2 | 0, this.Hl = h2 | 0;
  }
  _cloneInto(e2) {
    return (e2 ||= new this.constructor()).set(...this.get()), this._cloneIntoMeta(e2);
  }
  process(e2, t2) {
    for (let n3 = 0; n3 < 16; n3++, t2 += 4) N[n3] = e2.getUint32(t2), P[n3] = e2.getUint32(t2 += 4);
    for (let e3 = 16; e3 < 80; e3++) {
      let t3 = N[e3 - 15] | 0, n3 = P[e3 - 15] | 0, r3 = l(t3, n3, 1) ^ l(t3, n3, 8) ^ s(t3, n3, 7), i3 = u(t3, n3, 1) ^ u(t3, n3, 8) ^ c(t3, n3, 7), a3 = N[e3 - 2] | 0, o3 = P[e3 - 2] | 0, p2 = l(a3, o3, 19) ^ d(a3, o3, 61) ^ s(a3, o3, 6), m2 = g(i3, u(a3, o3, 19) ^ f(a3, o3, 61) ^ c(a3, o3, 6), P[e3 - 7], P[e3 - 16]), h2 = _(m2, r3, p2, N[e3 - 7], N[e3 - 16]);
      N[e3] = h2 | 0, P[e3] = m2 | 0;
    }
    let { Ah: n2, Al: r2, Bh: i2, Bl: a2, Ch: o2, Cl: b2, Dh: x2, Dl: S2, Eh: C2, El: w2, Fh: T2, Fl: E2, Gh: D2, Gl: O2, Hh: k2, Hl: A2 } = this;
    for (let e3 = 0; e3 < 80; e3++) {
      let t3 = l(C2, w2, 14) ^ l(C2, w2, 18) ^ d(C2, w2, 41), s2 = u(C2, w2, 14) ^ u(C2, w2, 18) ^ f(C2, w2, 41), c2 = C2 & T2 ^ ~C2 & D2, g2 = w2 & E2 ^ ~w2 & O2, _2 = v(A2, s2, g2, be[e3], P[e3]), j2 = y(_2, k2, t3, c2, ye[e3], N[e3]), ee2 = _2 | 0, te2 = l(n2, r2, 28) ^ d(n2, r2, 34) ^ d(n2, r2, 39), ne2 = u(n2, r2, 28) ^ f(n2, r2, 34) ^ f(n2, r2, 39), re2 = n2 & i2 ^ n2 & o2 ^ i2 & o2, ie2 = r2 & a2 ^ r2 & b2 ^ a2 & b2;
      k2 = D2 | 0, A2 = O2 | 0, D2 = T2 | 0, O2 = E2 | 0, T2 = C2 | 0, E2 = w2 | 0, { h: C2, l: w2 } = p(x2 | 0, S2 | 0, j2 | 0, ee2 | 0), x2 = o2 | 0, S2 = b2 | 0, o2 = i2 | 0, b2 = a2 | 0, i2 = n2 | 0, a2 = r2 | 0;
      let ae2 = m(ee2, ne2, ie2);
      n2 = h(ae2, j2, te2, re2), r2 = ae2 | 0;
    }
    ({ h: n2, l: r2 } = p(this.Ah | 0, this.Al | 0, n2 | 0, r2 | 0)), { h: i2, l: a2 } = p(this.Bh | 0, this.Bl | 0, i2 | 0, a2 | 0), { h: o2, l: b2 } = p(this.Ch | 0, this.Cl | 0, o2 | 0, b2 | 0), { h: x2, l: S2 } = p(this.Dh | 0, this.Dl | 0, x2 | 0, S2 | 0), { h: C2, l: w2 } = p(this.Eh | 0, this.El | 0, C2 | 0, w2 | 0), { h: T2, l: E2 } = p(this.Fh | 0, this.Fl | 0, T2 | 0, E2 | 0), { h: D2, l: O2 } = p(this.Gh | 0, this.Gl | 0, D2 | 0, O2 | 0), { h: k2, l: A2 } = p(this.Hh | 0, this.Hl | 0, k2 | 0, A2 | 0), this.set(n2, r2, i2, a2, o2, b2, x2, S2, C2, w2, T2, E2, D2, O2, k2, A2);
  }
  roundClean() {
    k(N, P);
  }
  destroy() {
    this.destroyed = true, k(this.buffer), this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  }
}, Se = class extends xe {
  constructor() {
    super(64, me);
  }
}, Ce = se(() => new _e(), le(1)), we = se(() => new Se(), le(3));
function Te(e2, t2, n2 = () => {
}) {
  if (!Array.isArray(e2)) throw TypeError(`"${t2}" expected array, got type=${typeof e2}`);
  for (let r2 = 0; r2 < e2.length; r2++) n2(e2[r2], `${t2}[${r2}]`);
  return e2;
}
var F = (e2, t2, n2) => C(e2, t2, n2), Ee = S;
function De(e2, t2 = ``) {
  if (typeof e2 != `string`) {
    let n2 = t2 && `"${t2}" `;
    throw TypeError(n2 + `expected string, got type=` + typeof e2);
  }
  return e2;
}
function I(e2, t2 = `object`) {
  if (typeof e2 != `object` || !e2 || Array.isArray(e2)) throw TypeError(t2 === `object` ? `expected valid options object` : `"${t2}" expected object, got type=${typeof e2}`);
  return e2;
}
function Oe(e2, t2) {
  if (typeof e2 != `function`) throw TypeError(`"${t2}" is invalid: expected function, got ${typeof e2}`);
  return e2;
}
var ke = ne, Ae = (...e2) => ae(...e2), je = (e2) => ie(e2), Me = b, Ne = (e2) => ce(e2), Pe = BigInt(0), Fe = BigInt(1), Ie = (e2) => e2 ? `"${e2}" ` : ``;
function L(e2, t2 = ``) {
  if (typeof e2 != `boolean`) throw TypeError(Ie(t2) + `expected boolean, got type=` + typeof e2);
  return e2;
}
function Le(e2) {
  if (typeof e2 == `bigint`) {
    if (!V(e2)) throw RangeError(`positive bigint expected, got ` + e2);
  } else Ee(e2);
  return e2;
}
function R(e2, t2 = ``) {
  if (typeof e2 != `number`) {
    let n2 = t2 && `"${t2}" `;
    throw TypeError(n2 + `expected number, got type=` + typeof e2);
  }
  if (!Number.isSafeInteger(e2)) {
    let n2 = t2 && `"${t2}" `;
    throw RangeError(n2 + `expected safe integer, got ` + e2);
  }
}
function Re(e2) {
  let t2 = Le(e2).toString(16);
  return t2.length & 1 ? `0` + t2 : t2;
}
function ze(e2) {
  if (typeof e2 != `string`) throw TypeError(`hex string expected, got ` + typeof e2);
  return e2 === `` ? Pe : BigInt(`0x` + e2);
}
function Be(e2) {
  return ze(ne(e2));
}
function z(e2) {
  return ze(ne(B(C(e2)).reverse()));
}
function Ve(e2, t2) {
  if (S(t2), t2 === 0) throw Error(`zero output length is invalid`);
  e2 = Le(e2);
  let n2 = t2 * 2, r2 = e2.toString(16);
  if (r2.length > n2) throw RangeError(`number is too large`);
  return ie(r2.padStart(n2, `0`));
}
function He(e2, t2) {
  return Ve(e2, t2).reverse();
}
function B(e2) {
  return Uint8Array.from(F(e2));
}
function V(e2) {
  return typeof e2 == `bigint` && Pe <= e2;
}
function Ue(e2, t2, n2) {
  return V(e2) && V(t2) && V(n2) && t2 <= e2 && e2 < n2;
}
function H(e2, t2, n2, r2) {
  if (!Ue(t2, n2, r2)) throw RangeError(`expected valid ` + e2 + `: ` + n2 + ` <= n < ` + r2 + `, got ` + t2);
}
function We(e2) {
  if (e2 < Pe) throw Error(`expected non-negative bigint, got ` + e2);
  return e2 === Pe ? 0 : e2.toString(2).length;
}
var Ge = (e2) => (R(e2, `n`), (Fe << BigInt(e2)) - Fe);
function Ke(e2, t2, n2) {
  if (S(e2, `hashLen`), S(t2, `qByteLen`), typeof n2 != `function`) throw TypeError(`hmacFn must be a function`);
  let r2 = (e3) => new Uint8Array(e3), i2 = Uint8Array.of(), a2 = Uint8Array.of(0), o2 = Uint8Array.of(1), s2 = r2(e2), c2 = r2(e2), l2 = 0, u2 = () => {
    s2.fill(1), c2.fill(0), l2 = 0;
  }, d2 = (...e3) => n2(c2, Ae(s2, ...e3)), f2 = (e3 = i2) => {
    c2 = d2(a2, e3), s2 = d2(), e3.length !== 0 && (c2 = d2(o2, e3), s2 = d2());
  }, p2 = () => {
    if (l2++ >= 1e3) throw Error(`drbg: tried max amount of iterations`);
    let e3 = 0, n3 = [];
    for (; e3 < t2; ) {
      s2 = d2();
      let t3 = s2.slice();
      n3.push(t3), e3 += s2.length;
    }
    return Ae(...n3);
  };
  return (e3, t3) => {
    u2(), f2(e3);
    let n3;
    for (; (n3 = t3(p2())) === void 0; ) f2();
    return u2(), n3;
  };
}
function U(e2, t2 = {}, n2 = {}, r2 = `object`) {
  I(e2, r2), I(t2, `fields`), I(n2, `optFields`);
  function i2(t3, n3, i3) {
    let a3 = r2 === `object` ? `param "${String(t3)}"` : `"${r2}.${String(t3)}"`, o2 = e2[t3];
    if (!Object.hasOwn(e2, t3) && (i3 ? o2 !== void 0 : n3 !== `function`)) throw TypeError(`${a3} is invalid: expected own property`);
    if (i3 && o2 === void 0) return;
    let s2 = typeof o2;
    if (s2 !== n3 || o2 === null) throw TypeError(`${a3} is invalid: expected ${n3}, got ${s2}`);
  }
  let a2 = (e3, t3) => Object.entries(e3).forEach(([e4, n3]) => i2(e4, n3, t3));
  a2(t2, false), a2(n2, true);
}
var W = BigInt(0), G = BigInt(1), K = BigInt(2), qe = BigInt(3), Je = BigInt(4), Ye = BigInt(5), Xe = BigInt(7), Ze = BigInt(8), Qe = BigInt(9), $e = BigInt(15), et = BigInt(16), tt = BigInt(`0x10000000000000000`);
function q(e2, t2) {
  if (t2 <= W) throw Error(`mod: expected positive modulus, got ` + t2);
  let n2 = e2 % t2;
  return n2 >= W ? n2 : t2 + n2;
}
function nt(e2, t2, n2) {
  if (n2 <= G) throw Error(`pow: expected modulus > 1, got ` + n2);
  if (typeof t2 != `bigint`) throw TypeError(`invalid exponent: expected bigint, got ` + typeof t2);
  if (t2 < W) throw Error(`invalid exponent, negatives unsupported`);
  if (t2 === W) return G;
  if (t2 === G) return e2;
  let r2 = e2 % n2;
  if (r2 < W && (r2 += n2), t2 < tt) {
    let e3 = G;
    for (; t2 > W; ) t2 & G && (e3 = e3 * r2 % n2), r2 = r2 * r2 % n2, t2 >>= G;
    return e3;
  }
  let i2 = [];
  for (; t2 > W; ) i2.push(Number(t2 & $e)), t2 >>= Je;
  let a2 = Array(16);
  a2[0] = G, a2[1] = r2;
  for (let e3 = 2; e3 < 16; e3++) a2[e3] = a2[e3 - 1] * r2 % n2;
  let o2 = a2[i2[i2.length - 1]];
  for (let e3 = i2.length - 2; e3 >= 0; e3--) {
    o2 = o2 * o2 % n2, o2 = o2 * o2 % n2, o2 = o2 * o2 % n2, o2 = o2 * o2 % n2;
    let t3 = i2[e3];
    t3 !== 0 && (o2 = o2 * a2[t3] % n2);
  }
  return o2;
}
function J(e2, t2, n2) {
  if (n2 <= G) throw Error(`pow2: expected modulus > 1, got ` + n2);
  if (t2 < W) throw Error(`pow2: expected non-negative exponent, got ` + t2);
  let r2 = e2;
  for (; t2-- > W; ) r2 *= r2, r2 %= n2;
  return r2;
}
function rt(e2, t2) {
  if (e2 === W) throw Error(`invert: expected non-zero number`);
  if (t2 <= G) throw Error(`invert: expected modulus > 1, got ` + t2);
  let n2 = q(e2, t2), r2 = t2, i2 = W, a2 = G;
  for (; n2 !== W; ) {
    let e3 = r2 / n2, t3 = r2 - n2 * e3, o2 = i2 - a2 * e3;
    r2 = n2, n2 = t3, i2 = a2, a2 = o2;
  }
  if (r2 !== G) throw Error(`invert: does not exist`);
  return q(i2, t2);
}
function it(e2, t2) {
  if (t2 <= G) throw Error(`invertCt: expected prime modulus > 1, got ` + t2);
  let n2 = q(e2, t2);
  if (n2 === W) throw Error(`invertCt: expected non-zero number`);
  let r2 = nt(n2, t2 - K, t2);
  if (q(n2 * r2, t2) !== G) throw Error(`invertCt: does not exist`);
  return r2;
}
function at(e2, t2, n2) {
  let r2 = e2;
  if (!r2.eql(r2.sqr(t2), n2)) throw Error(`Cannot find square root`);
}
function ot(e2, t2) {
  if ((e2 & G) === W) throw Error(t2 + `: expected odd modulus, got ` + e2);
}
function st(e2, t2) {
  let n2 = e2, r2 = (n2.ORDER + G) / Je, i2 = n2.pow(t2, r2);
  return at(n2, i2, t2), i2;
}
function ct(e2, t2) {
  let n2 = e2, r2 = (n2.ORDER - Ye) / Ze, i2 = n2.mul(t2, K), a2 = n2.pow(i2, r2), o2 = n2.mul(t2, a2), s2 = n2.mul(n2.mul(o2, K), a2), c2 = n2.mul(o2, n2.sub(s2, n2.ONE));
  return at(n2, c2, t2), c2;
}
function lt(e2) {
  let t2 = yt(e2), n2 = ut(e2), r2 = n2(t2, t2.neg(t2.ONE)), i2 = n2(t2, r2), a2 = n2(t2, t2.neg(r2)), o2 = (e2 + Xe) / et;
  return ((e3, t3) => {
    let n3 = e3, s2 = n3.pow(t3, o2), c2 = n3.mul(s2, r2), l2 = n3.mul(s2, i2), u2 = n3.mul(s2, a2), d2 = n3.eql(n3.sqr(c2), t3), f2 = n3.eql(n3.sqr(l2), t3);
    s2 = n3.cmov(s2, c2, d2), c2 = n3.cmov(u2, l2, f2);
    let p2 = n3.eql(n3.sqr(c2), t3), m2 = n3.cmov(s2, c2, p2);
    return at(n3, m2, t3), m2;
  });
}
function ut(e2) {
  if (e2 < qe) throw Error(`sqrt is not defined for small field`);
  ot(e2, `tonelliShanks`);
  let t2 = e2 - G, n2 = 0;
  for (; t2 % K === W; ) t2 /= K, n2++;
  let r2 = K, i2 = yt(e2);
  for (; ht(i2, r2) === 1; ) if (r2++ > 1e3) throw Error(`Cannot find square root: probably non-prime P`);
  if (n2 === 1) return st;
  let a2 = i2.pow(r2, t2), o2 = (t2 + G) / K;
  return function(e3, r3) {
    let i3 = e3;
    if (i3.is0(r3)) return r3;
    if (ht(i3, r3) !== 1) throw Error(`Cannot find square root`);
    let s2 = n2, c2 = i3.mul(i3.ONE, a2), l2 = i3.pow(r3, t2), u2 = i3.pow(r3, o2);
    for (; !i3.eql(l2, i3.ONE); ) {
      if (i3.is0(l2)) throw Error(`Cannot find square root: probably non-prime P`);
      let e4 = 1, t3 = i3.sqr(l2);
      for (; !i3.eql(t3, i3.ONE); ) if (e4++, t3 = i3.sqr(t3), e4 === s2) throw Error(`Cannot find square root`);
      let n3 = G << BigInt(s2 - e4 - 1), r4 = i3.pow(c2, n3);
      s2 = e4, c2 = i3.sqr(r4), l2 = i3.mul(l2, c2), u2 = i3.mul(u2, r4);
    }
    return u2;
  };
}
function dt(e2) {
  return ot(e2, `Fp.sqrt`), e2 % Je === qe ? st : e2 % Ze === Ye ? ct : e2 % et === Qe ? lt(e2) : ut(e2);
}
var ft = (e2, t2) => (q(e2, t2) & G) === G, pt = [`create`, `isValid`, `is0`, `neg`, `inv`, `sqrt`, `sqr`, `eql`, `add`, `sub`, `mul`, `pow`, `div`, `addN`, `subN`, `mulN`, `sqrN`];
function Y(e2) {
  if (I(e2, `field`), typeof e2.ORDER != `bigint`) throw TypeError(`param "ORDER" is invalid: expected bigint, got ` + typeof e2.ORDER);
  R(e2.BYTES, `BYTES`), R(e2.BITS, `BITS`);
  for (let t2 of pt) Oe(e2[t2], `field.` + t2);
  if (e2.BYTES < 1 || e2.BITS < 1) throw Error(`invalid field: expected BYTES/BITS > 0`);
  if (e2.ORDER <= G) throw Error(`invalid field: expected ORDER > 1, got ` + e2.ORDER);
  return e2;
}
function mt(e2, t2, n2 = false) {
  Y(e2), Te(t2, `nums`), L(n2, `passZero`);
  let r2 = e2, i2 = Array(t2.length).fill(n2 ? r2.ZERO : void 0), a2 = t2.reduce((e3, t3, n3) => r2.is0(t3) ? e3 : (i2[n3] = e3, r2.mul(e3, t3)), r2.ONE), o2 = r2.inv(a2);
  return t2.reduceRight((e3, t3, n3) => r2.is0(t3) ? e3 : (i2[n3] = r2.mul(e3, i2[n3]), r2.mul(e3, t3)), o2), i2;
}
function ht(e2, t2) {
  Y(e2);
  let n2 = e2;
  ot(n2.ORDER, `FpLegendre`);
  let r2 = (n2.ORDER - G) / K, i2 = n2.pow(t2, r2), a2 = n2.eql(i2, n2.ONE), o2 = n2.eql(i2, n2.ZERO), s2 = n2.eql(i2, n2.neg(n2.ONE));
  if (!a2 && !o2 && !s2) throw Error(`invalid Legendre symbol result`);
  return a2 ? 1 : o2 ? 0 : -1;
}
function gt(e2, t2) {
  if (t2 !== void 0 && Ee(t2), e2 <= W) throw Error(`invalid n length: expected positive n, got ` + e2);
  if (t2 !== void 0 && t2 < 1) throw Error(`invalid n length: expected positive bit length, got ` + t2);
  let n2 = We(e2);
  if (t2 !== void 0 && t2 < n2) throw Error(`invalid n length: expected nBitLength (${t2}) >= bitLen(n) (${n2})`);
  let r2 = t2 === void 0 ? n2 : t2;
  return { nBitLength: r2, nByteLength: Math.ceil(r2 / 8) };
}
var _t = /* @__PURE__ */ new WeakMap(), vt = class {
  ORDER;
  BITS;
  BYTES;
  isLE;
  ZERO = W;
  ONE = G;
  _lengths;
  _mod;
  constructor(e2, t2 = {}) {
    if (e2 <= G) throw Error(`invalid field: expected ORDER > 1, got ` + e2);
    let n2;
    this.isLE = false, typeof t2 == `object` && t2 && (typeof t2.BITS == `number` && (n2 = t2.BITS), typeof t2.sqrt == `function` && Object.defineProperty(this, "sqrt", { value: t2.sqrt, enumerable: true }), typeof t2.isLE == `boolean` && (this.isLE = t2.isLE), t2.allowedLengths && (this._lengths = Object.freeze(t2.allowedLengths.slice())), typeof t2.modFromBytes == `boolean` && (this._mod = t2.modFromBytes));
    let { nBitLength: r2, nByteLength: i2 } = gt(e2, n2);
    if (i2 > 2048) throw Error(`invalid field: expected ORDER of <= 2048 bytes`);
    this.ORDER = e2, this.BITS = r2, this.BYTES = i2, Object.freeze(this);
  }
  create(e2) {
    return q(e2, this.ORDER);
  }
  isValid(e2) {
    if (typeof e2 != `bigint`) throw TypeError(`invalid field element: expected bigint, got ` + typeof e2);
    return W <= e2 && e2 < this.ORDER;
  }
  is0(e2) {
    return e2 === W;
  }
  isValidNot0(e2) {
    return !this.is0(e2) && this.isValid(e2);
  }
  isOdd(e2) {
    return (e2 & G) === G;
  }
  neg(e2) {
    return q(-e2, this.ORDER);
  }
  eql(e2, t2) {
    return e2 === t2;
  }
  sqr(e2) {
    return q(e2 * e2, this.ORDER);
  }
  add(e2, t2) {
    return q(e2 + t2, this.ORDER);
  }
  sub(e2, t2) {
    return q(e2 - t2, this.ORDER);
  }
  mul(e2, t2) {
    return q(e2 * t2, this.ORDER);
  }
  pow(e2, t2) {
    return nt(e2, t2, this.ORDER);
  }
  div(e2, t2) {
    return q(e2 * rt(t2, this.ORDER), this.ORDER);
  }
  sqrN(e2) {
    return e2 * e2;
  }
  addN(e2, t2) {
    return e2 + t2;
  }
  subN(e2, t2) {
    return e2 - t2;
  }
  mulN(e2, t2) {
    return e2 * t2;
  }
  inv(e2) {
    return rt(e2, this.ORDER);
  }
  sqrt(e2) {
    let t2 = _t.get(this);
    return t2 || _t.set(this, t2 = dt(this.ORDER)), t2(this, e2);
  }
  toBytes(e2) {
    return this.isLE ? He(e2, this.BYTES) : Ve(e2, this.BYTES);
  }
  fromBytes(e2, t2 = false) {
    F(e2);
    let { _lengths: n2, BYTES: r2, isLE: i2, ORDER: a2, _mod: o2 } = this;
    if (n2) {
      if (e2.length < 1 || !n2.includes(e2.length) || e2.length > r2) throw Error(`Field.fromBytes: expected ` + n2 + ` bytes, got ` + e2.length);
      let t3 = new Uint8Array(r2);
      t3.set(e2, i2 ? 0 : t3.length - e2.length), e2 = t3;
    }
    if (e2.length !== r2) throw Error(`Field.fromBytes: expected ` + r2 + ` bytes, got ` + e2.length);
    let s2 = i2 ? z(e2) : Be(e2);
    if (o2 && (s2 = q(s2, a2)), !t2 && !this.isValid(s2)) throw Error(`invalid field element: outside of range 0..ORDER`);
    return s2;
  }
  invertBatch(e2) {
    return mt(this, e2, true);
  }
  cmov(e2, t2, n2) {
    return L(n2, `condition`), n2 ? t2 : e2;
  }
};
function yt(e2, t2 = {}) {
  return Object.freeze(vt.prototype), new vt(e2, t2);
}
function bt(e2) {
  if (typeof e2 != `bigint`) throw Error(`field order must be bigint`);
  if (e2 <= G) throw Error(`field order must be greater than 1`);
  let t2 = We(e2 - G);
  return Math.ceil(t2 / 8);
}
function xt(e2) {
  let t2 = bt(e2);
  return t2 + Math.ceil(t2 / 2);
}
function St(e2, t2, n2 = false) {
  F(e2);
  let r2 = e2.length, i2 = bt(t2), a2 = Math.max(xt(t2), 16);
  if (r2 < a2 || r2 > 1024) throw Error(`expected ` + a2 + `-1024 bytes of input, got ` + r2);
  let o2 = q(n2 ? z(e2) : Be(e2), t2 - G) + G;
  return n2 ? He(o2, i2) : Ve(o2, i2);
}
var Ct = BigInt(0), X = BigInt(1), wt = BigInt(4), Tt = 16, Et = 128, Dt = 5, Ot = 2 ** 31;
function Z(e2) {
  let t2 = e2;
  if (typeof t2 != `function`) throw TypeError(`"Point" expected constructor, got type=` + typeof e2);
  Oe(t2.fromAffine, `Point.fromAffine`), Oe(t2.fromBytes, `Point.fromBytes`), Oe(t2.fromHex, `Point.fromHex`), I(t2.BASE, `Point.BASE`), I(t2.ZERO, `Point.ZERO`), Y(t2.Fp), Y(t2.Fn);
}
function kt(e2, t2) {
  Z(e2), Nt(t2, e2);
  let n2 = mt(e2.Fp, t2.map((e3) => e3.Z));
  return t2.map((t3, r2) => e2.fromAffine(t3.toAffine(n2[r2])));
}
function At(e2, t2, n2 = 1) {
  if (!Number.isSafeInteger(e2) || e2 < n2 || e2 > t2) throw Error(`invalid window size, expected [` + n2 + `..` + t2 + `], got W=` + e2);
}
function jt(e2, t2) {
  let n2 = e2 * (4 * t2 + 128);
  if (n2 > Ot) throw Error(`invalid window size: table would need ~` + Math.ceil(n2 / 2 ** 20) + ` MiB, max ` + Ot / 2 ** 20 + ` MiB`);
}
function Mt(e2, t2) {
  if (e2 !== void 0) {
    Oe(e2, `randomBytes`);
    try {
      let n2 = e2(t2);
      if (!Me(n2) || n2.length !== t2) return;
    } catch {
      return;
    }
    return e2;
  }
}
function Nt(e2, t2) {
  Te(e2, `points`), e2.forEach((e3, n2) => {
    if (!(e3 instanceof t2)) throw Error(`invalid point at index ` + n2);
  });
}
function Pt(e2, t2, n2) {
  if (!Array.isArray(e2)) throw Error(`array of scalars expected`);
  e2.forEach((e3, r2) => {
    if (!(n2 === void 0 ? t2.isValid(e3) : V(e3) && e3 < n2)) throw Error(`invalid scalar at index ` + r2);
  });
}
var Ft = /* @__PURE__ */ new WeakMap();
function It(e2) {
  return Ft.get(e2) || 1;
}
function Lt(e2, t2) {
  let n2 = e2.double(), r2 = [e2];
  for (let e3 = 1; e3 < t2; e3++) r2.push(r2[e3 - 1].add(n2));
  return r2;
}
function Rt(e2, t2) {
  let n2 = 2 ** t2, r2 = n2 / 2, i2 = BigInt(n2 - 1), a2 = [];
  for (; e2 > Ct; ) {
    let t3 = 0;
    e2 & X && (t3 = Number(e2 & i2), t3 >= r2 && (t3 -= n2), e2 -= BigInt(t3)), a2.push(t3), e2 >>= X;
  }
  return a2;
}
function zt(e2, t2, n2) {
  let r2 = 2 ** t2, i2 = r2 / 2, a2 = BigInt(r2 - 1), o2 = BigInt(t2), s2 = [];
  for (let t3 = 0; t3 < n2; t3++) {
    let t4 = Number(e2 & a2);
    e2 >>= o2, t4 > i2 && (t4 -= r2, e2 += X), s2.push(t4);
  }
  if (e2 !== Ct) throw Error(`invalid wnaf`);
  return s2;
}
function Bt(e2, t2, n2) {
  let r2 = 0;
  for (let e3 of n2) r2 = Math.max(r2, e3.length);
  let i2 = e2;
  for (let e3 = r2 - 1; e3 >= 0; e3--) {
    e3 !== r2 - 1 && (i2 = i2.double());
    for (let r3 = 0; r3 < n2.length; r3++) {
      let a2 = n2[r3][e3];
      if (a2) {
        let e4 = t2[r3][Math.abs(a2) - 1 >> 1];
        i2 = i2.add(a2 < 0 ? e4.negate() : e4);
      }
    }
  }
  return i2;
}
var Vt = class {
  Point;
  BASE;
  ZERO;
  randomBytes;
  wnafPrecomputes = /* @__PURE__ */ new WeakMap();
  baseCanBeBlinded;
  bits;
  constructor(e2, t2) {
    Z(e2), this.randomBytes = Mt(t2, Tt), this.Point = e2, this.BASE = e2.BASE, this.ZERO = e2.ZERO, this.bits = e2.Fn.BITS;
  }
  buildWnafTable(e2, t2, n2) {
    let r2 = Math.ceil(n2 / t2) + 1, i2 = 2 ** (t2 - 1), a2 = [], o2 = e2;
    for (let e3 = 0; e3 < r2; e3++) {
      let e4 = o2;
      for (let t3 = 0; t3 < i2; t3++) a2.push(e4), e4 = e4.add(o2);
      o2 = a2[a2.length - 1].double();
    }
    return { W: t2, bits: n2, windows: r2, comp: a2 };
  }
  wnafCachedCT(e2, t2) {
    let { W: n2, windows: r2, comp: i2 } = e2, a2 = 2 ** (n2 - 1), o2 = zt(t2, n2, r2), s2 = this.ZERO, c2 = this.BASE;
    for (let e3 = 0; e3 < r2; e3++) {
      let t3 = o2[e3], n3 = e3 * a2, r3 = Math.abs(t3) - 1, l2 = i2[n3];
      for (let e4 = 1; e4 < a2; e4++) l2 = e4 === r3 ? i2[n3 + e4] : l2;
      let u2 = l2.negate();
      t3 === 0 ? c2 = c2.add(i2[n3]) : s2 = s2.add(t3 < 0 ? u2 : l2);
    }
    return { p: s2, f: c2 };
  }
  getWnafPrecomputes(e2, t2, n2, r2) {
    let i2 = this.wnafPrecomputes.get(t2), a2 = i2?.find((t3) => t3.W === e2 && t3.bits === n2);
    return a2 || (a2 = this.buildWnafTable(t2, e2, n2), typeof r2 == `function` && (a2 = { ...a2, comp: r2(a2.comp) }), i2 || (i2 = [], this.wnafPrecomputes.set(t2, i2)), i2.push(a2)), a2;
  }
  assertPoint(e2) {
    if (!(e2 instanceof this.Point)) throw TypeError(`"point" expected Point instance, got type=` + typeof e2);
  }
  validateMulInput(e2, t2) {
    if (this.assertPoint(e2), !Ue(t2, X, this.Point.Fn.ORDER)) throw Error(`invalid scalar`);
  }
  runCT(e2, t2, n2, r2) {
    let i2 = It(e2);
    return i2 === 1 ? this.fixedWindowCT(e2, t2, n2) : this.wnafCachedCT(this.getWnafPrecomputes(i2, e2, n2, r2), t2);
  }
  mulCT(e2, t2, n2) {
    return this.validateMulInput(e2, t2), this.runCT(e2, t2, this.bits, n2);
  }
  mulCTBlinded(e2, t2, n2) {
    if (this.validateMulInput(e2, t2), this.randomBytes === void 0) throw Error(`randomBytes is required for scalar blinding`);
    let r2 = this.Point.Fn.BITS + Et, i2 = this.randomBytes(Tt);
    if (!Me(i2) || i2.length !== Tt) throw Error(`randomBytes returned invalid byte array`);
    i2[0] = i2[0] & 63 | 128;
    let a2 = t2 + Be(i2) * this.Point.Fn.ORDER;
    return this.runCT(e2, a2, r2, n2);
  }
  fixedWindowCT(e2, t2, n2) {
    let r2 = Dt, i2 = Ge(r2), a2 = Array(32);
    a2[0] = this.ZERO;
    for (let t3 = 1; t3 < 32; t3++) a2[t3] = a2[t3 - 1].add(e2);
    let o2 = Math.ceil(n2 / r2), s2 = this.ZERO;
    for (let e3 = o2 - 1; e3 >= 0; e3--) {
      if (e3 !== o2 - 1) for (let e4 = 0; e4 < r2; e4++) s2 = s2.double();
      let n3 = Number(t2 >> BigInt(e3 * r2) & i2), c2 = a2[0];
      for (let e4 = 1; e4 < 32; e4++) c2 = e4 === n3 ? a2[e4] : c2;
      s2 = s2.add(c2);
    }
    return { p: s2, f: s2 };
  }
  shouldBlind(e2, t2) {
    return this.randomBytes === void 0 ? false : t2 === X || e2 === this.BASE && (this.baseCanBeBlinded === void 0 && (this.baseCanBeBlinded = this.mulUnsafe(this.BASE, this.Point.Fn.ORDER).is0()), this.baseCanBeBlinded);
  }
  mulSecret(e2, t2, n2, r2) {
    return this.shouldBlind(e2, n2) ? this.mulCTBlinded(e2, t2, r2) : this.mulCT(e2, t2, r2);
  }
  mulUnsafe(e2, t2, n2) {
    if (this.assertPoint(e2), !V(t2)) throw Error(`invalid scalar`);
    let r2 = It(e2);
    if (r2 === 1 || t2 >= this.Point.Fn.ORDER) return Ht(this.Point, [e2], [t2], true);
    let i2 = this.getWnafPrecomputes(r2, e2, this.bits, n2);
    return this.wnafCachedCT(i2, t2).p;
  }
  setWindowSize(e2, t2) {
    this.assertPoint(e2), At(t2, this.bits), jt((Math.ceil((this.bits + Et) / t2) + 1) * 2 ** (t2 - 1), this.Point.Fp.BYTES), Ft.set(e2, t2), this.wnafPrecomputes.delete(e2);
  }
  hasWindowSize(e2) {
    return It(e2) !== 1;
  }
};
function Ht(e2, t2, n2, r2 = false) {
  if (Z(e2), Nt(t2, e2), L(r2, `allowOversized`), Pt(n2, e2.Fn, r2 ? e2.Fn.ORDER ** wt : void 0), t2.length !== n2.length) throw Error(`arrays of points and scalars must have equal length`);
  let i2 = t2.map((e3) => Lt(e3, 4)), a2 = n2.map((e3) => Rt(e3, 4));
  return Bt(e2.ZERO, i2, a2);
}
function Ut(e2, t2, n2) {
  if (t2) {
    if (t2.ORDER !== e2) throw Error(`Field.ORDER must match order: Fp == p, Fn == n`);
    return Y(t2), t2;
  }
  return yt(e2, { isLE: n2 });
}
function Wt(e2, t2, n2 = {}, r2) {
  if (e2 !== `weierstrass` && e2 !== `edwards`) throw Error(`expected curve type "weierstrass" or "edwards"`);
  if (r2 === void 0 && (r2 = e2 === `edwards`), !t2 || typeof t2 != `object`) throw Error(`expected valid ${e2} CURVE object`);
  U(n2);
  for (let e3 of [`p`, `n`, `h`]) {
    let n3 = t2[e3];
    if (!(V(n3) && n3 !== Ct)) throw Error(`CURVE.${e3} must be positive bigint`);
  }
  let i2 = Ut(t2.p, n2.Fp, r2), a2 = Ut(t2.n, n2.Fn, r2), o2 = [`Gx`, `Gy`, `a`, e2 === `weierstrass` ? `b` : `d`];
  for (let e3 of o2) if (!i2.isValid(t2[e3])) throw Error(`CURVE.${e3} must be valid field element of CURVE.Fp`);
  return t2 = Object.freeze(Object.assign({}, t2)), { CURVE: t2, Fp: i2, Fn: a2 };
}
function Gt(e2, t2) {
  return function(n2) {
    let r2 = e2(n2);
    return { secretKey: r2, publicKey: t2(r2) };
  };
}
var Kt = BigInt(0), qt = BigInt(1), Jt = BigInt(2), Yt = BigInt(4), Xt = BigInt(8);
function Zt(e2, t2, n2, r2) {
  let i2 = e2.sqr(n2), a2 = e2.sqr(r2), o2 = e2.add(e2.mul(t2.a, i2), a2), s2 = e2.add(e2.ONE, e2.mul(t2.d, e2.mul(i2, a2)));
  return e2.eql(o2, s2);
}
function Qt(e2, t2 = {}) {
  U(t2, {}, {}, `extraOpts`);
  let n2 = t2, r2 = Wt(`edwards`, e2, n2, n2.FpFnLE), { Fp: i2, Fn: a2 } = r2, o2 = r2.CURVE, { h: s2 } = o2;
  if (ht(i2, o2.a) !== 1) throw Error(`edwards: CURVE.a must be a square in Fp for complete addition formulas`);
  if (ht(i2, o2.d) !== -1) throw Error(`edwards: CURVE.d must be a non-square in Fp for complete addition formulas`);
  U(n2, {}, { uvRatio: `function`, randomBytes: `function` });
  let c2 = n2.randomBytes === void 0 ? Ne : n2.randomBytes, l2 = Jt << BigInt(i2.BYTES * 8) - qt;
  function u2(e3) {
    if (!i2.isOdd) throw Error(`Field does not have .isOdd()`);
    return i2.isOdd(e3);
  }
  let d2 = n2.uvRatio === void 0 ? (e3, t3) => {
    try {
      return { isValid: true, value: i2.sqrt(i2.div(e3, t3)) };
    } catch {
      return { isValid: false, value: Kt };
    }
  } : n2.uvRatio;
  if (!Zt(i2, o2, o2.Gx, o2.Gy)) throw Error(`bad curve params: generator point`);
  let f2 = i2.eql(o2.a, i2.neg(i2.ONE)) ? (e3) => i2.neg(e3) : i2.eql(o2.a, i2.ONE) ? (e3) => e3 : (e3) => i2.mul(o2.a, e3);
  function p2(e3, t3, n3 = false) {
    let r3 = n3 ? qt : Kt;
    return H(`coordinate ` + e3, t3, r3, l2), t3;
  }
  function m2(e3) {
    if (!(e3 instanceof h2)) throw Error(`EdwardsPoint expected`);
  }
  class h2 {
    static BASE = new h2(o2.Gx, o2.Gy, i2.ONE, i2.mul(o2.Gx, o2.Gy));
    static ZERO = new h2(i2.ZERO, i2.ONE, i2.ONE, i2.ZERO);
    static Fp = i2;
    static Fn = a2;
    X;
    Y;
    Z;
    T;
    constructor(e3, t3, n3, r3) {
      this.X = p2(`x`, e3), this.Y = p2(`y`, t3), this.Z = p2(`z`, n3, true), this.T = p2(`t`, r3), Object.freeze(this);
    }
    static CURVE() {
      return o2;
    }
    static fromAffine(e3) {
      if (e3 instanceof h2) throw Error(`extended point not allowed`);
      let { x: t3, y: n3 } = e3 || {};
      return p2(`x`, t3), p2(`y`, n3), new h2(t3, n3, i2.ONE, i2.mul(t3, n3));
    }
    static fromBytes(e3, t3 = false) {
      let n3 = i2.BYTES, { a: r3, d: a3 } = o2;
      e3 = B(F(e3, n3, `point`)), L(t3, `zip215`);
      let s3 = B(e3), c3 = e3[n3 - 1];
      s3[n3 - 1] = c3 & -129;
      let f3 = z(s3);
      H(`point.y`, f3, Kt, t3 ? l2 : i2.ORDER);
      let p3 = i2.sqr(f3), m3 = i2.sub(p3, i2.ONE), g3 = i2.sub(i2.mulN(a3, p3), r3), { isValid: _3, value: v2 } = d2(m3, g3);
      if (!_3) throw Error(`bad point: invalid y coordinate`);
      let y2 = u2(v2), b2 = !!(c3 & 128);
      if (!t3 && i2.is0(v2) && b2) throw Error(`bad point: x=0 and x_0=1`);
      return b2 !== y2 && (v2 = i2.neg(v2)), h2.fromAffine({ x: v2, y: f3 });
    }
    static fromHex(e3, t3 = false) {
      return h2.fromBytes(je(e3), t3);
    }
    get x() {
      return this.toAffine().x;
    }
    get y() {
      return this.toAffine().y;
    }
    precompute(e3 = 6, t3 = true) {
      return _2.setWindowSize(this, e3), t3 || this.multiply(Jt), this;
    }
    assertValidity() {
      let e3 = this, { a: t3, d: n3 } = o2;
      if (e3.is0()) throw Error(`bad point: ZERO`);
      let { X: r3, Y: a3, Z: s3, T: c3 } = e3, l3 = i2.sqr(r3), u3 = i2.sqr(a3), d3 = i2.sqr(s3), f3 = i2.sqr(d3), p3 = i2.mul(l3, t3), m3 = i2.mul(i2.add(p3, u3), d3), h3 = i2.add(f3, i2.mul(n3, i2.mul(l3, u3)));
      if (!i2.eql(m3, h3)) throw Error(`bad point: equation left != right (1)`);
      let g3 = i2.mul(r3, a3), _3 = i2.mul(s3, c3);
      if (!i2.eql(g3, _3)) throw Error(`bad point: equation left != right (2)`);
    }
    equals(e3) {
      m2(e3);
      let { X: t3, Y: n3, Z: r3 } = this, { X: a3, Y: o3, Z: s3 } = e3, c3 = i2.mul(t3, s3), l3 = i2.mul(a3, r3), u3 = i2.mul(n3, s3), d3 = i2.mul(o3, r3);
      return i2.eql(c3, l3) && i2.eql(u3, d3);
    }
    is0() {
      return this.equals(h2.ZERO);
    }
    negate() {
      return new h2(i2.neg(this.X), this.Y, this.Z, i2.neg(this.T));
    }
    double() {
      let { X: e3, Y: t3, Z: n3 } = this, r3 = i2.sqr(e3), a3 = i2.sqr(t3), o3 = i2.mul(i2.sqr(n3), Jt), s3 = f2(r3), c3 = i2.addN(e3, t3), l3 = i2.sub(i2.subN(i2.sqr(c3), r3), a3), u3 = i2.addN(s3, a3), d3 = i2.subN(u3, o3), p3 = i2.subN(s3, a3), m3 = i2.mul(l3, d3), g3 = i2.mul(u3, p3), _3 = i2.mul(l3, p3), v2 = i2.mul(d3, u3);
      return new h2(m3, g3, v2, _3);
    }
    add(e3) {
      m2(e3);
      let { d: t3 } = o2, { X: n3, Y: r3, Z: a3, T: s3 } = this, { X: c3, Y: l3, Z: u3, T: d3 } = e3, p3 = i2.mul(n3, c3), g3 = i2.mul(r3, l3), _3 = i2.mul(i2.mulN(s3, t3), d3), v2 = i2.mul(a3, u3), y2 = i2.sub(i2.subN(i2.mulN(i2.addN(n3, r3), i2.addN(c3, l3)), p3), g3), b2 = i2.subN(v2, _3), x2 = i2.addN(v2, _3), S2 = i2.sub(g3, f2(p3)), C2 = i2.mul(y2, b2), w2 = i2.mul(x2, S2), T2 = i2.mul(y2, S2), E2 = i2.mul(b2, x2);
      return new h2(C2, w2, E2, T2);
    }
    subtract(e3) {
      return m2(e3), this.add(e3.negate());
    }
    multiply(e3) {
      if (!a2.isValidNot0(e3)) throw RangeError(`invalid scalar: expected 1 <= sc < curve.n`);
      let { p: t3, f: n3 } = _2.mulSecret(this, e3, s2, g2);
      return g2([t3, n3])[0];
    }
    multiplyUnsafe(e3) {
      if (!a2.isValid(e3)) throw RangeError(`invalid scalar: expected 0 <= sc < curve.n`);
      return e3 === Kt ? h2.ZERO : this.is0() || e3 === qt ? this : _2.mulUnsafe(this, e3, g2);
    }
    isSmallOrder() {
      return this.clearCofactor().is0();
    }
    isTorsionFree() {
      return _2.mulUnsafe(this, o2.n).is0();
    }
    toAffine(e3) {
      let t3 = this, n3 = e3;
      if (n3 != null && typeof n3 != `bigint`) throw TypeError(`"invertedZ" expected bigint, got type=` + typeof n3);
      let { X: r3, Y: a3, Z: o3 } = t3, s3 = t3.is0();
      n3 ??= s3 ? i2.create(Xt) : i2.inv(o3);
      let c3 = i2.mul(r3, n3), l3 = i2.mul(a3, n3), u3 = i2.mul(o3, n3);
      if (s3) return { x: i2.ZERO, y: i2.ONE };
      if (!i2.eql(u3, i2.ONE)) throw Error(`invZ was invalid`);
      return { x: c3, y: l3 };
    }
    clearCofactor() {
      return s2 === qt ? this : s2 === Jt ? this.double() : s2 === Yt ? this.double().double() : s2 === Xt ? this.double().double().double() : this.multiplyUnsafe(s2);
    }
    toBytes() {
      let { x: e3, y: t3 } = this.toAffine(), n3 = i2.toBytes(t3);
      return n3[n3.length - 1] |= u2(e3) ? 128 : 0, n3;
    }
    toHex() {
      return ke(this.toBytes());
    }
    toString() {
      return `<Point ${this.is0() ? `ZERO` : this.toHex()}>`;
    }
  }
  let g2 = (e3) => kt(h2, e3), _2 = new Vt(h2, c2);
  return _2.bits >= 6 && h2.BASE.precompute(6), Object.freeze(h2.prototype), Object.freeze(h2), h2;
}
function $t(e2, t2, n2 = {}) {
  if (Z(e2), typeof t2 != `function`) throw Error(`"hash" function param is required`);
  let r2 = t2, i2 = n2;
  U(i2, {}, { adjustScalarBytes: `function`, randomBytes: `function`, domain: `function`, prehash: `function`, zip215: `boolean`, mapToCurve: `function`, toMontgomery: `function`, toMontgomerySecret: `function` });
  let { prehash: a2 } = i2, { BASE: o2, Fp: s2, Fn: c2 } = e2, l2 = r2.outputLen, u2 = 2 * s2.BYTES;
  if (l2 !== void 0 && (R(l2, `hash.outputLen`), l2 !== u2)) throw Error(`hash.outputLen must be ${u2}, got ${l2}`);
  let d2 = i2.randomBytes === void 0 ? Ne : i2.randomBytes, f2 = i2.toMontgomery, p2 = i2.toMontgomerySecret, m2 = i2.adjustScalarBytes === void 0 ? (e3) => e3 : i2.adjustScalarBytes, h2 = i2.domain === void 0 ? (e3, t3, n3) => {
    if (L(n3, `phflag`), t3.length || n3) throw Error(`Contexts/pre-hash are not supported`);
    return e3;
  } : i2.domain;
  function g2(e3) {
    return c2.create(z(e3));
  }
  function _2(e3) {
    let t3 = T2.secretKey;
    F(e3, T2.secretKey, `secretKey`);
    let n3 = F(r2(e3), 2 * t3, `hashedSecretKey`), i3 = m2(n3.slice(0, t3));
    return { head: i3, prefix: n3.slice(t3, 2 * t3), scalar: g2(i3) };
  }
  function v2(e3) {
    let { head: t3, prefix: n3, scalar: r3 } = _2(e3), i3 = o2.multiply(r3);
    return { head: t3, prefix: n3, scalar: r3, point: i3, pointBytes: i3.toBytes() };
  }
  function y2(e3) {
    return v2(e3).pointBytes;
  }
  function b2(e3 = Uint8Array.of(), ...t3) {
    let n3 = Ae(...t3);
    return g2(r2(h2(n3, F(e3, void 0, `context`), !!a2)));
  }
  function x2(e3, t3, n3 = {}) {
    U(n3, {}, {}, `options`), e3 = B(F(e3, void 0, `message`)), a2 && (e3 = a2(e3));
    let { prefix: r3, scalar: i3, pointBytes: s3 } = v2(t3), l3 = b2(n3.context, r3, e3), u3 = o2.multiply(l3).toBytes(), d3 = b2(n3.context, u3, s3, e3), f3 = c2.create(l3 + d3 * i3);
    if (!c2.isValid(f3)) throw Error(`sign failed: invalid s`);
    return F(Ae(u3, c2.toBytes(f3)), T2.signature, `result`);
  }
  let S2 = { zip215: i2.zip215 };
  function C2(t3, n3, r3, i3 = S2) {
    U(i3);
    let { context: s3 } = i3, c3 = i3.zip215 === void 0 ? !!S2.zip215 : i3.zip215, l3 = T2.signature;
    t3 = F(t3, l3, `signature`), n3 = F(n3, void 0, `message`), r3 = F(r3, T2.publicKey, `publicKey`), c3 !== void 0 && L(c3, `zip215`), a2 && (n3 = a2(n3));
    let u3 = l3 / 2, d3 = t3.subarray(0, u3), f3 = z(t3.subarray(u3, l3)), p3, m3, h3;
    try {
      p3 = e2.fromBytes(r3, c3), m3 = e2.fromBytes(d3, c3), h3 = o2.multiplyUnsafe(f3);
    } catch {
      return false;
    }
    if (!c3 && p3.isSmallOrder()) return false;
    let g3 = b2(s3, d3, r3, n3);
    return m3.add(p3.multiplyUnsafe(g3)).subtract(h3).clearCofactor().is0();
  }
  let w2 = s2.BYTES, T2 = { secretKey: w2, publicKey: w2, signature: 2 * w2, seed: w2 };
  function E2(e3) {
    return e3 = e3 === void 0 ? d2(T2.seed) : e3, F(e3, T2.seed, `seed`);
  }
  function D2(e3) {
    return Me(e3) && e3.length === T2.secretKey;
  }
  function O2(t3, n3) {
    try {
      return !!e2.fromBytes(t3, n3 === void 0 ? S2.zip215 : n3);
    } catch {
      return false;
    }
  }
  let k2 = { getExtendedPublicKey: v2, randomSecretKey: E2, isValidSecretKey: D2, isValidPublicKey: O2, toMontgomery(t3) {
    if (f2 === void 0) throw Error(`Montgomery conversion is not supported for this curve`);
    return f2(e2.fromBytes(t3));
  }, toMontgomerySecret(e3) {
    if (p2 === void 0) throw Error(`Montgomery conversion is not supported for this curve`);
    return p2(e3);
  } };
  return Object.freeze(T2), Object.freeze(k2), Object.freeze({ keygen: Gt(E2, y2), getPublicKey: y2, sign: x2, verify: C2, utils: k2, Point: e2, lengths: T2 });
}
var Q = BigInt(0), $ = BigInt(1), en = BigInt(2);
function tn(e2, t2) {
  return e2 + t2 - (t2 >> $ << $);
}
function nn(e2) {
  let t2 = BigInt(6) * e2;
  return (n2, r2, i2) => {
    let a2 = r2 + i2, o2 = ((t2 + i2 - r2) * n2 + r2) % e2;
    return { x_2: o2, x_3: a2 - o2 };
  };
}
function rn(e2) {
  return U(e2, { P: `bigint`, type: `string`, adjustScalarBytes: `function`, powPminus2: `function` }, { randomBytes: `function`, scalarMultBase: `function` }), Object.freeze({ ...e2 });
}
function an(e2) {
  let t2 = rn(e2), { P: n2, type: r2, adjustScalarBytes: i2, powPminus2: a2, randomBytes: o2 } = t2, s2 = t2.scalarMultBase, c2 = r2 === `x25519`;
  if (!c2 && r2 !== `x448`) throw Error(`invalid type`);
  let l2 = o2 === void 0 ? Ne : o2, u2 = c2 ? 255 : 448, d2 = nn(n2), f2 = c2 ? 32 : 56, p2 = BigInt(c2 ? 9 : 5), m2 = BigInt(c2 ? 121665 : 39081), h2 = c2 ? en ** BigInt(254) : en ** BigInt(447), g2 = h2 + (c2 ? BigInt(8) * (en ** BigInt(251) - $) : BigInt(4) * (en ** BigInt(445) - $)) + $, _2 = (e3) => q(e3, n2), v2 = y2(p2);
  function y2(e3) {
    return He(_2(e3), f2);
  }
  function b2(e3) {
    let t3 = B(F(e3, f2, `uCoordinate`));
    return c2 && (t3[31] &= 127), _2(z(t3));
  }
  function x2(e3) {
    return z(i2(B(F(e3, f2, `scalar`))));
  }
  let S2 = new Set(c2 ? [Q, $, n2 - $, BigInt(`325606250916557431795983626356110631294008115727848805560023387167927233504`), BigInt(`39382357235489614581723060781553021112529911719440698176882885853963445705823`)] : [Q, $, n2 - $]);
  function C2(e3, t3) {
    let n3 = b2(t3);
    if (S2.has(n3)) throw Error(`invalid private or public key received`);
    let r3 = D2(n3, x2(e3));
    if (r3 === Q) throw Error(`invalid private or public key received`);
    return y2(r3);
  }
  function w2(e3) {
    if (s2 === void 0) return C2(e3, v2);
    let t3 = x2(e3);
    H(`scalar`, t3, h2, g2);
    let n3 = _2(s2(t3));
    if (n3 === Q) throw Error(`invalid private or public key received`);
    return y2(n3);
  }
  let T2 = w2, E2 = C2;
  function D2(e3, t3) {
    H(`u`, e3, Q, n2), H(`scalar`, t3, h2, g2);
    let r3 = t3, i3 = e3, o3 = $, s3 = Q, c3 = e3, l3 = $, f3 = r3 ^ r3 >> $;
    for (let e4 = BigInt(u2 - 1); e4 >= Q; e4--) {
      let t4 = tn(n2, f3 >> e4);
      ({ x_2: o3, x_3: c3 } = d2(t4, o3, c3)), { x_2: s3, x_3: l3 } = d2(t4, s3, l3);
      let r4 = o3 + s3, a3 = _2(r4 * r4), u3 = o3 - s3, p4 = _2(u3 * u3), h3 = a3 - p4, g3 = c3 + l3, v4 = c3 - l3, y3 = _2(v4 * r4), b3 = _2(g3 * u3), x3 = y3 + b3, S3 = y3 - b3;
      c3 = _2(x3 * x3), l3 = _2(i3 * _2(S3 * S3)), o3 = _2(a3 * p4), s3 = _2(h3 * (a3 + _2(m2 * h3)));
    }
    let p3 = tn(n2, r3);
    ({ x_2: o3, x_3: c3 } = d2(p3, o3, c3)), { x_2: s3, x_3: l3 } = d2(p3, s3, l3);
    let v3 = a2(s3);
    return _2(o3 * v3);
  }
  let O2 = { secretKey: f2, publicKey: f2, seed: f2 }, k2 = (e3) => (e3 = e3 === void 0 ? l2(f2) : e3, F(e3, O2.seed, `seed`), e3), A2 = { randomSecretKey: k2 };
  return Object.freeze(O2), Object.freeze(A2), Object.freeze({ keygen: Gt(k2, T2), getSharedSecret: E2, getPublicKey: T2, scalarMult: C2, scalarMultBase: w2, utils: A2, GuBytes: v2.slice(), lengths: O2 });
}
var on = BigInt(0), sn = BigInt(1), cn = BigInt(2), ln = BigInt(3), un = BigInt(5), dn = BigInt(8), fn = BigInt(`0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffed`), pn = { p: fn, n: BigInt(`0x1000000000000000000000000000000014def9dea2f79cd65812631a5cf5d3ed`), h: dn, a: BigInt(`0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffec`), d: BigInt(`0x52036cee2b6ffe738cc740797779e89800700a4d4141d8ab75eb4dca135978a3`), Gx: BigInt(`0x216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51a`), Gy: BigInt(`0x6666666666666666666666666666666666666666666666666666666666666658`) };
function mn(e2) {
  let t2 = BigInt(10), n2 = BigInt(20), r2 = BigInt(40), i2 = BigInt(80), a2 = fn, o2 = e2 * e2 % a2 * e2 % a2, s2 = J(J(o2, cn, a2) * o2 % a2, sn, a2) * e2 % a2, c2 = J(s2, un, a2) * s2 % a2, l2 = J(c2, t2, a2) * c2 % a2, u2 = J(l2, n2, a2) * l2 % a2, d2 = J(u2, r2, a2) * u2 % a2;
  return { pow_p_5_8: J(J(J(J(d2, i2, a2) * d2 % a2, i2, a2) * d2 % a2, t2, a2) * c2 % a2, cn, a2) * e2 % a2, b2: o2 };
}
function hn(e2) {
  return e2[0] &= 248, e2[31] &= 127, e2[31] |= 64, e2;
}
var gn = BigInt(`19681161376707505956807079304988542015446066515923890162744021073123829784752`);
function _n(e2, t2) {
  let n2 = fn, r2 = q(t2 * t2 * t2, n2), i2 = mn(e2 * q(r2 * r2 * t2, n2)).pow_p_5_8, a2 = q(e2 * r2 * i2, n2), o2 = q(t2 * a2 * a2, n2), s2 = a2, c2 = q(a2 * gn, n2), l2 = o2 === e2, u2 = o2 === q(-e2, n2), d2 = o2 === q(-e2 * gn, n2);
  return l2 && (a2 = s2), (u2 || d2) && (a2 = c2), ft(a2, n2) && (a2 = q(-a2, n2)), { isValid: l2 || u2, value: a2 };
}
var vn = Qt(pn, { uvRatio: _n }), yn = vn.Fp;
function bn(e2) {
  let { y: t2 } = e2;
  return yn.toBytes(yn.div(sn + t2, sn - t2));
}
function xn(e2) {
  let t2 = vn.Fp.BYTES;
  return C(e2, t2), hn(we(e2.subarray(0, t2))).subarray(0, t2);
}
function Sn(e2) {
  return $t(vn, we, Object.assign({ adjustScalarBytes: hn, toMontgomery: bn, toMontgomerySecret: xn, zip215: true }, e2));
}
var Cn = Sn({}), wn = (() => {
  let e2 = fn, t2 = (t3) => {
    let { pow_p_5_8: n2, b2: r2 } = mn(t3);
    return q(J(n2, ln, e2) * r2, e2);
  };
  return an({ P: e2, type: `x25519`, powPminus2: t2, adjustScalarBytes: hn, scalarMultBase: (n2) => {
    let r2 = q(n2, vn.Fn.ORDER);
    if (r2 === on) return on;
    let i2 = vn.BASE.multiply(r2);
    return q((i2.Z + i2.Y) * t2(q(i2.Z - i2.Y, e2)), e2);
  } });
})();
export {
  Ce as A,
  Ae as C,
  Re as D,
  Me as E,
  O as F,
  k as I,
  D as M,
  w as N,
  Ne as O,
  S as P,
  Be as S,
  je as T,
  R as _,
  Gt as a,
  Ge as b,
  Mt as c,
  it as d,
  St as f,
  F as g,
  L as h,
  Wt as i,
  C as j,
  U as k,
  Z as l,
  Le as m,
  wn as n,
  Ht as o,
  H as p,
  Vt as r,
  kt as s,
  Cn as t,
  xt as u,
  De as v,
  Ke as w,
  ke as x,
  We as y
};
