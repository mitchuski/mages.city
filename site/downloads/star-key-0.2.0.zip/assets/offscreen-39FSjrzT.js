import { $ as e, A as t, B as n, C as r, D as i, E as a, F as o, G as s, H as c, I as l, J as u, K as d, L as f, M as p, N as m, O as h, P as g, Q as _, R as v, S as y, T as b, U as ee, V as x, W as S, Y as C, _ as w, a as T, b as E, c as D, d as O, et as k, f as A, g as j, h as M, i as N, j as P, k as F, l as I, m as L, nt as te, o as ne, p as re, q as ie, rt as ae, s as oe, t as se, tt as ce, u as le, v as ue, w as de, x as fe, y as pe, z as R } from "./sign-in-uv-messages-Cu3YiOZZ.js";
import { _ as me, b as he, d as ge, f as z, l as _e, m as ve, o as ye, r as be, s as xe, t as Se, u as Ce, v as we, x as Te } from "./agreements-store-D0oqmDVT.js";
import { S as Ee, _ as De, a as Oe, b as ke, c as Ae, d as je, f as Me, g as Ne, h as Pe, i as Fe, l as Ie, m as Le, n as Re, o as ze, p as Be, r as Ve, s as He, t as Ue, u as We, v as Ge, x as Ke, y as qe, __tla as __tla_0 } from "./didcomm-D5nXYRy6.js";
import { A as Je, I as Ye, N as Xe, P as Ze, j as Qe, n as $e, t as et } from "./ed25519-CV189T12.js";
import { a as tt, c as nt, d as rt, f as it, h as at, l as ot, p as st, s as ct, t as lt } from "./grant-command-Cj-mgMRw.js";
import { a as ut, i as dt, n as ft, o as pt, t as mt } from "./verify-DUO6YZuM.js";
import { $ as ht, At as gt, F as _t, Gt as vt, Ht as yt, Jt as bt, Mt as xt, Nt as St, Rt as Ct, S as wt, Ut as Tt, Vt as Et, Yt as Dt, _t as Ot, dt as kt, et as At, i as jt, jt as Mt, n as Nt, qt as Pt, st as Ft, t as It, vt as Lt } from "./bridge-protocol-DoEW6v30.js";
Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  async function Rt(e2, t2 = {}) {
    let n2 = st(e2);
    if (n2 === `key`) {
      let t3 = e2.slice(8);
      return t3.startsWith(`z`) ? {
        did: e2,
        candidates: [
          `${e2}#${t3}`
        ]
      } : {
        did: e2,
        candidates: [],
        error: `did:key identifier is not base58btc multibase`
      };
    }
    if (n2 === `unknown`) return {
      did: e2,
      candidates: [],
      error: `Unrecognised DID method`
    };
    try {
      n2 === `webvh` && rt(e2);
      let r2 = await (t2.resolveDid ?? ((e3) => je(e3, {})))(e2), i2 = r2.didResolutionMetadata?.error;
      if (i2) return {
        did: e2,
        candidates: [],
        error: i2
      };
      let a2 = r2.didDocument;
      if (!a2) return {
        did: e2,
        candidates: [],
        error: `Resolver returned no DID document`
      };
      let o2 = zt(a2.authentication) || zt(a2.assertionMethod) || zt(a2.verificationMethod) || [];
      return o2.length === 0 ? {
        did: e2,
        candidates: [],
        error: `DID document has no usable verification methods`
      } : {
        did: e2,
        candidates: o2
      };
    } catch (t3) {
      return {
        did: e2,
        candidates: [],
        error: t3 instanceof Error ? t3.message : String(t3)
      };
    }
  }
  function zt(e2) {
    if (!e2 || e2.length === 0) return null;
    let t2 = [];
    for (let n2 of e2) typeof n2 == `string` ? t2.push(n2) : n2 && typeof n2 == `object` && typeof n2.id == `string` && t2.push(n2.id);
    return t2.length > 0 ? t2 : null;
  }
  function Bt(e2) {
    switch (e2) {
      case `unsupported-vid`:
      case `unknown-flow`:
      case `unsupported-version`:
        return `update`;
      case `expired`:
        return `expired`;
      case `no-common-transport`:
        return `unreachable`;
      case `not-ours`:
        return `pass-on`;
      default:
        return `invalid`;
    }
  }
  var Vt = {
    update: `This code needs a newer version of the app.`,
    expired: `This code has expired. Get a new one.`,
    unreachable: `This service can't be reached from your wallet.`,
    invalid: `This code can't be used.`
  };
  function Ht(e2) {
    return e2 === `pass-on` ? void 0 : Vt[e2];
  }
  var Ut = `https://link.trustoverip.org/vti/flow/`;
  function Wt(e2) {
    if (e2.length !== 0) return e2.map((e3) => {
      try {
        return decodeURIComponent(e3);
      } catch {
        return e3;
      }
    });
  }
  var Gt = {
    kind: `did:webvh`,
    route: `host-named`,
    listsServices: true,
    verified: true,
    wellFormed: (e2) => {
      let t2 = e2.split(`:`);
      return t2.length >= 4 && !!t2[2] && !!t2[3];
    },
    hostPath: (e2) => Wt(e2.split(`:`).slice(3))
  }, Kt = {
    kind: `did:web`,
    route: `host-named`,
    listsServices: true,
    verified: true,
    hostPath: (e2) => Wt(e2.split(`:`).slice(2))
  }, qt = [
    Gt,
    Kt,
    {
      kind: `did:key`,
      listsServices: false,
      verified: true,
      wellFormed: (e2) => /^did:key:z[1-9A-HJ-NP-Za-km-z]+$/.test(e2)
    },
    {
      kind: `did:peer`,
      listsServices: true,
      verified: true
    }
  ];
  function Jt(e2) {
    let t2 = /* @__PURE__ */ new Map();
    for (let n2 of e2) t2.set(n2.kind, n2);
    return {
      policyFor: (e3) => t2.get(e3)
    };
  }
  var Yt = Jt(qt);
  Object.freeze(Object.fromEntries(qt.map((e2) => [
    e2.kind,
    {
      namesHost: e2.route === `host-named`,
      listsServices: e2.listsServices,
      verified: e2.verified
    }
  ])));
  function Xt(e2, t2 = Yt) {
    let n2 = t2.policyFor(e2.kind);
    return n2?.route !== void 0 && n2.listsServices && n2.verified ? n2.route : void 0;
  }
  function Zt(e2, t2 = Yt) {
    return Xt(e2, t2) !== void 0;
  }
  var Qt = [
    {
      name: `sign-in`,
      base: `${Ut}sign-in`,
      major: 0,
      minors: [
        1
      ],
      draft: true,
      requiresExp: true,
      allowsContact: Zt
    }
  ], $t = [
    `_from`,
    `_id`,
    `_exp`,
    `_type`
  ];
  function en(e2, t2) {
    return {
      ok: false,
      reason: e2,
      outcome: Bt(e2),
      ...t2 ? {
        method: t2
      } : {}
    };
  }
  function tn(e2, t2) {
    let n2 = t2.flows ?? Qt, r2 = (t2.aliasSchemes ?? []).map((e3) => e3.toLowerCase()), i2 = Tn(typeof e2 == `string` ? e2 : ``);
    if (En(i2) > 1536) return en(`too-long`);
    let a2 = /^([A-Za-z][A-Za-z0-9+.-]*):\/\//.exec(i2), o2 = a2?.[1]?.toLowerCase();
    if (!o2 || !(o2 === `https` || o2 === `http` || r2.includes(o2))) return en(`not-ours`);
    let s2 = i2.indexOf(`#`), c2 = s2 === -1 ? i2 : i2.slice(0, s2), l2 = s2 === -1 ? `` : i2.slice(s2 + 1), u2 = _n(l2);
    if (!u2.some((e3) => wn(e3.name))) {
      let e3 = c2.indexOf(`?`);
      return en(_n(e3 === -1 ? `` : c2.slice(e3 + 1)).some((e4) => wn(e4.name)) ? `query-form` : `not-ours`);
    }
    if (o2 === `http`) return en(`insecure-scheme`);
    for (let e3 of i2) {
      let t3 = e3.codePointAt(0);
      if (t3 <= 32 || t3 === 127) return en(`bad-grammar`);
    }
    if (l2.includes(`#`)) return en(`bad-grammar`);
    let d2 = c2.slice(a2[0].length), f2 = d2.search(/[/?\\]/), p2 = f2 === -1 ? d2 : d2.slice(0, f2);
    if (p2.includes(`@`) || p2.includes(`:`)) return en(`bad-authority`);
    let m2 = an(p2);
    if (m2 === void 0 || !rn(m2)) return en(`bad-authority`);
    let h2 = {};
    for (let e3 of u2) if (wn(e3.name)) {
      if (h2[e3.name] !== void 0) return en(`repeated-param`);
      h2[e3.name] = {
        raw: e3.rawValue,
        value: e3.value
      };
    }
    let g2 = h2._from;
    if (g2 === void 0) return en(`missing-from`);
    let _2 = t2.contactMethods ?? Yt, v2 = un(g2.value, _2);
    if (v2 === `bad-from` || v2 === `unsupported-vid`) return en(v2);
    let y2 = h2._id;
    if (y2 === void 0 || !on(y2.value)) return en(`bad-id`);
    let b2;
    if (h2._exp !== void 0) {
      let e3 = cn(h2._exp.value);
      if (e3 === void 0) return en(`bad-exp`);
      b2 = e3;
    }
    let ee2;
    if (h2._type !== void 0) {
      let e3 = fn(h2._type.raw, m2);
      if (e3 === void 0) return en(`bad-type`);
      let t3 = hn(e3, n2);
      if (!t3.ok) return en(t3.reason);
      ee2 = t3.flow;
    }
    if (ee2) {
      if (!ee2.spec.allowsContact(v2, _2)) return en(`from-not-allowed`, v2.kind);
      if (ee2.spec.requiresExp && b2 === void 0) return en(`missing-exp`);
    }
    return b2 !== void 0 && b2 + 60 <= t2.now ? en(`expired`) : {
      ok: true,
      link: {
        scheme: o2,
        host: m2,
        from: v2,
        id: y2.value,
        ...b2 === void 0 ? {} : {
          exp: b2
        },
        ...ee2 ? {
          flow: ee2
        } : {}
      }
    };
  }
  var nn = /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/;
  function rn(e2) {
    if (typeof e2 != `string` || e2.length === 0 || e2.length > 253 || e2.endsWith(`.`)) return false;
    let t2 = e2.split(`.`);
    if (t2.length < 2) return false;
    for (let e3 of t2) if (!nn.test(e3)) return false;
    return !(/^[0-9]+$/.test(t2[t2.length - 1]) || e2 === `localhost` || e2.endsWith(`.localhost`) || e2.endsWith(`.local`) || e2 === `home.arpa` || e2.endsWith(`.home.arpa`));
  }
  function an(e2) {
    if (e2.length !== 0) try {
      let t2 = new URL(`https://${e2}/`);
      return t2.username || t2.password || t2.port ? void 0 : t2.hostname;
    } catch {
      return;
    }
  }
  function on(e2) {
    if (!/^[A-Za-z0-9_-]{22,43}$/.test(e2)) return false;
    let t2 = e2.length % 4;
    return t2 === 1 ? false : t2 === 0 || !(sn.indexOf(e2[e2.length - 1]) & (t2 === 2 ? 15 : 3));
  }
  var sn = `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_`;
  function cn(e2) {
    if (!/^(0|[1-9][0-9]*)$/.test(e2) || e2.length > 16) return;
    let t2 = Number(e2);
    return Number.isSafeInteger(t2) ? t2 : void 0;
  }
  var ln = /^did:[a-z0-9]+:(?:(?:[A-Za-z0-9._-]|%[0-9A-Fa-f]{2})*:)*(?:[A-Za-z0-9._-]|%[0-9A-Fa-f]{2})+$/;
  function un(e2, t2) {
    if (e2.length === 0) return `bad-from`;
    if (e2.includes(`/@`)) return `unsupported-vid`;
    if (e2.startsWith(`did:`)) {
      if (!ln.test(e2)) return `bad-from`;
      let n2 = `did:${e2.slice(4, e2.indexOf(`:`, 4))}`, r2 = t2.policyFor(n2);
      return !r2 || r2.route !== void 0 && !r2.verified ? `unsupported-vid` : r2.wellFormed && !r2.wellFormed(e2) ? `bad-from` : {
        kind: n2,
        value: e2
      };
    }
    return `unsupported-vid`;
  }
  function dn(e2, t2 = Yt) {
    let n2 = t2.policyFor(e2.kind)?.hostPath?.(e2.value);
    return n2 && n2.length > 0 ? n2.join(`/`) : void 0;
  }
  function fn(e2, t2) {
    if (e2.startsWith(`/`)) return pn(e2) ? `https://${t2.toLowerCase()}${e2}` : void 0;
    if (!e2.startsWith(`https://`)) return;
    let n2 = e2.slice(8), r2 = n2.indexOf(`/`);
    if (r2 !== -1 && rn(n2.slice(0, r2))) return pn(n2.slice(r2)) ? e2 : void 0;
  }
  function pn(e2) {
    if (!/^\/[A-Za-z0-9\-._~/]+$/.test(e2)) return false;
    let t2 = e2.slice(1).split(`/`);
    return !t2.some((e3) => e3 === `` || e3 === `.` || e3 === `..`) && mn(t2[t2.length - 1]);
  }
  function mn(e2) {
    return /^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$/.test(e2);
  }
  function hn(e2, t2) {
    let n2 = e2.lastIndexOf(`/`), r2 = e2.slice(0, n2), [i2, a2] = e2.slice(n2 + 1).split(`.`), o2 = Number(i2), s2 = Number(a2), c2 = t2.find((e3) => e3.base === r2);
    if (!c2) {
      let e3 = gn(r2);
      return t2.some((t3) => gn(t3.base) === e3) ? {
        ok: false,
        reason: `wrong-host`
      } : {
        ok: false,
        reason: `unknown-flow`
      };
    }
    return o2 !== c2.major || !(c2.draft ? c2.minors.includes(s2) : s2 >= Math.min(...c2.minors)) ? {
      ok: false,
      reason: `unsupported-version`
    } : {
      ok: true,
      flow: {
        spec: c2,
        uri: e2,
        major: o2,
        minor: s2
      }
    };
  }
  function gn(e2) {
    let t2 = e2.replace(/^https:\/\//i, ``), n2 = t2.indexOf(`/`);
    return n2 === -1 ? `` : t2.slice(n2);
  }
  function _n(e2) {
    let t2 = [];
    for (let n2 of e2.split(`&`)) {
      if (n2.length === 0) continue;
      let e3 = n2.indexOf(`=`), r2 = e3 === -1 ? n2 : n2.slice(0, e3), i2 = e3 === -1 ? `` : n2.slice(e3 + 1);
      t2.push({
        name: vn(r2),
        value: vn(i2),
        rawValue: i2
      });
    }
    return t2;
  }
  function vn(e2) {
    return xn(e2.replace(/\+/g, ` `));
  }
  var yn = new TextEncoder(), bn = new TextDecoder(`utf-8`);
  function xn(e2) {
    let t2 = yn.encode(e2), n2 = new Uint8Array(t2.length), r2 = 0;
    for (let e3 = 0; e3 < t2.length; e3++) {
      let i2 = t2[e3];
      i2 === 37 && e3 + 2 < t2.length && Sn(t2[e3 + 1]) && Sn(t2[e3 + 2]) ? (n2[r2++] = Cn(t2[e3 + 1]) << 4 | Cn(t2[e3 + 2]), e3 += 2) : n2[r2++] = i2;
    }
    return bn.decode(n2.subarray(0, r2));
  }
  function Sn(e2) {
    return e2 >= 48 && e2 <= 57 || e2 >= 65 && e2 <= 70 || e2 >= 97 && e2 <= 102;
  }
  function Cn(e2) {
    return e2 <= 57 ? e2 - 48 : e2 <= 70 ? e2 - 65 + 10 : e2 - 97 + 10;
  }
  function wn(e2) {
    return $t.includes(e2);
  }
  function Tn(e2) {
    return e2.replace(/^[\t\n\f\r ]+|[\t\n\f\r ]+$/g, ``);
  }
  function En(e2) {
    let t2 = 0;
    for (let n2 of e2) t2++;
    return t2;
  }
  function Dn(e2) {
    if (!e2.startsWith(`did:`)) return;
    let t2 = e2.indexOf(`:`, 4);
    return t2 > 4 ? `did:${e2.slice(4, t2)}` : void 0;
  }
  async function On(e2, t2) {
    let n2 = await (t2.resolveDid ?? ((e3) => je(e3, {})))(e2);
    if (n2?.didResolutionMetadata?.error) return {
      ok: false,
      reason: `did-document-unverified`
    };
    let r2 = n2?.didDocument;
    return !r2 || r2.id !== e2 ? {
      ok: false,
      reason: `did-document-unverified`
    } : {
      ok: true,
      doc: r2
    };
  }
  var kn = {
    ...Gt,
    resolve: async (e2, t2) => (rt(e2), On(e2, t2))
  }, An = {
    ...Kt,
    resolve: On
  }, jn = class {
    byKind = /* @__PURE__ */ new Map();
    constructor(e2 = []) {
      for (let t2 of e2) this.register(t2);
    }
    register(e2) {
      if (!/^did:[a-z0-9]+$/.test(e2.kind)) throw Error(`not a DID method: ${e2.kind}`);
      if (e2.route !== void 0 && typeof e2.resolve != `function`) throw Error(`${e2.kind}: a method with a route needs a resolver`);
      return this.byKind.set(e2.kind, e2), this;
    }
    policyFor(e2) {
      return this.byKind.get(e2);
    }
    methodOf(e2) {
      let t2 = Dn(e2);
      return t2 ? this.byKind.get(t2) : void 0;
    }
    routeOf(e2) {
      let t2 = this.methodOf(e2);
      return t2?.route !== void 0 && t2.listsServices && t2.verified && t2.resolve ? t2.route : void 0;
    }
    kinds() {
      return [
        ...this.byKind.keys()
      ];
    }
  };
  function Mn() {
    let e2 = /* @__PURE__ */ new Map([
      [
        kn.kind,
        kn
      ],
      [
        An.kind,
        An
      ]
    ]);
    return new jn(qt.map((t2) => e2.get(t2.kind) ?? t2));
  }
  var Nn = Mn();
  async function Pn(e2, t2 = {}) {
    let n2 = t2.methods ?? Nn, r2 = n2.methodOf(e2), i2 = n2.routeOf(e2);
    if (!r2?.resolve || i2 === void 0) return {
      ok: false,
      reason: `unsupported-vid`
    };
    let a2 = {
      ok: false,
      reason: `did-document-unverified`
    };
    if (i2 === `host-named`) {
      let t3 = r2.hostPath?.(e2)?.[0];
      if (t3 === void 0 || !rn(t3)) return a2;
    }
    try {
      let n3 = await r2.resolve(e2, t2.resolveDid ? {
        resolveDid: t2.resolveDid
      } : {});
      return !n3.ok || n3.doc.id !== e2 ? a2 : {
        ok: true,
        doc: n3.doc,
        route: i2
      };
    } catch {
      return a2;
    }
  }
  var Fn = 3e4, In = class {
    connection;
    defaultTimeoutMs;
    constructor(e2, t2) {
      this.connection = e2, this.defaultTimeoutMs = t2 ?? Fn;
    }
    async sendAndAwaitReply(e2, t2, n2) {
      let r2 = this.connection.waitFor(t2, n2.timeoutMs ?? this.defaultTimeoutMs, {
        from: n2.from
      });
      try {
        this.connection.send(e2);
      } catch (e3) {
        throw r2.catch(() => {
        }), e3;
      }
      return await r2;
    }
    async send(e2) {
      this.connection.send(e2);
    }
    close() {
      this.connection.close();
    }
  }, Ln = `https://trusttasks.org/spec/vta/webvh/dids/create/1.0`, Rn = `https://trusttasks.org/spec/vta/webvh/dids/delete/1.0`, zn = `https://trusttasks.org/spec/vta/webvh/dids/update/1.0`, Bn = `https://trusttasks.org/spec/vta/webvh/dids/rotate-keys/1.0`, Vn = `https://trusttasks.org/spec/vta/webvh/dids/register-with-server/1.0`, Hn = `https://trusttasks.org/spec/vta/webvh/agent-name/list/1.0`, Un = `https://trusttasks.org/spec/vta/webvh/agent-name/check/1.0`, Wn = `https://trusttasks.org/spec/vta/webvh/agent-name/set/1.0`, Gn = `https://trusttasks.org/spec/vta/webvh/agent-name/remove/1.0`, Kn = `https://trusttasks.org/spec/vta/webvh/agent-name/disable/1.0`, qn = `https://trusttasks.org/spec/vta/webvh/agent-name/enable/1.0`, Jn = `https://trusttasks.org/spec/vta/webvh/servers/domains/0.1`, Yn = `https://trusttasks.org/spec/vta/webvh/servers/reconcile/0.1`, Xn = `https://trusttasks.org/spec/vta/webvh/servers/retire-orphan/0.1`, Zn = `https://trusttasks.org/spec/rooms/owner/register/0.1`, Qn = `https://trusttasks.org/spec/rooms/keys/backfill/0.1`, $n = `https://trusttasks.org/spec/rooms/keys/read/0.1`, er = `https://trusttasks.org/spec/rooms/keys/read/0.1#response`, tr = `https://trusttasks.org/spec/rooms/keys/browse/0.1`, nr = `https://trusttasks.org/spec/rooms/keys/browse/0.1#response`, rr = `https://trusttasks.org/spec/vault/proxy-login/0.2`, ir = `https://trusttasks.org/spec/vault/proxy-login/0.2#response`, ar = `https://trusttasks.org/spec/provision/integration/0.3`, or = `https://trusttasks.org/spec/provision/integration/0.3#response`, sr = 1e4;
  function cr() {
    return 7e4;
  }
  function lr() {
    return cr() + sr;
  }
  var ur = /* @__PURE__ */ new Set([
    Ln,
    Rn,
    zn,
    Bn,
    Vn,
    Hn,
    Un,
    Wn,
    Gn,
    Kn,
    qn,
    Jn,
    Yn,
    Xn,
    Zn,
    Qn,
    $n,
    tr,
    rr,
    ar
  ]);
  function dr(e2) {
    return ur.has(e2);
  }
  function fr(e2, t2) {
    return dr(e2) ? Math.max(t2, lr()) : t2;
  }
  var pr = 2e4;
  function mr(e2, t2 = pr) {
    let n2 = e2 ?? fetch.bind(globalThis);
    return (e3, r2) => {
      let i2 = AbortSignal.timeout(t2), a2 = r2?.signal, o2 = i2;
      return a2 && (o2 = typeof AbortSignal.any == `function` ? AbortSignal.any([
        a2,
        i2
      ]) : i2), n2(e3, {
        ...r2,
        signal: o2
      });
    };
  }
  function hr(e2) {
    return e2 instanceof DOMException && e2.name === `TimeoutError`;
  }
  var gr = `TrustTaskHTTPS`, _r = `/trust-tasks`;
  function vr(e2) {
    if (typeof e2 == `string`) return e2;
    if (Array.isArray(e2)) {
      for (let t2 of e2) {
        let e3 = vr(t2);
        if (e3) return e3;
      }
      return;
    }
    if (e2 && typeof e2 == `object`) {
      let t2 = e2.uri;
      if (typeof t2 == `string`) return t2;
    }
  }
  function yr(e2, t2) {
    let n2 = e2.type;
    return typeof n2 == `string` ? n2 === t2 : Array.isArray(n2) ? n2.includes(t2) : false;
  }
  function br(e2) {
    if (!e2 || typeof e2 != `object`) return;
    let t2 = e2.service;
    if (Array.isArray(t2)) for (let e3 of t2) {
      if (!e3 || typeof e3 != `object` || !yr(e3, `TrustTaskHTTPS`)) continue;
      let t3 = vr(e3.serviceEndpoint);
      if (!t3) continue;
      let n2;
      try {
        n2 = new URL(t3);
      } catch {
        continue;
      }
      if (n2.protocol !== `https:`) throw new _(`e.client.parse`, `trust-task endpoint: ${gr} endpoint must be https:, got ${n2.protocol}`);
      return t3.replace(/\/+$/, ``);
    }
  }
  function xr(e2) {
    return `${e2.replace(/\/+$/, ``)}${_r}`;
  }
  var Sr = `https://trusttasks.org/spec/auth/challenge/0.1`, Cr = `https://trusttasks.org/spec/auth/challenge/0.1#response`, wr = `https://trusttasks.org/spec/auth/authenticate/0.2`, Tr = `https://trusttasks.org/spec/auth/authenticate/0.2#response`;
  async function Er(e2, t2) {
    let n2 = {
      ...t2.subject ? {
        subject: t2.subject
      } : {},
      ...t2.purpose ? {
        purpose: t2.purpose
      } : {}
    }, r2 = R(Sr, n2, {
      issuer: t2.issuer ?? t2.holder.did,
      recipient: t2.service.did
    });
    return e2.send(r2, {
      expectedResponseType: Cr,
      operationLabel: `auth/challenge/0.1`
    });
  }
  var Dr = /^did:key:z[1-9A-HJ-NP-Za-km-z]+$/, Or = 512;
  function kr(e2) {
    return typeof e2 == `string` && e2.length <= Or && Dr.test(e2);
  }
  async function Ar(e2, t2) {
    let n2 = {
      challenge: t2.challenge,
      sessionId: t2.sessionId,
      ...t2.scope && t2.scope.length > 0 ? {
        scope: t2.scope
      } : {},
      ...t2.sessionKey === void 0 ? {} : {
        sessionKey: t2.sessionKey
      }
    }, r2 = R(wr, n2, {
      issuer: t2.issuer ?? t2.holder.did,
      recipient: t2.service.did
    });
    return e2.send(r2, {
      expectedResponseType: Tr,
      operationLabel: `auth/authenticate/0.2`
    });
  }
  async function jr(t2) {
    if (t2.ok) return;
    let n2;
    try {
      n2 = await t2.json();
    } catch {
      throw t2.status === 429 ? k(t2, void 0) : e(void 0, t2.status, t2.statusText);
    }
    throw t2.status === 429 && !ie(n2?.type) ? k(t2, n2) : e(n2, t2.status, t2.statusText);
  }
  async function Mr(t2, n2 = {}) {
    let r2;
    try {
      r2 = await t2.json();
    } catch (n3) {
      throw t2.status === 429 ? k(t2, void 0) : t2.ok ? new _(`e.client.parse`, n3.message, {
        status: t2.status
      }) : e(void 0, t2.status, t2.statusText);
    }
    if (!t2.ok && !ie(r2?.type)) throw t2.status === 429 ? k(t2, r2) : e(r2, t2.status, t2.statusText);
    if (n2.expectedSigner !== void 0 && await ee(r2 ?? {}, n2.expectedSigner), n2.inReplyTo !== void 0 && !ie(r2?.type)) {
      let e2 = r2 ?? {}, t3 = n2.inReplyTo.threadId ?? n2.inReplyTo.id;
      if (e2.threadId !== t3) throw new _(`e.client.parse`, `${n2.operationLabel ?? `reply`}: the reply is threaded to ${String(e2.threadId)}, not to this request`);
      if (n2.inReplyTo.issuer !== void 0 && e2.recipient !== n2.inReplyTo.issuer) throw new _(`e.client.parse`, `${n2.operationLabel ?? `reply`}: the reply is addressed to ${String(e2.recipient)}, not ${n2.inReplyTo.issuer}`);
    }
    return x(r2, {
      ...n2.expectedResponseType === void 0 ? {} : {
        expectedResponseType: n2.expectedResponseType
      },
      ...n2.operationLabel === void 0 ? {} : {
        operationLabel: n2.operationLabel
      }
    });
  }
  var Nr = 6e5, Pr = /* @__PURE__ */ new Map(), Fr = /* @__PURE__ */ new Map();
  function Ir(e2, t2) {
    return `${e2.replace(/\/+$/, ``)}|${t2}`;
  }
  function Lr(e2) {
    return (t2) => {
      let n2 = Ir(e2.baseUrl, e2.holder.did);
      return (t2 === void 0 || Pr.get(n2)?.token === t2) && Pr.delete(n2), zr(e2);
    };
  }
  function Rr(e2) {
    return {
      label: `VTA REST`,
      schemes: [
        `https:`
      ],
      ...e2
    };
  }
  async function zr(e2) {
    let t2 = Ir(e2.baseUrl.replace(/\/+$/, ``), e2.holder.did), n2 = Pr.get(t2);
    if (n2 && n2.expiresAt > Date.now()) return n2.token;
    let r2 = Fr.get(t2);
    if (r2) return r2;
    let i2 = Br(e2, t2).finally(() => {
      Fr.get(t2) === i2 && Fr.delete(t2);
    });
    return Fr.set(t2, i2), i2;
  }
  async function Br(e2, t2) {
    let n2 = Vr(e2), r2 = await Er(n2, {
      holder: e2.holder,
      service: e2.service,
      subject: e2.holder.did
    }), i2 = await Ar(n2, {
      holder: e2.holder,
      service: e2.service,
      challenge: r2.challenge,
      sessionId: r2.sessionId
    }), a2 = i2.tokens?.accessToken;
    if (!a2) throw new _(`e.client.parse`, `auth/authenticate: the reply carries no access token`);
    let o2 = typeof i2.tokens.expiresIn == `number` ? Math.min(Nr, i2.tokens.expiresIn * 1e3 - 6e4) : Nr;
    return Pr.set(t2, {
      token: a2,
      expiresAt: Date.now() + o2
    }), a2;
  }
  function Vr(e2) {
    let t2 = mr(Me(e2.fetch, Rr(e2.netPolicy))), n2 = `${e2.baseUrl.replace(/\/+$/, ``)}${_r}`, r2 = v(e2.signing);
    return {
      async send(i2, a2 = {}) {
        let o2 = a2.operationLabel ?? i2.type;
        await c(i2, r2);
        let s2;
        try {
          s2 = await t2(n2, {
            method: `POST`,
            headers: {
              "content-type": `application/json`
            },
            body: JSON.stringify(i2)
          });
        } catch (e3) {
          throw hr(e3) ? new _(`e.client.timeout`, `${o2}: VTA did not respond within ${pr / 1e3}s`) : e3.code === void 0 ? new _(`e.client.network`, e3.message) : e3;
        }
        return Mr(s2, {
          ...a2.expectedResponseType === void 0 ? {} : {
            expectedResponseType: a2.expectedResponseType
          },
          operationLabel: o2,
          expectedSigner: e2.service.did,
          inReplyTo: i2
        });
      }
    };
  }
  var Hr = class {
    kind = `rest`;
    auth;
    signer;
    path;
    policyFetch;
    constructor(e2) {
      this.signer = v(e2.signing), this.auth = {
        baseUrl: e2.baseUrl,
        holder: e2.holder,
        service: e2.service,
        signing: this.signer,
        ...e2.netPolicy ? {
          netPolicy: e2.netPolicy
        } : {},
        ...e2.fetch ? {
          fetch: e2.fetch
        } : {}
      }, this.path = e2.trustTasksPath ?? `/trust-tasks`, this.policyFetch = Me(e2.fetch, Rr(e2.netPolicy));
    }
    async post(e2, t2, n2) {
      let r2 = `${this.auth.baseUrl.replace(/\/+$/, ``)}${this.path}`;
      await c(e2, this.signer);
      let i2 = JSON.stringify(e2), a2 = mr(this.policyFetch, n2), o2 = async (e3) => {
        try {
          return await a2(r2, {
            method: `POST`,
            headers: {
              "content-type": `application/json`,
              authorization: `Bearer ${e3}`
            },
            body: i2
          });
        } catch (e4) {
          throw hr(e4) ? new _(`e.client.timeout`, `${t2}: VTA did not respond within ${n2 / 1e3}s`) : new _(`e.client.network`, e4.message);
        }
      }, s2 = await zr(this.auth), l2 = await o2(s2);
      return l2.status === 401 ? o2(await Lr(this.auth)(s2)) : l2;
    }
    async send(e2, t2 = {}) {
      let n2 = t2.operationLabel ?? e2.type;
      return Mr(await this.post(e2, n2, fr(e2.type, t2.timeoutMs ?? 2e4)), {
        ...t2.expectedResponseType === void 0 ? {} : {
          expectedResponseType: t2.expectedResponseType
        },
        operationLabel: n2,
        expectedSigner: this.auth.service.did
      });
    }
    async notify(e2, t2 = {}) {
      return jr(await this.post(e2, t2.operationLabel ?? e2.type, t2.timeoutMs ?? 2e4));
    }
  }, Ur = `https://trusttasks.org/spec/vta/contexts/list/1.0`, Wr = `https://trusttasks.org/spec/vta/contexts/create/1.0`, Gr = `https://trusttasks.org/spec/vta/contexts/create/1.0#response`;
  function Kr(e2) {
    return e2;
  }
  async function qr(e2, t2) {
    let n2 = R(Ur, {}, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    });
    return ((await e2.send(n2, {
      expectedResponseType: `https://trusttasks.org/spec/vta/contexts/list/1.0#response`,
      operationLabel: `contexts/list/1.0`
    })).contexts ?? []).map(Kr);
  }
  async function Jr(e2, t2) {
    let n2 = R(Wr, {
      id: t2.id,
      name: t2.name ?? t2.id,
      ...t2.description ? {
        description: t2.description
      } : {},
      ...t2.parent ? {
        parent: t2.parent
      } : {}
    }, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    });
    return Kr(await e2.send(n2, {
      expectedResponseType: Gr,
      operationLabel: `contexts/create/1.0`
    }));
  }
  var Yr = 3e4;
  function Xr(e2) {
    let t2 = e2.body ?? {}, r2 = typeof t2.code == `string` ? t2.code : ``, i2 = r2.split(`.`).slice(2).join(`.`) || r2, a2 = typeof t2.comment == `string` && t2.comment ? t2.comment : r2;
    return new _(n(i2), a2 || `refused`, {
      details: {
        code: i2,
        message: a2,
        details: {
          problemCode: r2,
          ...Array.isArray(t2.args) ? {
            args: t2.args
          } : {}
        }
      }
    });
  }
  var Zr = class {
    kind = `didcomm`;
    bridge;
    holder;
    vta;
    signer;
    mediator;
    timeoutMs;
    replyProofPurpose;
    constructor(e2) {
      this.replyProofPurpose = e2.replyProofPurpose ?? `authentication`, this.signer = v(e2.signing), this.bridge = e2.bridge, this.holder = e2.holder, this.vta = e2.vta, e2.mediator !== void 0 && (this.mediator = e2.mediator), this.timeoutMs = e2.timeoutMs ?? Yr;
    }
    requestEnrollmentChallenge(e2) {
      return this.exchange(S.enrollChallenge, {
        did: e2
      });
    }
    submitPasskeyEnrollment(e2) {
      let t2 = {
        did: e2.did,
        ceremonyId: e2.ceremonyId,
        credentialId: e2.credentialId,
        publicKeyMultibase: e2.publicKeyMultibase,
        coseAlgorithm: e2.coseAlgorithm,
        attestationObject: e2.attestationObject,
        clientDataJson: e2.clientDataJson,
        authenticatorData: e2.authenticatorData,
        transports: e2.transports,
        ...e2.label === void 0 ? {} : {
          label: e2.label
        }
      };
      return this.exchange(S.enrollSubmit, t2);
    }
    listPasskeys(e2) {
      return this.exchange(S.list, {
        did: e2
      });
    }
    async removePasskey(e2, t2) {
      await this.exchange(S.revoke, {
        did: e2,
        fragment: t2
      });
    }
    async send(e2, t2 = {}) {
      let { outer: n2, requestId: r2 } = await this.packEnvelope(e2), i2 = await this.bridge.sendAndAwaitReply(n2, r2, {
        timeoutMs: fr(e2.type, t2.timeoutMs ?? this.timeoutMs),
        from: this.mediator ? [
          this.vta.did,
          this.mediator.did
        ] : [
          this.vta.did
        ]
      });
      if (i2.type === `https://didcomm.org/report-problem/2.0/problem-report`) {
        let e3 = typeof i2.from == `string` ? i2.from : void 0;
        throw !e3 || e3 !== this.vta.did && e3 !== this.mediator?.did ? new _(`e.p.msg.unauthorized`, `problem report from ${i2.from ?? `(none)`} != ${this.vta.did}`) : Xr(i2);
      }
      if (i2.type !== `https://trusttasks.org/binding/didcomm/0.1/envelope`) throw new _(`e.client.parse`, `reply type ${i2.type ?? `(none)`} != Trust-Task binding envelope`);
      let a2 = i2.thid ?? i2.id;
      if (a2 !== r2) throw new _(`e.client.parse`, `reply thread id ${a2 ?? `(none)`} (thid/id) != request id ${r2}`);
      if (i2.from !== this.vta.did) throw new _(`e.p.msg.unauthorized`, `reply from ${i2.from ?? `(none)`} != VTA ${this.vta.did}`);
      let o2 = i2.body ?? {};
      return await ee(o2 ?? {}, this.vta.did, {
        proofPurpose: this.replyProofPurpose
      }), x(o2, {
        ...t2.expectedResponseType === void 0 ? {} : {
          expectedResponseType: t2.expectedResponseType
        },
        ...t2.operationLabel === void 0 ? {} : {
          operationLabel: t2.operationLabel
        }
      });
    }
    async notify(e2, t2 = {}) {
      let { outer: n2 } = await this.packEnvelope(e2);
      await this.bridge.send(n2);
    }
    exchange(e2, t2) {
      return this.send(this.buildRequest(e2, t2));
    }
    buildRequest(e2, t2) {
      return R(e2, t2, {
        issuer: this.holder.did,
        recipient: this.vta.did
      });
    }
    async buildOutbound(e2, t2) {
      return this.packEnvelope(this.buildRequest(e2, t2));
    }
    async packEnvelope(e2) {
      await c(e2, this.signer, this.holder.did);
      let t2 = e2.id, n2 = {
        id: t2,
        type: s,
        from: this.holder.did,
        to: [
          this.vta.did
        ],
        body: e2
      }, r2 = await Ve(n2, this.holder, [
        {
          kid: this.vta.keyAgreementKid,
          jwk: this.vta.keyAgreementPublicJwk
        }
      ]);
      if (!this.mediator) return {
        outer: r2,
        inner: r2,
        requestId: t2
      };
      let i2 = We(this.vta.did, this.holder.did, this.mediator.did, r2);
      return {
        outer: await Fe(i2, this.holder, [
          {
            kid: this.mediator.keyAgreementKid,
            jwk: this.mediator.keyAgreementPublicJwk
          }
        ]),
        inner: r2,
        requestId: t2
      };
    }
  }, Qr = `https://trusttasks.org/spec/vta/webvh/dids/list/1.0`, $r = `${Qr}#response`;
  async function ei(e2, t2) {
    let n2 = R(Qr, t2.contextId ? {
      contextId: t2.contextId
    } : {}, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    });
    return (await e2.send(n2, {
      expectedResponseType: $r,
      operationLabel: `webvh/dids/list`
    })).dids ?? [];
  }
  var ti = [
    `tsp`,
    `didcomm`,
    `rest`
  ];
  function ni(e2) {
    return [
      ...e2
    ].sort((e3, t2) => ti.indexOf(e3.kind) - ti.indexOf(t2.kind));
  }
  var ri = class {
    channels;
    constructor(e2) {
      if (e2.length === 0) throw new _(`e.client.unsupported`, `VtaSession requires at least one channel`);
      this.channels = ni(e2);
    }
    get primaryKind() {
      return this.channels[0].kind;
    }
    get kinds() {
      return this.channels.map((e2) => e2.kind);
    }
    async send(e2, t2) {
      let n2 = this.channels.filter((t3) => !t3.supports || t3.supports(e2.type));
      if (n2.length === 0) throw new _(`e.client.unsupported`, `no channel routes trust task ${e2.type}`);
      let r2;
      for (let i2 = 0; i2 < n2.length; i2++) {
        let a2 = n2[i2];
        try {
          return await a2.send(e2, t2);
        } catch (e3) {
          let t3 = i2 === n2.length - 1;
          if (e3 instanceof _ && e3.code === `e.client.unsupported` && !t3) {
            r2 = e3;
            continue;
          }
          throw e3;
        }
      }
      throw r2 ?? new _(`e.client.unsupported`, `no channel routes trust task ${e2.type}`);
    }
    async notify(e2, t2) {
      let n2 = this.channels.filter((t3) => !t3.supports || t3.supports(e2.type));
      if (n2.length === 0) throw new _(`e.client.unsupported`, `no channel routes trust task ${e2.type}`);
      let r2;
      for (let i2 = 0; i2 < n2.length; i2++) {
        let a2 = n2[i2];
        try {
          await a2.notify(e2, t2);
          return;
        } catch (e3) {
          let t3 = i2 === n2.length - 1;
          if (e3 instanceof _ && e3.code === `e.client.unsupported` && !t3) {
            r2 = e3;
            continue;
          }
          throw e3;
        }
      }
      throw r2 ?? new _(`e.client.unsupported`, `no channel carries one-way trust task ${e2.type}`);
    }
    async close() {
      for (let e2 of this.channels) await e2.close?.();
    }
  }, ii = De.ED25519_PUB;
  function ai() {
    let e2 = et.utils.randomSecretKey();
    return si(e2, et.getPublicKey(e2));
  }
  function oi(e2) {
    return si(e2, et.getPublicKey(e2));
  }
  function si(e2, t2) {
    let n2 = ke(ii, t2), r2 = `did:key:${n2}`;
    return {
      did: r2,
      kid: `${r2}#${n2}`,
      privateKey: e2,
      publicKey: t2
    };
  }
  function ci(e2) {
    let t2 = et.utils.toMontgomerySecret(e2.privateKey), n2 = $e.getPublicKey(t2), r2 = Le(e2.did).didDocument.keyAgreement?.[0];
    if (!r2) throw Error(`siop: Ed25519 did:key has no keyAgreement VM`);
    return {
      keyAgreementKid: r2,
      secretJwk: {
        kty: `OKP`,
        crv: `X25519`,
        x: Ee(n2),
        d: Ee(t2)
      }
    };
  }
  function li(e2, t2) {
    let n2 = typeof e2;
    if (n2 !== typeof t2) return false;
    if (Array.isArray(e2)) {
      if (!Array.isArray(t2)) return false;
      let n3 = e2.length;
      if (n3 !== t2.length) return false;
      for (let r2 = 0; r2 < n3; r2++) if (!li(e2[r2], t2[r2])) return false;
      return true;
    }
    if (n2 === `object`) {
      if (!e2 || !t2) return e2 === t2;
      let n3 = Object.keys(e2), r2 = Object.keys(t2);
      if (n3.length !== r2.length) return false;
      for (let r3 of n3) if (!li(e2[r3], t2[r3])) return false;
      return true;
    }
    return e2 === t2;
  }
  function ui(e2) {
    return encodeURI(di(e2));
  }
  function di(e2) {
    return e2.replace(/~/g, `~0`).replace(/\//g, `~1`);
  }
  var fi = {
    prefixItems: true,
    items: true,
    allOf: true,
    anyOf: true,
    oneOf: true
  }, pi = {
    $defs: true,
    definitions: true,
    properties: true,
    patternProperties: true,
    dependentSchemas: true
  }, mi = {
    id: true,
    $id: true,
    $ref: true,
    $schema: true,
    $anchor: true,
    $vocabulary: true,
    $comment: true,
    default: true,
    enum: true,
    const: true,
    required: true,
    type: true,
    maximum: true,
    minimum: true,
    exclusiveMaximum: true,
    exclusiveMinimum: true,
    multipleOf: true,
    maxLength: true,
    minLength: true,
    pattern: true,
    format: true,
    maxItems: true,
    minItems: true,
    uniqueItems: true,
    maxProperties: true,
    minProperties: true
  }, hi = typeof self < `u` && self.location && self.location.origin !== `null` ? new URL(self.location.origin + self.location.pathname + location.search) : new URL(`https://github.com/cfworker`);
  function gi(e2, t2 = /* @__PURE__ */ Object.create(null), n2 = hi, r2 = ``) {
    if (e2 && typeof e2 == `object` && !Array.isArray(e2)) {
      let i3 = e2.$id || e2.id;
      if (i3) {
        let a2 = new URL(i3, n2.href);
        a2.hash.length > 1 ? t2[a2.href] = e2 : (a2.hash = ``, r2 === `` ? n2 = a2 : gi(e2, t2, n2));
      }
    } else if (e2 !== true && e2 !== false) return t2;
    let i2 = n2.href + (r2 ? `#` + r2 : ``);
    if (t2[i2] !== void 0) throw Error(`Duplicate schema URI "${i2}".`);
    if (t2[i2] = e2, e2 === true || e2 === false) return t2;
    if (e2.__absolute_uri__ === void 0 && Object.defineProperty(e2, "__absolute_uri__", {
      enumerable: false,
      value: i2
    }), e2.$ref && e2.__absolute_ref__ === void 0) {
      let t3 = new URL(e2.$ref, n2.href);
      t3.hash = t3.hash, Object.defineProperty(e2, "__absolute_ref__", {
        enumerable: false,
        value: t3.href
      });
    }
    if (e2.$recursiveRef && e2.__absolute_recursive_ref__ === void 0) {
      let t3 = new URL(e2.$recursiveRef, n2.href);
      t3.hash = t3.hash, Object.defineProperty(e2, "__absolute_recursive_ref__", {
        enumerable: false,
        value: t3.href
      });
    }
    if (e2.$anchor) {
      let r3 = new URL(`#` + e2.$anchor, n2.href);
      t2[r3.href] = e2;
    }
    for (let i3 in e2) {
      if (mi[i3]) continue;
      let a2 = `${r2}/${ui(i3)}`, o2 = e2[i3];
      if (Array.isArray(o2)) {
        if (fi[i3]) {
          let e3 = o2.length;
          for (let r3 = 0; r3 < e3; r3++) gi(o2[r3], t2, n2, `${a2}/${r3}`);
        }
      } else if (pi[i3]) for (let e3 in o2) gi(o2[e3], t2, n2, `${a2}/${ui(e3)}`);
      else gi(o2, t2, n2, a2);
    }
    return t2;
  }
  var _i = /^(\d\d\d\d)-(\d\d)-(\d\d)$/, vi = [
    0,
    31,
    28,
    31,
    30,
    31,
    30,
    31,
    31,
    30,
    31,
    30,
    31
  ], yi = /^(\d\d):(\d\d):(\d\d)(\.\d+)?(z|[+-]\d\d(?::?\d\d)?)?$/i, bi = /^(?=.{1,253}\.?$)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[-0-9a-z]{0,61}[0-9a-z])?)*\.?$/i, xi = /^(?:[a-z][a-z0-9+\-.]*:)?(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'"()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'"()*+,;=:@]|%[0-9a-f]{2})*)*)?(?:\?(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'"()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i, Si = /^(?:(?:[^\x00-\x20"'<>%\\^`{|}]|%[0-9a-f]{2})|\{[+#./;?&=,!@|]?(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?(?:,(?:[a-z0-9_]|%[0-9a-f]{2})+(?::[1-9][0-9]{0,3}|\*)?)*\})*$/i, Ci = /^(?:(?:https?|ftp):\/\/)(?:\S+(?::\S*)?@)?(?:(?!10(?:\.\d{1,3}){3})(?!127(?:\.\d{1,3}){3})(?!169\.254(?:\.\d{1,3}){2})(?!192\.168(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u{00a1}-\u{ffff}0-9]+-?)*[a-z\u{00a1}-\u{ffff}0-9]+)(?:\.(?:[a-z\u{00a1}-\u{ffff}0-9]+-?)*[a-z\u{00a1}-\u{ffff}0-9]+)*(?:\.(?:[a-z\u{00a1}-\u{ffff}]{2,})))(?::\d{2,5})?(?:\/[^\s]*)?$/iu, wi = /^(?:urn:uuid:)?[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i, Ti = /^(?:\/(?:[^~/]|~0|~1)*)*$/, Ei = /^#(?:\/(?:[a-z0-9_\-.!$&'()*+,;:=@]|%[0-9a-f]{2}|~0|~1)*)*$/i, Di = /^(?:0|[1-9][0-9]*)(?:#|(?:\/(?:[^~/]|~0|~1)*)*)$/, Oi = (e2) => {
    if (e2[0] === `"`) return false;
    let [t2, n2, ...r2] = e2.split(`@`);
    return !t2 || !n2 || r2.length !== 0 || t2.length > 64 || n2.length > 253 || t2[0] === `.` || t2.endsWith(`.`) || t2.includes(`..`) || !/^[a-z0-9.-]+$/i.test(n2) || !/^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+$/i.test(t2) ? false : n2.split(`.`).every((e3) => /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/i.test(e3));
  }, ki = /^(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$/, Ai = /^((([0-9a-f]{1,4}:){7}([0-9a-f]{1,4}|:))|(([0-9a-f]{1,4}:){6}(:[0-9a-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){5}(((:[0-9a-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9a-f]{1,4}:){4}(((:[0-9a-f]{1,4}){1,3})|((:[0-9a-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){3}(((:[0-9a-f]{1,4}){1,4})|((:[0-9a-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){2}(((:[0-9a-f]{1,4}){1,5})|((:[0-9a-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9a-f]{1,4}:){1}(((:[0-9a-f]{1,4}){1,6})|((:[0-9a-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9a-f]{1,4}){1,7})|((:[0-9a-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))$/i, ji = (e2) => e2.length > 1 && e2.length < 80 && (/^P\d+([.,]\d+)?W$/.test(e2) || /^P[\dYMDTHS]*(\d[.,]\d+)?[YMDHS]$/.test(e2) && /^P([.,\d]+Y)?([.,\d]+M)?([.,\d]+D)?(T([.,\d]+H)?([.,\d]+M)?([.,\d]+S)?)?$/.test(e2));
  function Mi(e2) {
    return e2.test.bind(e2);
  }
  var Ni = {
    date: Fi,
    time: Ii.bind(void 0, false),
    "date-time": Ri,
    duration: ji,
    uri: Vi,
    "uri-reference": Mi(xi),
    "uri-template": Mi(Si),
    url: Mi(Ci),
    email: Oi,
    hostname: Mi(bi),
    ipv4: Mi(ki),
    ipv6: Mi(Ai),
    regex: Ui,
    uuid: Mi(wi),
    "json-pointer": Mi(Ti),
    "json-pointer-uri-fragment": Mi(Ei),
    "relative-json-pointer": Mi(Di)
  };
  function Pi(e2) {
    return e2 % 4 == 0 && (e2 % 100 != 0 || e2 % 400 == 0);
  }
  function Fi(e2) {
    let t2 = e2.match(_i);
    if (!t2) return false;
    let n2 = +t2[1], r2 = +t2[2], i2 = +t2[3];
    return r2 >= 1 && r2 <= 12 && i2 >= 1 && i2 <= (r2 == 2 && Pi(n2) ? 29 : vi[r2]);
  }
  function Ii(e2, t2) {
    let n2 = t2.match(yi);
    if (!n2) return false;
    let r2 = +n2[1], i2 = +n2[2], a2 = +n2[3], o2 = !!n2[5];
    return (r2 <= 23 && i2 <= 59 && a2 <= 59 || r2 == 23 && i2 == 59 && a2 == 60) && (!e2 || o2);
  }
  var Li = /t|\s/i;
  function Ri(e2) {
    let t2 = e2.split(Li);
    return t2.length == 2 && Fi(t2[0]) && Ii(true, t2[1]);
  }
  var zi = /\/|:/, Bi = /^(?:[a-z][a-z0-9+\-.]*:)(?:\/?\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:]|%[0-9a-f]{2})*@)?(?:\[(?:(?:(?:(?:[0-9a-f]{1,4}:){6}|::(?:[0-9a-f]{1,4}:){5}|(?:[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){4}|(?:(?:[0-9a-f]{1,4}:){0,1}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){3}|(?:(?:[0-9a-f]{1,4}:){0,2}[0-9a-f]{1,4})?::(?:[0-9a-f]{1,4}:){2}|(?:(?:[0-9a-f]{1,4}:){0,3}[0-9a-f]{1,4})?::[0-9a-f]{1,4}:|(?:(?:[0-9a-f]{1,4}:){0,4}[0-9a-f]{1,4})?::)(?:[0-9a-f]{1,4}:[0-9a-f]{1,4}|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))|(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?::[0-9a-f]{1,4}|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::)|[Vv][0-9a-f]+\.[a-z0-9\-._~!$&'()*+,;=:]+)\]|(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)|(?:[a-z0-9\-._~!$&'()*+,;=]|%[0-9a-f]{2})*)(?::\d*)?(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*|\/(?:(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)?|(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})+(?:\/(?:[a-z0-9\-._~!$&'()*+,;=:@]|%[0-9a-f]{2})*)*)(?:\?(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?(?:#(?:[a-z0-9\-._~!$&'()*+,;=:@/?]|%[0-9a-f]{2})*)?$/i;
  function Vi(e2) {
    return zi.test(e2) && Bi.test(e2);
  }
  var Hi = /[^\\]\\Z/;
  function Ui(e2) {
    if (Hi.test(e2)) return false;
    try {
      return new RegExp(e2, `u`), true;
    } catch {
      return false;
    }
  }
  function Wi(e2) {
    let t2 = 0, n2 = e2.length, r2 = 0, i2;
    for (; r2 < n2; ) t2++, i2 = e2.charCodeAt(r2++), i2 >= 55296 && i2 <= 56319 && r2 < n2 && (i2 = e2.charCodeAt(r2), (i2 & 64512) == 56320 && r2++);
    return t2;
  }
  function B(e2, t2, n2 = `2019-09`, r2 = gi(t2), i2 = true, a2 = null, o2 = `#`, s2 = `#`, c2 = /* @__PURE__ */ Object.create(null)) {
    if (t2 === true) return {
      valid: true,
      errors: []
    };
    if (t2 === false) return {
      valid: false,
      errors: [
        {
          instanceLocation: o2,
          keyword: `false`,
          keywordLocation: o2,
          error: `False boolean schema.`
        }
      ]
    };
    let l2 = typeof e2, u2;
    switch (l2) {
      case `boolean`:
      case `number`:
      case `string`:
        u2 = l2;
        break;
      case `object`:
        u2 = e2 === null ? `null` : Array.isArray(e2) ? `array` : `object`;
        break;
      default:
        throw Error(`Instances of "${l2}" type are not supported.`);
    }
    let { $ref: d2, $recursiveRef: f2, $recursiveAnchor: p2, type: m2, const: h2, enum: g2, required: _2, not: v2, anyOf: y2, allOf: b2, oneOf: ee2, if: x2, then: S2, else: C2, format: w2, properties: T2, patternProperties: E2, additionalProperties: D2, unevaluatedProperties: O2, minProperties: k2, maxProperties: A2, propertyNames: j2, dependentRequired: M2, dependentSchemas: N2, dependencies: P2, prefixItems: F2, items: I2, additionalItems: L2, unevaluatedItems: te2, contains: ne2, minContains: re2, maxContains: ie2, minItems: ae2, maxItems: oe2, uniqueItems: se2, minimum: ce2, maximum: le2, exclusiveMinimum: ue2, exclusiveMaximum: de2, multipleOf: fe2, minLength: pe2, maxLength: R2, pattern: me2, __absolute_ref__: he2, __absolute_recursive_ref__: ge2 } = t2, z2 = [];
    if (p2 === true && a2 === null && (a2 = t2), f2 === `#`) {
      let l3 = a2 === null ? r2[ge2] : a2, u3 = `${s2}/$recursiveRef`, d3 = B(e2, a2 === null ? t2 : a2, n2, r2, i2, l3, o2, u3, c2);
      d3.valid || z2.push({
        instanceLocation: o2,
        keyword: `$recursiveRef`,
        keywordLocation: u3,
        error: `A subschema had errors.`
      }, ...d3.errors);
    }
    if (d2 !== void 0) {
      let t3 = r2[he2 || d2];
      if (t3 === void 0) {
        let e3 = `Unresolved $ref "${d2}".`;
        throw he2 && he2 !== d2 && (e3 += `  Absolute URI "${he2}".`), e3 += `
Known schemas:
- ${Object.keys(r2).join(`
- `)}`, Error(e3);
      }
      let l3 = `${s2}/$ref`, u3 = B(e2, t3, n2, r2, i2, a2, o2, l3, c2);
      if (u3.valid || z2.push({
        instanceLocation: o2,
        keyword: `$ref`,
        keywordLocation: l3,
        error: `A subschema had errors.`
      }, ...u3.errors), n2 === `4` || n2 === `7`) return {
        valid: z2.length === 0,
        errors: z2
      };
    }
    if (Array.isArray(m2)) {
      let t3 = m2.length, n3 = false;
      for (let r3 = 0; r3 < t3; r3++) if (u2 === m2[r3] || m2[r3] === `integer` && u2 === `number` && e2 % 1 == 0 && e2 === e2) {
        n3 = true;
        break;
      }
      n3 || z2.push({
        instanceLocation: o2,
        keyword: `type`,
        keywordLocation: `${s2}/type`,
        error: `Instance type "${u2}" is invalid. Expected "${m2.join(`", "`)}".`
      });
    } else m2 === `integer` ? (u2 !== `number` || e2 % 1 || e2 !== e2) && z2.push({
      instanceLocation: o2,
      keyword: `type`,
      keywordLocation: `${s2}/type`,
      error: `Instance type "${u2}" is invalid. Expected "${m2}".`
    }) : m2 !== void 0 && u2 !== m2 && z2.push({
      instanceLocation: o2,
      keyword: `type`,
      keywordLocation: `${s2}/type`,
      error: `Instance type "${u2}" is invalid. Expected "${m2}".`
    });
    if (h2 !== void 0 && (u2 === `object` || u2 === `array` ? li(e2, h2) || z2.push({
      instanceLocation: o2,
      keyword: `const`,
      keywordLocation: `${s2}/const`,
      error: `Instance does not match ${JSON.stringify(h2)}.`
    }) : e2 !== h2 && z2.push({
      instanceLocation: o2,
      keyword: `const`,
      keywordLocation: `${s2}/const`,
      error: `Instance does not match ${JSON.stringify(h2)}.`
    })), g2 !== void 0 && (u2 === `object` || u2 === `array` ? g2.some((t3) => li(e2, t3)) || z2.push({
      instanceLocation: o2,
      keyword: `enum`,
      keywordLocation: `${s2}/enum`,
      error: `Instance does not match any of ${JSON.stringify(g2)}.`
    }) : g2.some((t3) => e2 === t3) || z2.push({
      instanceLocation: o2,
      keyword: `enum`,
      keywordLocation: `${s2}/enum`,
      error: `Instance does not match any of ${JSON.stringify(g2)}.`
    })), v2 !== void 0) {
      let t3 = `${s2}/not`;
      B(e2, v2, n2, r2, i2, a2, o2, t3).valid && z2.push({
        instanceLocation: o2,
        keyword: `not`,
        keywordLocation: t3,
        error: `Instance matched "not" schema.`
      });
    }
    let _e2 = [];
    if (y2 !== void 0) {
      let t3 = `${s2}/anyOf`, l3 = z2.length, u3 = false;
      for (let s3 = 0; s3 < y2.length; s3++) {
        let l4 = y2[s3], d3 = Object.create(c2), f3 = B(e2, l4, n2, r2, i2, p2 === true ? a2 : null, o2, `${t3}/${s3}`, d3);
        z2.push(...f3.errors), u3 ||= f3.valid, f3.valid && _e2.push(d3);
      }
      u3 ? z2.length = l3 : z2.splice(l3, 0, {
        instanceLocation: o2,
        keyword: `anyOf`,
        keywordLocation: t3,
        error: `Instance does not match any subschemas.`
      });
    }
    if (b2 !== void 0) {
      let t3 = `${s2}/allOf`, l3 = z2.length, u3 = true;
      for (let s3 = 0; s3 < b2.length; s3++) {
        let l4 = b2[s3], d3 = Object.create(c2), f3 = B(e2, l4, n2, r2, i2, p2 === true ? a2 : null, o2, `${t3}/${s3}`, d3);
        z2.push(...f3.errors), u3 &&= f3.valid, f3.valid && _e2.push(d3);
      }
      u3 ? z2.length = l3 : z2.splice(l3, 0, {
        instanceLocation: o2,
        keyword: `allOf`,
        keywordLocation: t3,
        error: `Instance does not match every subschema.`
      });
    }
    if (ee2 !== void 0) {
      let t3 = `${s2}/oneOf`, l3 = z2.length, u3 = ee2.filter((s3, l4) => {
        let u4 = Object.create(c2), d3 = B(e2, s3, n2, r2, i2, p2 === true ? a2 : null, o2, `${t3}/${l4}`, u4);
        return z2.push(...d3.errors), d3.valid && _e2.push(u4), d3.valid;
      }).length;
      u3 === 1 ? z2.length = l3 : z2.splice(l3, 0, {
        instanceLocation: o2,
        keyword: `oneOf`,
        keywordLocation: t3,
        error: `Instance does not match exactly one subschema (${u3} matches).`
      });
    }
    if ((u2 === `object` || u2 === `array`) && Object.assign(c2, ..._e2), x2 !== void 0) {
      let t3 = `${s2}/if`;
      if (B(e2, x2, n2, r2, i2, a2, o2, t3, c2).valid) {
        if (S2 !== void 0) {
          let l3 = B(e2, S2, n2, r2, i2, a2, o2, `${s2}/then`, c2);
          l3.valid || z2.push({
            instanceLocation: o2,
            keyword: `if`,
            keywordLocation: t3,
            error: `Instance does not match "then" schema.`
          }, ...l3.errors);
        }
      } else if (C2 !== void 0) {
        let l3 = B(e2, C2, n2, r2, i2, a2, o2, `${s2}/else`, c2);
        l3.valid || z2.push({
          instanceLocation: o2,
          keyword: `if`,
          keywordLocation: t3,
          error: `Instance does not match "else" schema.`
        }, ...l3.errors);
      }
    }
    if (u2 === `object`) {
      if (_2 !== void 0) for (let t4 of _2) t4 in e2 || z2.push({
        instanceLocation: o2,
        keyword: `required`,
        keywordLocation: `${s2}/required`,
        error: `Instance does not have required property "${t4}".`
      });
      let t3 = Object.keys(e2);
      if (k2 !== void 0 && t3.length < k2 && z2.push({
        instanceLocation: o2,
        keyword: `minProperties`,
        keywordLocation: `${s2}/minProperties`,
        error: `Instance does not have at least ${k2} properties.`
      }), A2 !== void 0 && t3.length > A2 && z2.push({
        instanceLocation: o2,
        keyword: `maxProperties`,
        keywordLocation: `${s2}/maxProperties`,
        error: `Instance does not have at least ${A2} properties.`
      }), j2 !== void 0) {
        let t4 = `${s2}/propertyNames`;
        for (let s3 in e2) {
          let e3 = `${o2}/${ui(s3)}`, c3 = B(s3, j2, n2, r2, i2, a2, e3, t4);
          c3.valid || z2.push({
            instanceLocation: o2,
            keyword: `propertyNames`,
            keywordLocation: t4,
            error: `Property name "${s3}" does not match schema.`
          }, ...c3.errors);
        }
      }
      if (M2 !== void 0) {
        let t4 = `${s2}/dependantRequired`;
        for (let n3 in M2) if (n3 in e2) {
          let r3 = M2[n3];
          for (let i3 of r3) i3 in e2 || z2.push({
            instanceLocation: o2,
            keyword: `dependentRequired`,
            keywordLocation: t4,
            error: `Instance has "${n3}" but does not have "${i3}".`
          });
        }
      }
      if (N2 !== void 0) for (let t4 in N2) {
        let l4 = `${s2}/dependentSchemas`;
        if (t4 in e2) {
          let s3 = B(e2, N2[t4], n2, r2, i2, a2, o2, `${l4}/${ui(t4)}`, c2);
          s3.valid || z2.push({
            instanceLocation: o2,
            keyword: `dependentSchemas`,
            keywordLocation: l4,
            error: `Instance has "${t4}" but does not match dependant schema.`
          }, ...s3.errors);
        }
      }
      if (P2 !== void 0) {
        let t4 = `${s2}/dependencies`;
        for (let s3 in P2) if (s3 in e2) {
          let c3 = P2[s3];
          if (Array.isArray(c3)) for (let n3 of c3) n3 in e2 || z2.push({
            instanceLocation: o2,
            keyword: `dependencies`,
            keywordLocation: t4,
            error: `Instance has "${s3}" but does not have "${n3}".`
          });
          else {
            let l4 = B(e2, c3, n2, r2, i2, a2, o2, `${t4}/${ui(s3)}`);
            l4.valid || z2.push({
              instanceLocation: o2,
              keyword: `dependencies`,
              keywordLocation: t4,
              error: `Instance has "${s3}" but does not match dependant schema.`
            }, ...l4.errors);
          }
        }
      }
      let l3 = /* @__PURE__ */ Object.create(null), u3 = false;
      if (T2 !== void 0) {
        let t4 = `${s2}/properties`;
        for (let s3 in T2) {
          if (!(s3 in e2)) continue;
          let d3 = `${o2}/${ui(s3)}`, f3 = B(e2[s3], T2[s3], n2, r2, i2, a2, d3, `${t4}/${ui(s3)}`);
          if (f3.valid) c2[s3] = l3[s3] = true;
          else if (u3 = i2, z2.push({
            instanceLocation: o2,
            keyword: `properties`,
            keywordLocation: t4,
            error: `Property "${s3}" does not match schema.`
          }, ...f3.errors), u3) break;
        }
      }
      if (!u3 && E2 !== void 0) {
        let t4 = `${s2}/patternProperties`;
        for (let s3 in E2) {
          let d3 = new RegExp(s3, `u`), f3 = E2[s3];
          for (let p3 in e2) {
            if (!d3.test(p3)) continue;
            let m3 = `${o2}/${ui(p3)}`, h3 = B(e2[p3], f3, n2, r2, i2, a2, m3, `${t4}/${ui(s3)}`);
            h3.valid ? c2[p3] = l3[p3] = true : (u3 = i2, z2.push({
              instanceLocation: o2,
              keyword: `patternProperties`,
              keywordLocation: t4,
              error: `Property "${p3}" matches pattern "${s3}" but does not match associated schema.`
            }, ...h3.errors));
          }
        }
      }
      if (!u3 && D2 !== void 0) {
        let t4 = `${s2}/additionalProperties`;
        for (let s3 in e2) {
          if (l3[s3]) continue;
          let d3 = `${o2}/${ui(s3)}`, f3 = B(e2[s3], D2, n2, r2, i2, a2, d3, t4);
          f3.valid ? c2[s3] = true : (u3 = i2, z2.push({
            instanceLocation: o2,
            keyword: `additionalProperties`,
            keywordLocation: t4,
            error: `Property "${s3}" does not match additional properties schema.`
          }, ...f3.errors));
        }
      } else if (!u3 && O2 !== void 0) {
        let t4 = `${s2}/unevaluatedProperties`;
        for (let s3 in e2) if (!c2[s3]) {
          let l4 = `${o2}/${ui(s3)}`, u4 = B(e2[s3], O2, n2, r2, i2, a2, l4, t4);
          u4.valid ? c2[s3] = true : z2.push({
            instanceLocation: o2,
            keyword: `unevaluatedProperties`,
            keywordLocation: t4,
            error: `Property "${s3}" does not match unevaluated properties schema.`
          }, ...u4.errors);
        }
      }
    } else if (u2 === `array`) {
      oe2 !== void 0 && e2.length > oe2 && z2.push({
        instanceLocation: o2,
        keyword: `maxItems`,
        keywordLocation: `${s2}/maxItems`,
        error: `Array has too many items (${e2.length} > ${oe2}).`
      }), ae2 !== void 0 && e2.length < ae2 && z2.push({
        instanceLocation: o2,
        keyword: `minItems`,
        keywordLocation: `${s2}/minItems`,
        error: `Array has too few items (${e2.length} < ${ae2}).`
      });
      let t3 = e2.length, l3 = 0, u3 = false;
      if (F2 !== void 0) {
        let d3 = `${s2}/prefixItems`, f3 = Math.min(F2.length, t3);
        for (; l3 < f3; l3++) {
          let t4 = B(e2[l3], F2[l3], n2, r2, i2, a2, `${o2}/${l3}`, `${d3}/${l3}`);
          if (c2[l3] = true, !t4.valid && (u3 = i2, z2.push({
            instanceLocation: o2,
            keyword: `prefixItems`,
            keywordLocation: d3,
            error: `Items did not match schema.`
          }, ...t4.errors), u3)) break;
        }
      }
      if (I2 !== void 0) {
        let d3 = `${s2}/items`;
        if (Array.isArray(I2)) {
          let s3 = Math.min(I2.length, t3);
          for (; l3 < s3; l3++) {
            let t4 = B(e2[l3], I2[l3], n2, r2, i2, a2, `${o2}/${l3}`, `${d3}/${l3}`);
            if (c2[l3] = true, !t4.valid && (u3 = i2, z2.push({
              instanceLocation: o2,
              keyword: `items`,
              keywordLocation: d3,
              error: `Items did not match schema.`
            }, ...t4.errors), u3)) break;
          }
        } else for (; l3 < t3; l3++) {
          let t4 = B(e2[l3], I2, n2, r2, i2, a2, `${o2}/${l3}`, d3);
          if (c2[l3] = true, !t4.valid && (u3 = i2, z2.push({
            instanceLocation: o2,
            keyword: `items`,
            keywordLocation: d3,
            error: `Items did not match schema.`
          }, ...t4.errors), u3)) break;
        }
        if (!u3 && L2 !== void 0) {
          let d4 = `${s2}/additionalItems`;
          for (; l3 < t3; l3++) {
            let t4 = B(e2[l3], L2, n2, r2, i2, a2, `${o2}/${l3}`, d4);
            c2[l3] = true, t4.valid || (u3 = i2, z2.push({
              instanceLocation: o2,
              keyword: `additionalItems`,
              keywordLocation: d4,
              error: `Items did not match additional items schema.`
            }, ...t4.errors));
          }
        }
      }
      if (ne2 !== void 0) {
        if (t3 === 0 && re2 === void 0) z2.push({
          instanceLocation: o2,
          keyword: `contains`,
          keywordLocation: `${s2}/contains`,
          error: `Array is empty. It must contain at least one item matching the schema.`
        });
        else if (re2 !== void 0 && t3 < re2) z2.push({
          instanceLocation: o2,
          keyword: `minContains`,
          keywordLocation: `${s2}/minContains`,
          error: `Array has less items (${t3}) than minContains (${re2}).`
        });
        else {
          let l4 = `${s2}/contains`, u4 = z2.length, d3 = 0;
          for (let s3 = 0; s3 < t3; s3++) {
            let t4 = B(e2[s3], ne2, n2, r2, i2, a2, `${o2}/${s3}`, l4);
            t4.valid ? (c2[s3] = true, d3++) : z2.push(...t4.errors);
          }
          d3 >= (re2 || 0) && (z2.length = u4), re2 === void 0 && ie2 === void 0 && d3 === 0 ? z2.splice(u4, 0, {
            instanceLocation: o2,
            keyword: `contains`,
            keywordLocation: l4,
            error: `Array does not contain item matching schema.`
          }) : re2 !== void 0 && d3 < re2 ? z2.push({
            instanceLocation: o2,
            keyword: `minContains`,
            keywordLocation: `${s2}/minContains`,
            error: `Array must contain at least ${re2} items matching schema. Only ${d3} items were found.`
          }) : ie2 !== void 0 && d3 > ie2 && z2.push({
            instanceLocation: o2,
            keyword: `maxContains`,
            keywordLocation: `${s2}/maxContains`,
            error: `Array may contain at most ${ie2} items matching schema. ${d3} items were found.`
          });
        }
      }
      if (!u3 && te2 !== void 0) {
        let u4 = `${s2}/unevaluatedItems`;
        for (; l3 < t3; l3++) {
          if (c2[l3]) continue;
          let t4 = B(e2[l3], te2, n2, r2, i2, a2, `${o2}/${l3}`, u4);
          c2[l3] = true, t4.valid || z2.push({
            instanceLocation: o2,
            keyword: `unevaluatedItems`,
            keywordLocation: u4,
            error: `Items did not match unevaluated items schema.`
          }, ...t4.errors);
        }
      }
      if (se2) for (let n3 = 0; n3 < t3; n3++) {
        let r3 = e2[n3], i3 = typeof r3 == `object` && !!r3;
        for (let a3 = 0; a3 < t3; a3++) {
          if (n3 === a3) continue;
          let t4 = e2[a3];
          (r3 === t4 || i3 && typeof t4 == `object` && t4 && li(r3, t4)) && (z2.push({
            instanceLocation: o2,
            keyword: `uniqueItems`,
            keywordLocation: `${s2}/uniqueItems`,
            error: `Duplicate items at indexes ${n3} and ${a3}.`
          }), n3 = 2 ** 53 - 1, a3 = 2 ** 53 - 1);
        }
      }
    } else if (u2 === `number`) {
      if (n2 === `4` ? (ce2 !== void 0 && (ue2 === true && e2 <= ce2 || e2 < ce2) && z2.push({
        instanceLocation: o2,
        keyword: `minimum`,
        keywordLocation: `${s2}/minimum`,
        error: `${e2} is less than ${ue2 ? `or equal to ` : ``} ${ce2}.`
      }), le2 !== void 0 && (de2 === true && e2 >= le2 || e2 > le2) && z2.push({
        instanceLocation: o2,
        keyword: `maximum`,
        keywordLocation: `${s2}/maximum`,
        error: `${e2} is greater than ${de2 ? `or equal to ` : ``} ${le2}.`
      })) : (ce2 !== void 0 && e2 < ce2 && z2.push({
        instanceLocation: o2,
        keyword: `minimum`,
        keywordLocation: `${s2}/minimum`,
        error: `${e2} is less than ${ce2}.`
      }), le2 !== void 0 && e2 > le2 && z2.push({
        instanceLocation: o2,
        keyword: `maximum`,
        keywordLocation: `${s2}/maximum`,
        error: `${e2} is greater than ${le2}.`
      }), ue2 !== void 0 && e2 <= ue2 && z2.push({
        instanceLocation: o2,
        keyword: `exclusiveMinimum`,
        keywordLocation: `${s2}/exclusiveMinimum`,
        error: `${e2} is less than ${ue2}.`
      }), de2 !== void 0 && e2 >= de2 && z2.push({
        instanceLocation: o2,
        keyword: `exclusiveMaximum`,
        keywordLocation: `${s2}/exclusiveMaximum`,
        error: `${e2} is greater than or equal to ${de2}.`
      })), fe2 !== void 0) {
        let t3 = e2 % fe2;
        Math.abs(0 - t3) >= 11920929e-14 && Math.abs(fe2 - t3) >= 11920929e-14 && z2.push({
          instanceLocation: o2,
          keyword: `multipleOf`,
          keywordLocation: `${s2}/multipleOf`,
          error: `${e2} is not a multiple of ${fe2}.`
        });
      }
    } else if (u2 === `string`) {
      let t3 = pe2 === void 0 && R2 === void 0 ? 0 : Wi(e2);
      pe2 !== void 0 && t3 < pe2 && z2.push({
        instanceLocation: o2,
        keyword: `minLength`,
        keywordLocation: `${s2}/minLength`,
        error: `String is too short (${t3} < ${pe2}).`
      }), R2 !== void 0 && t3 > R2 && z2.push({
        instanceLocation: o2,
        keyword: `maxLength`,
        keywordLocation: `${s2}/maxLength`,
        error: `String is too long (${t3} > ${R2}).`
      }), me2 !== void 0 && !new RegExp(me2, `u`).test(e2) && z2.push({
        instanceLocation: o2,
        keyword: `pattern`,
        keywordLocation: `${s2}/pattern`,
        error: `String does not match pattern.`
      }), w2 !== void 0 && Ni[w2] && !Ni[w2](e2) && z2.push({
        instanceLocation: o2,
        keyword: `format`,
        keywordLocation: `${s2}/format`,
        error: `String does not match format "${w2}".`
      });
    }
    return {
      valid: z2.length === 0,
      errors: z2
    };
  }
  var Gi = class {
    schema;
    draft;
    shortCircuit;
    lookup;
    constructor(e2, t2 = `2019-09`, n2 = true) {
      this.schema = e2, this.draft = t2, this.shortCircuit = n2, this.lookup = gi(e2);
    }
    validate(e2) {
      return B(e2, this.schema, this.draft, this.lookup, this.shortCircuit);
    }
    addSchema(e2, t2) {
      t2 && (e2 = {
        ...e2,
        $id: t2
      }), gi(e2, this.lookup);
    }
  }, Ki = /* @__PURE__ */ new WeakMap();
  function qi(e2, t2) {
    if (typeof e2 != `object` || !e2) return {
      valid: false,
      violations: [
        {
          instanceLocation: ``,
          error: `no schema to validate against`
        }
      ]
    };
    let n2 = Ki.get(e2);
    n2 || (n2 = new Gi(e2, `2020-12`, false), Ki.set(e2, n2));
    let r2 = n2.validate(t2);
    return r2.valid ? {
      valid: true
    } : {
      valid: false,
      violations: r2.errors.map((e3) => ({
        instanceLocation: e3.instanceLocation,
        error: e3.error
      }))
    };
  }
  function Ji(e2) {
    return e2.map((e3) => `${e3.instanceLocation || `(root)`}: ${e3.error}`).join(`; `);
  }
  var Yi = `vtc/step-up/v1\0`, Xi = `vta/task-consent/v1\0`, Zi = [
    18,
    32
  ];
  function Qi(e2) {
    let t2 = new Uint8Array(8);
    return new DataView(t2.buffer).setBigUint64(0, BigInt(e2)), t2;
  }
  function $i(e2) {
    let t2 = e2.reduce((e3, t3) => e3 + t3.length, 0), n2 = new Uint8Array(t2), r2 = 0;
    for (let t3 of e2) n2.set(t3, r2), r2 += t3.length;
    return n2;
  }
  async function ea(e2, t2, n2, r2) {
    let i2 = new TextEncoder(), a2 = i2.encode(t2), o2 = i2.encode(ut(n2)), s2 = $i([
      i2.encode(e2),
      Qi(a2.length),
      a2,
      Qi(o2.length),
      o2,
      ...r2 === void 0 ? [] : [
        i2.encode(r2)
      ]
    ]), c2 = new Uint8Array(await crypto.subtle.digest(`SHA-256`, s2));
    return `z` + dt(Uint8Array.from([
      ...Zi,
      ...c2
    ]));
  }
  function ta(e2, t2, n2) {
    return ea(Yi, e2, t2, n2);
  }
  function na(e2, t2, n2) {
    return ea(Xi, e2, t2, n2);
  }
  var ra = `https://trusttasks.org/spec/auth/step-up/approver/attest/0.1`, ia = {
    malformed: `step-up-approver/malformed-request`,
    notOffered: `step-up-approver/not-offered`,
    boundToMismatch: `step-up-approver/bound-to-mismatch`,
    notApproverSigned: `step-up-approver/approver-signed-not-accepted`,
    subjectIsApprover: `step-up-approver/subject-is-approver`,
    notEnrolled: `step-up-approver/not-enrolled`
  }, aa = class extends Error {
    code;
    constructor(e2, t2) {
      super(t2), this.code = e2, this.name = `ApproverRefusalError`;
    }
  }, oa = (e2, t2 = 2048) => typeof e2 == `string` && e2.startsWith(`did:`) && e2.length >= 5 && e2.length <= t2, sa = (e2) => typeof e2 == `string` && e2.length >= 16 && e2.length <= 512, ca = (e2) => typeof e2 == `string` && e2.length >= 1 && e2.length <= 256;
  function la(e2) {
    let t2 = (e3) => {
      throw new aa(ia.malformed, `approver statement: ${e3}`);
    };
    return e2.purpose !== `stepUp` && e2.purpose !== `decision` && e2.purpose !== `enrol` && t2(`purpose must be stepUp, decision or enrol`), oa(e2.subject) || t2(`subject must be a DID`), oa(e2.audience) || t2(`audience must be a DID`), sa(e2.challenge) || t2(`challenge must be 16\u2013512 characters`), ca(e2.boundTo) || t2(`boundTo must be 1\u2013256 characters`), {
      purpose: e2.purpose,
      subject: e2.subject,
      audience: e2.audience,
      challenge: e2.challenge,
      boundTo: e2.boundTo
    };
  }
  async function ua(e2) {
    let { request: t2, operation: n2, audience: r2, approverDid: i2 } = e2, a2 = (e3) => {
      throw new aa(ia.malformed, `step-up request: ${e3}`);
    };
    (!t2 || typeof t2 != `object` || Array.isArray(t2)) && a2(`not an object`);
    let o2 = t2;
    oa(o2.subject) || a2(`subject must be a DID`), sa(o2.challenge) || a2(`challenge must be 16\u2013512 characters`), typeof o2.reason != `string` && a2(`reason must be a string`), ca(o2.boundTo) || a2(`boundTo is absent \u2014 it is not bound to one operation`), oa(r2) || a2(`audience must be a DID`), (!n2 || typeof n2 != `object` || Array.isArray(n2)) && a2(`operation must be {type, payload}`);
    let s2 = n2;
    if ((typeof s2.type != `string` || s2.type === ``) && a2(`operation.type must be a type URI`), (!(`payload` in s2) || s2.payload === void 0) && a2(`operation.payload is absent`), !Array.isArray(o2.accepts) || !o2.accepts.includes(`approverSigned`)) throw new aa(ia.notApproverSigned, `this step-up does not accept an approver's statement`);
    if (!(Array.isArray(o2.approvers) ? o2.approvers : []).includes(i2)) throw new aa(ia.notOffered, `this wallet's approver for ${r2} (${i2}) is not one the community has bound to this subject; enrol it first`);
    if (i2 === o2.subject) throw new aa(ia.subjectIsApprover, `the approver cannot be the subject it approves for`);
    if (await ta(s2.type, s2.payload, o2.challenge) !== o2.boundTo) throw new aa(ia.boundToMismatch, `the step-up's boundTo is not the digest of the operation shown; refusing to sign`);
    return la({
      purpose: `stepUp`,
      subject: o2.subject,
      audience: r2,
      challenge: o2.challenge,
      boundTo: o2.boundTo
    });
  }
  async function da(e2, t2, n2 = /* @__PURE__ */ new Date()) {
    let r2 = la(e2);
    if (t2.did === r2.subject) throw new aa(ia.subjectIsApprover, `the approver cannot be the subject it attests for`);
    let i2 = {
      id: `urn:uuid:${globalThis.crypto.randomUUID()}`,
      type: ra,
      issuer: t2.did,
      recipient: r2.audience,
      issuedAt: n2.toISOString(),
      payload: {
        ...r2
      }
    };
    return u({
      envelope: i2,
      signing: t2,
      proofPurpose: `authentication`
    });
  }
  async function fa(e2) {
    let { subject: t2, action: n2, decision: r2, audience: i2, approverDid: a2 } = e2, o2 = (e3) => {
      throw new aa(ia.malformed, `decision: ${e3}`);
    };
    oa(t2) || o2(`subject must be the administrator's DID`), oa(i2) || o2(`audience must be a DID`), (!n2 || typeof n2 != `object` || Array.isArray(n2)) && o2(`action must be {type, payload}`);
    let s2 = n2;
    (typeof s2.type != `string` || s2.type === ``) && o2(`action.type must be a type URI`), (!(`payload` in s2) || s2.payload === void 0) && o2(`action.payload is absent`), s2.actionId !== void 0 && (typeof s2.actionId != `string` || s2.actionId === ``) && o2(`action.actionId must be a non-empty string`), (!r2 || typeof r2 != `object` || Array.isArray(r2)) && o2(`decision must be {challenge, payloadDigest, decision}`);
    let c2 = r2;
    if (c2.decision !== `approve` && c2.decision !== `deny` && o2(`decision must be approve or deny`), sa(c2.challenge) || o2(`challenge must be 16\u2013512 characters`), ca(c2.payloadDigest) || o2(`payloadDigest must be 1\u2013256 characters`), a2 === t2) throw new aa(ia.subjectIsApprover, `the approver cannot be the administrator it vouches for`);
    if (await na(s2.type, s2.payload, c2.challenge) !== c2.payloadDigest) throw new aa(ia.boundToMismatch, `the decision's payloadDigest is not the digest of the action shown; refusing to sign`);
    return la({
      purpose: `decision`,
      subject: t2,
      audience: i2,
      challenge: c2.challenge,
      boundTo: c2.payloadDigest
    });
  }
  var pa = `pnm/step-up-approver/v1/`, ma = `${pa}seal`, ha = `${pa}aud/`, ga = `pnm/approver-identity/v1/`, _a = `pnm/step-up-approver/seal/v1`;
  function va(e2) {
    return ha + e2;
  }
  var ya = `step-up-approver/setup-required`, ba = class extends Error {
    code = ya;
    constructor() {
      super(`this wallet has no step-up approver key yet; approving the setup prompt creates one`), this.name = `StepUpApproverSetupRequiredError`;
    }
  };
  function xa(e2) {
    let t2 = ke(De.ED25519_PUB, et.getPublicKey(e2)), n2 = `did:key:${t2}`;
    return {
      did: n2,
      signingKid: `${n2}#${t2}`
    };
  }
  async function Sa(e2, t2, n2, r2, i2) {
    let a2 = new TextEncoder().encode(`${_a}\0${r2}\0${i2}`), o2 = await crypto.subtle.importKey(`raw`, e2, `HKDF`, false, [
      `deriveKey`
    ]), s2 = new Uint8Array(t2.length + n2.length);
    return s2.set(t2, 0), s2.set(n2, t2.length), {
      key: await crypto.subtle.deriveKey({
        name: `HKDF`,
        hash: `SHA-256`,
        salt: s2,
        info: a2
      }, o2, {
        name: `AES-GCM`,
        length: 256
      }, false, [
        `encrypt`,
        `decrypt`
      ]),
      aad: a2
    };
  }
  async function Ca(e2, t2, n2, r2) {
    let i2 = $e.utils.randomSecretKey(), a2 = $e.getPublicKey(i2), o2 = $e.getSharedSecret(i2, t2);
    i2.fill(0);
    let { key: s2, aad: c2 } = await Sa(o2, a2, t2, n2, r2);
    o2.fill(0);
    let l2 = crypto.getRandomValues(new Uint8Array(12)), u2 = new Uint8Array(await crypto.subtle.encrypt({
      name: `AES-GCM`,
      iv: l2,
      additionalData: c2
    }, s2, e2));
    return {
      ephemeralPublicB64u: Ee(a2),
      ivB64u: Ee(l2),
      ciphertextB64u: Ee(u2)
    };
  }
  async function wa(e2, t2, n2, r2) {
    let i2 = Ke(e2.ephemeralPublicB64u), a2 = $e.getPublicKey(t2), o2 = $e.getSharedSecret(t2, i2), { key: s2, aad: c2 } = await Sa(o2, i2, a2, n2, r2);
    return o2.fill(0), new Uint8Array(await crypto.subtle.decrypt({
      name: `AES-GCM`,
      iv: Ke(e2.ivB64u),
      additionalData: c2
    }, s2, Ke(e2.ciphertextB64u)));
  }
  function Ta(e2) {
    if (!e2 || e2.algorithm !== `webauthn-prf-aes-gcm/approver`) throw Error(`a step-up approver key needs the approver PRF wrap`);
    return e2;
  }
  async function Ea(e2, t2) {
    let n2 = $e.utils.randomSecretKey(), r2 = await bt(n2, t2), i2 = {
      publicKeyB64u: Ee($e.getPublicKey(n2)),
      wrappedSecret: r2,
      schemaVersion: 1
    };
    return await e2.put(ma, i2), n2.fill(0), Ke(i2.publicKeyB64u);
  }
  async function Da(e2) {
    let t2 = /* @__PURE__ */ new Set();
    for (let n2 of [
      ha,
      ga
    ]) for (let r2 of await e2.keys(n2)) {
      let n3 = await e2.get(r2);
      typeof n3?.did == `string` && t2.add(n3.did);
    }
    return t2;
  }
  async function Oa(e2, t2) {
    return (await e2.get(va(t2)))?.did ?? null;
  }
  async function ka(e2, t2, n2 = {}) {
    if (typeof t2 != `string` || !t2.startsWith(`did:`)) throw Error(`a step-up approver's audience must be a DID`);
    let r2 = await Oa(e2, t2);
    if (r2) return r2;
    let i2 = await e2.get(ma), a2;
    if (i2) a2 = Ke(i2.publicKeyB64u);
    else if (n2.secretWrap) a2 = await Ea(e2, Ta(n2.secretWrap));
    else throw new ba();
    let o2 = et.utils.randomSecretKey();
    try {
      let n3 = xa(o2);
      if ((await Da(e2)).has(n3.did)) throw Error(`refusing to reuse an approver DID already on file`);
      let r3 = {
        ...n3,
        audience: t2,
        sealed: await Ca(o2, a2, t2, n3.did),
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        schemaVersion: 1
      };
      return await e2.put(va(t2), r3), n3.did;
    } finally {
      o2.fill(0);
    }
  }
  async function Aa(e2, t2, n2) {
    let r2 = await e2.get(va(t2));
    if (!r2) return null;
    if (r2.audience !== t2) throw Error(`step-up approver record is misfiled`);
    let i2 = await e2.get(ma);
    if (!i2) throw Error(`the step-up approver sealing key is missing`);
    if (i2.wrappedSecret.algorithm !== `webauthn-prf-aes-gcm/approver`) throw Error(`the step-up approver sealing key is not PRF-wrapped`);
    let a2 = await Pt(i2.wrappedSecret, Ta(n2));
    try {
      let e3 = await wa(r2.sealed, a2, t2, r2.did), n3 = xa(e3);
      if (n3.did !== r2.did || n3.signingKid !== r2.signingKid) throw e3.fill(0), Error(`step-up approver key does not match its DID`);
      return {
        did: r2.did,
        kid: r2.signingKid,
        privateKey: e3,
        publicKey: et.getPublicKey(e3)
      };
    } finally {
      a2.fill(0);
    }
  }
  async function ja(e2, t2) {
    let n2 = await Oa(e2, t2.audience);
    if (!n2) throw Error(`this wallet has no step-up approver for ${t2.audience}; enrol one first`);
    let r2 = await ua({
      ...t2,
      approverDid: n2
    }), i2 = await Aa(e2, t2.audience, t2.secretWrap);
    if (!i2) throw Error(`step-up approver vanished before signing`);
    try {
      return {
        statement: await da(r2, i2),
        approverDid: n2
      };
    } finally {
      i2.privateKey.fill(0);
    }
  }
  async function Ma(e2, t2) {
    let n2 = await Oa(e2, t2.audience);
    if (!n2) throw new aa(ia.notEnrolled, `this wallet has no step-up approver for ${t2.audience}; enrol one first`);
    let r2 = await fa({
      ...t2,
      approverDid: n2
    }), i2 = await Aa(e2, t2.audience, t2.secretWrap);
    if (!i2) throw Error(`step-up approver vanished before signing`);
    try {
      return {
        statement: await da(r2, i2),
        approverDid: n2
      };
    } finally {
      i2.privateKey.fill(0);
    }
  }
  async function Na(e2, t2) {
    let n2 = la({
      purpose: `enrol`,
      subject: t2.subject,
      audience: t2.audience,
      challenge: t2.challenge,
      boundTo: t2.boundTo
    }), r2 = await ka(e2, t2.audience, {
      secretWrap: t2.secretWrap
    }), i2 = await Aa(e2, t2.audience, t2.secretWrap);
    if (!i2) throw Error(`step-up approver vanished before signing`);
    try {
      return {
        statement: await da(n2, i2),
        approverDid: r2
      };
    } finally {
      i2.privateKey.fill(0);
    }
  }
  var Pa = `pnm/sign-in-uv-key/v1/`;
  function Fa(e2) {
    return Pa + e2;
  }
  function Ia(e2) {
    let t2 = et.getPublicKey(e2), n2 = ke(De.ED25519_PUB, t2), r2 = `did:key:${n2}`;
    return {
      did: r2,
      kid: `${r2}#${n2}`,
      privateKey: e2,
      publicKey: t2
    };
  }
  async function La(e2, t2) {
    let n2 = new ct(t2.prfOutput), r2 = await e2.get(Fa(t2.vtaDid));
    if (r2) {
      if (r2.wrappedSecret.algorithm !== `webauthn-prf-aes-gcm/sign-in-uv`) throw Error(`the sign-in approval key is not sealed under the wallet's passkey`);
      let e3 = Ia(await Pt(r2.wrappedSecret, n2));
      if (e3.did !== r2.did) throw Error(`the sign-in approval key does not match its record`);
      return {
        signing: e3,
        minted: false
      };
    }
    let i2 = et.utils.randomSecretKey(), a2 = Ia(i2), o2 = {
      did: a2.did,
      signingKid: a2.kid,
      wrappedSecret: await bt(i2, n2),
      vtaDid: t2.vtaDid,
      schemaVersion: 1
    };
    return await e2.put(Fa(t2.vtaDid), o2), {
      signing: a2,
      minted: true
    };
  }
  var Ra = `pnm/uv-pin/v1/`;
  function za(e2) {
    return Ra + e2;
  }
  async function Ba(e2, t2) {
    let n2 = await e2.get(za(t2));
    return n2 && typeof n2.salt == `string` && typeof n2.iterations == `number` ? n2 : void 0;
  }
  async function Va(e2, t2, n2) {
    await e2.put(za(t2), {
      salt: n2.salt,
      iterations: n2.iterations
    });
  }
  async function Ha(e2, t2) {
    await e2.delete(za(t2));
  }
  function Ua(e2) {
    return JSON.stringify({
      type: d,
      document: e2
    });
  }
  function Wa(e2) {
    let t2;
    try {
      t2 = JSON.parse(e2);
    } catch (e3) {
      throw new _(`e.client.parse`, `tsp: payload is not JSON: ${e3.message}`);
    }
    if (typeof t2 != `object` || !t2) throw new _(`e.client.parse`, `tsp: payload is not an object`);
    let { type: n2, document: r2 } = t2;
    if (n2 !== `https://trusttasks.org/binding/tsp/0.1/envelope`) throw new _(`e.client.parse`, `tsp: payload is not a ${d} envelope (got ${JSON.stringify(n2)})`);
    if (typeof r2 != `object` || !r2) throw new _(`e.client.parse`, "tsp: envelope carries no `document`");
    return r2;
  }
  var Ga = 52, Ka = 53, qa = 56, Ja = 57, Ya = 58, Xa = 59, Za = 60, Qa = 61, $a = 62, eo = {
    major: 0,
    minor: 2
  };
  function to(e2) {
    let t2 = 0;
    for (let n2 = 0; n2 < e2.length; n2++) {
      let r2 = e2.charCodeAt(n2), i2;
      i2 = r2 >= 65 && r2 <= 90 ? r2 - 65 : r2 >= 97 && r2 <= 122 ? r2 - 97 + 26 : r2 >= 48 && r2 <= 57 ? r2 - 48 + 52 : r2 === 45 ? 62 : r2 === 95 ? 63 : 0, t2 = t2 << 6 | i2;
    }
    return t2 >>> 0;
  }
  function no(e2) {
    let t2 = to(e2);
    return new Uint8Array([
      t2 >>> 16 & 255,
      t2 >>> 8 & 255,
      t2 & 255
    ]);
  }
  var ro = (e2) => (1 << e2) - 1, V = (e2, t2) => e2 & ro(t2), io = (e2) => [
    e2 >>> 16 & 255,
    e2 >>> 8 & 255,
    e2 & 255
  ], ao = (e2) => e2 + (3 - e2 % 3) % 3;
  function oo(e2, t2) {
    if (!(t2 + 3 > e2.length)) return (e2[t2] << 16 | e2[t2 + 1] << 8 | e2[t2 + 2]) >>> 0;
  }
  var so = to(`B`), co = to(`B`), lo = to(`B`), uo = to(`G`), fo = to(`F`), po = to(`C`), mo = to(`X`), ho = to(`A`), go = to(`I`), _o = to(`E`), vo = to(`Z`), yo = to(`J`), bo = to(`A`), xo = to(`C`), So = to(`K`), Co = no(`XSCS`), wo = no(`XHOP`), To = no(`XRFI`), Eo = no(`XRFA`), Do = no(`XRFD`), Oo = no(`XCTL`), ko = no(`XPAD`), Ao = no(`YTSP`), jo = new TextEncoder().encode(`YTSP-`);
  function Mo(e2) {
    let t2 = e2[0];
    return t2 === 248 || t2 === 251;
  }
  function No(e2, t2, n2) {
    let r2 = ao(t2.length + 1) - t2.length, i2;
    i2 = r2 === 1 ? V(e2, 6) << 18 : r2 === 2 ? Ga << 18 | V(e2, 6) << 12 : Ka << 18 | V(e2, 18);
    let a2 = io(i2);
    for (let e3 = 0; e3 < r2; e3++) n2.push(a2[e3]);
    for (let e3 = 0; e3 < t2.length; e3++) n2.push(t2[e3]);
  }
  function Po(e2, t2, n2) {
    let r2 = ao(t2.length), i2 = r2 - t2.length, a2 = qa + i2, o2 = r2 / 3;
    if (o2 < 4096 && e2 < 64) {
      let t3 = V(a2, 6) << 18 | V(e2, 6) << 12 | V(o2, 12);
      for (let e3 of io(t3)) n2.push(e3);
    } else {
      let t3 = V(a2 + 3, 6) << 18 | V(e2, 18);
      for (let e3 of io(t3)) n2.push(e3);
      for (let e3 of io(V(o2, 24))) n2.push(e3);
    }
    for (let e3 = 0; e3 < i2; e3++) n2.push(0);
    for (let e3 = 0; e3 < t2.length; e3++) n2.push(t2[e3]);
  }
  function Fo(e2, t2, n2) {
    if (t2 < 4096) {
      let r2 = $a << 18 | V(e2, 6) << 12 | V(t2, 12);
      for (let e3 of io(r2)) n2.push(e3);
    } else {
      let r2 = 16506880 | V(e2, 6) << 6 | V(t2 >>> 24, 6), i2 = V(t2, 24);
      for (let e3 of io(r2)) n2.push(e3);
      for (let e3 of io(i2)) n2.push(e3);
    }
  }
  function Io(e2) {
    for (let t2 of Ao) e2.push(t2);
    Fo(eo.major, eo.minor, e2);
  }
  function Lo(e2, t2, n2) {
    let r2 = io(V(lo, 6) << 18 | V(e2, 6) << 12);
    n2.push(r2[0], r2[1]);
    for (let e3 = 0; e3 < t2.length; e3++) n2.push(t2[e3]);
  }
  function Ro(e2, t2, n2, r2 = 62) {
    let i2 = oo(t2, n2.pos);
    if (i2 === void 0) return;
    let a2 = i2 & ro(12), o2 = ($a << 18 | V(e2, 6) << 12 | V(a2, 12)) >>> 0, s2 = ($a << 18 | r2 << 12 | V(e2, 6) << 6 | V(a2 & 63, 6)) >>> 0;
    if (i2 === o2) return n2.pos += 3, a2;
    if (i2 === s2) {
      let e3 = oo(t2, n2.pos + 3);
      return e3 === void 0 ? void 0 : (n2.pos += 6, ((a2 & 63) << 24 | e3) >>> 0);
    }
  }
  function zo(e2, t2, n2, r2) {
    let i2 = ao(t2 + 1), a2 = i2 - t2, o2;
    if (a2 === 1) o2 = V(e2, 6) << 18;
    else if (a2 === 2) o2 = Ga << 18 | V(e2, 6) << 12;
    else if (a2 === 3) o2 = Ka << 18 | V(e2, 18);
    else return;
    let s2 = io(o2);
    if (r2.pos + i2 > n2.length) return;
    for (let e3 = 0; e3 < a2; e3++) if (n2[r2.pos + e3] !== s2[e3]) return;
    let c2 = n2.slice(r2.pos + a2, r2.pos + i2);
    return r2.pos += i2, c2;
  }
  function Bo(e2, t2, n2) {
    let r2 = oo(t2, n2.pos);
    if (r2 === void 0) return;
    let i2 = r2 >>> 18, a2, o2;
    if (i2 === qa || i2 === Ja || i2 === Ya) o2 = r2 >>> 12 & ro(6), a2 = r2 & ro(12);
    else if (i2 === Xa || i2 === Za || i2 === Qa) {
      o2 = r2 & ro(18);
      let e3 = oo(t2, n2.pos + 3);
      if (e3 === void 0) return;
      a2 = e3;
    } else return;
    if (o2 !== e2 || a2 * 3 > 50331648) return;
    let s2 = i2 - qa, c2 = s2 + 3, l2 = ao(s2 + 1) + 3 * a2;
    if (n2.pos + l2 > t2.length) return;
    let u2 = {
      begin: c2 + n2.pos,
      end: l2 + n2.pos
    };
    return n2.pos = u2.end, u2;
  }
  function Vo(e2, t2, n2) {
    let r2 = Bo(e2, t2, n2);
    if (r2 !== void 0) return t2.slice(r2.begin, r2.end);
  }
  function Ho(e2, t2) {
    if (t2.pos + Ao.length > e2.length) return;
    for (let n3 = 0; n3 < Ao.length; n3++) if (e2[t2.pos + n3] !== Ao[n3]) return;
    let n2 = oo(e2, t2.pos + Ao.length);
    if (n2 !== void 0 && n2 >>> 18 === $a) return t2.pos += Ao.length + 3, {
      major: n2 >>> 12 & ro(6),
      minor: n2 & ro(12)
    };
  }
  function Uo(e2, t2, n2) {
    return Xe(e2), n2 === void 0 && (n2 = new Uint8Array(e2.outputLen)), Ne(e2, n2, t2);
  }
  var Wo = Uint8Array.of(0), Go = Uint8Array.of();
  function Ko(e2, t2, n2, r2 = 32, i2) {
    Xe(e2), Ze(r2, `length`), Qe(t2, void 0, `prk`);
    let a2 = e2.outputLen;
    if (t2.length < a2) throw Error(`"prk" must be at least HashLen octets`);
    if (r2 > 255 * a2) throw Error(`Length must be <= 255*HashLen`);
    let o2 = Math.ceil(r2 / a2);
    if (n2 === void 0 ? n2 = Go : Qe(n2, void 0, `info`), !o2) return i2 && Ye(t2), new Uint8Array();
    let s2 = i2 && o2 === 1 ? t2 : new Uint8Array(o2 * a2), { iHash: c2, oHash: l2 } = Ne.create(e2, t2), u2 = i2 ? t2 : new Uint8Array(a2), d2 = o2 > 1 ? i2?.iHash || e2.create() : void 0;
    for (let e3 = 0; e3 < o2 - 1; e3++) {
      Wo[0] = e3 + 1;
      let t3 = c2._cloneInto(d2);
      e3 && t3.update(u2), t3.update(n2).update(Wo).digestInto(u2), l2._cloneInto(d2).update(u2).digestInto(u2), s2.set(u2, a2 * e3);
    }
    if (Wo[0] = o2, o2 > 1 && c2.update(u2), c2.update(n2).update(Wo).digestInto(u2), l2.update(u2).digestInto(u2), s2.set(u2, a2 * (o2 - 1)), c2.destroy(), l2.destroy(), d2?.destroy(), u2 !== s2 && Ye(u2), Ye(Wo), r2 === s2.length) return s2;
    let f2 = s2.slice(0, r2);
    return Ye(s2), f2;
  }
  function qo(e2) {
    return e2 instanceof Uint8Array || ArrayBuffer.isView(e2) && e2.constructor.name === `Uint8Array` && `BYTES_PER_ELEMENT` in e2 && e2.BYTES_PER_ELEMENT === 1;
  }
  var Jo = (e2) => e2 ? `"${e2}" ` : ``;
  function Yo(e2, t2 = ``) {
    if (typeof e2 != `boolean`) throw TypeError(Jo(t2) + `expected boolean, got type=` + typeof e2);
    return e2;
  }
  function Xo(e2, t2 = ``) {
    if (typeof e2 != `number`) throw TypeError(Jo(t2) + `expected number, got ` + typeof e2);
    if (!Number.isSafeInteger(e2) || e2 < 0) throw RangeError(Jo(t2) + `expected integer >= 0, got ` + e2);
    return e2;
  }
  function Zo(e2, t2, n2 = ``) {
    if (qo(e2) && (t2 === void 0 || e2.length === t2)) return e2;
    t2 !== void 0 && Xo(t2, `length`);
    let r2 = qo(e2), i2 = t2 === void 0 ? `` : ` of length ${t2}`, a2 = r2 ? `length=${e2.length}` : `type=${typeof e2}`, o2 = Jo(n2) + `expected Uint8Array` + i2 + `, got ` + a2;
    throw r2 ? RangeError(o2) : TypeError(o2);
  }
  var Qo = (e2, t2) => {
    if (typeof e2 != `object` || !e2 || Array.isArray(e2)) throw TypeError(t2 === `object` ? `expected valid options object` : `"${t2}" expected object, got type=${typeof e2}`);
  };
  function $o(e2, t2 = true) {
    if (e2.destroyed) throw Error(`hash was destroyed`);
    if (t2 && e2.finished) throw Error(`digest() was already called`);
  }
  function es(e2, t2) {
    Zo(e2, void 0, `output`);
    let n2 = t2.outputLen;
    if (!(e2.length >= n2)) throw RangeError(`"output" expected length >= ` + n2);
  }
  function ts(e2) {
    return new Uint32Array(e2.buffer, e2.byteOffset, Math.floor(e2.byteLength / 4));
  }
  function ns(...e2) {
    for (let t2 = 0; t2 < e2.length; t2++) e2[t2].fill(0);
  }
  function rs(e2) {
    return new DataView(e2.buffer, e2.byteOffset, e2.byteLength);
  }
  var is = new Uint8Array(new Uint32Array([
    287454020
  ]).buffer)[0] === 68;
  function as(e2) {
    return e2 << 24 & 4278190080 | e2 << 8 & 16711680 | e2 >>> 8 & 65280 | e2 >>> 24 & 255;
  }
  function os(e2) {
    for (let t2 = 0; t2 < e2.length; t2++) e2[t2] = as(e2[t2]);
    return e2;
  }
  var ss = is ? (e2) => e2 : os;
  function cs(e2, t2) {
    return !e2.byteLength || !t2.byteLength ? false : e2.buffer === t2.buffer && e2.byteOffset < t2.byteOffset + t2.byteLength && t2.byteOffset < e2.byteOffset + e2.byteLength;
  }
  function ls(e2, t2) {
    if (cs(e2, t2) && e2.byteOffset < t2.byteOffset) throw Error(`complex overlap of input and output is not supported`);
  }
  function us(e2, t2) {
    return Qo(e2, `defaults`), Qo(t2, `opts`), Object.assign(e2, t2);
  }
  function ds(e2, t2) {
    if (e2 = Zo(e2), t2 = Zo(t2), e2.length !== t2.length) return false;
    let n2 = 0;
    for (let r2 = 0; r2 < e2.length; r2++) n2 |= e2[r2] ^ t2[r2];
    return n2 === 0;
  }
  function fs(e2, t2, n2) {
    let r2 = t2, i2 = n2 || (() => []), a2 = (e3, t3) => r2(t3, ...i2(e3)).update(e3).digest(), o2 = r2(new Uint8Array(e2), ...i2(new Uint8Array()));
    return a2.outputLen = o2.outputLen, a2.blockLen = o2.blockLen, a2.create = (e3, ...t3) => r2(e3, ...t3), a2;
  }
  var ps = (e2, t2) => {
    function n2(n3, ...r2) {
      if (Zo(n3, void 0, `key`), e2.nonceLength !== void 0) {
        let t3 = r2[0];
        Zo(t3, e2.varSizeNonce ? void 0 : e2.nonceLength, `nonce`);
      }
      let i2 = e2.tagLength, a2 = e2.nonceLength === void 0 ? 0 : 1;
      if (!e2.withAAD) {
        for (let e3 = a2; e3 < r2.length; e3++) if (qo(r2[e3])) throw Error(`AAD not supported`);
      }
      e2.withAAD && r2[a2] !== void 0 && Zo(r2[a2], void 0, `AAD`);
      let o2 = t2(n3, ...r2), s2 = (e3, t3) => {
        if (t3 !== void 0) {
          if (e3 !== 2) throw Error(`cipher output not supported`);
          Zo(t3, void 0, `output`);
        }
      }, c2 = false;
      return {
        encrypt(e3, t3) {
          if (c2) throw Error(`cannot encrypt() twice with same key + nonce`);
          return c2 = true, Zo(e3, void 0, `data`), s2(o2.encrypt.length, t3), o2.encrypt(e3, t3);
        },
        decrypt(e3, t3) {
          if (Zo(e3, void 0, `data`), i2 && e3.length < i2) throw Error(`"ciphertext" expected length >= tagLength=` + i2);
          return s2(o2.decrypt.length, t3), o2.decrypt(e3, t3);
        }
      };
    }
    return Object.assign(n2, e2), n2;
  };
  function ms(e2, t2, n2 = true) {
    if (t2 === void 0) return new Uint8Array(e2);
    if (Zo(t2, e2, `output`), n2 && !gs(t2)) throw Error(`invalid output, must be aligned`);
    return t2;
  }
  function hs(e2, t2, n2) {
    Xo(e2), Xo(t2), Yo(n2);
    let r2 = new Uint8Array(16), i2 = rs(r2);
    return i2.setBigUint64(0, BigInt(t2), n2), i2.setBigUint64(8, BigInt(e2), n2), r2;
  }
  function gs(e2) {
    return e2.byteOffset % 4 == 0;
  }
  function _s(e2) {
    return Uint8Array.from(Zo(e2));
  }
  var vs = (e2) => Uint8Array.from(e2.split(``), (e3) => e3.charCodeAt(0)), ys = ss(ts(vs(`expand 16-byte k`))), bs = ss(ts(vs(`expand 32-byte k`)));
  function H(e2, t2) {
    return e2 << t2 | e2 >>> 32 - t2;
  }
  var xs = 64, Ss = 16, Cs = 2 ** 32 - 1, ws = Uint32Array.of();
  function Ts(e2, t2, n2, r2, i2, a2, o2, s2) {
    let c2 = i2.length, l2 = new Uint8Array(xs), u2 = ts(l2), d2 = is && gs(i2) && gs(a2), f2 = d2 ? ts(i2) : ws, p2 = d2 ? ts(a2) : ws;
    if (!is) {
      for (let d3 = 0; d3 < c2; o2++) {
        if (e2(t2, n2, r2, u2, o2, s2), ss(u2), o2 >= Cs) throw Error(`arx: counter overflow`);
        let f3 = Math.min(xs, c2 - d3);
        for (let e3 = 0, t3; e3 < f3; e3++) t3 = d3 + e3, a2[t3] = i2[t3] ^ l2[e3];
        d3 += f3;
      }
      return;
    }
    for (let m2 = 0; m2 < c2; o2++) {
      if (e2(t2, n2, r2, u2, o2, s2), o2 >= Cs) throw Error(`arx: counter overflow`);
      let h2 = Math.min(xs, c2 - m2);
      if (d2 && h2 === xs) {
        let e3 = m2 / 4;
        if (m2 % 4 != 0) throw Error(`arx: invalid block position`);
        for (let t3 = 0, n3; t3 < Ss; t3++) n3 = e3 + t3, p2[n3] = f2[n3] ^ u2[t3];
        m2 += xs;
        continue;
      }
      for (let e3 = 0, t3; e3 < h2; e3++) t3 = m2 + e3, a2[t3] = i2[t3] ^ l2[e3];
      m2 += h2;
    }
  }
  function Es(e2, t2) {
    let { allowShortKeys: n2, extendNonceFn: r2, counterLength: i2, counterRight: a2, rounds: o2 } = us({
      allowShortKeys: false,
      counterLength: 8,
      counterRight: false,
      rounds: 20
    }, t2);
    if (typeof e2 != `function`) throw Error(`core must be a function`);
    return Xo(i2), Xo(o2), Yo(a2), Yo(n2), (t3, s2, c2, l2, u2 = 0) => {
      Zo(t3, void 0, `key`), Zo(s2, void 0, `nonce`), Zo(c2, void 0, `data`);
      let d2 = c2.length, f2 = l2 !== void 0;
      if (l2 = ms(d2, l2, false), f2 && ls(c2, l2), Xo(u2), u2 < 0 || u2 >= Cs) throw Error(`arx: counter overflow`);
      let p2 = [], m2 = t3.length, h2, g2;
      if (m2 === 32) p2.push(h2 = _s(t3)), g2 = bs;
      else if (m2 === 16 && n2) h2 = new Uint8Array(32), h2.set(t3), h2.set(t3, 16), g2 = ys, p2.push(h2);
      else throw Zo(t3, 32, `arx key`), Error(`invalid key size`);
      (!is || !gs(s2)) && p2.push(s2 = _s(s2));
      let _2 = ts(h2);
      if (r2) {
        if (s2.length !== 24) throw Error(`arx: extended nonce must be 24 bytes`);
        let e3 = s2.subarray(0, 16);
        if (is) r2(g2, _2, ts(e3), _2);
        else {
          let t4 = ss(Uint32Array.from(g2));
          r2(t4, _2, ts(e3), _2), ns(t4), ss(_2);
        }
        s2 = s2.subarray(16);
      } else is || ss(_2);
      let v2 = 16 - i2;
      if (v2 !== s2.length) throw Error(`arx: nonce must be ${v2} or 16 bytes`);
      if (v2 !== 12) {
        let e3 = new Uint8Array(12);
        e3.set(s2, a2 ? 0 : 12 - s2.length), s2 = e3, p2.push(s2);
      }
      let y2 = ss(ts(s2));
      try {
        return Ts(e2, g2, _2, y2, c2, l2, u2, o2), l2;
      } finally {
        ns(...p2);
      }
    };
  }
  function Ds(e2, t2) {
    return e2[t2++] & 255 | (e2[t2++] & 255) << 8;
  }
  var Os = class {
    blockLen = 16;
    outputLen = 16;
    buffer = new Uint8Array(16);
    r = new Uint16Array(10);
    h = new Uint16Array(10);
    pad = new Uint16Array(8);
    pos = 0;
    finished = false;
    destroyed = false;
    constructor(e2) {
      e2 = _s(Zo(e2, 32, `key`));
      let t2 = Ds(e2, 0), n2 = Ds(e2, 2), r2 = Ds(e2, 4), i2 = Ds(e2, 6), a2 = Ds(e2, 8), o2 = Ds(e2, 10), s2 = Ds(e2, 12), c2 = Ds(e2, 14);
      this.r[0] = t2 & 8191, this.r[1] = (t2 >>> 13 | n2 << 3) & 8191, this.r[2] = (n2 >>> 10 | r2 << 6) & 7939, this.r[3] = (r2 >>> 7 | i2 << 9) & 8191, this.r[4] = (i2 >>> 4 | a2 << 12) & 255, this.r[5] = a2 >>> 1 & 8190, this.r[6] = (a2 >>> 14 | o2 << 2) & 8191, this.r[7] = (o2 >>> 11 | s2 << 5) & 8065, this.r[8] = (s2 >>> 8 | c2 << 8) & 8191, this.r[9] = c2 >>> 5 & 127;
      for (let t3 = 0; t3 < 8; t3++) this.pad[t3] = Ds(e2, 16 + 2 * t3);
    }
    process(e2, t2, n2 = false) {
      let r2 = n2 ? 0 : 2048, { h: i2, r: a2 } = this, o2 = a2[0], s2 = a2[1], c2 = a2[2], l2 = a2[3], u2 = a2[4], d2 = a2[5], f2 = a2[6], p2 = a2[7], m2 = a2[8], h2 = a2[9], g2 = Ds(e2, t2 + 0), _2 = Ds(e2, t2 + 2), v2 = Ds(e2, t2 + 4), y2 = Ds(e2, t2 + 6), b2 = Ds(e2, t2 + 8), ee2 = Ds(e2, t2 + 10), x2 = Ds(e2, t2 + 12), S2 = Ds(e2, t2 + 14), C2 = i2[0] + (g2 & 8191), w2 = i2[1] + ((g2 >>> 13 | _2 << 3) & 8191), T2 = i2[2] + ((_2 >>> 10 | v2 << 6) & 8191), E2 = i2[3] + ((v2 >>> 7 | y2 << 9) & 8191), D2 = i2[4] + ((y2 >>> 4 | b2 << 12) & 8191), O2 = i2[5] + (b2 >>> 1 & 8191), k2 = i2[6] + ((b2 >>> 14 | ee2 << 2) & 8191), A2 = i2[7] + ((ee2 >>> 11 | x2 << 5) & 8191), j2 = i2[8] + ((x2 >>> 8 | S2 << 8) & 8191), M2 = i2[9] + (S2 >>> 5 | r2), N2 = 0, P2 = N2 + C2 * o2 + 5 * h2 * w2 + 5 * m2 * T2 + 5 * p2 * E2 + 5 * f2 * D2;
      N2 = P2 >>> 13, P2 &= 8191, P2 += 5 * d2 * O2 + 5 * u2 * k2 + 5 * l2 * A2 + 5 * c2 * j2 + 5 * s2 * M2, N2 += P2 >>> 13, P2 &= 8191;
      let F2 = N2 + C2 * s2 + w2 * o2 + 5 * h2 * T2 + 5 * m2 * E2 + 5 * p2 * D2;
      N2 = F2 >>> 13, F2 &= 8191, F2 += 5 * f2 * O2 + 5 * d2 * k2 + 5 * u2 * A2 + 5 * l2 * j2 + 5 * c2 * M2, N2 += F2 >>> 13, F2 &= 8191;
      let I2 = N2 + C2 * c2 + w2 * s2 + T2 * o2 + 5 * h2 * E2 + 5 * m2 * D2;
      N2 = I2 >>> 13, I2 &= 8191, I2 += 5 * p2 * O2 + 5 * f2 * k2 + 5 * d2 * A2 + 5 * u2 * j2 + 5 * l2 * M2, N2 += I2 >>> 13, I2 &= 8191;
      let L2 = N2 + C2 * l2 + w2 * c2 + T2 * s2 + E2 * o2 + 5 * h2 * D2;
      N2 = L2 >>> 13, L2 &= 8191, L2 += 5 * m2 * O2 + 5 * p2 * k2 + 5 * f2 * A2 + 5 * d2 * j2 + 5 * u2 * M2, N2 += L2 >>> 13, L2 &= 8191;
      let te2 = N2 + C2 * u2 + w2 * l2 + T2 * c2 + E2 * s2 + D2 * o2;
      N2 = te2 >>> 13, te2 &= 8191, te2 += 5 * h2 * O2 + 5 * m2 * k2 + 5 * p2 * A2 + 5 * f2 * j2 + 5 * d2 * M2, N2 += te2 >>> 13, te2 &= 8191;
      let ne2 = N2 + C2 * d2 + w2 * u2 + T2 * l2 + E2 * c2 + D2 * s2;
      N2 = ne2 >>> 13, ne2 &= 8191, ne2 += O2 * o2 + 5 * h2 * k2 + 5 * m2 * A2 + 5 * p2 * j2 + 5 * f2 * M2, N2 += ne2 >>> 13, ne2 &= 8191;
      let re2 = N2 + C2 * f2 + w2 * d2 + T2 * u2 + E2 * l2 + D2 * c2;
      N2 = re2 >>> 13, re2 &= 8191, re2 += O2 * s2 + k2 * o2 + 5 * h2 * A2 + 5 * m2 * j2 + 5 * p2 * M2, N2 += re2 >>> 13, re2 &= 8191;
      let ie2 = N2 + C2 * p2 + w2 * f2 + T2 * d2 + E2 * u2 + D2 * l2;
      N2 = ie2 >>> 13, ie2 &= 8191, ie2 += O2 * c2 + k2 * s2 + A2 * o2 + 5 * h2 * j2 + 5 * m2 * M2, N2 += ie2 >>> 13, ie2 &= 8191;
      let ae2 = N2 + C2 * m2 + w2 * p2 + T2 * f2 + E2 * d2 + D2 * u2;
      N2 = ae2 >>> 13, ae2 &= 8191, ae2 += O2 * l2 + k2 * c2 + A2 * s2 + j2 * o2 + 5 * h2 * M2, N2 += ae2 >>> 13, ae2 &= 8191;
      let oe2 = N2 + C2 * h2 + w2 * m2 + T2 * p2 + E2 * f2 + D2 * d2;
      N2 = oe2 >>> 13, oe2 &= 8191, oe2 += O2 * u2 + k2 * l2 + A2 * c2 + j2 * s2 + M2 * o2, N2 += oe2 >>> 13, oe2 &= 8191, N2 = (N2 << 2) + N2 | 0, N2 = N2 + P2 | 0, P2 = N2 & 8191, N2 >>>= 13, F2 += N2, i2[0] = P2, i2[1] = F2, i2[2] = I2, i2[3] = L2, i2[4] = te2, i2[5] = ne2, i2[6] = re2, i2[7] = ie2, i2[8] = ae2, i2[9] = oe2;
    }
    finalize() {
      let { h: e2, pad: t2 } = this, n2 = new Uint16Array(10), r2 = e2[1] >>> 13;
      e2[1] &= 8191;
      for (let t3 = 2; t3 < 10; t3++) e2[t3] += r2, r2 = e2[t3] >>> 13, e2[t3] &= 8191;
      e2[0] += r2 * 5, r2 = e2[0] >>> 13, e2[0] &= 8191, e2[1] += r2, r2 = e2[1] >>> 13, e2[1] &= 8191, e2[2] += r2, n2[0] = e2[0] + 5, r2 = n2[0] >>> 13, n2[0] &= 8191;
      for (let t3 = 1; t3 < 10; t3++) n2[t3] = e2[t3] + r2, r2 = n2[t3] >>> 13, n2[t3] &= 8191;
      n2[9] -= 8192;
      let i2 = (r2 ^ 1) - 1;
      for (let e3 = 0; e3 < 10; e3++) n2[e3] &= i2;
      i2 = ~i2;
      for (let t3 = 0; t3 < 10; t3++) e2[t3] = e2[t3] & i2 | n2[t3];
      e2[0] = (e2[0] | e2[1] << 13) & 65535, e2[1] = (e2[1] >>> 3 | e2[2] << 10) & 65535, e2[2] = (e2[2] >>> 6 | e2[3] << 7) & 65535, e2[3] = (e2[3] >>> 9 | e2[4] << 4) & 65535, e2[4] = (e2[4] >>> 12 | e2[5] << 1 | e2[6] << 14) & 65535, e2[5] = (e2[6] >>> 2 | e2[7] << 11) & 65535, e2[6] = (e2[7] >>> 5 | e2[8] << 8) & 65535, e2[7] = (e2[8] >>> 8 | e2[9] << 5) & 65535;
      let a2 = e2[0] + t2[0];
      e2[0] = a2 & 65535;
      for (let n3 = 1; n3 < 8; n3++) a2 = (e2[n3] + t2[n3] | 0) + (a2 >>> 16) | 0, e2[n3] = a2 & 65535;
      ns(n2);
    }
    update(e2) {
      $o(this), Zo(e2), e2 = _s(e2);
      let { buffer: t2, blockLen: n2 } = this, r2 = e2.length;
      for (let i2 = 0; i2 < r2; ) {
        let a2 = Math.min(n2 - this.pos, r2 - i2);
        if (a2 === n2) {
          for (; n2 <= r2 - i2; i2 += n2) this.process(e2, i2);
          continue;
        }
        t2.set(e2.subarray(i2, i2 + a2), this.pos), this.pos += a2, i2 += a2, this.pos === n2 && (this.process(t2, 0, false), this.pos = 0);
      }
      return this;
    }
    destroy() {
      this.destroyed = true, ns(this.h, this.r, this.buffer, this.pad);
    }
    digestInto(e2) {
      $o(this), es(e2, this), this.finished = true;
      let { buffer: t2, h: n2 } = this, { pos: r2 } = this;
      if (r2) {
        for (t2[r2++] = 1; r2 < 16; r2++) t2[r2] = 0;
        this.process(t2, 0, true);
      }
      this.finalize();
      let i2 = 0;
      for (let t3 = 0; t3 < 8; t3++) e2[i2++] = n2[t3] >>> 0, e2[i2++] = n2[t3] >>> 8;
    }
    digest() {
      let { buffer: e2, outputLen: t2 } = this;
      this.digestInto(e2);
      let n2 = e2.slice(0, t2);
      return this.destroy(), n2;
    }
  }, ks = fs(32, (e2) => new Os(e2));
  function As(e2, t2, n2, r2, i2, a2 = 20) {
    let o2 = e2[0], s2 = e2[1], c2 = e2[2], l2 = e2[3], u2 = t2[0], d2 = t2[1], f2 = t2[2], p2 = t2[3], m2 = t2[4], h2 = t2[5], g2 = t2[6], _2 = t2[7], v2 = i2, y2 = n2[0], b2 = n2[1], ee2 = n2[2], x2 = o2, S2 = s2, C2 = c2, w2 = l2, T2 = u2, E2 = d2, D2 = f2, O2 = p2, k2 = m2, A2 = h2, j2 = g2, M2 = _2, N2 = v2, P2 = y2, F2 = b2, I2 = ee2;
    for (let e3 = 0; e3 < a2; e3 += 2) x2 = x2 + T2 | 0, N2 = H(N2 ^ x2, 16), k2 = k2 + N2 | 0, T2 = H(T2 ^ k2, 12), x2 = x2 + T2 | 0, N2 = H(N2 ^ x2, 8), k2 = k2 + N2 | 0, T2 = H(T2 ^ k2, 7), S2 = S2 + E2 | 0, P2 = H(P2 ^ S2, 16), A2 = A2 + P2 | 0, E2 = H(E2 ^ A2, 12), S2 = S2 + E2 | 0, P2 = H(P2 ^ S2, 8), A2 = A2 + P2 | 0, E2 = H(E2 ^ A2, 7), C2 = C2 + D2 | 0, F2 = H(F2 ^ C2, 16), j2 = j2 + F2 | 0, D2 = H(D2 ^ j2, 12), C2 = C2 + D2 | 0, F2 = H(F2 ^ C2, 8), j2 = j2 + F2 | 0, D2 = H(D2 ^ j2, 7), w2 = w2 + O2 | 0, I2 = H(I2 ^ w2, 16), M2 = M2 + I2 | 0, O2 = H(O2 ^ M2, 12), w2 = w2 + O2 | 0, I2 = H(I2 ^ w2, 8), M2 = M2 + I2 | 0, O2 = H(O2 ^ M2, 7), x2 = x2 + E2 | 0, I2 = H(I2 ^ x2, 16), j2 = j2 + I2 | 0, E2 = H(E2 ^ j2, 12), x2 = x2 + E2 | 0, I2 = H(I2 ^ x2, 8), j2 = j2 + I2 | 0, E2 = H(E2 ^ j2, 7), S2 = S2 + D2 | 0, N2 = H(N2 ^ S2, 16), M2 = M2 + N2 | 0, D2 = H(D2 ^ M2, 12), S2 = S2 + D2 | 0, N2 = H(N2 ^ S2, 8), M2 = M2 + N2 | 0, D2 = H(D2 ^ M2, 7), C2 = C2 + O2 | 0, P2 = H(P2 ^ C2, 16), k2 = k2 + P2 | 0, O2 = H(O2 ^ k2, 12), C2 = C2 + O2 | 0, P2 = H(P2 ^ C2, 8), k2 = k2 + P2 | 0, O2 = H(O2 ^ k2, 7), w2 = w2 + T2 | 0, F2 = H(F2 ^ w2, 16), A2 = A2 + F2 | 0, T2 = H(T2 ^ A2, 12), w2 = w2 + T2 | 0, F2 = H(F2 ^ w2, 8), A2 = A2 + F2 | 0, T2 = H(T2 ^ A2, 7);
    let L2 = 0;
    r2[L2++] = o2 + x2 | 0, r2[L2++] = s2 + S2 | 0, r2[L2++] = c2 + C2 | 0, r2[L2++] = l2 + w2 | 0, r2[L2++] = u2 + T2 | 0, r2[L2++] = d2 + E2 | 0, r2[L2++] = f2 + D2 | 0, r2[L2++] = p2 + O2 | 0, r2[L2++] = m2 + k2 | 0, r2[L2++] = h2 + A2 | 0, r2[L2++] = g2 + j2 | 0, r2[L2++] = _2 + M2 | 0, r2[L2++] = v2 + N2 | 0, r2[L2++] = y2 + P2 | 0, r2[L2++] = b2 + F2 | 0, r2[L2++] = ee2 + I2 | 0;
  }
  var js = Es(As, {
    counterRight: false,
    counterLength: 4,
    allowShortKeys: false
  }), Ms = new Uint8Array(16), Ns = (e2, t2) => {
    e2.update(t2);
    let n2 = t2.length % 16;
    n2 && e2.update(Ms.subarray(n2));
  }, Ps = new Uint8Array(32);
  function Fs(e2, t2, n2, r2, i2) {
    i2 !== void 0 && Zo(i2, void 0, `AAD`);
    let a2 = e2(t2, n2, Ps), o2 = hs(r2.length, i2 ? i2.length : 0, true), s2 = ks.create(a2);
    i2 && Ns(s2, i2), Ns(s2, r2), s2.update(o2);
    let c2 = s2.digest();
    return ns(a2, o2), c2;
  }
  var Is = ps({
    blockSize: 64,
    nonceLength: 12,
    tagLength: 16,
    withAAD: true
  }, /* @__PURE__ */ ((e2) => (t2, n2, r2) => ({
    encrypt(i2, a2) {
      let o2 = i2.length;
      a2 = ms(o2 + 16, a2, false), a2.set(i2);
      let s2 = a2.subarray(0, -16);
      e2(t2, n2, s2, s2, 1);
      let c2 = Fs(e2, t2, n2, s2, r2);
      return a2.set(c2, o2), ns(c2), a2;
    },
    decrypt(i2, a2) {
      a2 = ms(i2.length - 16, a2, false);
      let o2 = i2.subarray(0, -16), s2 = i2.subarray(-16), c2 = Fs(e2, t2, n2, o2, r2);
      if (!ds(s2, c2)) throw ns(c2), Error(`invalid tag`);
      return a2.set(i2.subarray(0, -16)), e2(t2, n2, a2, a2, 1), ns(c2), a2;
    }
  }))(js)), Ls = 32, Rs = 1, zs = 3, Bs = 0, Vs = 2, Hs = 32, Us = 32, Ws = 12, Gs = 32, Ks = new TextEncoder().encode(`HPKE-v1`), qs = new Uint8Array();
  function Js(...e2) {
    let t2 = new Uint8Array(e2.reduce((e3, t3) => e3 + t3.length, 0)), n2 = 0;
    for (let r2 of e2) t2.set(r2, n2), n2 += r2.length;
    return t2;
  }
  var Ys = (e2) => new Uint8Array([
    e2 >> 8 & 255,
    e2 & 255
  ]), Xs = (e2) => new TextEncoder().encode(e2), Zs = Js(Xs(`KEM`), Ys(Ls)), Qs = Js(Xs(`HPKE`), Ys(Ls), Ys(Rs), Ys(zs)), $s = (e2, t2, n2, r2) => Uo(Je, Js(Ks, e2, Xs(n2), r2), t2), ec = (e2, t2, n2, r2, i2) => Ko(Je, t2, Js(Ys(i2), Ks, e2, Xs(n2), r2), i2);
  function tc(e2, t2) {
    return ec(Zs, $s(Zs, qs, `eae_prk`, e2), `shared_secret`, t2, Hs);
  }
  function nc(e2, t2, n2) {
    let r2 = $s(Qs, qs, `psk_id_hash`, qs), i2 = $s(Qs, qs, `info_hash`, n2), a2 = Js(new Uint8Array([
      e2
    ]), r2, i2), o2 = $s(Qs, t2, `secret`, qs);
    return {
      key: ec(Qs, o2, `key`, a2, Us),
      baseNonce: ec(Qs, o2, `base_nonce`, a2, Ws)
    };
  }
  function rc(e2, t2) {
    let n2 = $e.getSharedSecret(e2, t2);
    if (n2.every((e3) => e3 === 0)) throw Error(`tsp: DH produced the all-zero shared secret`);
    return n2;
  }
  function ic(e2) {
    if (e2.length < Gs) throw Error(`tsp: DeriveKeyPair input must be at least ${Gs} bytes`);
    let t2 = ec(Zs, $s(Zs, qs, `dkp_prk`, e2), `sk`, qs, Gs);
    return {
      sk: t2,
      pk: $e.getPublicKey(t2)
    };
  }
  function ac(e2, t2) {
    let n2 = t2?.__unsafeFixedEphemeralSk ?? $e.utils.randomSecretKey(), r2 = $e.getPublicKey(n2);
    return {
      sharedSecret: tc(rc(n2, e2), Js(r2, e2)),
      enc: r2
    };
  }
  function oc(e2, t2) {
    let n2 = Js(e2, $e.getPublicKey(t2));
    return tc(rc(t2, e2), n2);
  }
  function sc(e2, t2, n2) {
    return tc(Js(rc(t2, e2), rc(t2, n2)), Js(e2, $e.getPublicKey(t2), n2));
  }
  async function cc(e2, t2, n2, r2, i2, a2) {
    let { key: o2, baseNonce: s2 } = nc(Vs, sc(n2, r2, i2), a2);
    return Is(o2, s2, t2).decrypt(e2);
  }
  async function lc(e2, t2, n2, r2, i2) {
    let { sharedSecret: a2, enc: o2 } = ac(n2, i2), { key: s2, baseNonce: c2 } = nc(Bs, a2, r2);
    return {
      enc: o2,
      ciphertext: Is(s2, c2, t2).encrypt(e2)
    };
  }
  async function uc(e2, t2, n2, r2, i2) {
    let { key: a2, baseNonce: o2 } = nc(Bs, oc(n2, r2), i2);
    return Is(a2, o2, t2).decrypt(e2);
  }
  async function dc(e2, t2, n2, r2, i2, a2) {
    return cc(e2, t2, n2, r2, i2, a2);
  }
  async function fc(e2, t2, n2, r2) {
    return lc(e2, t2, n2, r2);
  }
  async function pc(e2, t2, n2, r2, i2) {
    return uc(e2, t2, n2, r2, i2);
  }
  function mc(e2, t2) {
    return et.sign(e2, t2);
  }
  function hc(e2, t2, n2) {
    try {
      return et.verify(t2, e2, n2);
    } catch {
      return false;
    }
  }
  var gc = Object.freeze({
    1: `Rev 2 (YTSP-AAB)`,
    2: `Rev 3 (YTSP-AAC)`,
    64: `Rev 3 as published upstream (YTSP-ABA)`
  }), _c = class extends Error {
    code = `E_TSP_REVISION`;
    major;
    minor;
    constructor(e2, t2, n2) {
      super(e2), this.name = `TspRevisionError`, this.major = t2, this.minor = n2;
    }
  };
  function vc(e2) {
    if (!Mo(e2)) throw new _c(`tsp: not a TSP frame (no -E count code)`);
    let t2 = Ho(e2, {
      pos: e2[0] === 251 ? 6 : 3
    });
    if (t2 === void 0) throw new _c(`tsp: missing or malformed YTSP version marker`);
    if (t2.major !== 0) throw new _c(`tsp: message declares MAJOR ${t2.major}; this implementation speaks MAJOR 0`, t2.major, t2.minor);
    return {
      revision: t2.minor === 1 ? `rev2` : `rev3`,
      major: t2.major,
      minor: t2.minor,
      recognised: Object.hasOwn(gc, t2.minor)
    };
  }
  function yc(e2) {
    return gc[e2.minor] ?? `MAJOR ${e2.major}, MINOR ${e2.minor} (unrecognised)`;
  }
  var bc = new TextEncoder(), xc = new TextDecoder(`utf-8`, {
    fatal: true
  });
  function Sc(e2, t2) {
    let n2 = [];
    if (Io(n2), Po(co, bc.encode(e2), n2), Po(co, bc.encode(t2), n2), n2.length % 3 != 0) throw Error(`tsp: envelope fields not a multiple of 3 bytes`);
    return new Uint8Array(n2);
  }
  function Cc(e2, t2) {
    let n2 = e2.length + t2.length;
    if (n2 % 3 != 0) throw Error(`tsp: envelope content not a multiple of 3 bytes`);
    let r2 = [];
    Fo(_o, n2 / 3, r2);
    for (let t3 of e2) r2.push(t3);
    for (let e3 of t2) r2.push(e3);
    return new Uint8Array(r2);
  }
  function wc(e2) {
    let t2 = {
      pos: 0
    }, n2 = Ro(_o, e2, t2);
    if (n2 === void 0) throw Error(`tsp: missing -E envelope frame`);
    let r2 = t2.pos, i2 = r2 + n2 * 3;
    if (i2 > e2.length) throw Error(`tsp: -E frame declares more content than the message`);
    let a2 = Ho(e2, t2);
    if (a2 === void 0) throw Error(`tsp: missing or malformed version marker`);
    let o2 = Vo(co, e2, t2);
    if (o2 === void 0) throw Error(`tsp: missing sender VID`);
    let s2 = Vo(co, e2, t2);
    if (s2 === void 0) throw Error(`tsp: missing receiver VID field`);
    let c2, l2;
    try {
      c2 = xc.decode(o2), l2 = xc.decode(s2);
    } catch {
      throw Error(`tsp: invalid VID encoding`);
    }
    if (c2.length === 0) throw Error(`tsp: sender VID is the NULL VID; every TSP message names its sender`);
    if (t2.pos > i2) throw Error(`tsp: envelope fields overrun the -E frame count`);
    return {
      envelope: {
        sender: c2,
        receiver: l2
      },
      aad: {
        begin: r2,
        end: t2.pos
      },
      headerLen: t2.pos,
      contentEnd: i2,
      minor: a2.minor
    };
  }
  var Tc = 32, Ec = 64, Dc = 22, Oc = new Uint8Array(), kc = new TextDecoder(`utf-8`, {
    fatal: true
  }), Ac = 52;
  function jc(e2, t2) {
    if (e2.length !== t2.length) return false;
    for (let n2 = 0; n2 < e2.length; n2++) if (e2[n2] !== t2[n2]) return false;
    return true;
  }
  function Mc(e2) {
    let t2 = {
      pos: 0
    };
    if (Ro(_o, e2, t2, Ac) === void 0) throw Error(`tsp(rev2): missing -E envelope wrapper`);
    if (Ho(e2, t2) === void 0) throw Error(`tsp(rev2): missing or malformed version marker`);
    let n2 = Vo(co, e2, t2);
    if (n2 === void 0) throw Error(`tsp(rev2): missing sender VID`);
    let r2 = Vo(co, e2, t2);
    if (r2 === void 0) throw Error(`tsp(rev2): missing receiver VID`);
    let i2, a2;
    try {
      i2 = kc.decode(n2), a2 = kc.decode(r2);
    } catch {
      throw Error(`tsp(rev2): invalid VID encoding`);
    }
    return zo(mo, 2, e2, t2), {
      sender: i2,
      receiver: a2,
      headerLen: t2.pos
    };
  }
  function Nc(e2, t2) {
    let n2 = Ro(yo, e2, t2, Ac);
    if (n2 === void 0) throw Error(`tsp(rev2): malformed hop list`);
    if (n2 > 64) throw Error(`tsp(rev2): too many hops`);
    let r2 = [];
    for (let i2 = 0; i2 < n2; i2++) {
      let n3 = Vo(co, e2, t2);
      if (n3 === void 0) throw Error(`tsp(rev2): malformed hop VID`);
      r2.push(n3);
    }
    return r2;
  }
  function Pc(e2) {
    let t2 = {
      pos: 0
    };
    if (Ro(vo, e2, t2, Ac) === void 0) throw Error(`tsp(rev2): missing -Z payload frame`);
    Vo(co, e2, t2);
    let n2 = e2.slice(t2.pos, t2.pos + 3);
    if (jc(n2, Co)) {
      t2.pos += 3;
      let n3 = Vo(so, e2, t2);
      if (n3 === void 0) throw Error(`tsp(rev2): missing payload plaintext`);
      return {
        kind: `direct`,
        hops: [],
        body: n3
      };
    }
    if (jc(n2, wo)) {
      t2.pos += 3;
      let n3 = Nc(e2, t2), r2;
      try {
        r2 = n3.map((e3) => kc.decode(e3));
      } catch {
        throw Error(`tsp(rev2): hop VID not UTF-8`);
      }
      let i2 = Vo(so, e2, t2);
      if (i2 === void 0) throw Error(`tsp(rev2): missing payload plaintext`);
      return {
        kind: r2.length === 0 ? `nested` : `routed`,
        hops: r2,
        body: i2
      };
    }
    throw Error(`tsp(rev2): unsupported payload type marker`);
  }
  async function Fc(e2, t2) {
    if (e2.length < 48) throw Error(`tsp(rev2): message too short`);
    let { sender: n2, receiver: r2, headerLen: i2 } = Mc(e2), a2 = e2.slice(0, i2), o2 = {
      pos: i2
    }, s2 = Bo(uo, e2, o2);
    if (s2 === void 0) throw Error(`tsp(rev2): missing G ciphertext frame`);
    let c2 = o2.pos, l2 = s2.end - s2.begin;
    if (l2 > 50331648) throw Error(`tsp(rev2): ciphertext too large`);
    if (l2 < 48) throw Error(`tsp(rev2): ciphertext truncated`);
    let u2 = Ro(xo, e2, o2, Ac), d2 = Ro(So, e2, o2, Ac);
    if (u2 !== Dc || d2 !== Dc) throw Error(`tsp(rev2): unexpected signature group size`);
    let f2 = zo(lo, Ec, e2, o2);
    if (f2 === void 0) throw Error(`tsp(rev2): missing Ed25519 signature`);
    if (o2.pos !== e2.length) throw Error(`tsp(rev2): trailing bytes after signature`);
    if (!hc(e2.slice(0, c2), f2, t2.senderSigningKey)) throw Error(`tsp(rev2): signature verification failed`);
    let p2 = e2.slice(s2.begin, s2.end), m2 = p2.length - Tc, h2 = await dc(p2.slice(0, m2), Oc, p2.slice(m2), t2.receiverDecryptionKey, t2.senderEncryptionKey, a2), g2 = Je(h2), _2 = Pc(h2);
    return {
      payload: _2.body,
      sender: n2,
      receiver: r2,
      messageType: _2.kind,
      hops: _2.hops,
      threadDigest: g2
    };
  }
  function Ic(e2) {
    let t2 = vc(e2);
    if (t2.revision === `rev2`) {
      let n3 = Mc(e2);
      return {
        envelope: {
          sender: n3.sender,
          receiver: n3.receiver
        },
        headerLen: n3.headerLen,
        revision: `rev2`,
        minor: t2.minor
      };
    }
    let n2 = wc(e2);
    return {
      envelope: n2.envelope,
      headerLen: n2.headerLen,
      revision: `rev3`,
      minor: n2.minor
    };
  }
  var Lc = new TextEncoder(), Rc = new TextDecoder(`utf-8`, {
    fatal: true
  });
  function zc() {
    let e2 = new Uint8Array(16);
    return crypto.getRandomValues(e2), e2;
  }
  function Bc(e2, t2) {
    Po(co, Lc.encode(e2), t2);
  }
  function Vc(e2) {
    let t2 = [];
    return Bc(e2, t2), new Uint8Array(t2);
  }
  function Hc(e2) {
    Po(so, new Uint8Array(), e2);
  }
  function Uc(e2, t2) {
    if (Vo(so, e2, t2) === void 0) throw Error(`tsp: missing padding field`);
  }
  function Wc(e2, t2) {
    if (e2.length !== 32) throw Error(`tsp: digest must be 32 bytes`);
    No(go, e2, t2);
  }
  function Gc(e2, t2) {
    let n2 = zo(go, 32, e2, t2);
    if (n2 === void 0) throw Error(`tsp: missing digest field, or one not coded for HPKE-Base`);
    return n2;
  }
  function Kc(e2, t2) {
    if (e2.length !== 16) throw Error(`tsp: nonce must be 16 bytes`);
    No(ho, e2, t2);
  }
  function qc(e2, t2) {
    let n2 = zo(ho, 16, e2, t2);
    if (n2 === void 0) throw Error(`tsp: missing or malformed nonce`);
    return n2;
  }
  function Jc(e2, t2) {
    let n2 = [];
    for (let t3 of e2) Po(co, Lc.encode(t3), n2);
    if (n2.length % 3 != 0) throw Error(`tsp: -J VID list not a multiple of 3 bytes`);
    Fo(yo, n2.length / 3, t2);
    for (let e3 of n2) t2.push(e3);
  }
  function Yc(e2) {
    let t2 = [];
    return Jc(e2, t2), new Uint8Array(t2);
  }
  function Xc(e2, t2) {
    let n2 = Ro(yo, e2, t2);
    if (n2 === void 0) throw Error(`tsp: missing -J VID list`);
    let r2 = n2 * 3;
    if (r2 > 50331648) throw Error(`tsp: -J VID list too long`);
    let i2 = t2.pos + r2;
    if (i2 > e2.length) throw Error(`tsp: -J VID list overruns message`);
    let a2 = [];
    for (; t2.pos < i2; ) {
      if (a2.length >= 64) throw Error(`tsp: too many hops`);
      let n3 = Vo(co, e2, t2);
      if (n3 === void 0) throw Error(`tsp: malformed VID in -J list`);
      try {
        a2.push(Rc.decode(n3));
      } catch {
        throw Error(`tsp: VID in -J list is not UTF-8`);
      }
    }
    if (t2.pos !== i2) throw Error(`tsp: -J VID list does not fill its declared length`);
    return a2;
  }
  function Zc(e2) {
    let t2 = [];
    return Po(co, Lc.encode(e2), t2), new Uint8Array(t2);
  }
  function Qc() {
    let e2 = [];
    return Fo(yo, 0, e2), new Uint8Array(e2);
  }
  function $c(...e2) {
    let t2 = e2.reduce((e3, t3) => e3 + t3.length, 0), n2 = new Uint8Array(t2), r2 = 0;
    for (let t3 of e2) n2.set(t3, r2), r2 += t3.length;
    return n2;
  }
  var el = 35, tl = {
    invite: To,
    accept: Eo,
    cancel: Do
  };
  function nl(e2, t2, n2, r2) {
    return Je($c(e2, t2, n2, new Uint8Array(33).fill(el), r2));
  }
  function rl(e2, t2, n2) {
    let r2 = [];
    return Kc(e2, r2), $c(new Uint8Array(r2), Yc(t2), n2 ? Zc(n2.newVid) : Qc());
  }
  function il(e2, t2) {
    if (!e2) {
      Fo(yo, 0, t2);
      return;
    }
    let n2 = [];
    if (Po(co, new TextEncoder().encode(e2.newVid), n2), ll(e2.signature, n2), n2.length % 3 != 0) throw Error(`tsp: referral group not a multiple of 3 bytes`);
    Fo(yo, n2.length / 3, t2);
    for (let e3 of n2) t2.push(e3);
  }
  function al(e2, t2) {
    let n2 = Ro(yo, e2, t2);
    if (n2 === void 0) throw Error(`tsp: missing referral field`);
    if (n2 === 0) return;
    let r2 = t2.pos + n2 * 3;
    if (r2 > e2.length) throw Error(`tsp: referral field overruns the payload`);
    let i2 = Vo(co, e2, t2);
    if (i2 === void 0) throw Error(`tsp: malformed VID in referral field`);
    let a2;
    try {
      a2 = new TextDecoder(`utf-8`, {
        fatal: true
      }).decode(i2);
    } catch {
      throw Error(`tsp: referral VID is not UTF-8`);
    }
    if (a2.length === 0) throw Error(`tsp: referral field names the NULL VID`);
    let o2 = ul(e2, t2);
    if (t2.pos !== r2) throw Error(`tsp: referral field does not fill its own count`);
    return {
      newVid: a2,
      signature: o2
    };
  }
  var ol = 22, sl = 23, cl = 0;
  function ll(e2, t2) {
    if (e2.length !== 64) throw Error(`tsp: signature must be 64 bytes`);
    Fo(xo, sl, t2), Fo(So, ol, t2), Lo(cl, e2, t2);
  }
  function ul(e2, t2) {
    let n2 = Ro(xo, e2, t2), r2 = Ro(So, e2, t2);
    if (n2 !== sl || r2 !== ol) throw Error(`tsp: unexpected referral signature group size`);
    if (t2.pos + 2 + 64 > e2.length) throw Error(`tsp: truncated referral signature`);
    if ((e2[t2.pos] << 16 | e2[t2.pos + 1] << 8) >>> 0 >>> 18 !== lo) throw Error(`tsp: referral signature is not the indexed Ed25519 code`);
    t2.pos += 2;
    let i2 = e2.slice(t2.pos, t2.pos + 64);
    return t2.pos += 64, i2;
  }
  function dl(e2, t2, n2) {
    let r2 = Vc(t2), i2 = tl[e2.controlType], a2 = [];
    if (e2.controlType === `invite`) {
      let t3 = e2.nonce;
      if (t3 === void 0 || t3.length !== 16) throw Error(`tsp: an invite must carry a 128-bit nonce`);
      let o3 = nl(n2, i2, r2, rl(t3, e2.route, e2.referral));
      for (let e3 of i2) a2.push(e3);
      for (let e3 of r2) a2.push(e3);
      return Wc(o3, a2), Kc(t3, a2), Jc(e2.route, a2), il(e2.referral, a2), Hc(a2), {
        body: a2,
        threadDigest: o3
      };
    }
    if (e2.controlType === `accept`) {
      let t3 = e2.inReplyTo;
      if (t3 === void 0 || t3.length !== 32) throw Error(`tsp: an accept must name the invite it answers`);
      let o3 = Array.from(r2);
      Wc(t3, o3);
      let s2 = new Uint8Array(o3), c2 = nl(n2, i2, s2, new Uint8Array());
      for (let e3 of i2) a2.push(e3);
      for (let e3 of s2) a2.push(e3);
      return Wc(c2, a2), Hc(a2), {
        body: a2,
        threadDigest: c2
      };
    }
    let o2 = e2.inReplyTo;
    if (o2 === void 0 || o2.length !== 32) throw Error(`tsp: a cancel must name the relationship it ends`);
    for (let e3 of i2) a2.push(e3);
    for (let e3 of r2) a2.push(e3);
    return Wc(o2, a2), Hc(a2), {
      body: a2,
      threadDigest: o2
    };
  }
  function fl(e2, t2, n2, r2, i2) {
    let a2 = tl[e2], o2 = Gc(t2, n2);
    if (e2 === `invite`) {
      let s2 = qc(t2, n2), c2 = Xc(t2, n2), l2 = al(t2, n2);
      return Uc(t2, n2), pl(nl(i2, a2, r2, rl(s2, c2, l2)), o2), {
        control: {
          controlType: e2,
          digest: o2,
          nonce: s2,
          route: c2,
          ...l2 ? {
            referral: l2
          } : {}
        },
        threadDigest: o2
      };
    }
    if (e2 === `accept`) {
      let s2 = Gc(t2, n2);
      Uc(t2, n2);
      let c2 = Array.from(r2);
      return Wc(o2, c2), pl(nl(i2, a2, new Uint8Array(c2), new Uint8Array()), s2), {
        control: {
          controlType: e2,
          digest: s2,
          inReplyTo: o2,
          route: []
        },
        threadDigest: s2
      };
    }
    return Uc(t2, n2), {
      control: {
        controlType: e2,
        digest: o2,
        inReplyTo: o2,
        route: []
      },
      threadDigest: o2
    };
  }
  function pl(e2, t2) {
    if (e2.length !== t2.length) throw Error(`tsp: TSP_Digest does not match the message it identifies`);
    let n2 = 0;
    for (let r2 = 0; r2 < e2.length; r2++) n2 |= e2[r2] ^ t2[r2];
    if (n2 !== 0) throw Error(`tsp: TSP_Digest does not match the message it identifies`);
  }
  var ml = new TextDecoder(`utf-8`, {
    fatal: true
  });
  function hl(e2, t2) {
    if (e2.length !== t2.length) return false;
    for (let n2 = 0; n2 < e2.length; n2++) if (e2[n2] !== t2[n2]) return false;
    return true;
  }
  function gl(e2) {
    if (e2.length % 3 != 0) throw Error(`tsp: payload frame not a multiple of 3 bytes`);
    let t2 = [];
    Fo(vo, e2.length / 3, t2);
    for (let n2 of e2) t2.push(n2);
    return new Uint8Array(t2);
  }
  function _l(e2, t2, n2, r2) {
    let i2 = [];
    if (t2 === `direct`) {
      for (let e3 of Co) i2.push(e3);
      Bc(r2, i2), Hc(i2);
      let t3 = [];
      Po(so, e2, t3), Fo(bo, t3.length / 3, i2);
      for (let e3 of t3) i2.push(e3);
    } else {
      for (let e3 of wo) i2.push(e3);
      if (Bc(r2, i2), Jc(t2 === `nested` ? [] : n2, i2), Hc(i2), e2.length % 3 != 0) throw Error(`tsp: nested inner message is not quadlet-aligned`);
      for (let t3 of e2) i2.push(t3);
    }
    let a2 = gl(i2);
    return {
      frame: a2,
      threadDigest: Je(a2)
    };
  }
  function vl(e2, t2, n2) {
    let { body: r2, threadDigest: i2 } = dl(e2, t2, n2);
    return {
      frame: gl(r2),
      threadDigest: i2
    };
  }
  function yl(e2, t2, n2) {
    let r2 = {
      pos: 0
    }, i2 = Ro(vo, e2, r2);
    if (i2 === void 0) throw Error(`tsp: missing -Z payload frame`);
    let a2 = r2.pos + i2 * 3;
    if (a2 > e2.length) throw Error(`tsp: -Z frame declares more content than the payload`);
    let o2 = Je(e2.slice(0, a2));
    if (r2.pos + 3 > e2.length) throw Error(`tsp: truncated payload type code`);
    let s2 = e2.slice(r2.pos, r2.pos + 3);
    r2.pos += 3;
    let c2 = r2.pos, l2 = Vo(co, e2, r2);
    if (l2 === void 0) throw Error(`tsp: missing ESSR sender VID field`);
    let u2 = e2.slice(c2, r2.pos), d2;
    try {
      d2 = ml.decode(l2);
    } catch {
      throw Error(`tsp: ESSR sender VID is not UTF-8`);
    }
    if (d2.length > 0 && d2 !== t2) throw Error(`tsp: ESSR sender VID does not match the envelope sender`);
    if (hl(s2, Co) || hl(s2, Oo)) {
      Uc(e2, r2);
      let t3 = Ro(bo, e2, r2);
      if (t3 === void 0) throw Error(`tsp: missing -A payload stream`);
      let n3 = r2.pos + t3 * 3;
      if (n3 !== a2) throw Error(`tsp: -A stream does not end the payload frame`);
      let i3 = Vo(so, e2, r2);
      if (i3 === void 0) throw Error(`tsp: missing payload body`);
      if (r2.pos !== n3) throw Error(`tsp: -A stream must hold exactly one Bytes primitive`);
      return {
        kind: hl(s2, Co) ? `direct` : `control`,
        hops: [],
        body: i3,
        senderVid: d2,
        threadDigest: o2
      };
    }
    if (hl(s2, wo)) {
      let t3 = Xc(e2, r2);
      Uc(e2, r2);
      let n3 = e2.slice(r2.pos, a2);
      return {
        kind: t3.length === 0 ? `nested` : `routed`,
        hops: t3,
        body: n3,
        senderVid: d2,
        threadDigest: o2
      };
    }
    let f2 = bl(s2);
    if (f2) {
      let { control: t3, threadDigest: i3 } = fl(f2, e2, r2, u2, n2);
      return {
        kind: `control`,
        control: t3,
        hops: [],
        body: new Uint8Array(),
        senderVid: d2,
        threadDigest: i3
      };
    }
    if (hl(s2, ko)) return {
      kind: `padding`,
      hops: [],
      body: new Uint8Array(),
      senderVid: d2,
      threadDigest: o2
    };
    throw Error(`tsp: unsupported payload type marker`);
  }
  function bl(e2) {
    if (hl(e2, To)) return `invite`;
    if (hl(e2, Eo)) return `accept`;
    if (hl(e2, Do)) return `cancel`;
  }
  var xl = 32, Sl = 64, Cl = 22, wl = 23, Tl = 0, El = (e2, t2) => t2?.nullPayloadSender === true ? `` : e2;
  function Dl(e2, t2) {
    Fo(xo, wl, t2), Fo(So, Cl, t2), Lo(Tl, e2, t2);
  }
  function Ol(e2, t2) {
    let n2 = Ro(xo, e2, t2), r2 = Ro(So, e2, t2);
    if (n2 !== wl || r2 !== Cl) throw Error(`tsp: unexpected signature group size`);
    if (t2.pos + 2 + Sl > e2.length) throw Error(`tsp: truncated signature attachment`);
    let i2 = (e2[t2.pos] << 16 | e2[t2.pos + 1] << 8) >>> 0;
    if (i2 >>> 18 !== lo) throw Error(`tsp: signature is not the indexed Ed25519 code`);
    let a2 = i2 >>> 12 & 63;
    if (a2 !== Tl) throw Error(`tsp: signature names key index ${a2}, but only index ${Tl} can be verified`);
    t2.pos += 2;
    let o2 = e2.slice(t2.pos, t2.pos + Sl);
    return t2.pos += Sl, o2;
  }
  async function kl(e2, t2, n2, r2) {
    let i2 = r2 === void 0 ? await fc(t2, e2, n2.receiverEncryptionKey, jo) : await lc(t2, e2, n2.receiverEncryptionKey, jo, {
      __unsafeFixedEphemeralSk: ic(r2.__unsafeIkmE).sk
    }), a2 = new Uint8Array(i2.enc.length + i2.ciphertext.length);
    a2.set(i2.enc, 0), a2.set(i2.ciphertext, i2.enc.length);
    let o2 = [];
    Po(fo, a2, o2);
    let s2 = Cc(e2, new Uint8Array(o2)), c2 = mc(s2, n2.senderSigningKey), l2 = Array.from(s2);
    return Dl(c2, l2), new Uint8Array(l2);
  }
  async function Al(e2, t2, n2, r2, i2, a2, o2) {
    let s2 = Sc(r2, i2), { frame: c2, threadDigest: l2 } = _l(e2, t2, n2, El(r2, o2));
    return {
      bytes: await kl(s2, c2, a2, o2),
      threadDigest: l2
    };
  }
  async function jl(e2, t2, n2, r2, i2) {
    let a2 = Sc(t2, n2), { frame: o2, threadDigest: s2 } = vl(e2, El(t2, i2), a2);
    return {
      bytes: await kl(a2, o2, r2, i2),
      threadDigest: s2
    };
  }
  function Ml(e2, t2, n2, r2 = {}, i2) {
    return jl({
      controlType: `invite`,
      nonce: r2.nonce ?? zc(),
      route: r2.route ?? []
    }, e2, t2, n2, i2);
  }
  function Nl(e2, t2, n2, r2, i2) {
    return Al(e2, `direct`, [], t2, n2, r2, i2);
  }
  async function Pl(e2, t2) {
    if (e2.length < 48) throw Error(`tsp: message too short`);
    let n2 = wc(e2), r2 = e2.slice(n2.aad.begin, n2.aad.end), i2 = {
      pos: n2.headerLen
    }, a2 = Bo(fo, e2, i2);
    if (a2 === void 0) throw Bo(po, e2, {
      pos: n2.headerLen
    }) ? Error(`tsp: message is sealed with the libsodium sealed box (\xA78.3), which this implementation does not support`) : Error(`tsp: missing F ciphertext field`);
    let o2 = a2.end - a2.begin;
    if (o2 > 50331648) throw Error(`tsp: ciphertext too large`);
    if (o2 < 48) throw Error(`tsp: ciphertext truncated`);
    if (i2.pos !== n2.contentEnd) throw Error(`tsp: message body does not fill the -E frame`);
    let s2 = Ol(e2, i2);
    if (i2.pos !== e2.length) throw Error(`tsp: trailing bytes after signature`);
    if (!hc(e2.slice(0, n2.contentEnd), s2, t2.senderSigningKey)) throw Error(`tsp: signature verification failed`);
    let c2 = e2.slice(a2.begin, a2.end), l2 = yl(await pc(c2.slice(xl), r2, c2.slice(0, xl), t2.receiverDecryptionKey, jo), n2.envelope.sender, r2);
    return {
      payload: l2.body,
      sender: n2.envelope.sender,
      receiver: n2.envelope.receiver,
      messageType: l2.kind,
      ...l2.control ? {
        control: l2.control
      } : {},
      hops: l2.hops,
      threadDigest: l2.threadDigest
    };
  }
  function Fl(e2, t2, n2, r2) {
    return Nl(e2, t2, n2, r2);
  }
  function Il(e2, t2, n2, r2 = {}) {
    return Ml(e2, t2, n2, r2);
  }
  async function Ll(e2, t2) {
    let n2 = vc(e2);
    try {
      if (n2.revision === `rev2`) {
        if (t2.senderEncryptionKey === void 0) throw new _c(`tsp: message is Rev 2 (YTSP-AAB), which needs the sender's X25519 public key to open (HPKE-Auth); pass senderEncryptionKey`, n2.major, n2.minor);
        return {
          ...await Fc(e2, {
            receiverDecryptionKey: t2.receiverDecryptionKey,
            senderEncryptionKey: t2.senderEncryptionKey,
            senderSigningKey: t2.senderSigningKey
          }),
          revision: `rev2`
        };
      }
      return {
        ...await Pl(e2, {
          receiverDecryptionKey: t2.receiverDecryptionKey,
          senderSigningKey: t2.senderSigningKey
        }),
        revision: `rev3`
      };
    } catch (e3) {
      throw e3 instanceof _c || n2.recognised ? e3 : new _c(`tsp: could not parse a message declaring ${yc(n2)}; this implementation packs Rev 3 (YTSP-AAC) and reads Rev 2 (YTSP-AAB). Underlying error: ${e3 instanceof Error ? e3.message : String(e3)}`, n2.major, n2.minor);
    }
  }
  var Rl = class extends Error {
    code = `E_TSP_TRANSITION`;
    state;
    event;
    constructor(e2, t2) {
      super(`tsp: cannot ${t2} in relationship state ${e2}`), this.name = `InvalidTransitionError`, this.state = e2, this.event = t2;
    }
  }, zl = {
    none: {
      sendInvite: `pending`,
      receiveInvite: `inviteReceived`
    },
    pending: {
      receiveAccept: `bidirectional`,
      receiveCancel: `none`,
      sendCancel: `none`
    },
    inviteReceived: {
      sendAccept: `bidirectional`,
      sendCancel: `none`,
      receiveCancel: `none`
    },
    bidirectional: {
      sendCancel: `none`,
      receiveCancel: `none`
    }
  };
  function Bl(e2, t2) {
    let n2 = zl[e2][t2];
    if (n2 === void 0) throw new Rl(e2, t2);
    return n2;
  }
  function Vl(e2, t2) {
    let n2 = Math.min(e2.length, t2.length);
    for (let r2 = 0; r2 < n2; r2++) if (e2[r2] !== t2[r2]) return e2[r2] < t2[r2] ? -1 : 1;
    return e2.length - t2.length;
  }
  function Hl(e2, t2, n2) {
    return e2 !== `pending` || n2 === void 0 ? {
      action: `ignore`,
      reason: `answers no invite we have outstanding`
    } : t2 === void 0 || Vl(t2, n2) !== 0 ? {
      action: `ignore`,
      reason: `answers an invite we did not send`
    } : {
      action: `adopt`
    };
  }
  function Ul(e2, t2, n2) {
    return e2 === `none` ? {
      action: `ignore`,
      reason: `names no relationship we hold`
    } : t2 !== void 0 && !n2.some((e3) => Vl(e3, t2) === 0) ? {
      action: `ignore`,
      reason: `names an unrecognised relationship`
    } : e2 === `bidirectional` ? {
      action: `removeAndReply`
    } : {
      action: `remove`
    };
  }
  var Wl = class {
    records = /* @__PURE__ */ new Map();
    key(e2, t2) {
      return JSON.stringify([
        e2,
        t2
      ]);
    }
    async get(e2, t2) {
      return this.records.get(this.key(e2, t2));
    }
    async set(e2, t2, n2) {
      this.records.set(this.key(e2, t2), n2);
    }
    async clear(e2, t2) {
      this.records.delete(this.key(e2, t2));
    }
  }, Gl = (e2) => Array.from(e2, (e3) => e3.toString(16).padStart(2, `0`)).join(``), Kl = (e2) => {
    if (e2 === void 0 || e2.length % 2 != 0 || !/^[0-9a-f]*$/.test(e2)) return;
    let t2 = new Uint8Array(e2.length / 2);
    for (let n2 = 0; n2 < t2.length; n2++) t2[n2] = parseInt(e2.slice(n2 * 2, n2 * 2 + 2), 16);
    return t2;
  };
  async function ql(e2) {
    let { transport: t2, holder: n2, vta: r2, store: i2 } = e2, a2 = (t3) => (e2.onOutcome?.(t3), t3), o2 = await i2.get(n2.vid, r2.vid);
    if (o2?.state === `bidirectional`) return a2({
      kind: `alreadyEstablished`
    });
    let s2 = o2?.state ?? `none`, c2;
    try {
      c2 = Bl(s2, `sendInvite`);
    } catch (e3) {
      return a2({
        kind: `refused`,
        reason: e3.message
      });
    }
    let l2;
    try {
      l2 = await Il(n2.vid, r2.vid, {
        senderSigningKey: n2.signingPrivateKey,
        receiverEncryptionKey: r2.encryptionPublicKey
      });
    } catch (e3) {
      return a2({
        kind: `refused`,
        reason: `could not pack invite: ${e3.message}`
      });
    }
    let u2, d2 = async (e3) => {
      let t3;
      try {
        t3 = await Ll(e3, {
          receiverDecryptionKey: n2.encryptionPrivateKey,
          senderSigningKey: r2.signingPublicKey
        });
      } catch (e4) {
        return u2 = `unpack failed: ${e4.message}`, false;
      }
      if (t3.sender !== r2.vid) return u2 = `sealed by ${t3.sender}, not the VTA`, false;
      let i3 = t3.control;
      if (t3.messageType !== `control` || !i3) return u2 = `not a control message (${t3.messageType})`, false;
      if (i3.controlType !== `accept`) return u2 = `a ${i3.controlType}, not an accept`, false;
      let a3 = Hl(c2, i3.inReplyTo, l2.threadDigest);
      return a3.action !== `ignore` || (u2 = `an accept that ${a3.reason}`, false);
    };
    await i2.set(n2.vid, r2.vid, {
      state: c2,
      ourDigest: Gl(l2.threadDigest)
    });
    try {
      await t2.sendAndAwaitReply(l2.bytes, {
        timeoutMs: e2.handshakeTimeoutMs ?? 5e3,
        claims: d2
      });
    } catch (e3) {
      return a2({
        kind: `notAnswered`,
        reason: u2 ? `${e3.message} -- last frame declined: ${u2}` : e3.message
      });
    }
    return await i2.set(n2.vid, r2.vid, {
      state: Bl(c2, `receiveAccept`),
      ourDigest: Gl(l2.threadDigest)
    }), a2({
      kind: `established`,
      threadDigest: Gl(l2.threadDigest)
    });
  }
  async function Jl(e2, t2, n2) {
    await e2.clear(t2, n2);
  }
  async function Yl(e2, t2, n2, r2) {
    let i2 = await e2.get(t2, n2), a2 = i2?.state ?? `none`;
    if (r2.controlType === `accept`) {
      let o2 = Hl(a2, r2.inReplyTo, Kl(i2?.ourDigest));
      return o2.action === `ignore` ? {
        kind: `ignored`,
        reason: `an accept that ${o2.reason}`
      } : (await e2.set(t2, n2, {
        ...i2,
        state: Bl(a2, `receiveAccept`),
        ...r2.digest ? {
          theirDigest: Gl(r2.digest)
        } : {}
      }), {
        kind: `adopted`
      });
    }
    if (r2.controlType === `cancel`) {
      let o2 = [
        i2?.ourDigest,
        i2?.theirDigest
      ].map(Kl).filter((e3) => e3 !== void 0), s2 = Ul(a2, r2.inReplyTo, o2);
      return s2.action === `ignore` ? {
        kind: `ignored`,
        reason: `a cancellation: ${s2.reason}`
      } : (await e2.clear(t2, n2), {
        kind: `removed`,
        reply: s2.action === `removeAndReply`
      });
    }
    return {
      kind: `ignored`,
      reason: `an invite: this wallet does not take inbound relationships`
    };
  }
  var Xl = 3e4, Zl = /* @__PURE__ */ new WeakMap(), Ql = (e2) => Array.from(e2, (e3) => e3.toString(16).padStart(2, `0`)).join(``);
  function $l(e2, t2, n2) {
    let r2 = `${Ql(t2.encryptionPublicKey)}|${Ql(n2.encryptionPublicKey)}|${Ql(n2.signingPublicKey)}`, i2 = Zl.get(e2);
    i2 || (i2 = /* @__PURE__ */ new Map(), Zl.set(e2, i2));
    let a2 = i2.get(r2);
    if (a2) return a2;
    let o2 = (async () => {
      let r3;
      try {
        r3 = await Ll(e2, {
          receiverDecryptionKey: t2.encryptionPrivateKey,
          senderEncryptionKey: n2.encryptionPublicKey,
          senderSigningKey: n2.signingPublicKey
        });
      } catch (e3) {
        return {
          ok: false,
          decline: `unpack failed: ${e3.message}`
        };
      }
      try {
        let e3 = Wa(nu.decode(r3.payload));
        return {
          ok: true,
          sender: r3.sender,
          doc: e3
        };
      } catch (e3) {
        return {
          ok: false,
          decline: e3.message
        };
      }
    })();
    return i2.set(r2, o2), o2;
  }
  function eu(e2, t2) {
    let n2 = et.utils.toMontgomerySecret(t2);
    return {
      vid: e2,
      signingPrivateKey: t2,
      encryptionPrivateKey: n2,
      encryptionPublicKey: $e.getPublicKey(n2)
    };
  }
  var tu = new TextEncoder(), nu = new TextDecoder(`utf-8`, {
    fatal: true
  }), ru = class {
    kind = `tsp`;
    transport;
    holder;
    vta;
    signer;
    timeoutMs;
    relationships;
    handshakeTimeoutMs;
    onRelationship;
    handshake;
    constructor(e2) {
      this.signer = v(e2.signing), this.transport = e2.transport, this.holder = e2.holder, this.vta = e2.vta, this.timeoutMs = e2.timeoutMs ?? Xl, this.relationships = e2.relationships ?? new Wl(), this.handshakeTimeoutMs = e2.handshakeTimeoutMs, this.onRelationship = e2.onRelationship;
    }
    async ensureRelated() {
      this.handshake ||= ql({
        transport: this.transport,
        holder: this.holder,
        vta: this.vta,
        store: this.relationships,
        ...this.handshakeTimeoutMs === void 0 ? {} : {
          handshakeTimeoutMs: this.handshakeTimeoutMs
        },
        ...this.onRelationship ? {
          onOutcome: this.onRelationship
        } : {}
      }).finally(() => {
        this.handshake = void 0;
      }), await this.handshake;
    }
    async forgetRelationship() {
      await Jl(this.relationships, this.holder.vid, this.vta.vid);
    }
    async packForVta(e2) {
      return await c(e2, this.signer, this.holder.vid), (await Fl(tu.encode(Ua(e2)), this.holder.vid, this.vta.vid, {
        senderSigningKey: this.holder.signingPrivateKey,
        receiverEncryptionKey: this.vta.encryptionPublicKey
      })).bytes;
    }
    async notify(e2, t2 = {}) {
      if (!this.transport.send) throw new _(`e.client.unsupported`, `${t2.operationLabel ?? e2.type}: this TSP transport has no one-way send`);
      await this.ensureRelated();
      let n2 = await this.packForVta(e2);
      try {
        await this.transport.send(n2);
      } catch (e3) {
        throw await this.forgetRelationship(), e3;
      }
    }
    async send(e2, t2 = {}) {
      await this.ensureRelated();
      let n2 = {
        bytes: await this.packForVta(e2)
      }, r2, i2, a2 = 0, o2 = async (t3) => {
        a2++;
        let n3 = await $l(t3, this.holder, this.vta);
        if (!n3.ok) return i2 = n3.decline, false;
        if (n3.sender !== this.vta.vid) return i2 = `sealed by ${n3.sender}, not the VTA ${this.vta.vid}`, false;
        let o3 = n3.doc;
        return o3.threadId === e2.id ? (r2 = o3, true) : (i2 = `threadId ${JSON.stringify(o3.threadId)} != request id ${JSON.stringify(e2.id)} (reply type ${JSON.stringify(o3.type)}, reply id ${JSON.stringify(o3.id)})`, false);
      };
      try {
        await this.transport.sendAndAwaitReply(n2.bytes, {
          timeoutMs: fr(e2.type, t2.timeoutMs ?? this.timeoutMs),
          claims: o2
        });
      } catch (e3) {
        throw await this.forgetRelationship(), i2 ? new _(e3.code ?? `e.client.network`, `${e3.message} \u2014 last inbound frame declined: ${i2}`, {
          details: {
            lastDecline: i2,
            framesSeen: a2
          }
        }) : a2 === 0 ? new _(e3.code ?? `e.client.network`, `${e3.message} \u2014 no frame arrived on this socket while waiting, so the reply was lost before reaching the wallet (at the agent's send or at the mediator)`, {
          details: {
            framesSeen: a2
          }
        }) : e3;
      }
      let s2 = r2;
      if (!s2) throw new _(`e.client.parse`, `tsp: reply resolved with no claimed document`);
      return await ee(s2 ?? {}, this.vta.vid), x(s2, {
        ...t2.expectedResponseType === void 0 ? {} : {
          expectedResponseType: t2.expectedResponseType
        },
        ...t2.operationLabel === void 0 ? {} : {
          operationLabel: t2.operationLabel
        }
      });
    }
    async close() {
      await this.transport.close?.();
    }
  }, iu = new TextDecoder();
  function au(e2) {
    return e2.kind === `control`;
  }
  async function ou(e2, t2) {
    let n2;
    try {
      n2 = Ic(e2).envelope.sender;
    } catch (e3) {
      throw new _(`e.client.parse`, `tsp inbound: unreadable envelope: ${e3.message}`);
    }
    let r2;
    try {
      r2 = await t2.resolveSender(n2);
    } catch (e3) {
      throw new _(`e.client.parse`, `tsp inbound: cannot resolve sender ${n2}: ${e3.message}`);
    }
    let i2;
    try {
      i2 = await Ll(e2, {
        receiverDecryptionKey: t2.holder.encryptionPrivateKey,
        senderEncryptionKey: r2.encryptionPublicKey,
        senderSigningKey: r2.signingPublicKey
      });
    } catch (e3) {
      throw new _(`e.p.msg.unauthorized`, `tsp inbound: unpack failed for claimed sender ${n2}: ${e3.message}`);
    }
    if (i2.sender !== n2) throw new _(`e.p.msg.unauthorized`, `tsp inbound: proven sender ${i2.sender} != envelope sender ${n2}`);
    if (i2.control) return {
      kind: `control`,
      from: i2.sender,
      control: i2.control
    };
    let a2 = Wa(iu.decode(i2.payload)), o2 = typeof a2.id == `string` ? a2.id : void 0;
    if (!o2 || typeof a2.type != `string`) throw new _(`e.client.parse`, "tsp inbound: payload is not a Trust-Task document (no `id`/`type`)");
    return {
      id: o2,
      type: s,
      from: i2.sender,
      to: [
        t2.holder.vid
      ],
      body: a2,
      transport: `tsp`
    };
  }
  var su = 3e4, cu = class {
    conn;
    timeoutMs;
    constructor(e2) {
      this.conn = e2.connection, this.timeoutMs = e2.timeoutMs ?? su;
    }
    async sendAndAwaitReply(e2, t2 = {}) {
      let n2 = t2.timeoutMs ?? this.timeoutMs, r2 = t2.claims;
      if (!r2) throw new _(`e.client.unsupported`, "tsp: sendAndAwaitReply needs a `claims` predicate to tell its reply from an unsolicited inbound frame on the shared socket");
      let i2 = this.conn.awaitTspFrame(n2, r2);
      try {
        this.conn.sendBinary(e2);
      } catch (e3) {
        throw i2.catch(() => {
        }), new _(`e.client.unsupported`, `tsp: send failed (${e3.message}) \u2014 falling back`);
      }
      try {
        return await i2;
      } catch (e3) {
        throw new _(`e.client.network`, `tsp: ${e3.message}`);
      }
    }
  }, lu = 237;
  function uu(e2) {
    let t2 = 0, n2 = 0, r2 = 0;
    for (; r2 < e2.length; r2++) {
      let i2 = e2[r2];
      if (t2 |= (i2 & 127) << n2, !(i2 & 128)) return {
        value: t2 >>> 0,
        length: r2 + 1
      };
      if (n2 += 7, n2 > 28) break;
    }
    throw new _(`e.client.parse`, `tsp-vid: malformed multicodec varint`);
  }
  function du(e2) {
    if (!e2.startsWith(`z`)) throw new _(`e.client.parse`, `tsp-vid: not a base58btc Multikey: ${e2}`);
    let t2 = he.decode(e2.slice(1)), { value: n2, length: r2 } = uu(t2);
    return {
      codec: n2,
      key: t2.slice(r2)
    };
  }
  function fu(e2, t2) {
    if (e2.kty !== `OKP` || e2.crv !== t2 || !e2.x) throw new _(`e.client.parse`, `tsp-vid: expected OKP ${t2} JWK, got kty=${e2.kty} crv=${e2.crv}`);
    let n2 = te(e2.x);
    if (n2.length !== 32) throw new _(`e.client.parse`, `tsp-vid: ${t2} key is ${n2.length} bytes, want 32`);
    return n2;
  }
  function pu(e2) {
    if (e2.publicKeyMultibase) {
      let { codec: t2, key: n2 } = du(e2.publicKeyMultibase);
      if (t2 !== lu) throw new _(`e.client.parse`, `tsp-vid: VM is not Ed25519 (multicodec 0x${t2.toString(16)})`);
      if (n2.length !== 32) throw new _(`e.client.parse`, `tsp-vid: Ed25519 key is ${n2.length} bytes, want 32`);
      return n2;
    }
    if (e2.publicKeyJwk) return fu(e2.publicKeyJwk, `Ed25519`);
    throw new _(`e.client.parse`, `tsp-vid: VM has no publicKeyMultibase or publicKeyJwk`);
  }
  function mu(e2, t2) {
    return typeof e2 == `string` ? t2.find((t3) => t3.id === e2 || t3.id?.endsWith(e2)) : e2;
  }
  function hu(e2) {
    let t2 = e2.verificationMethod ?? [];
    for (let n2 of [
      e2.authentication,
      e2.assertionMethod
    ]) for (let e3 of n2 ?? []) {
      let n3 = mu(e3, t2);
      if (n3) try {
        return pu(n3);
      } catch {
      }
    }
    for (let e3 of t2) try {
      return pu(e3);
    } catch {
    }
    throw new _(`e.client.parse`, `tsp-vid: DID document has no Ed25519 verification method`);
  }
  function gu(e2, t2, n2) {
    return {
      vid: e2,
      encryptionPublicKey: fu(t2, `X25519`),
      signingPublicKey: hu(n2)
    };
  }
  async function _u(e2, t2) {
    let n2 = await ze(e2), r2 = await t2(e2);
    return gu(e2, n2.keyAgreementPublicJwk, r2);
  }
  function vu(e2) {
    return _u(e2, Oe);
  }
  var yu = 3e5, bu = 32, xu = /* @__PURE__ */ new Map();
  function Su(e2) {
    return Cu(e2, vu);
  }
  async function Cu(e2, t2, n2 = Date.now) {
    let r2 = xu.get(e2);
    if (r2 && n2() - r2.at < yu) return r2.endpoint;
    let i2 = await t2(e2);
    if (xu.set(e2, {
      at: n2(),
      endpoint: i2
    }), xu.size > bu) {
      let e3 = xu.keys().next().value;
      e3 !== void 0 && xu.delete(e3);
    }
    return i2;
  }
  var wu = `openvtc.origin`;
  async function Tu(e2, t2) {
    let n2 = {
      ...t2.payload
    };
    if (t2.origin) {
      let e3 = {
        ...n2.ext ?? {}
      };
      e3[wu] = t2.origin, n2.ext = e3;
    }
    let r2 = R(t2.type, n2, {
      issuer: t2.holderDid,
      recipient: t2.vtaDid
    });
    try {
      return {
        kind: `accepted`,
        result: await e2.send(r2)
      };
    } catch (e3) {
      let t3 = Eu(e3);
      if (t3) return t3;
      throw e3;
    }
  }
  function Eu(e2) {
    if (!(e2 instanceof _)) return null;
    let t2 = e2.details?.details ?? {};
    if (!((typeof t2.reason == `string` ? t2.reason : void 0) === `auth:consent_required` || Array.isArray(t2.consentRequests))) return null;
    let n2 = typeof t2.payloadDigest == `string` ? t2.payloadDigest : ``;
    return n2 ? {
      kind: `consentRequired`,
      payloadDigest: n2,
      challenge: typeof t2.challenge == `string` ? t2.challenge : ``,
      approverSet: typeof t2.approverSet == `string` ? t2.approverSet : ``,
      minApprovals: typeof t2.minApprovals == `number` ? t2.minApprovals : 1,
      consentRequests: Array.isArray(t2.consentRequests) ? t2.consentRequests : []
    } : null;
  }
  var Du = `https://trusttasks.org/spec/auth/whoami/0.1`, Ou = `https://trusttasks.org/spec/auth/whoami/0.1#response`;
  async function ku(e2, t2) {
    let n2 = t2.now ?? (() => performance.now()), r2 = n2(), i2 = R(Du, {}, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    });
    try {
      return await e2.send(i2, {
        expectedResponseType: Ou,
        operationLabel: `auth/whoami (round-trip check)`,
        ...t2.timeoutMs === void 0 ? {} : {
          timeoutMs: t2.timeoutMs
        }
      }), {
        kind: `answered`,
        ms: Math.round(n2() - r2)
      };
    } catch (e3) {
      let t3 = Math.round(n2() - r2), i3 = e3 instanceof _ ? e3.code : void 0;
      return i3 !== void 0 && !i3.startsWith(`e.client.`) ? {
        kind: `answered`,
        ms: t3,
        refusal: {
          code: i3,
          message: e3 instanceof Error ? e3.message : String(e3)
        }
      } : {
        kind: `failed`,
        ms: t3,
        ...i3 === void 0 ? {} : {
          code: i3
        },
        message: e3 instanceof Error ? e3.message : String(e3)
      };
    }
  }
  async function Au(e2) {
    let { sender: t2, holder: n2, service: r2 } = e2, i2 = e2.subject ?? n2.did;
    if (e2.sessionKey !== void 0 && !kr(e2.sessionKey)) throw new _(`e.client.invalid_session_key`, `sessionKey must be a did:key (did:key:z\u2026), with no fragment`);
    let a2 = await Er(t2, {
      holder: n2,
      service: r2,
      issuer: i2,
      subject: i2,
      purpose: `login`
    }), o2 = await Ar(t2, {
      holder: n2,
      service: r2,
      issuer: i2,
      challenge: a2.challenge,
      sessionId: a2.sessionId,
      ...e2.scope && e2.scope.length > 0 ? {
        scope: e2.scope
      } : {},
      ...e2.sessionKey === void 0 ? {} : {
        sessionKey: e2.sessionKey
      }
    });
    if (e2.sessionKey !== void 0 && o2.session.sessionKey !== e2.sessionKey) throw new _(`e.client.session_key_not_bound`, `the relying party did not bind the requested session key (got ${o2.session.sessionKey ?? `none`})`);
    let s2 = o2.tokens;
    return {
      accessToken: s2.accessToken,
      ...s2.refreshToken ? {
        refreshToken: s2.refreshToken
      } : {},
      sessionId: a2.sessionId,
      expiresIn: s2.expiresIn,
      ...s2.scope && s2.scope.length > 0 ? {
        scope: s2.scope
      } : {},
      ...e2.sessionKey === void 0 ? {} : {
        sessionKey: e2.sessionKey
      }
    };
  }
  var ju = `https://trusttasks.org/spec/auth/step-up/approve-response/0.3`, Mu = `https://trusttasks.org/spec/auth/step-up/approve-response/0.5`, Nu = `https://trusttasks.org/spec/auth/step-up/approve-response/0.5#response`, Pu = `https://trusttasks.org/spec/auth/step-up/approve-request/0.3`, Fu = [
    `https://trusttasks.org/spec/auth/step-up/approve-request/0.2`,
    `https://trusttasks.org/spec/auth/step-up/approve-request/0.1`
  ], Iu = [
    Pu
  ];
  async function Lu(e2, t2) {
    let n2 = (e3) => ({
      ok: false,
      reason: e3
    });
    if (!e2 || typeof e2 != `object`) return n2(`no signed approve-request document`);
    let r2 = e2.type;
    if (typeof r2 != `string` || !t2.acceptTypes.includes(r2)) return n2(`document type ${String(r2)} is not a step-up approve-request this party mints`);
    let i2 = await ft(e2, {
      expectedProofPurpose: `authentication`
    });
    if (!i2.verified || !i2.signer) return n2(i2.reason ?? `proof did not verify`);
    if (typeof e2.issuer != `string` || e2.issuer !== i2.signer) return n2(`issuer does not match the proven signer`);
    if (!t2.enrolledExecutorDids.includes(i2.signer)) return n2(`signed by ${i2.signer}, not an executor this wallet is enrolled with`);
    let a2 = e2.payload ?? {};
    if (typeof a2.subject != `string` || typeof a2.sessionId != `string` || typeof a2.challenge != `string`) return n2(`verified document is missing subject/sessionId/challenge`);
    let o2 = t2.now ?? /* @__PURE__ */ new Date();
    for (let t3 of [
      e2.expiresAt,
      a2.expiresAt
    ]) {
      if (typeof t3 != `string`) continue;
      let e3 = new Date(t3);
      if (Number.isNaN(e3.getTime()) || e3 <= o2) return n2(`approve-request lapsed at ${t3}`);
    }
    return {
      ok: true,
      issuer: i2.signer,
      request: {
        subject: a2.subject,
        sessionId: a2.sessionId,
        challenge: a2.challenge,
        ...typeof a2.reason == `string` ? {
          reason: a2.reason
        } : {}
      },
      ...typeof e2.expiresAt == `string` ? {
        expiresAt: e2.expiresAt
      } : typeof a2.expiresAt == `string` ? {
        expiresAt: a2.expiresAt
      } : {}
    };
  }
  async function Ru(e2) {
    let t2 = e2.approved ? `approved` : `denied`, n2 = {
      subject: e2.request.subject,
      sessionId: e2.request.sessionId,
      challenge: e2.request.challenge,
      decision: t2,
      ...t2 === `denied` && e2.deniedReason ? {
        deniedReason: e2.deniedReason
      } : {}
    }, r2 = {
      id: globalThis.crypto.randomUUID(),
      type: e2.responseVersion === `0.5` ? Mu : ju,
      issuer: e2.signing.did,
      recipient: e2.rpDid,
      issuedAt: (/* @__PURE__ */ new Date()).toISOString(),
      payload: n2
    };
    return await u({
      envelope: r2,
      signing: e2.signing,
      proofPurpose: `assertionMethod`
    }), r2;
  }
  var zu = `https://trusttasks.org/spec/auth/step-up/start/0.1`, Bu = `https://trusttasks.org/spec/auth/step-up/start/0.1#response`, Vu = `https://trusttasks.org/spec/auth/refresh/0.1`, Hu = `https://trusttasks.org/spec/auth/refresh/0.1#response`;
  async function Uu(e2, t2, n2, r2) {
    let i2 = mr(e2.fetchFn), a2 = `${e2.baseUrl.replace(/\/+$/, ``)}/trust-tasks`, o2;
    try {
      o2 = await i2(a2, {
        method: `POST`,
        headers: {
          "content-type": `application/json`,
          authorization: `Bearer ${e2.accessToken}`
        },
        body: JSON.stringify(t2)
      });
    } catch (e3) {
      throw hr(e3) ? new _(`e.client.timeout`, `${r2}: the relying party did not respond within ${pr / 1e3}s`) : new _(`e.client.network`, e3.message);
    }
    return Mr(o2, {
      expectedResponseType: n2,
      operationLabel: r2,
      expectedSigner: e2.rpDid,
      inReplyTo: t2
    });
  }
  async function Wu(e2, t2, n2) {
    let r2 = R(t2, n2, {
      id: `urn:uuid:${globalThis.crypto.randomUUID()}`,
      issuer: e2.signing.did,
      recipient: e2.rpDid
    });
    return await u({
      envelope: r2,
      signing: e2.signing,
      proofPurpose: `authentication`
    }), r2;
  }
  async function Gu(e2) {
    let t2 = (await Uu(e2, await Wu(e2, zu, {
      sessionId: e2.sessionId
    }), Bu, `auth/step-up/start/0.1`)).approveRequest, n2 = await Lu(t2, {
      enrolledExecutorDids: e2.enrolledExecutorDids,
      acceptTypes: Iu,
      ...e2.now ? {
        now: e2.now
      } : {}
    }), r2 = (e3) => {
      throw new _(`e.client.parse`, `step-up approve-request refused: ${e3}`);
    };
    return n2.ok ? (n2.issuer !== e2.rpDid && r2(`issuer ${n2.issuer} is not the relying party ${e2.rpDid}`), t2?.recipient !== e2.signing.did && r2(`it is addressed to ${String(t2?.recipient)}, not this wallet`), n2.request.subject !== e2.signing.did && r2(`it names subject ${n2.request.subject}, not ${e2.signing.did}`), n2.request.sessionId !== e2.sessionId && r2(`it is bound to a different session`), {
      request: n2.request,
      issuer: n2.issuer,
      ...n2.expiresAt === void 0 ? {} : {
        expiresAt: n2.expiresAt
      }
    }) : r2(n2.reason);
  }
  async function Ku(e2) {
    let t2 = await Uu(e2, e2.approval, Nu, `auth/step-up/approve-response/0.5`);
    if (t2.status !== `elevated`) throw new _(`e.client.parse`, `the relying party did not elevate the session (${t2.status}${t2.reason ? `: ${t2.reason}` : ``})`);
    let n2 = await Uu(e2, await Wu(e2, Vu, {
      refreshToken: e2.refreshToken
    }), Hu, `auth/refresh/0.1`);
    if (typeof n2.tokens?.accessToken != `string` || n2.tokens.accessToken === ``) throw new _(`e.client.parse`, `auth/refresh/0.1: the reply carries no access token`);
    return {
      accessToken: n2.tokens.accessToken,
      refreshToken: n2.tokens.refreshToken ?? e2.refreshToken,
      sessionId: n2.session?.id ?? e2.approval.payload.sessionId
    };
  }
  async function qu(e2) {
    let t2 = e2.onMark ?? (() => {
    }), n2;
    try {
      n2 = await Gu(e2);
    } catch (e3) {
      return {
        ok: false,
        error: e3.message,
        declined: false
      };
    }
    if (t2(`rp start (verified approve-request)`), !await e2.requestConsent({
      issuer: n2.issuer,
      subject: n2.request.subject,
      sessionId: n2.request.sessionId,
      ...typeof n2.request.reason == `string` ? {
        reason: n2.request.reason
      } : {}
    })) return {
      ok: false,
      error: `step-up denied by user`,
      declined: true
    };
    t2(`user consent`);
    let r2 = await Ru({
      signing: e2.signing,
      rpDid: e2.rpDid,
      request: n2.request,
      approved: true,
      responseVersion: `0.5`
    });
    t2(`sign approval`);
    let i2 = await Ku({
      ...e2,
      approval: r2
    });
    return t2(`rp finish (elevate + refresh)`), {
      ok: true,
      tokens: i2
    };
  }
  function Ju(e2) {
    let t2 = v(e2.signing), n2 = mr(e2.fetch), r2 = `${e2.baseUrl.replace(/\/+$/, ``)}/trust-tasks`;
    return {
      async send(i2, a2 = {}) {
        let o2 = a2.operationLabel ?? i2.type;
        if (i2.recipient !== e2.rpDid) throw new _(`e.client.identity`, `${o2}: the document is addressed to ${String(i2.recipient)}, not the relying party ${e2.rpDid}`);
        await c(i2, t2);
        let s2;
        try {
          s2 = await n2(r2, {
            method: `POST`,
            headers: {
              "content-type": `application/json`
            },
            body: JSON.stringify(i2)
          });
        } catch (e3) {
          throw hr(e3) ? new _(`e.client.timeout`, `${o2}: the relying party did not respond within ${pr / 1e3}s`) : new _(`e.client.network`, e3.message);
        }
        return Mr(s2, {
          ...a2.expectedResponseType === void 0 ? {} : {
            expectedResponseType: a2.expectedResponseType
          },
          operationLabel: o2,
          expectedSigner: e2.rpDid,
          inReplyTo: i2
        });
      }
    };
  }
  var Yu = `https://trusttasks.org/spec/task-consent/request/0.1`, Xu = {
    $schema: `https://json-schema.org/draft/2020-12/schema`,
    $id: `https://trusttasks.org/spec/task-consent/request/0.1`,
    title: `Task Consent Request \u2014 payload`,
    description: `The executor asks an enrolled approver device to authorize one pending privileged task, presenting the effects it computed by dry-running the real handler against its own prior state. The executor signs this document; the approver renders only what it verifies under that signature.`,
    type: `object`,
    additionalProperties: false,
    required: [
      `challenge`,
      `taskType`,
      `payloadDigest`,
      `sideEffects`,
      `exposure`,
      `effects`,
      `requester`,
      `approverSet`,
      `minApprovals`,
      `excludeRequester`,
      `expiresAt`
    ],
    properties: {
      challenge: {
        type: `string`,
        minLength: 16,
        description: "Per-request nonce (\u2265128 bits entropy) echoed and signed by the matching task-consent/decision. It is also the salt in `payloadDigest`, so a party that holds this request can re-derive the digest and a party that does not cannot invert it."
      },
      taskType: {
        type: `string`,
        format: `uri`,
        description: "Type URI of the task awaiting approval. It is bound into `payloadDigest`: without that binding, two tasks whose payloads canonicalize identically would share a digest, and an approval for a benign task would authorize a destructive one."
      },
      payloadDigest: {
        $ref: `#/$defs/DigestMultibase`,
        description: "The binding between what the approver sees and what executes. Multibase-encoded multihash over the RFC 8785 (JCS) canonicalization of the payload, the task type, and the `challenge` as salt. The decision echoes it; the executor re-derives it from the payload it is about to run and refuses on mismatch. Salted because an unsalted digest over a low-entropy payload is a confirmation oracle for anyone who observes it in transit."
      },
      sideEffects: {
        type: `string`,
        enum: [
          `none`,
          `mutating`,
          `destructive`
        ],
        description: `Authoritative SPEC \xA77.3 item 13 side-effect class of the pending task, derived by the executor from the compiled handler it is about to invoke. NEVER taken from the registry: a registry that decided this would be a consent kill-switch, downgradeable by publishing a new version with a weaker class.`
      },
      exposure: {
        $ref: `#/$defs/Exposure`
      },
      effects: {
        type: `array`,
        description: "What executing this task will actually do, computed by dry-running the real handler against the executor's prior state. MAY be empty when the executor has no dry-run for this handler \u2014 in which case `consequences` carries the specification's static fallback text. When BOTH are empty the surface MUST tell the approver the consequences could not be determined, and MUST NOT present the task as though it had none.",
        items: {
          $ref: `#/$defs/Effect`
        }
      },
      consequences: {
        type: `array`,
        description: "Static, human-facing second-order effects declared in the task's specification (SPEC \xA77.3 item 13). A fallback for handlers with no dry-run \u2014 per-task, not per-request, so it can say 'any document change rotates the update keys' but not which keys. Prefer `effects`.",
        items: {
          type: `string`,
          minLength: 1,
          maxLength: 500
        }
      },
      subject: {
        type: `string`,
        description: "OPTIONAL identifier the task acts on \u2014 the value at the specification's `subjectPath`, usually a DID. Absent for subjectless tasks."
      },
      requester: {
        type: `string`,
        description: "DID that submitted the pending task. Shown to the approver, and compared against the approver when `excludeRequester` is set."
      },
      requesterDeviceId: {
        type: `string`,
        description: `OPTIONAL enrolled device the task was submitted from.`
      },
      origin: {
        type: `string`,
        description: `OPTIONAL web origin that proposed the task, when it arrived via a relying party. This MUST be the origin the consumer's own runtime attested (e.g. the browser-supplied sender origin) \u2014 never a value the proposing page supplied, and never one the relying party could author.`
      },
      note: {
        type: `string`,
        minLength: 1,
        maxLength: 500,
        description: "OPTIONAL requester-authored display text \u2014 the one member of this payload whose prose the executor did NOT author, carried verbatim for context ('why I am asking'). EXPLICITLY UNTRUSTED: it is written by the least trusted party in the system and MUST NOT be treated as a statement of the task's effects. A surface that renders it MUST attribute it to `requester`, MUST present it visually distinct from `effects`, and MUST NOT let it substitute for, reorder, or obscure them. The executor's signature on this document attests only that the requester supplied this text, never that it is true."
      },
      statePin: {
        $ref: `#/$defs/StatePin`
      },
      approverSet: {
        type: `string`,
        description: "Name of the approver set the policy's `requireConsent` named."
      },
      minApprovals: {
        type: `integer`,
        minimum: 1,
        description: `Distinct approvals from the set required before the task may execute.`
      },
      excludeRequester: {
        type: `boolean`,
        description: "When true, `requester` may not count toward the threshold \u2014 so a single compromised device cannot both propose and approve. A surface MUST NOT offer to approve a request whose `requester` is its own subject when this is set."
      },
      expiresAt: {
        type: `string`,
        format: `date-time`,
        description: `After this instant the pending request lapses and no decision is accepted for it.`
      },
      ext: {
        $ref: `#/$defs/Ext`
      }
    },
    $defs: {
      Response: {
        $anchor: `response`,
        title: `Task Consent Request \u2014 response payload`,
        description: `Synchronous acknowledgement from the approver device that a prompt was raised. The decision itself arrives separately as a task-consent/decision \u2014 a human is in the loop, so it cannot be a synchronous reply.`,
        type: `object`,
        additionalProperties: false,
        required: [
          `status`
        ],
        properties: {
          status: {
            type: `string`,
            enum: [
              `prompted`,
              `refused`
            ],
            description: "`prompted` = the request was verified and an approval prompt raised. `refused` = the device will not prompt; `reason` MUST be set."
          },
          reason: {
            type: `string`,
            maxLength: 1024,
            description: "REQUIRED when status is `refused`."
          },
          ext: {
            $ref: `#/$defs/Ext`
          }
        }
      },
      Ext: {
        title: `Ext`,
        description: `Vendor-namespaced extension object per SPEC.md \xA74.5.1. Each immediate key MUST be a reverse-DNS namespace; structure under each namespace is opaque to the framework.`,
        type: `object`,
        minProperties: 1,
        additionalProperties: true,
        propertyNames: {
          pattern: `^[a-z][a-z0-9-]*(\\.[a-z0-9-]+)+$`
        }
      },
      StatePin: {
        title: `StatePin`,
        description: `The prior state the effects were computed against. A human in the loop makes the approval window minutes wide, so the state can move underneath a pending approval. The executor asserts this pin still holds at execution and refuses otherwise \u2014 without it, a lost update silently executes against state the approver never saw.`,
        type: `object`,
        additionalProperties: false,
        required: [
          `resource`,
          `version`
        ],
        properties: {
          resource: {
            type: `string`,
            minLength: 1,
            description: `Identifier of the pinned resource (usually the subject DID).`
          },
          version: {
            type: `string`,
            minLength: 1,
            description: "Opaque version identifier of the prior state (e.g. a did:webvh `versionId`). Compared for equality at execution; the executor MUST NOT attempt to order or interpret it."
          }
        }
      },
      Effect: {
        title: `Effect`,
        description: `One consequence of executing the pending task, authored by the executor that is about to run it. An effect is produced by dry-running the real handler against the executor's own prior state \u2014 never by the requester, and never by re-implementing the handler's semantics elsewhere. A consent surface renders ONLY effects it received under the executor's signature.`,
        type: `object`,
        additionalProperties: false,
        required: [
          `kind`,
          `summary`
        ],
        properties: {
          kind: {
            type: `string`,
            pattern: `^[a-z][a-zA-Z0-9]*$`,
            description: "Machine discriminator for rich rendering. Well-known kinds are registered in the prose (`documentChange`, `keyRotation`, `preRotationRefresh`, `resourceDelete`, `disclosure`), but the set is OPEN: handlers evolve faster than this schema, and an executor MUST be able to describe a consequence this version does not name. A surface that does not recognise a `kind` MUST still render `summary`."
          },
          summary: {
            type: `string`,
            minLength: 1,
            maxLength: 500,
            description: "REQUIRED human-facing sentence describing this consequence, authored by the executor. This is the ONLY member a consent surface is guaranteed to be able to render, and it is what makes an unrecognised `kind` degrade to something truthful rather than something invisible. A surface MUST render it verbatim; it MUST NOT substitute its own prose."
          },
          path: {
            type: `string`,
            description: "OPTIONAL RFC 6901 JSON Pointer locating the change within the subject resource (e.g. `/service/0`)."
          },
          before: {
            description: "OPTIONAL prior value at `path`, from the executor's authoritative state. ABSENT means there was no prior value (a creation); an explicit `null` is treated identically, so an executor MUST NOT rely on the two being distinguishable. Structured members are for rich rendering only \u2014 `summary` is what a surface is obliged to show, and it is where an executor states a distinction this shape cannot carry."
          },
          after: {
            description: "OPTIONAL resulting value at `path` once the task executes. ABSENT means the value is removed (a deletion), under the same rule as `before`."
          },
          detail: {
            type: `object`,
            description: 'OPTIONAL kind-specific structured extras (e.g. `{ "commitments": 2 }` for `preRotationRefresh`).',
            additionalProperties: true
          }
        }
      },
      Exposure: {
        title: `Exposure`,
        description: `The authoritative SPEC \xA77.3 item 14 exposure class of the pending task, derived by the executor from the compiled handler it is about to invoke \u2014 never from the registry's declared value.`,
        type: `object`,
        additionalProperties: false,
        required: [
          `discloses`,
          `actsAsSubject`
        ],
        properties: {
          discloses: {
            type: `string`,
            enum: [
              `none`,
              `metadata`,
              `secret`
            ],
            description: `Sensitivity of data the task returns to its caller.`
          },
          actsAsSubject: {
            type: `boolean`,
            description: `Whether execution exercises the subject's own authority to produce an attributable effect in the subject's name.`
          }
        }
      },
      DigestMultibase: {
        title: `DigestMultibase`,
        description: 'A cryptographic digest as a multibase-encoded multihash \u2014 the encoding the W3C Verifiable Credentials Data Model 2.0 defines for `digestMultibase`, and the one `did:webvh` uses for its SCID and entry hashes.\n\nMultihash carries the hash algorithm in-band, so the value is self-describing and the wire format survives an algorithm change without a schema revision; multibase does the same for the base encoding, so a verifier never infers base58 from base64url by context. A bare hex string or a `sha-256:`-style prefix hard-codes one algorithm into the wire contract and is non-conforming here.\n\nThis definition constrains the *encoding only*. What the digest is computed over is stated by each referencing field, because it differs legitimately: a digest over a JSON document is taken over its RFC 8785 (JCS) canonicalization, while a digest over an opaque artifact is taken over its bytes. A field whose input is a JSON document and which does not name a canonicalization is not reproducible.\n\nRestricted to the two multibase headers W3C Controlled Identifiers 1.0 \xA72.4 normatively requires \u2014 `z` (base58btc) and `u` (base64url-no-pad). CID permits others but states that "interoperability is not guaranteed between implementations using such values", and a registry whose purpose is interoperability should not mint digests a conforming verifier may be unable to read. The alphabets are enforced rather than assumed: base58btc excludes 0, O, I and l, and an earlier permissive pattern let three published examples carry digests that were not valid base58 at all. base58btc is RECOMMENDED, for consistency with `did:key` and `did:webvh`.',
        type: `string`,
        minLength: 16,
        pattern: `^(z[1-9A-HJ-NP-Za-km-z]+|u[A-Za-z0-9_-]+)$`,
        examples: [
          `zQmbWqxBEKC3P8tqsKc98xmWNzrzDtRLMiMPL8wBuTGsMnR`
        ]
      }
    }
  }, Zu = `https://trusttasks.org/spec/task-consent/decision/0.1`, Qu = {
    $schema: `https://json-schema.org/draft/2020-12/schema`,
    $ref: `#/$defs/Response`,
    $defs: {
      Response: {
        $anchor: `response`,
        title: `Task Consent Decision \u2014 response payload`,
        description: `Acknowledgement of the recorded decision, and whether the approval threshold is now met.`,
        type: `object`,
        additionalProperties: false,
        required: [
          `status`,
          `payloadDigest`
        ],
        properties: {
          status: {
            type: `string`,
            enum: [
              `granted`,
              `pending`,
              `denied`
            ],
            description: "`granted` = the threshold is met and the requester's re-submit will now execute. `pending` = the approval was recorded but more are needed. `denied` = the request was aborted."
          },
          payloadDigest: {
            $ref: `#/$defs/DigestMultibase`,
            description: "The digest this decision concerned, in the encoding `task-consent/request` carried it."
          },
          approvals: {
            type: `integer`,
            minimum: 0,
            description: `Distinct approvals recorded so far.`
          },
          needed: {
            type: `integer`,
            minimum: 1,
            description: "Distinct approvals required. Present when status is `pending`."
          },
          ext: {
            $ref: `#/$defs/Ext`
          }
        }
      },
      Ext: {
        title: `Ext`,
        description: `Vendor-namespaced extension object per SPEC.md \xA74.5.1. Each immediate key MUST be a reverse-DNS namespace; structure under each namespace is opaque to the framework.`,
        type: `object`,
        minProperties: 1,
        additionalProperties: true,
        propertyNames: {
          pattern: `^[a-z][a-z0-9-]*(\\.[a-z0-9-]+)+$`
        }
      },
      DigestMultibase: {
        title: `DigestMultibase`,
        description: 'A cryptographic digest as a multibase-encoded multihash \u2014 the encoding the W3C Verifiable Credentials Data Model 2.0 defines for `digestMultibase`, and the one `did:webvh` uses for its SCID and entry hashes.\n\nMultihash carries the hash algorithm in-band, so the value is self-describing and the wire format survives an algorithm change without a schema revision; multibase does the same for the base encoding, so a verifier never infers base58 from base64url by context. A bare hex string or a `sha-256:`-style prefix hard-codes one algorithm into the wire contract and is non-conforming here.\n\nThis definition constrains the *encoding only*. What the digest is computed over is stated by each referencing field, because it differs legitimately: a digest over a JSON document is taken over its RFC 8785 (JCS) canonicalization, while a digest over an opaque artifact is taken over its bytes. A field whose input is a JSON document and which does not name a canonicalization is not reproducible.\n\nRestricted to the two multibase headers W3C Controlled Identifiers 1.0 \xA72.4 normatively requires \u2014 `z` (base58btc) and `u` (base64url-no-pad). CID permits others but states that "interoperability is not guaranteed between implementations using such values", and a registry whose purpose is interoperability should not mint digests a conforming verifier may be unable to read. The alphabets are enforced rather than assumed: base58btc excludes 0, O, I and l, and an earlier permissive pattern let three published examples carry digests that were not valid base58 at all. base58btc is RECOMMENDED, for consistency with `did:key` and `did:webvh`.',
        type: `string`,
        minLength: 16,
        pattern: `^(z[1-9A-HJ-NP-Za-km-z]+|u[A-Za-z0-9_-]+)$`,
        examples: [
          `zQmbWqxBEKC3P8tqsKc98xmWNzrzDtRLMiMPL8wBuTGsMnR`
        ]
      },
      Decision: {
        title: `Decision`,
        type: `string`,
        enum: [
          `approve`,
          `deny`
        ],
        description: "The approver's answer. `deny` aborts the pending request; a subsequent submit of the same task starts a fresh one."
      }
    }
  }, $u = `https://trusttasks.org/spec/task-consent/granted/0.1`, ed = Yu, td = Zu, nd = $u, rd = `${td}#response`;
  async function id(e2, t2) {
    if (e2.type !== `https://trusttasks.org/binding/didcomm/0.1/envelope` || !t2.senderDid || t2.senderDid !== t2.expectedExecutorDid) return null;
    let n2 = e2.body ?? {};
    if (!ie(n2.type) && n2.type !== rd || n2.issuer !== void 0 && n2.issuer !== t2.expectedExecutorDid || n2.type === rd && n2.proof === void 0) return null;
    if (n2.proof !== void 0) {
      let e3 = await ft(n2, {
        expectedProofPurpose: `authentication`,
        ...t2.resolveDid ? {
          resolveDid: t2.resolveDid
        } : {}
      });
      if (!e3.verified || e3.signer !== t2.expectedExecutorDid || n2.issuer !== t2.expectedExecutorDid) return null;
    }
    let r2 = ad(e2);
    if (ie(n2.type)) {
      let e3 = n2.payload ?? {};
      return {
        accepted: false,
        code: typeof e3.code == `string` ? e3.code : `unknown`,
        ...typeof e3.message == `string` ? {
          message: e3.message
        } : {},
        retryable: e3.retryable === true,
        ...e3.details === void 0 ? {} : {
          details: e3.details
        },
        ...r2 ? {
          thid: r2
        } : {}
      };
    }
    if (n2.type === rd) {
      let e3 = qi(Qu, n2.payload);
      if (!e3.valid) return {
        accepted: false,
        code: `malformedRequest`,
        message: `the executor's decision response does not satisfy ${rd} \u2014 ${Ji(e3.violations)}`,
        retryable: false,
        ...r2 ? {
          thid: r2
        } : {}
      };
      let t3 = n2.payload;
      return {
        accepted: true,
        status: typeof t3.status == `string` ? t3.status : `unknown`,
        ...typeof t3.approvals == `number` ? {
          approvals: t3.approvals
        } : {},
        ...typeof t3.needed == `number` ? {
          needed: t3.needed
        } : {},
        ...typeof t3.payloadDigest == `string` ? {
          payloadDigest: t3.payloadDigest
        } : {},
        ...r2 ? {
          thid: r2
        } : {}
      };
    }
    return null;
  }
  function ad(e2) {
    let t2 = e2.body ?? {};
    return (typeof e2.thid == `string` ? e2.thid : void 0) ?? (typeof t2.threadId == `string` ? t2.threadId : void 0);
  }
  function od(e2, t2, n2) {
    if (e2.type !== `https://trusttasks.org/binding/didcomm/0.1/envelope` || !n2 || n2 !== t2) return null;
    let r2 = e2.body ?? {};
    if (r2.type !== nd || typeof r2.issuer == `string` && r2.issuer !== t2) return null;
    let i2 = r2.payload?.payloadDigest;
    return typeof i2 == `string` ? {
      payloadDigest: i2
    } : null;
  }
  async function sd(e2, t2) {
    let n2 = (e3, t3) => ({
      ok: false,
      reason: e3,
      ...t3 ? {
        detail: t3
      } : {}
    });
    if (e2.type !== `https://trusttasks.org/binding/didcomm/0.1/envelope`) return n2(`not-a-task-consent-request`);
    let r2 = e2.body ?? {};
    if (r2.type !== ed) return n2(`not-a-task-consent-request`);
    let i2 = await ft(r2, {
      expectedProofPurpose: `authentication`
    });
    if (!i2.verified) return n2(`untrusted_issuer`, i2.reason ?? `proof did not verify`);
    if (!i2.signer || !t2.enrolledExecutorDids.includes(i2.signer)) return n2(`untrusted_issuer`, `signed by ${i2.signer ?? `an unknown key`}, not an executor this device is enrolled with`);
    if (typeof r2.issuer == `string` && r2.issuer !== i2.signer) return n2(`untrusted_issuer`, `issuer does not match the proven signer`);
    if (typeof r2.recipient != `string`) return n2(`untrusted_issuer`, `request names no recipient, so it cannot be shown to be addressed to this device`);
    if (r2.recipient !== t2.holderDid) return n2(`untrusted_issuer`, `request is addressed to another device`);
    let a2 = (t2.validatePayload ?? qi)(Xu, r2.payload);
    if (!a2.valid) return n2(`malformed-payload`, `payload does not satisfy ${ed} \u2014 ${Ji(a2.violations)}`);
    let o2 = r2.payload, s2 = t2.now ?? /* @__PURE__ */ new Date(), c2 = new Date(o2.expiresAt);
    if (Number.isNaN(c2.getTime()) || c2 <= s2) return n2(`expired`, `request lapsed at ${o2.expiresAt}`);
    if (o2.excludeRequester && o2.requester === t2.holderDid) return n2(`not_eligible`, `this device proposed the task and may not approve it`);
    let l2 = (typeof e2.thid == `string` ? e2.thid : void 0) ?? (typeof r2.id == `string` ? r2.id : void 0) ?? (typeof e2.id == `string` ? e2.id : ``);
    return {
      ok: true,
      parsed: {
        executorDid: i2.signer,
        thid: l2,
        request: o2
      }
    };
  }
  async function cd(e2) {
    let t2 = {
      id: `urn:uuid:${crypto.randomUUID()}`,
      type: td,
      issuer: e2.signing.did,
      recipient: e2.vta.did,
      issuedAt: (/* @__PURE__ */ new Date()).toISOString(),
      payload: {
        challenge: e2.challenge,
        payloadDigest: e2.payloadDigest,
        decision: e2.decision,
        ...e2.reason ? {
          reason: e2.reason
        } : {}
      }
    };
    return await u({
      envelope: t2,
      signing: e2.signing,
      proofPurpose: C(td)
    }), t2;
  }
  async function ld(e2) {
    let t2 = e2.sender ?? e2.holder;
    if (t2.did !== e2.signing.did) throw Error(`task-consent/decision: sent as ${t2.did} but signed as ${e2.signing.did}. The executor requires the document's signer to be its sender; send it as the signer`);
    let n2 = await cd(e2), r2 = {
      id: n2.id,
      type: s,
      from: t2.did,
      to: [
        e2.vta.did
      ],
      thid: e2.thid,
      body: n2
    }, i2 = await Ve(r2, t2, [
      {
        kid: e2.vta.keyAgreementKid,
        jwk: e2.vta.keyAgreementPublicJwk
      }
    ]), a2 = We(e2.vta.did, e2.holder.did, e2.mediator.did, i2);
    return {
      packed: await Fe(a2, e2.holder, [
        {
          kid: e2.mediator.keyAgreementKid,
          jwk: e2.mediator.keyAgreementPublicJwk
        }
      ]),
      id: n2.id
    };
  }
  function ud(e2) {
    return typeof e2 != `object` || !e2 ? JSON.stringify(e2) ?? `null` : Array.isArray(e2) ? `[${e2.map((e3) => ud(e3)).join(`,`)}]` : `{${Object.entries(e2).filter(([, e3]) => e3 !== void 0).sort(([e3], [t2]) => e3 < t2 ? -1 : +(e3 > t2)).map(([e3, t2]) => `${JSON.stringify(e3)}:${ud(t2)}`).join(`,`)}}`;
  }
  var dd = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]), fd = (e2, t2) => e2 >>> t2 | e2 << 32 - t2;
  function pd(e2) {
    let t2 = [];
    for (let n2 = 0; n2 < e2.length; n2++) {
      let r2 = e2.charCodeAt(n2);
      if (r2 >= 55296 && r2 <= 56319 && n2 + 1 < e2.length) {
        let t3 = e2.charCodeAt(n2 + 1);
        t3 >= 56320 && t3 <= 57343 && (r2 = 65536 + (r2 - 55296 << 10) + (t3 - 56320), n2++);
      }
      r2 >= 55296 && r2 <= 57343 && (r2 = 65533), r2 < 128 ? t2.push(r2) : r2 < 2048 ? t2.push(192 | r2 >> 6, 128 | r2 & 63) : r2 < 65536 ? t2.push(224 | r2 >> 12, 128 | r2 >> 6 & 63, 128 | r2 & 63) : t2.push(240 | r2 >> 18, 128 | r2 >> 12 & 63, 128 | r2 >> 6 & 63, 128 | r2 & 63);
    }
    return Uint8Array.from(t2);
  }
  function md(e2) {
    let t2 = pd(e2), n2 = t2.length * 8, r2 = new Uint8Array(Math.ceil((t2.length + 9) / 64) * 64);
    r2.set(t2), r2[t2.length] = 128;
    let i2 = new DataView(r2.buffer);
    i2.setUint32(r2.length - 8, Math.floor(n2 / 4294967296), false), i2.setUint32(r2.length - 4, n2 >>> 0, false);
    let a2 = new Uint32Array([
      1779033703,
      3144134277,
      1013904242,
      2773480762,
      1359893119,
      2600822924,
      528734635,
      1541459225
    ]), o2 = new Uint32Array(64);
    for (let e3 = 0; e3 < r2.length; e3 += 64) {
      for (let t4 = 0; t4 < 16; t4++) o2[t4] = i2.getUint32(e3 + t4 * 4, false);
      for (let e4 = 16; e4 < 64; e4++) {
        let t4 = fd(o2[e4 - 15], 7) ^ fd(o2[e4 - 15], 18) ^ o2[e4 - 15] >>> 3, n4 = fd(o2[e4 - 2], 17) ^ fd(o2[e4 - 2], 19) ^ o2[e4 - 2] >>> 10;
        o2[e4] = o2[e4 - 16] + t4 + o2[e4 - 7] + n4 >>> 0;
      }
      let [t3, n3, r3, s2, c2, l2, u2, d2] = [
        a2[0],
        a2[1],
        a2[2],
        a2[3],
        a2[4],
        a2[5],
        a2[6],
        a2[7]
      ];
      for (let e4 = 0; e4 < 64; e4++) {
        let i3 = fd(c2, 6) ^ fd(c2, 11) ^ fd(c2, 25), a3 = c2 & l2 ^ ~c2 & u2, f3 = d2 + i3 + a3 + dd[e4] + o2[e4] >>> 0, p2 = (fd(t3, 2) ^ fd(t3, 13) ^ fd(t3, 22)) + (t3 & n3 ^ t3 & r3 ^ n3 & r3) >>> 0;
        d2 = u2, u2 = l2, l2 = c2, c2 = s2 + f3 >>> 0, s2 = r3, r3 = n3, n3 = t3, t3 = f3 + p2 >>> 0;
      }
      let f2 = [
        t3,
        n3,
        r3,
        s2,
        c2,
        l2,
        u2,
        d2
      ];
      for (let e4 = 0; e4 < 8; e4++) a2[e4] = a2[e4] + f2[e4] >>> 0;
    }
    return Array.from(a2, (e3) => e3.toString(16).padStart(8, `0`)).join(``);
  }
  function hd(e2) {
    return md(ud(e2));
  }
  var gd = `inbound:claims/v2`, _d = 256;
  async function vd(e2, t2) {
    let n2 = yd(t2);
    if (n2 === void 0) return `fresh`;
    let r2 = hd(t2), i2 = await e2.get(gd) ?? [], a2 = i2.find(([e3]) => e3 === n2);
    return a2 ? a2[1] === r2 ? `duplicate` : `conflict` : (i2.push([
      n2,
      r2
    ]), i2.length > _d && i2.splice(0, i2.length - _d), await e2.put(gd, i2), `fresh`);
  }
  function yd(e2) {
    if (typeof e2 != `object` || !e2) return;
    let t2 = e2.id;
    return typeof t2 == `string` && t2.length > 0 ? t2 : void 0;
  }
  var bd = class {
    #e;
    #t;
    #n = /* @__PURE__ */ new Map();
    constructor(e2) {
      this.#e = e2, this.#t = e2.timers ?? {
        setTimeout: (e3, t2) => setTimeout(e3, t2),
        clearTimeout: (e3) => clearTimeout(e3)
      };
    }
    schedule(e2) {
      if (this.#e.shouldRetry && !this.#e.shouldRetry(e2)) {
        this.clear(e2);
        return;
      }
      let t2 = this.#n.get(e2) ?? {
        delayMs: this.#e.baseMs,
        timer: void 0
      };
      t2.timer || (t2.timer = this.#t.setTimeout(() => {
        t2.timer = void 0, this.#e.attempt(e2).then((n2) => {
          if (n2) {
            this.clear(e2);
            return;
          }
          if (this.#e.shouldRetry && !this.#e.shouldRetry(e2)) {
            this.clear(e2);
            return;
          }
          this.#n.get(e2) === t2 && (t2.delayMs = Math.min(t2.delayMs * 2, this.#e.maxMs), this.schedule(e2));
        });
      }, t2.delayMs), this.#n.set(e2, t2));
    }
    clear(e2) {
      let t2 = this.#n.get(e2);
      t2?.timer && this.#t.clearTimeout(t2.timer), this.#n.delete(e2);
    }
    clearAll() {
      for (let e2 of [
        ...this.#n.keys()
      ]) this.clear(e2);
    }
    pendingDelayMs(e2) {
      return this.#n.get(e2)?.delayMs;
    }
    isArmed(e2) {
      return this.#n.get(e2)?.timer !== void 0;
    }
  }, xd = `inbound:pending`, Sd = 64;
  async function Cd(e2, t2) {
    let n2 = await e2.get(xd) ?? [], r2 = n2.find((e3) => e3.id === t2.id), i2 = {
      id: t2.id,
      message: t2.message,
      senderDid: t2.senderDid,
      vtaDid: t2.vtaDid,
      isApprover: t2.isApprover,
      receivedAt: r2?.receivedAt ?? t2.receivedAt ?? Date.now()
    }, a2 = n2.filter((e3) => e3.id !== t2.id);
    a2.push(i2), a2.length > Sd && a2.splice(0, a2.length - Sd), await e2.put(xd, a2);
  }
  async function wd(e2) {
    return await e2.get(xd) ?? [];
  }
  async function Td(e2, t2) {
    let n2 = await e2.get(xd) ?? [], r2 = n2.filter((e3) => e3.id !== t2);
    r2.length !== n2.length && await e2.put(xd, r2);
  }
  var Ed = `org.openvtc.authorization-context`, Dd = `https://openvtc.org/persona/authorization-context/0.1`, Od = `disclose`;
  function kd(e2, t2) {
    return {
      subject: e2.subject,
      sessionId: e2.sessionId,
      challenge: e2.challenge,
      decision: t2 ? `approved` : `denied`,
      grantedAcr: `aal2`
    };
  }
  var Ad = `https://trusttasks.org/spec/auth/step-up/approve-response/0.3`;
  async function jd(e2, t2) {
    let n2 = await Lu(e2.unverifiedApproveRequest, {
      ...t2,
      acceptTypes: Fu
    });
    if (!n2.ok) return n2;
    let r2 = (e2.unverifiedApproveRequest.payload ?? {}).ext?.[Ed] ?? {};
    if (r2.type !== Dd) return {
      ok: false,
      reason: `authorization context is ${String(r2.type)}, not a disclosure`
    };
    let i2 = r2.action ?? {};
    if (i2.kind !== Od) return {
      ok: false,
      reason: `authorization context action is ${String(i2.kind)}, not a disclosure`
    };
    if (i2.previewId !== e2.previewId) return {
      ok: false,
      reason: `the signed approve-request names a different preview than the refusal did \u2014 refusing rather than approving a disclosure the holder was not shown`
    };
    let a2 = Array.isArray(i2.claimTypes) ? i2.claimTypes.filter((e3) => typeof e3 == `string`) : [];
    return {
      ok: true,
      request: n2.request,
      issuer: n2.issuer,
      context: {
        claimTypes: a2,
        ...typeof r2.summary == `string` ? {
          summary: r2.summary
        } : {},
        ...typeof i2.verifierDid == `string` ? {
          verifierDid: i2.verifierDid
        } : {},
        ...typeof i2.purpose == `string` ? {
          purpose: i2.purpose
        } : {}
      }
    };
  }
  async function Md(e2, t2, n2 = 50) {
    let r2 = [], i2;
    for (let a2 = 0; a2 < n2; a2 += 1) {
      let n3 = await t2(i2);
      if (r2.push(...n3.items), n3.nextCursor === void 0) return r2;
      if (n3.nextCursor === i2) throw Error(`${e2}: your agent returned the same page cursor twice, so the listing cannot be finished`);
      i2 = n3.nextCursor;
    }
    throw Error(`${e2}: still more after ${n2} pages \u2014 refusing to keep asking, because a listing this long is an agent misbehaving rather than a pool this size`);
  }
  var Nd = `https://trusttasks.org/spec/vault/list/0.3`, Pd = `https://trusttasks.org/spec/vault/list/0.3#response`;
  async function Fd(e2, t2) {
    let n2 = R(Nd, t2.filter ?? {}, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    }), r2 = await e2.send(n2, {
      expectedResponseType: Pd,
      operationLabel: `vault/list/0.3`
    });
    return {
      entries: r2.entries ?? [],
      truncated: r2.truncated ?? false,
      ...r2.cursor ? {
        cursor: r2.cursor
      } : {},
      ...r2.redactedFields ? {
        redactedFields: r2.redactedFields
      } : {}
    };
  }
  var Id = `https://trusttasks.org/spec/vault/upsert/0.3`, Ld = `https://trusttasks.org/spec/vault/upsert/0.3#response`, Rd = `https://openvtc.org/vault/upsert/secret-envelope/1.0`;
  async function zd(e2, t2) {
    let n2;
    t2.secret && (n2 = {
      envelope: `didcommAuthcrypt`,
      jwe: await Bd({
        secret: t2.secret,
        holder: t2.holder,
        service: t2.service
      })
    });
    let r2 = {
      ...t2.id ? {
        id: t2.id
      } : {},
      ...t2.expectedVersion === void 0 ? {} : {
        expectedVersion: t2.expectedVersion
      },
      contextId: t2.contextId,
      targets: t2.targets,
      label: t2.label,
      secretKind: t2.secretKind,
      ...t2.tags ? {
        tags: t2.tags
      } : {},
      ...t2.notes === void 0 ? {} : {
        notes: t2.notes
      },
      ...t2.favicon ? {
        favicon: t2.favicon
      } : {},
      ...t2.selectors ? {
        selectors: t2.selectors
      } : {},
      ...t2.customFieldNames ? {
        customFieldNames: t2.customFieldNames
      } : {},
      ...t2.expiresAt ? {
        expiresAt: t2.expiresAt
      } : {},
      ...n2 ? {
        sealedSecret: n2
      } : {},
      ...t2.clearFields ? {
        clearFields: t2.clearFields
      } : {}
    }, i2 = R(Id, r2, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    });
    return e2.send(i2, {
      expectedResponseType: Ld,
      operationLabel: `vault/upsert/0.3`
    });
  }
  async function Bd(e2) {
    let t2 = {
      id: globalThis.crypto.randomUUID(),
      type: Rd,
      from: e2.holder.did,
      to: [
        e2.service.did
      ],
      body: e2.secret
    };
    return Ve(t2, e2.holder, [
      {
        kid: e2.service.keyAgreementKid,
        jwk: e2.service.keyAgreementPublicJwk
      }
    ]);
  }
  var Vd = `https://trusttasks.org/spec/vault/delete/0.1`, Hd = `https://trusttasks.org/spec/vault/delete/0.1#response`;
  async function Ud(e2, t2) {
    let n2 = R(Vd, {
      id: t2.id,
      ...t2.expectedVersion === void 0 ? {} : {
        expectedVersion: t2.expectedVersion
      },
      ...t2.reason ? {
        reason: t2.reason
      } : {}
    }, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    });
    return e2.send(n2, {
      expectedResponseType: Hd,
      operationLabel: `vault/delete/0.1`
    });
  }
  var Wd = `https://trusttasks.org/spec/vault/release/0.2`, Gd = `https://trusttasks.org/spec/vault/release/0.2#response`;
  async function Kd(e2, t2) {
    let n2 = R(Wd, {
      entryId: t2.entryId,
      ...t2.ttlSecondsHint === void 0 ? {} : {
        ttlSecondsHint: t2.ttlSecondsHint
      }
    }, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    }), r2 = await e2.send(n2, {
      expectedResponseType: Gd,
      operationLabel: `vault/release/0.2`
    });
    if (r2.sealedSecret.envelope !== `didcommAuthcrypt` && r2.sealedSecret.envelope !== `didcomm-authcrypt`) throw Error(`vault/release: unsupported envelope ${r2.sealedSecret.envelope} \u2014 this wallet only understands didcommAuthcrypt`);
    let i2 = await Ie({
      input: r2.sealedSecret.jwe,
      sender_public_jwk: t2.service.keyAgreementPublicJwk
    }, t2.holder);
    if (i2.kind !== `encrypted`) throw Error(`vault/release: unpacked JWE was not authcrypt-encrypted (kind=${i2.kind})`);
    if (!i2.authenticated) throw Error(`vault/release: unpacked JWE was not authenticated (anoncrypt downgrade)`);
    let a2 = i2.message.body;
    if (!a2 || typeof a2 != `object`) throw Error(`vault/release: unpacked DIDComm message has no body`);
    return {
      secret: a2,
      secretKind: r2.secretKind,
      ttlSeconds: r2.ttlSeconds
    };
  }
  async function qd(e2, t2) {
    let n2 = R(rr, {
      entryId: t2.entryId,
      ...t2.target === void 0 ? {} : {
        target: t2.target
      },
      ...t2.nonce === void 0 ? {} : {
        nonce: t2.nonce
      },
      ...t2.ttlSecondsHint === void 0 ? {} : {
        ttlSecondsHint: t2.ttlSecondsHint
      }
    }, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    }), r2 = await e2.send(n2, {
      expectedResponseType: ir,
      operationLabel: `vault/proxy-login/0.2`
    });
    if (r2.sealedSessionBlob.envelope !== `didcommAuthcrypt` && r2.sealedSessionBlob.envelope !== `didcomm-authcrypt`) throw Error(`vault/proxy-login: unsupported envelope ${r2.sealedSessionBlob.envelope} \u2014 this wallet only understands didcommAuthcrypt`);
    let i2 = await Ie({
      input: r2.sealedSessionBlob.jwe,
      sender_public_jwk: t2.service.keyAgreementPublicJwk
    }, t2.holder);
    if (i2.kind !== `encrypted`) throw Error(`vault/proxy-login: unpacked JWE was not authcrypt-encrypted (kind=${i2.kind})`);
    if (!i2.authenticated) throw Error(`vault/proxy-login: unpacked JWE was not authenticated (anoncrypt downgrade)`);
    let a2 = i2.message.body;
    if (!a2 || typeof a2 != `object`) throw Error(`vault/proxy-login: unpacked DIDComm message has no body`);
    return {
      sessionBlob: a2,
      sessionId: r2.sessionId,
      expiresAt: r2.expiresAt
    };
  }
  var Jd = `https://trusttasks.org/spec/vault/credentials/receive/0.1`, Yd = `https://trusttasks.org/spec/vault/credentials/receive/0.1#response`;
  async function Xd(e2, t2) {
    let n2 = R(Jd, {
      credential: t2.credential,
      ...t2.id ? {
        id: t2.id
      } : {},
      ...t2.contextId ? {
        contextId: t2.contextId
      } : {},
      ...t2.format ? {
        format: t2.format
      } : {}
    }, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    });
    return e2.send(n2, {
      expectedResponseType: Yd,
      operationLabel: `vault/credentials/receive/0.1`
    });
  }
  function Zd(e2) {
    return {
      did: e2.did,
      sign: async (t2) => {
        let { signedEnvelope: n2 } = await f(e2.session, {
          holder: e2.holder,
          service: e2.service,
          entryId: e2.entryId,
          unsignedEnvelope: t2
        }), r2 = n2.proof;
        if (!r2) throw Error(`vault/sign-trust-task: the VTA returned an envelope with no proof for ${e2.did}`);
        t2.proof = r2;
      }
    };
  }
  var Qd = 6e5, $d = `org.openvtc.uv-pin/v1|`, ef = `org.openvtc.uv-pin/v1|change|`;
  function tf(e2) {
    return $d + e2;
  }
  async function nf(e2) {
    let t2 = await pt(ut(e2));
    return ef + Array.from(t2, (e3) => e3.toString(16).padStart(2, `0`)).join(``);
  }
  async function rf(e2, t2, n2) {
    let r2 = new TextEncoder().encode(e2.normalize(`NFC`));
    try {
      let e3 = await crypto.subtle.importKey(`raw`, r2, `PBKDF2`, false, [
        `deriveBits`
      ]), i2 = await crypto.subtle.deriveBits({
        name: `PBKDF2`,
        hash: `SHA-256`,
        salt: t2,
        iterations: n2
      }, e3, 256);
      return new Uint8Array(i2);
    } finally {
      r2.fill(0);
    }
  }
  async function af(e2, t2) {
    let n2 = await crypto.subtle.importKey(`raw`, e2, {
      name: `HMAC`,
      hash: `SHA-256`
    }, false, [
      `sign`
    ]), r2 = await crypto.subtle.sign(`HMAC`, n2, new TextEncoder().encode(t2));
    return ae(new Uint8Array(r2));
  }
  function of(e2, t2) {
    return af(e2, tf(t2));
  }
  async function sf(e2, t2) {
    return af(e2, await nf(t2));
  }
  function cf() {
    return crypto.getRandomValues(new Uint8Array(16));
  }
  async function lf(e2, t2) {
    let n2 = {
      consumerKind: t2.consumerKind,
      displayName: t2.displayName,
      ...t2.platform ? {
        platform: t2.platform
      } : {},
      ...t2.attestation ? {
        attestation: t2.attestation
      } : {},
      ...t2.keyCustody ? {
        keyCustody: t2.keyCustody
      } : {},
      ...t2.hpkePublicKey ? {
        hpkePublicKey: t2.hpkePublicKey
      } : {}
    }, r2 = R(g, n2, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    });
    return (await e2.send(r2, {
      expectedResponseType: m,
      operationLabel: `device/register/0.2`
    })).binding;
  }
  async function uf(e2, t2) {
    let n2 = {
      ...t2.platform ? {
        platform: t2.platform
      } : {},
      ...t2.vaultSeq === void 0 ? {} : {
        vaultSeq: t2.vaultSeq
      }
    }, r2 = R(l, n2, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    }), i2 = await e2.send(r2, {
      expectedResponseType: o,
      operationLabel: `device/heartbeat/0.2`
    });
    return {
      serverTime: i2.serverTime,
      queuedOperations: i2.queuedOperations ?? [],
      ...i2.syncHint ? {
        syncHint: i2.syncHint
      } : {}
    };
  }
  async function df(e2, t2) {
    try {
      return await uf(e2, {
        holder: t2.holder,
        service: t2.service,
        ...t2.platform ? {
          platform: t2.platform
        } : {}
      }), `present`;
    } catch (e3) {
      if (ce(e3) !== `not_found`) throw e3;
    }
    try {
      return await lf(e2, t2), `registered`;
    } catch (e3) {
      if (ce(e3) === `conflict`) return `present`;
      throw e3;
    }
  }
  var ff = `https://trusttasks.org/spec/device/set-wake/0.2`, pf = `https://trusttasks.org/spec/device/set-wake/0.2#response`;
  async function mf(e2, t2) {
    let n2 = R(ff, {
      ...t2.wakeHandle ? {
        wakeHandle: t2.wakeHandle
      } : {},
      ...t2.pushPlatform ? {
        pushPlatform: t2.pushPlatform
      } : {},
      ...t2.suggestedTriggers ? {
        suggestedTriggers: t2.suggestedTriggers
      } : {}
    }, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    });
    return e2.send(n2, {
      expectedResponseType: pf,
      operationLabel: `device/set-wake/0.2`
    });
  }
  var hf = 11994318, gf = 25578747;
  function _f(e2) {
    let t2 = hf;
    for (let n2 = 0; n2 < e2.length; n2++) {
      t2 ^= e2[n2] << 16;
      for (let e3 = 0; e3 < 8; e3++) t2 <<= 1, t2 & 16777216 && (t2 ^= gf);
    }
    return t2 & 16777215;
  }
  var vf = `-----BEGIN VTA SEALED BUNDLE-----`, yf = `-----END VTA SEALED BUNDLE-----`, bf = 1, xf = /* @__PURE__ */ new Set([
    `Version`,
    `Bundle-Id`,
    `Chunk`,
    `Digest-Algo`
  ]), Sf = 4194304;
  function Cf(e2) {
    if (e2.length > 4194304) throw Error(`armor: input is ${e2.length} characters, over the ${Sf} limit`);
    let t2 = e2.split(/\r?\n/), n2 = [], r2 = 0;
    for (; r2 < t2.length; ) {
      if ((t2[r2] ?? ``).trim() !== vf) {
        r2++;
        continue;
      }
      let e3 = r2 + 1, i2 = e3;
      for (; i2 < t2.length && (t2[i2] ?? ``).trim() !== yf; ) i2++;
      if (i2 >= t2.length) throw Error(`armor: unterminated BEGIN block`);
      let a2 = wf(t2.slice(e3, i2)), o2 = n2.find((e4) => Of(e4.bundleId, a2.bundleId));
      if (o2) {
        if (o2.digestAlgo !== a2.digestAlgo) throw Error(`armor: digest_algo differs across chunks of the same bundle`);
        o2.chunks.push({
          chunkIndex: a2.chunkIndex,
          totalChunks: a2.totalChunks,
          sealedBytes: a2.sealedBytes
        });
      } else n2.push({
        bundleId: a2.bundleId,
        digestAlgo: a2.digestAlgo,
        chunks: [
          {
            chunkIndex: a2.chunkIndex,
            totalChunks: a2.totalChunks,
            sealedBytes: a2.sealedBytes
          }
        ]
      });
      r2 = i2 + 1;
    }
    if (n2.length === 0) throw Error(`armor: no BEGIN blocks found`);
    return n2;
  }
  function wf(e2) {
    let t2 = 0, n2, r2, i2, a2;
    for (; t2 < e2.length; ) {
      let o3 = (e2[t2] ?? ``).replace(/\s+$/, ``);
      if (t2++, o3.length === 0) break;
      let s3 = o3.indexOf(`:`);
      if (s3 < 0) throw Error(`armor: bad header: '${o3}'`);
      let c3 = o3.slice(0, s3).trim(), l3 = o3.slice(s3 + 1).trim();
      if (!xf.has(c3)) throw Error(`armor: unknown header '${c3}' (rejecting forward-compat hazard)`);
      switch (c3) {
        case `Version`: {
          let e3 = Number.parseInt(l3, 10);
          if (!Number.isFinite(e3)) throw Error(`armor: bad Version: ${l3}`);
          n2 = e3;
          break;
        }
        case `Bundle-Id`:
          if (r2 = Ef(l3), r2.length !== 16) throw Error(`armor: Bundle-Id must be 16 bytes (got ${r2.length})`);
          break;
        case `Chunk`: {
          let e3 = l3.indexOf(`/`);
          if (e3 < 0) throw Error(`armor: bad Chunk header: ${l3}`);
          let t3 = Number.parseInt(l3.slice(0, e3), 10), n3 = Number.parseInt(l3.slice(e3 + 1), 10);
          if (!Number.isFinite(t3) || !Number.isFinite(n3) || t3 === 0 || t3 > n3) throw Error(`armor: chunk ${t3}/${n3} out of range`);
          i2 = {
            index: t3 - 1,
            total: n3
          };
          break;
        }
        case `Digest-Algo`:
          a2 = l3;
      }
    }
    if (n2 === void 0) throw Error(`armor: missing Version`);
    if (n2 !== bf) throw Error(`armor: unsupported version ${n2}`);
    if (!r2) throw Error(`armor: missing Bundle-Id`);
    if (!i2) throw Error(`armor: missing Chunk header`);
    if (!a2) throw Error(`armor: missing Digest-Algo`);
    let o2 = ``, s2;
    for (; t2 < e2.length; ) {
      let n3 = (e2[t2] ?? ``).replace(/\s+$/, ``);
      if (t2++, n3.length !== 0) {
        if (n3.startsWith(`=`)) {
          s2 = n3.slice(1);
          break;
        }
        o2 += n3;
      }
    }
    if (s2 === void 0) throw Error(`armor: missing CRC line`);
    let c2 = Te.decode(o2), l2 = Te.decode(s2);
    if (l2.length !== 3) throw Error(`armor: CRC payload must be 3 bytes (got ${l2.length})`);
    let u2 = l2[0] << 16 | l2[1] << 8 | l2[2], d2 = _f(c2);
    if (d2 !== u2) throw Error(`armor: CRC24 mismatch (expected 0x${u2.toString(16)}, got 0x${d2.toString(16)})`);
    return {
      bundleId: r2,
      digestAlgo: a2,
      chunkIndex: i2.index,
      totalChunks: i2.total,
      sealedBytes: c2
    };
  }
  function Tf(e2) {
    if (e2.bundleId.length !== 16) throw Error(`buildChunkAad: bundleId must be 16 bytes (got ${e2.bundleId.length})`);
    let t2 = new TextEncoder().encode(e2.digestAlgo), n2 = Math.min(t2.length, 255), r2 = new Uint8Array(22 + n2), i2 = 0;
    return r2[i2++] = e2.version, r2.set(e2.bundleId, i2), i2 += 16, r2[i2++] = e2.chunkIndex >> 8 & 255, r2[i2++] = e2.chunkIndex & 255, r2[i2++] = e2.totalChunks >> 8 & 255, r2[i2++] = e2.totalChunks & 255, r2[i2++] = n2, r2.set(t2.subarray(0, n2), i2), r2;
  }
  function Ef(e2) {
    if (e2.length % 2 != 0) throw Error(`hex: odd length: ${e2.length}`);
    let t2 = new Uint8Array(e2.length / 2);
    for (let n2 = 0; n2 < e2.length; n2 += 2) {
      let r2 = Df(e2.charCodeAt(n2)), i2 = Df(e2.charCodeAt(n2 + 1));
      t2[n2 / 2] = r2 << 4 | i2;
    }
    return t2;
  }
  function Df(e2) {
    if (e2 >= 48 && e2 <= 57) return e2 - 48;
    if (e2 >= 97 && e2 <= 102) return e2 - 97 + 10;
    if (e2 >= 65 && e2 <= 70) return e2 - 65 + 10;
    throw Error(`hex: non-hex byte 0x${e2.toString(16)}`);
  }
  function Of(e2, t2) {
    if (e2.length !== t2.length) return false;
    for (let n2 = 0; n2 < e2.length; n2++) if (e2[n2] !== t2[n2]) return false;
    return true;
  }
  var kf = new TextEncoder().encode(`vta-sealed-transfer/v1`);
  async function Af(e2) {
    if (e2.recipientSecret.length !== 32) throw Error(`hpke: recipientSecret must be 32 bytes (got ${e2.recipientSecret.length})`);
    if (e2.kemEncap.length !== 32) throw Error(`hpke: kemEncap must be 32 bytes (got ${e2.kemEncap.length})`);
    return pc(e2.ciphertext, e2.aad, e2.kemEncap, e2.recipientSecret, kf);
  }
  var jf;
  try {
    jf = new TextDecoder();
  } catch {
  }
  var U, Mf, W = 0, Nf = [], Pf = 105, Ff = 57342, If = 57343, Lf = 57337, Rf = 6, zf = {}, Bf = 11281e4, Vf = 1681e4, Hf = Nf, Uf = 0, G = {}, Wf, Gf, Kf = 0, qf = 0, Jf, Yf, Xf = [], Zf = [], Qf, $f, ep, tp = {
    useRecords: false,
    mapsAsObjects: true
  }, np = false, rp = 2;
  try {
    Function(``);
  } catch {
    rp = 1 / 0;
  }
  var ip = class e2 {
    constructor(e3) {
      if (e3 && ((e3.keyMap || e3._keyMap) && !e3.useRecords && (e3.useRecords = false, e3.mapsAsObjects = true), e3.useRecords === false && e3.mapsAsObjects === void 0 && (e3.mapsAsObjects = true), e3.getStructures && (e3.getShared = e3.getStructures), e3.getShared && !e3.structures && ((e3.structures = []).uninitialized = true), e3.keyMap)) {
        this.mapKey = /* @__PURE__ */ new Map();
        for (let [t2, n2] of Object.entries(e3.keyMap)) this.mapKey.set(n2, t2);
      }
      Object.assign(this, e3);
    }
    decodeKey(e3) {
      return this.keyMap && this.mapKey.get(e3) || e3;
    }
    encodeKey(e3) {
      return this.keyMap && this.keyMap.hasOwnProperty(e3) ? this.keyMap[e3] : e3;
    }
    encodeKeys(e3) {
      if (!this._keyMap) return e3;
      let t2 = /* @__PURE__ */ new Map();
      for (let [n2, r2] of Object.entries(e3)) t2.set(this._keyMap.hasOwnProperty(n2) ? this._keyMap[n2] : n2, r2);
      return t2;
    }
    decodeKeys(e3) {
      if (!this._keyMap || e3.constructor.name != `Map`) return e3;
      if (!this._mapKey) {
        this._mapKey = /* @__PURE__ */ new Map();
        for (let [e4, t3] of Object.entries(this._keyMap)) this._mapKey.set(t3, e4);
      }
      let t2 = {};
      return e3.forEach((e4, n2) => t2[lp(this._mapKey.has(n2) ? this._mapKey.get(n2) : n2)] = e4), t2;
    }
    mapDecode(e3, t2) {
      let n2 = this.decode(e3);
      if (this._keyMap) switch (n2.constructor.name) {
        case `Array`:
          return n2.map((e4) => this.decodeKeys(e4));
      }
      return n2;
    }
    decode(t2, n2) {
      if (U) return Np(() => (Pp(), this ? this.decode(t2, n2) : e2.prototype.decode.call(tp, t2, n2)));
      Mf = n2 > -1 ? n2 : t2.length, W = 0, Uf = 0, qf = 0, Gf = null, Hf = Nf, Jf = null, U = t2;
      try {
        $f = t2.dataView ||= new DataView(t2.buffer, t2.byteOffset, t2.byteLength);
      } catch (e3) {
        throw U = null, t2 instanceof Uint8Array ? e3 : Error(`Source must be a Uint8Array or Buffer but was a ` + (t2 && typeof t2 == `object` ? t2.constructor.name : typeof t2));
      }
      if (this instanceof e2) {
        if (G = this, Qf = this.sharedValues && (this.pack ? Array(this.maxPrivatePackedValues || 16).concat(this.sharedValues) : this.sharedValues), this.structures) return Wf = this.structures, ap();
        (!Wf || Wf.length > 0) && (Wf = []);
      } else G = tp, (!Wf || Wf.length > 0) && (Wf = []), Qf = null;
      return ap();
    }
    decodeMultiple(e3, t2) {
      let n2, r2 = 0;
      try {
        let i2 = e3.length;
        np = true;
        let a2 = this ? this.decode(e3, i2) : Ip.decode(e3, i2);
        if (t2) {
          if (t2(a2) === false) return;
          for (; W < i2; ) if (r2 = W, t2(ap()) === false) return;
        } else {
          for (n2 = [
            a2
          ]; W < i2; ) r2 = W, n2.push(ap());
          return n2;
        }
      } catch (e4) {
        throw e4.lastPosition = r2, e4.values = n2, e4;
      } finally {
        np = false, Pp();
      }
    }
  };
  function ap() {
    try {
      let e2 = K();
      if (Jf) {
        if (W >= Jf.postBundlePosition) {
          let e3 = Error(`Unexpected bundle position`);
          throw e3.incomplete = true, e3;
        }
        W = Jf.postBundlePosition, Jf = null;
      }
      if (W == Mf) Wf = null, U = null, Yf &&= null;
      else if (W > Mf) {
        let e3 = Error(`Unexpected end of CBOR data`);
        throw e3.incomplete = true, e3;
      } else if (!np) throw Error(`Data read, but end of buffer not reached`);
      return e2;
    } catch (e2) {
      throw Pp(), (e2 instanceof RangeError || e2.message.startsWith(`Unexpected end of buffer`)) && (e2.incomplete = true), e2;
    }
  }
  function op() {
    let e2 = Error(`Unexpected end of CBOR data`);
    return e2.incomplete = true, e2;
  }
  function K() {
    if (!(W < Mf)) throw op();
    let e2 = U[W++], t2 = e2 >> 5;
    if (e2 &= 31, e2 > 23) switch (e2) {
      case 24:
        if (W >= Mf) throw op();
        e2 = U[W++];
        break;
      case 25:
        if (t2 == 7) return vp();
        e2 = $f.getUint16(W), W += 2;
        break;
      case 26:
        if (t2 == 7) {
          let e3 = $f.getFloat32(W);
          if (G.useFloat32 > 2) {
            let t3 = Fp[(U[W] & 127) << 1 | U[W + 1] >> 7];
            return W += 4, (t3 * e3 + (e3 > 0 ? 0.5 : -0.5) >> 0) / t3;
          }
          return W += 4, e3;
        }
        if (e2 = $f.getUint32(W), W += 4, t2 === 1) return -1 - e2;
        break;
      case 27:
        if (t2 == 7) {
          let e3 = $f.getFloat64(W);
          return W += 8, e3;
        }
        if (t2 > 1) {
          if ($f.getUint32(W) > 0) throw Error(`JavaScript does not support arrays, maps, or strings with length over 4294967295`);
          e2 = $f.getUint32(W + 4);
        } else G.int64AsNumber ? (e2 = $f.getUint32(W) * 4294967296, e2 += $f.getUint32(W + 4)) : e2 = $f.getBigUint64(W);
        W += 8;
        break;
      case 31:
        switch (t2) {
          case 2:
          case 3:
            throw Error(`Indefinite length not supported for byte or text strings`);
          case 4:
            let e3 = [], n2, r2 = 0;
            for (; (n2 = K()) != zf; ) {
              if (r2 >= Bf) throw Error(`Array length exceeds ${Bf}`);
              e3[r2++] = n2;
            }
            return t2 == 4 ? e3 : t2 == 3 ? e3.join(``) : Buffer.concat(e3);
          case 5:
            let i2;
            if (G.mapsAsObjects) {
              let e4 = {}, t3 = 0;
              if (G.keyMap) for (; (i2 = K()) != zf; ) {
                if (t3++ >= Vf) throw Error(`Property count exceeds ${Vf}`);
                e4[lp(G.decodeKey(i2))] = K();
              }
              else for (; (i2 = K()) != zf; ) {
                if (t3++ >= Vf) throw Error(`Property count exceeds ${Vf}`);
                e4[lp(i2)] = K();
              }
              return e4;
            }
            {
              ep &&= (G.mapsAsObjects = true, false);
              let e4 = /* @__PURE__ */ new Map();
              if (G.keyMap) {
                let t3 = 0;
                for (; (i2 = K()) != zf; ) {
                  if (t3++ >= Vf) throw Error(`Map size exceeds ${Vf}`);
                  e4.set(G.decodeKey(i2), K());
                }
              } else {
                let t3 = 0;
                for (; (i2 = K()) != zf; ) {
                  if (t3++ >= Vf) throw Error(`Map size exceeds ${Vf}`);
                  e4.set(i2, K());
                }
              }
              return e4;
            }
          case 7:
            return zf;
          default:
            throw Error(`Invalid major type for indefinite length ` + t2);
        }
      default:
        throw Error(`Unknown token ` + e2);
    }
    switch (t2) {
      case 0:
        return e2;
      case 1:
        return ~e2;
      case 2:
        return hp(e2);
      case 3:
        if (qf >= W) return Gf.slice(W - Kf, (W += e2) - Kf);
        if (qf == 0 && Mf < 140 && e2 < 32) {
          let t4 = e2 < 16 ? mp(e2) : pp(e2);
          if (t4 != null) return t4;
        }
        return up(e2);
      case 4:
        if (e2 >= Bf) throw Error(`Array length exceeds ${Bf}`);
        if (e2 > Mf - W) throw op();
        let t3 = Array(e2);
        for (let n3 = 0; n3 < e2; n3++) t3[n3] = K();
        return t3;
      case 5:
        if (e2 >= Vf) throw Error(`Map size exceeds ${Bf}`);
        if (e2 > (Mf - W) / 2) throw op();
        if (G.mapsAsObjects) {
          let t4 = {};
          if (G.keyMap) for (let n3 = 0; n3 < e2; n3++) t4[lp(G.decodeKey(K()))] = K();
          else for (let n3 = 0; n3 < e2; n3++) t4[lp(K())] = K();
          return t4;
        }
        {
          ep &&= (G.mapsAsObjects = true, false);
          let t4 = /* @__PURE__ */ new Map();
          if (G.keyMap) for (let n3 = 0; n3 < e2; n3++) t4.set(G.decodeKey(K()), K());
          else for (let n3 = 0; n3 < e2; n3++) t4.set(K(), K());
          return t4;
        }
      case 6:
        if (e2 >= Lf) {
          let t4 = Wf[e2 & 8191];
          if (t4) return t4.read || (t4.read = cp(t4)), t4.read();
          if (e2 < 65536) {
            if (e2 == If) {
              let e3 = jp(), t5 = K(), n3 = K();
              bp(t5, n3);
              let r2 = {};
              if (G.keyMap) for (let t6 = 2; t6 < e3; t6++) {
                let e4 = G.decodeKey(n3[t6 - 2]);
                r2[lp(e4)] = K();
              }
              else for (let t6 = 2; t6 < e3; t6++) {
                let e4 = n3[t6 - 2];
                r2[lp(e4)] = K();
              }
              return r2;
            }
            if (e2 == Ff) {
              let e3 = jp(), t5 = K();
              for (let n3 = 2; n3 < e3; n3++) bp(t5++, K());
              return K();
            }
            if (e2 == Lf) return Ap();
            if (G.getShared && (Mp(), t4 = Wf[e2 & 8191], t4)) return t4.read || (t4.read = cp(t4)), t4.read();
          }
        }
        let n2 = Xf[e2];
        if (n2) return n2.handlesRead ? n2(K) : n2(K());
        {
          let t4 = K();
          for (let n3 = 0; n3 < Zf.length; n3++) {
            let r2 = Zf[n3](e2, t4);
            if (r2 !== void 0) return r2;
          }
          return new yp(t4, e2);
        }
      case 7:
        switch (e2) {
          case 20:
            return false;
          case 21:
            return true;
          case 22:
            return null;
          case 23:
            return;
          default:
            let t4 = (Qf || wp())[e2];
            if (t4 !== void 0) return t4;
            throw Error(`Unknown token ` + e2);
        }
      default:
        throw isNaN(e2) ? op() : Error(`Unknown CBOR token ` + e2);
    }
  }
  var sp = /^[a-zA-Z_$][a-zA-Z\d_$]*$/;
  function cp(e2) {
    if (!e2) throw Error(`Structure is required in record definition`);
    function t2() {
      let e3 = U[W++];
      if (e3 &= 31, e3 > 23) switch (e3) {
        case 24:
          e3 = U[W++];
          break;
        case 25:
          e3 = $f.getUint16(W), W += 2;
          break;
        case 26:
          e3 = $f.getUint32(W), W += 4;
          break;
        default:
          throw Error(`Expected array header, but got ` + U[W - 1]);
      }
      let t3 = this.compiledReader;
      for (; t3; ) {
        if (t3.propertyCount === e3) return t3(K);
        t3 = t3.next;
      }
      if (this.slowReads++ >= rp) {
        let n3 = this.length == e3 ? this : this.slice(0, e3);
        return t3 = G.keyMap ? Function(`r`, `return {` + n3.map((e4) => G.decodeKey(e4)).map((e4) => sp.test(e4) ? lp(e4) + `:r()` : `[` + JSON.stringify(e4) + `]:r()`).join(`,`) + `}`) : Function(`r`, `return {` + n3.map((e4) => sp.test(e4) ? lp(e4) + `:r()` : `[` + JSON.stringify(e4) + `]:r()`).join(`,`) + `}`), this.compiledReader && (t3.next = this.compiledReader), t3.propertyCount = e3, this.compiledReader = t3, t3(K);
      }
      let n2 = {};
      if (G.keyMap) for (let t4 = 0; t4 < e3; t4++) n2[lp(G.decodeKey(this[t4]))] = K();
      else for (let t4 = 0; t4 < e3; t4++) n2[lp(this[t4])] = K();
      return n2;
    }
    return e2.slowReads = 0, t2;
  }
  function lp(e2) {
    if (typeof e2 == `string`) return e2 === `__proto__` ? `__proto_` : e2;
    if (typeof e2 == `number` || typeof e2 == `boolean` || typeof e2 == `bigint`) return e2.toString();
    if (e2 == null) return e2 + ``;
    throw Error(`Invalid property name type ` + typeof e2);
  }
  var up = dp;
  function dp(e2) {
    let t2;
    if (e2 < 16 && (t2 = mp(e2))) return t2;
    if (e2 > 64 && jf) return jf.decode(U.subarray(W, W += e2));
    let n2 = W + e2, r2 = [];
    for (t2 = ``; W < n2; ) {
      let e3 = U[W++];
      if (!(e3 & 128)) r2.push(e3);
      else if ((e3 & 224) == 192) {
        if (e3 < 194 || W >= n2 || (U[W] & 192) != 128) r2.push(65533);
        else {
          let t3 = U[W++] & 63;
          r2.push((e3 & 31) << 6 | t3);
        }
      } else if ((e3 & 240) == 224) {
        let t3 = W < n2 ? U[W] : 0;
        if (W >= n2 || (t3 & 192) != 128 || e3 === 224 && t3 < 160 || e3 === 237 && t3 >= 160) r2.push(65533);
        else if (W++, W >= n2 || (U[W] & 192) != 128) r2.push(65533);
        else {
          let n3 = U[W++] & 63;
          r2.push((e3 & 31) << 12 | (t3 & 63) << 6 | n3);
        }
      } else if ((e3 & 248) == 240) {
        let t3 = W < n2 ? U[W] : 0;
        if (e3 > 244 || W >= n2 || (t3 & 192) != 128 || e3 === 240 && t3 < 144 || e3 === 244 && t3 >= 144) r2.push(65533);
        else if (W++, W >= n2 || (U[W] & 192) != 128) r2.push(65533);
        else {
          let i2 = U[W++] & 63;
          if (W >= n2 || (U[W] & 192) != 128) r2.push(65533);
          else {
            let n3 = U[W++] & 63, a2 = (e3 & 7) << 18 | (t3 & 63) << 12 | i2 << 6 | n3;
            a2 -= 65536, r2.push(a2 >>> 10 & 1023 | 55296), r2.push(56320 | a2 & 1023);
          }
        }
      } else r2.push(65533);
      r2.length >= 4096 && (t2 += fp.apply(String, r2), r2.length = 0);
    }
    return r2.length > 0 && (t2 += fp.apply(String, r2)), t2;
  }
  var fp = String.fromCharCode;
  function pp(e2) {
    let t2 = W, n2 = Array(e2);
    for (let r2 = 0; r2 < e2; r2++) {
      let e3 = U[W++];
      if ((e3 & 128) > 0) {
        W = t2;
        return;
      }
      n2[r2] = e3;
    }
    return fp.apply(String, n2);
  }
  function mp(e2) {
    if (e2 < 4) {
      if (e2 < 2) {
        if (e2 === 0) return ``;
        {
          let e3 = U[W++];
          if ((e3 & 128) > 1) {
            --W;
            return;
          }
          return fp(e3);
        }
      }
      {
        let t2 = U[W++], n2 = U[W++];
        if ((t2 & 128) > 0 || (n2 & 128) > 0) {
          W -= 2;
          return;
        }
        if (e2 < 3) return fp(t2, n2);
        let r2 = U[W++];
        if ((r2 & 128) > 0) {
          W -= 3;
          return;
        }
        return fp(t2, n2, r2);
      }
    }
    {
      let t2 = U[W++], n2 = U[W++], r2 = U[W++], i2 = U[W++];
      if ((t2 & 128) > 0 || (n2 & 128) > 0 || (r2 & 128) > 0 || (i2 & 128) > 0) {
        W -= 4;
        return;
      }
      if (e2 < 6) {
        if (e2 === 4) return fp(t2, n2, r2, i2);
        {
          let e3 = U[W++];
          if ((e3 & 128) > 0) {
            W -= 5;
            return;
          }
          return fp(t2, n2, r2, i2, e3);
        }
      }
      if (e2 < 8) {
        let a2 = U[W++], o2 = U[W++];
        if ((a2 & 128) > 0 || (o2 & 128) > 0) {
          W -= 6;
          return;
        }
        if (e2 < 7) return fp(t2, n2, r2, i2, a2, o2);
        let s2 = U[W++];
        if ((s2 & 128) > 0) {
          W -= 7;
          return;
        }
        return fp(t2, n2, r2, i2, a2, o2, s2);
      }
      {
        let a2 = U[W++], o2 = U[W++], s2 = U[W++], c2 = U[W++];
        if ((a2 & 128) > 0 || (o2 & 128) > 0 || (s2 & 128) > 0 || (c2 & 128) > 0) {
          W -= 8;
          return;
        }
        if (e2 < 10) {
          if (e2 === 8) return fp(t2, n2, r2, i2, a2, o2, s2, c2);
          {
            let e3 = U[W++];
            if ((e3 & 128) > 0) {
              W -= 9;
              return;
            }
            return fp(t2, n2, r2, i2, a2, o2, s2, c2, e3);
          }
        }
        if (e2 < 12) {
          let l2 = U[W++], u2 = U[W++];
          if ((l2 & 128) > 0 || (u2 & 128) > 0) {
            W -= 10;
            return;
          }
          if (e2 < 11) return fp(t2, n2, r2, i2, a2, o2, s2, c2, l2, u2);
          let d2 = U[W++];
          if ((d2 & 128) > 0) {
            W -= 11;
            return;
          }
          return fp(t2, n2, r2, i2, a2, o2, s2, c2, l2, u2, d2);
        }
        {
          let l2 = U[W++], u2 = U[W++], d2 = U[W++], f2 = U[W++];
          if ((l2 & 128) > 0 || (u2 & 128) > 0 || (d2 & 128) > 0 || (f2 & 128) > 0) {
            W -= 12;
            return;
          }
          if (e2 < 14) {
            if (e2 === 12) return fp(t2, n2, r2, i2, a2, o2, s2, c2, l2, u2, d2, f2);
            {
              let e3 = U[W++];
              if ((e3 & 128) > 0) {
                W -= 13;
                return;
              }
              return fp(t2, n2, r2, i2, a2, o2, s2, c2, l2, u2, d2, f2, e3);
            }
          }
          {
            let p2 = U[W++], m2 = U[W++];
            if ((p2 & 128) > 0 || (m2 & 128) > 0) {
              W -= 14;
              return;
            }
            if (e2 < 15) return fp(t2, n2, r2, i2, a2, o2, s2, c2, l2, u2, d2, f2, p2, m2);
            let h2 = U[W++];
            if ((h2 & 128) > 0) {
              W -= 15;
              return;
            }
            return fp(t2, n2, r2, i2, a2, o2, s2, c2, l2, u2, d2, f2, p2, m2, h2);
          }
        }
      }
    }
  }
  function hp(e2) {
    return G.copyBuffers ? Uint8Array.prototype.slice.call(U, W, W += e2) : U.subarray(W, W += e2);
  }
  var gp = new Float32Array(1), _p = new Uint8Array(gp.buffer, 0, 4);
  function vp() {
    let e2 = U[W++], t2 = U[W++], n2 = (e2 & 127) >> 2;
    if (n2 === 31) return t2 || e2 & 3 ? NaN : e2 & 128 ? -1 / 0 : 1 / 0;
    if (n2 === 0) {
      let n3 = ((e2 & 3) << 8 | t2) / (1 << 24);
      return e2 & 128 ? -n3 : n3;
    }
    return _p[3] = e2 & 128 | (n2 >> 1) + 56, _p[2] = (e2 & 7) << 5 | t2 >> 3, _p[1] = t2 << 5, _p[0] = 0, gp[0];
  }
  Array(4096);
  var yp = class {
    constructor(e2, t2) {
      this.value = e2, this.tag = t2;
    }
  };
  Xf[0] = (e2) => new Date(e2), Xf[1] = (e2) => new Date(Math.round(e2 * 1e3)), Xf[2] = (e2) => {
    let t2 = BigInt(0);
    for (let n2 = 0, r2 = e2.byteLength; n2 < r2; n2++) t2 = BigInt(e2[n2]) + (t2 << BigInt(8));
    return t2;
  }, Xf[3] = (e2) => BigInt(-1) - Xf[2](e2), Xf[4] = (e2) => +(e2[1] + `e` + e2[0]), Xf[5] = (e2) => e2[1] * Math.exp(e2[0] * Math.log(2));
  var bp = (e2, t2) => {
    e2 -= 57344;
    let n2 = Wf[e2];
    n2 && n2.isShared && ((Wf.restoreStructures || (Wf.restoreStructures = []))[e2] = n2), Wf[e2] = t2, t2.read = cp(t2);
  };
  Xf[Pf] = (e2) => {
    let t2 = e2.length, n2 = e2[1];
    bp(e2[0], n2);
    let r2 = {};
    for (let i2 = 2; i2 < t2; i2++) {
      let t3 = n2[i2 - 2];
      r2[lp(t3)] = e2[i2];
    }
    return r2;
  }, Xf[14] = (e2) => Jf ? Jf[0].slice(Jf.position0, Jf.position0 += e2) : new yp(e2, 14), Xf[15] = (e2) => Jf ? Jf[1].slice(Jf.position1, Jf.position1 += e2) : new yp(e2, 15);
  var xp = {
    Error,
    RegExp
  };
  Xf[27] = (e2) => (xp[e2[0]] || Error)(e2[1], e2[2]);
  var Sp = (e2) => {
    if (U[W++] != 132) {
      let e3 = Error(`Packed values structure must be followed by a 4 element array`);
      throw U.length < W && (e3.incomplete = true), e3;
    }
    let t2 = e2();
    if (!t2 || !t2.length) {
      let e3 = Error(`Packed values structure must be followed by a 4 element array`);
      throw e3.incomplete = true, e3;
    }
    return Qf = Qf ? t2.concat(Qf.slice(t2.length)) : t2, Qf.prefixes = e2(), Qf.suffixes = e2(), e2();
  };
  Sp.handlesRead = true, Xf[51] = Sp, Xf[Rf] = (e2) => {
    if (!Qf) {
      if (G.getShared) Mp();
      else return new yp(e2, Rf);
    }
    if (typeof e2 == `number`) return Qf[16 + (e2 >= 0 ? 2 * e2 : -2 * e2 - 1)];
    let t2 = Error(`No support for non-integer packed references yet`);
    throw e2 === void 0 && (t2.incomplete = true), t2;
  }, Xf[28] = (e2) => {
    Yf || (Yf = /* @__PURE__ */ new Map(), Yf.id = 0);
    let t2 = Yf.id++, n2 = W, r2 = U[W], i2;
    i2 = r2 >> 5 == 4 ? [] : {};
    let a2 = {
      target: i2
    };
    Yf.set(t2, a2);
    let o2 = e2();
    return a2.used ? (Object.getPrototypeOf(i2) !== Object.getPrototypeOf(o2) && (W = n2, i2 = o2, Yf.set(t2, {
      target: i2
    }), o2 = e2()), Object.assign(i2, o2)) : (a2.target = o2, o2);
  }, Xf[28].handlesRead = true, Xf[29] = (e2) => {
    let t2 = Yf.get(e2);
    return t2.used = true, t2.target;
  }, Xf[258] = (e2) => new Set(e2), (Xf[259] = (e2) => (G.mapsAsObjects && (G.mapsAsObjects = false, ep = true), e2())).handlesRead = true;
  function Cp(e2, t2) {
    return typeof e2 == `string` ? e2 + t2 : e2 instanceof Array ? e2.concat(t2) : Object.assign({}, e2, t2);
  }
  function wp() {
    if (!Qf) {
      if (G.getShared) Mp();
      else throw Error(`No packed values available`);
    }
    return Qf;
  }
  var Tp = 1399353956;
  Zf.push((e2, t2) => {
    if (e2 >= 225 && e2 <= 255) return Cp(wp().prefixes[e2 - 224], t2);
    if (e2 >= 28704 && e2 <= 32767) return Cp(wp().prefixes[e2 - 28672], t2);
    if (e2 >= 1879052288 && e2 <= 2147483647) return Cp(wp().prefixes[e2 - 1879048192], t2);
    if (e2 >= 216 && e2 <= 223) return Cp(t2, wp().suffixes[e2 - 216]);
    if (e2 >= 27647 && e2 <= 28671) return Cp(t2, wp().suffixes[e2 - 27639]);
    if (e2 >= 1811940352 && e2 <= 1879048191) return Cp(t2, wp().suffixes[e2 - 1811939328]);
    if (e2 == Tp) return {
      packedValues: Qf,
      structures: Wf.slice(0),
      version: t2
    };
    if (e2 == 55799) return t2;
  });
  var Ep = new Uint8Array(new Uint16Array([
    1
  ]).buffer)[0] == 1, Dp = [
    Uint8Array,
    Uint8ClampedArray,
    Uint16Array,
    Uint32Array,
    typeof BigUint64Array > `u` ? {
      name: `BigUint64Array`
    } : BigUint64Array,
    Int8Array,
    Int16Array,
    Int32Array,
    typeof BigInt64Array > `u` ? {
      name: `BigInt64Array`
    } : BigInt64Array,
    Float32Array,
    Float64Array
  ], Op = [
    64,
    68,
    69,
    70,
    71,
    72,
    77,
    78,
    79,
    85,
    86
  ];
  for (let e2 = 0; e2 < Dp.length; e2++) kp(Dp[e2], Op[e2]);
  function kp(e2, t2) {
    let n2 = `get` + e2.name.slice(0, -5), r2;
    typeof e2 == `function` ? r2 = e2.BYTES_PER_ELEMENT : e2 = null;
    for (let i2 = 0; i2 < 2; i2++) {
      if (!i2 && r2 == 1) continue;
      let a2 = r2 == 2 ? 1 : r2 == 4 ? 2 : r2 == 8 ? 3 : 0;
      Xf[i2 ? t2 : t2 - 4] = r2 == 1 || i2 == Ep ? (n3) => {
        if (!e2) throw Error(`Could not find typed array for code ` + t2);
        return !G.copyBuffers && (r2 === 1 || r2 === 2 && !(n3.byteOffset & 1) || r2 === 4 && !(n3.byteOffset & 3) || r2 === 8 && !(n3.byteOffset & 7)) ? new e2(n3.buffer, n3.byteOffset, n3.byteLength >> a2) : new e2(Uint8Array.prototype.slice.call(n3, 0).buffer);
      } : (r3) => {
        if (!e2) throw Error(`Could not find typed array for code ` + t2);
        let o2 = new DataView(r3.buffer, r3.byteOffset, r3.byteLength), s2 = r3.length >> a2, c2 = new e2(s2), l2 = o2[n2];
        for (let e3 = 0; e3 < s2; e3++) c2[e3] = l2.call(o2, e3 << a2, i2);
        return c2;
      };
    }
  }
  function Ap() {
    let e2 = jp(), t2 = W + K();
    for (let t3 = 2; t3 < e2; t3++) {
      let e3 = jp();
      W += e3;
    }
    let n2 = W;
    return W = t2, Jf = [
      dp(jp()),
      dp(jp())
    ], Jf.position0 = 0, Jf.position1 = 0, Jf.postBundlePosition = W, W = n2, K();
  }
  function jp() {
    if (!(W < Mf)) throw op();
    let e2 = U[W++] & 31;
    if (e2 > 23) switch (e2) {
      case 24:
        if (W >= Mf) throw op();
        e2 = U[W++];
        break;
      case 25:
        e2 = $f.getUint16(W), W += 2;
        break;
      case 26:
        e2 = $f.getUint32(W), W += 4;
    }
    return e2;
  }
  function Mp() {
    if (G.getShared) {
      let e2 = Np(() => (U = null, G.getShared())) || {}, t2 = e2.structures || [];
      G.sharedVersion = e2.version, Qf = G.sharedValues = e2.packedValues, Wf === true ? G.structures = Wf = t2 : Wf.splice.apply(Wf, [
        0,
        t2.length
      ].concat(t2));
    }
  }
  function Np(e2) {
    let t2 = Mf, n2 = W, r2 = Uf, i2 = Kf, a2 = qf, o2 = Gf, s2 = Hf, c2 = Yf, l2 = Jf, u2 = new Uint8Array(U.slice(0, Mf)), d2 = Wf, f2 = G, p2 = np, m2 = e2();
    return Mf = t2, W = n2, Uf = r2, Kf = i2, qf = a2, Gf = o2, Hf = s2, Yf = c2, Jf = l2, U = u2, np = p2, Wf = d2, G = f2, $f = new DataView(U.buffer, U.byteOffset, U.byteLength), m2;
  }
  function Pp() {
    U = null, Yf = null, Wf = null;
  }
  var Fp = Array(147);
  for (let e2 = 0; e2 < 256; e2++) Fp[e2] = +(`1e` + Math.floor(45.15 - e2 * 0.30103));
  var Ip = new ip({
    useRecords: false
  });
  Ip.decode, Ip.decodeMultiple;
  var Lp = {
    NEVER: 0,
    ALWAYS: 1,
    DECIMAL_ROUND: 3,
    DECIMAL_FIT: 4
  }, Rp;
  try {
    Rp = new TextEncoder();
  } catch {
  }
  var zp, Bp, Vp = typeof globalThis == `object` && globalThis.Buffer, Hp = Vp !== void 0, Up = Hp ? Vp.allocUnsafeSlow : Uint8Array, Wp = Hp ? Vp : Uint8Array, Gp = 256, Kp = Hp ? 4294967296 : 2144337920, qp, q, J, Y = 0, Jp, Yp = null, Xp = 61440, Zp = /[\u0080-\uFFFF]/, Qp = /* @__PURE__ */ Symbol(`record-id`), $p = class extends ip {
    constructor(e2) {
      super(e2), this.offset = 0;
      let t2, n2, r2, i2, a2;
      e2 ||= {};
      let o2 = Wp.prototype.utf8Write ? function(e3, t3) {
        return q.utf8Write(e3, t3, q.byteLength - t3);
      } : Rp && Rp.encodeInto ? function(e3, t3) {
        return Rp.encodeInto(e3, q.subarray(t3)).written;
      } : false, s2 = this, c2 = e2.structures || e2.saveStructures, l2 = e2.maxSharedStructures;
      if (l2 ??= c2 ? 128 : 0, l2 > 8190) throw Error(`Maximum maxSharedStructure is 8190`);
      let u2 = e2.sequential;
      u2 && (l2 = 0), this.structures ||= [], this.saveStructures && (this.saveShared = this.saveStructures);
      let d2, f2, p2 = e2.sharedValues, m2;
      if (p2) {
        m2 = /* @__PURE__ */ Object.create(null);
        for (let e3 = 0, t3 = p2.length; e3 < t3; e3++) m2[p2[e3]] = e3;
      }
      let h2 = [], g2 = 0, _2 = 0;
      this.mapEncode = function(e3, t3) {
        if (this._keyMap && !this._mapped) switch (e3.constructor.name) {
          case `Array`:
            e3 = e3.map((e4) => this.encodeKeys(e4));
        }
        return this.encode(e3, t3);
      }, this.encode = function(o3, c3) {
        if (q || (q = new Up(8192), J = new DataView(q.buffer, 0, 8192), Y = 0), Jp = q.length - 10, Jp - Y < 2048 ? (q = new Up(q.length), J = new DataView(q.buffer, 0, q.length), Jp = q.length - 10, Y = 0) : c3 === 512 && (Y = Y + 7 & 2147483640), t2 = Y, s2.useSelfDescribedHeader && (J.setUint32(Y, 3654940416), Y += 3), a2 = s2.structuredClone ? /* @__PURE__ */ new Map() : null, s2.bundleStrings && typeof o3 != `string` ? (Yp = [], Yp.size = 1 / 0) : Yp = null, n2 = s2.structures, n2) {
          if (n2.uninitialized) {
            let e4 = s2.getShared() || {};
            s2.structures = n2 = e4.structures || [], s2.sharedVersion = e4.version;
            let t3 = s2.sharedValues = e4.packedValues;
            if (t3) {
              m2 = {};
              for (let e5 = 0, n3 = t3.length; e5 < n3; e5++) m2[t3[e5]] = e5;
            }
          }
          let e3 = n2.length;
          if (e3 > l2 && !u2 && (e3 = l2), !n2.transitions) {
            n2.transitions = /* @__PURE__ */ Object.create(null);
            for (let t3 = 0; t3 < e3; t3++) {
              let e4 = n2[t3];
              if (!e4) continue;
              let r3, i3 = n2.transitions;
              for (let n3 = 0, a3 = e4.length; n3 < a3; n3++) {
                i3[Qp] === void 0 && (i3[Qp] = t3);
                let a4 = e4[n3];
                r3 = i3[a4], r3 ||= i3[a4] = /* @__PURE__ */ Object.create(null), i3 = r3;
              }
              i3[Qp] = t3 | 1048576;
            }
          }
          u2 || (n2.nextId = e3);
        }
        if (r2 &&= false, i2 = n2 || [], f2 = m2, e2.pack) {
          let t3 = /* @__PURE__ */ new Map();
          if (t3.values = [], t3.encoder = s2, t3.maxValues = e2.maxPrivatePackedValues || (m2 ? 16 : 1 / 0), t3.objectMap = m2 || false, t3.samplingPackedValues = d2, am(o3, t3), t3.values.length > 0) {
            q[Y++] = 216, q[Y++] = 51, nm(4);
            let e3 = t3.values;
            v2(e3), nm(0), nm(0), f2 = Object.create(m2 || null);
            for (let t4 = 0, n3 = e3.length; t4 < n3; t4++) f2[e3[t4]] = t4;
          }
        }
        qp = c3 & gm;
        try {
          if (qp) return;
          if (v2(o3), Yp && um(t2, v2), s2.offset = Y, a2 && a2.idsToInsert) {
            Y += a2.idsToInsert.length * 2, Y > Jp && b2(Y), s2.offset = Y;
            let e3 = lm(q.subarray(t2, Y), a2.idsToInsert);
            return a2 = null, e3;
          }
          return c3 & 512 ? (q.start = t2, q.end = Y, q) : q.subarray(t2, Y);
        } finally {
          if (n2) {
            if (_2 < 10 && _2++, n2.length > l2 && (n2.length = l2), g2 > 1e4) n2.transitions = null, _2 = 0, g2 = 0, h2.length > 0 && (h2 = []);
            else if (h2.length > 0 && !u2) {
              for (let e3 = 0, t3 = h2.length; e3 < t3; e3++) h2[e3][Qp] = void 0;
              h2 = [];
            }
          }
          if (r2 && s2.saveShared) {
            s2.structures.length > l2 && (s2.structures = s2.structures.slice(0, l2));
            let e3 = q.subarray(t2, Y);
            return s2.updateSharedData() === false ? s2.encode(o3) : e3;
          }
          c3 & 1024 && (Y = t2);
        }
      }, this.findCommonStringsToPack = () => (d2 = /* @__PURE__ */ new Map(), m2 ||= /* @__PURE__ */ Object.create(null), (e3) => {
        let t3 = e3 && e3.threshold || 4, n3 = this.pack ? e3.maxPrivatePackedValues || 16 : 0;
        p2 ||= this.sharedValues = [];
        for (let [e4, i3] of d2) i3.count > t3 && (m2[e4] = n3++, p2.push(e4), r2 = true);
        for (; this.saveShared && this.updateSharedData() === false; ) ;
        d2 = null;
      });
      let v2 = (n3) => {
        Y > Jp && (q = b2(Y));
        var r3 = typeof n3, i3;
        if (r3 === `string`) {
          if (f2) {
            let t3 = f2[n3];
            if (t3 >= 0) {
              t3 < 16 ? q[Y++] = t3 + 224 : (q[Y++] = 198, t3 & 1 ? v2(15 - t3 >> 1) : v2(t3 - 16 >> 1));
              return;
            }
            if (d2 && !e2.pack) {
              let e3 = d2.get(n3);
              e3 ? e3.count++ : d2.set(n3, {
                count: 1
              });
            }
          }
          let r4 = n3.length;
          if (Yp && r4 >= 4 && r4 < 1024) {
            if ((Yp.size += r4) > Xp) {
              let e4, n4 = (Yp[0] ? Yp[0].length * 3 + Yp[1].length : 0) + 10;
              Y + n4 > Jp && (q = b2(Y + n4)), q[Y++] = 217, q[Y++] = 223, q[Y++] = 249, q[Y++] = Yp.position ? 132 : 130, q[Y++] = 26, e4 = Y - t2, Y += 4, Yp.position && um(t2, v2), Yp = [
                ``,
                ``
              ], Yp.size = 0, Yp.position = e4;
            }
            let e3 = Zp.test(n3);
            Yp[+!e3] += n3, q[Y++] = e3 ? 206 : 207, v2(r4);
            return;
          }
          let a3;
          a3 = r4 < 32 ? 1 : r4 < 256 ? 2 : r4 < 65536 ? 3 : 5;
          let s3 = r4 * 3;
          if (Y + s3 > Jp && (q = b2(Y + s3)), r4 < 64 || !o2) {
            let e3, t3, o3, s4 = Y + a3;
            for (e3 = 0; e3 < r4; e3++) t3 = n3.charCodeAt(e3), t3 < 128 ? q[s4++] = t3 : t3 < 2048 ? (q[s4++] = t3 >> 6 | 192, q[s4++] = t3 & 63 | 128) : (t3 & 64512) == 55296 && ((o3 = n3.charCodeAt(e3 + 1)) & 64512) == 56320 ? (t3 = 65536 + ((t3 & 1023) << 10) + (o3 & 1023), e3++, q[s4++] = t3 >> 18 | 240, q[s4++] = t3 >> 12 & 63 | 128, q[s4++] = t3 >> 6 & 63 | 128, q[s4++] = t3 & 63 | 128) : (q[s4++] = t3 >> 12 | 224, q[s4++] = t3 >> 6 & 63 | 128, q[s4++] = t3 & 63 | 128);
            i3 = s4 - Y - a3;
          } else i3 = o2(n3, Y + a3, s3);
          i3 < 24 ? q[Y++] = 96 | i3 : i3 < 256 ? (a3 < 2 && q.copyWithin(Y + 2, Y + 1, Y + 1 + i3), q[Y++] = 120, q[Y++] = i3) : i3 < 65536 ? (a3 < 3 && q.copyWithin(Y + 3, Y + 2, Y + 2 + i3), q[Y++] = 121, q[Y++] = i3 >> 8, q[Y++] = i3 & 255) : (a3 < 5 && q.copyWithin(Y + 5, Y + 3, Y + 3 + i3), q[Y++] = 122, J.setUint32(Y, i3), Y += 4), Y += i3;
        } else if (r3 === `number`) {
          if (!this.alwaysUseFloat && n3 >>> 0 === n3) n3 < 24 ? q[Y++] = n3 : n3 < 256 ? (q[Y++] = 24, q[Y++] = n3) : n3 < 65536 ? (q[Y++] = 25, q[Y++] = n3 >> 8, q[Y++] = n3 & 255) : (q[Y++] = 26, J.setUint32(Y, n3), Y += 4);
          else if (!this.alwaysUseFloat && n3 >> 0 === n3) n3 >= -24 ? q[Y++] = 31 - n3 : n3 >= -256 ? (q[Y++] = 56, q[Y++] = ~n3) : n3 >= -65536 ? (q[Y++] = 57, J.setUint16(Y, ~n3), Y += 2) : (q[Y++] = 58, J.setUint32(Y, ~n3), Y += 4);
          else if (!this.alwaysUseFloat && n3 < 0 && n3 >= -4294967296 && Math.floor(n3) === n3) q[Y++] = 58, J.setUint32(Y, -1 - n3), Y += 4;
          else {
            let e3;
            if ((e3 = this.useFloat32) > 0 && n3 < 4294967296 && n3 >= -2147483648) {
              q[Y++] = 250, J.setFloat32(Y, n3);
              let t3;
              if (e3 < 4 || (t3 = n3 * Fp[(q[Y] & 127) << 1 | q[Y + 1] >> 7]) >> 0 === t3) {
                Y += 4;
                return;
              }
              Y--;
            }
            q[Y++] = 251, J.setFloat64(Y, n3), Y += 8;
          }
        } else if (r3 === `object`) {
          if (!n3) q[Y++] = 246;
          else {
            if (a2) {
              let e4 = a2.get(n3);
              if (e4) {
                if (q[Y++] = 216, q[Y++] = 29, q[Y++] = 25, !e4.references) {
                  let t3 = a2.idsToInsert || (a2.idsToInsert = []);
                  e4.references = [], t3.push(e4);
                }
                e4.references.push(Y - t2), Y += 2;
                return;
              }
              a2.set(n3, {
                offset: Y - t2
              });
            }
            let e3 = n3.constructor;
            if (e3 === Object) this.skipFunction === true && (n3 = Object.fromEntries([
              ...Object.keys(n3).filter((e4) => typeof n3[e4] != `function`).map((e4) => [
                e4,
                n3[e4]
              ])
            ])), y2(n3);
            else if (e3 === Array) {
              i3 = n3.length, i3 < 24 ? q[Y++] = 128 | i3 : nm(i3);
              for (let e4 = 0; e4 < i3; e4++) v2(n3[e4]);
            } else if (e3 === Map) {
              if ((this.mapsAsObjects ? this.useTag259ForMaps !== false : this.useTag259ForMaps) && (q[Y++] = 217, q[Y++] = 1, q[Y++] = 3), i3 = n3.size, i3 < 24 ? q[Y++] = 160 | i3 : i3 < 256 ? (q[Y++] = 184, q[Y++] = i3) : i3 < 65536 ? (q[Y++] = 185, q[Y++] = i3 >> 8, q[Y++] = i3 & 255) : (q[Y++] = 186, J.setUint32(Y, i3), Y += 4), s2.keyMap) for (let [e4, t3] of n3) v2(s2.encodeKey(e4)), v2(t3);
              else for (let [e4, t3] of n3) v2(e4), v2(t3);
            } else {
              for (let e4 = 0, t3 = zp.length; e4 < t3; e4++) {
                let t4 = Bp[e4];
                if (n3 instanceof t4) {
                  let t5 = zp[e4], r4 = t5.tag;
                  r4 ??= t5.getTag && t5.getTag.call(this, n3), r4 < 24 ? q[Y++] = 192 | r4 : r4 < 256 ? (q[Y++] = 216, q[Y++] = r4) : r4 < 65536 ? (q[Y++] = 217, q[Y++] = r4 >> 8, q[Y++] = r4 & 255) : r4 > -1 && (q[Y++] = 218, J.setUint32(Y, r4), Y += 4), t5.encode.call(this, n3, v2, b2);
                  return;
                }
              }
              if (n3[Symbol.iterator]) {
                if (qp) {
                  let e4 = Error(`Iterable should be serialized as iterator`);
                  throw e4.iteratorNotHandled = true, e4;
                }
                q[Y++] = 159;
                for (let e4 of n3) v2(e4);
                q[Y++] = 255;
                return;
              }
              if (n3[Symbol.asyncIterator] || im(n3)) {
                let e4 = Error(`Iterable/blob should be serialized as iterator`);
                throw e4.iteratorNotHandled = true, e4;
              }
              if (this.useToJSON && n3.toJSON) {
                let e4 = n3.toJSON();
                if (e4 !== n3) return v2(e4);
              }
              y2(n3);
            }
          }
        } else if (r3 === `boolean`) q[Y++] = n3 ? 245 : 244;
        else if (r3 === `bigint`) {
          if (n3 < BigInt(1) << BigInt(64) && n3 >= 0) q[Y++] = 27, J.setBigUint64(Y, n3);
          else if (n3 > -(BigInt(1) << BigInt(64)) && n3 < 0) q[Y++] = 59, J.setBigUint64(Y, -n3 - BigInt(1));
          else if (this.largeBigIntToFloat) q[Y++] = 251, J.setFloat64(Y, Number(n3));
          else {
            n3 >= BigInt(0) ? q[Y++] = 194 : (q[Y++] = 195, n3 = BigInt(-1) - n3);
            let e3 = [];
            for (; n3; ) e3.push(Number(n3 & BigInt(255))), n3 >>= BigInt(8);
            cm(new Uint8Array(e3.reverse()), b2);
            return;
          }
          Y += 8;
        } else if (r3 === `undefined`) q[Y++] = 247;
        else throw Error(`Unknown type: ` + r3);
      }, y2 = this.useRecords === false ? this.variableMapSize ? (e3) => {
        let t3 = Object.keys(e3), n3 = Object.values(e3), r3 = t3.length;
        if (r3 < 24 ? q[Y++] = 160 | r3 : r3 < 256 ? (q[Y++] = 184, q[Y++] = r3) : r3 < 65536 ? (q[Y++] = 185, q[Y++] = r3 >> 8, q[Y++] = r3 & 255) : (q[Y++] = 186, J.setUint32(Y, r3), Y += 4), s2.keyMap) for (let e4 = 0; e4 < r3; e4++) v2(s2.encodeKey(t3[e4])), v2(n3[e4]);
        else for (let e4 = 0; e4 < r3; e4++) v2(t3[e4]), v2(n3[e4]);
      } : (e3) => {
        q[Y++] = 185;
        let n3 = Y - t2;
        Y += 2;
        let r3 = 0;
        if (s2.keyMap) for (let t3 in e3) (typeof e3.hasOwnProperty != `function` || e3.hasOwnProperty(t3)) && (v2(s2.encodeKey(t3)), v2(e3[t3]), r3++);
        else for (let t3 in e3) (typeof e3.hasOwnProperty != `function` || e3.hasOwnProperty(t3)) && (v2(t3), v2(e3[t3]), r3++);
        q[n3++ + t2] = r3 >> 8, q[n3 + t2] = r3 & 255;
      } : (e3, t3) => {
        let n3, a3 = i2.transitions || (i2.transitions = /* @__PURE__ */ Object.create(null)), o3 = 0, s3 = 0, c3, u3;
        if (this.keyMap) {
          u3 = Object.keys(e3).map((e4) => this.encodeKey(e4)), s3 = u3.length;
          for (let e4 = 0; e4 < s3; e4++) {
            let t4 = u3[e4];
            n3 = a3[t4], n3 || (n3 = a3[t4] = /* @__PURE__ */ Object.create(null), o3++), a3 = n3;
          }
        } else for (let t4 in e3) (typeof e3.hasOwnProperty != `function` || e3.hasOwnProperty(t4)) && (n3 = a3[t4], n3 || (a3[Qp] & 1048576 && (c3 = a3[Qp] & 65535), n3 = a3[t4] = /* @__PURE__ */ Object.create(null), o3++), a3 = n3, s3++);
        let d3 = a3[Qp];
        if (d3 !== void 0) d3 &= 65535, q[Y++] = 217, q[Y++] = d3 >> 8 | 224, q[Y++] = d3 & 255;
        else if (u3 ||= a3.__keys__ || (a3.__keys__ = Object.keys(e3)), c3 === void 0 ? (d3 = i2.nextId++, d3 || (d3 = 0, i2.nextId = 1), d3 >= Gp && (i2.nextId = (d3 = l2) + 1)) : d3 = c3, i2[d3] = u3, d3 < l2) {
          q[Y++] = 217, q[Y++] = d3 >> 8 | 224, q[Y++] = d3 & 255, a3 = i2.transitions;
          for (let e4 = 0; e4 < s3; e4++) (a3[Qp] === void 0 || a3[Qp] & 1048576) && (a3[Qp] = d3), a3 = a3[u3[e4]];
          a3[Qp] = d3 | 1048576, r2 = true;
        } else {
          if (a3[Qp] = d3, J.setUint32(Y, 3655335680), Y += 3, o3 && (g2 += _2 * o3), h2.length >= Gp - l2 && (h2.shift()[Qp] = void 0), h2.push(a3), nm(s3 + 2), v2(57344 + d3), v2(u3), t3) return;
          for (let t4 in e3) (typeof e3.hasOwnProperty != `function` || e3.hasOwnProperty(t4)) && v2(e3[t4]);
          return;
        }
        if (s3 < 24 ? q[Y++] = 128 | s3 : nm(s3), !t3) for (let t4 in e3) (typeof e3.hasOwnProperty != `function` || e3.hasOwnProperty(t4)) && v2(e3[t4]);
      }, b2 = (e3) => {
        let n3;
        if (e3 > 16777216) {
          if (e3 - t2 > Kp) throw Error(`Encoded buffer would be larger than maximum buffer size`);
          n3 = Math.min(Kp, Math.round(Math.max((e3 - t2) * (e3 > 67108864 ? 1.25 : 2), 4194304) / 4096) * 4096);
        } else n3 = (Math.max(e3 - t2 << 2, q.length - 1) >> 12) + 1 << 12;
        let r3 = new Up(n3);
        return J = new DataView(r3.buffer, 0, n3), q.copy ? q.copy(r3, 0, t2, e3) : r3.set(q.slice(t2, e3)), Y -= t2, t2 = 0, Jp = r3.length - 10, q = r3;
      }, ee2 = 100, x2 = 1e3;
      this.encodeAsIterable = function(e3, t3) {
        return T2(e3, t3, S2);
      }, this.encodeAsAsyncIterable = function(e3, t3) {
        return T2(e3, t3, E2);
      };
      function* S2(e3, n3, r3) {
        let i3 = e3.constructor;
        if (i3 === Object) {
          let t3 = s2.useRecords !== false;
          t3 ? y2(e3, true) : em(Object.keys(e3).length, 160);
          for (let r4 in e3) {
            let i4 = e3[r4];
            t3 || v2(r4), i4 && typeof i4 == `object` ? n3[r4] ? yield* S2(i4, n3[r4]) : yield* C2(i4, n3, r4) : v2(i4);
          }
        } else if (i3 === Array) {
          let r4 = e3.length;
          nm(r4);
          for (let i4 = 0; i4 < r4; i4++) {
            let r5 = e3[i4];
            r5 && (typeof r5 == `object` || Y - t2 > ee2) ? n3.element ? yield* S2(r5, n3.element) : yield* C2(r5, n3, `element`) : v2(r5);
          }
        } else if (e3[Symbol.iterator] && !e3.buffer) {
          q[Y++] = 159;
          for (let r4 of e3) r4 && (typeof r4 == `object` || Y - t2 > ee2) ? n3.element ? yield* S2(r4, n3.element) : yield* C2(r4, n3, `element`) : v2(r4);
          q[Y++] = 255;
        } else im(e3) ? (em(e3.size, 64), yield q.subarray(t2, Y), yield e3, w2()) : e3[Symbol.asyncIterator] ? (q[Y++] = 159, yield q.subarray(t2, Y), yield e3, w2(), q[Y++] = 255) : v2(e3);
        r3 && Y > t2 ? yield q.subarray(t2, Y) : Y - t2 > ee2 && (yield q.subarray(t2, Y), w2());
      }
      function* C2(e3, n3, r3) {
        let i3 = Y - t2;
        try {
          v2(e3), Y - t2 > ee2 && (yield q.subarray(t2, Y), w2());
        } catch (a3) {
          if (a3.iteratorNotHandled) n3[r3] = {}, Y = t2 + i3, yield* S2.call(this, e3, n3[r3]);
          else throw a3;
        }
      }
      function w2() {
        ee2 = x2, s2.encode(null, gm);
      }
      function T2(e3, t3, n3) {
        return ee2 = t3 && t3.chunkThreshold ? x2 = t3.chunkThreshold : 100, e3 && typeof e3 == `object` ? (s2.encode(null, gm), n3(e3, s2.iterateProperties ||= {}, true)) : [
          s2.encode(e3)
        ];
      }
      async function* E2(e3, t3) {
        for (let n3 of S2(e3, t3, true)) {
          let e4 = n3.constructor;
          if (e4 === Wp || e4 === Uint8Array) yield n3;
          else if (im(n3)) {
            let e5 = n3.stream().getReader(), t4;
            for (; !(t4 = await e5.read()).done; ) yield t4.value;
          } else if (n3[Symbol.asyncIterator]) for await (let e5 of n3) w2(), e5 ? yield* E2(e5, t3.async ||= {}) : yield s2.encode(e5);
          else yield n3;
        }
      }
    }
    useBuffer(e2) {
      q = e2, J = new DataView(q.buffer, q.byteOffset, q.byteLength), Y = 0;
    }
    clearSharedData() {
      this.structures &&= [], this.sharedValues &&= void 0;
    }
    updateSharedData() {
      let e2 = this.sharedVersion || 0;
      this.sharedVersion = e2 + 1;
      let t2 = this.structures.slice(0), n2 = new tm(t2, this.sharedValues, this.sharedVersion), r2 = this.saveShared(n2, (t3) => (t3 && t3.version || 0) == e2);
      return r2 === false ? (n2 = this.getShared() || {}, this.structures = n2.structures || [], this.sharedValues = n2.packedValues, this.sharedVersion = n2.version, this.structures.nextId = this.structures.length) : t2.forEach((e3, t3) => this.structures[t3] = e3), r2;
    }
  };
  function em(e2, t2) {
    e2 < 24 ? q[Y++] = t2 | e2 : e2 < 256 ? (q[Y++] = t2 | 24, q[Y++] = e2) : e2 < 65536 ? (q[Y++] = t2 | 25, q[Y++] = e2 >> 8, q[Y++] = e2 & 255) : (q[Y++] = t2 | 26, J.setUint32(Y, e2), Y += 4);
  }
  var tm = class {
    constructor(e2, t2, n2) {
      this.structures = e2, this.packedValues = t2, this.version = n2;
    }
  };
  function nm(e2) {
    e2 < 24 ? q[Y++] = 128 | e2 : e2 < 256 ? (q[Y++] = 152, q[Y++] = e2) : e2 < 65536 ? (q[Y++] = 153, q[Y++] = e2 >> 8, q[Y++] = e2 & 255) : (q[Y++] = 154, J.setUint32(Y, e2), Y += 4);
  }
  var rm = typeof Blob > `u` ? function() {
  } : Blob;
  function im(e2) {
    if (e2 instanceof rm) return true;
    let t2 = e2[Symbol.toStringTag];
    return t2 === `Blob` || t2 === `File`;
  }
  function am(e2, t2) {
    switch (typeof e2) {
      case `string`:
        if (e2.length > 3) {
          if (t2.objectMap[e2] > -1 || t2.values.length >= t2.maxValues) return;
          let n3 = t2.get(e2);
          if (n3) ++n3.count == 2 && t2.values.push(e2);
          else if (t2.set(e2, {
            count: 1
          }), t2.samplingPackedValues) {
            let n4 = t2.samplingPackedValues.get(e2);
            n4 ? n4.count++ : t2.samplingPackedValues.set(e2, {
              count: 1
            });
          }
        }
        break;
      case `object`:
        if (e2) {
          if (e2 instanceof Array) for (let n3 = 0, r2 = e2.length; n3 < r2; n3++) am(e2[n3], t2);
          else {
            let r2 = !t2.encoder.useRecords;
            for (var n2 in e2) e2.hasOwnProperty(n2) && (r2 && am(n2, t2), am(e2[n2], t2));
          }
        }
        break;
      case `function`:
        console.log(e2);
    }
  }
  var om = new Uint8Array(new Uint16Array([
    1
  ]).buffer)[0] == 1;
  Bp = [
    Date,
    Set,
    Error,
    RegExp,
    yp,
    ArrayBuffer,
    Uint8Array,
    Uint8ClampedArray,
    Uint16Array,
    Uint32Array,
    typeof BigUint64Array > `u` ? function() {
    } : BigUint64Array,
    Int8Array,
    Int16Array,
    Int32Array,
    typeof BigInt64Array > `u` ? function() {
    } : BigInt64Array,
    Float32Array,
    Float64Array,
    tm
  ], zp = [
    {
      tag: 1,
      encode(e2, t2) {
        let n2 = e2.getTime() / 1e3;
        (this.useTimestamp32 || e2.getMilliseconds() === 0) && n2 >= 0 && n2 < 4294967296 ? (q[Y++] = 26, J.setUint32(Y, n2), Y += 4) : (q[Y++] = 251, J.setFloat64(Y, n2), Y += 8);
      }
    },
    {
      tag: 258,
      encode(e2, t2) {
        t2(Array.from(e2));
      }
    },
    {
      tag: 27,
      encode(e2, t2) {
        t2([
          e2.name,
          e2.message
        ]);
      }
    },
    {
      tag: 27,
      encode(e2, t2) {
        t2([
          `RegExp`,
          e2.source,
          e2.flags
        ]);
      }
    },
    {
      getTag(e2) {
        return e2.tag;
      },
      encode(e2, t2) {
        t2(e2.value);
      }
    },
    {
      encode(e2, t2, n2) {
        cm(e2, n2);
      }
    },
    {
      getTag(e2) {
        if (e2.constructor === Uint8Array && (this.tagUint8Array || Hp && this.tagUint8Array !== false)) return 64;
      },
      encode(e2, t2, n2) {
        cm(e2, n2);
      }
    },
    sm(68, 1),
    sm(69, 2),
    sm(70, 4),
    sm(71, 8),
    sm(72, 1),
    sm(77, 2),
    sm(78, 4),
    sm(79, 8),
    sm(85, 4),
    sm(86, 8),
    {
      encode(e2, t2) {
        let n2 = e2.packedValues || [], r2 = e2.structures || [];
        if (n2.values.length > 0) {
          q[Y++] = 216, q[Y++] = 51, nm(4);
          let e3 = n2.values;
          t2(e3), nm(0), nm(0), packedObjectMap = Object.create(sharedPackedObjectMap || null);
          for (let t3 = 0, n3 = e3.length; t3 < n3; t3++) packedObjectMap[e3[t3]] = t3;
        }
        if (r2) {
          J.setUint32(Y, 3655335424), Y += 3;
          let n3 = r2.slice(0);
          n3.unshift(57344), n3.push(new yp(e2.version, 1399353956)), t2(n3);
        } else t2(new yp(e2.version, 1399353956));
      }
    }
  ];
  function sm(e2, t2) {
    return !om && t2 > 1 && (e2 -= 4), {
      tag: e2,
      encode: function(e3, t3) {
        let n2 = e3.byteLength, r2 = e3.byteOffset || 0, i2 = e3.buffer || e3;
        t3(Hp ? Vp.from(i2, r2, n2) : new Uint8Array(i2, r2, n2));
      }
    };
  }
  function cm(e2, t2) {
    let n2 = e2.byteLength;
    n2 < 24 ? q[Y++] = 64 + n2 : n2 < 256 ? (q[Y++] = 88, q[Y++] = n2) : n2 < 65536 ? (q[Y++] = 89, q[Y++] = n2 >> 8, q[Y++] = n2 & 255) : (q[Y++] = 90, J.setUint32(Y, n2), Y += 4), Y + n2 >= q.length && t2(Y + n2), q.set(e2.buffer ? e2 : new Uint8Array(e2), Y), Y += n2;
  }
  function lm(e2, t2) {
    let n2, r2 = t2.length * 2, i2 = e2.length - r2;
    t2.sort((e3, t3) => e3.offset > t3.offset ? 1 : -1);
    for (let n3 = 0; n3 < t2.length; n3++) {
      let r3 = t2[n3];
      r3.id = n3;
      for (let t3 of r3.references) e2[t3++] = n3 >> 8, e2[t3] = n3 & 255;
    }
    for (; n2 = t2.pop(); ) {
      let t3 = n2.offset;
      e2.copyWithin(t3 + r2, t3, i2), r2 -= 2;
      let a2 = t3 + r2;
      e2[a2++] = 216, e2[a2++] = 28, i2 = t3;
    }
    return e2;
  }
  function um(e2, t2) {
    J.setUint32(Yp.position + e2, Y - Yp.position - e2 + 1);
    let n2 = Yp;
    Yp = null, t2(n2[0]), t2(n2[1]);
  }
  var dm = new $p({
    useRecords: false
  });
  dm.encode, dm.encodeAsIterable, dm.encodeAsAsyncIterable;
  var { NEVER: fm, ALWAYS: pm, DECIMAL_ROUND: mm, DECIMAL_FIT: hm } = Lp, gm = 2048, _m = 1, vm = new ip({
    mapsAsObjects: true,
    copyBuffers: true
  });
  async function ym(e2, t2) {
    if (t2.length !== 32) throw Error(`openSealedBundle: edSeed must be 32 bytes (got ${t2.length})`);
    let n2 = et.utils.toMontgomerySecret(t2), r2 = Cf(e2)[0];
    return bm(r2, n2);
  }
  async function bm(e2, t2) {
    if (e2.chunks.length === 0) throw Error(`openBundle: no chunks`);
    let n2 = [];
    for (let r3 of e2.chunks) {
      let i3 = Cm(r3.sealedBytes), a3 = Tf({
        version: _m,
        bundleId: e2.bundleId,
        chunkIndex: r3.chunkIndex,
        totalChunks: r3.totalChunks,
        digestAlgo: e2.digestAlgo
      }), o3 = wm(await Af({
        recipientSecret: t2,
        kemEncap: i3.kem_encap,
        ciphertext: i3.aead_ciphertext,
        aad: a3
      }));
      if (!Em(o3.bundle_id, e2.bundleId) || o3.chunk_index !== r3.chunkIndex || o3.total_chunks !== r3.totalChunks || o3.version !== _m) throw Error(`openBundle: inner ChunkPlaintext header disagrees with armor header`);
      n2.push(o3);
    }
    n2.sort((e3, t3) => e3.chunk_index - t3.chunk_index);
    let r2 = n2[0].total_chunks;
    if (n2.length !== r2) throw Error(`openBundle: have ${n2.length} chunks, expected ${r2}`);
    for (let e3 = 0; e3 < n2.length; e3++) if (n2[e3].chunk_index !== e3) throw Error(`openBundle: chunk index gap or duplicate at position ${e3}`);
    let i2 = n2.reduce((e3, t3) => e3 + t3.payload_fragment.length, 0), a2 = new Uint8Array(i2), o2 = 0;
    for (let e3 of n2) a2.set(e3.payload_fragment, o2), o2 += e3.payload_fragment.length;
    let s2 = Tm(vm.decode(a2));
    return {
      bundleId: e2.bundleId,
      digestAlgo: e2.digestAlgo,
      payload: s2
    };
  }
  async function xm(e2, t2) {
    let n2 = await ym(e2, t2);
    if (n2.payload.kind !== `admin_rotation`) {
      let e3 = n2.payload.kind === `other` ? n2.payload.tag : n2.payload.kind;
      throw Error(`openAdminRotationBundle: expected admin_rotation variant, got '${e3}'`);
    }
    return {
      bundleId: n2.bundleId,
      payload: n2.payload.body
    };
  }
  function Sm(e2, t2) {
    if (e2 instanceof Uint8Array) return e2;
    if (Array.isArray(e2)) {
      let n2 = new Uint8Array(e2.length);
      for (let r2 = 0; r2 < e2.length; r2++) {
        let i2 = e2[r2];
        if (typeof i2 != `number` || !Number.isInteger(i2) || i2 < 0 || i2 > 255) throw Error(`${t2}: array entry ${r2} is not a byte (got ${typeof i2} ${String(i2)})`);
        n2[r2] = i2;
      }
      return n2;
    }
    throw Error(`${t2}: expected CBOR bytes or array of u8, got ${typeof e2}`);
  }
  function Cm(e2) {
    let t2 = vm.decode(e2), n2 = Sm(t2.kem_encap, `HpkeSealed.kem_encap`), r2 = Sm(t2.aead_ciphertext, `HpkeSealed.aead_ciphertext`);
    if (n2.length !== 32) throw Error(`HpkeSealed.kem_encap: must be 32 bytes (got ${n2.length})`);
    return {
      kem_encap: n2,
      aead_ciphertext: r2
    };
  }
  function wm(e2) {
    let t2 = vm.decode(e2), n2 = t2.version, r2 = t2.chunk_index, i2 = t2.total_chunks;
    if (typeof n2 != `number`) throw Error(`ChunkPlaintext: version missing/wrong`);
    if (typeof r2 != `number`) throw Error(`ChunkPlaintext: chunk_index missing`);
    if (typeof i2 != `number`) throw Error(`ChunkPlaintext: total_chunks missing`);
    let a2 = Sm(t2.bundle_id, `ChunkPlaintext.bundle_id`);
    if (a2.length !== 16) throw Error(`ChunkPlaintext.bundle_id: must be 16 bytes (got ${a2.length})`);
    let o2 = {
      version: n2,
      bundle_id: a2,
      chunk_index: r2,
      total_chunks: i2,
      payload_fragment: Sm(t2.payload_fragment, `ChunkPlaintext.payload_fragment`)
    };
    typeof t2.producer_did == `string` && (o2.producer_did = t2.producer_did);
    let s2 = t2.producer_assertion;
    return s2 !== void 0 && (o2.producer_assertion = s2), o2;
  }
  function Tm(e2) {
    let t2 = Object.keys(e2);
    if (t2.length !== 1) throw Error(`SealedPayloadV1: expected externally-tagged map with one key, got ${t2.length}`);
    let n2 = t2[0], r2 = e2[n2];
    if (!r2 || typeof r2 != `object`) throw Error(`SealedPayloadV1: body for tag '${n2}' is not an object`);
    switch (n2) {
      case `admin_rotation`:
        return {
          kind: `admin_rotation`,
          body: r2
        };
      case `template_bootstrap`:
        return {
          kind: `template_bootstrap`,
          body: r2
        };
      default:
        return {
          kind: `other`,
          tag: n2,
          body: r2
        };
    }
  }
  function Em(e2, t2) {
    if (e2.length !== t2.length) return false;
    for (let n2 = 0; n2 < e2.length; n2++) if (e2[n2] !== t2[n2]) return false;
    return true;
  }
  var Dm = `https://www.w3.org/ns/credentials/v2`, Om = `https://openvtc.org/contexts/bootstrap-v1`;
  async function km(e2) {
    let t2 = new Uint8Array(16);
    crypto.getRandomValues(t2);
    let n2 = new Date((/* @__PURE__ */ new Date()).getTime() + (e2.validityMs ?? 9e5)), r2 = {
      "@context": [
        Dm,
        Om
      ],
      type: [
        `VerifiablePresentation`,
        `BootstrapRequest`
      ],
      id: `urn:uuid:${crypto.randomUUID()}`,
      holder: e2.ephemeral.did,
      nonce: Ee(t2),
      validUntil: n2.toISOString(),
      ...e2.label ? {
        label: e2.label
      } : {},
      ask: e2.ask,
      proof: null
    };
    return await u({
      envelope: r2,
      signing: e2.ephemeral,
      proofPurpose: `authentication`
    }), {
      vp: r2,
      nonce: t2
    };
  }
  var Am = 6e4;
  function jm(e2) {
    if (!(e2 instanceof _)) return;
    let t2 = e2.details;
    if (!t2 || typeof t2.code != `string`) return;
    let n2 = t2.details?.candidates;
    return {
      code: t2.code,
      message: typeof t2.message == `string` ? t2.message : e2.message,
      candidates: Array.isArray(n2) ? n2.filter((e3) => typeof e3 == `string`) : []
    };
  }
  async function Mm(e2) {
    let t2 = R(ar, e2.body, {
      issuer: e2.ephemeralDid,
      recipient: e2.vtaDid
    });
    return e2.sender.send(t2, {
      expectedResponseType: or,
      operationLabel: `provision/integration/0.3`,
      timeoutMs: e2.timeoutMs ?? Am
    });
  }
  async function Nm(e2) {
    let t2 = {
      type: `adminRotation`,
      contextHint: e2.context,
      adminTemplate: {
        name: e2.adminTemplateName ?? `vta-admin`,
        vars: {}
      },
      ...e2.note ? {
        note: e2.note
      } : {}
    }, { vp: n2, nonce: r2 } = await km({
      ephemeral: e2.ephemeralSigning,
      ask: t2,
      ...e2.note ? {
        label: e2.note
      } : {}
    }), i2 = await Mm({
      sender: e2.sender,
      ephemeralDid: e2.ephemeralSigning.did,
      vtaDid: e2.vtaDid,
      body: {
        request: n2,
        context: e2.context,
        ...e2.adminScope && e2.adminScope !== `context` ? {
          adminScope: e2.adminScope
        } : {},
        ...e2.createContext ? {
          createContext: true
        } : {}
      },
      ...e2.timeoutMs === void 0 ? {} : {
        timeoutMs: e2.timeoutMs
      }
    }), a2 = Pm(r2);
    if (i2.summary.bundleIdHex !== a2) throw Error(`provision-integration: bundleIdHex mismatch \u2014 expected ${a2}, got ${i2.summary.bundleIdHex}`);
    if (e2.ephemeralSigning.privateKey.length !== 32) throw Error(`provision-integration: ephemeral Ed25519 seed must be 32 bytes`);
    let o2 = await xm(i2.bundle, e2.ephemeralSigning.privateKey), s2 = o2.payload.admin;
    if (!s2 || !s2.did) throw Error(`provision-integration: AdminRotation payload missing admin.did`);
    if (!s2.signing_key?.private_key_multibase || !s2.ka_key?.private_key_multibase) throw Error(`provision-integration: AdminRotation payload missing admin signing/ka private key`);
    if (i2.summary.adminDid && i2.summary.adminDid !== s2.did) throw Error(`provision-integration: summary.adminDid (${i2.summary.adminDid}) disagrees with sealed admin.did (${s2.did})`);
    return {
      adminDid: s2.did,
      adminSigningPrivateMultibase: s2.signing_key.private_key_multibase,
      adminKaPrivateMultibase: s2.ka_key.private_key_multibase,
      vtaDid: o2.payload.vta_trust?.vta_did ?? e2.vtaDid,
      ...o2.payload.vta_url ? {
        vtaUrl: o2.payload.vta_url
      } : {},
      summary: i2.summary,
      context: i2.summary.context ?? e2.context,
      adminScope: i2.summary.adminScope ?? `context`
    };
  }
  function Pm(e2) {
    let t2 = ``;
    for (let n2 = 0; n2 < e2.length; n2++) t2 += e2[n2].toString(16).padStart(2, `0`);
    return t2;
  }
  var Fm = new Uint8Array([
    128,
    38
  ]), Im = new Uint8Array([
    130,
    38
  ]);
  function Lm(e2) {
    let t2 = Rm(e2.adminSigningPrivateMultibase, Fm, `signing (Ed25519)`), n2 = Rm(e2.adminKaPrivateMultibase, Im, `keyAgreement (X25519)`), r2 = et.utils.toMontgomerySecret(t2);
    if (!Bm(r2, n2)) throw Error(`provision-integration: VTA's ka_key.private_key_multibase does not equal toMontgomerySecret(signing seed). The wallet stores the seed and re-derives X25519 on demand; a mismatch would break DIDComm.`);
    let i2 = et.getPublicKey(t2), a2 = zm(e2.adminDid), o2 = qe(a2);
    if (!Bm(o2.codec, De.ED25519_PUB)) throw Error(`provision-integration: adminDid '${e2.adminDid}' is not an Ed25519 did:key`);
    if (!Bm(o2.key, i2)) throw Error(`provision-integration: adminDid's multibase identifier does not encode the Ed25519 public key that the shipped seed expands to. The wallet would publish a DID it does not actually control.`);
    let s2 = $e.getPublicKey(r2), c2 = ke(De.X25519_PUB, s2), l2 = `${e2.adminDid}#${c2}`, u2 = `${e2.adminDid}#${a2}`;
    return {
      did: e2.adminDid,
      signingKid: u2,
      keyAgreementKid: l2,
      edSeed: t2,
      vtaDid: e2.vtaDid,
      ...e2.vtaUrl ? {
        vtaUrl: e2.vtaUrl
      } : {}
    };
  }
  function Rm(e2, t2, n2) {
    let { codec: r2, key: i2 } = qe(e2);
    if (!Bm(r2, t2)) throw Error(`provision-integration: ${n2} multicodec mismatch \u2014 expected ${Vm(t2)}, got ${Vm(r2)}`);
    if (i2.length !== 32) throw Error(`provision-integration: ${n2} key length ${i2.length} != 32 bytes`);
    return i2;
  }
  function zm(e2) {
    if (!e2.startsWith(`did:key:`)) throw Error(`provision-integration: '${e2}' is not a did:key`);
    let t2 = e2.slice(8);
    if (!t2.startsWith(`z`)) throw Error(`provision-integration: did:key identifier '${t2}' is not base58btc multibase`);
    return t2;
  }
  function Bm(e2, t2) {
    if (e2.length !== t2.length) return false;
    let n2 = 0;
    for (let r2 = 0; r2 < e2.length; r2++) n2 |= e2[r2] ^ t2[r2];
    return n2 === 0;
  }
  function Vm(e2) {
    let t2 = ``;
    for (let n2 = 0; n2 < e2.length; n2++) t2 += e2[n2].toString(16).padStart(2, `0`);
    return t2;
  }
  function Hm() {
    let e2 = Date.now(), t2 = e2, n2 = [];
    return {
      marks: n2,
      mark(e3) {
        let r2 = Date.now();
        n2.push({
          label: e3,
          ms: r2 - t2
        }), t2 = r2;
      },
      total() {
        return Date.now() - e2;
      }
    };
  }
  var Um = `https://trusttasks.org/spec/auth/oob`, Wm = {
    claim: `${Um}/claim/0.1`,
    prove: `${Um}/prove/0.1`,
    identify: `${Um}/identify/0.1`,
    respond: `${Um}/respond/0.1`,
    grant: `${Um}/grant/0.1`,
    cancel: `${Um}/cancel/0.1`,
    prove02: `${Um}/prove/0.2`,
    respond02: `${Um}/respond/0.2`,
    grant02: `${Um}/grant/0.2`
  }, Gm = [
    `auth`,
    `acl`,
    `consent`,
    `task-consent`,
    `confirm`
  ], Km = /^[a-z][a-z0-9-]*(\/[a-z][a-z0-9-]*)*$/, qm = (e2) => `${e2}#response`, Jm = `org.openvtc.session`;
  function Ym(e2) {
    let t2 = e2.ext;
    if (t2 == null) return `member`;
    if (typeof t2 != `object`) return;
    let n2 = t2[Jm];
    if (n2 === void 0) return `member`;
    let r2 = n2?.audience;
    return r2 === `member` || r2 === `admin` ? r2 : void 0;
  }
  var Xm = class extends Error {
    code;
    constructor(e2, t2) {
      super(t2), this.code = e2, this.name = `OobRefusedError`;
    }
  }, Zm = `auth/oob/reply-invalid`, X = class extends Error {
    code = Zm;
    constructor(e2) {
      super(e2), this.name = `OobReplyInvalidError`;
    }
  }, Qm = `SignInPortal`;
  function $m(e2, t2) {
    return typeof e2.type == `string` ? e2.type === t2 : Array.isArray(e2.type) && e2.type.includes(t2);
  }
  function eh(e2) {
    if (typeof e2 == `string`) return e2;
    if (Array.isArray(e2)) return e2.map(eh).find((e3) => e3 !== void 0);
    if (e2 && typeof e2 == `object` && typeof e2.uri == `string`) return e2.uri;
  }
  function th(e2) {
    let t2 = eh(e2);
    if (t2 === void 0) return;
    let n2;
    try {
      n2 = new URL(t2);
    } catch {
      return;
    }
    if (!(n2.protocol !== `https:` || n2.username || n2.password || n2.port)) return rn(n2.hostname) ? {
      url: n2,
      text: t2
    } : void 0;
  }
  function nh(e2) {
    let t2 = Array.isArray(e2?.service) ? e2.service : [], n2, r2, i2 = false, a2 = false;
    for (let e3 of t2) if (e3 && typeof e3 == `object` && ($m(e3, `SignInPortal`) && (i2 = true), $m(e3, `TrustTaskHTTPS`) && (a2 = true), !n2 && $m(e3, `SignInPortal`) && (n2 = th(e3.serviceEndpoint)?.url), !r2 && $m(e3, `TrustTaskHTTPS`))) {
      let t3 = th(e3.serviceEndpoint)?.text;
      t3 !== void 0 && (r2 = xr(t3));
    }
    return n2 ? r2 ? {
      ok: true,
      services: {
        portalOrigin: n2.origin,
        trustTaskEndpoint: r2
      }
    } : {
      ok: false,
      reason: `no-common-transport`,
      service: gr,
      ...a2 ? {
        unusable: true
      } : {}
    } : {
      ok: false,
      reason: `no-portal-service`,
      service: Qm,
      ...i2 ? {
        unusable: true
      } : {}
    };
  }
  function rh(e2, t2) {
    return typeof e2 == `string` && e2.length > 0 && e2 === t2;
  }
  async function ih(e2, t2 = {}) {
    return Pn(e2, {
      ...t2.resolveDid ? {
        resolveDid: t2.resolveDid
      } : {},
      ...t2.contactMethods ? {
        methods: t2.contactMethods
      } : {}
    });
  }
  function ah() {
    return ai();
  }
  function oh(e2, t2, n2, r2) {
    return {
      id: globalThis.crypto.randomUUID(),
      type: e2,
      issuer: t2,
      recipient: n2,
      issuedAt: (/* @__PURE__ */ new Date()).toISOString(),
      payload: r2
    };
  }
  function sh(e2, t2, n2) {
    return {
      ...oh(Wm.claim, e2.did, t2, {
        requestId: n2
      }),
      parentThreadId: n2
    };
  }
  function ch(e2, t2, n2) {
    if (!/^[0-9]{2}$/.test(n2.enteredNumber)) throw new X(`the number must be the two digits shown on the screen`);
    return oh(Wm.identify, e2, t2, n2);
  }
  function lh(e2, t2, n2, r2, i2 = `0.1`) {
    return {
      ...oh(i2 === `0.2` ? Wm.prove02 : Wm.prove, e2.did, t2, {
        identify: n2
      }),
      parentThreadId: r2
    };
  }
  function uh(e2, t2, n2, r2 = `0.1`) {
    if (r2 === `0.1` && n2.signingScope !== void 0) throw new X(`a 0.1 grant cannot delegate signing`);
    return oh(r2 === `0.2` ? Wm.grant02 : Wm.grant, e2, t2, n2);
  }
  function dh(e2, t2, n2, r2, i2 = `0.1`) {
    return {
      ...oh(i2 === `0.2` ? Wm.respond02 : Wm.respond, e2.did, t2, {
        grant: n2
      }),
      parentThreadId: r2
    };
  }
  function fh(e2, t2, n2) {
    return oh(Wm.cancel, e2.did, t2, {
      requestId: n2
    });
  }
  function ph(e2, t2, n2) {
    if (!t2 || typeof t2 != `object`) throw new X(`the VTA returned no document`);
    let { proof: r2, ...i2 } = t2;
    if (!r2 || typeof r2 != `object`) throw new X(`the VTA returned the document unsigned`);
    let { proof: a2, ...o2 } = e2;
    if (ut(i2) !== ut(o2)) throw new X(`the VTA changed the document it was asked to sign`);
    let s2 = r2.proofPurpose;
    if (s2 !== n2) throw new X(`the VTA signed for ${String(s2)}, not ${n2}`);
    return t2;
  }
  async function mh(e2) {
    let t2 = await pt(ut(e2)), n2 = new Uint8Array(2 + t2.length);
    return n2.set([
      18,
      32
    ], 0), n2.set(t2, 2), `z${dt(n2)}`;
  }
  function hh(e2) {
    return mh(e2);
  }
  function gh(e2) {
    let { proof: t2, ...n2 } = e2;
    return mh(n2);
  }
  var _h = 1e4;
  function vh(e2) {
    let t2 = Number(e2.headers.get(`retry-after`)), n2 = Number.isFinite(t2) && t2 > 0 ? t2 * 1e3 : 2e3;
    return Math.min(n2, _h);
  }
  async function yh(e2, t2, n2, r2, i2 = `assertionMethod`) {
    if (t2.issuer !== e2.did || t2.recipient !== n2.vtcDid) throw new X(`${r2}: the document is not from K_a to the community`);
    return await u({
      envelope: t2,
      signing: e2,
      proofPurpose: `authentication`
    }), bh(t2, n2, r2, i2);
  }
  async function bh(e2, t2, n2, r2) {
    if (e2.recipient !== t2.vtcDid) throw new X(`${n2}: the document is not addressed to the community`);
    let i2 = mr(t2.fetch), a2 = t2.sleep ?? ((e3) => new Promise((t3) => setTimeout(t3, e3))), o2;
    for (let r3 = 0; ; r3++) {
      try {
        o2 = await i2(t2.trustTaskEndpoint, {
          method: `POST`,
          headers: {
            "content-type": `application/json`
          },
          body: JSON.stringify(e2),
          redirect: `error`,
          credentials: `omit`
        });
      } catch (e3) {
        throw new Xm(hr(e3) ? `timeout` : `network`, `${n2}: the community could not be reached`);
      }
      if (o2.status !== 429 || r3 >= 3) break;
      await a2(vh(o2));
    }
    let s2;
    try {
      s2 = await o2.json();
    } catch {
      throw new Xm(`http-${o2.status}`, `${n2}: the community answered ${o2.status} with no document`);
    }
    if (ie(s2?.type)) {
      let e3 = s2.payload?.code;
      throw new Xm(typeof e3 == `string` ? e3 : `taskFailed`, `${n2}: refused (${String(e3)})`);
    }
    if (!o2.ok) throw new Xm(`http-${o2.status}`, `${n2}: the community answered ${o2.status}`);
    if (s2?.type !== qm(e2.type)) throw new X(`${n2}: unexpected reply type ${String(s2?.type)}`);
    if (s2.threadId !== e2.id) throw new X(`${n2}: the reply is not threaded to this request`);
    if (s2.recipient !== void 0 && s2.recipient !== e2.issuer) throw new X(`${n2}: the reply is addressed to someone else`);
    return await xh(s2, t2.vtcDid, t2.vtcDocument, n2, r2), {
      doc: s2,
      payload: s2.payload
    };
  }
  async function xh(e2, t2, n2, r2, i2 = `assertionMethod`) {
    let a2 = await ft(e2, {
      expectedProofPurpose: i2,
      resolveDid: async (e3) => {
        if (e3 !== t2) throw Error(`reply signed by ${e3}, not the community`);
        return n2;
      }
    });
    if (!a2.verified || a2.signer !== t2) throw new X(`${r2}: the reply is not signed by the community (${a2.reason ?? `wrong signer`})`);
    let o2 = e2.proof.verificationMethod, s2 = n2[i2], c2 = Array.isArray(s2) ? s2 : [], l2 = o2.slice(o2.indexOf(`#`));
    if (!c2.some((e3) => {
      let t3 = typeof e3 == `string` ? e3 : e3?.id;
      return typeof t3 == `string` && (t3 === o2 || t3 === l2);
    })) throw new X(`${r2}: the signing key is not one of the community's ${i2} keys`);
  }
  function Sh(e2, t2) {
    let n2 = (e3) => {
      throw new X(`step 1: ${e3}`);
    };
    (!e2 || typeof e2 != `object`) && n2(`no payload`), e2.requestId !== t2.requestId && n2(`a different request`), e2.service?.did !== t2.vtcDid && n2(`a different community`), typeof e2.service?.name != `string` && n2(`no community name`), e2.purpose !== `login` && n2(`a purpose other than login`), e2.origin !== t2.portalOrigin && n2(`an origin the community's document does not list`), Ym(e2) === void 0 && n2(`a session this wallet does not know`);
    let r2 = Ch(e2.decisionDeadline);
    return r2 === void 0 && n2(`no decision deadline`), r2 <= t2.now && n2(`the decision deadline has passed`), e2;
  }
  function Ch(e2) {
    return typeof e2 == `number` && Number.isSafeInteger(e2) && e2 >= 0 ? e2 * 1e3 : void 0;
  }
  function wh(e2, t2, n2) {
    let r2 = (e3) => {
      throw new X(`step 2: ${e3}`);
    };
    (!e2 || typeof e2 != `object`) && r2(`no payload`);
    let i2 = (e3) => ({
      requestId: e3.requestId,
      service: e3.service,
      origin: e3.origin,
      purpose: e3.purpose,
      decisionDeadline: e3.decisionDeadline
    });
    if (ut(i2(e2)) !== ut(i2(t2)) && r2(`it does not repeat step 1`), Ym(e2) !== Ym(t2) && r2(`it names a different session than step 1`), (typeof e2.sessionKey != `string` || !/^did:key:z6Mk[1-9A-HJ-NP-Za-km-z]+$/.test(e2.sessionKey)) && r2(`the session key is not an Ed25519 did:key`), e2.identifiedAs !== n2 && r2(`a different identity`), e2.signingScope !== void 0) {
      let t3 = e2.signingScope;
      (!Array.isArray(t3) || t3.length === 0 || t3.length > 8 || new Set(t3).size !== t3.length) && r2(`a malformed signing scope`);
      for (let e3 of t3) (typeof e3 != `string` || !Km.test(e3)) && r2(`a malformed signing scope`), Gm.some((t4) => e3 === t4 || e3.startsWith(`${t4}/`)) && r2(`it asks to let the browser sign ${e3} documents as you, which a wallet never delegates`);
    }
    let a2 = e2.requester;
    return (!a2 || typeof a2.location != `string` || typeof a2.browser != `string` || typeof a2.os != `string`) && r2(`no requester details`), e2;
  }
  function Th(e2) {
    return e2 === true ? `same` : e2 === false ? `different` : `unknown`;
  }
  var Eh = `/.well-known/did-configuration.json`, Dh = 65536, Oh = 32, kh = `DomainLinkageCredential`, Ah = class extends Error {
  };
  function Z(e2) {
    throw new Ah(e2);
  }
  async function jh(e2) {
    try {
      let t2 = Mh(e2.origin), n2 = await Nh(t2, e2), r2 = `no linked DID`;
      for (let i2 of n2.linked_dids.slice(0, Oh)) try {
        return {
          ok: true,
          format: await Ih(i2, {
            did: e2.did,
            didDocument: e2.didDocument,
            origin: t2,
            now: e2.now
          })
        };
      } catch (e3) {
        if (!(e3 instanceof Ah)) throw e3;
        r2 = e3.message;
      }
      return {
        ok: false,
        reason: `domain-not-linked`,
        detail: r2
      };
    } catch (e3) {
      return {
        ok: false,
        reason: `domain-not-linked`,
        detail: e3 instanceof Ah ? e3.message : `unexpected error`
      };
    }
  }
  function Mh(e2) {
    let t2;
    try {
      t2 = new URL(e2);
    } catch {
      return Z(`the portal origin is not a URL`);
    }
    return (t2.protocol !== `https:` || t2.origin !== e2) && Z(`the portal origin is not an https origin`), e2;
  }
  async function Nh(e2, t2) {
    let n2 = `${e2}${Eh}`, r2 = mr(t2.fetch, t2.timeoutMs ?? 1e4), i2;
    try {
      i2 = await r2(n2, {
        method: `GET`,
        headers: {
          accept: `application/json`
        },
        credentials: `omit`,
        redirect: `error`
      });
    } catch (e3) {
      return Z(hr(e3) ? `timeout` : `unreachable`);
    }
    if ((i2.redirected || i2.type === `opaqueredirect`) && Z(`redirected`), i2.url) {
      let t3;
      try {
        t3 = new URL(i2.url).origin;
      } catch {
        t3 = void 0;
      }
      t3 !== e2 && Z(`redirected`);
    }
    i2.status !== 200 && Z(`status ${i2.status}`);
    let a2 = await Ph(i2, Dh), o2;
    try {
      o2 = JSON.parse(a2);
    } catch {
      return Z(`not JSON`);
    }
    let s2 = o2;
    return (!s2 || typeof s2 != `object` || Array.isArray(s2)) && Z(`not a DID Configuration`), s2[`@context`] !== `https://identity.foundation/.well-known/did-configuration/v1` && Z(`wrong @context`), Array.isArray(s2.linked_dids) || Z(`no linked_dids`), s2;
  }
  async function Ph(e2, t2) {
    let n2 = Number(e2.headers.get(`content-length`));
    Number.isFinite(n2) && n2 > t2 && Z(`too large`);
    let r2 = new TextDecoder(`utf-8`, {
      fatal: true
    }), i2 = e2.body?.getReader();
    if (!i2) {
      let n3 = new Uint8Array(await e2.arrayBuffer());
      return n3.length > t2 && Z(`too large`), Fh(r2, n3);
    }
    let a2 = [], o2 = 0;
    for (; ; ) {
      let { done: e3, value: n3 } = await i2.read();
      if (e3) break;
      o2 += n3.length, o2 > t2 && (await i2.cancel().catch(() => void 0), Z(`too large`)), a2.push(n3);
    }
    let s2 = new Uint8Array(o2), c2 = 0;
    for (let e3 of a2) s2.set(e3, c2), c2 += e3.length;
    return Fh(r2, s2);
  }
  function Fh(e2, t2) {
    try {
      return e2.decode(t2);
    } catch {
      return Z(`not UTF-8`);
    }
  }
  async function Ih(e2, t2) {
    return typeof e2 == `string` ? (await Uh(e2, t2), `jwt`) : e2 && typeof e2 == `object` && !Array.isArray(e2) ? (await Gh(e2, t2), `jsonld`) : Z(`an entry that is neither a JWT nor a credential`);
  }
  function Lh(e2) {
    return e2 && typeof e2 == `object` ? e2.id : e2;
  }
  function Rh(e2, t2, n2) {
    let r2 = e2.type;
    (!Array.isArray(r2) || !r2.includes(kh)) && Z(`not a DomainLinkageCredential`), (n2 || e2.issuer !== void 0) && Lh(e2.issuer) !== t2.did && Z(`wrong issuer`);
    let i2 = e2.credentialSubject;
    (!i2 || typeof i2 != `object` || Array.isArray(i2)) && Z(`no credentialSubject`), i2.id !== t2.did && Z(`wrong subject DID`), i2.origin !== t2.origin && Z(`wrong origin`);
    let a2 = zh(e2.validFrom ?? e2.issuanceDate), o2 = zh(e2.validUntil ?? e2.expirationDate);
    return {
      ...a2 === void 0 ? {} : {
        from: a2
      },
      ...o2 === void 0 ? {} : {
        until: o2
      }
    };
  }
  function zh(e2) {
    if (e2 === void 0) return;
    if (typeof e2 != `string`) return Z(`a date that is not a string`);
    let t2 = Date.parse(e2);
    return Number.isFinite(t2) || Z(`a date that does not parse`), t2;
  }
  function Bh(e2, t2, n2) {
    let r2 = 6e4;
    t2 === void 0 && Z(`no expiry`), e2 !== void 0 && e2 - r2 > n2 && Z(`not yet valid`), t2 + r2 <= n2 && Z(`expired`);
  }
  function Vh(e2) {
    let t2;
    try {
      t2 = JSON.parse(new TextDecoder(`utf-8`, {
        fatal: true
      }).decode(te(e2)));
    } catch {
      return Z(`a malformed JWT`);
    }
    return (!t2 || typeof t2 != `object` || Array.isArray(t2)) && Z(`a malformed JWT`), t2;
  }
  function Hh(e2, t2) {
    if (e2 !== void 0) return typeof e2 != `number` || !Number.isFinite(e2) ? Z(`a malformed ${t2}`) : e2 * 1e3;
  }
  async function Uh(e2, t2) {
    let n2 = e2.split(`.`);
    n2.length !== 3 && Z(`a malformed JWT`);
    let [r2, i2, a2] = n2, o2 = Vh(r2), s2 = Vh(i2), c2 = o2.alg;
    c2 !== `EdDSA` && c2 !== `ES256` && Z(`an unsupported JWT alg`), o2.crit !== void 0 && Z(`a JWT with crit`), s2.iss !== t2.did && Z(`wrong issuer`), s2.sub !== t2.did && Z(`wrong subject DID`);
    let l2 = s2.vc;
    (!l2 || typeof l2 != `object` || Array.isArray(l2)) && Z(`no vc claim`);
    let u2 = Rh(l2, t2, false), d2 = Hh(s2.nbf, `nbf`), f2 = Hh(s2.exp, `exp`), p2 = [
      d2,
      u2.from
    ].filter((e3) => e3 !== void 0), m2 = [
      f2,
      u2.until
    ].filter((e3) => e3 !== void 0);
    Bh(p2.length ? Math.max(...p2) : void 0, m2.length ? Math.min(...m2) : void 0, t2.now);
    let h2 = o2.kid;
    (typeof h2 != `string` || h2.length === 0) && Z(`a JWT with no kid`);
    let g2 = h2.startsWith(`#`) ? `${t2.did}${h2}` : h2;
    g2.startsWith(`${t2.did}#`) || Z(`a key of another DID`);
    let _2 = Wh(t2.didDocument, g2);
    c2 === `EdDSA` != (_2.curve === `Ed25519`) && Z(`the alg does not match the key`);
    let v2;
    try {
      v2 = te(a2);
    } catch {
      return Z(`a malformed JWT signature`);
    }
    v2.length !== 64 && Z(`bad signature`);
    let y2 = new TextEncoder().encode(`${r2}.${i2}`), b2 = false;
    try {
      b2 = _2.curve === `Ed25519` ? et.verify(v2, y2, _2.bytes) : Pe.verify(v2, y2, _2.bytes, {
        prehash: true,
        lowS: false
      });
    } catch {
      b2 = false;
    }
    b2 || Z(`bad signature`);
  }
  function Wh(e2, t2) {
    mt(e2, t2, `assertionMethod`) || Z(`a key not under assertionMethod`);
    let n2 = t2.slice(t2.indexOf(`#`)), r2 = (e3) => {
      let r3 = e3?.id;
      return r3 === t2 || r3 === n2;
    }, i2 = Array.isArray(e2.assertionMethod) ? e2.assertionMethod.find((e3) => e3 && typeof e3 == `object` && r2(e3)) : void 0, a2 = Array.isArray(e2.verificationMethod) ? e2.verificationMethod.find(r2) : void 0, o2 = i2 ?? a2;
    if (!o2) return Z(`a key the document does not have`);
    try {
      if (typeof o2.publicKeyMultibase == `string`) {
        let { codec: e4, key: t3 } = qe(o2.publicKeyMultibase), n3 = (t4) => e4.length === t4.length && e4.every((e5, n4) => e5 === t4[n4]);
        return n3(De.ED25519_PUB) && t3.length === 32 ? {
          curve: `Ed25519`,
          bytes: t3
        } : n3(De.P256_PUB) ? {
          curve: `P-256`,
          bytes: t3
        } : Z(`an unsupported key type`);
      }
      let e3 = o2.publicKeyJwk;
      if (e3 && typeof e3 == `object`) {
        if (e3.kty === `OKP` && e3.crv === `Ed25519` && typeof e3.x == `string`) {
          let t3 = te(e3.x);
          if (t3.length === 32) return {
            curve: `Ed25519`,
            bytes: t3
          };
        }
        if (e3.kty === `EC` && e3.crv === `P-256` && typeof e3.x == `string` && typeof e3.y == `string`) {
          let t3 = te(e3.x), n3 = te(e3.y);
          if (t3.length === 32 && n3.length === 32) {
            let e4 = new Uint8Array(65);
            return e4[0] = 4, e4.set(t3, 1), e4.set(n3, 33), {
              curve: `P-256`,
              bytes: e4
            };
          }
        }
      }
    } catch (e3) {
      if (e3 instanceof Ah) throw e3;
      return Z(`a malformed key`);
    }
    return Z(`an unsupported key type`);
  }
  async function Gh(e2, t2) {
    let n2 = Rh(e2, t2, true);
    Bh(n2.from, n2.until, t2.now);
    let r2 = e2.proof;
    (!r2 || typeof r2 != `object` || Array.isArray(r2)) && Z(`no single proof`), (r2.type !== `DataIntegrityProof` || r2.cryptosuite !== `eddsa-jcs-2022`) && Z(`an unsupported proof`), r2.proofPurpose !== `assertionMethod` && Z(`a proof not for assertionMethod`);
    let i2 = r2.verificationMethod;
    (typeof i2 != `string` || !i2.startsWith(`${t2.did}#`)) && Z(`a key of another DID`);
    let a2 = r2[`@context`];
    if (a2 !== void 0) {
      let t3 = [].concat(e2[`@context`] ?? []);
      [].concat(a2).some((e3, n3) => JSON.stringify(e3) !== JSON.stringify(t3[n3])) && Z(`a proof @context that does not match`);
    }
    mt(t2.didDocument, i2, `assertionMethod`) || Z(`a key not under assertionMethod`);
    let o2 = await ft(e2, {
      expectedProofPurpose: `assertionMethod`,
      resolveDid: async (e3) => {
        if (e3 !== t2.did) throw Error(`another DID`);
        return t2.didDocument;
      }
    });
    (!o2.verified || o2.signer !== t2.did) && Z(`bad signature`);
  }
  var Kh = `https://trusttasks.org/spec/vtc/join-requests/manifest/0.3`, qh = `https://trusttasks.org/spec/vtc/join-requests/manifest/0.4`, Jh = `https://trusttasks.org/spec/vtc/join-requests/submit/0.3`, Yh = [
    `admins`,
    `groups`,
    `connections`,
    `members`,
    `public`
  ], Xh = {
    admins: `the community's administrators only`,
    groups: `members who share a group with you`,
    connections: `members you have a verified relationship with`,
    members: `the community's other members`,
    public: `anyone, outside the community too`
  };
  function Zh(e2) {
    let t2 = e2, n2 = (e3) => new X(`directory disclosure: ${e3}`);
    if (!t2 || typeof t2 != `object`) throw n2(`not an object`);
    if (!Array.isArray(t2.fields)) throw n2(`no fields`);
    for (let e3 of t2.fields) if (!e3 || typeof e3.label != `string` || !Yh.includes(e3.ceiling) || !Yh.includes(e3.defaultVisibility)) throw n2(`a field without a label or its audiences`);
    if (!t2.newCard || typeof t2.newCard.listing != `string`) throw n2(`no new-card defaults`);
    if (!Yh.includes(t2.membershipIdentifiers)) throw n2(`no membership-identifier reach`);
    if (typeof t2.adminNotes != `boolean` || typeof t2.externalCards != `boolean`) throw n2(`does not say whether notes are kept or cards published`);
    if (typeof t2.statementDigest != `string` || t2.statementDigest === ``) throw n2(`no statementDigest`);
    return t2;
  }
  function Qh(e2) {
    let t2 = /^P(?:(\d+)W)?(?:(\d+)D)?$/.exec(e2);
    if (!t2 || !t2[1] && !t2[2]) return e2;
    let n2 = Number(t2[1] ?? 0) * 7 + Number(t2[2] ?? 0);
    return n2 === 1 ? `1 day` : `${n2} days`;
  }
  function $h(e2) {
    return e2.length < 2 ? e2.join(``) : `${e2.slice(0, -1).join(`, `)} and ${e2.at(-1)}`;
  }
  function eg(e2) {
    let t2 = [], n2 = Yh.filter((e3) => e3 !== `admins`).map((t3) => ({
      a: t3,
      labels: e2.fields.filter((e3) => e3.defaultVisibility === t3).map((e3) => e3.label)
    })).filter((e3) => e3.labels.length > 0);
    for (let e3 of n2) t2.push(`Your ${$h(e3.labels)} will be seen by ${Xh[e3.a]}.`);
    t2.push(n2.length > 0 ? `Anything else you add is seen by the administrators only, until you choose otherwise.` : `Anything you add is seen by the administrators only, until you choose otherwise.`);
    let r2 = Yh.filter((e3) => e3 !== `admins`).map((t3) => ({
      a: t3,
      labels: e2.fields.filter((e3) => e3.ceiling === t3).map((e3) => e3.label)
    })).filter((e3) => e3.labels.length > 0);
    for (let e3 of r2) t2.push(`You may choose to show your ${$h(e3.labels)} to ${Xh[e3.a]}, and no further.`);
    let i2 = e2.fields.filter((e3) => e3.source === `admin`).map((e3) => e3.label);
    return i2.length > 0 && t2.push(`The community sets your ${$h(i2)} itself; you can read ${i2.length === 1 ? `it` : `them`} but not change ${i2.length === 1 ? `it` : `them`}.`), t2.push(e2.newCard.listing === `listed` ? `Members browsing the directory will find you; you can hide yourself.` : e2.newCard.listing === `findable` ? `Members can find you by searching, not by browsing; you can hide yourself.` : `Members won't find you in the directory unless you choose to be listed.`), t2.push(e2.membershipIdentifiers === `admins` ? `The DID you join with is seen by the administrators only.` : `The DID you join with is seen by the administrators only, unless you choose to show it to ${Xh[e2.membershipIdentifiers]}.`), t2.push(e2.adminNotes ? `The administrators may keep notes about you. They never appear on your card.` : `The administrators keep no notes about members.`), e2.groups && typeof e2.groups.credentialValidity == `string` && t2.push(`If you join a group you'll hold a credential showing it, valid for ${Qh(e2.groups.credentialValidity)} at a time, which you can show outside the community.`), t2.push(e2.externalCards ? `You may publish your card beyond the community; it is off unless you turn it on.` : `Your card is never published outside the community.`), t2;
  }
  var tg = /^(x:)?[a-z][A-Za-z0-9]*(\.[a-z][A-Za-z0-9]*)*$/;
  function ng(e2) {
    let t2 = [];
    return e2.invitationRequired === true && t2.push(`an invitation from the community`), e2.presentationDefinition !== void 0 && t2.push(`a credential`), e2.vetting !== void 0 && t2.push(`identity vetting by its vetters`), t2;
  }
  function rg(e2) {
    let t2 = typeof e2.branding?.displayName == `string` && e2.branding.displayName.trim() !== `` ? e2.branding.displayName.trim() : void 0, n2 = t2 === void 0 ? {} : {
      displayName: t2
    }, r2 = Array.isArray(e2.criteria) ? e2.criteria : [];
    if (r2.length === 0) return {
      ok: false,
      reason: `not-accepting`,
      needs: [],
      ...n2
    };
    let i2 = r2.filter((e3) => ng(e3).length === 0 && typeof e3.requirementsDigest == `string` && (e3.admission === `automatic` || e3.admission === `review`)), a2 = i2.find((e3) => e3.admission === `automatic`) ?? i2[0];
    if (!a2) {
      let e3 = [];
      for (let t3 of r2) {
        let n3 = typeof t3.description == `string` && t3.description.trim() !== `` ? t3.description.trim() : ng(t3).join(` and `);
        n3 && !e3.includes(n3) && e3.push(n3);
      }
      return {
        ok: false,
        reason: `needs-more`,
        needs: e3,
        ...n2
      };
    }
    let o2 = (e2.requestedAttributes ?? []).filter((e3) => typeof e3?.type == `string` && tg.test(e3.type)).map((e3) => ({
      type: e3.type,
      required: e3.required === true,
      ...typeof e3.purpose == `string` && e3.purpose.trim() !== `` ? {
        purpose: e3.purpose.trim()
      } : {}
    })), s2 = e2.directoryDisclosure ? {
      directory: {
        lines: eg(e2.directoryDisclosure),
        statementDigest: e2.directoryDisclosure.statementDigest
      }
    } : {};
    return {
      ok: true,
      criterion: a2.requirementsDigest,
      admission: a2.admission,
      requestedAttributes: o2,
      ...n2,
      ...s2
    };
  }
  function ig(e2, t2, n2, r2) {
    return {
      id: globalThis.crypto.randomUUID(),
      type: e2,
      issuer: t2,
      recipient: n2,
      issuedAt: (/* @__PURE__ */ new Date()).toISOString(),
      payload: r2
    };
  }
  function ag(e2, t2, n2 = `0.4`) {
    return ig(n2 === `0.4` ? qh : Kh, e2, t2, {});
  }
  function og(e2, t2) {
    let n2 = e2;
    if (!n2 || typeof n2 != `object`) throw new X(`join manifest: no payload`);
    if (n2.communityDid !== t2) throw new X(`join manifest: a different community`);
    if (!Array.isArray(n2.criteria)) throw new X(`join manifest: no criteria`);
    return n2.directoryDisclosure !== void 0 && Zh(n2.directoryDisclosure), n2;
  }
  function sg(e2, t2, n2) {
    return ig(Jh, e2, t2, {
      vp: {
        "@context": [
          `https://www.w3.org/ns/credentials/v2`
        ],
        type: [
          `VerifiablePresentation`
        ],
        holder: e2
      },
      criterion: n2.criterion,
      registryConsent: n2.registryConsent,
      ...n2.attributes.length > 0 ? {
        attributes: n2.attributes.map((e3) => ({
          type: e3.type,
          value: e3.value
        }))
      } : {},
      ...n2.extensions && Object.keys(n2.extensions).length > 0 ? {
        extensions: n2.extensions
      } : {}
    });
  }
  function cg(e2) {
    let t2 = e2;
    if (!t2 || typeof t2.requestId != `string` || !t2.verdict || typeof t2.verdict != `object`) throw new X(`join submit: no verdict`);
    let n2 = t2.verdict.with ?? {}, r2 = (e3) => typeof e3 == `string` && e3.trim() !== `` ? e3.trim() : void 0;
    switch (t2.verdict.effect) {
      case `allow`: {
        let e3 = r2(n2.role);
        return {
          kind: `admitted`,
          requestId: t2.requestId,
          ...e3 ? {
            role: e3
          } : {}
        };
      }
      case `refer`:
        return {
          kind: `pending`,
          requestId: t2.requestId
        };
      case `requestMore`: {
        let e3 = Array.isArray(n2.needs) ? n2.needs.filter((e4) => typeof e4 == `string`) : [];
        return {
          kind: `pending`,
          requestId: t2.requestId,
          ...e3.length ? {
            needs: e3
          } : {}
        };
      }
      case `deny`: {
        let e3 = r2(n2.code), i2 = r2(n2.reason);
        return {
          kind: `declined`,
          requestId: t2.requestId,
          ...e3 ? {
            code: e3
          } : {},
          ...i2 ? {
            reason: i2
          } : {}
        };
      }
      default:
        throw new X(`join submit: an effect this wallet does not know (${String(t2.verdict.effect)})`);
    }
  }
  var lg = `https://trusttasks.org/spec/vtc/directory/card/show/0.1`, ug = `https://trusttasks.org/spec/vtc/directory/fields/list/0.1`, dg = `https://trusttasks.org/spec/vtc/directory/card/publish/0.1`, fg = `https://trusttasks.org/spec/keys/list/0.1`, pg = `https://trusttasks.org/spec/keys/list/0.1#response`, mg = `https://trusttasks.org/spec/keys/sign-document/0.1`, hg = `https://trusttasks.org/spec/keys/sign-document/0.1#response`, gg = `urn:vtc-directory:`;
  function _g(e2, t2, n2, r2) {
    return {
      id: globalThis.crypto.randomUUID(),
      type: e2,
      issuer: t2,
      recipient: n2,
      issuedAt: (/* @__PURE__ */ new Date()).toISOString(),
      payload: r2
    };
  }
  function vg(e2, t2) {
    return _g(lg, e2, t2, {});
  }
  function yg(e2, t2) {
    return _g(ug, e2, t2, {});
  }
  function bg(e2, t2) {
    let n2 = e2.values ?? {}, r2 = e2.visibility ?? {};
    return [
      ...t2
    ].filter((e3) => e3.state === `active` && e3.ceiling === `public`).filter((e3) => (r2[e3.key] ?? e3.defaultVisibility) === `public`).filter((e3) => n2[e3.key] !== void 0 && n2[e3.key] !== null).sort((e3, t3) => (e3.order ?? 0) - (t3.order ?? 0)).map((e3) => ({
      field: e3,
      value: n2[e3.key]
    }));
  }
  function xg(e2) {
    let t2 = e2;
    return t2 && typeof t2 == `object` && typeof t2.sha256 == `string` && typeof t2.mediaType == `string` ? t2 : null;
  }
  function Sg(e2, t2, n2) {
    switch (t2.base ? t2.jsContactPath : void 0) {
      case `name.full`:
        return [
          `name`,
          {
            full: n2
          }
        ];
      case `nicknames`:
        return [
          `nicknames`,
          {
            k1: {
              name: n2
            }
          }
        ];
      case `media`: {
        let r3 = xg(n2);
        return [
          `media`,
          {
            m1: {
              kind: `photo`,
              uri: `${gg}${e2}:${t2.key}:${r3?.sha256 ?? ``}`,
              mediaType: r3?.mediaType ?? null
            }
          }
        ];
      }
      case `speakToAs.pronouns`:
        return [
          `speakToAs`,
          {
            pronouns: {
              p1: {
                pronouns: n2
              }
            }
          }
        ];
      case `notes`:
        return [
          `notes`,
          {
            n1: {
              note: n2
            }
          }
        ];
      case `links`:
        if (Array.isArray(n2)) return [
          `links`,
          Object.fromEntries(n2.map((e3, t3) => [
            `l${t3 + 1}`,
            {
              uri: e3
            }
          ]))
        ];
    }
    let r2 = xg(n2);
    if (r2) {
      let { url: e3, urlExpiresAt: n3, ...i2 } = r2;
      return [
        t2.key,
        i2
      ];
    }
    return [
      t2.key,
      n2
    ];
  }
  function Cg(e2) {
    return Array.isArray(e2) ? e2.map(String).join(`, `) : e2 === true ? `Yes` : e2 === false ? `No` : String(e2);
  }
  function wg(e2, t2, n2) {
    let r2 = t2.entryId, i2 = {
      "@type": `Card`,
      version: `1.0`,
      uid: `${gg}${r2}`,
      issuer: e2
    }, a2 = [];
    for (let { field: e3, value: o2 } of bg(t2, n2)) {
      let [t3, n3] = Sg(r2, e3, o2);
      i2[t3] = n3;
      let s2 = e3.type === `image` ? xg(o2) : null;
      a2.push(s2 ? {
        key: e3.key,
        label: e3.label,
        text: null,
        picture: s2
      } : {
        key: e3.key,
        label: e3.label,
        text: Cg(o2)
      });
    }
    return {
      card: i2,
      values: a2,
      revision: t2.revision,
      entryId: r2
    };
  }
  function Tg(e2, t2) {
    return {
      meaning: [
        `Anyone will be able to find and read this card \u2014 people outside ${e2} too.`,
        `${e2} will serve it exactly as you sign it, and its trust registry will point to it.`
      ],
      values: t2.values.map((e3) => `${e3.label}: ${e3.text ?? `your picture`}`),
      closing: `If you change what you show to anyone, the card stops being published until you sign it again. You can stop publishing at any time.`
    };
  }
  function Eg(e2, t2, n2) {
    let r2 = t2, i2 = (e3) => new X(`signed card: ${e3}`);
    if (!r2 || typeof r2 != `object`) throw i2(`not an object`);
    let { proof: a2, ...o2 } = r2;
    if (JSON.stringify(Dg(o2)) !== JSON.stringify(Dg(e2))) throw i2(`the agent changed the card`);
    let s2 = a2;
    if (!s2 || s2.type !== `DataIntegrityProof` || s2.proofPurpose !== `assertionMethod`) throw i2(`no assertionMethod Data Integrity proof`);
    if (typeof s2.verificationMethod != `string` || !s2.verificationMethod.startsWith(`${n2}#`)) throw i2(`the proof is not the member's`);
    return r2;
  }
  function Dg(e2) {
    return Array.isArray(e2) ? e2.map(Dg) : e2 && typeof e2 == `object` ? Object.fromEntries(Object.keys(e2).sort().map((t2) => [
      t2,
      Dg(e2[t2])
    ])) : e2;
  }
  function Og(e2, t2, n2, r2) {
    return _g(dg, e2, t2, {
      card: n2,
      expectedRevision: r2
    });
  }
  function kg(e2) {
    let t2 = e2?.externalCard;
    if (!t2 || t2.state !== `published` && t2.state !== `awaitingSignature`) throw new X(`card/publish: no externalCard state`);
    return t2;
  }
  function Ag(e2) {
    try {
      let t2 = we(e2), n2 = t2.length === 34 && t2[0] === 237 && t2[1] === 1 ? t2.slice(2) : t2;
      return n2.length === 32 ? Array.from(n2, (e3) => e3.toString(16).padStart(2, `0`)).join(``) : null;
    } catch {
      return null;
    }
  }
  function jg(e2, t2) {
    let n2 = /* @__PURE__ */ new Set();
    if (e2.startsWith(`did:key:`)) {
      let t3 = Ag(e2.slice(8));
      return t3 && n2.add(t3), n2;
    }
    if (!t2) return n2;
    let r2 = (t3) => t3.startsWith(`#`) ? `${e2}${t3}` : t3, i2 = /* @__PURE__ */ new Map(), a2 = (e3) => {
      let t3 = e3;
      if (typeof t3?.id == `string` && typeof t3.publicKeyMultibase == `string`) {
        let e4 = Ag(t3.publicKeyMultibase);
        e4 && i2.set(r2(t3.id), e4);
      }
    }, o2 = t2.verificationMethod;
    Array.isArray(o2) && o2.forEach(a2);
    let s2 = t2.assertionMethod;
    if (Array.isArray(s2)) for (let e3 of s2) if (typeof e3 == `string`) {
      let t3 = i2.get(r2(e3));
      t3 && n2.add(t3);
    } else {
      a2(e3);
      let t3 = e3?.id, o3 = typeof t3 == `string` ? i2.get(r2(t3)) : void 0;
      o3 && n2.add(o3);
    }
    return n2;
  }
  async function Mg(e2, t2, n2, r2) {
    let i2 = jg(n2, r2);
    if (i2.size === 0) return null;
    for (let n3 = 0; ; n3 += 100) {
      let r3 = await e2.send(R(fg, {
        status: `active`,
        offset: n3,
        limit: 100
      }, {
        issuer: t2.holder.did,
        recipient: t2.service.did
      }), {
        expectedResponseType: pg,
        operationLabel: `keys/list/0.1`
      });
      for (let e3 of r3.keys ?? []) {
        let t3 = e3.keyType === `ed25519` ? Ag(e3.publicKey) : null;
        if (t3 && i2.has(t3)) return e3.keyId;
      }
      if (!r3.keys?.length || n3 + r3.keys.length >= (r3.total ?? 0)) return null;
    }
  }
  async function Ng(e2, t2, n2, r2, i2) {
    let a2 = await e2.send(R(mg, {
      keyId: n2,
      document: r2,
      proofPurpose: `assertionMethod`
    }, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    }), {
      expectedResponseType: hg,
      operationLabel: `keys/sign-document/0.1`
    });
    if (a2.signerDid !== i2) throw new X(`keys/sign-document: signed as someone else`);
    return Eg(r2, a2.document, i2);
  }
  function Pg() {
    return false;
  }
  function Fg(e2 = {}) {
    let t2 = e2.allowHosts && e2.allowHosts.length > 0 ? [
      ...e2.allowHosts
    ] : void 0;
    return {
      ...Pg() ? {
        allowInsecure: true,
        allowPrivate: true
      } : {},
      ...t2 ? {
        allowHosts: t2
      } : {}
    };
  }
  var Ig = 3e4;
  function Lg(e2, t2, n2 = Ig) {
    return e2.isOpen ? e2.expiresAt === void 0 || t2 < e2.expiresAt - n2 : false;
  }
  function Rg(e2) {
    let t2 = e2.intervalMs ?? 5e3, n2 = e2.toleranceMs ?? 2e4, r2 = e2.now ?? Date.now, i2 = e2.setInterval ?? ((e3, t3) => setInterval(e3, t3)), a2 = e2.clearInterval ?? ((e3) => clearInterval(e3)), o2 = r2(), s2 = i2(() => {
      let i3 = r2(), a3 = i3 - o2;
      o2 = i3, a3 > t2 + n2 && e2.onWake(a3);
    }, t2);
    return () => a2(s2);
  }
  function zg(e2, t2 = {}) {
    if (!e2.isOpen) {
      e2.close();
      return;
    }
    (t2.setTimeout ?? ((e3, t3) => setTimeout(e3, t3)))(() => e2.close(), t2.graceMs ?? 35e3);
  }
  async function Bg(e2, t2) {
    if (!e2) return false;
    let n2 = await e2.catch(() => void 0);
    return n2 !== void 0 && n2 !== t2();
  }
  async function Vg() {
    if ((await Mt()).encryptHolderSecret) return new Ct(chrome.runtime.id);
  }
  async function Hg(e2) {
    let t2 = await Vg();
    return vt(new Dt(), {
      vtaDid: e2,
      ...t2 ? {
        secretWrap: t2
      } : {}
    });
  }
  var Ug = {
    blockedEndpoint: `mediator/blocked-endpoint`,
    originNotAllowed: `mediator/origin-not-allowed`,
    unreachable: `mediator/unreachable`,
    timeout: `mediator/timeout`,
    rejected: `mediator/rejected`,
    noReply: `mediator/no-reply`,
    unknown: `mediator/unknown`
  };
  function Wg(e2) {
    let { error: t2, reachable: n2, host: r2, origin: i2 } = e2, a2 = r2 ? ` at ${r2}` : ``;
    if (it(t2)) {
      let e3 = t2.host ?? r2;
      return {
        code: Ug.blockedEndpoint,
        detail: `This wallet refused the endpoint${e3 ? ` ${e3}` : ``} because it names a host that is not on the public internet, so nothing was contacted.`,
        remediation: "Check the endpoints in the mediator's DID document. A wallet will not dial loopback, a private, link-local or carrier-NAT address, or a local-only name such as `localhost` \u2014 whoever operates this mediator has to advertise the address it is reachable at from the internet. Only a development build of this extension talks to a local stack."
      };
    }
    return hr(t2) ? {
      code: Ug.timeout,
      detail: `The mediator${a2} did not answer before the request deadline.`
    } : t2 instanceof TypeError ? n2 === `reachable` ? {
      code: Ug.originNotAllowed,
      detail: `The mediator${a2} is up and answering, but refused this request. A browser extension is a cross-origin caller, so the mediator has to allow this wallet's origin explicitly${i2 ? ` (${i2})` : ``}.`,
      remediation: "Whoever operates this mediator needs to add the origin to `[security] cors_allow_origin` in its `mediator.toml` and restart it. The same setting also gates the WebSocket upgrade, so nothing this wallet can grant locally substitutes for it."
    } : n2 === `unreachable` ? {
      code: Ug.unreachable,
      detail: `Nothing answered at the mediator's address${a2}.`,
      remediation: `Check the mediator is running and that the endpoint in its DID document is the one it actually serves.`
    } : {
      code: Ug.unknown,
      detail: `The connection to the mediator${a2} failed before it produced a response.`
    } : {
      code: Ug.rejected,
      detail: `The mediator${a2} answered and refused the request: ${Jg(t2)}`
    };
  }
  async function Gg(e2, t2) {
    try {
      return await t2(e2, {
        method: `GET`,
        mode: `no-cors`,
        cache: `no-store`,
        redirect: `follow`
      }), `reachable`;
    } catch (e3) {
      return hr(e3) || e3 instanceof TypeError ? `unreachable` : `unprobed`;
    }
  }
  function Kg(e2) {
    if (e2) try {
      return new URL(e2).origin;
    } catch {
      return;
    }
  }
  function qg(e2) {
    return e2 instanceof Error ? e2.message : String(e2);
  }
  function Jg(e2) {
    let { status: t2, body: n2 } = e2, r2 = typeof t2 == `number` ? ` (HTTP ${t2})` : ``, i2 = typeof n2 == `string` ? n2.trim() : ``, a2 = i2 ? ` \u2014 it said: ${JSON.stringify(i2.slice(0, 200))}` : ``;
    return `${qg(e2)}${r2}${a2}`;
  }
  var Yg = 3e5, Xg = `\0`, Zg = class {
    until = /* @__PURE__ */ new Map();
    lastNotified = /* @__PURE__ */ new Map();
    noteNoReply(e2, t2, n2) {
      this.until.set(e2 + Xg + t2, n2 + Yg);
    }
    isSittingOut(e2, t2, n2) {
      let r2 = e2 + Xg + t2, i2 = this.until.get(r2);
      return i2 === void 0 ? false : n2 < i2 || (this.until.delete(r2), false);
    }
    isAnySittingOut(e2, t2) {
      let n2 = e2 + Xg;
      for (let [e3, r2] of this.until) if (e3.startsWith(n2) && t2 < r2) return true;
      return false;
    }
    claimNotification(e2, t2) {
      let n2 = this.lastNotified.get(e2);
      return n2 !== void 0 && t2 - n2 < 18e5 ? false : (this.lastNotified.set(e2, t2), true);
    }
  };
  function Qg(e2) {
    return `no reply through ${e2} within the request timeout, so requests go over REST for a few minutes. Approval requests from this agent come through the same mediator and may not be arriving either.`;
  }
  function $g(e2) {
    return {
      title: `Your agent switched to REST`,
      message: `${e2} stopped replying through its mediator, so the wallet is using REST instead. Approval requests from it may not reach you until its mediator connection is fixed.`
    };
  }
  function e_(e2) {
    let t2 = e2.split(`:`);
    return t2[0] === `did` && t2[1] === `webvh` && t2.length >= 4 ? t2.slice(3).map(decodeURIComponent).join(`/`) : e2;
  }
  function t_(e2) {
    return [
      `TSP`,
      `DIDComm`
    ].filter((t2) => e2[t2]?.state === `down` && e2[t2]?.code === Ug.noReply);
  }
  function n_(e2, t2) {
    if (t2) return e2;
    let n2 = {
      ...e2
    };
    for (let t3 of t_(e2)) delete n2[t3];
    return n2;
  }
  var r_ = `org.openvtc.rooms`;
  function i_(e2) {
    return e2 === void 0 ? {} : {
      ext: {
        [r_]: {
          member: e2
        }
      }
    };
  }
  var a_ = `https://trusttasks.org/spec/rooms/blobs/upload/chunk/0.2`, o_ = `https://trusttasks.org/spec/rooms/blobs/upload/chunk/0.2#response`, s_ = `https://trusttasks.org/spec/rooms/blobs/upload/commit/0.2`, c_ = `https://trusttasks.org/spec/rooms/blobs/upload/commit/0.2#response`, l_ = `https://trusttasks.org/spec/rooms/blobs/upload/abort/0.2`, u_ = `https://trusttasks.org/spec/rooms/blobs/upload/abort/0.2#response`, d_ = `https://trusttasks.org/spec/rooms/keys/file-key/0.1`, f_ = `https://trusttasks.org/spec/rooms/keys/file-key/0.1#response`, p_ = class {
    hostDid;
    endpoint;
    signer;
    policyFetch;
    constructor(e2) {
      this.hostDid = e2.hostDid, this.endpoint = e2.endpoint, this.signer = e2.signing ? v(e2.signing) : void 0, this.policyFetch = Me(e2.fetch, {
        label: `room host`,
        schemes: [
          `https:`
        ],
        ...e2.netPolicy
      });
    }
    async send(e2, t2 = {}) {
      let n2 = t2.operationLabel ?? e2.type;
      if (this.checkAddressed(e2, n2), !this.signer) throw new _(`e.client.identity`, `${n2}: this channel to ${this.hostDid} carries completed documents only, and signs nothing`);
      return await c(e2, this.signer), this.post(e2, n2, t2);
    }
    async sendCompleted(e2, t2 = {}) {
      let n2 = e2, r2 = t2.operationLabel ?? String(n2.type);
      if (this.checkAddressed(n2, r2), typeof n2.issuer != `string` || !e2.proof) throw new _(`e.client.identity`, `${r2}: the document came back from the VTA without an issuer or a proof, so it is not one the member signed`);
      return this.post(n2, r2, t2);
    }
    checkAddressed(e2, t2) {
      if (e2.recipient !== this.hostDid) throw new _(`e.client.parse`, `${t2}: the document is addressed to ${String(e2.recipient)}, not to the host ${this.hostDid}`);
    }
    async post(e2, t2, n2) {
      let r2 = n2.timeoutMs ?? 2e4, i2;
      try {
        i2 = await mr(this.policyFetch, r2)(this.endpoint, {
          method: `POST`,
          headers: {
            "content-type": `application/json`
          },
          body: JSON.stringify(e2),
          credentials: `omit`
        });
      } catch (e3) {
        throw hr(e3) ? new _(`e.client.timeout`, `${t2}: the room host did not respond within ${r2 / 1e3}s`) : new _(`e.client.network`, `${t2}: the room host could not be reached (${e3.message})`);
      }
      return Mr(i2, {
        ...n2.expectedResponseType === void 0 ? {} : {
          expectedResponseType: n2.expectedResponseType
        },
        operationLabel: t2,
        expectedSigner: this.hostDid,
        inReplyTo: e2
      });
    }
  }, m_ = class extends _ {
    did;
    reason = `noTrustTaskService`;
    constructor(e2) {
      super(`e.client.parse`, `${e2} advertises no TrustTaskHTTPS service, so there is nowhere to send a room request`), this.did = e2, this.name = `NoTrustTaskServiceError`;
    }
  };
  function h_(e2) {
    return e2?.reason === `noTrustTaskService`;
  }
  async function g_(e2, t2 = Oe) {
    let n2 = br(await t2(e2));
    if (!n2) throw new m_(e2);
    return xr(n2);
  }
  var __ = `https://trusttasks.org/spec/rooms/keys/list/0.2`, v_ = `https://trusttasks.org/spec/rooms/keys/list/0.2#response`, y_ = `https://trusttasks.org/spec/rooms/keys/list/0.1`, b_ = `https://trusttasks.org/spec/rooms/keys/list/0.1#response`, x_ = `https://trusttasks.org/spec/rooms/keys/open/0.1`, S_ = `https://trusttasks.org/spec/rooms/keys/open/0.1#response`, C_ = `https://trusttasks.org/spec/rooms/records/list/0.1`, w_ = `https://trusttasks.org/spec/rooms/records/list/0.1#response`, T_ = `https://trusttasks.org/spec/rooms/records/put/0.1`, E_ = `https://trusttasks.org/spec/rooms/records/put/0.1#response`, D_ = `https://trusttasks.org/spec/rooms/keys/act/0.1`, O_ = `https://trusttasks.org/spec/rooms/keys/act/0.1#response`, k_ = `https://trusttasks.org/spec/rooms/keys/act/0.5`, A_ = `https://trusttasks.org/spec/rooms/keys/act/0.5#response`, j_ = `https://trusttasks.org/spec/rooms/keys/seal/0.2`, M_ = `https://trusttasks.org/spec/rooms/keys/seal/0.2#response`, N_ = `https://trusttasks.org/spec/rooms/info/0.1`, P_ = `https://trusttasks.org/spec/rooms/info/0.1#response`, F_ = `https://trusttasks.org/spec/rooms/records/curate/0.1`, I_ = `https://trusttasks.org/spec/rooms/records/curate/0.1#response`, L_ = `https://trusttasks.org/spec/rooms/records/put/0.2`, R_ = `https://trusttasks.org/spec/rooms/records/put/0.2#response`;
  function z_(e2, t2, n2, r2) {
    return R(e2, n2, {
      id: `urn:uuid:${globalThis.crypto.randomUUID()}`,
      recipient: t2,
      ...r2 === void 0 ? {} : {
        issuer: r2
      }
    });
  }
  async function B_(e2, t2, n2, r2 = `0.1`) {
    let i2 = R(r2 === `0.5` ? k_ : D_, {
      document: n2
    }, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    }), a2 = await e2.send(i2, {
      expectedResponseType: r2 === `0.5` ? A_ : O_,
      operationLabel: `rooms/keys/act/${r2}`
    }), o2 = a2.document, s2 = a2.principal, c2 = (e3) => {
      throw Error(`${t2.service.did} completed ${n2.type} as the member, but ${e3}`);
    };
    (typeof s2 != `string` || !s2.startsWith(`did:`)) && c2(`named no member it acted as`), (!o2 || typeof o2 != `object`) && c2(`returned no document`), (o2.id !== n2.id || o2.type !== n2.type || o2.recipient !== n2.recipient) && c2(`the document it returned is not the one it was asked to complete`), o2.issuer !== s2 && c2(`the document is issued by ${String(o2.issuer)}, not ${s2}`), n2.issuer !== void 0 && s2 !== n2.issuer && c2(`it acted as ${s2}, not ${String(n2.issuer)}, the member named`), o2.proof || c2(`the document carries no proof`);
    let l2 = n2.payload, u2 = o2.payload ?? {};
    for (let [e3, t3] of Object.entries(l2)) V_(u2[e3]) !== V_(t3) && c2(`it changed the payload's ${e3}`);
    for (let e3 of Object.keys(u2)) !(e3 in l2) && e3 !== `presentation` && c2(`it added ${e3} to the payload`);
    return {
      principal: s2,
      document: o2
    };
  }
  function V_(e2) {
    if (Array.isArray(e2)) return `[${e2.map(V_).join(`,`)}]`;
    if (e2 && typeof e2 == `object`) {
      let t2 = e2;
      return `{${Object.keys(t2).filter((e3) => t2[e3] !== void 0).sort().map((e3) => `${JSON.stringify(e3)}:${V_(t2[e3])}`).join(`,`)}}`;
    }
    return JSON.stringify(e2);
  }
  var H_ = class extends Error {
    code;
    constructor(e2, t2) {
      super(t2), this.code = e2, this.name = `RoomActError`;
    }
  };
  function U_(e2) {
    let t2 = e2 instanceof Error ? e2.message : String(e2);
    for (let e3 of [
      `notAMember`,
      `principalAmbiguous`,
      `actionNotHeld`,
      `issuerNotPrincipal`
    ]) if (t2.includes(e3)) {
      let n2 = {
        notAMember: `Your VTA holds no credential this room issued to an identity you may act as.`,
        principalAmbiguous: `Your agent holds this room as more than one member, and the request did not say which one to act as.`,
        actionNotHeld: `Your own credentials for this room do not allow that.`,
        issuerNotPrincipal: `That identity is not a member of this room you may act as.`
      }[e3];
      return new H_(e3, `${n2} (${t2})`);
    }
    return e2 instanceof Error ? e2 : Error(t2);
  }
  async function W_(e2, t2, n2, r2, i2 = e2.member) {
    let a2 = {
      holder: e2.holder,
      service: {
        did: e2.vta.did
      }
    }, o2;
    try {
      o2 = await B_(e2.vta.sender, a2, z_(t2, e2.host.did, r2, i2));
    } catch (e3) {
      throw U_(e3);
    }
    let s2 = await e2.host.sender.sendCompleted(o2.document, {
      expectedResponseType: n2,
      operationLabel: t2.replace(/^https:\/\/trusttasks\.org\/spec\//, ``)
    });
    return {
      principal: o2.principal,
      reply: s2
    };
  }
  async function G_(e2, t2, n2) {
    let r2 = {
      roomId: n2.roomId,
      key: n2.key,
      version: n2.version,
      plaintext: Ee(new TextEncoder().encode(JSON.stringify(n2.body))),
      signAsPrincipal: true
    }, i2 = R(j_, r2, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    });
    return (await e2.send(i2, {
      expectedResponseType: M_,
      operationLabel: `rooms/keys/seal/0.2`
    })).sealed;
  }
  async function K_(e2) {
    let { principal: t2, reply: n2 } = await W_(e2, N_, P_, {
      roomId: e2.roomId
    });
    if (n2.roomId !== e2.roomId) throw Error(`${e2.host.did} answered rooms/info for ${n2.roomId}, not ${e2.roomId}`);
    return {
      principal: t2,
      info: n2
    };
  }
  async function q_(e2) {
    let { reply: t2 } = await W_(e2, C_, w_, {
      roomId: e2.roomId,
      limit: 1
    });
    return t2.headVersion ?? 0;
  }
  var J_ = 4, Y_ = class extends Error {
    key;
    landed;
    constructor(e2, t2) {
      super(`${e2} is stored at version ${t2} but sealed for another, so it does not open: the room kept moving under ${J_} attempts. Write it again.`), this.key = e2, this.landed = t2, this.name = `VersionRaceError`;
    }
  };
  async function X_(e2, t2, n2, r2 = {}) {
    if (e2.member !== void 0 && t2.author !== e2.member) throw Error(`a record written as ${e2.member} cannot name ${t2.author} as its author`);
    let i2 = {
      holder: e2.holder,
      service: {
        did: e2.vta.did
      }
    }, a2 = await q_(e2) + 1, o2 = r2.replaces ?? 0, s2 = 0;
    for (let r3 = 0; r3 < J_; r3++) {
      let r4 = await G_(e2.vta.sender, i2, {
        roomId: e2.roomId,
        key: t2.key,
        version: a2,
        body: $_({
          ...t2,
          version: a2
        })
      }), c2 = {
        roomId: e2.roomId,
        key: t2.key,
        sealed: r4,
        expectedVersion: o2,
        ...n2 === void 0 ? {} : {
          blobs: [
            n2
          ]
        }
      };
      if (s2 = (n2 === void 0 ? (await W_(e2, T_, E_, c2)).reply : (await W_(e2, L_, R_, c2)).reply).version, s2 === a2) return s2;
      o2 = s2, a2 = s2 + 1;
    }
    throw new Y_(t2.key, s2);
  }
  async function Z_(e2, t2) {
    let n2 = {};
    t2.title !== void 0 && (n2.title = t2.title), t2.body !== void 0 && (n2.body = t2.body);
    let { reply: r2 } = await W_(e2, T_, E_, {
      roomId: e2.roomId,
      key: t2.key,
      cleartext: n2,
      expectedVersion: t2.replaces ?? 0
    });
    return r2.version;
  }
  async function Q_(e2, t2) {
    let n2 = {
      roomId: e2.roomId,
      key: t2.key
    };
    t2.status !== void 0 && (n2.status = t2.status), t2.pinned !== void 0 && (n2.pinned = t2.pinned), t2.reason !== void 0 && t2.reason !== `` && (n2.reason = t2.reason), t2.expectedVersion !== void 0 && (n2.expectedVersion = t2.expectedVersion);
    let { reply: r2 } = await W_(e2, F_, I_, n2);
    if (r2.key !== t2.key) throw Error(`${e2.host.did} answered rooms/records/curate for ${r2.key}, not ${t2.key}`);
    return r2;
  }
  function $_(e2) {
    let t2 = {
      roomId: e2.roomId,
      key: e2.key,
      version: e2.version,
      author: e2.author
    };
    return e2.title !== void 0 && (t2.title = e2.title), e2.description !== void 0 && (t2.description = e2.description), e2.body !== void 0 && (t2.body = e2.body), e2.tags !== void 0 && e2.tags.length > 0 && (t2.tags = e2.tags), e2.file !== void 0 && (t2.file = e2.file), t2;
  }
  function ev() {
    return Ee(globalThis.crypto.getRandomValues(new Uint8Array(16)));
  }
  var tv = `https://trusttasks.org/spec/vtc/rooms/offers/list/0.2`, nv = `https://trusttasks.org/spec/vtc/rooms/offers/list/0.2#response`, rv = `https://trusttasks.org/spec/vtc/rooms/memberships/list/0.1`, iv = `https://trusttasks.org/spec/vtc/rooms/memberships/list/0.1#response`, av = class extends Error {
    stage;
    inner;
    constructor(e2, t2) {
      super(t2 instanceof Error ? t2.message : String(t2)), this.stage = e2, this.inner = t2, this.name = `OfferReadError`;
    }
  }, ov = 10;
  async function sv(e2) {
    return lv(e2, tv, nv, `vtc/rooms/offers/list/0.2`);
  }
  async function cv(e2) {
    return lv(e2, rv, iv, `vtc/rooms/memberships/list/0.1`);
  }
  async function lv(e2, t2, n2, r2) {
    let i2 = [], a2;
    for (let o2 = 0; o2 < ov; o2++) {
      let o3 = a2 === void 0 ? {} : {
        cursor: a2
      }, s2;
      try {
        ({ document: s2 } = await B_(e2.vta.sender, {
          holder: e2.holder,
          service: {
            did: e2.vta.did
          }
        }, z_(t2, e2.community.did, o3, e2.member), `0.5`));
      } catch (e3) {
        throw new av(`act`, e3);
      }
      let c2;
      try {
        c2 = await e2.community.sender.sendCompleted(s2, {
          expectedResponseType: n2,
          operationLabel: r2
        });
      } catch (e3) {
        throw new av(`community`, e3);
      }
      if (!c2 || !Array.isArray(c2.items)) throw new av(`community`, Error(`${e2.community.did} answered ${r2} without items`));
      if (i2.push(...c2.items), typeof c2.nextCursor != `string` || c2.nextCursor === ``) return i2;
      a2 = c2.nextCursor;
    }
    return i2;
  }
  function uv(e2, t2) {
    return e2.state === `offered` ? `offered` : e2.state === `removed` ? `removed` : e2.visibility === `open` || t2 ? `joined` : e2.repeatAcceptUntil === void 0 ? `needsReadmission` : `unfinished`;
  }
  function dv(e2) {
    let t2 = {};
    for (let n2 of e2) {
      if (!n2 || typeof n2 != `object`) continue;
      let e3 = n2;
      if (typeof e3.roomId != `string` || !e3.roomId.startsWith(`did:`) || typeof e3.label != `string`) continue;
      let r2 = [
        ...e3.label.trim()
      ].slice(0, 200).join(``);
      r2 !== `` && (t2[e3.roomId] = {
        label: r2,
        ...typeof e3.visibility == `string` ? {
          visibility: e3.visibility
        } : {}
      });
    }
    return t2;
  }
  var fv = `https://trusttasks.org/spec/vtc/rooms/offers/accept/0.1`, pv = `https://trusttasks.org/spec/vtc/rooms/offers/accept/0.1#response`, mv = `https://trusttasks.org/spec/rooms/keys/key-package/0.2`, hv = `https://trusttasks.org/spec/rooms/keys/key-package/0.2#response`, gv = `https://trusttasks.org/spec/rooms/keys/welcome/0.1`, _v = `https://trusttasks.org/spec/rooms/keys/welcome/0.1#response`, Q = class extends Error {
    code;
    retryable;
    constructor(e2, t2, n2 = false) {
      super(t2), this.code = e2, this.retryable = n2, this.name = `RoomOfferError`;
    }
  };
  function vv(e2) {
    let t2 = e2?.details, n2 = t2 && typeof t2 == `object` ? t2.code : void 0;
    if (typeof n2 == `string` && n2 !== ``) return n2.slice(n2.lastIndexOf(`:`) + 1);
  }
  function yv(e2) {
    let t2 = e2?.code;
    return typeof t2 == `string` ? t2 : void 0;
  }
  var bv = (e2) => e2 instanceof Error ? e2.message : String(e2);
  function xv(e2) {
    return `pnm acl update ${e2} --capabilities-all`;
  }
  function Sv(e2, t2) {
    let n2 = vv(e2);
    return n2 === `unsupportedType` || n2 === `unsupportedVersion` ? new Q(`actUnsupported`, `Your agent does not serve rooms/keys/act 0.5, the version that signs your requests to a community about its rooms as you. It must be updated before offers can be read or accepted from the wallet.`) : n2 === `permissionDenied` || yv(e2) === `e.p.msg.forbidden` ? new Q(`capability`, `Your agent refused to sign as ${t2.member}: this wallet's credential there (${t2.holder.did}) does not carry the room-present capability. Someone holding the whole agent can restore what its role carries with \`${xv(t2.holder.did)}\`. (${bv(e2)})`) : n2 === `issuerNotPrincipal` || n2 === `principalAmbiguous` ? new Q(`notPersona`, `Your agent holds no authentication key of ${t2.member} that this wallet may act as, so it cannot answer the offer as that identity. (${bv(e2)})`) : n2 === `keyPackageNotHeld` ? new Q(`keyPackageNotHeld`, `Your agent no longer holds the key package it gave for this room (it has been used, or it expired). Accept again and it gives a fresh one. (${bv(e2)})`) : new Q(`other`, bv(e2));
  }
  function Cv(e2, t2, n2, r2) {
    let i2 = vv(e2), a2 = t2.community.did;
    switch (i2) {
      case `notAMember`:
        return new Q(`notAMember`, `${a2} says ${t2.member} is not an active member of the community.`);
      case `notFound`:
        return new Q(`notFound`, `${a2} has no open or recently accepted offer of ${n2} to ${t2.member}.`);
      case `offerExpired`:
        return new Q(`offerExpired`, `The offer of ${n2} has expired. Ask the community to offer it again.`);
      case `alreadyAccepted`:
        return new Q(`alreadyAccepted`, `${a2} says the offer was already accepted, with another key package or too long ago for it to answer again. Ask an administrator to remove you from the room and offer it again.`);
      case `admissionPending`:
        return new Q(`admissionPending`, `${a2} could not yet confirm the admission with its own agent. Accept again \u2014 here or anywhere else: your agent gives the same key package, and the community settles the admission before answering.`, true);
      case `keyHolderRefused`: {
        let t3 = e2.details?.details, n3 = [
          t3?.code,
          t3?.message
        ].filter((e3) => typeof e3 == `string`).join(`: `);
        return new Q(`keyHolderRefused`, `The community's own agent refused to admit you${n3 ? ` (${n3})` : ``}. Tell the community.`);
      }
      case `keyPackageInvalid`:
      case `keyPackageRequired`:
      case `keyPackageNotExpected`:
        return new Q(`keyPackageInvalid`, `${a2} refused the key package: ${bv(e2)}`);
    }
    let o2 = yv(e2);
    return o2 === `e.client.timeout` || o2 === `e.client.network` ? new Q(`noAnswer`, `${a2} did not answer (${bv(e2)}). Accept again${r2 ? ` \u2014 here or anywhere else: your agent gives the same key package, so if the community did admit you, it answers with the same Welcome` : ``}.`, true) : new Q(`other`, `${a2} did not take the acceptance: ${bv(e2)}`);
  }
  function wv(e2) {
    return e2 !== `open`;
  }
  async function Tv(e2, t2, n2) {
    let r2 = {
      holder: e2.holder,
      service: {
        did: e2.vta.did
      }
    }, i2 = (n3, r3, i3, a3) => ({
      roomId: t2,
      member: e2.member,
      communityDid: e2.community.did,
      visibility: n3,
      joined: r3,
      ...i3 === void 0 ? {} : {
        epoch: i3
      },
      resumed: a3
    });
    n2.progress?.(`reading`);
    let a2;
    try {
      a2 = await sv(e2);
    } catch (t3) {
      throw t3 instanceof Q ? t3 : Ev(t3, e2);
    }
    let o2 = a2.find((e3) => e3.roomId === t2);
    if (!o2) throw new Q(`notFound`, `${e2.community.did} has no open or recently accepted offer of ${t2} to ${e2.member}. If it was accepted long ago and never joined, ask an administrator to remove you from the room and offer it again.`);
    if (o2.host !== e2.community.did) throw new Q(`other`, `the offer of ${t2} names ${o2.host} as its host, not ${e2.community.did}`);
    let s2 = o2.visibility, c2 = wv(s2), l2 = o2.credentials.invitation;
    if (o2.state === `accepted`) {
      if (!c2) return i2(s2, false, void 0, true);
      if (await n2.joined(t2, e2.member)) return i2(s2, true, void 0, true);
    }
    n2.progress?.(`storing`);
    for (let [t3, r3] of [
      [
        `membership`,
        o2.credentials.membership
      ],
      [
        `authority`,
        o2.credentials.authority
      ]
    ]) {
      let i3;
      try {
        i3 = JSON.parse(r3);
      } catch (e3) {
        throw new Q(`other`, `the offer's ${t3} credential is not JSON: ${bv(e3)}`);
      }
      if (!i3 || typeof i3 != `object` || Array.isArray(i3)) throw new Q(`other`, `the offer's ${t3} credential is not a credential`);
      try {
        await n2.receive(i3);
      } catch (n3) {
        throw vv(n3) === `permissionDenied` || yv(n3) === `e.p.msg.forbidden` ? new Q(`capability`, `Your agent's credential vault refused the ${t3} credential: this wallet's credential there (${e2.holder.did}) does not carry the vault-write capability. Someone holding the whole agent can restore what its role carries with \`${xv(e2.holder.did)}\`. (${bv(n3)})`) : new Q(`other`, `Your agent's credential vault refused the ${t3} credential: ${bv(n3)}`);
      }
    }
    let u2, d2 = false;
    if (c2) {
      n2.progress?.(`keyPackage`);
      let i3 = await kv(e2, r2, t2, l2);
      u2 = i3.keyPackage, d2 = i3.alreadyMinted;
    }
    n2.progress?.(`accepting`);
    let f2 = {
      roomId: t2,
      ...u2 === void 0 ? {} : {
        keyPackage: u2
      }
    }, p2;
    try {
      ({ document: p2 } = await B_(e2.vta.sender, r2, z_(fv, e2.community.did, f2, e2.member), `0.5`));
    } catch (t3) {
      throw Sv(t3, e2);
    }
    let m2;
    try {
      m2 = await e2.community.sender.sendCompleted(p2, {
        expectedResponseType: pv,
        operationLabel: `vtc/rooms/offers/accept/0.1`
      });
    } catch (r3) {
      let a3 = Cv(r3, e2, t2, c2);
      if (a3.code === `alreadyAccepted` && c2 && await n2.joined(t2, e2.member).catch(() => false)) return i2(s2, true, void 0, true);
      throw a3;
    }
    if (m2.roomId !== t2 || m2.state !== `admitted`) throw new Q(`other`, `${e2.community.did} answered the acceptance of ${t2} for ${m2.roomId} (${m2.state})`);
    if (!c2) return i2(s2, false, m2.epoch, o2.state === `accepted`);
    if (typeof m2.welcome != `string` || m2.welcome === ``) throw new Q(`welcomeMissing`, `${e2.community.did} admitted you to sealed room ${t2} but sent no Welcome. Accept again to ask for it.`, true);
    n2.progress?.(`joining`);
    try {
      await Av(e2.vta.sender, r2, {
        roomId: t2,
        invitation: l2,
        welcome: m2.welcome,
        ...m2.ratchetTree === void 0 ? {} : {
          ratchetTree: m2.ratchetTree
        }
      });
    } catch (e3) {
      if (vv(e3) !== `alreadyJoined`) throw new Q(`joinFailed`, `Admitted at room epoch ${m2.epoch}, but your agent did not join from the Welcome: ${bv(e3)}. Accept again: the community answers with the same Welcome.`, true);
      d2 = true;
    }
    return i2(s2, true, m2.epoch, d2 || o2.state === `accepted`);
  }
  function Ev(e2, t2) {
    return e2 instanceof av ? e2.stage === `act` ? Sv(e2.inner, t2) : Dv(e2.inner, t2) : new Q(`other`, bv(e2));
  }
  function Dv(e2, t2) {
    let n2 = vv(e2), r2 = t2.community.did;
    if (n2 === `unsupportedType` || n2 === `unsupportedVersion`) return new Q(`noRoomOffers`, `${r2} makes no room offers: it does not serve the room requests a member makes (${bv(e2)}).`);
    if (n2 === `notAMember`) return new Q(`notAMember`, `${r2} says ${t2.member} is not an active member of the community.`);
    if (n2 === `permissionDenied` || yv(e2) === `e.p.msg.forbidden`) return new Q(`communityRefused`, `${r2} refused to list its offers to ${t2.member}: ${bv(e2)}`);
    let i2 = yv(e2);
    return i2 === `e.client.timeout` || i2 === `e.client.network` ? new Q(`noAnswer`, `${r2} did not answer the request for its offers (${bv(e2)}).`, true) : new Q(`other`, `${r2} did not list its offers: ${bv(e2)}`);
  }
  function Ov(e2, t2) {
    return e2 instanceof Q ? e2 : Ev(e2, t2);
  }
  async function kv(e2, t2, n2, r2) {
    let i2 = {
      roomId: n2,
      invitation: r2
    };
    try {
      let n3 = await e2.vta.sender.send(R(mv, i2, {
        issuer: t2.holder.did,
        recipient: t2.service.did
      }), {
        expectedResponseType: hv,
        operationLabel: `rooms/keys/key-package/0.2`
      });
      if (typeof n3?.keyPackage != `string` || n3.keyPackage === ``) throw Error(`the answer carries no key package`);
      if (typeof n3.alreadyMinted != `boolean`) throw Error(`the answer does not say whether it was already minted`);
      return n3;
    } catch (e3) {
      let t3 = vv(e3);
      throw t3 === `unsupportedType` || t3 === `unsupportedVersion` ? new Q(`actUnsupported`, `Your agent does not serve rooms/keys/key-package 0.2, which gives the same key package to every surface you accept from. It must be updated before rooms can be accepted from the wallet.`) : new Q(`other`, `Your agent did not give a key package for ${n2}: ${bv(e3)}`);
    }
  }
  async function Av(e2, t2, n2) {
    return e2.send(R(gv, n2, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    }), {
      expectedResponseType: _v,
      operationLabel: `rooms/keys/welcome/0.1`
    });
  }
  var jv = `https://trusttasks.org/spec/rooms/keys/profile/read/0.1`, Mv = `https://trusttasks.org/spec/rooms/keys/profile/read/0.1#response`;
  async function Nv(e2, t2) {
    let n2 = {
      roomId: t2.roomId,
      host: t2.host,
      ...i_(t2.member)
    }, r2 = R(jv, n2, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    });
    return e2.send(r2, {
      expectedResponseType: Mv,
      operationLabel: `rooms/keys/profile/read/0.1`
    });
  }
  var Pv = 128, Fv = 1e3, Iv = 32, Lv = 16;
  function Rv(e2, t2, n2 = false) {
    return [
      ...[
        ...e2
      ].map((e3) => {
        let t3 = e3.codePointAt(0) ?? 0;
        return e3 === `
` && n2 ? e3 : e3 === `
` || e3 === `	` ? ` ` : t3 < 32 || t3 >= 127 && t3 < 160 || t3 >= 8234 && t3 <= 8238 || t3 >= 8294 && t3 <= 8297 || t3 === 8206 || t3 === 8207 ? `` : e3;
      }).join(``).trim()
    ].slice(0, t2).join(``);
  }
  var zv = /* @__PURE__ */ new Set([
    `noAuthority`,
    `timing`,
    `revoked`
  ]);
  function Bv(e2) {
    let t2 = e2 && typeof e2 == `object` ? e2 : {}, n2 = t2.status === `found` || t2.status === `cleared` ? t2.status : `absent`, r2 = {
      status: n2,
      stale: false,
      renameRefused: false,
      refusedAuthors: []
    }, i2 = t2.profile;
    if (n2 === `found` && i2 && typeof i2 == `object` && typeof i2.name == `string`) {
      let e3 = Rv(i2.name, Pv);
      if (e3 !== `` && (r2.name = e3), typeof i2.description == `string`) {
        let e4 = Rv(i2.description, Fv, true);
        e4 !== `` && (r2.description = e4);
      }
      if (typeof i2.emoji == `string`) {
        let e4 = Rv(i2.emoji, Lv);
        e4 !== `` && (r2.emoji = e4);
      }
      if (Array.isArray(i2.tags)) {
        let e4 = i2.tags.filter((e5) => typeof e5 == `string`).map((e5) => Rv(e5, Iv)).filter((e5) => e5 !== ``);
        e4.length > 0 && (r2.tags = e4);
      }
      r2.stale = t2.stale === true;
    }
    if (Array.isArray(t2.rejected)) for (let e3 of t2.rejected) {
      let t3 = e3 ?? {};
      typeof t3.reason == `string` && zv.has(t3.reason) && (r2.renameRefused = true, typeof t3.author == `string` && t3.author.startsWith(`did:`) && !r2.refusedAuthors.includes(t3.author) && r2.refusedAuthors.push(Rv(t3.author, 256)));
    }
    return r2;
  }
  async function Vv(e2, t2, n2, r2, i2, a2) {
    let o2 = R(n2, a2, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    });
    return e2.send(o2, {
      expectedResponseType: r2,
      operationLabel: i2
    });
  }
  function Hv(e2, t2) {
    let n2 = e2?.[r_]?.held, r2 = Array.isArray(n2) ? n2[t2] : void 0;
    if (!r2 || typeof r2 != `object`) return {};
    let i2 = {};
    return typeof r2.member == `string` && (i2.member = r2.member), typeof r2.context == `string` && (i2.context = r2.context), Array.isArray(r2.actions) && (i2.actions = r2.actions.filter((e3) => typeof e3 == `string`)), i2;
  }
  async function Uv(e2, t2, n2 = {}) {
    let r2 = n2.includePersonal === true ? {
      includePersonal: true
    } : {}, i2;
    try {
      i2 = await Vv(e2, t2, __, v_, `rooms/keys/list/0.2`, r2);
    } catch (n3) {
      if (!Wv(n3)) throw n3;
      return Gv(e2, t2);
    }
    return (i2.rooms ?? []).map((e3, t3) => {
      let { member: r3, ...a2 } = Hv(i2.ext, t3), o2 = {
        ...e3,
        ...a2
      };
      return n2.includePersonal !== true && delete o2.personal, o2;
    });
  }
  function Wv(e2) {
    let t2 = e2?.details, n2 = t2 && typeof t2 == `object` ? t2.code : void 0;
    if (typeof n2 != `string`) return false;
    let r2 = n2.slice(n2.lastIndexOf(`:`) + 1);
    return r2 === `unsupportedVersion` || r2 === `unsupportedType`;
  }
  async function Gv(e2, t2) {
    let n2 = await Vv(e2, t2, y_, b_, `rooms/keys/list/0.1`, {});
    return (n2.rooms ?? []).map((e3, t3) => {
      let r2 = Hv(n2.ext, t3);
      return {
        ...e3,
        ...r2
      };
    });
  }
  function Kv(e2, t2) {
    let n2 = e2.version;
    if (n2 === void 0) return t2;
    if (!Number.isSafeInteger(n2) || n2 < 1 || n2 > t2) throw Error(`the host says this body was sealed at version ${String(n2)}, which is not a version at or before the record's ${t2}`);
    return n2;
  }
  async function qv(e2, t2) {
    let { holder: n2, service: r2, member: i2, sealed: a2, ...o2 } = t2, s2 = await Vv(e2, {
      holder: n2,
      service: r2
    }, x_, S_, `rooms/keys/open/0.1`, {
      ...o2,
      sealed: {
        ciphertext: a2.ciphertext,
        nonce: a2.nonce,
        epoch: a2.epoch
      },
      ...i_(i2)
    }), c2 = s2.ext?.[r_]?.sealedAt;
    if (c2 === void 0) return {
      plaintext: s2.plaintext,
      sealedAt: t2.version
    };
    if (typeof c2 != `number` || !Number.isSafeInteger(c2) || c2 < 1 || c2 > t2.version) throw Error(`${r2.did} opened the record at version ${String(c2)}, which is not at or before the ${t2.version} it was asked for`);
    return {
      plaintext: s2.plaintext,
      sealedAt: c2
    };
  }
  async function Jv(e2, t2) {
    let n2 = {
      roomId: t2.roomId,
      host: t2.host,
      key: t2.key,
      ...i_(t2.member)
    };
    return Vv(e2, {
      holder: t2.holder,
      service: t2.service
    }, $n, er, `rooms/keys/read/0.1`, n2);
  }
  async function Yv(e2, t2) {
    let n2 = {
      roomId: t2.roomId,
      host: t2.host,
      ...t2.prefix === void 0 ? {} : {
        prefix: t2.prefix
      },
      ...t2.sinceVersion === void 0 ? {} : {
        sinceVersion: t2.sinceVersion
      },
      ...t2.limit === void 0 ? {} : {
        limit: t2.limit
      },
      ...i_(t2.member)
    };
    return Vv(e2, {
      holder: t2.holder,
      service: t2.service
    }, tr, nr, `rooms/keys/browse/0.1`, n2);
  }
  var Xv = `https://trusttasks.org/spec/rooms/blobs/upload/begin/0.2`, Zv = `https://trusttasks.org/spec/rooms/blobs/upload/begin/0.2#response`, Qv = `https://trusttasks.org/spec/rooms/blobs/get/0.2`, $v = `https://trusttasks.org/spec/rooms/blobs/get/0.2#response`, ey = `https://trusttasks.org/spec/rooms/blobs/chunk/0.1`, ty = `https://trusttasks.org/spec/rooms/blobs/chunk/0.1#response`, ny = `https://trusttasks.org/spec/rooms/records/get/0.2`, ry = `https://trusttasks.org/spec/rooms/records/get/0.2#response`, iy = class extends Error {
    code;
    constructor(e2, t2) {
      super(t2), this.code = e2, this.name = `RoomFileError`;
    }
  }, ay = 67108864;
  function oy(e2) {
    if (e2?.aborted) throw new iy(`aborted`, `stopped before it finished`);
  }
  function sy(e2) {
    return Ee(crypto.getRandomValues(new Uint8Array(e2)));
  }
  async function cy(e2) {
    let t2 = new Uint8Array(await crypto.subtle.digest(`SHA-256`, e2)), n2 = new Uint8Array(2 + t2.length);
    return n2.set([
      18,
      32
    ], 0), n2.set(t2, 2), `u${Ee(n2)}`;
  }
  async function ly(e2, t2) {
    let n2 = (t3) => e2.onProgress?.(t3);
    if (t2.bytes.length > 67108864) throw new iy(`tooLarge`, `${t2.bytes.length} bytes is more than the ${ay} this wallet seals in one piece; \`pnm rooms file put\` takes larger files`);
    n2({
      stage: `checking`
    });
    let { principal: r2, info: i2 } = await K_(e2);
    if (i2.visibility === `open`) throw new iy(`openRoom`, `this room is open: its records are cleartext, and a file's manifest belongs inside a sealed body. Files go in attributed and private rooms.`);
    if (!i2.limits.filesEnabled) throw new iy(`filesDisabled`, `${e2.host.did} does not accept files in this room`);
    oy(e2.signal), n2({
      stage: `sealing`
    });
    let a2 = sy(32), o2 = await _y(e2.vta.sender, {
      holder: e2.holder,
      service: {
        did: e2.vta.did
      },
      roomId: e2.roomId,
      fileId: a2,
      purpose: `seal`,
      ...e2.member === void 0 ? {} : {
        member: e2.member
      }
    }), s2, c2, l2, u2 = e2.cipher.FileSealer.withKey(e2.roomId, a2, BigInt(o2.epoch), o2.key, BigInt(t2.bytes.length), t2.padme ?? false, t2.name, t2.mediaType ?? null, null);
    try {
      let e3 = u2.push(t2.bytes), n3 = u2.finish();
      s2 = new Uint8Array(e3.length + n3.length), s2.set(e3, 0), s2.set(n3, e3.length), c2 = u2.chunkSize, l2 = JSON.parse(u2.manifests());
    } finally {
      u2.free();
    }
    let d2 = Math.min(i2.limits.room?.maxFileBytes ?? 1 / 0, i2.usage.member?.limits.maxFileBytes ?? i2.limits.member?.maxFileBytes ?? 1 / 0);
    if (l2.blob.size > d2) throw new iy(`tooLarge`, `sealed, this file is ${l2.blob.size} bytes, and ${e2.host.did} accepts at most ${d2} in this room`);
    let f2 = [];
    for (let e3 = 0; e3 < s2.length; e3 += c2) f2.push(s2.subarray(e3, e3 + c2));
    oy(e2.signal), n2({
      stage: `uploading`,
      done: 0,
      total: f2.length
    });
    let p2 = ai(), { reply: m2 } = await W_(e2, Xv, Zv, {
      roomId: e2.roomId,
      uploadKey: p2.did,
      manifest: l2.blob
    }), h2;
    if (m2.alreadyCommitted === true) h2 = l2.file.blobRef;
    else {
      if (m2.mode !== `proxied`) throw new iy(`hostMisbehaved`, `${e2.host.did} answered a proxied-only upload in ${String(m2.mode)} mode`);
      let t3 = m2.uploadId, r3 = e2.uploadChannel(p2), i3 = {
        holder: {
          did: p2.did
        },
        service: {
          did: e2.host.did
        }
      };
      try {
        let a3 = 0;
        for (let o3 of m2.missing) {
          oy(e2.signal);
          let s3 = f2[o3];
          if (!Number.isSafeInteger(o3) || s3 === void 0) throw new iy(`hostMisbehaved`, `${e2.host.did} asked for chunk ${o3}, which does not exist`);
          await fy(r3, {
            ...i3,
            uploadId: t3,
            index: o3,
            digestMultibase: l2.blob.chunks.chunkDigests[o3],
            data: s3
          }), n2({
            stage: `uploading`,
            done: ++a3,
            total: m2.missing.length
          });
        }
      } catch (e3) {
        throw await my(r3, {
          ...i3,
          uploadId: t3
        }).catch(() => void 0), e3;
      }
      h2 = (await py(r3, {
        ...i3,
        uploadId: t3
      })).blobRef;
    }
    if (!yy(h2, l2.file.blobRef)) throw new iy(`hostMisbehaved`, `${e2.host.did} committed ${h2}, not the blob sealed here (${l2.file.blobRef})`);
    n2({
      stage: `writing`
    });
    let g2 = ev(), _2;
    try {
      _2 = await X_(e2, {
        roomId: e2.roomId,
        key: g2,
        author: r2,
        ...t2.title === void 0 ? {} : {
          title: t2.title
        },
        ...t2.description === void 0 ? {} : {
          description: t2.description
        },
        ...t2.tags === void 0 ? {} : {
          tags: t2.tags
        },
        file: l2.file
      }, h2);
    } catch (e3) {
      throw e3 instanceof Y_ ? new iy(`versionRace`, `${e3.key} is stored at version ${e3.landed} but sealed for another, so it does not open: the room kept moving. Put the file again.`) : e3;
    }
    return {
      key: g2,
      version: _2,
      blobRef: h2,
      size: t2.bytes.length,
      author: r2
    };
  }
  async function uy(e2, t2, n2) {
    let r2 = (t3) => e2.onProgress?.(t3), i2 = {
      holder: e2.holder,
      service: {
        did: e2.vta.did
      }
    };
    r2({
      stage: `reading`
    });
    let { principal: a2, reply: o2 } = await W_(e2, ny, ry, {
      roomId: e2.roomId,
      key: t2
    });
    if (!o2.sealed) throw new iy(`noFile`, `the record has no sealed body: it is on an open room, or it has been retracted`);
    let s2 = o2.sealed, { plaintext: c2, sealedAt: l2 } = await qv(e2.vta.sender, {
      ...i2,
      roomId: e2.roomId,
      key: t2,
      version: Kv(s2, o2.version),
      sealed: s2,
      ...e2.member === void 0 ? {} : {
        member: e2.member
      }
    }), u2 = await Ay(Ke(c2), {
      roomId: e2.roomId,
      key: t2,
      version: l2
    }, o2.author), d2 = u2.file;
    if (!d2) throw new iy(`noFile`, `the record carries no file`);
    if (!(o2.blobs ?? []).some((e3) => yy(e3, d2.blobRef))) throw new iy(`blobNotNamed`, `the host does not name the file's blob on this record; it may have been released`);
    oy(e2.signal);
    let { reply: f2 } = await W_(e2, Qv, $v, {
      roomId: e2.roomId,
      blobRef: d2.blobRef,
      direct: false
    }), p2 = f2.downloadId;
    if (f2.mode !== `proxied` || typeof p2 != `string`) throw new iy(`hostMisbehaved`, `${e2.host.did} answered a proxied download with no download handle`);
    let m2 = f2.manifest, h2 = await _y(e2.vta.sender, {
      ...i2,
      roomId: e2.roomId,
      fileId: d2.fileId,
      purpose: `open`,
      epoch: d2.epoch,
      ...e2.member === void 0 ? {} : {
        member: e2.member
      }
    }), g2 = e2.cipher.FileOpener.withKey(e2.roomId, h2.key, JSON.stringify(d2), JSON.stringify(m2));
    try {
      let t3 = m2.chunks.chunkCount;
      r2({
        stage: `downloading`,
        done: 0,
        total: t3
      });
      for (let i3 = 0; i3 < t3; i3++) {
        oy(e2.signal);
        let { reply: o3 } = await W_(e2, ey, ty, {
          downloadId: p2,
          index: i3
        }, a2), s3 = hy(e2.host.did, i3, o3);
        if (!yy(await cy(s3.data), m2.chunks.chunkDigests[i3])) throw new iy(`hostMisbehaved`, `chunk ${i3} from ${e2.host.did} does not match the manifest`);
        n2(g2.push(s3.data)), r2({
          stage: `downloading`,
          done: i3 + 1,
          total: t3
        });
      }
      if (r2({
        stage: `verifying`
      }), g2.finish(), !g2.verified) throw new iy(`notVerified`, `the file did not verify against the digest its author signed`);
    } finally {
      g2.free();
    }
    return {
      file: d2,
      author: u2.author,
      version: o2.version,
      ...u2.title === void 0 ? {} : {
        title: u2.title
      },
      ...u2.description === void 0 ? {} : {
        description: u2.description
      },
      ...u2.tags === void 0 ? {} : {
        tags: [
          ...u2.tags
        ]
      }
    };
  }
  async function dy(e2, t2, n2, r2, i2, a2) {
    let o2 = R(n2, a2, {
      issuer: t2.holder.did,
      recipient: t2.service.did
    });
    return e2.send(o2, {
      expectedResponseType: r2,
      operationLabel: i2
    });
  }
  async function fy(e2, t2) {
    return dy(e2, t2, a_, o_, `rooms/blobs/upload/chunk/0.2`, {
      uploadId: t2.uploadId,
      index: t2.index,
      digestMultibase: t2.digestMultibase,
      data: Ee(t2.data)
    });
  }
  async function py(e2, t2) {
    return dy(e2, t2, s_, c_, `rooms/blobs/upload/commit/0.2`, {
      uploadId: t2.uploadId
    });
  }
  async function my(e2, t2) {
    return dy(e2, t2, l_, u_, `rooms/blobs/upload/abort/0.2`, {
      uploadId: t2.uploadId
    });
  }
  function hy(e2, t2, n2) {
    if (n2.index !== t2) throw Error(`${e2} answered chunk ${n2.index} to a request for ${t2}`);
    return {
      index: n2.index,
      digestMultibase: n2.digestMultibase,
      data: Ke(n2.data)
    };
  }
  var gy = 32;
  async function _y(e2, t2) {
    let n2 = await dy(e2, t2, d_, f_, `rooms/keys/file-key/0.1`, {
      roomId: t2.roomId,
      fileId: t2.fileId,
      purpose: t2.purpose,
      ...t2.epoch === void 0 ? {} : {
        epoch: t2.epoch
      },
      ...i_(t2.member)
    }), r2;
    try {
      r2 = Ke(n2.key);
    } catch {
      throw Error(`${t2.service.did} returned a file key that is not base64url`);
    }
    if (r2.length !== gy) throw Error(`${t2.service.did} returned a file key of ${r2.length} bytes, not ${gy}`);
    if (r2.fill(0), t2.purpose === `open` && t2.epoch !== void 0 && n2.epoch !== t2.epoch) throw Error(`${t2.service.did} released a key for epoch ${n2.epoch} to open a file sealed under ${t2.epoch}`);
    return {
      key: n2.key,
      epoch: n2.epoch
    };
  }
  function vy(e2) {
    try {
      if (e2.startsWith(`z`)) return Ge(e2.slice(1));
      if (e2.startsWith(`u`)) return Ke(e2.slice(1));
    } catch {
      return;
    }
  }
  function yy(e2, t2) {
    let n2 = vy(e2), r2 = vy(t2);
    return !n2 || !r2 || n2.length !== r2.length ? false : n2.every((e3, t3) => e3 === r2[t3]);
  }
  var by = /* @__PURE__ */ new Set([
    `roomId`,
    `key`,
    `version`,
    `author`,
    `title`,
    `description`,
    `body`,
    `tags`,
    `file`
  ]), xy = 512, Sy = 512, Cy = 2048, wy = 1048576, Ty = 32, Ey = 64, Dy = class extends Error {
    kind;
    constructor(e2, t2) {
      super(t2), this.kind = e2, this.name = `RecordBodyError`;
    }
  }, Oy = (e2) => [
    ...e2
  ].length;
  function ky(e2) {
    let t2 = (e3) => {
      throw new Dy(`malformed`, `the record body is malformed: ${e3}`);
    };
    (typeof e2.roomId != `string` || e2.roomId === ``) && t2(`roomId is empty`), (typeof e2.key != `string` || e2.key === `` || e2.key.length > xy) && t2(`key must be 1 to ${xy} characters`), (!Number.isSafeInteger(e2.version) || e2.version < 1) && t2(`version starts at 1`), (typeof e2.author != `string` || !e2.author.startsWith(`did:`)) && t2(`author is not a DID`);
    let n2 = (e3, t3) => e3 !== void 0 && (typeof e3 != `string` || Oy(e3) > t3);
    n2(e2.title, Sy) && t2(`title is longer than ${Sy} characters`), n2(e2.description, Cy) && t2(`description is longer than ${Cy} characters`), n2(e2.body, wy) && t2(`body is longer than ${wy} characters`), e2.tags !== void 0 && (!Array.isArray(e2.tags) || e2.tags.length > Ty || e2.tags.some((e3) => typeof e3 != `string` || Oy(e3) > Ey)) && t2(`at most ${Ty} tags of ${Ey} characters each`), e2.file !== void 0 && (typeof e2.file != `object` || e2.file === null) && t2(`file is not a manifest`);
  }
  async function Ay(e2, t2, n2, r2 = {}) {
    let i2;
    try {
      i2 = JSON.parse(new TextDecoder(`utf-8`, {
        fatal: true
      }).decode(e2));
    } catch (e3) {
      throw new Dy(`malformed`, `the record body is malformed: not JSON (${String(e3)})`);
    }
    if (typeof i2 != `object` || !i2 || Array.isArray(i2)) throw new Dy(`malformed`, `the record body is malformed: not an object`);
    let a2 = i2, o2 = await ft(a2, {
      expectedProofPurpose: `assertionMethod`,
      ...r2.resolveDid ? {
        resolveDid: r2.resolveDid
      } : {}
    });
    if (!o2.verified || !o2.signer) throw new Dy(`signature`, `the record body's signature does not hold: ${o2.reason ?? `unverified`}`);
    let s2 = Object.keys(a2).filter((e3) => e3 !== `proof` && !by.has(e3));
    if (s2.length > 0) throw new Dy(`malformed`, `the record body is malformed: unknown member ${s2.join(`, `)}`);
    let c2 = {
      ...a2
    };
    if (delete c2.proof, ky(c2), o2.signer !== c2.author) throw new Dy(`signature`, `the record body's signature does not hold: it verifies for ${o2.signer}, but the body names ${c2.author} as its author`);
    if (c2.roomId !== t2.roomId || c2.key !== t2.key || c2.version !== t2.version) throw new Dy(`relocated`, `the record body was signed for ${c2.roomId} / ${c2.key} @ v${c2.version}, but was read from ${t2.roomId} / ${t2.key} @ v${t2.version}`);
    if (n2 !== void 0 && n2 !== c2.author) throw new Dy(`authorMismatch`, `the record body is signed by ${c2.author}, but the host recorded ${n2} as its author`);
    return Object.freeze(c2);
  }
  async function jy(e2) {
    let t2 = await g_(e2);
    return {
      completed: new p_({
        hostDid: e2,
        endpoint: t2
      }),
      signedBy: (n2) => new p_({
        hostDid: e2,
        endpoint: t2,
        signing: n2
      })
    };
  }
  var My;
  function Ny() {
    return My ??= Be(() => import("./vti_rooms_wasm-26cf0awW.js").then(async (m2) => {
      await m2.__tla;
      return m2;
    }).then((e2) => e2, (e2) => {
      throw My = void 0, e2;
    }), []), My;
  }
  function Py(e2) {
    return g_(e2);
  }
  function Fy(e2) {
    chrome.runtime.onConnect.addListener((t2) => {
      if (t2.name === `vta-wallet/room-files`) {
        if (!e2.fromExtensionPage(t2)) {
          console.warn(`[room files] refusing a transfer port from ${t2.sender?.url}`), t2.disconnect();
          return;
        }
        Iy(t2, e2);
      }
    });
  }
  function Iy(e2, t2) {
    let n2 = new AbortController(), r2 = true, i2 = `transfer`, a2 = (t3) => {
      if (r2) try {
        e2.postMessage(t3);
      } catch (e3) {
        console.warn(`[room files] ${i2}: could not send ${t3.kind} to the console:`, e3 instanceof Error ? e3.message : String(e3)), r2 = false, n2.abort();
      }
    };
    e2.onDisconnect.addListener(() => {
      globalThis.chrome?.runtime?.lastError, r2 && console.info(`[room files] ${i2} stopped: the console closed the transfer`), r2 = false, n2.abort();
    });
    let o2 = (t3) => {
      a2(t3), t3.kind !== `failed` && console.info(r2 ? `[room files] ${i2}: ${t3.kind}, sent to the console` : `[room files] ${i2}: ${t3.kind}, but the console was gone`), r2 && (r2 = false, e2.disconnect());
    }, s2 = (e3) => {
      let t3 = e3?.code;
      console.warn(`[room files] ${i2} failed${typeof t3 == `string` ? ` (${t3})` : ``}:`, e3 instanceof Error ? e3.message : String(e3)), o2({
        kind: `failed`,
        error: e3 instanceof Error ? e3.message : String(e3),
        ...typeof t3 == `string` ? {
          code: t3
        } : {}
      });
    }, c2, l2 = false;
    e2.onMessage.addListener((e3) => {
      let r3 = e3;
      try {
        if (!l2) {
          if (l2 = true, i2 = r3.kind === `get` ? `get ${r3.key}` : r3.kind === `put` ? `put of ${r3.size} bytes` : r3.kind === `note` ? r3.key ? `note edit of ${r3.key}` : `new note` : r3.kind === `curate` ? `curate ${r3.key}` : String(r3.kind), console.info(`[room files] ${i2} in ${`roomId` in r3 ? r3.roomId : `?`}: started`), r3.kind === `get` || r3.kind === `note` || r3.kind === `curate`) Ly(t2, r3, n2.signal, a2).then(o2, s2);
          else if (r3.kind === `put`) {
            if (!Number.isSafeInteger(r3.size) || r3.size < 0 || r3.size > 67108864) throw Error(`a file of ${r3.size} bytes is not one this wallet seals (at most ${ay})`);
            c2 = {
              into: new Uint8Array(r3.size),
              filled: 0,
              begin: r3
            };
          } else throw Error(`a transfer starts with put or get`);
          return;
        }
        if (!c2) throw Error(`only an upload takes data`);
        if (r3.kind === `data`) {
          let e4 = Ke(r3.data);
          if (c2.filled + e4.length > c2.into.length) throw Error(`more bytes than the file was declared to hold`);
          c2.into.set(e4, c2.filled), c2.filled += e4.length;
        } else if (r3.kind === `end`) {
          if (c2.filled !== c2.into.length) throw Error(`the file ended after ${c2.filled} of ${c2.into.length} bytes`);
          let { begin: e4, into: r4 } = c2;
          c2 = void 0, Ly(t2, e4, n2.signal, a2, r4).then(o2, s2);
        }
      } catch (e4) {
        c2 = void 0, s2(e4);
      }
    });
  }
  async function Ly(e2, t2, n2, r2, i2) {
    let a2 = t2.kind === `put` || t2.kind === `get`, [{ sender: o2, signing: s2 }, c2] = await Promise.all([
      e2.agent(t2.vtaDid, t2.restBaseUrl),
      a2 ? Ny() : Promise.resolve(void 0)
    ]), l2 = await (e2.host ?? jy)(t2.hostDid);
    if (t2.kind === `note` || t2.kind === `curate`) {
      let e3 = {
        roomId: t2.roomId,
        holder: {
          did: s2.did
        },
        vta: {
          did: t2.vtaDid,
          sender: o2
        },
        host: {
          did: t2.hostDid,
          sender: l2.completed
        },
        ...t2.member === void 0 ? {} : {
          member: t2.member
        }
      };
      if (t2.kind === `curate`) {
        let n4 = await Q_(e3, {
          key: t2.key,
          ...t2.status === void 0 ? {} : {
            status: t2.status
          },
          ...t2.pinned === void 0 ? {} : {
            pinned: t2.pinned
          },
          ...t2.reason === void 0 ? {} : {
            reason: t2.reason
          },
          ...t2.expectedVersion === void 0 ? {} : {
            expectedVersion: t2.expectedVersion
          }
        });
        return {
          kind: `curated`,
          key: n4.key,
          version: n4.version,
          status: n4.status,
          ...n4.pinned === void 0 ? {} : {
            pinned: n4.pinned
          }
        };
      }
      let { principal: n3, info: r3 } = await K_(e3), i3 = t2.key ?? ev();
      return {
        kind: `noted`,
        key: i3,
        version: r3.visibility === `open` ? await Z_(e3, {
          key: i3,
          title: t2.title,
          ...t2.body === void 0 ? {} : {
            body: t2.body
          },
          ...t2.replaces === void 0 ? {} : {
            replaces: t2.replaces
          }
        }) : await X_(e3, {
          roomId: t2.roomId,
          key: i3,
          author: n3,
          title: t2.title,
          ...t2.body === void 0 ? {} : {
            body: t2.body
          }
        }, void 0, t2.replaces === void 0 ? {} : {
          replaces: t2.replaces
        }),
        author: n3
      };
    }
    let u2 = {
      roomId: t2.roomId,
      holder: {
        did: s2.did
      },
      vta: {
        did: t2.vtaDid,
        sender: o2
      },
      host: {
        did: t2.hostDid,
        sender: l2.completed
      },
      ...t2.member === void 0 ? {} : {
        member: t2.member
      },
      uploadChannel: l2.signedBy,
      cipher: c2,
      onProgress: (e3) => r2({
        kind: `progress`,
        ...e3
      }),
      signal: n2
    };
    if (t2.kind === `put`) return {
      kind: `put`,
      ...await ly(u2, {
        name: t2.name,
        bytes: i2,
        ...t2.mediaType === void 0 ? {} : {
          mediaType: t2.mediaType
        },
        ...t2.title === void 0 ? {} : {
          title: t2.title
        },
        ...t2.description === void 0 ? {} : {
          description: t2.description
        },
        ...t2.tags === void 0 ? {} : {
          tags: t2.tags
        },
        ...t2.padme === void 0 ? {} : {
          padme: t2.padme
        }
      })
    };
    let d2 = await uy(u2, t2.key, (e3) => r2({
      kind: `provisional`,
      data: Ee(e3)
    }));
    return {
      kind: `got`,
      file: {
        name: d2.file.name,
        size: d2.file.size,
        ...d2.file.mediaType === void 0 ? {} : {
          mediaType: d2.file.mediaType
        }
      },
      author: d2.author,
      version: d2.version,
      ...d2.title === void 0 ? {} : {
        title: d2.title
      },
      ...d2.description === void 0 ? {} : {
        description: d2.description
      },
      ...d2.tags === void 0 ? {} : {
        tags: d2.tags
      }
    };
  }
  async function Ry(e2, t2 = Date.now) {
    let n2 = await ih(e2, {
      contactMethods: Nn
    });
    if (!n2.ok) throw Error(`${e2}'s DID document could not be verified (${n2.reason})`);
    let r2 = nh(n2.doc);
    if (!r2.ok) throw Error(`${e2}'s DID document names no usable ${r2.service} service`);
    if (n2.route === `domain-linked` && !(await jh({
      did: e2,
      didDocument: n2.doc,
      origin: r2.services.portalOrigin,
      now: t2()
    })).ok) throw Error(`${r2.services.portalOrigin} is not linked to ${e2}`);
    return {
      portalOrigin: r2.services.portalOrigin,
      endpoint: r2.services.trustTaskEndpoint
    };
  }
  async function zy(e2, t2, n2) {
    let r2 = e2.now ?? Date.now;
    if (n2.op === `portal`) return (e2.portal ?? ((e3) => Ry(e3, r2)))(n2.hostDid);
    if (n2.op === `members`) {
      if (!e2.identities) throw Error(`the wallet cannot read which identities you use at this community`);
      return ve(await e2.identities(t2.vtaDid, t2.restBaseUrl), n2.hostDid);
    }
    let { sender: i2, holderDid: a2 } = await e2.agent(t2.vtaDid, t2.restBaseUrl), o2 = {
      holder: {
        did: a2
      },
      service: {
        did: t2.vtaDid
      }
    };
    if (n2.op === `held`) return (await Uv(i2, o2)).map((e3) => ({
      roomId: e3.roomId,
      epoch: e3.epoch,
      earliestReadableEpoch: e3.earliestReadableEpoch,
      member: e3.member,
      ...e3.context === void 0 ? {} : {
        context: e3.context
      },
      ...e3.actions === void 0 ? {} : {
        actions: e3.actions
      }
    }));
    if (n2.op === `roomNames`) {
      let { endpoint: o3 } = await (e2.portal ?? ((e3) => Ry(e3, r2)))(n2.hostDid), s3 = {
        did: n2.hostDid,
        sender: (e2.completed ?? ((e3, t3) => new p_({
          hostDid: e3,
          endpoint: t3
        })))(n2.hostDid, o3)
      }, c2 = {};
      for (let e3 of new Set(n2.members)) try {
        let n3 = await cv({
          holder: {
            did: a2
          },
          vta: {
            did: t2.vtaDid,
            sender: i2
          },
          community: s3,
          member: e3
        });
        Object.assign(c2, dv(n3));
      } catch {
      }
      return c2;
    }
    if (n2.op === `roomProfiles`) {
      let e3 = {};
      for (let { roomId: t3, member: r3 } of n2.rooms) if (!e3[t3]) try {
        e3[t3] = Hy(Bv(await Nv(i2, {
          ...o2,
          roomId: t3,
          host: n2.hostDid,
          member: r3
        })));
      } catch {
      }
      return e3;
    }
    let s2 = async (o3, s3) => {
      let { endpoint: c2 } = await (e2.portal ?? ((e3) => Ry(e3, r2)))(n2.hostDid);
      return {
        roomId: o3,
        member: s3,
        holder: {
          did: a2
        },
        vta: {
          did: t2.vtaDid,
          sender: i2
        },
        host: {
          did: n2.hostDid,
          sender: (e2.completed ?? ((e3, t3) => new p_({
            hostDid: e3,
            endpoint: t3
          })))(n2.hostDid, c2)
        }
      };
    };
    switch (n2.op) {
      case `info`: {
        let { principal: e3, info: t3 } = await K_(await s2(n2.roomId, n2.member));
        return {
          roomId: t3.roomId,
          visibility: t3.visibility,
          epoch: t3.epoch,
          member: e3,
          limits: t3.limits,
          usage: t3.usage
        };
      }
      case `browse`: {
        let e3 = await Yv(i2, {
          ...o2,
          roomId: n2.roomId,
          host: n2.hostDid,
          member: n2.member,
          ...n2.prefix === void 0 ? {} : {
            prefix: n2.prefix
          },
          ...n2.sinceVersion === void 0 ? {} : {
            sinceVersion: n2.sinceVersion
          }
        });
        return {
          records: (e3.records ?? []).map((e4) => By(e4)),
          complete: e3.complete === true,
          verification: e3.verification
        };
      }
      case `read`:
        return Vy(n2.roomId, n2.key, await Jv(i2, {
          ...o2,
          roomId: n2.roomId,
          host: n2.hostDid,
          key: n2.key,
          member: n2.member
        }));
      case `putNote`: {
        let e3 = await s2(n2.roomId, n2.member), { principal: t3, info: r3 } = await K_(e3);
        if (r3.visibility === `open`) throw Error(`this room is open: notes from the portal go in attributed rooms, whose records are sealed`);
        let i3 = ev();
        return {
          key: i3,
          version: await X_(e3, {
            roomId: n2.roomId,
            key: i3,
            author: t3,
            title: n2.title,
            ...n2.body === void 0 ? {} : {
              body: n2.body
            },
            ...n2.description === void 0 ? {} : {
              description: n2.description
            },
            ...n2.tags === void 0 ? {} : {
              tags: n2.tags
            }
          })
        };
      }
    }
  }
  function By(e2) {
    let t2 = {
      key: String(e2.key),
      version: Number(e2.version),
      updatedAt: String(e2.updatedAt)
    };
    return typeof e2.status == `string` && (t2.status = e2.status), typeof e2.epoch == `number` && (t2.epoch = e2.epoch), typeof e2.author == `string` && (t2.author = e2.author), typeof e2.title == `string` && (t2.title = e2.title), typeof e2.description == `string` && (t2.description = e2.description), t2;
  }
  async function Vy(e2, t2, n2, r2) {
    if (n2.key !== t2) throw Error(`the agent answered for record ${n2.key}, not ${t2}`);
    let i2 = {
      key: n2.key,
      version: n2.version,
      status: n2.status ?? `active`,
      updatedAt: n2.updatedAt ?? ``,
      sealed: n2.cleartext === void 0,
      verification: n2.verification,
      ...n2.author === void 0 ? {} : {
        author: n2.author
      }
    };
    if (n2.plaintext !== void 0) {
      let a2 = await Ay(Ke(n2.plaintext), {
        roomId: e2,
        key: t2,
        version: n2.version
      }, n2.author, r2 ? {
        resolveDid: r2
      } : {});
      return {
        ...i2,
        author: a2.author,
        ...a2.title === void 0 ? {} : {
          title: a2.title
        },
        ...a2.description === void 0 ? {} : {
          description: a2.description
        },
        ...a2.body === void 0 ? {} : {
          body: a2.body
        },
        ...a2.tags === void 0 ? {} : {
          tags: [
            ...a2.tags
          ]
        },
        ...a2.file ? {
          file: {
            name: a2.file.name,
            size: a2.file.size,
            ...a2.file.mediaType === void 0 ? {} : {
              mediaType: a2.file.mediaType
            }
          }
        } : {}
      };
    }
    if (n2.cleartext !== void 0) {
      let e3 = n2.cleartext, t3 = (e4) => typeof e4 == `string` ? e4 : void 0, r3 = t3(e3.title), a2 = t3(e3.description), o2 = t3(e3.body), s2 = Array.isArray(e3.tags) ? e3.tags.filter((e4) => typeof e4 == `string`) : void 0;
      return {
        ...i2,
        ...r3 === void 0 ? {} : {
          title: r3
        },
        ...a2 === void 0 ? {} : {
          description: a2
        },
        ...o2 === void 0 ? {} : {
          body: o2
        },
        ...s2 === void 0 ? {} : {
          tags: s2
        }
      };
    }
    return i2;
  }
  function Hy(e2) {
    return {
      status: e2.status,
      ...e2.name === void 0 ? {} : {
        name: e2.name
      },
      ...e2.description === void 0 ? {} : {
        description: e2.description
      },
      ...e2.emoji === void 0 ? {} : {
        emoji: e2.emoji
      },
      stale: e2.stale,
      renameRefused: e2.renameRefused
    };
  }
  async function Uy(e2, t2 = Date.now) {
    let n2 = await ih(e2, {
      contactMethods: Nn
    });
    if (!n2.ok) throw Error(`${e2}'s DID document could not be verified (${n2.reason})`);
    let r2 = nh(n2.doc);
    if (!r2.ok) throw Error(`${e2}'s DID document names no usable ${r2.service} service`);
    if (n2.route === `domain-linked` && !(await jh({
      did: e2,
      didDocument: n2.doc,
      origin: r2.services.portalOrigin,
      now: t2()
    })).ok) throw Error(`${r2.services.portalOrigin} is not linked to ${e2}`);
    return {
      portalOrigin: r2.services.portalOrigin,
      endpoint: r2.services.trustTaskEndpoint,
      document: n2.doc
    };
  }
  async function Wy(e2) {
    let t2 = await ih(e2, {
      contactMethods: Nn
    });
    return t2.ok ? t2.doc : null;
  }
  function Gy(e2, t2) {
    return e2.filter((e3) => typeof e3.principalDid == `string` && e3.principalDid !== t2 && e3.targets.some((e4) => e4.kind === `did` && e4.did === t2));
  }
  function Ky(e2, t2) {
    if (!(e2 instanceof Xm)) return e2 instanceof Error ? e2 : Error(String(e2));
    let n2 = e2.code.slice(e2.code.lastIndexOf(`:`) + 1), r2 = {
      consentRequired: `${t2} doesn't publish your card while you haven't agreed to be listed in its trust registry.`,
      notAvailable: `${t2} doesn't publish members' cards beyond the community.`,
      superseded: `Your card changed while you were deciding. Try again to publish what it shows now.`,
      cardMismatch: `${t2} says the card doesn't match what your card shows anyone \u2014 its own rules may keep some of it private. Nothing was published.`,
      signatureInvalid: `${t2} couldn't verify your signature on the card. Nothing was published.`,
      notMember: `${t2} doesn't count you as an active member.`
    };
    return Error(r2[n2] ?? `${t2} didn't publish your card (${e2.code}).`);
  }
  async function qy(e2, t2, n2) {
    let r2 = e2.now ?? Date.now, i2 = (t3) => (e2.community ?? ((e3) => Uy(e3, r2)))(t3);
    if (n2.op === `portal`) {
      let { portalOrigin: e3, endpoint: t3 } = await i2(n2.hostDid);
      return {
        portalOrigin: e3,
        endpoint: t3
      };
    }
    let a2 = Gy(await e2.identities(t2.vtaDid, t2.restBaseUrl), n2.hostDid);
    if (n2.op === `members`) return a2.map((e3) => e3.principalDid);
    let o2 = a2.find((e3) => e3.principalDid === n2.member);
    if (!o2) throw Error(`The wallet holds no such identity for this community.`);
    let s2 = o2.label?.trim() || `This community`, c2 = await i2(n2.hostDid), l2 = {
      vtcDid: n2.hostDid,
      vtcDocument: c2.document,
      trustTaskEndpoint: c2.endpoint,
      ...e2.fetch ? {
        fetch: e2.fetch
      } : {}
    }, { sender: u2, holder: d2, service: p2 } = await e2.agent(t2.vtaDid, t2.restBaseUrl), m2 = {
      holder: {
        did: d2.did
      },
      service: {
        did: p2.did
      }
    }, h2 = async (e3, t3) => {
      let { signedEnvelope: n3 } = await f(u2, {
        holder: d2,
        service: p2,
        entryId: o2.id,
        unsignedEnvelope: e3
      });
      return (await bh(ph(e3, n3, `authentication`), l2, t3, `authentication`)).doc.payload;
    };
    if (n2.op === `prepare`) try {
      let { card: e3 } = await h2(vg(n2.member, n2.hostDid), `vtc/directory/card/show`), { fields: t3 } = await h2(yg(n2.member, n2.hostDid), `vtc/directory/fields/list`), r3 = wg(n2.member, e3, t3);
      return {
        card: r3.card,
        revision: r3.revision,
        communityName: s2,
        said: Tg(s2, r3)
      };
    } catch (e3) {
      throw Ky(e3, s2);
    }
    let g2 = n2.member.startsWith(`did:key:`) ? null : await (e2.memberDocument ?? Wy)(n2.member), _2 = await Mg(u2, m2, n2.member, g2);
    if (!_2) throw Error(`Your agent doesn't hold the key this identity signs with, so it can't sign your card. Nothing was published.`);
    let v2 = await Ng(u2, m2, _2, n2.card, n2.member);
    try {
      let e3 = kg(await h2(Og(n2.member, n2.hostDid, v2, n2.revision), `vtc/directory/card/publish`)), t3 = {
        state: e3.state
      };
      return e3.cardDigest && (t3.cardDigest = e3.cardDigest), e3.publishedAt && (t3.publishedAt = e3.publishedAt), t3;
    } catch (e3) {
      throw Ky(e3, s2);
    }
  }
  var Jy = class extends Error {
    code;
    constructor(e2, t2) {
      super(e2), this.code = t2, this.name = `OfferOpError`;
    }
  };
  async function Yy(e2, t2, n2) {
    let r2 = e2.endpoint ?? ((e3) => g_(e3)), i2 = async (e3) => {
      try {
        return await r2(e3);
      } catch (e4) {
        throw h_(e4) ? new Jy(e4 instanceof Error ? e4.message : String(e4), xe) : e4;
      }
    };
    if (n2.op === `sources`) return z(await e2.identities(t2.vtaDid, t2.restBaseUrl));
    if (n2.op === `endpoint`) return {
      endpoint: await i2(n2.communityDid)
    };
    let a2 = z(await e2.identities(t2.vtaDid, t2.restBaseUrl));
    if (!_e(a2, n2.communityDid, n2.member)) throw new Jy(`${n2.member} is not an identity you sign in to ${n2.communityDid} with`, `notASource`);
    let { sender: o2, holderDid: s2 } = await e2.agent(t2.vtaDid, t2.restBaseUrl), c2 = await i2(n2.communityDid), l2 = {
      holder: {
        did: s2
      },
      vta: {
        did: t2.vtaDid,
        sender: o2
      },
      community: {
        did: n2.communityDid,
        sender: (e2.completed ?? ((e3, t3) => new p_({
          hostDid: e3,
          endpoint: t3
        })))(n2.communityDid, c2)
      },
      member: n2.member
    }, u2 = {
      holder: {
        did: s2
      },
      service: {
        did: t2.vtaDid
      }
    };
    if (n2.op === `list`) {
      let e3;
      try {
        e3 = await cv(l2);
      } catch (e4) {
        let t4 = Ov(e4, l2);
        throw new Jy(t4.message, t4.code);
      }
      let t3 = new Set((await Uv(o2, u2)).filter((e4) => e4.member === n2.member).map((e4) => e4.roomId)), r3 = [];
      for (let i3 of e3) {
        if (i3.host !== n2.communityDid) continue;
        let e4 = Ce(i3.description);
        r3.push({
          communityDid: n2.communityDid,
          member: n2.member,
          roomId: i3.roomId,
          label: ge(i3.label),
          visibility: i3.visibility,
          actions: [
            ...i3.actions
          ],
          validUntil: i3.validUntil,
          offeredAt: i3.offeredAt,
          ...e4 === void 0 ? {} : {
            description: e4
          },
          ...i3.admittedAt === void 0 ? {} : {
            admittedAt: i3.admittedAt
          },
          ...i3.removedAt === void 0 ? {} : {
            removedAt: i3.removedAt
          },
          ...i3.repeatAcceptUntil === void 0 ? {} : {
            repeatAcceptUntil: i3.repeatAcceptUntil
          },
          state: uv(i3, t3.has(i3.roomId))
        });
      }
      return r3;
    }
    let d2 = e2.receive ?? (async (e3, t3, n3, r3) => {
      await Xd(e3, {
        holder: {
          did: t3
        },
        service: {
          did: n3
        },
        credential: r3
      });
    });
    try {
      return await Tv(l2, n2.roomId, {
        receive: (e3) => d2(o2, s2, t2.vtaDid, e3),
        async joined(e3, t3) {
          return (await Uv(o2, u2)).some((n3) => n3.roomId === e3 && n3.member === t3);
        }
      });
    } catch (e3) {
      throw e3 instanceof Q ? new Jy(e3.message, e3.code) : e3;
    }
  }
  function Xy(e2) {
    let t2 = e2?.service;
    if (!Array.isArray(t2)) return `other`;
    let n2 = (e3) => t2.some((t3) => {
      let n3 = t3?.type;
      return n3 === e3 || Array.isArray(n3) && n3.includes(e3);
    });
    return n2(`WebVHHosting`) ? `did-hosting` : n2(`VTCRest`) ? `community` : `other`;
  }
  function Zy(e2) {
    try {
      return new URL(e2).hostname || e2;
    } catch {
      return e2;
    }
  }
  function Qy(e2) {
    try {
      return new URL(e2).origin;
    } catch {
      return e2;
    }
  }
  function $y(e2, t2) {
    let n2 = [
      ...new Set(t2.filter((t3) => t3.secretKind === `didSelfIssued` && t3.principalDid === e2.did).map((e3) => e3.label))
    ];
    return {
      did: e2.did,
      contextId: e2.contextId,
      ...n2.length ? {
        usedAt: n2
      } : {}
    };
  }
  function eb(e2) {
    return e2.slice(e2.lastIndexOf(`:`) + 1);
  }
  function tb(e2) {
    if (!e2.link) throw _b();
    return e2.link.id;
  }
  var nb = `sign-in/out-of-order`, rb = `join/did-unverified`, ib = `join/no-service`, ab = `This code was already used by another device. If that wasn't you, cancel on the website.`, ob = `Refresh the code on the website and try again.`, sb = `sign-in/join-failed`, cb = `sign-in/join-declined`, lb = {
    notAccepting: (e2) => `${e2} isn't accepting new members right now.`,
    attributesMissing: (e2) => `${e2} needs details this request didn't include. Try again and fill in every required field.`,
    attributesUnrequested: (e2) => `${e2} didn't ask for some of the details sent. Try again.`,
    criterionUnknown: (e2) => `${e2} changed what it requires to join. Try again.`,
    presentationInvalid: (e2) => `${e2} didn't accept the request as sent.`,
    permissionDenied: (e2) => `${e2} doesn't share how to join with people who aren't members.`
  }, ub = `domain-not-linked`, db = `This code can't be used. Your wallet couldn't confirm that this website belongs to the community that made the code.`, fb = (e2) => `${e2} hasn't added you yet. Send this DID to its operator:`, pb = {
    [A]: `This browser isn't registered as one of your devices with your agent, and registering it didn't work. Check that the wallet can reach your agent, then refresh the code on the website and try again.`,
    [O]: `This browser has been disabled as one of your devices at your agent, so it can't sign you in. Sign in from another device, or connect this browser to your agent again.`,
    [re]: `Your agent doesn't hold this browser's sign-in approval key yet. Refresh the code on the website and approve again to set it up.`,
    [j]: `Your agent didn't accept this browser's approval. Refresh the code on the website and try again.`,
    [L]: `You declined this sign-in on your phone. Nothing was approved.`,
    [M]: `Your phone didn't approve this sign-in in time. Refresh the code on the website and try again.`
  }, mb = (e2, t2) => {
    let n2 = Bt(e2), r2 = n2 === `pass-on` ? `invalid` : n2;
    return {
      kind: `refused`,
      outcome: r2,
      message: Ht(r2),
      ...t2 ? {
        detail: t2
      } : {}
    };
  }, hb = class {
    deps;
    flows = /* @__PURE__ */ new Map();
    constructor(e2) {
      this.deps = e2;
    }
    has(e2) {
      return this.flows.has(e2);
    }
    async step(e2) {
      if (e2.step === `prepare`) return e2.joinDid === void 0 ? this.prepare(e2.flowId, e2.link, e2.origin, e2.vtaDid, e2.restBaseUrl) : this.prepareJoin(e2.flowId, e2.joinDid, e2.joinSource ?? `pasted`, e2.vtaDid, e2.restBaseUrl);
      let t2 = this.flows.get(e2.flowId);
      if (!t2 || t2.phase === `ended`) return {
        kind: `failed`,
        code: nb,
        message: ob
      };
      try {
        switch (e2.step) {
          case `join`:
            return await this.join(e2.flowId, t2, e2.did);
          case `join-manifest`:
            return await this.joinManifest(e2.flowId, t2);
          case `join-submit`:
            return await this.joinSubmit(e2.flowId, t2, e2);
          case `claim`:
            return await this.claim(e2.flowId, t2, e2.entryId);
          case `prove`:
            return await this.prove(t2, e2.enteredNumber);
          case `adopt-name`:
            return await this.adoptName(t2);
          case `grant-digest`:
            return await this.grantChallenge(t2);
          case `uv-approvers`:
            return await this.uvApprovers(t2);
          case `respond`:
            return await this.respond(t2, e2);
          case `cancel`:
            return await this.cancel(e2.flowId, t2);
        }
      } catch (n2) {
        return await this.fail(e2.flowId, t2, n2);
      }
    }
    pageNumber(e2, t2) {
      if (!/^[0-9]{2}$/.test(t2)) return;
      let n2 = this.flows.get(e2);
      !n2 || n2.phase !== `prepared` && n2.phase !== `claimed` || (n2.pageNumber ??= t2, n2.pageNumberWaiter?.(n2.pageNumber));
    }
    waitForPageNumber(e2) {
      if (e2.pageNumber !== void 0) return Promise.resolve(e2.pageNumber);
      let t2 = this.deps.pageNumberWaitMs ?? 6e3;
      return new Promise((n2) => {
        let r2 = setTimeout(() => {
          delete e2.pageNumberWaiter, n2(void 0);
        }, t2);
        e2.pageNumberWaiter = (t3) => {
          clearTimeout(r2), delete e2.pageNumberWaiter, n2(t3);
        };
      });
    }
    async abort(e2) {
      let t2 = this.flows.get(e2);
      t2 && await this.cancel(e2, t2).catch(() => void 0);
    }
    async prepareJoin(e2, t2, n2, r2, i2) {
      if (this.flows.has(e2)) return {
        kind: `failed`,
        code: nb,
        message: ob
      };
      let a2 = this.deps.contactMethods ?? Nn, o2 = t2.trim(), s2 = this.deps.vta(r2, i2);
      await s2.ensureDevice?.().catch(() => void 0);
      let c2 = await s2.listIdentities(), l2 = c2.filter((e3) => e3.secretKind === `didSelfIssued` && typeof e3.principalDid == `string` && e3.targets.some((e4) => e4.kind === `did` && e4.did === o2)).map((e3) => ({
        entryId: e3.id,
        did: e3.principalDid,
        label: e3.label
      })).filter((e3, t3, n3) => n3.findIndex((t4) => t4.did === e3.did) === t3), u2 = await ih(o2, {
        ...this.deps.resolveDid ? {
          resolveDid: this.deps.resolveDid
        } : {},
        contactMethods: a2
      });
      if (!u2.ok) {
        let e3 = o2.split(`:`).slice(0, 2).join(`:`);
        return {
          kind: `failed`,
          code: rb,
          message: u2.reason === `unsupported-vid` ? `Your wallet doesn't resolve ${e3} identifiers, so it can't check this community. Nothing was sent.` : `Your wallet couldn't verify this DID's document, so it can't tell what this is. Nothing was sent.`,
          party: `wallet`,
          detail: u2.reason === `unsupported-vid` ? {
            reason: `unsupported-vid`,
            method: e3,
            did: o2
          } : {
            reason: `did-document-unverified`,
            did: o2
          }
        };
      }
      let d2 = nh(u2.doc);
      if (!d2.ok) return {
        kind: `failed`,
        code: ib,
        message: d2.reason === `no-portal-service` ? `This DID's document names no sign-in page, so there is nowhere to join. Nothing was sent.` : `This DID's document names no address your wallet can reach. Nothing was sent.`,
        party: `wallet`,
        detail: {
          reason: d2.reason === `no-portal-service` ? `no-portal-service` : `no-common-transport`,
          did: o2,
          service: d2.service,
          ...d2.unusable ? {
            unusable: true
          } : {}
        }
      };
      let { portalOrigin: f2 } = d2.services, p2 = Xy(u2.doc);
      if (p2 !== `community`) return {
        kind: `not-a-community`,
        did: o2,
        portalOrigin: f2
      };
      if (l2.length > 0) return {
        kind: `already-member`,
        communityName: l2[0].label,
        portalOrigin: f2
      };
      let m2 = Zy(f2);
      return this.flows.set(e2, {
        vtaDid: r2,
        phase: `joining`,
        vta: s2,
        vtcDid: o2,
        vtcDocument: u2.doc,
        services: d2.services,
        communityName: m2,
        identities: [],
        kind: p2,
        route: u2.route,
        entries: c2,
        join: {
          source: n2
        }
      }), {
        kind: `join-community`,
        host: m2,
        portalOrigin: f2,
        trustTaskOrigin: Qy(d2.services.trustTaskEndpoint),
        source: n2
      };
    }
    async prepare(e2, t2, n2, r2, i2) {
      if (this.flows.has(e2)) return {
        kind: `failed`,
        code: nb,
        message: ob
      };
      let a2 = this.deps.contactMethods ?? Nn, o2 = tn(t2 ?? ``, {
        now: Math.floor(this.deps.now() / 1e3),
        contactMethods: a2
      });
      if (!o2.ok) return o2.reason === `from-not-allowed` && o2.method ? mb(o2.reason, {
        reason: o2.reason,
        method: o2.method
      }) : mb(o2.reason);
      let s2 = o2.link;
      if (!s2.flow) return mb(`untyped`);
      if (s2.flow.spec.name !== `sign-in`) return mb(`unknown-flow`);
      let c2 = s2.from.value, l2 = this.deps.vta(r2, i2);
      await l2.ensureDevice?.().catch(() => void 0);
      let u2 = await l2.listIdentities(), d2 = u2.filter((e3) => e3.secretKind === `didSelfIssued` && typeof e3.principalDid == `string` && e3.targets.some((e4) => e4.kind === `did` && e4.did === c2)).map((e3) => ({
        entryId: e3.id,
        did: e3.principalDid,
        label: e3.label
      })).filter((e3, t3, n3) => n3.findIndex((t4) => t4.did === e3.did) === t3), f2 = await ih(c2, {
        ...this.deps.resolveDid ? {
          resolveDid: this.deps.resolveDid
        } : {},
        contactMethods: a2
      });
      if (!f2.ok) return f2.reason === `unsupported-vid` ? mb(f2.reason, {
        reason: f2.reason,
        method: s2.from.kind
      }) : mb(f2.reason, {
        reason: `did-document-unverified`,
        did: c2
      });
      let p2 = nh(f2.doc);
      if (!p2.ok) return mb(p2.reason, {
        reason: p2.reason === `no-portal-service` ? `no-portal-service` : `no-common-transport`,
        did: c2,
        service: p2.service,
        ...p2.unusable ? {
          unusable: true
        } : {}
      });
      if (!n2 || !rh(n2, p2.services.portalOrigin)) return mb(`wrong-origin`, {
        reason: `wrong-origin`,
        did: c2,
        ...n2 ? {
          pageOrigin: n2
        } : {},
        portalOrigin: p2.services.portalOrigin
      });
      let m2 = Xy(f2.doc);
      if (d2.length === 0) {
        let { portalOrigin: t3 } = p2.services;
        if (m2 === `community`) {
          let n4 = Zy(t3);
          return this.flows.set(e2, {
            vtaDid: r2,
            phase: `joining`,
            link: s2,
            vta: l2,
            vtcDid: c2,
            vtcDocument: f2.doc,
            services: p2.services,
            communityName: n4,
            identities: [],
            kind: m2,
            route: f2.route,
            entries: u2
          }), {
            kind: `join-community`,
            host: n4,
            portalOrigin: t3,
            trustTaskOrigin: Qy(p2.services.trustTaskEndpoint)
          };
        }
        if (m2 !== `did-hosting`) {
          let e3 = dn(s2.from, a2);
          return {
            kind: `not-member`,
            ...e3 ? {
              contactLabel: e3
            } : {},
            portalOrigin: t3
          };
        }
        let n3 = await l2.listPersonas(), i3 = Zy(t3);
        return this.flows.set(e2, {
          vtaDid: r2,
          phase: `joining`,
          link: s2,
          vta: l2,
          vtcDid: c2,
          vtcDocument: f2.doc,
          services: p2.services,
          communityName: i3,
          identities: [],
          kind: m2,
          route: f2.route,
          personas: n3
        }), {
          kind: `join-hosting`,
          host: i3,
          portalOrigin: t3,
          identities: n3.map((e3) => ({
            did: e3.did,
            contextId: e3.contextId
          }))
        };
      }
      let h2 = d2[0].label;
      return this.flows.set(e2, {
        vtaDid: r2,
        phase: `prepared`,
        link: s2,
        vta: l2,
        vtcDid: c2,
        vtcDocument: f2.doc,
        services: p2.services,
        communityName: h2,
        identities: d2,
        kind: m2,
        route: f2.route
      }), {
        kind: `confirm`,
        communityName: h2,
        portalOrigin: p2.services.portalOrigin,
        identities: d2
      };
    }
    async join(e2, t2, n2) {
      if (t2.phase !== `joining` || t2.kind !== `did-hosting` || !t2.personas?.some((e3) => e3.did === n2)) throw _b();
      let r2 = await this.confirmLinkage(e2, t2);
      if (r2) return r2;
      t2.at = `join`;
      let i2;
      try {
        i2 = await t2.vta.bindIdentity({
          origin: t2.services.portalOrigin,
          did: n2,
          rpDid: t2.vtcDid
        });
      } catch (n3) {
        this.end(t2), this.flows.delete(e2);
        let r3 = n3 instanceof Error ? n3.message : String(n3);
        return {
          kind: `failed`,
          code: sb,
          message: `Your wallet couldn't record ${t2.communityName}: ${r3}`,
          stage: `join`
        };
      }
      return t2.identities = [
        {
          entryId: i2.entryId,
          did: n2,
          label: i2.label
        }
      ], t2.communityName = i2.label, delete t2.personas, t2.phase = `prepared`, {
        kind: `confirm`,
        communityName: t2.communityName,
        portalOrigin: t2.services.portalOrigin,
        identities: t2.identities
      };
    }
    async joinManifest(e2, t2) {
      if (t2.phase !== `joining` || t2.kind !== `community` || t2.joinPlan) throw _b();
      let n2 = await this.confirmLinkage(e2, t2);
      if (n2) return n2;
      let r2 = t2.communityName, { portalOrigin: i2 } = t2.services;
      t2.at = `join-manifest`;
      let a2 = ah(), o2;
      try {
        let e3 = (e4) => yh(a2, ag(a2.did, t2.vtcDid, e4), this.sendOpts(t2), `vtc/join-requests/manifest`, `authentication`), n3;
        try {
          n3 = await e3(`0.4`);
        } catch (t3) {
          if (!(t3 instanceof Xm) || !/unsupportedType$/.test(t3.code)) throw t3;
          n3 = await e3(`0.3`);
        }
        o2 = rg(og(n3.payload, t2.vtcDid));
      } catch (n3) {
        return this.joinFailed(e2, t2, n3, `Your wallet couldn't ask ${r2} how to join`);
      } finally {
        a2.privateKey.fill(0);
      }
      let s2 = o2.displayName === void 0 ? {} : {
        displayName: o2.displayName
      };
      if (!o2.ok) return this.end(t2), this.flows.delete(e2), {
        kind: `join-elsewhere`,
        host: r2,
        portalOrigin: i2,
        reason: o2.reason,
        needs: o2.needs,
        ...s2
      };
      t2.joinPlan = o2, t2.personas = await t2.vta.listPersonas();
      let c2 = await this.termsFor(t2);
      return {
        kind: `join-apply`,
        host: r2,
        portalOrigin: i2,
        ...s2,
        admission: o2.admission,
        attributes: o2.requestedAttributes,
        ...o2.directory ? {
          directory: o2.directory
        } : {},
        identities: t2.personas.map((e3) => $y(e3, t2.entries ?? [])),
        ...c2 ? {
          terms: c2
        } : {}
      };
    }
    async termsFor(e2) {
      let t2 = ne(e2.vtcDocument);
      if (!t2) return;
      let n2;
      try {
        n2 = await T(t2, this.deps.fetch ? {
          fetch: this.deps.fetch
        } : {});
      } catch {
        return {
          status: `unavailable`
        };
      }
      let r2 = await this.deps.termsPreference?.(e2.vtaDid, e2.vtcDid).catch(() => void 0), i2 = await this.deps.myTerms?.().catch(() => void 0), a2 = [
        ...r2?.offer ? [
          r2.offer
        ] : [],
        ...D(i2)
      ], o2 = I(a2, n2);
      if (!o2.ok) return {
        status: `no-match`,
        accepts: n2.accepts
      };
      let s2 = le(o2.code);
      e2.terms = {
        code: o2.code,
        counter: o2.counter,
        community: n2
      };
      let c2 = r2?.terms ?? true;
      return {
        status: `offered`,
        code: s2.code,
        title: s2.title,
        meaning: s2.meaning,
        counter: o2.counter,
        ...o2.declined ? {
          declined: o2.declined
        } : {},
        accepts: n2.accepts,
        ...n2.agreementsUrl ? {
          agreementsUrl: n2.agreementsUrl
        } : {},
        enabled: c2
      };
    }
    async joinSubmit(e2, t2, n2) {
      let r2 = t2.joinPlan;
      if (t2.phase !== `joining` || t2.kind !== `community` || !r2 || !t2.personas?.some((e3) => e3.did === n2.did) || typeof n2.registryConsent != `boolean` || n2.terms !== void 0 && (!t2.terms || typeof n2.terms?.code != `string` || n2.terms.code !== t2.terms.code)) throw _b();
      let i2 = n2.terms ? N(n2.did, t2.vtcDid, n2.terms.code, this.deps.now()) : void 0, a2 = new Map(r2.requestedAttributes.map((e3) => [
        e3.type,
        e3
      ])), o2 = [];
      for (let e3 of Array.isArray(n2.attributes) ? n2.attributes : []) {
        if (!a2.has(e3?.type) || typeof e3.value != `string` || o2.some((t4) => t4.type === e3.type)) throw _b();
        let t3 = e3.value.trim();
        t3 !== `` && o2.push({
          type: e3.type,
          value: t3
        });
      }
      for (let e3 of r2.requestedAttributes) if (e3.required && !o2.some((t3) => t3.type === e3.type)) throw _b();
      let s2 = t2.communityName, { portalOrigin: c2 } = t2.services;
      t2.at = `join`;
      let l2;
      try {
        l2 = await t2.vta.bindIdentity({
          origin: c2,
          did: n2.did,
          rpDid: t2.vtcDid
        });
      } catch (n3) {
        return this.end(t2), this.flows.delete(e2), {
          kind: `failed`,
          code: sb,
          message: `Your wallet couldn't record ${s2}, so nothing was sent to it: ${n3 instanceof Error ? n3.message : String(n3)}`,
          stage: `join`
        };
      }
      let u2 = () => t2.vta.unbindIdentity(l2.entryId).catch(() => void 0), d2, f2;
      try {
        let e3 = sg(n2.did, t2.vtcDid, {
          criterion: r2.criterion,
          attributes: o2,
          registryConsent: n2.registryConsent,
          ...i2 ? {
            extensions: oe(i2)
          } : {}
        });
        t2.at = `join-sign`;
        let a3 = ph(e3, await t2.vta.signTask(l2.entryId, e3), `authentication`);
        t2.at = `join-submit`;
        let c3 = await bh(a3, this.sendOpts(t2), `vtc/join-requests/submit`, `authentication`);
        if (d2 = cg(c3.payload), i2) {
          f2 = {
            code: i2.references[0].code,
            agreementId: i2.agreementId
          };
          let e4 = {
            vtaDid: t2.vtaDid,
            communityDid: t2.vtcDid,
            host: s2,
            applicantDid: n2.did,
            code: f2.code,
            agreementId: i2.agreementId,
            requestId: d2.requestId,
            effect: d2.kind === `admitted` ? `allow` : d2.kind === `declined` ? `deny` : `pending`,
            requestDigest: await mh(a3),
            replyDigest: await mh(c3.doc),
            at: this.deps.now()
          };
          await this.deps.recordTerms?.(e4).catch(() => void 0);
        }
      } catch (n3) {
        return n3 instanceof Xm && eb(n3.code) === `requestAlreadyOpen` ? (this.end(t2), this.flows.delete(e2), {
          kind: `join-pending`,
          host: s2,
          portalOrigin: c2
        }) : (await u2(), this.joinFailed(e2, t2, n3, `${s2} didn't take the request`));
      }
      return d2.kind === `admitted` && t2.join ? (this.end(t2), this.flows.delete(e2), {
        kind: `join-admitted`,
        host: s2,
        portalOrigin: c2,
        ...r2.displayName === void 0 ? {} : {
          displayName: r2.displayName
        },
        ...d2.role ? {
          role: d2.role
        } : {},
        ...f2 ? {
          terms: f2
        } : {}
      }) : d2.kind === `admitted` ? (t2.identities = [
        {
          entryId: l2.entryId,
          did: n2.did,
          label: l2.label
        }
      ], t2.communityName = l2.label, delete t2.personas, delete t2.joinPlan, delete t2.entries, t2.phase = `prepared`, {
        kind: `confirm`,
        communityName: t2.communityName,
        portalOrigin: c2,
        identities: t2.identities
      }) : (this.end(t2), this.flows.delete(e2), d2.kind === `pending` ? {
        kind: `join-pending`,
        host: s2,
        portalOrigin: c2,
        ...d2.needs ? {
          needs: d2.needs
        } : {},
        ...f2 ? {
          terms: f2
        } : {}
      } : (await u2(), {
        kind: `failed`,
        code: cb,
        message: d2.reason ? `${s2} declined your request to join: ${d2.reason}` : `${s2} declined your request to join.`,
        stage: `join-submit`,
        party: `community`,
        ...d2.code ? {
          cause: ye(d2.code) ?? `deny`
        } : {}
      }));
    }
    joinFailed(e2, t2, n2, r2) {
      let i2 = bb(t2.at, n2);
      this.end(t2), this.flows.delete(e2);
      let a2 = t2.communityName;
      if (n2 instanceof Xm) {
        let e3 = eb(n2.code);
        if (vb.has(n2.code)) return {
          kind: `failed`,
          code: n2.code,
          message: `${r2}: it couldn't be reached. Check your connection and try again.`,
          ...i2
        };
        let t3 = lb[e3];
        return {
          kind: `failed`,
          code: n2.code,
          message: t3 ? t3(a2) : `${r2}. It answered ${n2.code}.`,
          ...i2
        };
      }
      let o2 = h(n2) ?? xb(n2);
      if (o2 && t2.at === `join-sign`) return {
        kind: `failed`,
        code: o2,
        message: `${r2}: your agent didn't sign the request (${o2}).`,
        ...i2
      };
      let s2 = n2?.code === `auth/oob/reply-invalid` ? Zm : sb, c2 = s2 === `sign-in/join-failed` ? Sb(n2) : void 0;
      return {
        kind: `failed`,
        code: s2,
        message: s2 === `auth/oob/reply-invalid` ? `${r2}: its answer didn't check out, so your wallet stopped.` : `${r2}: ${n2 instanceof Error ? n2.message : String(n2)}`,
        ...i2,
        ...c2 ? {
          cause: c2
        } : {}
      };
    }
    async confirmLinkage(e2, t2) {
      if (!(t2.route !== `domain-linked` || t2.linked)) {
        if (t2.at = `domain-linkage`, (await jh({
          did: t2.vtcDid,
          didDocument: t2.vtcDocument,
          origin: t2.services.portalOrigin,
          now: this.deps.now(),
          ...this.deps.fetch ? {
            fetch: this.deps.fetch
          } : {}
        })).ok) {
          t2.linked = true;
          return;
        }
        return this.end(t2), this.flows.delete(e2), {
          kind: `failed`,
          code: ub,
          message: db,
          stage: `domain-linkage`,
          detail: {
            reason: ub,
            did: t2.vtcDid,
            portalOrigin: t2.services.portalOrigin
          }
        };
      }
    }
    async claim(e2, t2, n2) {
      if (t2.phase !== `prepared`) throw _b();
      let r2 = t2.identities.find((e3) => e3.entryId === n2);
      if (!r2) throw _b();
      let i2 = await this.confirmLinkage(e2, t2);
      if (i2) return i2;
      let a2 = ah();
      t2.kA = a2, t2.entry = r2, t2.at = `claim`;
      let o2 = await yh(a2, sh(a2, t2.vtcDid, tb(t2)), this.sendOpts(t2), `auth/oob/claim`);
      t2.phase = `claimed`, t2.step1 = Sh(o2.payload, {
        requestId: tb(t2),
        vtcDid: t2.vtcDid,
        portalOrigin: t2.services.portalOrigin,
        now: this.deps.now()
      });
      let s2 = Tb(t2.step1.service.name, t2.step1.service.did, t2.communityName, t2.services.portalOrigin);
      if (s2 === void 0) {
        let e3 = await this.waitForPageNumber(t2);
        if (e3 !== void 0 && t2.phase === `claimed`) return await this.prove(t2, e3);
      }
      return {
        kind: `enter-number`,
        decisionDeadline: Ch(t2.step1.decisionDeadline),
        audience: Ym(t2.step1),
        ...s2 === void 0 ? {} : {
          nameMismatch: s2
        }
      };
    }
    async adoptName(e2) {
      if (e2.phase !== `claimed` || !e2.entry || !e2.step1) throw _b();
      let t2 = Tb(e2.step1.service.name, e2.step1.service.did, e2.communityName, e2.services.portalOrigin), n2 = (t3 = {}) => ({
        kind: `enter-number`,
        decisionDeadline: Ch(e2.step1.decisionDeadline),
        audience: Ym(e2.step1),
        ...t3
      });
      if (t2 === void 0) return n2();
      let r2 = t2.trim().replace(/\s+/g, ` `);
      try {
        if (!e2.vta.renameIdentity) throw Error(`this wallet cannot rename its records`);
        await e2.vta.renameIdentity(e2.entry.entryId, r2);
      } catch (e3) {
        return n2({
          nameMismatch: t2,
          adoptFailed: e3 instanceof Error ? e3.message : String(e3)
        });
      }
      e2.communityName = r2, e2.entry = {
        ...e2.entry,
        label: r2
      };
      let i2 = await this.waitForPageNumber(e2);
      return i2 !== void 0 && e2.phase === `claimed` ? await this.prove(e2, i2) : n2();
    }
    async prove(e2, t2) {
      if (e2.phase !== `claimed` || !e2.kA || !e2.entry || !e2.step1) throw _b();
      let n2 = ch(e2.entry.did, e2.vtcDid, {
        requestId: tb(e2),
        approverKey: e2.kA.did,
        enteredNumber: t2
      });
      e2.at = `identify`;
      let r2 = ph(n2, await e2.vta.signIdentify(e2.entry.entryId, n2), `authentication`);
      e2.at = `prove`;
      let i2 = `0.2`, a2;
      try {
        a2 = await yh(e2.kA, lh(e2.kA, e2.vtcDid, r2, tb(e2), `0.2`), this.sendOpts(e2), `auth/oob/prove`);
      } catch (t3) {
        if (!(t3 instanceof Xm) || !/unsupportedType$/.test(t3.code)) throw t3;
        i2 = `0.1`, a2 = await yh(e2.kA, lh(e2.kA, e2.vtcDid, r2, tb(e2), `0.1`), this.sendOpts(e2), `auth/oob/prove`);
      }
      let o2 = wh(a2.payload, e2.step1, e2.entry.did), s2 = await e2.vta.uvMethod().catch(() => void 0);
      return e2.version = i2, e2.step2Doc = a2.doc, e2.phase = `identified`, {
        kind: `review`,
        location: o2.requester.location,
        browser: o2.requester.browser,
        os: o2.requester.os,
        createdAt: o2.requester.createdAt,
        network: Th(o2.requester.sameNetwork),
        identifiedAs: o2.identifiedAs,
        audience: Ym(o2),
        decisionDeadline: Ch(e2.step1.decisionDeadline),
        ...o2.signingScope ? {
          signingScope: o2.signingScope
        } : {},
        ...s2 ? {
          uvMethod: s2
        } : {}
      };
    }
    async buildGrantFor(e2, t2) {
      let n2 = e2.step2Doc.payload;
      return uh(e2.entry.did, e2.vtcDid, {
        requestId: tb(e2),
        decision: t2,
        sessionKey: n2.sessionKey,
        approverKey: e2.kA.did,
        origin: n2.origin,
        contextDigest: await hh(e2.step2Doc),
        notAfter: Math.floor((this.deps.now() + this.deps.grantLifetimeMs) / 1e3),
        ...n2.signingScope ? {
          signingScope: n2.signingScope
        } : {}
      }, e2.version ?? `0.1`);
    }
    async grantChallenge(e2) {
      if (e2.phase !== `identified` || !e2.kA || !e2.step2Doc) throw _b();
      return e2.at = `grant-digest`, e2.unsignedGrant = await this.buildGrantFor(e2, `approve`), e2.grantDigest = await gh(e2.unsignedGrant), {
        kind: `uv-challenge`,
        challenge: ae(i(e2.grantDigest)),
        vtaDid: e2.vtaDid
      };
    }
    async uvApprovers(e2) {
      if (e2.phase !== `identified`) throw _b();
      try {
        return {
          kind: `uv-approvers`,
          approvers: await e2.vta.uvApprovers()
        };
      } catch (e3) {
        return {
          kind: `uv-approvers`,
          approvers: [],
          error: e3?.message ?? String(e3)
        };
      }
    }
    async respond(e2, t2) {
      if (e2.phase !== `identified` || !e2.kA || !e2.entry) throw _b();
      let n2 = t2.decision, r2, i2;
      if (t2.decision === `approve`) {
        if (!e2.unsignedGrant || !e2.grantDigest) throw _b();
        r2 = e2.unsignedGrant;
        let n3 = e2.grantDigest;
        if (`prfOutputB64u` in t2) {
          if (!t2.prfOutputB64u) throw _b();
          let r3 = te(t2.prfOutputB64u);
          i2 = {
            payloadDigest: n3,
            prfOutput: r3
          }, e2.at = `enrol-uv`, await e2.vta.enrolUvKey(r3);
        } else if (`pin` in t2) {
          if (typeof t2.pin != `string` || t2.pin.length === 0) throw _b();
          let r3;
          t2.setPin && (e2.at = `enrol-uv`, r3 = await e2.vta.enrolUvMethod({
            kind: `vtaPin`,
            pin: t2.pin
          })), i2 = {
            payloadDigest: n3,
            pin: t2.pin,
            ...r3 ? {
              pinKey: r3
            } : {}
          };
        } else if (t2.remote === true) t2.approver && (e2.at = `enrol-uv`, await e2.vta.enrolUvMethod({
          kind: `remoteApprover`,
          approver: t2.approver
        })), i2 = {
          payloadDigest: n3,
          remote: true
        };
        else throw _b();
      } else r2 = await this.buildGrantFor(e2, `decline`);
      e2.at = `grant`;
      let a2;
      try {
        a2 = await e2.vta.signGrant(e2.entry.entryId, r2, i2);
      } catch (e3) {
        let t3 = i2 && gb(e3);
        if (t3) return t3;
        throw e3;
      } finally {
        i2 && `pinKey` in i2 && i2.pinKey?.fill(0);
      }
      let o2 = ph(r2, a2, `assertionMethod`);
      e2.at = `respond`;
      let s2 = await yh(e2.kA, dh(e2.kA, e2.vtcDid, o2, tb(e2), e2.version ?? `0.1`), this.sendOpts(e2), `auth/oob/respond`);
      return this.end(e2), {
        kind: `done`,
        decision: n2,
        status: typeof s2.payload?.status == `string` ? s2.payload.status : `ok`
      };
    }
    async cancel(e2, t2) {
      let n2 = t2.phase !== `ended` && t2.kA !== void 0, r2 = t2.kA;
      return t2.phase = `ended`, this.flows.delete(e2), n2 && r2 && await yh(r2, fh(r2, t2.vtcDid, tb(t2)), this.sendOpts(t2), `auth/oob/cancel`).catch(() => void 0), this.end(t2), {
        kind: `done`,
        decision: `decline`,
        status: `cancelled`
      };
    }
    end(e2) {
      e2.phase = `ended`, e2.kA && e2.kA.privateKey.fill(0), delete e2.kA;
    }
    async fail(e2, t2, n2) {
      if (n2?.code === `sign-in/out-of-order`) return {
        kind: `failed`,
        code: nb,
        message: ob,
        party: `wallet`
      };
      let r2 = bb(t2.at, n2);
      if (t2.kA && (n2 instanceof Xm ? (this.end(t2), this.flows.delete(e2)) : await this.cancel(e2, t2).catch(() => void 0)), n2 instanceof Xm) {
        let e3 = eb(n2.code);
        if (e3 === `notAuthorized` && t2.at === `prove` && t2.kind === `did-hosting` && t2.entry) {
          let e4 = Zy(t2.services.portalOrigin);
          return {
            kind: `failed`,
            code: n2.code,
            message: fb(e4),
            ...r2,
            unlisted: {
              host: e4,
              did: t2.entry.did
            }
          };
        }
        return e3 === `alreadyClaimed` ? {
          kind: `failed`,
          code: n2.code,
          message: ab,
          ...r2
        } : e3 === `requestExpired` ? mb(`expired`) : {
          kind: `failed`,
          code: n2.code,
          message: `${Ht(`invalid`)} ${ob}`,
          ...r2
        };
      }
      let i2 = h(n2), a2 = i2 ? pb[i2] : void 0;
      if (i2 && a2) return {
        kind: `failed`,
        code: i2,
        message: a2,
        ...r2
      };
      let o2 = fe(n2), s2 = o2 ? se[o2.code] : void 0;
      if (o2 && s2) return {
        kind: `failed`,
        code: o2.code,
        message: s2,
        ...r2,
        party: `vta`
      };
      let c2 = n2?.code === `auth/oob/reply-invalid` ? Zm : `sign-in/failed`, l2 = c2 === `sign-in/failed` ? Sb(n2) : void 0;
      return {
        kind: `failed`,
        code: c2,
        message: `${Ht(`invalid`)} ${ob}`,
        ...r2,
        ...l2 ? {
          cause: l2
        } : {}
      };
    }
    sendOpts(e2) {
      return {
        vtcDid: e2.vtcDid,
        vtcDocument: e2.vtcDocument,
        trustTaskEndpoint: e2.services.trustTaskEndpoint,
        ...this.deps.fetch ? {
          fetch: this.deps.fetch
        } : {}
      };
    }
  };
  function gb(e2) {
    let t2 = F(e2);
    switch (t2?.code) {
      case pe:
        return {
          kind: `uv-pin`,
          ...t2.attemptsRemaining === void 0 ? {} : {
            attemptsRemaining: t2.attemptsRemaining
          },
          ...t2.lockedUntil === void 0 ? {} : {
            lockedUntil: t2.lockedUntil * 1e3
          }
        };
      case w:
        return {
          kind: `uv-pin`,
          ...t2.lockedUntil === void 0 ? {} : {
            lockedUntil: t2.lockedUntil * 1e3
          }
        };
      case ue:
        return {
          kind: `uv-pending`,
          ...t2.matchCode === void 0 ? {} : {
            matchCode: t2.matchCode
          },
          ...t2.expiresAt === void 0 ? {} : {
            expiresAt: t2.expiresAt * 1e3
          }
        };
      default:
        return;
    }
  }
  function _b() {
    return Object.assign(Error(`this step is not available now`), {
      code: nb
    });
  }
  var vb = /* @__PURE__ */ new Set([
    `network`,
    `timeout`
  ]), yb = /* @__PURE__ */ new Set([
    `join-sign`,
    `identify`,
    `grant`,
    `enrol-uv`
  ]);
  function bb(e2, t2) {
    let n2 = t2 instanceof Xm ? vb.has(t2.code) ? void 0 : `community` : t2?.code === `auth/oob/reply-invalid` ? `wallet` : h(t2) !== void 0 || e2 !== void 0 && yb.has(e2) && xb(t2) !== void 0 ? `vta` : void 0;
    return {
      ...e2 ? {
        stage: e2
      } : {},
      ...n2 ? {
        party: n2
      } : {}
    };
  }
  function xb(e2) {
    let t2 = e2;
    return ye(t2?.details?.details?.code) ?? ye(t2?.details?.code) ?? ye(t2?.code);
  }
  function Sb(e2) {
    let t2 = xb(e2);
    if (t2) return t2;
    let n2 = e2?.name;
    return n2 === `Error` ? void 0 : ye(n2);
  }
  function Cb(e2) {
    return e2.trim().replace(/\s+/g, ` `).toLowerCase();
  }
  function wb(e2) {
    try {
      return new URL(e2).hostname.toLowerCase();
    } catch {
      return;
    }
  }
  function Tb(e2, t2, n2, r2) {
    if (typeof e2 != `string`) return;
    let i2 = e2.trim();
    if (i2 !== `` && (typeof t2 != `string` || i2 !== t2.trim()) && !/^did:/i.test(i2)) {
      if (r2 !== void 0) {
        let t3 = wb(r2);
        if (Cb(e2) === t3 || Cb(n2) === t3) return;
      }
      return Cb(e2) === Cb(n2) ? void 0 : e2;
    }
  }
  var Eb = /* @__PURE__ */ new Set([
    `prfSealedKey`,
    `vtaPin`,
    `remoteApprover`
  ]), Db = `pnm/uv-key/enrolled/`;
  function Ob(e2) {
    return Db + e2;
  }
  var kb = class extends Error {
    code = `sign-in/pin-too-short`;
    constructor() {
      super(`Use 6 or more characters.`), this.name = `PinPolicyError`;
    }
  }, Ab = class extends Error {
    code = `sign-in/pin-unknown`;
    constructor() {
      super(`Your agent holds no PIN for this browser. Set one up again.`), this.name = `PinParamsMissingError`;
    }
  };
  async function jb(e2, t2) {
    let n2 = await e2.store.get(Ob(t2));
    if (!n2 || typeof n2.kind != `string`) return;
    let { did: r2 } = await e2.holder(t2);
    return n2.holderDid === r2 ? n2 : void 0;
  }
  async function Mb(e2, t2, n2) {
    let r2 = (e2.now ?? Date.now)(), i2 = {
      ...n2,
      at: r2
    };
    return await e2.store.put(Ob(t2), i2), await e2.enrolled?.(t2, n2.holderDid, r2), i2;
  }
  function Nb(e2, t2, n2, r2) {
    return Mb(e2, t2, {
      holderDid: n2,
      kind: `prfSealedKey`,
      uvDid: r2
    });
  }
  async function Pb(e2, t2, n2) {
    let { sender: r2, holder: i2, service: a2 } = await e2.session(t2, n2), o2 = await b(r2, {
      holder: i2,
      service: a2
    });
    if (!o2 || !Eb.has(o2.kind)) return;
    let s2 = o2.kind;
    if (s2 === `vtaPin`) {
      if (!o2.salt || o2.iterations === void 0) return;
      await Va(e2.store, t2, {
        salt: o2.salt,
        iterations: o2.iterations
      });
    }
    return Mb(e2, t2, {
      holderDid: i2.did,
      kind: s2,
      ...s2 === `remoteApprover` && o2.approver ? {
        approver: o2.approver
      } : {},
      ...s2 === `prfSealedKey` && o2.did ? {
        uvDid: o2.did
      } : {}
    });
  }
  async function Fb(e2, t2, n2) {
    return await jb(e2, t2) ?? Pb(e2, t2, n2);
  }
  async function Ib(e2, t2, n2, r2, i2) {
    let a2 = await Ba(e2.store, t2);
    if (a2 ||= (await Pb(e2, t2, n2), await Ba(e2.store, t2)), !a2) throw new Ab();
    let o2 = await rf(r2, te(a2.salt), a2.iterations);
    try {
      return await i2(o2);
    } finally {
      o2.fill(0);
    }
  }
  async function Lb(e2, t2, n2, r2, i2) {
    let a2 = (await jb(e2, t2))?.kind === `vtaPin` ? await Ib(e2, t2, n2, i2 ?? ``, (e3) => sf(e3, r2)) : void 0, { sender: o2, holder: s2, service: c2 } = await e2.session(t2, n2);
    return await y(o2, {
      holder: s2,
      service: c2,
      enrolment: r2,
      displayName: e2.displayName(),
      ...a2 ? {
        changeProof: a2
      } : {}
    }), s2.did;
  }
  async function Rb(e2, t2, n2, r2, i2) {
    if (r2.normalize(`NFC`).length < 6) throw new kb();
    let a2 = cf(), o2 = Qd, s2 = await rf(r2, a2, o2);
    try {
      let r3 = await Lb(e2, t2, n2, p({
        salt: a2,
        iterations: o2,
        verifier: s2
      }), i2);
      return await Va(e2.store, t2, {
        salt: ae(a2),
        iterations: o2
      }), {
        record: await Mb(e2, t2, {
          holderDid: r3,
          kind: `vtaPin`
        }),
        key: s2
      };
    } catch (e3) {
      throw s2.fill(0), e3;
    }
  }
  async function zb(e2, t2, n2, r2, i2) {
    let o2 = await Lb(e2, t2, n2, a(r2), i2);
    return await Ha(e2.store, t2), Mb(e2, t2, {
      holderDid: o2,
      kind: `remoteApprover`,
      approver: r2
    });
  }
  async function Bb(e2, t2, n2, r2, i2, a2, o2) {
    let s2 = o2 ? await of(o2, a2) : await Ib(e2, t2, n2, i2, (e3) => of(e3, a2)), { signing: c2 } = await e2.holder(t2);
    return {
      decision: await E({
        uvKey: c2,
        vtaDid: r2,
        payloadDigest: a2
      }),
      pinProof: s2
    };
  }
  async function Vb(e2, t2, n2) {
    let { sender: i2, holder: a2, service: o2 } = await e2.session(t2, n2);
    return r(i2, {
      holder: a2,
      service: o2
    });
  }
  var Hb = `didSelfIssued`;
  function Ub(e2) {
    try {
      return new URL(e2).hostname || e2;
    } catch {
      return e2;
    }
  }
  function Wb(e2) {
    return {
      contextId: e2.contextId,
      label: Ub(e2.origin),
      targets: [
        {
          kind: `webOrigin`,
          origin: e2.origin
        },
        ...e2.rpDid ? [
          {
            kind: `did`,
            did: e2.rpDid
          }
        ] : []
      ],
      secretKind: Hb,
      secret: {
        kind: `didSelfIssued`,
        did: e2.did,
        signingKeyId: e2.signingKeyId
      }
    };
  }
  async function Gb(e2, t2) {
    let { origin: n2, did: r2, rpDid: i2 } = t2;
    try {
      let t3 = (await e2.listDids()).find((e3) => e3.did === r2);
      if (!t3) return {
        ok: false,
        error: `${r2} is not an identity this agent hosts`
      };
      let a2 = await e2.deriveSigningKeyIds(r2);
      if (a2.error) return {
        ok: false,
        error: a2.error
      };
      let o2 = a2.candidates;
      if (o2.length !== 1) return {
        ok: false,
        error: o2.length === 0 ? `no signing key could be derived from ${r2}` : `${r2} has ${o2.length} possible signing keys \u2014 bind it from the wallet's vault panel, which lets you choose one`
      };
      let { entryId: s2 } = await e2.upsert(Wb({
        origin: n2,
        did: r2,
        contextId: t3.contextId,
        signingKeyId: o2[0],
        ...i2 ? {
          rpDid: i2
        } : {}
      }));
      return {
        ok: true,
        entryId: s2
      };
    } catch (e3) {
      return {
        ok: false,
        error: e3 instanceof Error ? e3.message : String(e3)
      };
    }
  }
  var Kb = [
    [
      `Microsoft Edge`,
      `Edge`
    ],
    [
      `Brave`,
      `Brave`
    ],
    [
      `Opera`,
      `Opera`
    ],
    [
      `Vivaldi`,
      `Vivaldi`
    ],
    [
      `Google Chrome`,
      `Chrome`
    ],
    [
      `Chromium`,
      `Chromium`
    ]
  ], qb = [
    [
      /Firefox\//,
      `Firefox`
    ],
    [
      /Edg\//,
      `Edge`
    ],
    [
      /OPR\//,
      `Opera`
    ],
    [
      /Vivaldi\//,
      `Vivaldi`
    ],
    [
      /Chrome\//,
      `Chrome`
    ],
    [
      /Safari\//,
      `Safari`
    ]
  ], Jb = [
    [
      /CrOS/,
      `ChromeOS`
    ],
    [
      /Android/,
      `Android`
    ],
    [
      /iPhone|iPad/,
      `iOS`
    ],
    [
      /Macintosh|Mac OS X/,
      `macOS`
    ],
    [
      /Windows/,
      `Windows`
    ],
    [
      /Linux/,
      `Linux`
    ]
  ], Yb = {
    macOS: `macOS`,
    Windows: `Windows`,
    Linux: `Linux`,
    "Chrome OS": `ChromeOS`,
    ChromeOS: `ChromeOS`,
    Android: `Android`
  };
  function Xb(e2) {
    let t2 = e2.userAgentData?.brands ?? [];
    for (let [e3, n3] of Kb) if (t2.some((t3) => t3.brand === e3)) return n3;
    let n2 = e2.userAgent ?? ``;
    return qb.find(([e3]) => e3.test(n2))?.[1];
  }
  function Zb(e2) {
    let t2 = e2.userAgentData?.platform;
    if (t2 && Yb[t2]) return Yb[t2];
    let n2 = e2.userAgent ?? ``;
    return Jb.find(([e3]) => e3.test(n2))?.[1];
  }
  function Qb(e2 = globalThis.navigator ?? {}) {
    let t2 = Xb(e2) ?? `Browser`, n2 = Zb(e2);
    return {
      displayName: n2 ? `${t2} on ${n2}` : t2,
      ...n2 ? {
        platform: n2
      } : {}
    };
  }
  function $b(e2) {
    if (e2 == null) return;
    let t2;
    try {
      t2 = JSON.parse(JSON.stringify(e2));
    } catch {
      return;
    }
    if (t2 != null && (typeof t2 != `object` || Array.isArray(t2) || Object.keys(t2).length !== 0)) return t2;
  }
  function ex(e2) {
    return e2 instanceof Error ? e2.message : String(e2);
  }
  function tx(e2) {
    let t2 = ex(e2);
    if (!(e2 instanceof _)) return {
      ok: false,
      error: t2
    };
    let n2 = e2.details, r2 = typeof n2?.code == `string` && n2.code.length > 0 ? n2.code : void 0, i2 = $b(r2 === void 0 ? e2.details : n2?.details);
    return {
      ok: false,
      error: t2,
      code: r2 ?? e2.code,
      ...i2 === void 0 ? {} : {
        details: i2
      }
    };
  }
  var nx = (e2) => typeof e2 == `string` && e2 ? e2 : void 0;
  function rx(e2, t2, n2) {
    if (!t2 || typeof t2 != `object`) return;
    let r2 = t2;
    if (r2.ok !== false) return;
    let i2 = e2 && typeof e2 == `object` ? e2 : {}, a2 = nx(i2.type) ?? `(unknown request)`, o2 = {
      error: nx(r2.error) ?? `(no message)`,
      elapsedMs: Math.round(n2)
    }, s2 = nx(i2.vtaDid);
    s2 && (o2.vtaDid = s2);
    let c2 = nx(i2.params?.type);
    c2 && (o2.task = c2);
    let l2 = nx(r2.code);
    return l2 && (o2.code = l2), r2.details !== void 0 && (o2.details = r2.details), [
      `[pnm request] ${a2} failed after ${(n2 / 1e3).toFixed(1)}s`,
      o2
    ];
  }
  var ix = (e2) => `${(e2 / 1e3).toFixed(1)} s`;
  function ax(e2, t2) {
    let n2 = `vta.roundtrip.${e2.toLowerCase()}`, r2 = `Agent answers over ${e2}`;
    return t2.kind === `skipped` ? {
      id: n2,
      label: r2,
      status: `skip`,
      detail: t2.reason
    } : t2.kind === `answered` ? t2.refusal ? {
      id: n2,
      label: r2,
      status: `pass`,
      detail: `The agent answered in ${ix(t2.ms)}, refusing the request: ${t2.refusal.message}. The path works both ways; the refusal is about this wallet's authority at the agent.`,
      code: t2.refusal.code
    } : {
      id: n2,
      label: r2,
      status: `pass`,
      detail: `The agent answered in ${ix(t2.ms)}.`
    } : {
      id: n2,
      label: r2,
      status: `fail`,
      detail: `No answer after ${ix(t2.ms)}: ${t2.message}`,
      ...t2.code ? {
        code: t2.code
      } : {},
      remediation: e2 === `REST` ? `Check the agent's REST endpoint and this wallet's sign-in to it.` : "The request left this wallet. Check the agent's log for the reply it sent (`failed to send TSP reply`, or the reply's route) and the mediator's traffic for this wallet's account."
    };
  }
  var ox = `sign-trust-task/as-did-unavailable`, sx = class extends Error {
    code;
    constructor(e2) {
      super(e2), this.code = ox, this.name = `SignAsUnavailableError`;
    }
  };
  function cx(e2, t2) {
    return e2 !== void 0 && e2 !== t2;
  }
  function lx(e2, t2, n2) {
    if (!cx(e2, t2)) return {
      kind: `holder`
    };
    if (n2 === null) throw new sx(`cannot sign as ${e2}: this wallet has no route to its VTA to sign with that identity`);
    let r2 = n2.find((t3) => t3.principalDid === e2 && (t3.secretKind === `didSelfIssued` || t3.secretKind === `didcommPeer`));
    if (!r2) throw new sx(`cannot sign as ${e2}: no identity of that DID is held in this wallet's vault`);
    return {
      kind: `vault`,
      entryId: r2.id
    };
  }
  function ux(e2, t2, n2) {
    return {
      accessToken: e2.accessToken,
      refreshToken: e2.refreshToken ?? ``,
      sessionId: e2.sessionId,
      holderDid: t2,
      timings: n2
    };
  }
  function dx(e2) {
    if (e2) return `a persona cannot sign in over DIDComm or TSP: the document must be sent by its signer, and the persona's keys stay at the agent. Use the REST sign-in for this site`;
  }
  function fx(e2, t2) {
    return t2.inboxes[e2.vtaDid]?.did === e2.mediatorDid ? {
      ok: true,
      isInbox: true
    } : t2.pooled.some((t3) => t3.mediatorDid === e2.mediatorDid && t3.vtaDid === e2.vtaDid) ? {
      ok: true,
      isInbox: false
    } : {
      ok: false,
      code: `mediator/no-standing`,
      reason: `this wallet holds no session with ${e2.mediatorDid} for that agent. The lens only looks through a relay the wallet already uses \u2014 it never signs in somewhere new.`
    };
  }
  function px(e2, t2) {
    let n2 = /* @__PURE__ */ new Map(), r2 = (e3) => `${e3.mediatorDid}|${e3.vtaDid}`;
    for (let [i2, a2] of Object.entries(e2.inboxes)) {
      if (!a2?.did) continue;
      let e3 = {
        mediatorDid: a2.did,
        vtaDid: i2
      };
      n2.set(r2(e3), {
        ...e3,
        isInbox: true,
        state: t2(e3) ?? `closed`
      });
    }
    for (let i2 of e2.pooled) n2.has(r2(i2)) || n2.set(r2(i2), {
      ...i2,
      isInbox: false,
      state: t2(i2) ?? `closed`
    });
    return [
      ...n2.values()
    ].sort((e3, t3) => Number(t3.isInbox) - Number(e3.isInbox));
  }
  var mx = [
    `https://trusttasks.org/spec/messaging/stats/show/0.1`,
    `https://trusttasks.org/spec/messaging/queue/list/0.1`,
    `https://trusttasks.org/spec/messaging/queue/status/0.1`,
    `https://trusttasks.org/spec/messaging/queue/purge/0.1`,
    `https://trusttasks.org/spec/messaging/account/get/0.1`,
    `https://trusttasks.org/spec/messaging/account/list/0.1`,
    `https://trusttasks.org/spec/messaging/account/update/0.1`,
    `https://trusttasks.org/spec/messaging/message/list/0.1`,
    `https://trusttasks.org/spec/messaging/message/delete/0.1`,
    `https://trusttasks.org/spec/audit/list/0.1`,
    `https://trusttasks.org/spec/config/show/0.1`
  ];
  function hx(e2) {
    return mx.includes(e2);
  }
  var gx = `https://trusttasks.org/spec/messaging/monitor/subscribe/0.1`, _x = `https://trusttasks.org/spec/messaging/monitor/subscribe/0.1#response`, vx = `https://trusttasks.org/spec/messaging/monitor/unsubscribe/0.1`, yx = `https://trusttasks.org/spec/messaging/monitor/unsubscribe/0.1#response`;
  async function bx(e2, t2, n2, r2, i2, a2) {
    let o2 = R(n2, a2, {
      issuer: t2.holder.did,
      recipient: t2.mediator.did
    });
    return e2.send(o2, {
      expectedResponseType: r2,
      operationLabel: i2
    });
  }
  async function xx(e2, t2, n2 = {}) {
    return bx(e2, t2, gx, _x, `messaging/monitor/subscribe`, {
      ...n2.filter ? {
        filter: n2.filter
      } : {},
      ...n2.leaseSeconds === void 0 ? {} : {
        leaseSeconds: n2.leaseSeconds
      },
      ...n2.maxEventsPerSecond === void 0 ? {} : {
        maxEventsPerSecond: n2.maxEventsPerSecond
      },
      ...n2.subscriptionId ? {
        subscriptionId: n2.subscriptionId
      } : {}
    });
  }
  async function Sx(e2, t2, n2) {
    return bx(e2, t2, vx, yx, `messaging/monitor/unsubscribe`, {
      subscriptionId: n2
    });
  }
  function Cx(e2) {
    if (!e2 || typeof e2 != `object`) return;
    let t2 = e2;
    if (t2.type !== `https://trusttasks.org/spec/messaging/monitor/event/0.1`) return;
    let n2 = t2.payload;
    if (n2 && typeof n2.subscriptionId == `string` && typeof n2.seq == `number` && Array.isArray(n2.events) && typeof n2.dropped == `number`) return n2;
  }
  var wx = class {
    last = 0;
    push(e2) {
      let t2 = [];
      return this.last > 0 && e2.seq > this.last + 1 && t2.push({
        kind: `gap`,
        missing: e2.seq - this.last - 1
      }), e2.seq > this.last && (this.last = e2.seq), e2.events.length === 0 && e2.dropped === 0 ? t2.push({
        kind: `heartbeat`
      }) : t2.push({
        kind: `events`,
        events: e2.events,
        dropped: e2.dropped
      }), t2;
    }
  };
  (async function() {
    try {
      if (!navigator.storage?.persist) {
        console.warn(`[pnm] StorageManager.persist unavailable \u2014 IndexedDB remains best-effort`);
        return;
      }
      if (await navigator.storage.persisted()) return;
      let e2 = await navigator.storage.persist();
      console.info(e2 ? `[pnm] persistent storage granted \u2014 IndexedDB holder records are now eviction-protected` : `[pnm] persistent storage request denied \u2014 IndexedDB holder records remain best-effort`);
    } catch (e2) {
      console.warn(`[pnm] persistent storage request failed:`, e2 instanceof Error ? e2.message : e2);
    }
  })(), chrome.runtime.onMessage.addListener((e2, t2, n2) => {
    let r2 = performance.now(), i2 = (t3) => {
      let i3 = rx(e2, t3, performance.now() - r2);
      i3 && console.warn(...i3), n2(t3);
    };
    if (t2.id !== chrome.runtime.id) return console.warn(`[offscreen] rejecting message from foreign sender id=${t2.id} url=${t2.url}`), i2({
      ok: false,
      error: `foreign sender rejected`
    }), false;
    let a2 = e2;
    if (a2?.target !== `offscreen`) return false;
    if (a2.type === `offscreen/didcomm-login`) return OC(e2).then(i2).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/sign-in-page-number`) {
      let t3 = e2;
      return Bx.pageNumber(t3.flowId, t3.matchNumber), false;
    }
    if (a2.type === `offscreen/sign-in-step`) {
      if (!iC(t2)) return i2({
        ok: false,
        error: `sign-in steps come from the wallet's own window`
      }), false;
      let n3 = e2;
      return Bx.step(n3).then((e3) => ({
        ok: true,
        result: e3
      })).then(i2).catch((e3) => i2({
        ok: false,
        error: e3 instanceof Error ? e3.message : String(e3)
      })), true;
    }
    if (a2.type === `offscreen/uv-settings`) return iC(t2) ? (Jx(e2).then(i2).catch((e3) => i2(Yx(e3))), true) : (i2({
      ok: false,
      error: `sign-in approval settings are the wallet's own`
    }), false);
    if (a2.type === `offscreen/rest-login`) return EC(e2).then(i2).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `pnm/offscreen-disclosure-step-up`) return kC(e2).then(i2).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/step-up-vta`) return AC(e2).then(i2).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/start-inbound`) {
      let t3 = e2;
      return oS = [
        ...t3.vtaDids ?? []
      ], yC(t3.vtaDids ?? []), false;
    }
    if (a2.type === `offscreen/get-status`) return i2({
      mediators: GS()
    }), false;
    if (a2.type === `offscreen/transport-health`) return kx().then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/run-diagnostics`) return Fx(e2.vtaDid).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/lock-wallet`) return Ct.lock(), hC(), false;
    if (a2.type === `offscreen/onboard-prepare`) {
      let t3 = e2;
      return vS(t3.vtaDid, t3.adminScope, t3.context, t3.personaHolder === true).then((e3) => i2({
        ok: true,
        result: e3
      })).catch((e3) => i2({
        ok: false,
        error: e3 instanceof Error ? e3.message : String(e3)
      })), true;
    }
    if (a2.type === `offscreen/onboard-contexts`) return SS().then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/onboard-connect`) {
      let t3 = e2;
      return xS({
        context: t3.context,
        adminScope: t3.adminScope,
        createIfMissing: t3.createIfMissing ?? false,
        ...t3.mediatorDid ? {
          mediatorDid: t3.mediatorDid
        } : {}
      }).then((e3) => i2({
        ok: true,
        result: e3
      })).catch((e3) => {
        let t4 = jm(e3);
        if (t4) {
          i2({
            ok: false,
            error: t4.message,
            code: t4.code,
            candidates: t4.candidates
          });
          return;
        }
        if (e3 instanceof yS) {
          i2({
            ok: false,
            error: e3.message,
            code: jt
          });
          return;
        }
        i2({
          ok: false,
          error: e3 instanceof Error ? e3.message : String(e3)
        });
      }), true;
    }
    if (a2.type === `offscreen/list-contexts`) return kS(e2).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/list-dids`) return AS(e2).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/set-wake`) return OS(e2).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/create-context`) return jS(e2).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/derive-signing-key-id`) return MS(e2.did).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/unlock-prf`) {
      let t3 = e2, n3;
      try {
        if (typeof t3.prfOutputB64u != `string` || t3.prfOutputB64u.length === 0) throw Error(`prfOutputB64u missing or empty`);
        n3 = Ke(t3.prfOutputB64u);
      } catch (e3) {
        return i2({
          ok: false,
          error: e3 instanceof Error ? e3.message : String(e3)
        }), false;
      }
      return wS(n3).then(() => i2({
        ok: true
      })).catch((e3) => i2({
        ok: false,
        error: e3 instanceof Error ? e3.message : String(e3)
      })), true;
    }
    if (a2.type === `offscreen/approver-state`) return uC(e2.vtaDid).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/unlock-approver`) {
      let t3 = e2, n3;
      try {
        if (typeof t3.prfOutputB64u != `string` || t3.prfOutputB64u.length === 0) throw Error(`prfOutputB64u missing or empty`);
        if (typeof t3.vtaDid != `string` || !t3.vtaDid) throw Error(`vtaDid missing`);
        n3 = Ke(t3.prfOutputB64u);
      } catch (e3) {
        return i2({
          ok: false,
          error: e3 instanceof Error ? e3.message : String(e3)
        }), false;
      }
      return dC(n3, t3.vtaDid).then((e3) => i2({
        ok: true,
        approverDid: e3.approverDid
      })).catch((e3) => i2({
        ok: false,
        error: e3 instanceof Error ? e3.message : String(e3)
      })), true;
    }
    if (a2.type === `offscreen/lock-state`) return TS(e2.vtaDid).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/forget-holder-record`) return ES(e2.vtaDid).then(() => i2({
      ok: true
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/refresh-vta-transports`) return DS(e2.vtaDid).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/holder-state`) return CS().then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/step-up-approver`) return gS(e2).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3),
      ...typeof e3?.code == `string` ? {
        code: e3.code
      } : {}
    })), true;
    if (a2.type === `offscreen/sign-trust-task`) {
      let t3 = e2;
      return hS(t3.vtaDid, t3.params, t3.restBaseUrl).then((e3) => i2({
        ok: true,
        result: e3
      })).catch((e3) => i2({
        ok: false,
        error: e3 instanceof Error ? e3.message : String(e3)
      })), true;
    }
    if (a2.type === `offscreen/verify-did`) return mS(e2.did).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true;
    if (a2.type === `offscreen/directory-page`) {
      if (!iC(t2)) return i2({
        ok: false,
        error: `directory work is asked for by the wallet`
      }), false;
      let n3 = e2;
      return qy({
        async agent(e3, t3) {
          let { session: n4, holder: r3, service: i3 } = await $(e3, t3);
          return {
            sender: n4,
            holder: r3,
            service: i3
          };
        },
        identities: (e3, t3) => zx(e3, t3)
      }, {
        vtaDid: n3.vtaDid,
        ...n3.restBaseUrl ? {
          restBaseUrl: n3.restBaseUrl
        } : {}
      }, n3.params).then((e3) => i2({
        ok: true,
        result: e3
      })).catch((e3) => i2({
        ok: false,
        error: e3 instanceof Error ? e3.message : String(e3)
      })), true;
    }
    if (a2.type === `offscreen/rooms-page`) {
      if (!iC(t2)) return i2({
        ok: false,
        error: `room work is asked for by the wallet`
      }), false;
      let n3 = e2;
      return zy({
        async agent(e3, t3) {
          let { session: n4 } = await $(e3, t3), { signing: r3 } = await Hg(e3);
          return {
            sender: n4,
            holderDid: r3.did
          };
        },
        identities: (e3, t3) => zx(e3, t3)
      }, {
        vtaDid: n3.vtaDid,
        ...n3.restBaseUrl ? {
          restBaseUrl: n3.restBaseUrl
        } : {}
      }, n3.params).then((e3) => i2({
        ok: true,
        result: e3
      })).catch((e3) => i2({
        ok: false,
        error: e3 instanceof Error ? e3.message : String(e3)
      })), true;
    }
    if (a2.type === `offscreen/room-offers`) {
      if (!iC(t2)) return i2({
        ok: false,
        error: `room offers are asked for by the wallet`
      }), false;
      let n3 = e2;
      return Yy({
        async agent(e3, t3) {
          let { session: n4 } = await $(e3, t3), { signing: r3 } = await Hg(e3);
          return {
            sender: n4,
            holderDid: r3.did
          };
        },
        identities: (e3, t3) => zx(e3, t3)
      }, {
        vtaDid: n3.vtaDid,
        ...n3.restBaseUrl ? {
          restBaseUrl: n3.restBaseUrl
        } : {}
      }, n3.params).then((e3) => i2({
        ok: true,
        result: e3
      })).catch((e3) => i2({
        ok: false,
        error: e3 instanceof Error ? e3.message : String(e3),
        ...e3 instanceof Jy && e3.code ? {
          code: e3.code
        } : {}
      })), true;
    }
    return a2.type === `offscreen/room-host-endpoint` ? iC(t2) ? (Py(e2.hostDid).then((e3) => i2({
      ok: true,
      endpoint: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3),
      ...h_(e3) ? {
        code: `noTrustTaskService`
      } : {}
    })), true) : (i2({
      ok: false,
      error: `room files are not page-reachable`
    }), false) : a2.type === `offscreen/mediator` ? iC(t2) ? (eC(e2.op).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2(XS(e3))), true) : (i2({
      ok: false,
      error: `mediator surface is not page-reachable`
    }), false) : a2.type === `offscreen/request-task` ? (Qx(e2).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2(tx(e3))), true) : a2.type === `offscreen/vault-list` ? (lS(e2).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true) : a2.type === `offscreen/vault-upsert` ? (uS(e2).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true) : a2.type === `offscreen/vault-delete` ? (dS(e2).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true) : a2.type === `offscreen/vault-release` ? (fS(e2).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true) : a2.type === `offscreen/vault-proxy-login` && (pS(e2).then((e3) => i2({
      ok: true,
      result: e3
    })).catch((e3) => i2({
      ok: false,
      error: e3 instanceof Error ? e3.message : String(e3)
    })), true);
  });
  var Tx = /* @__PURE__ */ new Map(), Ex = new Zg(), Dx = new Wl();
  function Ox(e2, t2, n2) {
    let r2 = Tx.get(e2) ?? {};
    Tx.set(e2, {
      ...r2,
      [t2]: n2
    });
  }
  async function kx() {
    let e2 = {}, t2 = Date.now();
    for (let [n3, r2] of Tx) e2[n3] = n_(r2, Ex.isAnySittingOut(n3, t2));
    let n2 = await HS();
    return {
      byVta: e2,
      sessions: GS().map((e3) => ({
        ...e3,
        isInbox: n2.get(e3.vtaDid) === e3.mediatorDid
      }))
    };
  }
  function Ax(e2, t2, n2, r2) {
    let i2 = r2 instanceof Error ? r2.message : String(r2);
    console.warn(`[pnm ${t2.toLowerCase()}] skipping ${t2} channel:`, i2), Ox(e2, t2, {
      state: `down`,
      detail: i2
    }), jx(e2, t2, n2, r2);
  }
  async function jx(e2, t2, n2, r2) {
    try {
      let i2 = mr(void 0, 5e3), a2;
      n2 && (a2 = await He(n2, {
        netPolicy: Fg()
      }).then((e3) => e3.authEndpoint).catch(() => void 0));
      let o2 = a2 ? await Gg(a2, i2) : `unprobed`, s2 = Kg(a2), c2 = Mx(), l2 = Wg({
        error: r2,
        reachable: o2,
        ...s2 ? {
          host: s2
        } : {},
        ...c2 ? {
          origin: c2
        } : {}
      });
      if (Tx.get(e2)?.[t2]?.state !== `down`) return;
      Ox(e2, t2, {
        state: `down`,
        code: l2.code,
        detail: l2.remediation ? `${l2.detail} ${l2.remediation}` : l2.detail
      }), console.warn(`[pnm ${t2.toLowerCase()}] ${l2.code}: ${l2.detail}`);
    } catch {
    }
  }
  function Mx() {
    try {
      return new URL(chrome.runtime.getURL(``)).origin;
    } catch {
      return;
    }
  }
  async function Nx(e2, t2) {
    try {
      return await t2(e2, {
        method: `GET`,
        cache: `no-store`
      }), {
        ok: true
      };
    } catch (e3) {
      return {
        ok: false,
        error: e3
      };
    }
  }
  async function Px(e2, t2, n2, r2) {
    let i2 = [], a2 = `mediator.${e2}`, o2;
    try {
      o2 = (await He(t2, {
        netPolicy: Fg()
      })).authEndpoint, i2.push({
        id: `${a2}.resolve`,
        label: `${e2} mediator DID resolves`,
        status: `pass`,
        detail: `${t2} \u2192 ${Kg(o2) ?? o2}`
      });
    } catch (t3) {
      return i2.push({
        id: `${a2}.resolve`,
        label: `${e2} mediator DID resolves`,
        status: `fail`,
        detail: t3 instanceof Error ? t3.message : String(t3),
        remediation: `The mediator's DID document must resolve and advertise a WebSocket endpoint.`
      }), i2;
    }
    let s2 = Kg(o2), c2 = await Nx(o2, n2);
    if (c2.ok) return i2.push({
      id: `${a2}.origin`,
      label: `${e2} mediator accepts this wallet's origin`,
      status: `pass`,
      detail: `${s2} answered a request carrying this extension's origin.`
    }), i2;
    let l2 = await Gg(o2, n2), u2 = Wg({
      error: c2.error,
      reachable: l2,
      ...s2 ? {
        host: s2
      } : {},
      ...r2 ? {
        origin: r2
      } : {}
    });
    return i2.push({
      id: `${a2}.origin`,
      label: `${e2} mediator accepts this wallet's origin`,
      status: `fail`,
      detail: u2.detail,
      code: u2.code,
      ...u2.remediation ? {
        remediation: u2.remediation
      } : {}
    }), i2;
  }
  async function Fx(e2) {
    let t2 = mr(void 0, 8e3), n2 = Mx(), r2 = [], i2;
    try {
      i2 = await Ae(e2);
      let t3 = [
        i2.tsp ? `TSP` : null,
        i2.didcomm ? `DIDComm` : null,
        i2.rest ? `REST` : null
      ].filter(Boolean);
      r2.push({
        id: `vta.resolve`,
        label: `Trust agent DID resolves`,
        status: `pass`,
        detail: `Advertises ${t3.join(`, `) || `no transport`}.`
      });
    } catch (t3) {
      return r2.push({
        id: `vta.resolve`,
        label: `Trust agent DID resolves`,
        status: `fail`,
        detail: t3 instanceof Error ? t3.message : String(t3)
      }), {
        vtaDid: e2,
        extensionOrigin: n2 ?? `unknown`,
        generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        checks: r2
      };
    }
    let a2 = /* @__PURE__ */ new Map();
    i2.tsp && a2.set(i2.tsp.mediatorDid, [
      `TSP`
    ]), i2.didcomm && a2.set(i2.didcomm.mediatorDid, [
      ...a2.get(i2.didcomm.mediatorDid) ?? [],
      `DIDComm`
    ]);
    for (let [e3, i3] of a2) r2.push(...await Px(i3.join(`+`), e3, t2, n2));
    a2.size === 0 && r2.push({
      id: `mediator.none`,
      label: `Mediator`,
      status: `skip`,
      detail: `This agent advertises no mediator \u2014 REST only, and nothing can be pushed to this wallet.`
    });
    let o2 = await VS(e2);
    if (o2 ? i2.didcomm && o2 !== i2.didcomm.mediatorDid ? (r2.push(...await Px(`inbox`, o2, t2, n2)), r2.push({
      id: `inbox.mismatch`,
      label: `This agent's inbox is not the relay it pushes through`,
      status: `warn`,
      detail: `This wallet listens for this agent at ${o2}, but the agent advertises ${i2.didcomm.mediatorDid}. Nothing tells it to use the first, so its messages are handed to the second and never picked up.`,
      remediation: `Clear the manual relay under Setup \u2192 Message routing so the wallet follows the agent, unless you know this relay reaches it.`
    })) : a2.has(o2) || r2.push(...await Px(`inbox`, o2, t2, n2)) : r2.push({
      id: `inbox.unset`,
      label: `This agent's inbox`,
      status: `fail`,
      detail: `No inbox relay is configured for this agent, so it cannot push to this wallet \u2014 its consent requests and approvals will never arrive.`,
      remediation: `Reconnect to this agent to adopt its relay automatically, or set one under Setup \u2192 Message routing. If the agent advertises no DIDComm mediator, it cannot push to a wallet at all and one must be configured by hand.`
    }), i2.rest) {
      let e3 = i2.rest.baseUrl, a3 = await Nx(e3, t2);
      if (a3.ok) r2.push({
        id: `vta.rest`,
        label: `Trust agent REST accepts this wallet's origin`,
        status: `pass`,
        detail: `${Kg(e3) ?? e3} answered a request carrying this extension's origin.`
      });
      else {
        let i3 = await Gg(e3, t2), o3 = Wg({
          error: a3.error,
          reachable: i3,
          ...Kg(e3) ? {
            host: Kg(e3)
          } : {},
          ...n2 ? {
            origin: n2
          } : {}
        });
        r2.push({
          id: `vta.rest`,
          label: `Trust agent REST accepts this wallet's origin`,
          status: `fail`,
          detail: o3.detail,
          code: o3.code,
          remediation: "vta-service applies an origin allowlist \u2014 add this origin to `[server] cors_origins` in its config.toml and restart. The wallet also needs a host permission for this origin, which Setup requests."
        });
      }
    }
    let s2 = GS().filter((t3) => t3.vtaDid === e2 && t3.state === `live`);
    return r2.push(s2.length > 0 ? {
      id: `inbox.session`,
      label: `Inbox session is live`,
      status: `pass`,
      detail: `${s2.length} mediator session(s) open for this agent.`
    } : {
      id: `inbox.session`,
      label: `Inbox session is live`,
      status: `warn`,
      detail: `No mediator session is open for this agent. Nothing pushed to this wallet will arrive \u2014 including approval requests \u2014 until one is.`
    }), r2.push(...await Lx(e2, i2)), {
      vtaDid: e2,
      extensionOrigin: n2 ?? `unknown`,
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      checks: r2
    };
  }
  var Ix = 12e3;
  async function Lx(e2, t2) {
    if (!t2) return [];
    let { preferTsp: n2 } = await Mt(), r2;
    try {
      let { identity: t3, signing: n3 } = await Hg(e2);
      r2 = {
        holder: t3,
        signing: n3
      };
    } catch (e3) {
      let n3 = `This wallet's identity for the agent could not be loaded: ${e3 instanceof Error ? e3.message : String(e3)}`;
      return [
        `TSP`,
        `DIDComm`,
        `REST`
      ].filter((e4) => e4 === `TSP` ? t2.tsp : e4 === `DIDComm` ? t2.didcomm : t2.rest).map((e4) => ax(e4, {
        kind: `skipped`,
        reason: n3
      }));
    }
    let i2 = [
      [
        `TSP`,
        t2.tsp ? {
          tsp: t2.tsp
        } : void 0,
        n2 ? void 0 : `Prefer TSP is off, so this wallet does not use it.`
      ],
      [
        `DIDComm`,
        t2.didcomm ? {
          didcomm: t2.didcomm
        } : void 0,
        void 0
      ],
      [
        `REST`,
        t2.rest ? {
          rest: t2.rest
        } : void 0,
        void 0
      ]
    ], a2 = [];
    for (let [t3, n3, o2] of i2) {
      if (!n3) continue;
      if (o2) {
        a2.push(ax(t3, {
          kind: `skipped`,
          reason: o2
        }));
        continue;
      }
      let i3;
      try {
        let { session: t4, holder: a3, service: o3 } = await Rx(e2, r2, (t5) => KS(t5, e2), {
          services: n3,
          probe: true
        });
        i3 = await ku(t4, {
          holder: a3,
          service: o3,
          timeoutMs: Ix
        });
      } catch (e3) {
        i3 = {
          kind: `failed`,
          ms: 0,
          message: e3 instanceof Error ? e3.message : String(e3)
        };
      }
      a2.push(ax(t3, i3));
    }
    return a2;
  }
  async function Rx(e2, t2, n2, r2 = {}) {
    let { holder: i2, signing: a2 } = t2, o2 = r2.restBaseUrl, s2 = await ze(e2), c2 = r2.services ?? await Ae(e2), l2 = [], u2 = o2 || c2.rest?.baseUrl, d2 = false, f2 = (t3, n3) => r2.probe || !u2 || !Ex.isSittingOut(e2, n3, Date.now()) ? false : (Ox(e2, t3, {
      state: `down`,
      code: Ug.noReply,
      detail: Qg(n3)
    }), d2 = true, true), { preferTsp: p2 } = await Mt();
    if (p2 && c2.tsp && !f2(`TSP`, c2.tsp.mediatorDid)) try {
      let t3 = await vu(e2), r3 = await n2(c2.tsp.mediatorDid);
      l2.push(new ru({
        transport: new cu({
          connection: r3
        }),
        holder: eu(i2.did, a2.privateKey),
        signing: a2,
        vta: t3,
        relationships: Dx
      })), Ox(e2, `TSP`, {
        state: `up`
      });
    } catch (t3) {
      Ax(e2, `TSP`, c2.tsp.mediatorDid, t3);
    }
    let m2;
    if (c2.didcomm && !f2(`DIDComm`, c2.didcomm.mediatorDid)) {
      let t3 = c2.didcomm.mediatorDid, r3 = await n2(t3).catch((n3) => {
        Ax(e2, `DIDComm`, t3, n3);
      });
      if (r3) {
        Ox(e2, `DIDComm`, {
          state: `up`
        }), m2 = r3;
        let t4 = new In(r3);
        l2.push(new Zr({
          bridge: t4,
          holder: i2,
          signing: a2,
          vta: s2,
          mediator: r3.mediator
        }));
      }
    }
    if (u2 && (l2.push(new Hr({
      baseUrl: u2,
      holder: i2,
      signing: a2,
      service: s2,
      netPolicy: Fg()
    })), Ox(e2, `REST`, {
      state: `unknown`
    })), l2.length === 0) throw Error(`${e2} advertises no usable transport (#tsp, #vta-didcomm or #vta-rest)`);
    if (d2 && (console.warn(`[pnm mediator] no reply recently from`, e2, `through its mediator; using REST`), Ex.claimNotification(e2, Date.now()))) {
      let { title: t3, message: n3 } = $g(e_(e2));
      iS(t3, n3);
    }
    return {
      session: new ri(r2.didcommFirst ? [
        ...l2.filter((e3) => e3.kind === `didcomm`),
        ...l2.filter((e3) => e3.kind !== `didcomm`)
      ] : l2),
      holder: i2,
      service: s2,
      ...m2 ? {
        didcommConn: m2
      } : {}
    };
  }
  async function zx(e2, t2) {
    let { session: n2, holder: r2, service: i2 } = await $(e2, t2);
    return Md(`vault/list (didSelfIssued)`, async (e3) => {
      let t3 = await Fd(n2, {
        holder: r2,
        service: i2,
        filter: {
          secretKind: `didSelfIssued`,
          ...e3 ? {
            cursor: e3
          } : {}
        }
      });
      return {
        items: t3.entries,
        ...t3.cursor ? {
          nextCursor: t3.cursor
        } : {}
      };
    });
  }
  var Bx = new hb({
    now: () => Date.now(),
    grantLifetimeMs: 432e5,
    myTerms: async () => (await Mt()).myTermsOffers,
    termsPreference: (e2, t2) => Se(e2, t2),
    recordTerms: (e2) => be(me(e2)),
    vta: (e2, n2) => ({
      listIdentities: () => zx(e2, n2),
      listPersonas: async () => {
        let { session: t2, holder: r2, service: i2 } = await $(e2, n2);
        return (await ei(t2, {
          holder: r2,
          service: i2
        })).map((e3) => ({
          did: e3.did,
          contextId: e3.contextId
        }));
      },
      bindIdentity: async ({ origin: t2, did: r2, rpDid: i2 }) => {
        let a2 = await Gb({
          listDids: async () => {
            let { session: t3, holder: r3, service: i3 } = await $(e2, n2);
            return ei(t3, {
              holder: r3,
              service: i3
            });
          },
          deriveSigningKeyIds: (e3) => Rt(e3),
          upsert: async (t3) => {
            let { session: r3, holder: i3, service: a3 } = await $(e2, n2);
            return {
              entryId: (await zd(r3, {
                holder: i3,
                service: a3,
                ...t3
              })).entry.id
            };
          }
        }, {
          origin: t2,
          did: r2,
          rpDid: i2
        });
        if (!a2.ok) throw Error(a2.error);
        return {
          entryId: a2.entryId,
          label: Ub(t2)
        };
      },
      signTask: async (t2, r2) => {
        let { session: i2, holder: a2, service: o2 } = await $(e2, n2), { signedEnvelope: s2 } = await f(i2, {
          holder: a2,
          service: o2,
          entryId: t2,
          unsignedEnvelope: r2
        });
        return s2;
      },
      renameIdentity: async (t2, r2) => {
        let i2 = (await zx(e2, n2)).find((e3) => e3.id === t2);
        if (!i2) throw Error(`the record is no longer in your wallet`);
        let { session: a2, holder: o2, service: s2 } = await $(e2, n2);
        await zd(a2, {
          holder: o2,
          service: s2,
          id: i2.id,
          expectedVersion: i2.version,
          contextId: i2.contextId,
          targets: i2.targets,
          label: r2,
          secretKind: i2.secretKind
        });
      },
      unbindIdentity: async (t2) => {
        let { session: r2, holder: i2, service: a2 } = await $(e2, n2);
        await Ud(r2, {
          holder: i2,
          service: a2,
          id: t2,
          reason: `join request not taken`
        });
      },
      ensureDevice: () => Gx(e2, n2),
      signIdentify: (t2, r2) => Zx(e2, n2, async () => {
        let { session: i2, holder: a2, service: o2 } = await $(e2, n2);
        return P(i2, {
          holder: a2,
          service: o2,
          entryId: t2,
          unsignedIdentify: r2
        });
      }),
      signGrant: (r2, i2, a2) => Zx(e2, n2, async () => {
        let { session: o2, holder: s2, service: c2 } = await $(e2, n2), l2 = async () => {
          if (a2) {
            if (`prfOutput` in a2) {
              let t2 = (await La(new Dt(), {
                vtaDid: e2,
                prfOutput: a2.prfOutput
              })).signing;
              return {
                decision: await E({
                  uvKey: t2,
                  vtaDid: c2.did,
                  payloadDigest: a2.payloadDigest
                })
              };
            }
            return `pin` in a2 ? Bb(Ux(), e2, n2, c2.did, a2.pin, a2.payloadDigest, a2.pinKey) : {
              remote: true
            };
          }
        }, u2 = async () => {
          let e3 = await l2();
          return t(o2, {
            holder: s2,
            service: c2,
            entryId: r2,
            unsignedGrant: i2,
            ...e3 ? {
              consent: e3
            } : {}
          });
        };
        try {
          return await u2();
        } catch (t2) {
          if (!a2 || !(`prfOutput` in a2) || h(t2) !== `oobNoUvKey`) throw t2;
          return await Kx(e2, n2, a2.prfOutput, true), u2();
        }
      }),
      enrolUvKey: (t2) => Kx(e2, n2, t2),
      uvMethod: async () => (await Fb(Ux(), e2, n2))?.kind,
      enrolUvMethod: async (t2) => {
        if (t2.kind === `vtaPin`) return (await Rb(Ux(), e2, n2, t2.pin)).key;
        await zb(Ux(), e2, n2, t2.approver);
      },
      uvApprovers: () => Vb(Ux(), e2, n2)
    })
  }), Vx = `pnm/device-enrolment/`;
  function Hx(e2) {
    return Vx + e2;
  }
  function Ux() {
    return {
      store: new Dt(),
      holder: async (e2) => {
        let { identity: t2, signing: n2 } = await Hg(e2);
        return {
          did: t2.did,
          signing: n2
        };
      },
      session: async (e2, t2) => {
        let { session: n2, holder: r2, service: i2 } = await $(e2, t2);
        return {
          sender: n2,
          holder: r2,
          service: i2
        };
      },
      displayName: () => Qb().displayName,
      enrolled: async (e2, t2, n2) => {
        await new Dt().put(Hx(e2), {
          holderDid: t2,
          at: n2
        });
      }
    };
  }
  var Wx = /* @__PURE__ */ new Map();
  async function Gx(e2, t2, n2 = false) {
    let r2 = Wx.get(e2);
    if (r2) {
      if (!n2) return r2;
      await r2.catch(() => void 0);
    }
    let i2 = (async () => {
      let r3 = new Dt(), i3 = Hx(e2);
      if (!n2) {
        let t3 = await r3.get(i3), { identity: n3 } = await Hg(e2);
        if (t3?.holderDid === n3.did) return;
      }
      let { session: a2, holder: o2, service: s2 } = await $(e2, t2), c2 = Qb(), l2 = await df(a2, {
        holder: o2,
        service: s2,
        consumerKind: {
          kind: `companion`,
          formFactor: `browser`
        },
        displayName: c2.displayName,
        ...c2.platform ? {
          platform: c2.platform
        } : {}
      });
      await r3.put(i3, {
        holderDid: o2.did,
        at: Date.now()
      }), l2 === `registered` && console.info(`[pnm device] registered with`, e2, `as`, c2.displayName);
    })().finally(() => Wx.delete(e2));
    return Wx.set(e2, i2), i2;
  }
  async function Kx(e2, t2, n2, r2 = false) {
    let i2 = new Dt(), { signing: a2 } = await La(i2, {
      vtaDid: e2,
      prfOutput: n2
    }), { identity: o2 } = await Hg(e2), s2 = await i2.get(Ob(e2));
    if (!r2 && s2?.kind === `prfSealedKey` && s2.holderDid === o2.did && s2.uvDid === a2.did) return;
    let { session: c2, holder: l2, service: u2 } = await $(e2, t2);
    await y(c2, {
      holder: l2,
      service: u2,
      enrolment: de(a2.did),
      displayName: Qb().displayName
    }), await Nb(Ux(), e2, l2.did, a2.did);
  }
  function qx(e2, t2) {
    return {
      vtaDid: e2,
      ...t2 ? {
        method: t2.kind
      } : {},
      ...t2?.approver ? {
        approver: t2.approver
      } : {}
    };
  }
  async function Jx(e2) {
    let t2 = Ux();
    if (e2.op === `status`) {
      let n3 = [];
      for (let r2 of e2.agents) {
        let e3 = await Fb(t2, r2.vtaDid, r2.restBaseUrl).catch(() => void 0);
        n3.push(qx(r2.vtaDid, e3));
      }
      return {
        ok: true,
        result: {
          op: `status`,
          agents: n3
        }
      };
    }
    let n2 = e2.agents.find((t3) => t3.vtaDid === e2.vtaDid);
    if (!n2) return {
      ok: false,
      error: `This wallet isn't connected to that agent.`
    };
    switch (e2.op) {
      case `approvers`:
        return {
          ok: true,
          result: {
            op: `approvers`,
            approvers: await Vb(t2, n2.vtaDid, n2.restBaseUrl)
          }
        };
      case `use-pin`: {
        let { record: r2, key: i2 } = await Rb(t2, n2.vtaDid, n2.restBaseUrl, e2.newPin, e2.currentPin);
        return i2.fill(0), {
          ok: true,
          result: {
            op: `use-pin`,
            agent: qx(n2.vtaDid, r2)
          }
        };
      }
      case `use-phone`: {
        let r2 = await zb(t2, n2.vtaDid, n2.restBaseUrl, e2.approver, e2.currentPin);
        return {
          ok: true,
          result: {
            op: `use-phone`,
            agent: qx(n2.vtaDid, r2)
          }
        };
      }
    }
  }
  function Yx(e2) {
    let t2 = fe(e2), n2 = e2 instanceof Error ? e2.message : String(e2);
    if (!t2) {
      let t3 = e2?.code;
      return {
        ok: false,
        error: n2,
        ...typeof t3 == `string` && t3.startsWith(`sign-in/`) ? {
          code: t3
        } : {}
      };
    }
    return {
      ok: false,
      error: n2,
      code: t2.code,
      ...t2.attemptsRemaining === void 0 ? {} : {
        attemptsRemaining: t2.attemptsRemaining
      },
      ...t2.lockedUntil === void 0 ? {} : {
        lockedUntil: t2.lockedUntil * 1e3
      }
    };
  }
  function Xx(e2, t2) {
    Gx(e2, t2).catch((t3) => console.warn(`[pnm device] could not register this browser with`, e2, t3));
  }
  async function Zx(e2, t2, n2) {
    try {
      return await n2();
    } catch (e3) {
      if (h(e3) !== `oobNotEnrolledDevice`) throw e3;
    }
    return await Gx(e2, t2, true), n2();
  }
  async function $(e2, t2) {
    let { identity: n2, signing: r2 } = await Hg(e2);
    return Rx(e2, {
      holder: n2,
      signing: r2
    }, (t3) => KS(t3, e2), {
      ...t2 ? {
        restBaseUrl: t2
      } : {}
    });
  }
  async function Qx(e2) {
    let { session: t2, holder: n2, service: r2, didcommConn: i2 } = await $(e2.vtaDid, e2.restBaseUrl), a2 = await Tu(t2, {
      type: e2.params.type,
      payload: e2.params.payload,
      holderDid: n2.did,
      vtaDid: e2.vtaDid,
      ...e2.origin ? {
        origin: e2.origin
      } : {}
    });
    return a2.kind === `consentRequired` && i2 && cS(e2.vtaDid, n2, r2, i2, a2).catch((e3) => console.error(`[pnm consent relay] failed:`, e3)), a2;
  }
  var $x = /* @__PURE__ */ new Set(), eS = 64, tS = /* @__PURE__ */ new Map();
  function nS(e2, t2) {
    if (tS.size >= eS) {
      let e3 = tS.keys().next();
      e3.done || tS.delete(e3.value);
    }
    tS.set(e2, t2);
  }
  function rS(e2) {
    iS(`Approval was not accepted`, e2);
  }
  function iS(e2, t2) {
    chrome.runtime.sendMessage({
      type: Ft,
      title: e2,
      message: t2
    }).catch((t3) => console.warn(`[pnm] could not raise a notification:`, e2, t3));
  }
  async function aS(e2, t2, n2) {
    let r2 = ad(t2), i2 = r2 ? tS.get(r2) : void 0, a2 = await id(t2, {
      senderDid: n2,
      expectedExecutorDid: i2?.executorDid ?? e2
    });
    if (!a2) return false;
    a2.thid && tS.delete(a2.thid);
    let o2 = i2 ? `${i2.decision} of ${i2.taskType} (digest ${i2.payloadDigest.slice(0, 12)}\u2026)` : `a decision this device sent (thid ${a2.thid ?? `unknown`})`;
    return a2.accepted ? (console.info(`[pnm inbound] task-consent decision accepted: ${a2.status} \u2014 ${o2}`, a2.approvals === void 0 ? `` : `approvals=${a2.approvals}${a2.needed === void 0 ? `` : `/${a2.needed}`}`), true) : (console.error(`[pnm inbound] task-consent decision REFUSED by the executor: ${o2} \u2014 code=${a2.code} retryable=${a2.retryable} ${a2.message ?? ``}`, a2.details ?? ``), rS(i2 ? `The VTA refused your approval (${a2.code}). The change has NOT been made.` : `The VTA refused an approval from this device (${a2.code}).`), true);
  }
  var oS = [];
  async function sS(e2) {
    let t2 = await Mt();
    return [
      .../* @__PURE__ */ new Set([
        ...e2 ? [
          e2
        ] : [],
        ...oS,
        ...t2.defaultStepUpVtaDid ? [
          t2.defaultStepUpVtaDid
        ] : [],
        ...t2.enrolledExecutorDids ?? []
      ])
    ];
  }
  async function cS(e2, t2, n2, r2, i2) {
    let a2 = new Dt(), o2 = await nt(a2, e2);
    if (!o2) return;
    let c2 = i2.consentRequests.find((e3) => e3?.recipient === o2);
    if (!c2 || $x.has(i2.payloadDigest)) return;
    let l2 = await sd({
      type: s,
      body: c2,
      id: c2.id
    }, {
      enrolledExecutorDids: await sS(e2),
      holderDid: o2
    });
    if (!l2.ok) {
      console.warn(`[pnm consent relay] consent request did not verify:`, l2.reason, l2.detail ?? ``);
      return;
    }
    $x.add(i2.payloadDigest);
    let u2 = chrome.runtime.connect({
      name: It
    });
    try {
      let i3 = await chrome.runtime.sendMessage({
        type: Lt,
        request: l2.parsed.request,
        approver: true
      });
      if (i3?.approved !== true) {
        console.info(`[pnm consent relay] approver declined; pending will lapse on its TTL`);
        return;
      }
      if (!i3.prfOutputB64u) {
        console.warn(`[pnm consent relay] approval carried no PRF output; not signing`);
        return;
      }
      let o3 = await ot(a2, {
        vtaDid: e2,
        secretWrap: new tt(Ke(i3.prfOutputB64u))
      });
      if (!o3) {
        console.warn(`[pnm consent relay] approver identity vanished before signing`);
        return;
      }
      let s2 = await ld({
        holder: t2,
        sender: o3.identity,
        signing: o3.signing,
        vta: n2,
        mediator: r2.mediator,
        decision: `approve`,
        challenge: l2.parsed.request.challenge,
        payloadDigest: l2.parsed.request.payloadDigest,
        thid: l2.parsed.thid
      });
      r2.send(s2.packed), nS(s2.id, {
        executorDid: e2,
        payloadDigest: l2.parsed.request.payloadDigest,
        decision: `approve`,
        taskType: l2.parsed.request.taskType,
        sentAt: Date.now()
      }), console.info(`[pnm consent relay] decision relayed over the worker session; awaiting the`, `executor's answer on thid`, s2.id);
    } finally {
      u2.disconnect(), $x.delete(i2.payloadDigest);
    }
  }
  async function lS(e2) {
    let { session: t2, holder: n2, service: r2 } = await $(e2.vtaDid, e2.restBaseUrl), i2 = await Fd(t2, {
      holder: n2,
      service: r2,
      ...e2.filter ? {
        filter: e2.filter
      } : {}
    });
    return {
      entries: i2.entries,
      truncated: i2.truncated
    };
  }
  async function uS(e2) {
    let { session: t2, holder: n2, service: r2 } = await $(e2.vtaDid, e2.restBaseUrl);
    return await zd(t2, {
      holder: n2,
      service: r2,
      ...e2.body
    });
  }
  async function dS(e2) {
    let { session: t2, holder: n2, service: r2 } = await $(e2.vtaDid, e2.restBaseUrl);
    return await Ud(t2, {
      holder: n2,
      service: r2,
      ...e2.body
    });
  }
  async function fS(e2) {
    let { session: t2, holder: n2, service: r2 } = await $(e2.vtaDid, e2.restBaseUrl);
    return await Kd(t2, {
      holder: n2,
      service: r2,
      ...e2.body
    });
  }
  async function pS(e2) {
    let { session: t2, holder: n2, service: r2 } = await $(e2.vtaDid, e2.restBaseUrl), i2 = await qd(t2, {
      holder: n2,
      service: r2,
      ...e2.body
    }), { cookies: a2, ...o2 } = i2.sessionBlob;
    return {
      ...i2,
      sessionBlob: o2
    };
  }
  async function mS(e2) {
    let t2 = await at(e2);
    return {
      did: t2.did,
      method: t2.method,
      resolved: t2.resolved,
      ...t2.domain ? {
        domain: t2.domain
      } : {},
      ...t2.alsoKnownAs ? {
        alsoKnownAs: t2.alsoKnownAs
      } : {},
      ...t2.error ? {
        error: t2.error
      } : {}
    };
  }
  async function hS(e2, t2, n2) {
    let r2 = t2.envelope, { signing: i2 } = await Hg(e2);
    if (cx(t2.asDid, i2.did)) {
      let a2 = await $(e2, n2), o2 = await Fd(a2.session, {
        holder: a2.holder,
        service: a2.service
      }), s2 = lx(t2.asDid, i2.did, o2.entries);
      if (s2.kind !== `vault`) throw new sx(`cannot sign as ${t2.asDid}`);
      {
        let { session: e3, holder: n3, service: i3 } = a2, o3 = r2.issuer;
        if (typeof o3 == `string` && o3 !== t2.asDid) throw Error(`signTrustTask: envelope.issuer (${o3}) does not match asDid (${t2.asDid}); set envelope.issuer = asDid before calling`);
        let c2 = {
          ...r2,
          issuer: t2.asDid
        }, { signedEnvelope: l2 } = await f(e3, {
          holder: n3,
          service: i3,
          entryId: s2.entryId,
          unsignedEnvelope: c2
        });
        return {
          signedEnvelope: l2,
          holderDid: t2.asDid
        };
      }
    }
    return {
      signedEnvelope: await u({
        envelope: {
          ...r2
        },
        signing: i2,
        proofPurpose: C(String(r2.type))
      }),
      holderDid: i2.did
    };
  }
  async function gS(e2) {
    let t2 = new Dt(), n2 = (e3) => {
      if (typeof e3 != `string` || e3.length === 0) throw Error(`prfOutputB64u missing or empty`);
      return new tt(Ke(e3));
    };
    switch (e2.op) {
      case `identity`:
        return {
          approverDid: await ka(t2, e2.audience, {
            ...e2.prfOutputB64u ? {
              secretWrap: n2(e2.prfOutputB64u)
            } : {}
          })
        };
      case `check-step-up`: {
        let n3 = e2.params, r2 = await Oa(t2, n3?.audience);
        if (!r2) throw Object.assign(Error(`this wallet has no step-up approver for ${String(n3?.audience)}; enrol one first`), {
          code: `step-up-approver/not-offered`
        });
        return {
          approverDid: r2,
          boundTo: (await ua({
            request: n3.request,
            operation: n3.operation,
            audience: n3.audience,
            approverDid: r2
          })).boundTo
        };
      }
      case `sign-step-up`: {
        let r2 = e2.params;
        return ja(t2, {
          request: r2.request,
          operation: r2.operation,
          audience: r2.audience,
          secretWrap: n2(e2.prfOutputB64u)
        });
      }
      case `sign-enrol`: {
        let r2 = e2.params;
        if (r2.purpose !== `enrol`) throw Error(`only an enrolment statement is signed here`);
        return Na(t2, {
          subject: r2.subject,
          audience: r2.audience,
          challenge: r2.challenge,
          boundTo: r2.boundTo,
          secretWrap: n2(e2.prfOutputB64u)
        });
      }
      case `check-decision`: {
        let n3 = e2.params, r2 = await Oa(t2, n3?.audience);
        if (!r2) throw Object.assign(Error(`this wallet has no step-up approver for ${String(n3?.audience)}; enrol one first`), {
          code: `step-up-approver/not-enrolled`
        });
        return {
          approverDid: r2,
          boundTo: (await fa({
            subject: n3.subject,
            action: n3.action,
            decision: n3.decision,
            audience: n3.audience,
            approverDid: r2
          })).boundTo
        };
      }
      case `sign-decision`: {
        let r2 = e2.params;
        return Ma(t2, {
          subject: r2.subject,
          action: r2.action,
          decision: r2.decision,
          audience: r2.audience,
          secretWrap: n2(e2.prfOutputB64u)
        });
      }
      default:
        throw Error(`unknown step-up approver operation`);
    }
  }
  var _S = `onboard:pending`;
  async function vS(e2, t2, n2, r2) {
    let i2 = await Ae(e2);
    if (!i2.didcomm && !i2.rest) throw Error(`${e2} advertises no #vta-didcomm or #vta-rest service`);
    let a2 = ai(), o2 = new Dt(), s2 = {
      ephemeralSecret: a2.privateKey,
      vtaDid: e2,
      ...i2.didcomm ? {
        mediatorDid: i2.didcomm.mediatorDid
      } : {},
      ...i2.rest ? {
        restBaseUrl: i2.rest.baseUrl
      } : {}
    };
    return await o2.put(_S, s2), {
      ephemeralDid: a2.did,
      command: lt({
        ephemeralDid: a2.did,
        adminScope: t2,
        ...n2 ? {
          context: n2
        } : {},
        personaHolder: r2
      }),
      ...i2.didcomm ? {
        mediatorDid: i2.didcomm.mediatorDid
      } : {},
      ...i2.rest ? {
        restBaseUrl: i2.rest.baseUrl
      } : {}
    };
  }
  var yS = class extends Error {
    vtaDid;
    code = jt;
    constructor(e2) {
      super(`${e2} publishes no mediator, and onboarding needs one to route through. Supply a mediator DID and try again.`), this.vtaDid = e2, this.name = `MediatorRequiredError`;
    }
  };
  function bS(e2) {
    chrome.runtime.sendMessage({
      type: kt,
      stage: e2
    }).catch(() => {
    });
  }
  async function xS(e2) {
    let t2 = new Dt(), n2 = await t2.get(_S);
    if (!n2) throw Error(`no pending onboarding \u2014 prepare first`);
    let r2 = n2.mediatorDid ?? e2.mediatorDid, i2 = await Ae(n2.vtaDid).catch(() => ({}));
    if (!r2 && !i2.rest && !i2.didcomm && !i2.tsp) throw new yS(n2.vtaDid);
    let a2 = oi(new Uint8Array(n2.ephemeralSecret)), o2 = ci(a2), s2 = Ue.fromSecretJwk({
      did: a2.did,
      kid: o2.keyAgreementKid,
      jwk: o2.secretJwk
    });
    bS(`resolving-agent`), bS(`connecting-mediator`);
    let c2 = /* @__PURE__ */ new Map(), l2 = (e3) => {
      let t3 = c2.get(e3);
      return t3 || (t3 = Re({
        holder: s2,
        mediatorDid: e3,
        vtaDid: n2.vtaDid,
        netPolicy: Fg()
      }), c2.set(e3, t3)), t3;
    }, u2 = {
      ...i2,
      ...i2.didcomm || !r2 ? {} : {
        didcomm: {
          mediatorDid: r2
        }
      }
    }, d2;
    try {
      bS(`provisioning`);
      let { session: t3 } = await Rx(n2.vtaDid, {
        holder: s2,
        signing: a2
      }, l2, {
        didcommFirst: true,
        services: u2
      });
      d2 = await Nm({
        sender: t3,
        ephemeralSigning: a2,
        vtaDid: n2.vtaDid,
        context: e2.context,
        adminScope: e2.adminScope,
        ...e2.createIfMissing ? {
          createContext: true
        } : {},
        note: `browser-plugin onboarding`
      });
    } finally {
      for (let e3 of c2.values()) await e3.then((e4) => e4.close()).catch(() => {
      });
    }
    bS(`installing-identity`);
    let f2 = Lm(d2);
    await Tt(t2, f2);
    let p2 = u2.didcomm?.mediatorDid;
    if (p2) {
      let e3 = i2.didcomm ? `agent` : `operator`;
      await St(n2.vtaDid, {
        did: p2,
        source: e3
      }), console.info(`[pnm onboard] inbox for`, n2.vtaDid, `=`, p2, `(${e3})`);
    }
    return await t2.delete(_S), Xx(n2.vtaDid, n2.restBaseUrl), {
      holderDid: d2.adminDid,
      role: `admin`,
      context: d2.context,
      adminScope: d2.adminScope,
      secretEncrypted: false
    };
  }
  async function SS() {
    let e2 = await new Dt().get(_S);
    if (!e2) throw Error(`no pending onboarding \u2014 prepare first`);
    let t2 = oi(new Uint8Array(e2.ephemeralSecret)), n2 = ci(t2), r2 = Ue.fromSecretJwk({
      did: t2.did,
      kid: n2.keyAgreementKid,
      jwk: n2.secretJwk
    }), i2 = await Ae(e2.vtaDid).catch(() => ({})), a2 = {
      ...i2,
      ...i2.didcomm || !e2.mediatorDid ? {} : {
        didcomm: {
          mediatorDid: e2.mediatorDid
        }
      }
    }, o2 = /* @__PURE__ */ new Map(), s2 = (t3) => {
      let n3 = o2.get(t3);
      return n3 || (n3 = Re({
        holder: r2,
        mediatorDid: t3,
        vtaDid: e2.vtaDid,
        netPolicy: Fg()
      }), o2.set(t3, n3)), n3;
    };
    try {
      let { session: n3 } = await Rx(e2.vtaDid, {
        holder: r2,
        signing: t2
      }, s2, {
        didcommFirst: true,
        services: a2
      });
      return {
        contexts: (await qr(n3, {
          holder: {
            did: t2.did
          },
          service: {
            did: e2.vtaDid
          }
        })).map((e3) => ({
          id: e3.id,
          name: e3.name
        }))
      };
    } finally {
      for (let e3 of o2.values()) await e3.then((e4) => e4.close()).catch(() => {
      });
    }
  }
  async function CS() {
    return yt(new Dt());
  }
  async function wS(e2) {
    if (!(e2 instanceof Uint8Array) || e2.length === 0) throw Error(`UNLOCK_PRF: prfOutput missing or not bytes`);
    await Ct.seedCachedKeyFromPrfOutput(e2);
  }
  async function TS(e2) {
    let t2 = await yt(new Dt(), e2);
    return t2.kind === `v4` ? t2.wrapAlgorithm === `passthrough` ? {
      encrypted: false,
      unlocked: true
    } : {
      encrypted: true,
      unlocked: Ct.isUnlocked()
    } : {
      encrypted: false,
      unlocked: false
    };
  }
  async function ES(e2) {
    await Et(new Dt(), e2);
  }
  async function DS(e2) {
    let t2 = await Ae(e2);
    return {
      ...t2.rest ? {
        restBaseUrl: t2.rest.baseUrl
      } : {},
      ...t2.didcomm ? {
        mediatorDid: t2.didcomm.mediatorDid
      } : {},
      ...t2.tsp ? {
        tspMediatorDid: t2.tsp.mediatorDid
      } : {}
    };
  }
  async function OS(e2) {
    let { session: t2, holder: n2, service: r2 } = await $(e2.vtaDid, e2.restBaseUrl);
    return mf(t2, {
      holder: n2,
      service: r2,
      ...e2.wakeHandle ? {
        wakeHandle: e2.wakeHandle
      } : {},
      ...e2.pushPlatform ? {
        pushPlatform: e2.pushPlatform
      } : {},
      ...e2.suggestedTriggers ? {
        suggestedTriggers: e2.suggestedTriggers
      } : {}
    });
  }
  async function kS(e2) {
    let { session: t2, holder: n2, service: r2 } = await $(e2.vtaDid, e2.restBaseUrl);
    return {
      contexts: (await qr(t2, {
        holder: n2,
        service: r2
      })).map((e3) => ({
        id: e3.id,
        name: e3.name
      }))
    };
  }
  async function AS(e2) {
    let { session: t2, holder: n2, service: r2 } = await $(e2.vtaDid, e2.restBaseUrl);
    return {
      dids: (await ei(t2, {
        holder: n2,
        service: r2,
        ...e2.contextId ? {
          contextId: e2.contextId
        } : {}
      })).map((e3) => ({
        did: e3.did,
        contextId: e3.contextId
      }))
    };
  }
  async function jS(e2) {
    let { session: t2, holder: n2, service: r2 } = await $(e2.vtaDid, e2.restBaseUrl), i2 = await Jr(t2, {
      holder: n2,
      service: r2,
      id: e2.id,
      ...e2.name ? {
        name: e2.name
      } : {},
      ...e2.description ? {
        description: e2.description
      } : {}
    });
    return {
      id: i2.id,
      name: i2.name
    };
  }
  async function MS(e2) {
    return Rt(e2);
  }
  var NS = `|`;
  function PS(e2, t2) {
    return e2 + NS + t2;
  }
  function FS(e2) {
    let t2 = e2.indexOf(NS);
    return {
      mediatorDid: e2.slice(0, t2),
      vtaDid: e2.slice(t2 + 1)
    };
  }
  var IS = /* @__PURE__ */ new Map(), LS = /* @__PURE__ */ new Map(), RS = 2e3, zS = 6e4, BS = /* @__PURE__ */ new Map();
  async function VS(e2) {
    return xt(await Mt(), e2)?.did;
  }
  async function HS() {
    let e2 = await Mt();
    return new Map(Object.entries(e2.inboxes ?? {}).map(([e3, t2]) => [
      e3,
      t2.did
    ]));
  }
  var US = class extends Error {
    vtaDid;
    code = Nt;
    constructor(e2) {
      super(`no inbox relay is configured for ${e2}, so that agent cannot push to this wallet. Onboarding sets one from the agent; re-connect to it, or set one under Setup \u2192 Message routing.`), this.vtaDid = e2, this.name = `NoInboxMediatorError`;
    }
  };
  async function WS(e2) {
    let t2 = await VS(e2);
    if (!t2) throw new US(e2);
    return t2;
  }
  function GS() {
    return [
      ...LS.entries()
    ].map(([e2, t2]) => {
      let { mediatorDid: n2, vtaDid: r2 } = FS(e2);
      return {
        mediatorDid: n2,
        vtaDid: r2,
        state: t2
      };
    });
  }
  async function KS(e2, t2) {
    let n2 = PS(e2, t2), r2 = IS.get(n2);
    if (r2) {
      let e3 = await r2.catch(() => null);
      if (e3 && Lg(e3, Date.now())) return e3;
      IS.get(n2) === r2 && IS.delete(n2), e3 && zg(e3);
    }
    LS.set(n2, `connecting`);
    let i2 = JS(e2, t2).then((e3) => (LS.set(n2, `live`), e3), (e3) => {
      throw LS.set(n2, `closed`), IS.delete(n2), e3;
    });
    return IS.set(n2, i2), i2;
  }
  async function qS(e2, t2, n2) {
    let r2 = IS.get(e2);
    if (!r2 || await r2.catch(() => null) !== t2 || IS.get(e2) !== r2) return;
    IS.delete(e2), LS.set(e2, `closed`), t2.close();
    let { mediatorDid: i2, vtaDid: a2 } = FS(e2);
    console.info(`[pnm mediator] dropped session for`, a2, `at`, i2, `\u2014`, n2), i2 === await VS(a2) && _C(a2);
  }
  Rg({
    onWake: (e2) => {
      console.info(`[pnm mediator] woke after ${Math.round(e2 / 1e3)}s; reconnecting sessions`);
      for (let [e3, t2] of IS) t2.then((t3) => qS(e3, t3, `machine slept`), () => void 0);
    }
  });
  async function JS(e2, t2) {
    let { identity: n2, signing: r2 } = await Hg(t2), i2 = e2 === await VS(t2), a2 = PS(e2, t2), o2, s2 = await Re({
      holder: n2,
      mediatorDid: e2,
      netPolicy: Fg(),
      vtaDid: n2.did,
      onClose: () => {
        let e3 = IS.get(a2);
        Bg(e3, () => o2).then((n3) => {
          n3 || (IS.get(a2) === e3 && IS.delete(a2), LS.set(a2, `closed`), i2 && _C(t2));
        });
      },
      onReplyTimeout: () => {
        Ex.noteNoReply(t2, e2, Date.now()), o2 && qS(a2, o2, `reply timeout`);
      }
    });
    return o2 = s2, i2 && (s2.onInbound((e3, i3, a3) => SC(s2, n2, r2, t2, e3, a3.did)), s2.onInboundTsp((e3) => xC(s2, n2, r2, t2, e3, false))), s2;
  }
  var YS = class extends Error {
    code;
    constructor(e2, t2) {
      super(t2), this.code = e2, this.name = `MediatorLensError`;
    }
  };
  function XS(e2) {
    return e2 instanceof YS ? {
      ok: false,
      error: e2.message,
      code: e2.code
    } : tx(e2);
  }
  function ZS() {
    return GS().map(({ mediatorDid: e2, vtaDid: t2 }) => ({
      mediatorDid: e2,
      vtaDid: t2
    }));
  }
  async function QS(e2, t2) {
    let n2 = await Mt(), r2 = fx({
      mediatorDid: e2,
      vtaDid: t2
    }, {
      inboxes: n2.inboxes ?? {},
      pooled: ZS()
    });
    if (!r2.ok) throw new YS(r2.code, r2.reason);
    let i2 = await KS(e2, t2), { identity: a2, signing: o2 } = await Hg(t2);
    return {
      conn: i2,
      channel: new Zr({
        bridge: new In(i2),
        holder: a2,
        signing: o2,
        vta: i2.mediator,
        timeoutMs: 2e4,
        replyProofPurpose: `any`
      }),
      caller: {
        holder: {
          did: a2.did
        },
        mediator: {
          did: i2.mediator.did
        }
      },
      isInbox: r2.isInbox
    };
  }
  async function $S(e2) {
    try {
      let { restEndpoint: t2 } = await He(e2, {
        netPolicy: Fg()
      }), n2 = `${t2.replace(/\/+$/, ``)}/readyz`, r2 = await (await mr(void 0, 5e3)(n2, {
        redirect: `error`
      })).json().catch(() => ({}));
      return typeof r2.version == `string` && r2.version ? {
        version: r2.version
      } : {
        versionError: `${Kg(n2) ?? n2} answered readyz without a version`
      };
    } catch (e3) {
      return e3 instanceof TypeError ? {
        versionError: `the mediator's /readyz does not answer a browser (it sends no CORS headers), so its release cannot be read from here`
      } : {
        versionError: e3 instanceof Error ? e3.message : String(e3)
      };
    }
  }
  async function eC(e2) {
    switch (e2.kind) {
      case `task`: {
        if (!hx(e2.params.type)) throw new YS(`mediator/task-not-offered`, `${e2.params.type} is not something the lens runs.`);
        let { channel: t2, caller: n2 } = await QS(e2.mediatorDid, e2.vtaDid), r2 = R(e2.params.type, e2.params.payload, {
          issuer: n2.holder.did,
          recipient: n2.mediator.did
        });
        return {
          kind: `accepted`,
          result: await t2.send(r2, {
            expectedResponseType: `${e2.params.type}#response`
          })
        };
      }
      case `probe`: {
        let { caller: t2, isInbox: n2 } = await QS(e2.mediatorDid, e2.vtaDid);
        return {
          mediatorDid: e2.mediatorDid,
          vtaDid: e2.vtaDid,
          holderDid: t2.holder.did,
          isInbox: n2,
          ...await $S(e2.mediatorDid)
        };
      }
      case `locate`: {
        let t2 = await Ae(e2.did), n2 = t2.didcomm?.mediatorDid ?? t2.tsp?.mediatorDid;
        return {
          did: e2.did,
          ...n2 ? {
            mediatorDid: n2
          } : {}
        };
      }
      case `relays`: {
        let e3 = await Mt(), t2 = new Map(GS().map((e4) => [
          `${e4.mediatorDid}|${e4.vtaDid}`,
          e4.state
        ]));
        return px({
          inboxes: e3.inboxes ?? {},
          pooled: ZS()
        }, (e4) => t2.get(`${e4.mediatorDid}|${e4.vtaDid}`));
      }
    }
  }
  Fy({
    async agent(e2, t2) {
      let { session: n2 } = await $(e2, t2), { signing: r2 } = await Hg(e2);
      return {
        sender: n2,
        signing: r2
      };
    },
    fromExtensionPage: rC
  });
  var tC = 60, nC = 2e4;
  function rC(e2) {
    return iC(e2.sender ?? {});
  }
  function iC(e2) {
    let t2 = chrome.runtime.getURL(``);
    return typeof e2.url == `string` && e2.url.startsWith(t2);
  }
  chrome.runtime.onConnect.addListener((e2) => {
    if (e2.name !== `vta-wallet/mediator-monitor`) return;
    if (!rC(e2)) {
      console.warn(`[mediator lens] refusing monitor port from ${e2.sender?.url}`), e2.disconnect();
      return;
    }
    let t2 = {
      closed: false,
      onClose: []
    };
    e2.onDisconnect.addListener(() => {
      t2.closed = true;
      for (let e3 of t2.onClose.splice(0)) e3();
    });
    let n2 = (r2) => {
      e2.onMessage.removeListener(n2);
      let i2 = r2;
      if (i2?.kind !== `open`) {
        e2.disconnect();
        return;
      }
      aC(e2, i2, t2);
    };
    e2.onMessage.addListener(n2);
  });
  async function aC(e2, t2, n2) {
    let r2 = !n2.closed, i2;
    n2.onClose.push(() => {
      r2 = false, i2?.(`the console closed the feed`);
    });
    let a2 = (t3) => {
      if (r2) try {
        e2.postMessage(t3);
      } catch {
        r2 = false, i2?.(`the console is no longer listening`);
      }
    }, o2;
    try {
      o2 = await QS(t2.mediatorDid, t2.vtaDid);
    } catch (t3) {
      let n3 = XS(t3);
      a2({
        kind: `ended`,
        reason: n3.ok ? `` : n3.error,
        ...!n3.ok && n3.code ? {
          code: n3.code
        } : {}
      }), e2.disconnect();
      return;
    }
    let { conn: s2, channel: c2, caller: l2 } = o2, u2 = l2.mediator.did, d2 = new wx(), f2, p2 = [], m2 = false, h2, g2 = Promise.resolve(), _2 = (e3) => {
      g2 = g2.then(async () => {
        let t3 = Cx(e3);
        if (t3 && t3.subscriptionId === f2 && !m2) {
          try {
            await ee(e3, u2, {
              proofPurpose: `any`
            });
          } catch (e4) {
            console.warn(`[mediator lens] dropped a monitor batch that did not verify:`, e4);
            return;
          }
          for (let e4 of d2.push(t3)) a2({
            kind: `update`,
            update: e4
          });
        }
      });
    }, v2 = s2.onMediatorFrame((e3) => {
      if (e3.type !== `https://trusttasks.org/binding/didcomm/0.1/envelope` || e3.from !== u2) return;
      let t3 = e3.body;
      t3 && Cx(t3) && (f2 === void 0 ? p2.push(t3) : _2(t3));
    }), y2 = (t3, n3) => {
      m2 || (m2 = true, h2 && clearTimeout(h2), v2(), a2({
        kind: `ended`,
        reason: t3,
        ...n3 ? {
          code: n3
        } : {}
      }), f2 && s2.isOpen && Sx(c2, l2, f2).catch(() => void 0), r2 && (r2 = false, e2.disconnect()));
    };
    if (i2 = y2, !r2) {
      y2(`the console closed the feed`);
      return;
    }
    let b2 = (e3) => {
      if (m2) return;
      let t3 = Date.parse(e3), n3 = Number.isFinite(t3) ? Math.max(5e3, t3 - Date.now() - nC) : tC * 1e3 / 2;
      h2 = setTimeout(() => void x2(), n3);
    }, x2 = async () => {
      if (!m2 && f2) {
        if (!s2.isOpen) return y2(`the session with the mediator dropped`);
        try {
          let e3 = await xx(c2, l2, {
            subscriptionId: f2,
            leaseSeconds: tC
          });
          b2(e3.expiresAt);
        } catch (e3) {
          let t3 = XS(e3);
          y2(`the lease could not be renewed: ${t3.ok ? `` : t3.error}`, t3.ok ? void 0 : t3.code);
        }
      }
    };
    try {
      let e3 = await xx(c2, l2, {
        ...t2.filter ? {
          filter: t2.filter
        } : {},
        leaseSeconds: tC
      });
      if (f2 = e3.subscriptionId, m2) {
        Sx(c2, l2, e3.subscriptionId).catch(() => void 0);
        return;
      }
      a2({
        kind: `granted`,
        subscriptionId: e3.subscriptionId,
        filter: e3.filter,
        expiresAt: e3.expiresAt
      });
      for (let e4 of p2.splice(0)) _2(e4);
      b2(e3.expiresAt);
    } catch (e3) {
      let t3 = XS(e3);
      y2(t3.ok ? `subscription refused` : t3.error, t3.ok ? void 0 : t3.code);
    }
  }
  var oC = /* @__PURE__ */ new Map(), sC = /* @__PURE__ */ new Map(), cC = new bd({
    baseMs: RS,
    maxMs: zS,
    attempt: (e2) => mC(e2),
    shouldRetry: (e2) => oC.has(e2)
  });
  function lC(e2, t2) {
    return `approver:${PS(e2, t2)}`;
  }
  async function uC(e2) {
    let t2 = await nt(new Dt(), e2);
    if (!t2) return {
      minted: false,
      running: false
    };
    let n2 = await VS(e2);
    if (!n2) return {
      minted: true,
      running: false,
      approverDid: t2
    };
    let r2 = sC.get(lC(n2, e2)), i2 = r2 ? await r2.catch(() => null) : null;
    return {
      minted: true,
      running: oC.has(e2) && !!i2?.isOpen,
      approverDid: t2
    };
  }
  async function dC(e2, t2) {
    let n2 = await ot(new Dt(), {
      vtaDid: t2,
      secretWrap: new tt(e2)
    });
    if (!n2) throw Error(`no approver identity minted for ${t2}`);
    return oC.set(t2, n2), cC.clear(t2), await fC(t2), {
      approverDid: n2.did
    };
  }
  async function fC(e2) {
    let t2 = lC(await WS(e2), e2), n2 = sC.get(t2);
    if (n2) {
      let e3 = await n2.catch(() => null);
      if (e3 && e3.isOpen) return e3;
      sC.delete(t2);
    }
    let r2 = pC(e2).catch((e3) => {
      throw sC.delete(t2), e3;
    });
    return sC.set(t2, r2), r2;
  }
  async function pC(e2) {
    let t2 = oC.get(e2);
    if (!t2) throw Error(`approver for ${e2} is locked`);
    let n2 = await WS(e2), r2 = lC(n2, e2), i2, a2 = await Re({
      holder: t2.identity,
      mediatorDid: n2,
      netPolicy: Fg(),
      vtaDid: t2.identity.did,
      onClose: () => {
        let t3 = sC.get(r2);
        Bg(t3, () => i2).then((n3) => {
          n3 || (sC.get(r2) === t3 && sC.delete(r2), oC.has(e2) && cC.schedule(e2));
        });
      }
    });
    return i2 = a2, a2.onInboundTsp((n3) => xC(a2, t2.identity, t2.signing, e2, n3, true)), a2.onInbound((n3, r3, i3) => SC(a2, t2.identity, t2.signing, e2, n3, i3.did, true)), console.info(`[pnm approver] inbox listening as`, t2.did), a2;
  }
  async function mC(e2) {
    if (!oC.has(e2)) return false;
    try {
      return await fC(e2), true;
    } catch (t2) {
      return console.warn(`[pnm approver] inbox connect failed for`, e2, t2), false;
    }
  }
  function hC() {
    oC.clear(), cC.clearAll();
    for (let [e2, t2] of sC) t2.then((e3) => e3.close?.()).catch(() => void 0), sC.delete(e2);
  }
  async function gC(e2) {
    try {
      let t2 = await WS(e2);
      return await KS(t2, e2), console.info(`[pnm inbound] listening for confirm requests via`, t2, `as`, e2), Xx(e2), true;
    } catch (e3) {
      return console.error(`[pnm inbound] failed to start inbound session:`, e3), false;
    }
  }
  function _C(e2) {
    let t2 = BS.get(e2) ?? {
      delayMs: RS,
      timer: void 0
    };
    t2.timer || (t2.timer = setTimeout(() => {
      t2.timer = void 0, gC(e2).then((n2) => {
        if (n2) {
          vC(e2);
          return;
        }
        BS.get(e2) === t2 && (t2.delayMs = Math.min(t2.delayMs * 2, zS), _C(e2));
      });
    }, t2.delayMs), BS.set(e2, t2));
  }
  function vC(e2) {
    let t2 = BS.get(e2);
    t2?.timer && clearTimeout(t2.timer), BS.delete(e2);
  }
  async function yC(e2) {
    let t2 = await HS(), n2 = new Set(e2), r2 = [];
    await Promise.all(e2.map(async (e3) => {
      if (!t2.has(e3)) {
        r2.push(e3);
        return;
      }
      await gC(e3) ? vC(e3) : _C(e3);
    })), r2.length > 0 && console.warn(`[pnm inbound] no inbox relay configured for`, r2.join(`, `), `\u2014 those agents cannot reach this wallet.`), bC(e2);
    for (let [e3, r3] of IS) {
      let i2 = FS(e3);
      t2.get(i2.vtaDid) === i2.mediatorDid && (n2.has(i2.vtaDid) || (vC(i2.vtaDid), IS.delete(e3), LS.set(e3, `closed`), r3.then((e4) => e4.close(), () => void 0), gt(i2.vtaDid), console.info(`[pnm inbound] closed listener for forgotten VTA`, i2.vtaDid)));
    }
  }
  async function bC(e2) {
    let t2 = await wd(new Dt()).catch((e3) => (console.warn(`[pnm inbound] could not read pending inbound`, e3), []));
    if (t2.length === 0) return;
    let n2 = new Set(e2);
    for (let e3 of t2) if (n2.has(e3.vtaDid)) try {
      if (e3.isApprover) {
        let t3 = oC.get(e3.vtaDid);
        if (!t3) continue;
        let n3 = await fC(e3.vtaDid);
        console.info(`[pnm inbound] re-driving interrupted approver message`, e3.id), await CC(n3, t3.identity, t3.signing, e3.vtaDid, e3.message, e3.senderDid, true, true);
      } else {
        let t3 = await KS(await WS(e3.vtaDid), e3.vtaDid), { identity: n3, signing: r2 } = await Hg(e3.vtaDid);
        console.info(`[pnm inbound] re-driving interrupted message`, e3.id), await CC(t3, n3, r2, e3.vtaDid, e3.message, e3.senderDid, false, true);
      }
    } catch (t3) {
      console.warn(`[pnm inbound] could not re-drive pending message`, e3.id, t3);
    }
  }
  async function xC(e2, t2, n2, r2, i2, a2) {
    let o2;
    try {
      o2 = await ou(i2, {
        holder: eu(t2.did, n2.privateKey),
        resolveSender: Su
      });
    } catch (e3) {
      throw console.warn(`[pnm inbound] refusing inbound TSP frame:`, e3 instanceof Error ? e3.message : String(e3)), e3;
    }
    if (au(o2)) {
      let e3 = await Yl(Dx, t2.did, o2.from, o2.control);
      e3.kind === `ignored` ? console.info(`[pnm tsp] ignored a relationship message from`, o2.from, `\u2014`, e3.reason) : e3.kind === `adopted` ? console.info(`[pnm tsp] relationship with`, o2.from, `accepted after the handshake stopped waiting`) : console.info(`[pnm tsp] relationship with`, o2.from, `cancelled by the peer`, e3.reply ? `(answering cancellation not sent)` : ``);
      return;
    }
    await SC(e2, t2, n2, r2, o2, o2.from, a2);
  }
  async function SC(e2, t2, n2, r2, i2, a2, o2 = false) {
    let s2 = typeof i2.id == `string` ? i2.id : void 0;
    console.info(`[pnm inbound] received`, o2 ? `(approver inbox)` : `(worker inbox)`, `type=`, i2.type, `id=`, s2 ?? `(none)`, `sender=`, a2, `to=`, i2.to);
    let c2;
    if (s2) try {
      await Cd(new Dt(), {
        id: s2,
        message: i2,
        senderDid: a2,
        vtaDid: r2,
        isApprover: o2
      });
    } catch (e3) {
      c2 = e3, console.error(`[pnm inbound] FAILED to durably record inbound message \u2014 it cannot be recovered if this document is torn down before the user decides`, s2, e3);
    }
    if (CC(e2, t2, n2, r2, i2, a2, o2), c2) throw c2;
  }
  async function CC(e2, t2, n2, r2, i2, a2, o2 = false, s2 = false) {
    try {
      await wC(e2, t2, n2, r2, i2, a2, o2, s2);
    } catch (e3) {
      console.error(`[pnm inbound] handling threw \u2014 no prompt was raised for this message:`, typeof i2.type == `string` ? i2.type : `(no type)`, typeof i2.id == `string` ? i2.id : `(no id)`, e3);
    } finally {
      let e3 = typeof i2.id == `string` ? i2.id : void 0;
      e3 && await Td(new Dt(), e3).catch((t3) => {
        console.warn(`[pnm inbound] could not clear pending record`, e3, t3);
      });
    }
  }
  async function wC(e2, t2, n2, r2, i2, a2, o2 = false, s2 = false) {
    let c2 = od(i2, r2, a2);
    if (c2) {
      chrome.runtime.sendMessage({
        type: At,
        event: `consentgranted`,
        detail: {
          payloadDigest: c2.payloadDigest
        }
      });
      return;
    }
    if (await aS(r2, i2, a2)) return;
    let l2 = await sd(i2, {
      enrolledExecutorDids: await sS(r2),
      holderDid: n2.did
    });
    if (l2.ok) {
      await TC(e2, t2, n2, l2.parsed, i2, o2);
      return;
    }
    if (l2.reason !== `not-a-task-consent-request`) {
      console.warn(`[pnm inbound] refusing task-consent request:`, l2.reason, l2.detail ?? ``);
      return;
    }
  }
  async function TC(e2, t2, n2, r2, i2, a2 = false) {
    let o2 = await vd(new Dt(), i2.body);
    if (o2 === `duplicate`) {
      console.info(`[pnm inbound] skipping replayed task-consent:`, i2.id);
      return;
    }
    if (o2 === `conflict`) {
      console.warn(`[pnm inbound] refusing task-consent: idConflict \u2014 document id already claimed by different content:`, i2.id);
      return;
    }
    if ($x.has(r2.request.payloadDigest)) {
      console.info(`[pnm inbound] task-consent already prompting for this digest; skipping`);
      return;
    }
    $x.add(r2.request.payloadDigest);
    let s2 = chrome.runtime.connect({
      name: It
    });
    try {
      let i3 = (await chrome.runtime.sendMessage({
        type: `vta-wallet/task-consent`,
        request: r2.request,
        approver: a2
      }))?.approved === true ? `approve` : `deny`, o3 = await ld({
        holder: t2,
        signing: n2,
        vta: await ze(r2.executorDid),
        mediator: e2.mediator,
        decision: i3,
        challenge: r2.request.challenge,
        payloadDigest: r2.request.payloadDigest,
        thid: r2.thid
      });
      e2.send(o3.packed), nS(o3.id, {
        executorDid: r2.executorDid,
        payloadDigest: r2.request.payloadDigest,
        decision: i3,
        taskType: r2.request.taskType,
        sentAt: Date.now()
      }), console.info(`[pnm inbound] task-consent decision sent:`, i3, `awaiting the executor's answer on thid`, o3.id);
    } catch (e3) {
      console.error(`[pnm inbound] task-consent handling failed:`, e3);
    } finally {
      s2.disconnect(), $x.delete(r2.request.payloadDigest);
    }
  }
  async function EC(e2) {
    let t2 = Hm(), { identity: n2, signing: r2 } = await Hg(e2.vtaDid);
    t2.mark(`load holder`);
    let i2 = e2.entryId ? await DC(e2.vtaDid, e2.restBaseUrl, e2.entryId) : void 0, a2 = await Au({
      sender: Ju({
        baseUrl: e2.params.baseUrl,
        rpDid: e2.params.rpDid,
        signing: i2 ?? r2
      }),
      holder: n2,
      service: {
        did: e2.params.rpDid
      },
      ...i2 ? {
        subject: i2.did
      } : {},
      ...e2.params.sessionKey === void 0 ? {} : {
        sessionKey: e2.params.sessionKey
      }
    });
    return t2.mark(`authenticate (trust-task)`), {
      ok: true,
      result: {
        accessToken: a2.accessToken,
        refreshToken: a2.refreshToken ?? ``,
        sessionId: a2.sessionId,
        holderDid: i2?.did ?? r2.did,
        ...a2.sessionKey === void 0 ? {} : {
          sessionKey: a2.sessionKey
        },
        timings: t2.marks
      }
    };
  }
  async function DC(e2, t2, n2) {
    let { session: r2, holder: i2, service: a2 } = await $(e2, t2), o2 = (await Fd(r2, {
      holder: i2,
      service: a2
    })).entries.find((e3) => e3.id === n2);
    if (!o2?.principalDid) throw Error(`vault entry ${n2} names no persona DID`);
    return Zd({
      session: r2,
      holder: i2,
      service: a2,
      entryId: n2,
      did: o2.principalDid
    });
  }
  async function OC(e2) {
    let t2 = dx(e2.entryId);
    if (t2) return {
      ok: false,
      error: t2
    };
    let n2 = Hm(), { identity: r2, signing: i2 } = await Hg(e2.vtaDid);
    n2.mark(`load holder`);
    let a2 = await Ae(e2.params.controlDid).catch(() => ({})), o2 = {
      ...a2,
      ...a2.didcomm || !e2.params.mediatorDid ? {} : {
        didcomm: {
          mediatorDid: e2.params.mediatorDid
        }
      }
    };
    n2.mark(`resolve rp services`);
    let { session: s2 } = await Rx(e2.params.controlDid, {
      holder: r2,
      signing: i2
    }, (t3) => KS(t3, e2.vtaDid), {
      services: o2
    });
    n2.mark(`rp session`);
    let c2 = await Au({
      sender: s2,
      holder: r2,
      service: await ze(e2.params.controlDid),
      ...e2.params.scope ? {
        scope: e2.params.scope
      } : {}
    });
    return n2.mark(`authenticate (trust-task)`), {
      ok: true,
      result: ux(c2, i2.did, n2.marks)
    };
  }
  async function kC(e2) {
    let t2 = await jd({
      kind: `stepUpRequired`,
      ...e2.refusal
    }, {
      enrolledExecutorDids: await sS(e2.vtaDid)
    });
    if (!t2.ok) return {
      ok: false,
      error: `step-up request refused: ${t2.reason}`
    };
    let n2 = {
      type: ht,
      origin: e2.origin,
      agentDid: t2.issuer,
      claimTypes: [
        ...t2.context.claimTypes
      ],
      ...t2.context.verifierDid === void 0 ? {} : {
        verifierDid: t2.context.verifierDid
      },
      ...t2.context.purpose === void 0 ? {} : {
        purpose: t2.context.purpose
      }
    };
    return (await chrome.runtime.sendMessage(n2))?.approved === true ? (await Qx({
      target: _t,
      type: wt,
      vtaDid: e2.vtaDid,
      ...e2.restBaseUrl === void 0 ? {} : {
        restBaseUrl: e2.restBaseUrl
      },
      origin: e2.origin,
      params: {
        type: Ad,
        payload: kd(t2.request, true)
      }
    }), {
      ok: true
    }) : {
      ok: false,
      error: `user declined the step-up approval`
    };
  }
  async function AC(e2) {
    let t2 = Hm(), { signing: n2 } = await Hg(e2.vtaDid);
    t2.mark(`load holder`);
    let r2 = await qu({
      baseUrl: e2.params.baseUrl,
      accessToken: e2.params.accessToken,
      refreshToken: e2.params.refreshToken,
      sessionId: e2.params.sessionId,
      signing: n2,
      rpDid: e2.params.rpDid,
      enrolledExecutorDids: await sS(e2.vtaDid),
      onMark: (e3) => t2.mark(e3),
      requestConsent: async (t3) => {
        let r3 = {
          type: Ot,
          origin: e2.origin,
          rpDid: e2.params.rpDid,
          baseUrl: e2.params.baseUrl,
          holderDid: n2.did,
          ...t3.reason === void 0 ? {} : {
            reason: t3.reason
          }
        };
        return (await chrome.runtime.sendMessage(r3))?.approved === true;
      }
    });
    return r2.ok ? {
      ok: true,
      result: {
        accessToken: r2.tokens.accessToken,
        refreshToken: r2.tokens.refreshToken,
        sessionId: r2.tokens.sessionId,
        holderDid: n2.did,
        timings: t2.marks
      }
    } : (console.warn(`[pnm step-up]`, r2.error), {
      ok: false,
      error: r2.error
    });
  }
});
