import { i as e, t } from "./rolldown-runtime-Dd_uD5pT.js";
import { a as n, i as r, r as i, t as a } from "./theme-pbhxFgxu.js";
import { A as o, D as s, F as c, I as l, L as u, M as d, N as f, O as p, P as m, R as h, a as g, b as _, c as v, f as y, g as b, j as x, l as S, m as C, o as w, p as T, r as E, u as D, w as O, y as ee, z as k } from "./host-permissions-TPtLahe0.js";
import { a as A, c as j, n as te } from "./sign-in-uv-messages-Cu3YiOZZ.js";
import { a as ne, c as M, g as N, h as re, i as ie, n as ae, p as oe, u as se, y as P } from "./agreements-store-D0oqmDVT.js";
import { S as ce } from "./didcomm-D5nXYRy6.js";
import { Lt as F, Ot as le, X as ue, at as de, jt as fe, rt as pe, zt as me } from "./bridge-protocol-DoEW6v30.js";
function he(e2) {
  if (e2 === void 0) return `\u2205`;
  let t2;
  if (typeof e2 == `string`) t2 = e2;
  else try {
    t2 = JSON.stringify(e2) ?? String(e2);
  } catch {
    t2 = String(e2);
  }
  return t2.length > 200 ? `${t2.slice(0, 200)}\u2026` : t2;
}
function ge(e2) {
  return e2.path !== void 0 || e2.before !== void 0 || e2.after !== void 0;
}
function _e(e2) {
  if (!ge(e2)) return null;
  let t2 = {};
  return e2.path !== void 0 && (t2.path = e2.path), e2.before !== void 0 && (t2.before = he(e2.before)), e2.after !== void 0 && (t2.after = he(e2.after)), t2;
}
var I = { stale: 0, anomalous: 1, new: 2, predicate: 3 };
function ve(e2) {
  let t2 = new Set(e2.anomalous ?? []), n2 = e2.claims.map((e3, n3) => {
    let r3 = [];
    return e3.stale === true && r3.push(`stale`), t2.has(e3.type) && r3.push(`anomalous`), e3.newToThisVerifier === true && r3.push(`new`), e3.predicate !== void 0 && r3.push(`predicate`), { claim: e3, notices: r3, index: n3 };
  }), r2 = (e3) => e3.length === 0 ? 2 ** 53 - 1 : I[e3[0]];
  return n2.sort((e3, t3) => r2(e3.notices) - r2(t3.notices) || e3.index - t3.index).map(({ claim: e3, notices: t3 }) => ({ claim: e3, notices: t3 }));
}
function L(e2) {
  let t2 = e2.sendingCount === 1 ? `1 claim` : `${e2.sendingCount} claims`;
  return e2.withheldCount === 0 ? t2 : `${t2} \u2014 ${e2.withheldCount} cannot be sent`;
}
function ye(e2) {
  return `proves ${{ gte: `is at least`, gt: `is more than`, lte: `is at most`, lt: `is less than`, eq: `is`, ne: `is not`, memberOf: `is one of` }[e2.op] ?? e2.op} ${typeof e2.arg == `string` ? e2.arg : JSON.stringify(e2.arg)} \u2014 the value itself is not sent`;
}
function be(e2) {
  return typeof e2 == `string` ? e2 : e2 === void 0 ? `(no value)` : JSON.stringify(e2);
}
function R(e2, t2) {
  let n2 = ve(e2).map(({ claim: e3, notices: t3 }) => e3.stale === true ? { type: e3.type, shown: `will NOT be sent \u2014 the credential behind it could not be checked`, kind: `withheld`, notices: t3, claim: e3 } : e3.predicate === void 0 ? { type: e3.type, shown: be(e3.value), kind: `value`, notices: t3, claim: e3 } : { type: e3.type, shown: ye(e3.predicate), kind: `predicate`, notices: t3, claim: e3 }), r2 = n2.filter((e3) => e3.kind === `withheld`).length;
  return { verifierDid: t2.verifierDid, ...t2.purpose === void 0 ? {} : { purpose: t2.purpose }, subject: e2.subject, rows: n2, sendingCount: n2.length - r2, withheldCount: r2, ...e2.renderer === void 0 ? {} : { renderer: e2.renderer }, correlation: { severity: e2.correlation?.severity ?? `none`, ...e2.correlation?.reason === void 0 ? {} : { reason: e2.correlation.reason } }, expiresAt: e2.expiresAt, previewId: e2.previewId };
}
function z(e2) {
  return e2.correlation.severity !== `none`;
}
var B = e(n(), 1), xe = a(), V = i();
function Se({ row: e2 }) {
  let t2 = e2.kind === `withheld` ? { fg: `var(--w-warn)`, bg: `var(--w-warn-soft)` } : e2.kind === `predicate` ? { fg: `var(--w-ok)`, bg: `var(--w-ok-soft)` } : { fg: `var(--w-text)`, bg: `transparent` };
  return (0, V.jsxs)(`li`, { style: { listStyle: `none`, padding: `8px 10px`, borderRadius: `var(--w-r-sm)`, background: t2.bg, marginBottom: 4 }, children: [(0, V.jsxs)(`div`, { style: { display: `flex`, gap: 8, alignItems: `baseline` }, children: [e2.notices.length > 0 && (0, V.jsx)(`span`, { "aria-hidden": true, style: { color: `var(--w-warn)`, fontWeight: 700 }, children: `!` }), (0, V.jsx)(`code`, { style: { fontSize: `var(--w-t-sm)`, color: `var(--w-muted)` }, children: e2.type })] }), (0, V.jsx)(`div`, { style: { color: t2.fg, fontSize: `var(--w-t-base)`, marginTop: 2 }, children: e2.shown }), e2.notices.length > 0 && (0, V.jsx)(`div`, { style: { fontSize: `var(--w-t-xs)`, color: `var(--w-muted)`, marginTop: 2 }, children: e2.notices.map((e3) => ({ stale: `cannot be sent`, anomalous: `unusual for the stated purpose`, new: `this verifier has not had this before`, predicate: `proven, not shown` })[e3]).join(` \xB7 `) })] });
}
function Ce({ consentId: e2, decide: t2 }) {
  let [n2, r2] = (0, B.useState)(null);
  if ((0, B.useEffect)(() => {
    chrome.storage.session.get(`disclosure-consent:${e2}`).then((t3) => {
      r2(t3[`disclosure-consent:${e2}`] ?? null);
    });
  }, [e2]), !n2) return (0, V.jsx)(`div`, { style: { padding: 20, fontSize: `var(--w-t-base)` }, children: `Loading request\u2026` });
  let i2 = R(n2.preview, { verifierDid: n2.verifierDid, ...n2.purpose === void 0 ? {} : { purpose: n2.purpose } }), a2 = z(i2);
  return (0, V.jsxs)(`div`, { style: { padding: 20, maxWidth: 520 }, children: [(0, V.jsx)(`h1`, { style: { fontSize: `var(--w-t-lg)`, margin: `0 0 4px` }, children: `Share your details?` }), (0, V.jsx)(`p`, { style: { margin: `0 0 14px`, color: `var(--w-muted)`, fontSize: `var(--w-t-sm)` }, children: `Nothing has been sent yet.` }), (0, V.jsxs)(`dl`, { style: { margin: `0 0 14px`, fontSize: `var(--w-t-sm)` }, children: [(0, V.jsx)(`dt`, { style: { color: `var(--w-faint)` }, children: `To` }), (0, V.jsx)(`dd`, { style: { margin: `0 0 6px` }, children: (0, V.jsx)(b, { value: i2.verifierDid }) }), i2.purpose !== void 0 && (0, V.jsxs)(V.Fragment, { children: [(0, V.jsx)(`dt`, { style: { color: `var(--w-faint)` }, children: `Because` }), (0, V.jsx)(`dd`, { style: { margin: `0 0 6px` }, children: i2.purpose })] }), (0, V.jsx)(`dt`, { style: { color: `var(--w-faint)` }, children: `As` }), (0, V.jsxs)(`dd`, { style: { margin: 0 }, children: [(0, V.jsx)(b, { value: i2.subject }), (0, V.jsx)(`div`, { style: { color: `var(--w-faint)`, fontSize: `var(--w-t-xs)`, marginTop: 2 }, children: `A one-off identifier for this verifier \u2014 it cannot be matched against what you have shared elsewhere.` })] })] }), a2 && (0, V.jsxs)(`div`, { style: { padding: `8px 10px`, borderRadius: `var(--w-r-sm)`, background: i2.correlation.severity === `high` ? `var(--w-danger-soft)` : `var(--w-warn-soft)`, color: i2.correlation.severity === `high` ? `var(--w-danger)` : `var(--w-warn)`, fontSize: `var(--w-t-sm)`, marginBottom: 12 }, children: [(0, V.jsx)(`strong`, { children: i2.correlation.severity === `high` ? `This can be linked to you elsewhere.` : `This is somewhat linkable.` }), i2.correlation.reason !== void 0 && (0, V.jsx)(`div`, { children: i2.correlation.reason })] }), i2.renderer !== void 0 && i2.renderer.drops.length > 0 && (0, V.jsxs)(`div`, { style: { fontSize: `var(--w-t-sm)`, color: `var(--w-warn)`, marginBottom: 12 }, children: [`Sent as `, (0, V.jsx)(`code`, { children: i2.renderer.id }), `, which drops`, ` `, i2.renderer.drops.join(`, `), ` \u2014 the verifier sees the values but not that they were attested.`] }), (0, V.jsx)(`h2`, { style: { fontSize: `var(--w-t-base)`, margin: `0 0 6px` }, children: L(i2) }), i2.rows.length === 0 ? (0, V.jsx)(`p`, { style: { color: `var(--w-muted)`, fontSize: `var(--w-t-sm)` }, children: `This persona would share nothing with this verifier.` }) : (0, V.jsx)(`ul`, { style: { padding: 0, margin: `0 0 16px` }, children: i2.rows.map((e3) => (0, V.jsx)(Se, { row: e3 }, e3.type)) }), (0, V.jsxs)(`div`, { style: { display: `flex`, gap: 8 }, children: [(0, V.jsx)(`button`, { type: `button`, onClick: () => t2(true), children: `Share` }), (0, V.jsx)(`button`, { type: `button`, onClick: () => t2(false), children: `Don't share` })] })] });
}
var we = /[​-‏‪-‮⁠-⁤⁦-⁩﻿]/g;
function Te(e2) {
  let t2;
  try {
    t2 = JSON.stringify(e2, null, 2) ?? String(e2);
  } catch {
    t2 = String(e2);
  }
  return t2.replace(we, (e3) => `\\u${e3.charCodeAt(0).toString(16).toUpperCase().padStart(4, `0`)}`);
}
var Ee = `approver-consent:`;
function De(e2) {
  return [`vta-approver/${e2.kind}`, e2.audience, e2.subject ?? ``, e2.challenge ?? ``, e2.boundTo ?? ``, ...e2.kind === `decision` ? [e2.decision ?? ``] : []].join(`\0`);
}
function H(e2) {
  return /\/spec\/(.+)\/[\d.]+$/.exec(e2)?.[1] ?? e2;
}
function Oe(e2) {
  try {
    return new URL(e2).host;
  } catch {
    return e2;
  }
}
var U = { fontSize: 10.5, fontWeight: 700, letterSpacing: 0.6, textTransform: `uppercase`, color: `var(--w-muted)`, marginBottom: 4 }, W = { border: `1px solid var(--w-line)`, borderRadius: 6, padding: 10, background: `var(--w-raised)` };
function ke({ consentId: e2, decide: t2 }) {
  let [n2, r2] = (0, B.useState)(null), [i2, a2] = (0, B.useState)(false), [o2, s2] = (0, B.useState)(null);
  if ((0, B.useEffect)(() => {
    chrome.storage.session.get(`${Ee}${e2}`).then((t3) => {
      r2(t3[`approver-consent:${e2}`] ?? null);
    });
  }, [e2]), !n2) return (0, V.jsx)(`div`, { style: { padding: 20, fontSize: 13 }, children: `Loading request\u2026` });
  async function c2(e3) {
    a2(true), s2(null);
    try {
      let { prfOutput: n3 } = await D(chrome.runtime.id, De(e3));
      t2(true, ce(n3));
    } catch (e4) {
      s2(e4 instanceof Error ? e4.message : String(e4));
    } finally {
      a2(false);
    }
  }
  let l2 = n2.kind === `stepUp` ? `Approve this action with your approver?` : n2.kind === `decision` ? n2.decision === `deny` ? `Deny this action, vouched for by your approver?` : `Approve this action, vouched for by your approver?` : n2.kind === `enrol` ? `Enrol this wallet's approver?` : `Set up step-up approval in this wallet?`;
  return (0, V.jsxs)(`div`, { style: { padding: 20, background: `var(--w-danger-wash)`, minHeight: `100vh`, color: `var(--w-text)`, fontSize: 13 }, children: [(0, V.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 10, background: `var(--w-danger-soft)`, color: `var(--w-danger)`, padding: `11px 16px`, margin: `-20px -20px 16px`, borderBottom: `3px solid var(--w-danger)` }, children: [(0, V.jsx)(`span`, { style: { fontSize: 20, lineHeight: 1 }, "aria-hidden": true, children: `\u{1F6E1}\uFE0F` }), (0, V.jsxs)(`div`, { style: { display: `grid`, gap: 1 }, children: [(0, V.jsx)(`span`, { style: { fontSize: 12, fontWeight: 800, letterSpacing: 1.2 }, children: `APPROVER MODE` }), (0, V.jsx)(`span`, { style: { fontSize: 11, opacity: 0.85 }, children: `You are re-authenticating \u2014 read it before you approve` })] })] }), (0, V.jsxs)(`div`, { style: { display: `grid`, gap: 14 }, children: [(0, V.jsx)(`strong`, { style: { fontSize: 14 }, children: l2 }), (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: U, children: `Community` }), (0, V.jsx)(b, { value: n2.audience }), (0, V.jsxs)(`div`, { style: { fontSize: 11, color: `var(--w-muted)`, marginTop: 4 }, children: [`Asked from `, (0, V.jsx)(`strong`, { children: Oe(n2.origin) }), `, which you signed in to this community from.`] })] }), n2.kind === `stepUp` && n2.operation ? (0, V.jsxs)(V.Fragment, { children: [n2.reason ? (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: U, children: `The community's reason (not verified by the wallet)` }), (0, V.jsx)(`div`, { style: { ...W, whiteSpace: `pre-wrap`, wordBreak: `break-word` }, children: n2.reason })] }) : null, (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: U, children: `The action this approves \u2014 and nothing else` }), (0, V.jsxs)(`div`, { style: W, children: [(0, V.jsx)(`code`, { style: { fontSize: 12 }, children: H(n2.operation.type) }), (0, V.jsx)(`div`, { style: { fontSize: 10.5, color: `var(--w-muted)`, wordBreak: `break-all`, marginTop: 2 }, children: n2.operation.type }), (0, V.jsx)(`pre`, { style: { margin: `8px 0 0`, maxHeight: 220, overflow: `auto`, fontSize: 11, whiteSpace: `pre-wrap`, wordBreak: `break-all` }, children: Te(n2.operation.payload) })] })] })] }) : null, n2.kind === `decision` && n2.operation ? (0, V.jsxs)(V.Fragment, { children: [(0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: U, children: `Your decision` }), (0, V.jsx)(`div`, { style: { ...W, fontWeight: 800, fontSize: 14, color: n2.decision === `deny` ? `var(--w-danger)` : `var(--w-text)` }, children: n2.decision === `deny` ? `DENY` : `APPROVE` })] }), n2.summary ? (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: U, children: `The community's summary (not verified by the wallet)` }), (0, V.jsx)(`div`, { style: { ...W, whiteSpace: `pre-wrap`, wordBreak: `break-word` }, children: n2.summary })] }) : null, n2.reason ? (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: U, children: `Your note on the decision` }), (0, V.jsx)(`div`, { style: { ...W, whiteSpace: `pre-wrap`, wordBreak: `break-word` }, children: n2.reason })] }) : null, (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: U, children: `The action this decides \u2014 and nothing else` }), (0, V.jsxs)(`div`, { style: W, children: [(0, V.jsx)(`code`, { style: { fontSize: 12 }, children: H(n2.operation.type) }), (0, V.jsxs)(`div`, { style: { fontSize: 10.5, color: `var(--w-muted)`, wordBreak: `break-all`, marginTop: 2 }, children: [n2.operation.type, n2.actionId ? ` \xB7 action ${n2.actionId}` : ``] }), (0, V.jsx)(`pre`, { style: { margin: `8px 0 0`, maxHeight: 220, overflow: `auto`, fontSize: 11, whiteSpace: `pre-wrap`, wordBreak: `break-all` }, children: Te(n2.operation.payload) })] })] })] }) : null, n2.kind === `enrol` ? (0, V.jsxs)(`div`, { style: { color: `var(--w-muted)`, lineHeight: 1.45 }, children: [`This proves to the community that this wallet holds the approver below, so it can be bound to you as a step-up factor. Bound to`, ` `, (0, V.jsx)(`code`, { style: { fontSize: 11, wordBreak: `break-all` }, children: n2.boundTo }), `.`] }) : null, n2.kind === `setup` ? (0, V.jsx)(`div`, { style: { color: `var(--w-muted)`, lineHeight: 1.45 }, children: `This creates the key that protects this wallet's step-up approvers \u2014 one per community, so communities cannot recognise you by it. It signs nothing.` }) : null, n2.subject ? (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: U, children: n2.kind === `decision` ? `Decided by` : `On behalf of` }), (0, V.jsx)(b, { value: n2.subject })] }) : null, n2.approverDid ? (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: U, children: `Approver (this wallet, for this community only)` }), (0, V.jsx)(b, { value: n2.approverDid })] }) : null, o2 ? (0, V.jsxs)(`div`, { style: { color: `var(--w-danger)`, fontSize: 12, lineHeight: 1.4 }, children: [`Not signed: `, o2] }) : null, (0, V.jsxs)(`div`, { style: { display: `flex`, gap: 8, justifyContent: `flex-end`, marginTop: 4 }, children: [(0, V.jsx)(`button`, { autoFocus: true, onClick: () => t2(false), style: { padding: `8px 16px`, fontSize: 13 }, children: `Deny` }), (0, V.jsx)(`button`, { disabled: i2, onClick: () => void c2(n2), style: { padding: `8px 18px`, fontSize: 13, fontWeight: 700, border: `none`, borderRadius: 8, color: `var(--w-accent-ink)`, background: `var(--w-danger)`, opacity: i2 ? 0.45 : 1, cursor: i2 ? `not-allowed` : `pointer` }, children: i2 ? `Waiting for authenticator\u2026` : `Approve with biometric` })] })] })] });
}
function Ae(e2) {
  try {
    return new URL(e2).host;
  } catch {
    return e2;
  }
}
var je = { fontSize: 10.5, fontWeight: 700, letterSpacing: 0.6, textTransform: `uppercase`, color: `var(--w-muted)`, marginBottom: 4 }, Me = { border: `1px solid var(--w-line)`, borderRadius: 6, padding: 10, background: `var(--w-raised)` }, Ne = { padding: `8px 18px`, fontSize: 13, fontWeight: 700, border: `none`, borderRadius: 8, color: `var(--w-accent-ink)`, background: `var(--w-accent)`, cursor: `pointer` };
function Pe(e2) {
  let t2 = Date.parse(e2);
  return Number.isNaN(t2) ? e2 : new Date(t2).toLocaleDateString(void 0, { year: `numeric`, month: `short`, day: `numeric` });
}
function Fe({ view: e2, decide: t2 }) {
  let [n2, r2] = (0, B.useState)(null);
  async function i2() {
    if (!await g(e2.needsOrigin).catch(() => false)) {
      r2(`The wallet needs to reach ${Ae(e2.needsOrigin)} to read this community's offers.`);
      return;
    }
    t2(true);
  }
  return e2.needsOrigin ? (0, V.jsxs)(V.Fragment, { children: [(0, V.jsx)(`strong`, { style: { fontSize: 14 }, children: `Let the wallet read this community's offers?` }), (0, V.jsxs)(`div`, { style: { color: `var(--w-muted)`, lineHeight: 1.45 }, children: [e2.origin ? `${Ae(e2.origin)} asks you to accept a room offered by ` : `To accept a room offered by `, (0, V.jsx)(b, { value: e2.communityDid }), `, the wallet needs to reach `, Ae(e2.needsOrigin), `, where the community takes requests. Nothing is accepted yet: the offer is shown to you next.`] }), n2 && (0, V.jsx)(`div`, { style: { color: `var(--w-danger)` }, children: n2 }), (0, V.jsxs)(`div`, { style: { display: `flex`, justifyContent: `flex-end`, gap: 8, marginTop: 16 }, children: [(0, V.jsx)(`button`, { autoFocus: true, onClick: () => t2(false), style: { padding: `8px 16px`, fontSize: 13 }, children: `Cancel` }), (0, V.jsxs)(`button`, { onClick: () => void i2(), style: Ne, children: [`Allow `, Ae(e2.needsOrigin)] })] })] }) : (0, V.jsxs)(V.Fragment, { children: [(0, V.jsx)(`strong`, { style: { fontSize: 14 }, children: e2.resume ? `Finish joining this room?` : `Join this room?` }), (0, V.jsxs)(`div`, { style: { color: `var(--w-muted)`, lineHeight: 1.45 }, children: [e2.origin ? (0, V.jsxs)(V.Fragment, { children: [Ae(e2.origin), ` asks you to accept `] }) : (0, V.jsx)(V.Fragment, { children: `Accept ` }), `an offer from `, (0, V.jsx)(b, { value: e2.communityDid }), `. `, M(e2.visibility), e2.resume ? ` An earlier accept of this offer did not finish; this finishes it, with the same key package.` : ``] }), (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: je, children: `Room` }), (0, V.jsxs)(`div`, { style: Me, children: [e2.label ? (0, V.jsx)(`div`, { style: { fontWeight: 600, marginBottom: 4, wordBreak: `break-word` }, title: `The name the community gave it`, children: e2.label }) : null, se(e2.description) ? (0, V.jsx)(`div`, { style: { fontSize: 12, marginBottom: 4, wordBreak: `break-word`, whiteSpace: `pre-line` }, title: `What the community says the room is for`, children: se(e2.description) }) : null, (0, V.jsx)(b, { value: e2.roomId }), (0, V.jsxs)(`div`, { style: { fontSize: 11, color: `var(--w-muted)`, marginTop: 4 }, children: [e2.visibility, ` room \xB7 you may `, e2.actions.join(`, `) || `\u2014`, ` \xB7 offer valid until `, Pe(e2.validUntil)] })] })] }), (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: je, children: `You join as` }), (0, V.jsxs)(`div`, { style: Me, children: [(0, V.jsx)(b, { value: e2.member }), (0, V.jsx)(`div`, { style: { fontSize: 11, color: `var(--w-muted)`, marginTop: 4 }, children: `The identity you sign in to this community with, held by your agent. It signs the acceptance; the community sees it, and nothing of this wallet.` })] })] }), (0, V.jsxs)(`div`, { style: { display: `flex`, justifyContent: `flex-end`, gap: 8, marginTop: 16 }, children: [(0, V.jsx)(`button`, { autoFocus: true, onClick: () => t2(false), style: { padding: `8px 16px`, fontSize: 13 }, children: `Not now` }), (0, V.jsx)(`button`, { onClick: () => t2(true), style: Ne, children: e2.resume ? `Finish joining` : `Accept and join` })] })] });
}
function Ie(e2) {
  try {
    return new URL(e2).host;
  } catch {
    return e2;
  }
}
function Le(e2) {
  return e2 < 1024 ? `${e2} B` : e2 < 1048576 ? `${(e2 / 1024).toFixed(1)} KiB` : `${(e2 / 1048576).toFixed(1)} MiB`;
}
var Re = { fontSize: 10.5, fontWeight: 700, letterSpacing: 0.6, textTransform: `uppercase`, color: `var(--w-muted)`, marginBottom: 4 }, ze = { border: `1px solid var(--w-line)`, borderRadius: 6, padding: 10, background: `var(--w-raised)` }, Be = { display: `flex`, justifyContent: `flex-end`, gap: 8, marginTop: 16 };
function Ve(e2) {
  return (0, V.jsx)(`button`, { disabled: e2.disabled, onClick: e2.onClick, style: { padding: `8px 18px`, fontSize: 13, fontWeight: 700, border: `none`, borderRadius: 8, color: `var(--w-accent-ink)`, background: `var(--w-accent)`, opacity: e2.disabled ? 0.45 : 1, cursor: e2.disabled ? `not-allowed` : `pointer` }, children: e2.children });
}
function He({ consentId: e2, decide: t2 }) {
  let [n2, r2] = (0, B.useState)(null);
  return (0, B.useEffect)(() => {
    let t3 = `${oe}${e2}`;
    chrome.storage.session.get(t3).then((e3) => {
      r2(e3[t3] ?? null);
    });
  }, [e2]), n2 ? (0, V.jsx)(`div`, { style: { padding: 20, fontSize: 13, display: `grid`, gap: 14 }, children: n2.kind === `share` ? (0, V.jsx)(Ge, { view: n2, decide: t2 }) : n2.kind === `offer` ? (0, V.jsx)(Fe, { view: n2, decide: t2 }) : (0, V.jsx)(Ke, { view: n2, decide: t2 }) }) : (0, V.jsx)(`div`, { style: { padding: 20, fontSize: 13 }, children: `Loading request\u2026` });
}
function Ue(e2) {
  return e2.length > 48 ? `${e2.slice(0, 24)}\u2026${e2.slice(-14)}` : e2;
}
function We(e2) {
  return e2 === `administers` ? `administers the room` : e2 === `member` ? `member` : `place not reported`;
}
function Ge({ view: e2, decide: t2 }) {
  let [n2, r2] = (0, B.useState)(() => new Set(e2.rooms.filter((e3) => e3.ticked).map((e3) => e3.key))), [i2, a2] = (0, B.useState)(null), o2 = (t3) => r2((n3) => N(e2.rooms, n3, t3)), s2 = new Set(e2.rooms.filter((t3, n3) => e2.rooms.findIndex((e3) => e3.roomId === t3.roomId) !== n3).map((e3) => e3.roomId));
  async function c2() {
    if (e2.needsOrigin && !await g(e2.needsOrigin).catch(() => false)) {
      a2(`The wallet needs to reach ${Ie(e2.needsOrigin)} to use these rooms.`);
      return;
    }
    t2(true, [...n2]);
  }
  return (0, V.jsxs)(V.Fragment, { children: [(0, V.jsxs)(`strong`, { style: { fontSize: 14 }, children: [`Share rooms with `, Ie(e2.origin), `?`] }), (0, V.jsxs)(`div`, { style: { color: `var(--w-muted)`, lineHeight: 1.45 }, children: [`This is the member portal of `, (0, V.jsx)(b, { value: e2.hostDid }), `, by its DID document. Tick the rooms that belong to this community. The page will be able to `, (0, V.jsx)(`b`, { children: `read` }), ` them, and to `, (0, V.jsx)(`b`, { children: `ask` }), ` to add notes and files \u2014 each addition is shown to you here first. It sees no other room, and no key.`] }), (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: Re, children: `Rooms you hold as the identity you use here` }), e2.members.length === 0 ? (0, V.jsx)(`div`, { style: ze, children: `You have not signed in to this community with an identity your agent holds, so there is no one to share a room as. Sign in to the portal with your wallet first.` }) : e2.rooms.length === 0 ? (0, V.jsx)(`div`, { style: ze, children: `Your agent holds no room as the identity you use here.` }) : (0, V.jsx)(`div`, { style: { ...ze, display: `grid`, gap: 8, maxHeight: 300, overflow: `auto` }, children: e2.rooms.map((e3) => (0, V.jsxs)(`label`, { style: { display: `flex`, gap: 8, alignItems: `flex-start` }, children: [(0, V.jsx)(`input`, { type: `checkbox`, checked: n2.has(e3.key), onChange: () => o2(e3.key), "aria-label": `Share ${e3.label ?? e3.roomId} as ${e3.member}` }), (0, V.jsxs)(`span`, { style: { display: `grid`, gap: 2 }, children: [e3.label !== void 0 && (0, V.jsx)(`strong`, { style: { fontSize: 13 }, children: e3.label }), (0, V.jsx)(b, { value: e3.roomId }), (0, V.jsxs)(`span`, { style: { fontSize: 11 }, title: e3.member, children: [`as `, (0, V.jsx)(`code`, { children: Ue(e3.member) }), e3.context ? ` \xB7 context ${e3.context}` : ``, ` \xB7 `, We(e3.role)] }), (0, V.jsxs)(`span`, { style: { fontSize: 11, color: `var(--w-muted)` }, children: [e3.shared ? `shared with this portal` : e3.ticked ? `the page asked for this one` : `not shared`, s2.has(e3.roomId) ? ` \xB7 you hold this room as more than one identity: tick the one to use here` : ``] })] })] }, e3.key)) }), e2.others > 0 && (0, V.jsxs)(`div`, { style: { fontSize: 11, color: `var(--w-muted)`, marginTop: 6 }, children: [e2.others === 1 ? `1 other room your agent holds is` : `${e2.others} other rooms your agent holds are`, ` `, `held only as other identities \u2014 the community's own among them, for a room it owns \u2014 and`, ` `, e2.others === 1 ? `is` : `are`, ` not offered to this page.`] })] }), (0, V.jsx)(`div`, { style: { fontSize: 11, color: `var(--w-muted)` }, children: `Each room is checked with the community, as you, before it is shared. A private room is never shared with a portal: its host is not to learn who reads it. Shares last 30 days, and you can revoke them in the wallet's console.` }), i2 && (0, V.jsx)(`div`, { style: { color: `var(--w-danger)` }, children: i2 }), (0, V.jsxs)(`div`, { style: Be, children: [(0, V.jsx)(`button`, { autoFocus: true, onClick: () => t2(false), style: { padding: `8px 16px`, fontSize: 13 }, children: `Cancel` }), (0, V.jsx)(Ve, { onClick: () => void c2(), children: re(n2.size) })] })] });
}
function Ke({ view: e2, decide: t2 }) {
  let n2 = `file` in e2.what;
  return (0, V.jsxs)(V.Fragment, { children: [(0, V.jsxs)(`strong`, { style: { fontSize: 14 }, children: [`Add `, n2 ? `a file` : `a note`, ` to this room as you?`] }), (0, V.jsxs)(`div`, { style: { color: `var(--w-muted)`, lineHeight: 1.45 }, children: [Ie(e2.origin), ` asks to write to a room, signed as you. Every member of the room will read it as yours.`] }), (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: Re, children: `Room` }), (0, V.jsxs)(`div`, { style: ze, children: [(0, V.jsx)(b, { value: e2.roomId }), (0, V.jsxs)(`div`, { style: { fontSize: 11, color: `var(--w-muted)`, marginTop: 4 }, children: [e2.visibility, ` room, hosted by `, (0, V.jsx)(b, { value: e2.hostDid })] })] })] }), (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: Re, children: `Signed as` }), (0, V.jsx)(`div`, { style: ze, children: (0, V.jsx)(b, { value: e2.member }) })] }), (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: Re, children: `What will be written` }), (0, V.jsx)(`div`, { style: { ...ze, whiteSpace: `pre-wrap`, wordBreak: `break-word` }, children: `file` in e2.what ? (0, V.jsxs)(V.Fragment, { children: [(0, V.jsx)(`b`, { children: e2.what.name }), ` \xB7 `, Le(e2.what.size), e2.what.mediaType ? ` \xB7 ${e2.what.mediaType}` : ``, e2.what.title ? (0, V.jsxs)(`div`, { children: [`Title: `, e2.what.title] }) : null] }) : (0, V.jsxs)(V.Fragment, { children: [(0, V.jsx)(`b`, { children: e2.what.title }), e2.what.excerpt ? (0, V.jsx)(`div`, { style: { marginTop: 6 }, children: e2.what.excerpt }) : null, (0, V.jsxs)(`div`, { style: { fontSize: 11, color: `var(--w-muted)`, marginTop: 6 }, children: [e2.what.bodyChars, ` characters`] })] }) })] }), (0, V.jsxs)(`div`, { style: Be, children: [(0, V.jsx)(`button`, { autoFocus: true, onClick: () => t2(false), style: { padding: `8px 16px`, fontSize: 13 }, children: `Deny` }), (0, V.jsxs)(Ve, { onClick: () => t2(true), children: [`Add `, n2 ? `file` : `note`] })] })] });
}
var qe = `directory-consent:`;
function Je(e2) {
  try {
    return new URL(e2).host;
  } catch {
    return e2;
  }
}
var Ye = { fontSize: 10.5, fontWeight: 700, letterSpacing: 0.6, textTransform: `uppercase`, color: `var(--w-muted)`, marginBottom: 4 }, Xe = { border: `1px solid var(--w-line)`, borderRadius: 6, padding: 10, background: `var(--w-raised)` };
function Ze({ consentId: e2, decide: t2 }) {
  let [n2, r2] = (0, B.useState)(null);
  return (0, B.useEffect)(() => {
    let t3 = `${qe}${e2}`;
    chrome.storage.session.get(t3).then((e3) => {
      r2(e3[t3] ?? null);
    });
  }, [e2]), n2 ? (0, V.jsxs)(`div`, { style: { padding: 20, fontSize: 13, display: `grid`, gap: 14 }, children: [(0, V.jsxs)(`strong`, { style: { fontSize: 14 }, children: [`Publish your card from `, n2.communityName, `?`] }), (0, V.jsxs)(`div`, { style: { color: `var(--w-muted)`, lineHeight: 1.45 }, "data-testid": `directory-consent-meaning`, children: [n2.meaning.map((e3) => (0, V.jsx)(`p`, { style: { margin: `0 0 6px` }, children: e3 }, e3)), (0, V.jsxs)(`p`, { style: { margin: 0 }, children: [`Asked for by `, Je(n2.origin), `.`] })] }), (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: Ye, children: `What anyone will be able to read` }), (0, V.jsx)(`div`, { style: { ...Xe, whiteSpace: `pre-wrap`, wordBreak: `break-word` }, "data-testid": `directory-consent-values`, children: n2.values.length === 0 ? (0, V.jsx)(`span`, { children: `Nothing: none of your card is shown to anyone.` }) : n2.values.map((e3) => (0, V.jsx)(`div`, { children: e3 }, e3)) })] }), (0, V.jsxs)(`div`, { children: [(0, V.jsx)(`div`, { style: Ye, children: `Signed as` }), (0, V.jsx)(`div`, { style: Xe, children: (0, V.jsx)(b, { value: n2.member }) })] }), (0, V.jsx)(`p`, { style: { color: `var(--w-muted)`, lineHeight: 1.45, margin: 0 }, children: n2.closing }), (0, V.jsxs)(`div`, { style: { display: `flex`, justifyContent: `flex-end`, gap: 8, marginTop: 8 }, children: [(0, V.jsx)(`button`, { autoFocus: true, onClick: () => t2(false), style: { padding: `8px 16px`, fontSize: 13 }, children: `Don\u2019t publish` }), (0, V.jsx)(`button`, { onClick: () => t2(true), style: { padding: `8px 18px`, fontSize: 13, fontWeight: 700, border: `none`, borderRadius: 8, color: `var(--w-accent-ink)`, background: `var(--w-accent)`, cursor: `pointer` }, children: `Sign and publish` })] })] }) : (0, V.jsx)(`div`, { style: { padding: 20, fontSize: 13 }, children: `Loading request\u2026` });
}
function Qe() {
  return { send: (e2) => chrome.runtime.sendMessage(e2), close: () => window.close() };
}
function $e(e2, t2 = Qe()) {
  let n2 = false;
  return async (r2) => {
    if (!n2) {
      n2 = true;
      try {
        await t2.send({ type: ue, consentId: e2, ...r2 });
      } catch {
      }
      t2.close();
    }
  };
}
function et({ sessionKey: e2 }) {
  return (0, V.jsxs)(`div`, { role: `note`, "data-testid": `session-key-notice`, style: { border: `1px solid var(--w-warn)`, background: `var(--w-warn-soft)`, borderRadius: 10, padding: 12, marginBottom: 12, fontSize: 12 }, children: [(0, V.jsx)(`strong`, { style: { display: `block`, marginBottom: 4, color: `var(--w-text)` }, children: `This site will get a session key` }), (0, V.jsx)(`p`, { style: { margin: `0 0 6px`, color: `var(--w-text)` }, children: `For this sign-in only, the site can sign requests as you without asking the wallet again. The key stops working when you sign out or the session ends. It cannot approve a step-up. That still needs this wallet.` }), (0, V.jsx)(`div`, { style: { color: `var(--w-faint)`, fontSize: 11, marginBottom: 2 }, children: `Session key:` }), (0, V.jsx)(`div`, { style: { wordBreak: `break-all`, fontSize: 11, fontFamily: `ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace` }, children: e2 })] });
}
function tt(e2) {
  return e2 instanceof F || e2 instanceof v && e2.reason === `no-prf-output` || e2?.name === `NotSupportedError`;
}
var nt = 6, rt = 2e3, it = { offersPrf: me, enrolled: S, enrol: x, unlock: async (e2) => (await y(chrome.runtime.id, e2)).prfOutput }, at = 1200, G = { overflowWrap: `anywhere`, minWidth: 0 }, ot = { method: { color: f.faint }, opaque: { color: f.muted }, host: { color: f.text, fontWeight: 620 }, path: { color: f.faint } };
function st({ value: e2, toggle: t2 = false }) {
  let [n2, r2] = (0, B.useState)(false), i2 = n2 ? [{ text: e2, role: `opaque` }] : p(e2), a2 = i2.map((e3) => e3.text).join(``) !== e2;
  return (0, V.jsxs)(`span`, { style: G, children: [(0, V.jsx)(`span`, { title: e2, style: { fontFamily: c.mono, fontSize: k.sm, ...G }, children: i2.map((e3, t3) => (0, V.jsx)(`span`, { style: n2 ? { color: f.text } : ot[e3.role], children: e3.text }, t3)) }), t2 && (a2 || n2) && (0, V.jsx)(`button`, { type: `button`, onClick: () => r2((e3) => !e3), "aria-expanded": n2, style: { ...d(`quiet`), padding: `0 4px`, fontSize: k.xs, color: f.accent, marginLeft: 4 }, children: n2 ? `Show less` : `Show full` })] });
}
function ct({ value: e2 }) {
  return e2.startsWith(`did:`) ? (0, V.jsx)(st, { value: e2, toggle: true }) : (0, V.jsx)(`strong`, { style: G, children: e2 });
}
function K({ origin: e2, testId: t2 }) {
  let n2 = ``, r2 = e2, i2 = ``;
  try {
    let t3 = new URL(e2);
    n2 = `${t3.protocol}//`, r2 = t3.hostname, i2 = t3.port ? `:${t3.port}` : ``;
  } catch {
  }
  return (0, V.jsxs)(`span`, { "data-testid": t2, title: e2, style: { ...G, fontSize: k.md }, children: [(0, V.jsx)(`span`, { style: { color: f.faint }, children: n2 }), (0, V.jsx)(`span`, { style: { color: f.text, fontWeight: 650 }, children: r2 }), (0, V.jsx)(`span`, { style: { color: f.faint }, children: i2 })] });
}
function lt({ who: e2 }) {
  return (0, V.jsxs)(`header`, { style: { display: `grid`, gap: 14, marginBottom: 14 }, children: [(0, V.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 9 }, children: [(0, V.jsx)(ee, {}), (0, V.jsx)(`span`, { style: { fontWeight: 640, fontSize: k.sm, letterSpacing: `-0.01em` }, children: `VTA Wallet` }), (0, V.jsx)(`span`, { style: { marginLeft: `auto`, fontSize: k.xs, color: f.faint }, children: `Sign-in request` })] }), e2 && (0, V.jsxs)(`div`, { style: { display: `grid`, gap: 3, minWidth: 0 }, children: [(0, V.jsx)(`div`, { style: l, children: `Community \xB7 your wallet's record` }), (0, V.jsx)(`div`, { "data-testid": `community`, style: { fontSize: k.lg, fontWeight: 650, lineHeight: 1.25, ...G }, children: e2.community }), e2.subtitle && (0, V.jsx)(`div`, { "data-testid": `subtitle`, style: { fontSize: k.sm, color: f.muted, ...G }, children: e2.subtitle }), (0, V.jsxs)(`div`, { style: { display: `flex`, alignItems: `baseline`, gap: 6, flexWrap: `wrap`, marginTop: 4, minWidth: 0 }, children: [(0, V.jsx)(`span`, { style: { fontSize: k.sm, color: f.muted }, children: `at` }), (0, V.jsx)(K, { origin: e2.origin, testId: `portal` })] }), (0, V.jsx)(`div`, { style: { fontSize: k.xs, color: f.faint }, children: `From its verified DID document. Check it matches the website's address.` })] })] });
}
function ut(e2, t2) {
  (0, B.useEffect)(() => {
    let n2 = (n3) => {
      if (!(n3.defaultPrevented || n3.isComposing || n3.altKey || n3.ctrlKey || n3.metaKey)) {
        if (n3.key === `Escape` && t2 && !t2.disabled) n3.preventDefault(), t2.run();
        else if (n3.key === `Enter` && e2 && !e2.disabled) {
          if (n3.target?.closest?.(`button, a, summary, textarea, select`)) return;
          n3.preventDefault(), e2.run();
        }
      }
    };
    return addEventListener(`keydown`, n2), () => removeEventListener(`keydown`, n2);
  }, [e2, t2]);
}
function dt({ action: e2, kind: t2 }) {
  return (0, V.jsx)(`button`, { type: `button`, "data-testid": e2.testId, disabled: e2.disabled, onClick: e2.run, style: { ...d(e2.kind ?? t2), fontSize: k.base, padding: `9px 18px`, minWidth: 104, ...e2.disabled ? { opacity: 0.5, cursor: `default` } : {} }, children: e2.label });
}
function q({ who: e2, title: t2, icon: n2, primary: r2, secondary: i2, escape: a2, children: o2 }) {
  return ut(r2, i2 ?? a2), (0, V.jsxs)(`div`, { style: { maxWidth: 520, margin: `0 auto`, padding: `18px 20px 24px`, boxSizing: `border-box`, fontSize: k.base, lineHeight: 1.5, color: f.text, minWidth: 0 }, children: [(0, V.jsx)(lt, { who: e2 }), (0, V.jsxs)(`main`, { style: { background: f.surface, border: `1px solid ${f.line}`, borderRadius: h.lg, padding: `18px 20px`, display: `grid`, gap: 14, minWidth: 0 }, children: [(0, V.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 10, minWidth: 0 }, children: [n2, (0, V.jsx)(`h1`, { style: { fontSize: k.md, fontWeight: 650, margin: 0, lineHeight: 1.3, ...G }, children: t2 })] }), o2, (r2 || i2) && (0, V.jsxs)(`footer`, { style: { display: `flex`, justifyContent: `flex-end`, gap: 10, flexWrap: `wrap`, borderTop: `1px solid ${f.lineSoft}`, paddingTop: 14, marginTop: 2 }, children: [i2 && (0, V.jsx)(dt, { action: i2, kind: `default` }), r2 && (0, V.jsx)(dt, { action: r2, kind: `primary` })] })] })] });
}
function J({ children: e2, muted: t2 = false }) {
  return (0, V.jsx)(`p`, { "data-testid": `message`, style: { margin: 0, color: t2 ? f.muted : f.text, ...G }, children: e2 });
}
function Y({ tone: e2 }) {
  let t2 = e2 === `ok` ? f.ok : e2 === `warn` ? f.warn : e2 === `danger` ? f.danger : f.faint, n2 = e2 === `ok` ? f.okSoft : e2 === `warn` ? f.warnSoft : e2 === `danger` ? f.dangerSoft : f.raised;
  return (0, V.jsx)(`span`, { "aria-hidden": true, style: { width: 26, height: 26, borderRadius: 999, background: n2, display: `grid`, placeItems: `center`, flex: `none` }, children: (0, V.jsx)(`svg`, { width: `14`, height: `14`, viewBox: `0 0 14 14`, fill: `none`, stroke: t2, strokeWidth: `2`, strokeLinecap: `round`, children: e2 === `ok` ? (0, V.jsx)(`path`, { d: `M3 7.5l2.5 2.5L11 4.5` }) : e2 === `off` ? (0, V.jsx)(`path`, { d: `M4 7h6` }) : (0, V.jsxs)(V.Fragment, { children: [(0, V.jsx)(`path`, { d: `M7 3.5v4.5` }), (0, V.jsx)(`path`, { d: `M7 10.5v.01` })] }) }) });
}
function ft({ deadline: e2, now: t2 }) {
  let [n2, r2] = (0, B.useState)(t2);
  (0, B.useEffect)(() => {
    let e3 = setInterval(() => r2(t2()), 1e3);
    return () => clearInterval(e3);
  }, [t2]);
  let i2 = Math.max(0, Math.ceil((e2 - n2) / 1e3));
  if (i2 === 0) return (0, V.jsx)(`div`, { "data-testid": `countdown`, style: { fontSize: k.sm, color: f.warn, textAlign: `center` }, children: `The time to decide has passed. If the website refuses, refresh the code there.` });
  let a2 = `${Math.floor(i2 / 60)}:${String(i2 % 60).padStart(2, `0`)}`;
  return (0, V.jsxs)(`div`, { "data-testid": `countdown`, style: { fontSize: k.sm, color: i2 <= 20 ? f.warn : f.muted, textAlign: `center` }, children: [`Time left to decide`, ` `, (0, V.jsx)(`span`, { style: { fontVariantNumeric: `tabular-nums`, fontWeight: 600 }, children: a2 })] });
}
function pt({ result: e2 }) {
  let t2 = ne(e2);
  return t2.length === 0 ? null : (0, V.jsxs)(`details`, { "data-testid": `failure-details`, style: { fontSize: k.xs, color: f.muted }, children: [(0, V.jsx)(`summary`, { style: { cursor: `pointer`, color: f.muted, width: `fit-content` }, children: `Details` }), (0, V.jsx)(`dl`, { style: { display: `grid`, gridTemplateColumns: `auto minmax(0, 1fr)`, gap: `3px 12px`, margin: `8px 0 0` }, children: t2.map(([e3, t3]) => (0, V.jsxs)(`div`, { style: { display: `contents` }, children: [(0, V.jsx)(`dt`, { style: { color: f.faint }, children: e3 }), (0, V.jsx)(`dd`, { style: { margin: 0, fontFamily: e3 === `Code` || e3 === `Cause` ? c.mono : void 0, ...G }, children: e3 === `DID` ? (0, V.jsx)(mt, { did: t3, testId: `details-did` }) : t3 })] }, e3)) })] });
}
function mt({ did: e2, testId: t2 = `unlisted-did` }) {
  let [n2, r2] = (0, B.useState)(), i2 = () => {
    let t3 = globalThis.navigator?.clipboard;
    if (!t3) {
      r2(`no`);
      return;
    }
    t3.writeText(e2).then(() => r2(`yes`), () => r2(`no`));
  };
  return (0, V.jsxs)(`div`, { style: { display: `grid`, gridTemplateColumns: `minmax(0, 1fr) auto`, gap: 10, alignItems: `center`, padding: `10px 12px`, borderRadius: h.md, background: f.raised, border: `1px solid ${f.lineSoft}`, minWidth: 0 }, children: [(0, V.jsx)(`code`, { "data-testid": t2, style: { fontFamily: c.mono, fontSize: k.sm, ...G }, children: e2 }), (0, V.jsx)(`button`, { type: `button`, "data-testid": `copy-did`, onClick: i2, style: { ...d(`default`), fontSize: k.sm, padding: `5px 12px` }, children: n2 === `yes` ? `Copied` : n2 === `no` ? `Copy failed` : `Copy` })] });
}
var ht = { expired: `Code expired`, update: `Update needed`, unreachable: `Community unreachable`, invalid: `Code not accepted` }, gt = { page: `The DID was read off the code on the page you were on.`, camera: `The DID was read off the code your camera saw.`, image: `The DID was read off the code in the image you gave.`, pasted: `The DID is the one you pasted.` };
function _t({ flowId: e2, send: t2, uv: n2, close: r2, now: i2, approvedCloseMs: a2 = at, pollMs: o2 = rt, openPortal: s2 = (e3) => void window.open(e3, `_blank`, `noopener`), allowOrigins: u2 = w }) {
  let p2 = t2 ?? ((t3) => chrome.runtime.sendMessage({ type: `vta-wallet/sign-in-step`, flowId: e2, ...t3 })), m2 = n2 ?? it, g2 = r2 ?? (() => window.close()), [y2] = (0, B.useState)(() => i2 ?? Date.now), [b2, x2] = (0, B.useState)({ kind: `loading` }), [S2, C2] = (0, B.useState)(), [T2, E2] = (0, B.useState)(``), [D2, O2] = (0, B.useState)(``), [ee2, A2] = (0, B.useState)(``), j2 = (0, B.useRef)(0), [ne2, M2] = (0, B.useState)(``), [N2, re2] = (0, B.useState)(``), [ie2, ae2] = (0, B.useState)(``), [oe2, se2] = (0, B.useState)([]), [P2, F2] = (0, B.useState)(``), [le2, ue2] = (0, B.useState)({}), [de2, fe2] = (0, B.useState)(false), [pe2, he2] = (0, B.useState)(false), [ge2, _e2] = (0, B.useState)(``), [I2, ve2] = (0, B.useState)(), [L2, ye2] = (0, B.useState)(false), [be2, R2] = (0, B.useState)(), z2 = async (e3) => {
    ye2(true), R2(void 0);
    try {
      let t3 = await p2(e3);
      if (!t3 || !t3.ok) {
        x2({ kind: `failed`, code: `sign-in/failed`, message: t3?.error ?? `The wallet did not answer.` });
        return;
      }
      if (t3.result.kind === `confirm`) {
        M2(t3.result.portalOrigin), re2(t3.result.communityName), se2(t3.result.identities), ae2(t3.result.identities[0]?.entryId ?? ``);
        let e4 = t3.result.identities.length === 1 ? t3.result.identities[0] : void 0;
        if (e4) return x2({ kind: `connecting` }), await z2({ step: `claim`, entryId: e4.entryId });
      }
      if (t3.result.kind === `join-community` && M2(t3.result.portalOrigin), t3.result.kind === `join-apply`) {
        M2(t3.result.portalOrigin), he2(t3.result.terms?.status === `offered` && t3.result.terms.enabled);
        let e4 = t3.result.identities.filter((e5) => !e5.usedAt?.length);
        F2(t3.result.identities.length === 1 && e4.length === 1 ? e4[0].did : ``);
      }
      return t3.result.kind === `join-hosting` && (M2(t3.result.portalOrigin), F2(t3.result.identities.length === 1 ? t3.result.identities[0].did : ``)), (t3.result.kind === `enter-number` || t3.result.kind === `review`) && ve2(t3.result.decisionDeadline), t3.result.kind === `review` && C2(t3.result), t3.result.kind !== `uv-challenge` && t3.result.kind !== `uv-approvers` && x2(t3.result), t3.result;
    } finally {
      ye2(false);
    }
  };
  (0, B.useEffect)(() => {
    z2({ step: `prepare` });
  }, []);
  let xe2 = b2.kind === `done` && b2.decision === `approve`;
  (0, B.useEffect)(() => {
    if (!xe2) return;
    let e3 = setTimeout(g2, a2);
    return () => clearTimeout(e3);
  }, [xe2]), (0, B.useEffect)(() => {
    if (b2.kind !== `uv-pending`) return;
    let e3 = j2.current, t3 = setTimeout(() => {
      (async () => {
        if (e3 !== j2.current) return;
        if (I2 !== void 0 && y2() >= I2) {
          j2.current++, await p2({ step: `cancel` }).catch(() => void 0), x2({ kind: `failed`, code: `oobUvExpired`, message: `Your phone didn't approve this sign-in in time. Refresh the code on the website and try again.` });
          return;
        }
        let t4 = await p2({ step: `respond`, decision: `approve`, remote: true }).catch(() => void 0);
        if (e3 === j2.current) {
          if (!t4 || !t4.ok) {
            x2({ kind: `failed`, code: `sign-in/failed`, message: t4?.error ?? `The wallet did not answer.` });
            return;
          }
          x2({ ...t4.result });
        }
      })();
    }, o2);
    return () => clearTimeout(t3);
  }, [b2]);
  let Se2 = (e3) => {
    j2.current++, E2(``), O2(``), S2 && x2(S2), R2(e3);
  }, Ce2 = (e3) => {
    R2(void 0), x2(e3 ? { kind: `uv-choose`, noPrf: true } : { kind: `uv-choose` });
  }, we2 = async () => {
    let e3 = S2?.uvMethod;
    if (e3 === `vtaPin`) {
      E2(``), R2(void 0), x2({ kind: `uv-pin` });
      return;
    }
    if (e3 === `remoteApprover`) {
      await Ee2();
      return;
    }
    let t3 = (e4) => R2(e4 instanceof v && e4.reason === `cancelled` ? `Approval cancelled.` : String(e4.message ?? e4));
    if (e3 === void 0 && !await m2.enrolled() && await (m2.offersPrf ?? me)() === false) {
      Ce2(true);
      return;
    }
    let n3 = await z2({ step: `grant-digest` });
    if (n3?.kind !== `uv-challenge`) return;
    let r3;
    try {
      await m2.enrolled() || await m2.enrol(n3.vtaDid), r3 = await m2.unlock(n3.challenge);
    } catch (n4) {
      if (e3 === void 0 && tt(n4)) {
        Ce2(true);
        return;
      }
      t3(n4);
      return;
    }
    await z2({ step: `respond`, decision: `approve`, prfOutputB64u: ce(r3) });
  }, Te2 = async (e3) => {
    let t3 = T2;
    if (E2(``), O2(``), (await z2({ step: `grant-digest` }))?.kind !== `uv-challenge`) return;
    let n3 = await z2(e3 ? { step: `respond`, decision: `approve`, pin: t3, setPin: true } : { step: `respond`, decision: `approve`, pin: t3 });
    e3 && n3?.kind === `uv-pin` && S2 && C2({ ...S2, uvMethod: `vtaPin` });
  }, Ee2 = async (e3) => {
    if (j2.current++, R2(void 0), (await z2({ step: `grant-digest` }))?.kind !== `uv-challenge`) return;
    let t3 = await z2({ step: `respond`, decision: `approve`, remote: true, ...e3 ? { approver: e3 } : {} });
    e3 && t3?.kind === `uv-pending` && S2 && C2({ ...S2, uvMethod: `remoteApprover` });
  }, De2 = async () => {
    R2(void 0), A2(``), x2({ kind: `uv-phone` });
    let e3 = await p2({ step: `uv-approvers` }).catch(() => void 0);
    if (!e3 || !e3.ok) {
      x2({ kind: `uv-phone`, approvers: [], error: e3?.error ?? `The wallet did not answer.` });
      return;
    }
    if (e3.result.kind !== `uv-approvers`) {
      x2(e3.result);
      return;
    }
    let t3 = e3.result.approvers;
    t3.length === 1 && A2(t3[0].did), x2({ kind: `uv-phone`, approvers: t3, ...e3.result.error ? { error: e3.result.error } : {} });
  }, H2 = N2 ? { community: N2, origin: ne2 } : void 0, Oe2 = H2 && { ...H2, subtitle: `Operator console` }, U2 = { label: `Close`, run: g2, testId: `close` }, W2 = { label: `Decline`, run: () => void z2({ step: `cancel` }).then(g2), disabled: L2, testId: `decline` };
  switch (b2.kind) {
    case `loading`:
      return (0, V.jsx)(q, { title: `Checking this sign-in code\u2026`, children: (0, V.jsx)(J, { muted: true, children: `Your wallet is checking who sent this code. Nothing has been sent to anyone yet.` }) });
    case `connecting`:
      return (0, V.jsx)(q, { who: H2, title: `Signing in to ${N2}\u2026`, children: (0, V.jsx)(J, { muted: true, children: `Matching the number the website shows. You'll approve the sign-in next.` }) });
    case `refused`:
      return (0, V.jsxs)(q, { title: ht[b2.outcome] ?? `Sign in`, icon: (0, V.jsx)(Y, { tone: `warn` }), primary: U2, escape: U2, children: [(0, V.jsx)(J, { children: b2.message }), (0, V.jsx)(pt, { result: b2 })] });
    case `join-hosting`:
      return (0, V.jsxs)(q, { title: `Use ${b2.host} to host your DIDs?`, primary: { label: `Use ${b2.host}`, run: () => void z2({ step: `join`, did: P2 }), disabled: L2 || !P2, testId: `join` }, secondary: { label: `Not now`, run: () => void z2({ step: `cancel` }).then(g2), disabled: L2, testId: `decline` }, children: [(0, V.jsxs)(`p`, { style: { margin: 0, ...G }, children: [(0, V.jsx)(K, { origin: b2.portalOrigin, testId: `portal` }), ` is a DID hosting service your wallet hasn't used before. Its address is from its verified DID document; check it matches the website's.`] }), (0, V.jsx)(`p`, { style: { margin: 0, color: f.muted }, children: `Nothing has been sent to it. If you go ahead, your wallet remembers it and signs you in with the identity you choose.` }), b2.identities.length === 0 ? (0, V.jsx)(_, { tone: `warn`, children: (0, V.jsx)(`div`, { "data-testid": `no-identities`, style: G, children: `Your agent hosts no identities yet, so there is nothing to sign in as. Create one in the wallet and try again.` }) }) : (0, V.jsxs)(`fieldset`, { style: { border: `none`, margin: 0, padding: 0, display: `grid`, gap: 8, minWidth: 0 }, children: [(0, V.jsx)(`legend`, { style: { ...l, padding: 0, marginBottom: 8 }, children: `Sign in as` }), b2.identities.map((e3) => {
        let t3 = P2 === e3.did;
        return (0, V.jsxs)(`label`, { style: { display: `grid`, gridTemplateColumns: `auto minmax(0, 1fr)`, gap: `2px 10px`, alignItems: `start`, padding: `10px 12px`, borderRadius: h.md, border: `1px solid ${t3 ? f.accent : f.line}`, background: t3 ? f.accentSoft : f.surface, cursor: `pointer`, minWidth: 0 }, children: [(0, V.jsx)(`input`, { type: `radio`, name: `persona`, value: e3.did, checked: t3, onChange: () => F2(e3.did), style: { accentColor: f.accent, margin: `3px 0 0`, padding: 0 } }), (0, V.jsx)(st, { value: e3.did }), (0, V.jsx)(`span`, {}), (0, V.jsx)(`span`, { style: { fontSize: k.xs, color: f.faint, ...G }, children: e3.contextId })] }, e3.did);
      })] }), (0, V.jsxs)(`p`, { style: { margin: 0, fontSize: k.sm, color: f.muted, ...G }, children: [b2.host, ` admits only identities its operator has added. If it hasn't added this one yet, the wallet will show you the DID to send them.`] })] });
    case `join-community`:
      return (0, V.jsxs)(q, { title: `Join ${b2.host}?`, primary: { label: `See what it asks`, run: () => void u2([b2.portalOrigin, b2.trustTaskOrigin]).then((e3) => {
        if (e3) return z2({ step: `join-manifest` });
        R2(`Your wallet needs permission to reach ${b2.host} to ask it anything. Nothing was sent.`);
      }, () => R2(`Your wallet needs permission to reach ${b2.host} to ask it anything. Nothing was sent.`)), disabled: L2, testId: `join-manifest` }, secondary: { label: `Not now`, run: () => void z2({ step: `cancel` }).then(g2), disabled: L2, testId: `decline` }, children: [(0, V.jsxs)(`p`, { style: { margin: 0, ...G }, children: [(0, V.jsx)(K, { origin: b2.portalOrigin, testId: `portal` }), ` is a community you're not a member of. Its address is from its verified DID document;`, ` `, b2.source ? `check it is the community you meant. ${gt[b2.source]}` : `check it matches the website's.`] }), (0, V.jsx)(`p`, { style: { margin: 0, color: f.muted }, children: `Nothing has been sent to it. If you continue, your wallet asks it what it requires to join, without saying who you are.` })] });
    case `already-member`:
      return (0, V.jsxs)(q, { title: `You're already in ${b2.communityName}`, icon: (0, V.jsx)(Y, { tone: `ok` }), primary: { label: `Open the member page`, run: () => {
        s2(b2.portalOrigin), g2();
      }, testId: `open-portal` }, secondary: U2, children: [(0, V.jsx)(J, { children: `This DID is a community your wallet already signs in to. Nothing was sent.` }), (0, V.jsxs)(`p`, { style: { margin: 0, color: f.muted, ...G }, children: [`Sign in from `, (0, V.jsx)(K, { origin: b2.portalOrigin, testId: `portal` }), `.`] })] });
    case `not-a-community`:
      return (0, V.jsxs)(q, { title: `Not a community`, icon: (0, V.jsx)(Y, { tone: `off` }), primary: U2, escape: U2, children: [(0, V.jsx)(J, { children: `This DID's verified document doesn't describe a community you can join. Nothing was sent to it.` }), (0, V.jsx)(`p`, { style: { margin: 0, color: f.muted, ...G }, children: (0, V.jsx)(st, { value: b2.did, toggle: true }) }), b2.portalOrigin && (0, V.jsxs)(`p`, { style: { margin: 0, color: f.muted, ...G }, children: [`Its sign-in page is`, ` `, (0, V.jsx)(K, { origin: b2.portalOrigin, testId: `portal` }), `.`] })] });
    case `join-admitted`:
      return (0, V.jsxs)(q, { title: `You're in${b2.displayName ? `: ${b2.displayName}` : ``}`, icon: (0, V.jsx)(Y, { tone: `ok` }), primary: { label: `Open the member page`, run: () => {
        s2(b2.portalOrigin), g2();
      }, testId: `open-portal` }, secondary: U2, children: [(0, V.jsxs)(J, { children: [b2.host, ` admitted you`, b2.role ? ` as ${b2.role}` : ``, `. Your wallet remembers the identity you joined as, so signing in there works from now on.`] }), b2.terms && (0, V.jsxs)(`p`, { style: { margin: 0, color: f.muted, ...G }, "data-testid": `terms-record`, children: [`Joined under `, b2.terms.code, `. Agreement `, b2.terms.agreementId, `.`] }), (0, V.jsxs)(`p`, { style: { margin: 0, color: f.muted, ...G }, children: [`Sign in from `, (0, V.jsx)(K, { origin: b2.portalOrigin, testId: `portal` }), `.`] })] });
    case `join-apply`: {
      let e3 = b2.attributes.some((e4) => e4.required && !(le2[e4.type] ?? ``).trim());
      return (0, V.jsxs)(q, { title: `Ask to join ${b2.host}`, primary: { label: `Send request`, run: () => void z2({ step: `join-submit`, did: P2, attributes: b2.attributes.map((e4) => ({ type: e4.type, value: (le2[e4.type] ?? ``).trim() })).filter((e4) => e4.value !== ``), registryConsent: de2, ...b2.terms?.status === `offered` && pe2 ? { terms: { code: b2.terms.code } } : {} }), disabled: L2 || !P2 || e3, testId: `join-submit` }, secondary: { label: `Not now`, run: () => void z2({ step: `cancel` }).then(g2), disabled: L2, testId: `decline` }, children: [(0, V.jsxs)(`p`, { style: { margin: 0, ...G }, children: [(0, V.jsx)(K, { origin: b2.portalOrigin, testId: `portal` }), b2.displayName ? (0, V.jsxs)(V.Fragment, { children: [` `, `calls itself`, ` `, (0, V.jsx)(`strong`, { "data-testid": `display-name`, style: G, children: b2.displayName }), ` `, `(its own word, not checked)`] }) : null, `.`, ` `, (0, V.jsx)(`span`, { "data-testid": `admission`, children: b2.admission === `automatic` ? `It admits members straight away.` : `An administrator reviews each request.` })] }), b2.directory ? (0, V.jsxs)(`section`, { "data-testid": `directory-disclosure`, style: { display: `grid`, gap: 6, minWidth: 0 }, children: [(0, V.jsx)(`div`, { style: { ...l, padding: 0 }, children: `What the directory will show about you` }), (0, V.jsx)(`ul`, { style: { margin: 0, paddingLeft: 18, display: `grid`, gap: 4, color: f.muted, ...G }, children: b2.directory.lines.map((e4) => (0, V.jsx)(`li`, { children: e4 }, e4)) })] }) : null, b2.terms ? (0, V.jsxs)(`section`, { "data-testid": `join-terms`, style: { display: `grid`, gap: 6, minWidth: 0 }, children: [(0, V.jsx)(`div`, { style: { ...l, padding: 0 }, children: `Your terms (MyTerms)` }), b2.terms.status === `offered` ? (0, V.jsxs)(V.Fragment, { children: [(0, V.jsxs)(`label`, { style: { display: `grid`, gridTemplateColumns: `auto minmax(0, 1fr)`, gap: 10, alignItems: `start`, cursor: `pointer` }, children: [(0, V.jsx)(`input`, { type: `checkbox`, "data-testid": `terms-on`, checked: pe2, onChange: (e4) => he2(e4.target.checked), style: { accentColor: f.accent, margin: `3px 0 0` } }), (0, V.jsxs)(`span`, { style: { fontSize: k.sm, ...G }, children: [`Join under `, (0, V.jsx)(`strong`, { "data-testid": `terms-code`, children: b2.terms.code }), ` `, `\u2014 `, b2.terms.title, `. `, b2.terms.meaning] })] }), (0, V.jsxs)(`p`, { style: { margin: 0, fontSize: k.sm, color: f.muted, ...G }, children: [b2.terms.counter ? b2.terms.declined ? `${b2.host} doesn't accept your standing terms (${b2.terms.declined}); this is its counter-offer, the most protective agreement it accepts.` : `You have no standing terms yet; this is ${b2.host}'s most protective agreement. Set yours in Settings.` : `Your standing terms, which it accepts.`, ` `, `It accepts `, b2.terms.accepts.join(`, `), `. The agreement goes inside your signed request; `, b2.host, `'s signed answer is the other half of the record, and your wallet keeps both.`] })] }) : b2.terms.status === `no-match` ? (0, V.jsxs)(`p`, { style: { margin: 0, fontSize: k.sm, color: f.muted, ...G }, children: [b2.host, ` takes terms, but none this wallet knows`, b2.terms.accepts.length ? ` (${b2.terms.accepts.join(`, `)})` : ``, `. The request goes without terms.`] }) : (0, V.jsxs)(`p`, { style: { margin: 0, fontSize: k.sm, color: f.muted, ...G }, children: [b2.host, ` names terms its wallet-readable configuration couldn't be read from. The request goes without terms.`] })] }) : null, b2.identities.length === 0 ? (0, V.jsx)(_, { tone: `warn`, children: (0, V.jsx)(`div`, { "data-testid": `no-identities`, style: G, children: `Your agent hosts no identities yet, so there is nothing to join as. Create one in the wallet and try again.` }) }) : (0, V.jsxs)(`fieldset`, { style: { border: `none`, margin: 0, padding: 0, display: `grid`, gap: 8, minWidth: 0 }, children: [(0, V.jsx)(`legend`, { style: { ...l, padding: 0, marginBottom: 8 }, children: `Join as` }), b2.identities.map((e4) => {
        let t3 = P2 === e4.did;
        return (0, V.jsxs)(`label`, { style: { display: `grid`, gridTemplateColumns: `auto minmax(0, 1fr)`, gap: `2px 10px`, alignItems: `start`, padding: `10px 12px`, borderRadius: h.md, border: `1px solid ${t3 ? f.accent : f.line}`, background: t3 ? f.accentSoft : f.surface, cursor: `pointer`, minWidth: 0 }, children: [(0, V.jsx)(`input`, { type: `radio`, name: `applicant`, value: e4.did, checked: t3, onChange: () => F2(e4.did), style: { accentColor: f.accent, margin: `3px 0 0`, padding: 0 } }), (0, V.jsx)(st, { value: e4.did }), (0, V.jsx)(`span`, {}), (0, V.jsx)(`span`, { style: { fontSize: k.xs, color: f.faint, ...G }, children: e4.usedAt?.length ? `Also used at ${e4.usedAt.join(`, `)}` : e4.contextId })] }, e4.did);
      })] }), b2.attributes.length > 0 && (0, V.jsxs)(`div`, { style: { display: `grid`, gap: 8, minWidth: 0 }, children: [(0, V.jsx)(`div`, { style: { ...l }, children: `It asks you to tell it` }), b2.attributes.map((e4) => (0, V.jsxs)(`label`, { style: { display: `grid`, gap: 4, minWidth: 0 }, children: [(0, V.jsxs)(`span`, { style: { fontSize: k.sm, ...G }, children: [(0, V.jsx)(`code`, { style: { fontFamily: c.mono }, children: e4.type }), e4.required ? ` (required)` : ` (optional)`, e4.purpose ? (0, V.jsxs)(`span`, { style: { color: f.muted }, children: [` \u2014 `, e4.purpose] }) : null] }), (0, V.jsx)(`input`, { type: `text`, "data-testid": `attribute-${e4.type}`, autoComplete: `off`, value: le2[e4.type] ?? ``, onChange: (t3) => ue2((n3) => ({ ...n3, [e4.type]: t3.target.value })), style: { font: `inherit`, padding: `7px 10px`, background: f.ground, color: f.text, border: `1px solid ${f.line}`, borderRadius: h.md, minWidth: 0 } })] }, e4.type)), (0, V.jsx)(`span`, { style: { fontSize: k.xs, color: f.faint }, children: `What you type is sent as you typed it, signed by the identity you join as.` })] }), (0, V.jsxs)(`label`, { style: { display: `grid`, gridTemplateColumns: `auto minmax(0, 1fr)`, gap: 10, alignItems: `start`, cursor: `pointer` }, children: [(0, V.jsx)(`input`, { type: `checkbox`, "data-testid": `registry-consent`, checked: de2, onChange: (e4) => fe2(e4.target.checked), style: { accentColor: f.accent, margin: `3px 0 0` } }), (0, V.jsxs)(`span`, { style: { fontSize: k.sm, ...G }, children: [`List me in `, b2.host, `'s public member registry`] })] }), (0, V.jsxs)(`p`, { style: { margin: 0, fontSize: k.sm, color: f.muted, ...G }, children: [`Sending the request tells `, b2.host, ` the identity you chose. Your wallet remembers `, b2.host, ` for that identity.`] })] });
    }
    case `join-elsewhere`:
      return (0, V.jsx)(q, { title: b2.reason === `not-accepting` ? `${b2.host} isn't taking new members` : `${b2.host} needs more than your wallet can send`, icon: (0, V.jsx)(Y, { tone: `off` }), primary: U2, escape: U2, children: b2.reason === `not-accepting` ? (0, V.jsx)(J, { children: `It isn't accepting requests to join right now. Nothing about you was sent to it.` }) : (0, V.jsxs)(V.Fragment, { children: [(0, V.jsx)(J, { children: `To join, it asks for something this wallet can't provide yet. Nothing about you was sent to it.` }), (0, V.jsx)(`ul`, { "data-testid": `join-needs`, style: { margin: 0, paddingLeft: 18, color: f.muted, ...G }, children: b2.needs.map((e3) => (0, V.jsx)(`li`, { children: e3 }, e3)) }), (0, V.jsxs)(`p`, { style: { margin: 0, color: f.muted, ...G }, children: [`Ask the community how to join. Its verified address is`, ` `, (0, V.jsx)(K, { origin: b2.portalOrigin, testId: `portal` }), `.`] })] }) });
    case `join-pending`:
      return (0, V.jsxs)(q, { title: `Request sent`, icon: (0, V.jsx)(Y, { tone: `ok` }), primary: U2, escape: U2, children: [(0, V.jsxs)(J, { children: [`You can sign in once `, b2.host, ` approves it. Nothing else was sent.`] }), b2.terms && (0, V.jsxs)(`p`, { style: { margin: 0, color: f.muted, ...G }, "data-testid": `terms-record`, children: [`Requested under `, b2.terms.code, `. Agreement `, b2.terms.agreementId, `.`] }), b2.needs?.length ? (0, V.jsxs)(V.Fragment, { children: [(0, V.jsx)(`p`, { style: { margin: 0, color: f.muted, ...G }, children: `Before it decides, it asks for:` }), (0, V.jsx)(`ul`, { "data-testid": `join-needs`, style: { margin: 0, paddingLeft: 18, color: f.muted, ...G }, children: b2.needs.map((e3) => (0, V.jsx)(`li`, { children: e3 }, e3)) })] }) : null, (0, V.jsxs)(`p`, { style: { margin: 0, color: f.muted, ...G }, children: [`Sign in from `, (0, V.jsx)(K, { origin: b2.portalOrigin, testId: `portal` }), ` `, `once you're in.`] })] });
    case `not-member`:
      return (0, V.jsxs)(q, { title: `Not one of your communities`, icon: (0, V.jsx)(Y, { tone: `off` }), primary: U2, escape: U2, children: [(0, V.jsxs)(J, { children: [`You're not a member of`, ` `, b2.contactLabel ? (0, V.jsx)(`strong`, { style: G, children: b2.contactLabel }) : `this community`, b2.contactLabel && !b2.portalOrigin ? ` (unverified)` : ``, `. Nothing was sent to it.`] }), b2.portalOrigin && (0, V.jsxs)(`p`, { style: { margin: 0, color: f.muted, ...G }, children: [`Its verified sign-in page is`, ` `, (0, V.jsx)(K, { origin: b2.portalOrigin, testId: `portal` }), `.`] }), (0, V.jsx)(`p`, { style: { margin: 0, color: f.muted }, children: `To sign in here, join the community first.` })] });
    case `confirm`:
      return (0, V.jsxs)(q, { who: { community: b2.communityName, origin: b2.portalOrigin }, title: `Sign in to ${b2.communityName}?`, primary: { label: `Continue`, run: () => void z2({ step: `claim`, entryId: ie2 }), disabled: L2 || !ie2, testId: `continue` }, secondary: W2, children: [(0, V.jsx)(`p`, { style: { margin: 0, color: f.muted }, children: `Nothing is sent to the community until you continue.` }), (0, V.jsxs)(`fieldset`, { style: { border: `none`, margin: 0, padding: 0, display: `grid`, gap: 8, minWidth: 0 }, children: [(0, V.jsx)(`legend`, { style: { ...l, padding: 0, marginBottom: 8 }, children: `Sign in as` }), oe2.map((e3) => {
        let t3 = ie2 === e3.entryId;
        return (0, V.jsxs)(`label`, { style: { display: `grid`, gridTemplateColumns: `auto minmax(0, 1fr)`, gap: `2px 10px`, alignItems: `start`, padding: `10px 12px`, borderRadius: h.md, border: `1px solid ${t3 ? f.accent : f.line}`, background: t3 ? f.accentSoft : f.surface, cursor: `pointer`, minWidth: 0 }, children: [(0, V.jsx)(`input`, { type: `radio`, name: `identity`, value: e3.entryId, checked: t3, onChange: () => ae2(e3.entryId), style: { accentColor: f.accent, margin: `3px 0 0`, padding: 0 } }), (0, V.jsx)(`span`, { style: { fontWeight: 600, ...G }, children: e3.label }), (0, V.jsx)(`span`, {}), (0, V.jsx)(st, { value: e3.did })] }, e3.entryId);
      })] })] });
    case `enter-number`:
      return (0, V.jsxs)(q, { who: b2.audience === `admin` ? Oe2 : H2, title: `Type the number on the screen`, primary: { label: `Continue`, run: () => void z2({ step: `prove`, enteredNumber: ge2 }), disabled: L2 || ge2.length !== 2, testId: `prove` }, secondary: W2, children: [b2.audience === `admin` && (0, V.jsx)(_, { tone: `accent`, children: (0, V.jsxs)(`div`, { "data-testid": `operator-console`, style: G, children: [`This signs you in to the community's`, ` `, (0, V.jsx)(`strong`, { children: `operator console` }), `, not its member portal. Only an identity the community holds as an administrator is admitted.`] }) }), b2.nameMismatch !== void 0 && (0, V.jsxs)(_, { tone: `warn`, children: [(0, V.jsxs)(`div`, { "data-testid": `name-mismatch`, style: G, children: [`The community calls itself`, ` `, (0, V.jsx)(ct, { value: b2.nameMismatch }), `, but your wallet knows it as `, (0, V.jsx)(`strong`, { style: G, children: N2 }), `. If you didn't expect that, decline.`] }), !/^did:/i.test(b2.nameMismatch.trim()) && (0, V.jsxs)(`button`, { type: `button`, "data-testid": `adopt-name`, disabled: L2, onClick: async () => {
        let e3 = b2.nameMismatch.trim().replace(/\s+/g, ` `), t3 = await z2({ step: `adopt-name` });
        t3 && !(t3.kind === `enter-number` && t3.adoptFailed) && re2(e3);
      }, style: { ...d(`default`), marginTop: 8, fontSize: k.sm, padding: `5px 12px`, ...G }, children: [`Call it `, b2.nameMismatch.trim(), ` in my wallet`] }), b2.adoptFailed !== void 0 && (0, V.jsxs)(`div`, { "data-testid": `adopt-failed`, style: { marginTop: 6, ...G }, children: [`Your wallet couldn't rename it: `, b2.adoptFailed] })] }), (0, V.jsxs)(`p`, { style: { margin: 0, ...G }, children: [`The website at `, (0, V.jsx)(K, { origin: ne2 }), ` is showing a two-digit number. Type it here.`] }), (0, V.jsxs)(`div`, { style: { display: `grid`, justifyItems: `center`, gap: 8, padding: `6px 0 2px` }, children: [(0, V.jsx)(`input`, { "data-testid": `number`, inputMode: `numeric`, pattern: `[0-9]*`, autoComplete: `off`, autoFocus: true, maxLength: 2, "aria-label": `The two-digit number the website shows`, value: ge2, onChange: (e3) => _e2(e3.target.value.replace(/[^0-9]/g, ``).slice(0, 2)), style: { fontFamily: c.mono, fontSize: 40, fontWeight: 600, fontVariantNumeric: `tabular-nums`, width: 132, padding: `8px 0 8px 0.3em`, letterSpacing: `0.3em`, textAlign: `center`, background: f.ground, color: f.text, border: `1.5px solid ${ge2.length === 2 ? f.accent : f.line}`, borderRadius: h.md } }), I2 !== void 0 && (0, V.jsx)(ft, { deadline: I2, now: y2 })] })] });
    case `review`: {
      let e3 = b2.location === `unknown`;
      return (0, V.jsxs)(q, { who: b2.audience === `admin` ? Oe2 : H2, title: b2.audience === `admin` ? `Approve this sign-in to the operator console?` : `Approve this sign-in?`, primary: { label: `Approve`, run: () => void we2(), disabled: L2, testId: `approve` }, secondary: { label: `Decline`, run: () => void z2({ step: `respond`, decision: `decline` }), disabled: L2, testId: `decline` }, children: [(0, V.jsxs)(`div`, { style: { display: `grid`, gap: 6, padding: `12px 14px`, borderRadius: h.md, background: f.raised, border: `1px solid ${f.lineSoft}`, minWidth: 0 }, children: [(0, V.jsx)(`div`, { style: l, children: `Request from \xB7 as the community reports it` }), (0, V.jsxs)(`div`, { "data-testid": `requester`, style: { fontWeight: 600, ...G }, children: [b2.browser, ` on `, b2.os, ` \xB7`, ` `, e3 ? `location unknown` : `near ${b2.location}`, ` `, `\xB7 `, new Date(b2.createdAt).toLocaleTimeString()] }), (0, V.jsx)(`div`, { "data-testid": `network`, style: { fontSize: k.sm, color: b2.network === `different` ? f.warn : b2.network === `same` ? f.ok : f.muted }, children: b2.network === `same` ? `Same network as this browser` : b2.network === `different` ? `Not on this browser's network. If you didn't start this sign-in, decline.` : `Network: can't tell` })] }), e3 && (0, V.jsx)(_, { tone: `warn`, children: `The community could not tell where this request came from.` }), b2.network === `different` && (0, V.jsx)(_, { tone: `warn`, children: `This request did not come from the network this browser is on.` }), (0, V.jsxs)(`p`, { style: { margin: 0, fontSize: k.sm, color: f.muted, ...G }, children: [`This signs in that browser`, b2.audience === `admin` ? ` to the operator console` : ``, ` at`, ` `, ne2, ` as `, (0, V.jsx)(st, { value: b2.identifiedAs }), `, for this session only.`, ` `, b2.uvMethod === `vtaPin` ? `Approving asks for your PIN.` : b2.uvMethod === `remoteApprover` ? `Approving asks your phone.` : `Approving asks for your passkey.`] }), b2.uvMethod === void 0 && (0, V.jsx)(`button`, { type: `button`, "data-testid": `uv-other`, disabled: L2, onClick: () => Ce2(false), style: { ...d(`quiet`), justifySelf: `start`, padding: `0 2px`, fontSize: k.sm, color: f.accent }, children: `Use a PIN or my phone instead` }), b2.signingScope && b2.signingScope.length > 0 && (0, V.jsx)(_, { tone: `accent`, children: (0, V.jsxs)(`span`, { "data-testid": `signing-scope`, children: [`It also lets that browser act as you, for this session, in:`, ` `, b2.signingScope.map(bt).join(`, `), `.`] }) }), I2 !== void 0 && (0, V.jsx)(ft, { deadline: I2, now: y2 }), be2 && (0, V.jsx)(_, { tone: `danger`, children: be2 })] });
    }
    case `done`:
      return b2.decision === `approve` ? (0, V.jsx)(q, { who: H2, title: `Approved`, icon: (0, V.jsx)(Y, { tone: `ok` }), primary: U2, escape: U2, children: (0, V.jsx)(J, { children: `Taking you back to the website\u2026` }) }) : (0, V.jsx)(q, { who: H2, title: `Declined`, icon: (0, V.jsx)(Y, { tone: `off` }), primary: U2, escape: U2, children: (0, V.jsx)(J, { children: `Nothing was approved. You can close this window.` }) });
    case `failed`:
      return b2.unlisted ? (0, V.jsxs)(q, { who: H2, title: `${b2.unlisted.host} hasn't added you yet`, icon: (0, V.jsx)(Y, { tone: `warn` }), primary: U2, escape: U2, children: [(0, V.jsx)(J, { children: b2.message }), (0, V.jsx)(mt, { did: b2.unlisted.did }), (0, V.jsxs)(`p`, { style: { margin: 0, color: f.muted, ...G }, children: [`Once it's on `, b2.unlisted.host, `'s access list, refresh the code on the website and sign in again.`] }), (0, V.jsx)(pt, { result: b2 })] }) : (0, V.jsxs)(q, { who: H2, title: `Sign-in stopped`, icon: (0, V.jsx)(Y, { tone: `danger` }), primary: U2, escape: U2, children: [(0, V.jsx)(J, { children: b2.message }), (0, V.jsx)(pt, { result: b2 })] });
    case `uv-choose`:
      return (0, V.jsxs)(q, { who: H2, title: `How should this browser approve sign-ins?`, secondary: { label: `Back`, run: () => Se2(), testId: `back` }, children: [b2.noPrf && (0, V.jsx)(_, { tone: `warn`, children: (0, V.jsx)(`span`, { "data-testid": `no-prf`, children: `This browser can't keep a passkey for approving. Choose another way.` }) }), (0, V.jsx)(vt, { testId: `choose-pin`, title: `Set a PIN`, run: () => {
        E2(``), O2(``), x2({ kind: `uv-set-pin` });
      }, children: `You type it each time you approve. Your agent checks it, and locks it for a while after 5 wrong tries.` }), (0, V.jsx)(vt, { testId: `choose-phone`, title: `Approve on my phone`, run: () => void De2(), children: `The wallet app on your phone asks you to approve each sign-in.` }), (0, V.jsx)(`p`, { style: { margin: 0, fontSize: k.sm, color: f.muted }, children: `Your wallet remembers this for your agent. You can change it in Settings.` })] });
    case `uv-set-pin`: {
      let e3 = T2.normalize(`NFC`).length < nt, t3 = D2.length > 0 && T2 !== D2;
      return (0, V.jsxs)(q, { who: H2, title: `Set a PIN`, primary: { label: `Set PIN and approve`, run: () => void Te2(true), disabled: L2 || e3 || T2 !== D2, testId: `set-pin` }, secondary: { label: `Back`, run: () => Ce2(false), disabled: L2, testId: `back` }, children: [(0, V.jsxs)(J, { children: [`You'll type this PIN each time you approve a sign-in from this browser. Use `, nt, ` or more characters: digits or a passphrase.`] }), (0, V.jsx)(yt, { testId: `pin`, label: `PIN`, value: T2, onChange: E2, autoFocus: true }), (0, V.jsx)(yt, { testId: `pin-again`, label: `PIN again`, value: D2, onChange: O2 }), t3 && (0, V.jsx)(_, { tone: `danger`, children: (0, V.jsx)(`span`, { "data-testid": `pin-mismatch`, children: `The two PINs don't match.` }) }), I2 !== void 0 && (0, V.jsx)(ft, { deadline: I2, now: y2 }), be2 && (0, V.jsx)(_, { tone: `danger`, children: be2 })] });
    }
    case `uv-phone`:
      return (0, V.jsxs)(q, { who: H2, title: `Approve on my phone`, primary: { label: `Use this phone`, run: () => void Ee2(ee2), disabled: L2 || !ee2, testId: `use-phone` }, secondary: { label: `Back`, run: () => Ce2(false), disabled: L2, testId: `back` }, children: [b2.approvers === void 0 ? (0, V.jsx)(J, { muted: true, children: `Asking your agent for your phone\u2026` }) : b2.approvers.length === 0 ? (0, V.jsx)(_, { tone: `warn`, children: (0, V.jsxs)(`div`, { "data-testid": `no-phones`, style: G, children: [te, b2.error && (0, V.jsxs)(`div`, { style: { marginTop: 6, color: f.muted }, children: [`Your agent said: `, b2.error] })] }) }) : (0, V.jsxs)(`fieldset`, { style: { border: `none`, margin: 0, padding: 0, display: `grid`, gap: 8, minWidth: 0 }, children: [(0, V.jsx)(`legend`, { style: { ...l, marginBottom: 6 }, children: `Your phones` }), b2.approvers.map((e3) => (0, V.jsxs)(`label`, { style: { display: `flex`, gap: 10, alignItems: `center`, cursor: `pointer`, minWidth: 0 }, children: [(0, V.jsx)(`input`, { type: `radio`, name: `approver`, "data-testid": `approver`, checked: ee2 === e3.did, onChange: () => A2(e3.did) }), (0, V.jsxs)(`span`, { style: { display: `grid`, minWidth: 0 }, children: [(0, V.jsx)(`strong`, { style: G, children: e3.displayName ?? `Phone` }), (0, V.jsx)(st, { value: e3.did })] })] }, e3.did))] }), (0, V.jsx)(`p`, { style: { margin: 0, fontSize: k.sm, color: f.muted }, children: `Your phone will ask you to approve this sign-in and each one after it from this browser.` }), be2 && (0, V.jsx)(_, { tone: `danger`, children: be2 })] });
    case `uv-pin`: {
      let e3 = b2.lockedUntil !== void 0 && b2.lockedUntil > y2();
      return (0, V.jsxs)(q, { who: H2, title: `Enter your PIN`, primary: { label: `Approve`, run: () => void Te2(false), disabled: L2 || e3 || T2.length === 0, testId: `approve-pin` }, secondary: { label: `Back`, run: () => Se2(), disabled: L2, testId: `back` }, children: [(0, V.jsx)(J, { children: `Type the PIN you set for approving sign-ins from this browser.` }), b2.attemptsRemaining !== void 0 && b2.lockedUntil === void 0 && (0, V.jsx)(_, { tone: `danger`, children: (0, V.jsxs)(`span`, { "data-testid": `pin-wrong`, children: [`Wrong PIN.`, ` `, b2.attemptsRemaining === 1 ? `1 try left before it locks.` : `${b2.attemptsRemaining} tries left before it locks.`] }) }), b2.lockedUntil !== void 0 && (0, V.jsx)(_, { tone: `warn`, children: (0, V.jsxs)(`span`, { "data-testid": `pin-locked`, children: [`Too many wrong PINs. Locked until`, ` `, new Date(b2.lockedUntil).toLocaleTimeString(), `.`] }) }), (0, V.jsx)(yt, { testId: `pin`, label: `PIN`, value: T2, onChange: E2, autoFocus: true, disabled: e3 }), I2 !== void 0 && (0, V.jsx)(ft, { deadline: I2, now: y2 })] });
    }
    case `uv-pending`:
      return (0, V.jsxs)(q, { who: H2, title: `Approve on your phone`, secondary: { label: `Cancel`, run: () => Se2(`Approval cancelled.`), testId: `cancel-phone` }, children: [(0, V.jsx)(J, { children: `Your phone is asking you to approve this sign-in. Check it shows this code, then approve there.` }), b2.matchCode && (0, V.jsx)(`div`, { "data-testid": `match-code`, style: { fontFamily: c.mono, fontSize: 36, fontWeight: 600, letterSpacing: `0.2em`, textAlign: `center`, fontVariantNumeric: `tabular-nums` }, children: b2.matchCode }), (0, V.jsx)(J, { muted: true, children: `Waiting for your phone\u2026` }), I2 !== void 0 && (0, V.jsx)(ft, { deadline: I2, now: y2 })] });
    case `uv-challenge`:
    case `uv-approvers`:
      return null;
  }
}
function vt({ title: e2, testId: t2, run: n2, children: r2 }) {
  return (0, V.jsxs)(`button`, { type: `button`, "data-testid": t2, onClick: n2, style: { ...d(`default`), display: `grid`, gap: 4, textAlign: `left`, padding: `12px 14px`, borderRadius: h.md, minWidth: 0 }, children: [(0, V.jsx)(`strong`, { style: { fontSize: k.base }, children: e2 }), (0, V.jsx)(`span`, { style: { fontSize: k.sm, color: f.muted, fontWeight: 400, ...G }, children: r2 })] });
}
function yt({ label: e2, value: t2, onChange: n2, testId: r2, autoFocus: i2 = false, disabled: a2 = false }) {
  return (0, V.jsxs)(`label`, { style: { display: `grid`, gap: 4, minWidth: 0 }, children: [(0, V.jsx)(`span`, { style: l, children: e2 }), (0, V.jsx)(`input`, { type: `password`, "data-testid": r2, autoComplete: `off`, autoFocus: i2, disabled: a2, value: t2, onChange: (e3) => n2(e3.target.value), style: { fontFamily: c.mono, fontSize: k.md, padding: `8px 10px`, background: f.ground, color: f.text, border: `1.5px solid ${f.line}`, borderRadius: h.md, minWidth: 0 } })] });
}
function bt(e2) {
  switch (e2) {
    case `vtc/directory`:
      return `the member directory (reading it, and editing your own card)`;
    case `vtc/groups`:
      return `community groups`;
    default:
      return e2;
  }
}
var xt = e(t(((e2, t2) => {
  (function(n2, r2) {
    typeof e2 == `object` && typeof t2 == `object` ? t2.exports = r2() : typeof define == `function` && define.amd ? define([], r2) : typeof e2 == `object` ? e2.jsQR = r2() : n2.jsQR = r2();
  })(typeof self < `u` ? self : e2, function() {
    return (function(e3) {
      var t3 = {};
      function n2(r2) {
        if (t3[r2]) return t3[r2].exports;
        var i2 = t3[r2] = { i: r2, l: false, exports: {} };
        return e3[r2].call(i2.exports, i2, i2.exports, n2), i2.l = true, i2.exports;
      }
      return n2.m = e3, n2.c = t3, n2.d = function(e4, t4, r2) {
        n2.o(e4, t4) || Object.defineProperty(e4, t4, { configurable: false, enumerable: true, get: r2 });
      }, n2.n = function(e4) {
        var t4 = e4 && e4.__esModule ? function() {
          return e4.default;
        } : function() {
          return e4;
        };
        return n2.d(t4, `a`, t4), t4;
      }, n2.o = function(e4, t4) {
        return Object.prototype.hasOwnProperty.call(e4, t4);
      }, n2.p = ``, n2(n2.s = 3);
    })([(function(e3, t3, n2) {
      Object.defineProperty(t3, "__esModule", { value: true }), t3.BitMatrix = (function() {
        function e4(e5, t4) {
          this.width = t4, this.height = e5.length / t4, this.data = e5;
        }
        return e4.createEmpty = function(t4, n3) {
          return new e4(new Uint8ClampedArray(t4 * n3), t4);
        }, e4.prototype.get = function(e5, t4) {
          return e5 < 0 || e5 >= this.width || t4 < 0 || t4 >= this.height ? false : !!this.data[t4 * this.width + e5];
        }, e4.prototype.set = function(e5, t4, n3) {
          this.data[t4 * this.width + e5] = +!!n3;
        }, e4.prototype.setRegion = function(e5, t4, n3, r2, i2) {
          for (var a2 = t4; a2 < t4 + r2; a2++) for (var o2 = e5; o2 < e5 + n3; o2++) this.set(o2, a2, !!i2);
        }, e4;
      })();
    }), (function(e3, t3, n2) {
      Object.defineProperty(t3, "__esModule", { value: true });
      var r2 = n2(2);
      function i2(e4, t4) {
        return e4 ^ t4;
      }
      t3.addOrSubtractGF = i2, t3.default = (function() {
        function e4(e5, t4, n3) {
          this.primitive = e5, this.size = t4, this.generatorBase = n3, this.expTable = Array(this.size), this.logTable = Array(this.size);
          for (var i3 = 1, a2 = 0; a2 < this.size; a2++) this.expTable[a2] = i3, i3 *= 2, i3 >= this.size && (i3 = (i3 ^ this.primitive) & this.size - 1);
          for (var a2 = 0; a2 < this.size - 1; a2++) this.logTable[this.expTable[a2]] = a2;
          this.zero = new r2.default(this, Uint8ClampedArray.from([0])), this.one = new r2.default(this, Uint8ClampedArray.from([1]));
        }
        return e4.prototype.multiply = function(e5, t4) {
          return e5 === 0 || t4 === 0 ? 0 : this.expTable[(this.logTable[e5] + this.logTable[t4]) % (this.size - 1)];
        }, e4.prototype.inverse = function(e5) {
          if (e5 === 0) throw Error(`Can't invert 0`);
          return this.expTable[this.size - this.logTable[e5] - 1];
        }, e4.prototype.buildMonomial = function(e5, t4) {
          if (e5 < 0) throw Error(`Invalid monomial degree less than 0`);
          if (t4 === 0) return this.zero;
          var n3 = new Uint8ClampedArray(e5 + 1);
          return n3[0] = t4, new r2.default(this, n3);
        }, e4.prototype.log = function(e5) {
          if (e5 === 0) throw Error(`Can't take log(0)`);
          return this.logTable[e5];
        }, e4.prototype.exp = function(e5) {
          return this.expTable[e5];
        }, e4;
      })();
    }), (function(e3, t3, n2) {
      Object.defineProperty(t3, "__esModule", { value: true });
      var r2 = n2(1);
      t3.default = (function() {
        function e4(e5, t4) {
          if (t4.length === 0) throw Error(`No coefficients.`);
          this.field = e5;
          var n3 = t4.length;
          if (n3 > 1 && t4[0] === 0) {
            for (var r3 = 1; r3 < n3 && t4[r3] === 0; ) r3++;
            if (r3 === n3) this.coefficients = e5.zero.coefficients;
            else {
              this.coefficients = new Uint8ClampedArray(n3 - r3);
              for (var i2 = 0; i2 < this.coefficients.length; i2++) this.coefficients[i2] = t4[r3 + i2];
            }
          } else this.coefficients = t4;
        }
        return e4.prototype.degree = function() {
          return this.coefficients.length - 1;
        }, e4.prototype.isZero = function() {
          return this.coefficients[0] === 0;
        }, e4.prototype.getCoefficient = function(e5) {
          return this.coefficients[this.coefficients.length - 1 - e5];
        }, e4.prototype.addOrSubtract = function(t4) {
          var n3;
          if (this.isZero()) return t4;
          if (t4.isZero()) return this;
          var i2 = this.coefficients, a2 = t4.coefficients;
          i2.length > a2.length && (n3 = [a2, i2], i2 = n3[0], a2 = n3[1]);
          for (var o2 = new Uint8ClampedArray(a2.length), s2 = a2.length - i2.length, c2 = 0; c2 < s2; c2++) o2[c2] = a2[c2];
          for (var c2 = s2; c2 < a2.length; c2++) o2[c2] = r2.addOrSubtractGF(i2[c2 - s2], a2[c2]);
          return new e4(this.field, o2);
        }, e4.prototype.multiply = function(t4) {
          if (t4 === 0) return this.field.zero;
          if (t4 === 1) return this;
          for (var n3 = this.coefficients.length, r3 = new Uint8ClampedArray(n3), i2 = 0; i2 < n3; i2++) r3[i2] = this.field.multiply(this.coefficients[i2], t4);
          return new e4(this.field, r3);
        }, e4.prototype.multiplyPoly = function(t4) {
          if (this.isZero() || t4.isZero()) return this.field.zero;
          for (var n3 = this.coefficients, i2 = n3.length, a2 = t4.coefficients, o2 = a2.length, s2 = new Uint8ClampedArray(i2 + o2 - 1), c2 = 0; c2 < i2; c2++) for (var l2 = n3[c2], u2 = 0; u2 < o2; u2++) s2[c2 + u2] = r2.addOrSubtractGF(s2[c2 + u2], this.field.multiply(l2, a2[u2]));
          return new e4(this.field, s2);
        }, e4.prototype.multiplyByMonomial = function(t4, n3) {
          if (t4 < 0) throw Error(`Invalid degree less than 0`);
          if (n3 === 0) return this.field.zero;
          for (var r3 = this.coefficients.length, i2 = new Uint8ClampedArray(r3 + t4), a2 = 0; a2 < r3; a2++) i2[a2] = this.field.multiply(this.coefficients[a2], n3);
          return new e4(this.field, i2);
        }, e4.prototype.evaluateAt = function(e5) {
          var t4 = 0;
          if (e5 === 0) return this.getCoefficient(0);
          var n3 = this.coefficients.length;
          if (e5 === 1) return this.coefficients.forEach(function(e6) {
            t4 = r2.addOrSubtractGF(t4, e6);
          }), t4;
          t4 = this.coefficients[0];
          for (var i2 = 1; i2 < n3; i2++) t4 = r2.addOrSubtractGF(this.field.multiply(e5, t4), this.coefficients[i2]);
          return t4;
        }, e4;
      })();
    }), (function(e3, t3, n2) {
      Object.defineProperty(t3, "__esModule", { value: true });
      var r2 = n2(4), i2 = n2(5), a2 = n2(11), o2 = n2(12);
      function s2(e4) {
        var t4 = o2.locate(e4);
        if (!t4) return null;
        for (var n3 = 0, r3 = t4; n3 < r3.length; n3++) {
          var s3 = r3[n3], c3 = a2.extract(e4, s3), l3 = i2.decode(c3.matrix);
          if (l3) return { binaryData: l3.bytes, data: l3.text, chunks: l3.chunks, version: l3.version, location: { topRightCorner: c3.mappingFunction(s3.dimension, 0), topLeftCorner: c3.mappingFunction(0, 0), bottomRightCorner: c3.mappingFunction(s3.dimension, s3.dimension), bottomLeftCorner: c3.mappingFunction(0, s3.dimension), topRightFinderPattern: s3.topRight, topLeftFinderPattern: s3.topLeft, bottomLeftFinderPattern: s3.bottomLeft, bottomRightAlignmentPattern: s3.alignmentPattern } };
        }
        return null;
      }
      var c2 = { inversionAttempts: `attemptBoth` };
      function l2(e4, t4, n3, i3) {
        i3 === void 0 && (i3 = {});
        var a3 = c2;
        Object.keys(a3 || {}).forEach(function(e5) {
          a3[e5] = i3[e5] || a3[e5];
        });
        var o3 = a3.inversionAttempts === `attemptBoth` || a3.inversionAttempts === `invertFirst`, l3 = a3.inversionAttempts === `onlyInvert` || a3.inversionAttempts === `invertFirst`, u2 = r2.binarize(e4, t4, n3, o3), d2 = u2.binarized, f2 = u2.inverted, p2 = s2(l3 ? f2 : d2);
        return !p2 && (a3.inversionAttempts === `attemptBoth` || a3.inversionAttempts === `invertFirst`) && (p2 = s2(l3 ? d2 : f2)), p2;
      }
      l2.default = l2, t3.default = l2;
    }), (function(e3, t3, n2) {
      Object.defineProperty(t3, "__esModule", { value: true });
      var r2 = n2(0), i2 = 8, a2 = 24;
      function o2(e4, t4, n3) {
        return e4 < t4 ? t4 : e4 > n3 ? n3 : e4;
      }
      var s2 = (function() {
        function e4(e5, t4) {
          this.width = e5, this.data = new Uint8ClampedArray(e5 * t4);
        }
        return e4.prototype.get = function(e5, t4) {
          return this.data[t4 * this.width + e5];
        }, e4.prototype.set = function(e5, t4, n3) {
          this.data[t4 * this.width + e5] = n3;
        }, e4;
      })();
      function c2(e4, t4, n3, c3) {
        if (e4.length !== t4 * n3 * 4) throw Error(`Malformed data passed to binarizer.`);
        for (var l2 = new s2(t4, n3), u2 = 0; u2 < t4; u2++) for (var d2 = 0; d2 < n3; d2++) {
          var f2 = e4[(d2 * t4 + u2) * 4 + 0], p2 = e4[(d2 * t4 + u2) * 4 + 1], m2 = e4[(d2 * t4 + u2) * 4 + 2];
          l2.set(u2, d2, 0.2126 * f2 + 0.7152 * p2 + 0.0722 * m2);
        }
        for (var h2 = Math.ceil(t4 / i2), g2 = Math.ceil(n3 / i2), _2 = new s2(h2, g2), v2 = 0; v2 < g2; v2++) for (var y2 = 0; y2 < h2; y2++) {
          for (var b2 = 0, x2 = 1 / 0, S2 = 0, d2 = 0; d2 < i2; d2++) for (var u2 = 0; u2 < i2; u2++) {
            var C2 = l2.get(y2 * i2 + u2, v2 * i2 + d2);
            b2 += C2, x2 = Math.min(x2, C2), S2 = Math.max(S2, C2);
          }
          var w2 = b2 / i2 ** 2;
          if (S2 - x2 <= a2 && (w2 = x2 / 2, v2 > 0 && y2 > 0)) {
            var T2 = (_2.get(y2, v2 - 1) + 2 * _2.get(y2 - 1, v2) + _2.get(y2 - 1, v2 - 1)) / 4;
            x2 < T2 && (w2 = T2);
          }
          _2.set(y2, v2, w2);
        }
        var E2 = r2.BitMatrix.createEmpty(t4, n3), D2 = null;
        c3 && (D2 = r2.BitMatrix.createEmpty(t4, n3));
        for (var v2 = 0; v2 < g2; v2++) for (var y2 = 0; y2 < h2; y2++) {
          for (var O2 = o2(y2, 2, h2 - 3), ee2 = o2(v2, 2, g2 - 3), b2 = 0, k2 = -2; k2 <= 2; k2++) for (var A2 = -2; A2 <= 2; A2++) b2 += _2.get(O2 + k2, ee2 + A2);
          for (var j2 = b2 / 25, k2 = 0; k2 < i2; k2++) for (var A2 = 0; A2 < i2; A2++) {
            var u2 = y2 * i2 + k2, d2 = v2 * i2 + A2, te2 = l2.get(u2, d2);
            E2.set(u2, d2, te2 <= j2), c3 && D2.set(u2, d2, !(te2 <= j2));
          }
        }
        return c3 ? { binarized: E2, inverted: D2 } : { binarized: E2 };
      }
      t3.binarize = c2;
    }), (function(e3, t3, n2) {
      Object.defineProperty(t3, "__esModule", { value: true });
      var r2 = n2(0), i2 = n2(6), a2 = n2(9), o2 = n2(10);
      function s2(e4, t4) {
        for (var n3 = e4 ^ t4, r3 = 0; n3; ) r3++, n3 &= n3 - 1;
        return r3;
      }
      function c2(e4, t4) {
        return t4 << 1 | e4;
      }
      var l2 = [{ bits: 21522, formatInfo: { errorCorrectionLevel: 1, dataMask: 0 } }, { bits: 20773, formatInfo: { errorCorrectionLevel: 1, dataMask: 1 } }, { bits: 24188, formatInfo: { errorCorrectionLevel: 1, dataMask: 2 } }, { bits: 23371, formatInfo: { errorCorrectionLevel: 1, dataMask: 3 } }, { bits: 17913, formatInfo: { errorCorrectionLevel: 1, dataMask: 4 } }, { bits: 16590, formatInfo: { errorCorrectionLevel: 1, dataMask: 5 } }, { bits: 20375, formatInfo: { errorCorrectionLevel: 1, dataMask: 6 } }, { bits: 19104, formatInfo: { errorCorrectionLevel: 1, dataMask: 7 } }, { bits: 30660, formatInfo: { errorCorrectionLevel: 0, dataMask: 0 } }, { bits: 29427, formatInfo: { errorCorrectionLevel: 0, dataMask: 1 } }, { bits: 32170, formatInfo: { errorCorrectionLevel: 0, dataMask: 2 } }, { bits: 30877, formatInfo: { errorCorrectionLevel: 0, dataMask: 3 } }, { bits: 26159, formatInfo: { errorCorrectionLevel: 0, dataMask: 4 } }, { bits: 25368, formatInfo: { errorCorrectionLevel: 0, dataMask: 5 } }, { bits: 27713, formatInfo: { errorCorrectionLevel: 0, dataMask: 6 } }, { bits: 26998, formatInfo: { errorCorrectionLevel: 0, dataMask: 7 } }, { bits: 5769, formatInfo: { errorCorrectionLevel: 3, dataMask: 0 } }, { bits: 5054, formatInfo: { errorCorrectionLevel: 3, dataMask: 1 } }, { bits: 7399, formatInfo: { errorCorrectionLevel: 3, dataMask: 2 } }, { bits: 6608, formatInfo: { errorCorrectionLevel: 3, dataMask: 3 } }, { bits: 1890, formatInfo: { errorCorrectionLevel: 3, dataMask: 4 } }, { bits: 597, formatInfo: { errorCorrectionLevel: 3, dataMask: 5 } }, { bits: 3340, formatInfo: { errorCorrectionLevel: 3, dataMask: 6 } }, { bits: 2107, formatInfo: { errorCorrectionLevel: 3, dataMask: 7 } }, { bits: 13663, formatInfo: { errorCorrectionLevel: 2, dataMask: 0 } }, { bits: 12392, formatInfo: { errorCorrectionLevel: 2, dataMask: 1 } }, { bits: 16177, formatInfo: { errorCorrectionLevel: 2, dataMask: 2 } }, { bits: 14854, formatInfo: { errorCorrectionLevel: 2, dataMask: 3 } }, { bits: 9396, formatInfo: { errorCorrectionLevel: 2, dataMask: 4 } }, { bits: 8579, formatInfo: { errorCorrectionLevel: 2, dataMask: 5 } }, { bits: 11994, formatInfo: { errorCorrectionLevel: 2, dataMask: 6 } }, { bits: 11245, formatInfo: { errorCorrectionLevel: 2, dataMask: 7 } }], u2 = [function(e4) {
        return (e4.y + e4.x) % 2 == 0;
      }, function(e4) {
        return e4.y % 2 == 0;
      }, function(e4) {
        return e4.x % 3 == 0;
      }, function(e4) {
        return (e4.y + e4.x) % 3 == 0;
      }, function(e4) {
        return (Math.floor(e4.y / 2) + Math.floor(e4.x / 3)) % 2 == 0;
      }, function(e4) {
        return e4.x * e4.y % 2 + e4.x * e4.y % 3 == 0;
      }, function(e4) {
        return (e4.y * e4.x % 2 + e4.y * e4.x % 3) % 2 == 0;
      }, function(e4) {
        return ((e4.y + e4.x) % 2 + e4.y * e4.x % 3) % 2 == 0;
      }];
      function d2(e4) {
        var t4 = 17 + 4 * e4.versionNumber, n3 = r2.BitMatrix.createEmpty(t4, t4);
        n3.setRegion(0, 0, 9, 9, true), n3.setRegion(t4 - 8, 0, 8, 9, true), n3.setRegion(0, t4 - 8, 9, 8, true);
        for (var i3 = 0, a3 = e4.alignmentPatternCenters; i3 < a3.length; i3++) for (var o3 = a3[i3], s3 = 0, c3 = e4.alignmentPatternCenters; s3 < c3.length; s3++) {
          var l3 = c3[s3];
          o3 === 6 && l3 === 6 || o3 === 6 && l3 === t4 - 7 || o3 === t4 - 7 && l3 === 6 || n3.setRegion(o3 - 2, l3 - 2, 5, 5, true);
        }
        return n3.setRegion(6, 9, 1, t4 - 17, true), n3.setRegion(9, 6, t4 - 17, 1, true), e4.versionNumber > 6 && (n3.setRegion(t4 - 11, 0, 3, 6, true), n3.setRegion(0, t4 - 11, 6, 3, true)), n3;
      }
      function f2(e4, t4, n3) {
        for (var r3 = u2[n3.dataMask], i3 = e4.height, a3 = d2(t4), o3 = [], s3 = 0, l3 = 0, f3 = true, p3 = i3 - 1; p3 > 0; p3 -= 2) {
          p3 === 6 && p3--;
          for (var m3 = 0; m3 < i3; m3++) for (var h3 = f3 ? i3 - 1 - m3 : m3, g3 = 0; g3 < 2; g3++) {
            var _3 = p3 - g3;
            if (!a3.get(_3, h3)) {
              l3++;
              var v2 = e4.get(_3, h3);
              r3({ y: h3, x: _3 }) && (v2 = !v2), s3 = c2(v2, s3), l3 === 8 && (o3.push(s3), l3 = 0, s3 = 0);
            }
          }
          f3 = !f3;
        }
        return o3;
      }
      function p2(e4) {
        var t4 = e4.height, n3 = Math.floor((t4 - 17) / 4);
        if (n3 <= 6) return o2.VERSIONS[n3 - 1];
        for (var r3 = 0, i3 = 5; i3 >= 0; i3--) for (var a3 = t4 - 9; a3 >= t4 - 11; a3--) r3 = c2(e4.get(a3, i3), r3);
        for (var l3 = 0, a3 = 5; a3 >= 0; a3--) for (var i3 = t4 - 9; i3 >= t4 - 11; i3--) l3 = c2(e4.get(a3, i3), l3);
        for (var u3 = 1 / 0, d3, f3 = 0, p3 = o2.VERSIONS; f3 < p3.length; f3++) {
          var m3 = p3[f3];
          if (m3.infoBits === r3 || m3.infoBits === l3) return m3;
          var h3 = s2(r3, m3.infoBits);
          h3 < u3 && (d3 = m3, u3 = h3), h3 = s2(l3, m3.infoBits), h3 < u3 && (d3 = m3, u3 = h3);
        }
        if (u3 <= 3) return d3;
      }
      function m2(e4) {
        for (var t4 = 0, n3 = 0; n3 <= 8; n3++) n3 !== 6 && (t4 = c2(e4.get(n3, 8), t4));
        for (var r3 = 7; r3 >= 0; r3--) r3 !== 6 && (t4 = c2(e4.get(8, r3), t4));
        for (var i3 = e4.height, a3 = 0, r3 = i3 - 1; r3 >= i3 - 7; r3--) a3 = c2(e4.get(8, r3), a3);
        for (var n3 = i3 - 8; n3 < i3; n3++) a3 = c2(e4.get(n3, 8), a3);
        for (var o3 = 1 / 0, u3 = null, d3 = 0, f3 = l2; d3 < f3.length; d3++) {
          var p3 = f3[d3], m3 = p3.bits, h3 = p3.formatInfo;
          if (m3 === t4 || m3 === a3) return h3;
          var g3 = s2(t4, m3);
          g3 < o3 && (u3 = h3, o3 = g3), t4 !== a3 && (g3 = s2(a3, m3), g3 < o3 && (u3 = h3, o3 = g3));
        }
        return o3 <= 3 ? u3 : null;
      }
      function h2(e4, t4, n3) {
        var r3 = t4.errorCorrectionLevels[n3], i3 = [], a3 = 0;
        if (r3.ecBlocks.forEach(function(e5) {
          for (var t5 = 0; t5 < e5.numBlocks; t5++) i3.push({ numDataCodewords: e5.dataCodewordsPerBlock, codewords: [] }), a3 += e5.dataCodewordsPerBlock + r3.ecCodewordsPerBlock;
        }), e4.length < a3) return null;
        e4 = e4.slice(0, a3);
        for (var o3 = r3.ecBlocks[0].dataCodewordsPerBlock, s3 = 0; s3 < o3; s3++) for (var c3 = 0, l3 = i3; c3 < l3.length; c3++) {
          var u3 = l3[c3];
          u3.codewords.push(e4.shift());
        }
        if (r3.ecBlocks.length > 1) for (var d3 = r3.ecBlocks[0].numBlocks, f3 = r3.ecBlocks[1].numBlocks, s3 = 0; s3 < f3; s3++) i3[d3 + s3].codewords.push(e4.shift());
        for (; e4.length > 0; ) for (var p3 = 0, m3 = i3; p3 < m3.length; p3++) {
          var u3 = m3[p3];
          u3.codewords.push(e4.shift());
        }
        return i3;
      }
      function g2(e4) {
        var t4 = p2(e4);
        if (!t4) return null;
        var n3 = m2(e4);
        if (!n3) return null;
        var r3 = h2(f2(e4, t4, n3), t4, n3.errorCorrectionLevel);
        if (!r3) return null;
        for (var o3 = r3.reduce(function(e5, t5) {
          return e5 + t5.numDataCodewords;
        }, 0), s3 = new Uint8ClampedArray(o3), c3 = 0, l3 = 0, u3 = r3; l3 < u3.length; l3++) {
          var d3 = u3[l3], g3 = a2.decode(d3.codewords, d3.codewords.length - d3.numDataCodewords);
          if (!g3) return null;
          for (var _3 = 0; _3 < d3.numDataCodewords; _3++) s3[c3++] = g3[_3];
        }
        try {
          return i2.decode(s3, t4.versionNumber);
        } catch {
          return null;
        }
      }
      function _2(e4) {
        if (e4 == null) return null;
        var t4 = g2(e4);
        if (t4) return t4;
        for (var n3 = 0; n3 < e4.width; n3++) for (var r3 = n3 + 1; r3 < e4.height; r3++) e4.get(n3, r3) !== e4.get(r3, n3) && (e4.set(n3, r3, !e4.get(n3, r3)), e4.set(r3, n3, !e4.get(r3, n3)));
        return g2(e4);
      }
      t3.decode = _2;
    }), (function(e3, t3, n2) {
      Object.defineProperty(t3, "__esModule", { value: true });
      var r2 = n2(7), i2 = n2(8), a2;
      (function(e4) {
        e4.Numeric = `numeric`, e4.Alphanumeric = `alphanumeric`, e4.Byte = `byte`, e4.Kanji = `kanji`, e4.ECI = `eci`;
      })(a2 = t3.Mode ||= {});
      var o2;
      (function(e4) {
        e4[e4.Terminator = 0] = `Terminator`, e4[e4.Numeric = 1] = `Numeric`, e4[e4.Alphanumeric = 2] = `Alphanumeric`, e4[e4.Byte = 4] = `Byte`, e4[e4.Kanji = 8] = `Kanji`, e4[e4.ECI = 7] = `ECI`;
      })(o2 ||= {});
      function s2(e4, t4) {
        for (var n3 = [], r3 = ``, i3 = [10, 12, 14][t4], a3 = e4.readBits(i3); a3 >= 3; ) {
          var o3 = e4.readBits(10);
          if (o3 >= 1e3) throw Error(`Invalid numeric value above 999`);
          var s3 = Math.floor(o3 / 100), c3 = Math.floor(o3 / 10) % 10, l3 = o3 % 10;
          n3.push(48 + s3, 48 + c3, 48 + l3), r3 += s3.toString() + c3.toString() + l3.toString(), a3 -= 3;
        }
        if (a3 === 2) {
          var o3 = e4.readBits(7);
          if (o3 >= 100) throw Error(`Invalid numeric value above 99`);
          var s3 = Math.floor(o3 / 10), c3 = o3 % 10;
          n3.push(48 + s3, 48 + c3), r3 += s3.toString() + c3.toString();
        } else if (a3 === 1) {
          var o3 = e4.readBits(4);
          if (o3 >= 10) throw Error(`Invalid numeric value above 9`);
          n3.push(48 + o3), r3 += o3.toString();
        }
        return { bytes: n3, text: r3 };
      }
      var c2 = `0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:`.split(``);
      function l2(e4, t4) {
        for (var n3 = [], r3 = ``, i3 = [9, 11, 13][t4], a3 = e4.readBits(i3); a3 >= 2; ) {
          var o3 = e4.readBits(11), s3 = Math.floor(o3 / 45), l3 = o3 % 45;
          n3.push(c2[s3].charCodeAt(0), c2[l3].charCodeAt(0)), r3 += c2[s3] + c2[l3], a3 -= 2;
        }
        if (a3 === 1) {
          var s3 = e4.readBits(6);
          n3.push(c2[s3].charCodeAt(0)), r3 += c2[s3];
        }
        return { bytes: n3, text: r3 };
      }
      function u2(e4, t4) {
        for (var n3 = [], r3 = ``, i3 = [8, 16, 16][t4], a3 = e4.readBits(i3), o3 = 0; o3 < a3; o3++) {
          var s3 = e4.readBits(8);
          n3.push(s3);
        }
        try {
          r3 += decodeURIComponent(n3.map(function(e5) {
            return `%` + (`0` + e5.toString(16)).substr(-2);
          }).join(``));
        } catch {
        }
        return { bytes: n3, text: r3 };
      }
      function d2(e4, t4) {
        for (var n3 = [], r3 = ``, a3 = [8, 10, 12][t4], o3 = e4.readBits(a3), s3 = 0; s3 < o3; s3++) {
          var c3 = e4.readBits(13), l3 = Math.floor(c3 / 192) << 8 | c3 % 192;
          l3 += l3 < 7936 ? 33088 : 49472, n3.push(l3 >> 8, l3 & 255), r3 += String.fromCharCode(i2.shiftJISTable[l3]);
        }
        return { bytes: n3, text: r3 };
      }
      function f2(e4, t4) {
        for (var n3, i3, c3, f3, p2 = new r2.BitStream(e4), m2 = t4 <= 9 ? 0 : t4 <= 26 ? 1 : 2, h2 = { text: ``, bytes: [], chunks: [], version: t4 }; p2.available() >= 4; ) {
          var g2 = p2.readBits(4);
          if (g2 === o2.Terminator) return h2;
          if (g2 === o2.ECI) p2.readBits(1) === 0 ? h2.chunks.push({ type: a2.ECI, assignmentNumber: p2.readBits(7) }) : p2.readBits(1) === 0 ? h2.chunks.push({ type: a2.ECI, assignmentNumber: p2.readBits(14) }) : p2.readBits(1) === 0 ? h2.chunks.push({ type: a2.ECI, assignmentNumber: p2.readBits(21) }) : h2.chunks.push({ type: a2.ECI, assignmentNumber: -1 });
          else if (g2 === o2.Numeric) {
            var _2 = s2(p2, m2);
            h2.text += _2.text, (n3 = h2.bytes).push.apply(n3, _2.bytes), h2.chunks.push({ type: a2.Numeric, text: _2.text });
          } else if (g2 === o2.Alphanumeric) {
            var v2 = l2(p2, m2);
            h2.text += v2.text, (i3 = h2.bytes).push.apply(i3, v2.bytes), h2.chunks.push({ type: a2.Alphanumeric, text: v2.text });
          } else if (g2 === o2.Byte) {
            var y2 = u2(p2, m2);
            h2.text += y2.text, (c3 = h2.bytes).push.apply(c3, y2.bytes), h2.chunks.push({ type: a2.Byte, bytes: y2.bytes, text: y2.text });
          } else if (g2 === o2.Kanji) {
            var b2 = d2(p2, m2);
            h2.text += b2.text, (f3 = h2.bytes).push.apply(f3, b2.bytes), h2.chunks.push({ type: a2.Kanji, bytes: b2.bytes, text: b2.text });
          }
        }
        if (p2.available() === 0 || p2.readBits(p2.available()) === 0) return h2;
      }
      t3.decode = f2;
    }), (function(e3, t3, n2) {
      Object.defineProperty(t3, "__esModule", { value: true }), t3.BitStream = (function() {
        function e4(e5) {
          this.byteOffset = 0, this.bitOffset = 0, this.bytes = e5;
        }
        return e4.prototype.readBits = function(e5) {
          if (e5 < 1 || e5 > 32 || e5 > this.available()) throw Error(`Cannot read ` + e5.toString() + ` bits`);
          var t4 = 0;
          if (this.bitOffset > 0) {
            var n3 = 8 - this.bitOffset, r2 = e5 < n3 ? e5 : n3, i2 = n3 - r2, a2 = 255 >> 8 - r2 << i2;
            t4 = (this.bytes[this.byteOffset] & a2) >> i2, e5 -= r2, this.bitOffset += r2, this.bitOffset === 8 && (this.bitOffset = 0, this.byteOffset++);
          }
          if (e5 > 0) {
            for (; e5 >= 8; ) t4 = t4 << 8 | this.bytes[this.byteOffset] & 255, this.byteOffset++, e5 -= 8;
            if (e5 > 0) {
              var i2 = 8 - e5, a2 = 255 >> i2 << i2;
              t4 = t4 << e5 | (this.bytes[this.byteOffset] & a2) >> i2, this.bitOffset += e5;
            }
          }
          return t4;
        }, e4.prototype.available = function() {
          return 8 * (this.bytes.length - this.byteOffset) - this.bitOffset;
        }, e4;
      })();
    }), (function(e3, t3, n2) {
      Object.defineProperty(t3, "__esModule", { value: true }), t3.shiftJISTable = { 32: 32, 33: 33, 34: 34, 35: 35, 36: 36, 37: 37, 38: 38, 39: 39, 40: 40, 41: 41, 42: 42, 43: 43, 44: 44, 45: 45, 46: 46, 47: 47, 48: 48, 49: 49, 50: 50, 51: 51, 52: 52, 53: 53, 54: 54, 55: 55, 56: 56, 57: 57, 58: 58, 59: 59, 60: 60, 61: 61, 62: 62, 63: 63, 64: 64, 65: 65, 66: 66, 67: 67, 68: 68, 69: 69, 70: 70, 71: 71, 72: 72, 73: 73, 74: 74, 75: 75, 76: 76, 77: 77, 78: 78, 79: 79, 80: 80, 81: 81, 82: 82, 83: 83, 84: 84, 85: 85, 86: 86, 87: 87, 88: 88, 89: 89, 90: 90, 91: 91, 92: 165, 93: 93, 94: 94, 95: 95, 96: 96, 97: 97, 98: 98, 99: 99, 100: 100, 101: 101, 102: 102, 103: 103, 104: 104, 105: 105, 106: 106, 107: 107, 108: 108, 109: 109, 110: 110, 111: 111, 112: 112, 113: 113, 114: 114, 115: 115, 116: 116, 117: 117, 118: 118, 119: 119, 120: 120, 121: 121, 122: 122, 123: 123, 124: 124, 125: 125, 126: 8254, 33088: 12288, 33089: 12289, 33090: 12290, 33091: 65292, 33092: 65294, 33093: 12539, 33094: 65306, 33095: 65307, 33096: 65311, 33097: 65281, 33098: 12443, 33099: 12444, 33100: 180, 33101: 65344, 33102: 168, 33103: 65342, 33104: 65507, 33105: 65343, 33106: 12541, 33107: 12542, 33108: 12445, 33109: 12446, 33110: 12291, 33111: 20189, 33112: 12293, 33113: 12294, 33114: 12295, 33115: 12540, 33116: 8213, 33117: 8208, 33118: 65295, 33119: 92, 33120: 12316, 33121: 8214, 33122: 65372, 33123: 8230, 33124: 8229, 33125: 8216, 33126: 8217, 33127: 8220, 33128: 8221, 33129: 65288, 33130: 65289, 33131: 12308, 33132: 12309, 33133: 65339, 33134: 65341, 33135: 65371, 33136: 65373, 33137: 12296, 33138: 12297, 33139: 12298, 33140: 12299, 33141: 12300, 33142: 12301, 33143: 12302, 33144: 12303, 33145: 12304, 33146: 12305, 33147: 65291, 33148: 8722, 33149: 177, 33150: 215, 33152: 247, 33153: 65309, 33154: 8800, 33155: 65308, 33156: 65310, 33157: 8806, 33158: 8807, 33159: 8734, 33160: 8756, 33161: 9794, 33162: 9792, 33163: 176, 33164: 8242, 33165: 8243, 33166: 8451, 33167: 65509, 33168: 65284, 33169: 162, 33170: 163, 33171: 65285, 33172: 65283, 33173: 65286, 33174: 65290, 33175: 65312, 33176: 167, 33177: 9734, 33178: 9733, 33179: 9675, 33180: 9679, 33181: 9678, 33182: 9671, 33183: 9670, 33184: 9633, 33185: 9632, 33186: 9651, 33187: 9650, 33188: 9661, 33189: 9660, 33190: 8251, 33191: 12306, 33192: 8594, 33193: 8592, 33194: 8593, 33195: 8595, 33196: 12307, 33208: 8712, 33209: 8715, 33210: 8838, 33211: 8839, 33212: 8834, 33213: 8835, 33214: 8746, 33215: 8745, 33224: 8743, 33225: 8744, 33226: 172, 33227: 8658, 33228: 8660, 33229: 8704, 33230: 8707, 33242: 8736, 33243: 8869, 33244: 8978, 33245: 8706, 33246: 8711, 33247: 8801, 33248: 8786, 33249: 8810, 33250: 8811, 33251: 8730, 33252: 8765, 33253: 8733, 33254: 8757, 33255: 8747, 33256: 8748, 33264: 8491, 33265: 8240, 33266: 9839, 33267: 9837, 33268: 9834, 33269: 8224, 33270: 8225, 33271: 182, 33276: 9711, 33359: 65296, 33360: 65297, 33361: 65298, 33362: 65299, 33363: 65300, 33364: 65301, 33365: 65302, 33366: 65303, 33367: 65304, 33368: 65305, 33376: 65313, 33377: 65314, 33378: 65315, 33379: 65316, 33380: 65317, 33381: 65318, 33382: 65319, 33383: 65320, 33384: 65321, 33385: 65322, 33386: 65323, 33387: 65324, 33388: 65325, 33389: 65326, 33390: 65327, 33391: 65328, 33392: 65329, 33393: 65330, 33394: 65331, 33395: 65332, 33396: 65333, 33397: 65334, 33398: 65335, 33399: 65336, 33400: 65337, 33401: 65338, 33409: 65345, 33410: 65346, 33411: 65347, 33412: 65348, 33413: 65349, 33414: 65350, 33415: 65351, 33416: 65352, 33417: 65353, 33418: 65354, 33419: 65355, 33420: 65356, 33421: 65357, 33422: 65358, 33423: 65359, 33424: 65360, 33425: 65361, 33426: 65362, 33427: 65363, 33428: 65364, 33429: 65365, 33430: 65366, 33431: 65367, 33432: 65368, 33433: 65369, 33434: 65370, 33439: 12353, 33440: 12354, 33441: 12355, 33442: 12356, 33443: 12357, 33444: 12358, 33445: 12359, 33446: 12360, 33447: 12361, 33448: 12362, 33449: 12363, 33450: 12364, 33451: 12365, 33452: 12366, 33453: 12367, 33454: 12368, 33455: 12369, 33456: 12370, 33457: 12371, 33458: 12372, 33459: 12373, 33460: 12374, 33461: 12375, 33462: 12376, 33463: 12377, 33464: 12378, 33465: 12379, 33466: 12380, 33467: 12381, 33468: 12382, 33469: 12383, 33470: 12384, 33471: 12385, 33472: 12386, 33473: 12387, 33474: 12388, 33475: 12389, 33476: 12390, 33477: 12391, 33478: 12392, 33479: 12393, 33480: 12394, 33481: 12395, 33482: 12396, 33483: 12397, 33484: 12398, 33485: 12399, 33486: 12400, 33487: 12401, 33488: 12402, 33489: 12403, 33490: 12404, 33491: 12405, 33492: 12406, 33493: 12407, 33494: 12408, 33495: 12409, 33496: 12410, 33497: 12411, 33498: 12412, 33499: 12413, 33500: 12414, 33501: 12415, 33502: 12416, 33503: 12417, 33504: 12418, 33505: 12419, 33506: 12420, 33507: 12421, 33508: 12422, 33509: 12423, 33510: 12424, 33511: 12425, 33512: 12426, 33513: 12427, 33514: 12428, 33515: 12429, 33516: 12430, 33517: 12431, 33518: 12432, 33519: 12433, 33520: 12434, 33521: 12435, 33600: 12449, 33601: 12450, 33602: 12451, 33603: 12452, 33604: 12453, 33605: 12454, 33606: 12455, 33607: 12456, 33608: 12457, 33609: 12458, 33610: 12459, 33611: 12460, 33612: 12461, 33613: 12462, 33614: 12463, 33615: 12464, 33616: 12465, 33617: 12466, 33618: 12467, 33619: 12468, 33620: 12469, 33621: 12470, 33622: 12471, 33623: 12472, 33624: 12473, 33625: 12474, 33626: 12475, 33627: 12476, 33628: 12477, 33629: 12478, 33630: 12479, 33631: 12480, 33632: 12481, 33633: 12482, 33634: 12483, 33635: 12484, 33636: 12485, 33637: 12486, 33638: 12487, 33639: 12488, 33640: 12489, 33641: 12490, 33642: 12491, 33643: 12492, 33644: 12493, 33645: 12494, 33646: 12495, 33647: 12496, 33648: 12497, 33649: 12498, 33650: 12499, 33651: 12500, 33652: 12501, 33653: 12502, 33654: 12503, 33655: 12504, 33656: 12505, 33657: 12506, 33658: 12507, 33659: 12508, 33660: 12509, 33661: 12510, 33662: 12511, 33664: 12512, 33665: 12513, 33666: 12514, 33667: 12515, 33668: 12516, 33669: 12517, 33670: 12518, 33671: 12519, 33672: 12520, 33673: 12521, 33674: 12522, 33675: 12523, 33676: 12524, 33677: 12525, 33678: 12526, 33679: 12527, 33680: 12528, 33681: 12529, 33682: 12530, 33683: 12531, 33684: 12532, 33685: 12533, 33686: 12534, 33695: 913, 33696: 914, 33697: 915, 33698: 916, 33699: 917, 33700: 918, 33701: 919, 33702: 920, 33703: 921, 33704: 922, 33705: 923, 33706: 924, 33707: 925, 33708: 926, 33709: 927, 33710: 928, 33711: 929, 33712: 931, 33713: 932, 33714: 933, 33715: 934, 33716: 935, 33717: 936, 33718: 937, 33727: 945, 33728: 946, 33729: 947, 33730: 948, 33731: 949, 33732: 950, 33733: 951, 33734: 952, 33735: 953, 33736: 954, 33737: 955, 33738: 956, 33739: 957, 33740: 958, 33741: 959, 33742: 960, 33743: 961, 33744: 963, 33745: 964, 33746: 965, 33747: 966, 33748: 967, 33749: 968, 33750: 969, 33856: 1040, 33857: 1041, 33858: 1042, 33859: 1043, 33860: 1044, 33861: 1045, 33862: 1025, 33863: 1046, 33864: 1047, 33865: 1048, 33866: 1049, 33867: 1050, 33868: 1051, 33869: 1052, 33870: 1053, 33871: 1054, 33872: 1055, 33873: 1056, 33874: 1057, 33875: 1058, 33876: 1059, 33877: 1060, 33878: 1061, 33879: 1062, 33880: 1063, 33881: 1064, 33882: 1065, 33883: 1066, 33884: 1067, 33885: 1068, 33886: 1069, 33887: 1070, 33888: 1071, 33904: 1072, 33905: 1073, 33906: 1074, 33907: 1075, 33908: 1076, 33909: 1077, 33910: 1105, 33911: 1078, 33912: 1079, 33913: 1080, 33914: 1081, 33915: 1082, 33916: 1083, 33917: 1084, 33918: 1085, 33920: 1086, 33921: 1087, 33922: 1088, 33923: 1089, 33924: 1090, 33925: 1091, 33926: 1092, 33927: 1093, 33928: 1094, 33929: 1095, 33930: 1096, 33931: 1097, 33932: 1098, 33933: 1099, 33934: 1100, 33935: 1101, 33936: 1102, 33937: 1103, 33951: 9472, 33952: 9474, 33953: 9484, 33954: 9488, 33955: 9496, 33956: 9492, 33957: 9500, 33958: 9516, 33959: 9508, 33960: 9524, 33961: 9532, 33962: 9473, 33963: 9475, 33964: 9487, 33965: 9491, 33966: 9499, 33967: 9495, 33968: 9507, 33969: 9523, 33970: 9515, 33971: 9531, 33972: 9547, 33973: 9504, 33974: 9519, 33975: 9512, 33976: 9527, 33977: 9535, 33978: 9501, 33979: 9520, 33980: 9509, 33981: 9528, 33982: 9538, 34975: 20124, 34976: 21782, 34977: 23043, 34978: 38463, 34979: 21696, 34980: 24859, 34981: 25384, 34982: 23030, 34983: 36898, 34984: 33909, 34985: 33564, 34986: 31312, 34987: 24746, 34988: 25569, 34989: 28197, 34990: 26093, 34991: 33894, 34992: 33446, 34993: 39925, 34994: 26771, 34995: 22311, 34996: 26017, 34997: 25201, 34998: 23451, 34999: 22992, 35e3: 34427, 35001: 39156, 35002: 32098, 35003: 32190, 35004: 39822, 35005: 25110, 35006: 31903, 35007: 34999, 35008: 23433, 35009: 24245, 35010: 25353, 35011: 26263, 35012: 26696, 35013: 38343, 35014: 38797, 35015: 26447, 35016: 20197, 35017: 20234, 35018: 20301, 35019: 20381, 35020: 20553, 35021: 22258, 35022: 22839, 35023: 22996, 35024: 23041, 35025: 23561, 35026: 24799, 35027: 24847, 35028: 24944, 35029: 26131, 35030: 26885, 35031: 28858, 35032: 30031, 35033: 30064, 35034: 31227, 35035: 32173, 35036: 32239, 35037: 32963, 35038: 33806, 35039: 34915, 35040: 35586, 35041: 36949, 35042: 36986, 35043: 21307, 35044: 20117, 35045: 20133, 35046: 22495, 35047: 32946, 35048: 37057, 35049: 30959, 35050: 19968, 35051: 22769, 35052: 28322, 35053: 36920, 35054: 31282, 35055: 33576, 35056: 33419, 35057: 39983, 35058: 20801, 35059: 21360, 35060: 21693, 35061: 21729, 35062: 22240, 35063: 23035, 35064: 24341, 35065: 39154, 35066: 28139, 35067: 32996, 35068: 34093, 35136: 38498, 35137: 38512, 35138: 38560, 35139: 38907, 35140: 21515, 35141: 21491, 35142: 23431, 35143: 28879, 35144: 32701, 35145: 36802, 35146: 38632, 35147: 21359, 35148: 40284, 35149: 31418, 35150: 19985, 35151: 30867, 35152: 33276, 35153: 28198, 35154: 22040, 35155: 21764, 35156: 27421, 35157: 34074, 35158: 39995, 35159: 23013, 35160: 21417, 35161: 28006, 35162: 29916, 35163: 38287, 35164: 22082, 35165: 20113, 35166: 36939, 35167: 38642, 35168: 33615, 35169: 39180, 35170: 21473, 35171: 21942, 35172: 23344, 35173: 24433, 35174: 26144, 35175: 26355, 35176: 26628, 35177: 27704, 35178: 27891, 35179: 27945, 35180: 29787, 35181: 30408, 35182: 31310, 35183: 38964, 35184: 33521, 35185: 34907, 35186: 35424, 35187: 37613, 35188: 28082, 35189: 30123, 35190: 30410, 35191: 39365, 35192: 24742, 35193: 35585, 35194: 36234, 35195: 38322, 35196: 27022, 35197: 21421, 35198: 20870, 35200: 22290, 35201: 22576, 35202: 22852, 35203: 23476, 35204: 24310, 35205: 24616, 35206: 25513, 35207: 25588, 35208: 27839, 35209: 28436, 35210: 28814, 35211: 28948, 35212: 29017, 35213: 29141, 35214: 29503, 35215: 32257, 35216: 33398, 35217: 33489, 35218: 34199, 35219: 36960, 35220: 37467, 35221: 40219, 35222: 22633, 35223: 26044, 35224: 27738, 35225: 29989, 35226: 20985, 35227: 22830, 35228: 22885, 35229: 24448, 35230: 24540, 35231: 25276, 35232: 26106, 35233: 27178, 35234: 27431, 35235: 27572, 35236: 29579, 35237: 32705, 35238: 35158, 35239: 40236, 35240: 40206, 35241: 40644, 35242: 23713, 35243: 27798, 35244: 33659, 35245: 20740, 35246: 23627, 35247: 25014, 35248: 33222, 35249: 26742, 35250: 29281, 35251: 20057, 35252: 20474, 35253: 21368, 35254: 24681, 35255: 28201, 35256: 31311, 35257: 38899, 35258: 19979, 35259: 21270, 35260: 20206, 35261: 20309, 35262: 20285, 35263: 20385, 35264: 20339, 35265: 21152, 35266: 21487, 35267: 22025, 35268: 22799, 35269: 23233, 35270: 23478, 35271: 23521, 35272: 31185, 35273: 26247, 35274: 26524, 35275: 26550, 35276: 27468, 35277: 27827, 35278: 28779, 35279: 29634, 35280: 31117, 35281: 31166, 35282: 31292, 35283: 31623, 35284: 33457, 35285: 33499, 35286: 33540, 35287: 33655, 35288: 33775, 35289: 33747, 35290: 34662, 35291: 35506, 35292: 22057, 35293: 36008, 35294: 36838, 35295: 36942, 35296: 38686, 35297: 34442, 35298: 20420, 35299: 23784, 35300: 25105, 35301: 29273, 35302: 30011, 35303: 33253, 35304: 33469, 35305: 34558, 35306: 36032, 35307: 38597, 35308: 39187, 35309: 39381, 35310: 20171, 35311: 20250, 35312: 35299, 35313: 22238, 35314: 22602, 35315: 22730, 35316: 24315, 35317: 24555, 35318: 24618, 35319: 24724, 35320: 24674, 35321: 25040, 35322: 25106, 35323: 25296, 35324: 25913, 35392: 39745, 35393: 26214, 35394: 26800, 35395: 28023, 35396: 28784, 35397: 30028, 35398: 30342, 35399: 32117, 35400: 33445, 35401: 34809, 35402: 38283, 35403: 38542, 35404: 35997, 35405: 20977, 35406: 21182, 35407: 22806, 35408: 21683, 35409: 23475, 35410: 23830, 35411: 24936, 35412: 27010, 35413: 28079, 35414: 30861, 35415: 33995, 35416: 34903, 35417: 35442, 35418: 37799, 35419: 39608, 35420: 28012, 35421: 39336, 35422: 34521, 35423: 22435, 35424: 26623, 35425: 34510, 35426: 37390, 35427: 21123, 35428: 22151, 35429: 21508, 35430: 24275, 35431: 25313, 35432: 25785, 35433: 26684, 35434: 26680, 35435: 27579, 35436: 29554, 35437: 30906, 35438: 31339, 35439: 35226, 35440: 35282, 35441: 36203, 35442: 36611, 35443: 37101, 35444: 38307, 35445: 38548, 35446: 38761, 35447: 23398, 35448: 23731, 35449: 27005, 35450: 38989, 35451: 38990, 35452: 25499, 35453: 31520, 35454: 27179, 35456: 27263, 35457: 26806, 35458: 39949, 35459: 28511, 35460: 21106, 35461: 21917, 35462: 24688, 35463: 25324, 35464: 27963, 35465: 28167, 35466: 28369, 35467: 33883, 35468: 35088, 35469: 36676, 35470: 19988, 35471: 39993, 35472: 21494, 35473: 26907, 35474: 27194, 35475: 38788, 35476: 26666, 35477: 20828, 35478: 31427, 35479: 33970, 35480: 37340, 35481: 37772, 35482: 22107, 35483: 40232, 35484: 26658, 35485: 33541, 35486: 33841, 35487: 31909, 35488: 21e3, 35489: 33477, 35490: 29926, 35491: 20094, 35492: 20355, 35493: 20896, 35494: 23506, 35495: 21002, 35496: 21208, 35497: 21223, 35498: 24059, 35499: 21914, 35500: 22570, 35501: 23014, 35502: 23436, 35503: 23448, 35504: 23515, 35505: 24178, 35506: 24185, 35507: 24739, 35508: 24863, 35509: 24931, 35510: 25022, 35511: 25563, 35512: 25954, 35513: 26577, 35514: 26707, 35515: 26874, 35516: 27454, 35517: 27475, 35518: 27735, 35519: 28450, 35520: 28567, 35521: 28485, 35522: 29872, 35523: 29976, 35524: 30435, 35525: 30475, 35526: 31487, 35527: 31649, 35528: 31777, 35529: 32233, 35530: 32566, 35531: 32752, 35532: 32925, 35533: 33382, 35534: 33694, 35535: 35251, 35536: 35532, 35537: 36011, 35538: 36996, 35539: 37969, 35540: 38291, 35541: 38289, 35542: 38306, 35543: 38501, 35544: 38867, 35545: 39208, 35546: 33304, 35547: 20024, 35548: 21547, 35549: 23736, 35550: 24012, 35551: 29609, 35552: 30284, 35553: 30524, 35554: 23721, 35555: 32747, 35556: 36107, 35557: 38593, 35558: 38929, 35559: 38996, 35560: 39e3, 35561: 20225, 35562: 20238, 35563: 21361, 35564: 21916, 35565: 22120, 35566: 22522, 35567: 22855, 35568: 23305, 35569: 23492, 35570: 23696, 35571: 24076, 35572: 24190, 35573: 24524, 35574: 25582, 35575: 26426, 35576: 26071, 35577: 26082, 35578: 26399, 35579: 26827, 35580: 26820, 35648: 27231, 35649: 24112, 35650: 27589, 35651: 27671, 35652: 27773, 35653: 30079, 35654: 31048, 35655: 23395, 35656: 31232, 35657: 32e3, 35658: 24509, 35659: 35215, 35660: 35352, 35661: 36020, 35662: 36215, 35663: 36556, 35664: 36637, 35665: 39138, 35666: 39438, 35667: 39740, 35668: 20096, 35669: 20605, 35670: 20736, 35671: 22931, 35672: 23452, 35673: 25135, 35674: 25216, 35675: 25836, 35676: 27450, 35677: 29344, 35678: 30097, 35679: 31047, 35680: 32681, 35681: 34811, 35682: 35516, 35683: 35696, 35684: 25516, 35685: 33738, 35686: 38816, 35687: 21513, 35688: 21507, 35689: 21931, 35690: 26708, 35691: 27224, 35692: 35440, 35693: 30759, 35694: 26485, 35695: 40653, 35696: 21364, 35697: 23458, 35698: 33050, 35699: 34384, 35700: 36870, 35701: 19992, 35702: 20037, 35703: 20167, 35704: 20241, 35705: 21450, 35706: 21560, 35707: 23470, 35708: 24339, 35709: 24613, 35710: 25937, 35712: 26429, 35713: 27714, 35714: 27762, 35715: 27875, 35716: 28792, 35717: 29699, 35718: 31350, 35719: 31406, 35720: 31496, 35721: 32026, 35722: 31998, 35723: 32102, 35724: 26087, 35725: 29275, 35726: 21435, 35727: 23621, 35728: 24040, 35729: 25298, 35730: 25312, 35731: 25369, 35732: 28192, 35733: 34394, 35734: 35377, 35735: 36317, 35736: 37624, 35737: 28417, 35738: 31142, 35739: 39770, 35740: 20136, 35741: 20139, 35742: 20140, 35743: 20379, 35744: 20384, 35745: 20689, 35746: 20807, 35747: 31478, 35748: 20849, 35749: 20982, 35750: 21332, 35751: 21281, 35752: 21375, 35753: 21483, 35754: 21932, 35755: 22659, 35756: 23777, 35757: 24375, 35758: 24394, 35759: 24623, 35760: 24656, 35761: 24685, 35762: 25375, 35763: 25945, 35764: 27211, 35765: 27841, 35766: 29378, 35767: 29421, 35768: 30703, 35769: 33016, 35770: 33029, 35771: 33288, 35772: 34126, 35773: 37111, 35774: 37857, 35775: 38911, 35776: 39255, 35777: 39514, 35778: 20208, 35779: 20957, 35780: 23597, 35781: 26241, 35782: 26989, 35783: 23616, 35784: 26354, 35785: 26997, 35786: 29577, 35787: 26704, 35788: 31873, 35789: 20677, 35790: 21220, 35791: 22343, 35792: 24062, 35793: 37670, 35794: 26020, 35795: 27427, 35796: 27453, 35797: 29748, 35798: 31105, 35799: 31165, 35800: 31563, 35801: 32202, 35802: 33465, 35803: 33740, 35804: 34943, 35805: 35167, 35806: 35641, 35807: 36817, 35808: 37329, 35809: 21535, 35810: 37504, 35811: 20061, 35812: 20534, 35813: 21477, 35814: 21306, 35815: 29399, 35816: 29590, 35817: 30697, 35818: 33510, 35819: 36527, 35820: 39366, 35821: 39368, 35822: 39378, 35823: 20855, 35824: 24858, 35825: 34398, 35826: 21936, 35827: 31354, 35828: 20598, 35829: 23507, 35830: 36935, 35831: 38533, 35832: 20018, 35833: 27355, 35834: 37351, 35835: 23633, 35836: 23624, 35904: 25496, 35905: 31391, 35906: 27795, 35907: 38772, 35908: 36705, 35909: 31402, 35910: 29066, 35911: 38536, 35912: 31874, 35913: 26647, 35914: 32368, 35915: 26705, 35916: 37740, 35917: 21234, 35918: 21531, 35919: 34219, 35920: 35347, 35921: 32676, 35922: 36557, 35923: 37089, 35924: 21350, 35925: 34952, 35926: 31041, 35927: 20418, 35928: 20670, 35929: 21009, 35930: 20804, 35931: 21843, 35932: 22317, 35933: 29674, 35934: 22411, 35935: 22865, 35936: 24418, 35937: 24452, 35938: 24693, 35939: 24950, 35940: 24935, 35941: 25001, 35942: 25522, 35943: 25658, 35944: 25964, 35945: 26223, 35946: 26690, 35947: 28179, 35948: 30054, 35949: 31293, 35950: 31995, 35951: 32076, 35952: 32153, 35953: 32331, 35954: 32619, 35955: 33550, 35956: 33610, 35957: 34509, 35958: 35336, 35959: 35427, 35960: 35686, 35961: 36605, 35962: 38938, 35963: 40335, 35964: 33464, 35965: 36814, 35966: 39912, 35968: 21127, 35969: 25119, 35970: 25731, 35971: 28608, 35972: 38553, 35973: 26689, 35974: 20625, 35975: 27424, 35976: 27770, 35977: 28500, 35978: 31348, 35979: 32080, 35980: 34880, 35981: 35363, 35982: 26376, 35983: 20214, 35984: 20537, 35985: 20518, 35986: 20581, 35987: 20860, 35988: 21048, 35989: 21091, 35990: 21927, 35991: 22287, 35992: 22533, 35993: 23244, 35994: 24314, 35995: 25010, 35996: 25080, 35997: 25331, 35998: 25458, 35999: 26908, 36e3: 27177, 36001: 29309, 36002: 29356, 36003: 29486, 36004: 30740, 36005: 30831, 36006: 32121, 36007: 30476, 36008: 32937, 36009: 35211, 36010: 35609, 36011: 36066, 36012: 36562, 36013: 36963, 36014: 37749, 36015: 38522, 36016: 38997, 36017: 39443, 36018: 40568, 36019: 20803, 36020: 21407, 36021: 21427, 36022: 24187, 36023: 24358, 36024: 28187, 36025: 28304, 36026: 29572, 36027: 29694, 36028: 32067, 36029: 33335, 36030: 35328, 36031: 35578, 36032: 38480, 36033: 20046, 36034: 20491, 36035: 21476, 36036: 21628, 36037: 22266, 36038: 22993, 36039: 23396, 36040: 24049, 36041: 24235, 36042: 24359, 36043: 25144, 36044: 25925, 36045: 26543, 36046: 28246, 36047: 29392, 36048: 31946, 36049: 34996, 36050: 32929, 36051: 32993, 36052: 33776, 36053: 34382, 36054: 35463, 36055: 36328, 36056: 37431, 36057: 38599, 36058: 39015, 36059: 40723, 36060: 20116, 36061: 20114, 36062: 20237, 36063: 21320, 36064: 21577, 36065: 21566, 36066: 23087, 36067: 24460, 36068: 24481, 36069: 24735, 36070: 26791, 36071: 27278, 36072: 29786, 36073: 30849, 36074: 35486, 36075: 35492, 36076: 35703, 36077: 37264, 36078: 20062, 36079: 39881, 36080: 20132, 36081: 20348, 36082: 20399, 36083: 20505, 36084: 20502, 36085: 20809, 36086: 20844, 36087: 21151, 36088: 21177, 36089: 21246, 36090: 21402, 36091: 21475, 36092: 21521, 36160: 21518, 36161: 21897, 36162: 22353, 36163: 22434, 36164: 22909, 36165: 23380, 36166: 23389, 36167: 23439, 36168: 24037, 36169: 24039, 36170: 24055, 36171: 24184, 36172: 24195, 36173: 24218, 36174: 24247, 36175: 24344, 36176: 24658, 36177: 24908, 36178: 25239, 36179: 25304, 36180: 25511, 36181: 25915, 36182: 26114, 36183: 26179, 36184: 26356, 36185: 26477, 36186: 26657, 36187: 26775, 36188: 27083, 36189: 27743, 36190: 27946, 36191: 28009, 36192: 28207, 36193: 28317, 36194: 30002, 36195: 30343, 36196: 30828, 36197: 31295, 36198: 31968, 36199: 32005, 36200: 32024, 36201: 32094, 36202: 32177, 36203: 32789, 36204: 32771, 36205: 32943, 36206: 32945, 36207: 33108, 36208: 33167, 36209: 33322, 36210: 33618, 36211: 34892, 36212: 34913, 36213: 35611, 36214: 36002, 36215: 36092, 36216: 37066, 36217: 37237, 36218: 37489, 36219: 30783, 36220: 37628, 36221: 38308, 36222: 38477, 36224: 38917, 36225: 39321, 36226: 39640, 36227: 40251, 36228: 21083, 36229: 21163, 36230: 21495, 36231: 21512, 36232: 22741, 36233: 25335, 36234: 28640, 36235: 35946, 36236: 36703, 36237: 40633, 36238: 20811, 36239: 21051, 36240: 21578, 36241: 22269, 36242: 31296, 36243: 37239, 36244: 40288, 36245: 40658, 36246: 29508, 36247: 28425, 36248: 33136, 36249: 29969, 36250: 24573, 36251: 24794, 36252: 39592, 36253: 29403, 36254: 36796, 36255: 27492, 36256: 38915, 36257: 20170, 36258: 22256, 36259: 22372, 36260: 22718, 36261: 23130, 36262: 24680, 36263: 25031, 36264: 26127, 36265: 26118, 36266: 26681, 36267: 26801, 36268: 28151, 36269: 30165, 36270: 32058, 36271: 33390, 36272: 39746, 36273: 20123, 36274: 20304, 36275: 21449, 36276: 21766, 36277: 23919, 36278: 24038, 36279: 24046, 36280: 26619, 36281: 27801, 36282: 29811, 36283: 30722, 36284: 35408, 36285: 37782, 36286: 35039, 36287: 22352, 36288: 24231, 36289: 25387, 36290: 20661, 36291: 20652, 36292: 20877, 36293: 26368, 36294: 21705, 36295: 22622, 36296: 22971, 36297: 23472, 36298: 24425, 36299: 25165, 36300: 25505, 36301: 26685, 36302: 27507, 36303: 28168, 36304: 28797, 36305: 37319, 36306: 29312, 36307: 30741, 36308: 30758, 36309: 31085, 36310: 25998, 36311: 32048, 36312: 33756, 36313: 35009, 36314: 36617, 36315: 38555, 36316: 21092, 36317: 22312, 36318: 26448, 36319: 32618, 36320: 36001, 36321: 20916, 36322: 22338, 36323: 38442, 36324: 22586, 36325: 27018, 36326: 32948, 36327: 21682, 36328: 23822, 36329: 22524, 36330: 30869, 36331: 40442, 36332: 20316, 36333: 21066, 36334: 21643, 36335: 25662, 36336: 26152, 36337: 26388, 36338: 26613, 36339: 31364, 36340: 31574, 36341: 32034, 36342: 37679, 36343: 26716, 36344: 39853, 36345: 31545, 36346: 21273, 36347: 20874, 36348: 21047, 36416: 23519, 36417: 25334, 36418: 25774, 36419: 25830, 36420: 26413, 36421: 27578, 36422: 34217, 36423: 38609, 36424: 30352, 36425: 39894, 36426: 25420, 36427: 37638, 36428: 39851, 36429: 30399, 36430: 26194, 36431: 19977, 36432: 20632, 36433: 21442, 36434: 23665, 36435: 24808, 36436: 25746, 36437: 25955, 36438: 26719, 36439: 29158, 36440: 29642, 36441: 29987, 36442: 31639, 36443: 32386, 36444: 34453, 36445: 35715, 36446: 36059, 36447: 37240, 36448: 39184, 36449: 26028, 36450: 26283, 36451: 27531, 36452: 20181, 36453: 20180, 36454: 20282, 36455: 20351, 36456: 21050, 36457: 21496, 36458: 21490, 36459: 21987, 36460: 22235, 36461: 22763, 36462: 22987, 36463: 22985, 36464: 23039, 36465: 23376, 36466: 23629, 36467: 24066, 36468: 24107, 36469: 24535, 36470: 24605, 36471: 25351, 36472: 25903, 36473: 23388, 36474: 26031, 36475: 26045, 36476: 26088, 36477: 26525, 36478: 27490, 36480: 27515, 36481: 27663, 36482: 29509, 36483: 31049, 36484: 31169, 36485: 31992, 36486: 32025, 36487: 32043, 36488: 32930, 36489: 33026, 36490: 33267, 36491: 35222, 36492: 35422, 36493: 35433, 36494: 35430, 36495: 35468, 36496: 35566, 36497: 36039, 36498: 36060, 36499: 38604, 36500: 39164, 36501: 27503, 36502: 20107, 36503: 20284, 36504: 20365, 36505: 20816, 36506: 23383, 36507: 23546, 36508: 24904, 36509: 25345, 36510: 26178, 36511: 27425, 36512: 28363, 36513: 27835, 36514: 29246, 36515: 29885, 36516: 30164, 36517: 30913, 36518: 31034, 36519: 32780, 36520: 32819, 36521: 33258, 36522: 33940, 36523: 36766, 36524: 27728, 36525: 40575, 36526: 24335, 36527: 35672, 36528: 40235, 36529: 31482, 36530: 36600, 36531: 23437, 36532: 38635, 36533: 19971, 36534: 21489, 36535: 22519, 36536: 22833, 36537: 23241, 36538: 23460, 36539: 24713, 36540: 28287, 36541: 28422, 36542: 30142, 36543: 36074, 36544: 23455, 36545: 34048, 36546: 31712, 36547: 20594, 36548: 26612, 36549: 33437, 36550: 23649, 36551: 34122, 36552: 32286, 36553: 33294, 36554: 20889, 36555: 23556, 36556: 25448, 36557: 36198, 36558: 26012, 36559: 29038, 36560: 31038, 36561: 32023, 36562: 32773, 36563: 35613, 36564: 36554, 36565: 36974, 36566: 34503, 36567: 37034, 36568: 20511, 36569: 21242, 36570: 23610, 36571: 26451, 36572: 28796, 36573: 29237, 36574: 37196, 36575: 37320, 36576: 37675, 36577: 33509, 36578: 23490, 36579: 24369, 36580: 24825, 36581: 20027, 36582: 21462, 36583: 23432, 36584: 25163, 36585: 26417, 36586: 27530, 36587: 29417, 36588: 29664, 36589: 31278, 36590: 33131, 36591: 36259, 36592: 37202, 36593: 39318, 36594: 20754, 36595: 21463, 36596: 21610, 36597: 23551, 36598: 25480, 36599: 27193, 36600: 32172, 36601: 38656, 36602: 22234, 36603: 21454, 36604: 21608, 36672: 23447, 36673: 23601, 36674: 24030, 36675: 20462, 36676: 24833, 36677: 25342, 36678: 27954, 36679: 31168, 36680: 31179, 36681: 32066, 36682: 32333, 36683: 32722, 36684: 33261, 36685: 33311, 36686: 33936, 36687: 34886, 36688: 35186, 36689: 35728, 36690: 36468, 36691: 36655, 36692: 36913, 36693: 37195, 36694: 37228, 36695: 38598, 36696: 37276, 36697: 20160, 36698: 20303, 36699: 20805, 36700: 21313, 36701: 24467, 36702: 25102, 36703: 26580, 36704: 27713, 36705: 28171, 36706: 29539, 36707: 32294, 36708: 37325, 36709: 37507, 36710: 21460, 36711: 22809, 36712: 23487, 36713: 28113, 36714: 31069, 36715: 32302, 36716: 31899, 36717: 22654, 36718: 29087, 36719: 20986, 36720: 34899, 36721: 36848, 36722: 20426, 36723: 23803, 36724: 26149, 36725: 30636, 36726: 31459, 36727: 33308, 36728: 39423, 36729: 20934, 36730: 24490, 36731: 26092, 36732: 26991, 36733: 27529, 36734: 28147, 36736: 28310, 36737: 28516, 36738: 30462, 36739: 32020, 36740: 24033, 36741: 36981, 36742: 37255, 36743: 38918, 36744: 20966, 36745: 21021, 36746: 25152, 36747: 26257, 36748: 26329, 36749: 28186, 36750: 24246, 36751: 32210, 36752: 32626, 36753: 26360, 36754: 34223, 36755: 34295, 36756: 35576, 36757: 21161, 36758: 21465, 36759: 22899, 36760: 24207, 36761: 24464, 36762: 24661, 36763: 37604, 36764: 38500, 36765: 20663, 36766: 20767, 36767: 21213, 36768: 21280, 36769: 21319, 36770: 21484, 36771: 21736, 36772: 21830, 36773: 21809, 36774: 22039, 36775: 22888, 36776: 22974, 36777: 23100, 36778: 23477, 36779: 23558, 36780: 23567, 36781: 23569, 36782: 23578, 36783: 24196, 36784: 24202, 36785: 24288, 36786: 24432, 36787: 25215, 36788: 25220, 36789: 25307, 36790: 25484, 36791: 25463, 36792: 26119, 36793: 26124, 36794: 26157, 36795: 26230, 36796: 26494, 36797: 26786, 36798: 27167, 36799: 27189, 36800: 27836, 36801: 28040, 36802: 28169, 36803: 28248, 36804: 28988, 36805: 28966, 36806: 29031, 36807: 30151, 36808: 30465, 36809: 30813, 36810: 30977, 36811: 31077, 36812: 31216, 36813: 31456, 36814: 31505, 36815: 31911, 36816: 32057, 36817: 32918, 36818: 33750, 36819: 33931, 36820: 34121, 36821: 34909, 36822: 35059, 36823: 35359, 36824: 35388, 36825: 35412, 36826: 35443, 36827: 35937, 36828: 36062, 36829: 37284, 36830: 37478, 36831: 37758, 36832: 37912, 36833: 38556, 36834: 38808, 36835: 19978, 36836: 19976, 36837: 19998, 36838: 20055, 36839: 20887, 36840: 21104, 36841: 22478, 36842: 22580, 36843: 22732, 36844: 23330, 36845: 24120, 36846: 24773, 36847: 25854, 36848: 26465, 36849: 26454, 36850: 27972, 36851: 29366, 36852: 30067, 36853: 31331, 36854: 33976, 36855: 35698, 36856: 37304, 36857: 37664, 36858: 22065, 36859: 22516, 36860: 39166, 36928: 25325, 36929: 26893, 36930: 27542, 36931: 29165, 36932: 32340, 36933: 32887, 36934: 33394, 36935: 35302, 36936: 39135, 36937: 34645, 36938: 36785, 36939: 23611, 36940: 20280, 36941: 20449, 36942: 20405, 36943: 21767, 36944: 23072, 36945: 23517, 36946: 23529, 36947: 24515, 36948: 24910, 36949: 25391, 36950: 26032, 36951: 26187, 36952: 26862, 36953: 27035, 36954: 28024, 36955: 28145, 36956: 30003, 36957: 30137, 36958: 30495, 36959: 31070, 36960: 31206, 36961: 32051, 36962: 33251, 36963: 33455, 36964: 34218, 36965: 35242, 36966: 35386, 36967: 36523, 36968: 36763, 36969: 36914, 36970: 37341, 36971: 38663, 36972: 20154, 36973: 20161, 36974: 20995, 36975: 22645, 36976: 22764, 36977: 23563, 36978: 29978, 36979: 23613, 36980: 33102, 36981: 35338, 36982: 36805, 36983: 38499, 36984: 38765, 36985: 31525, 36986: 35535, 36987: 38920, 36988: 37218, 36989: 22259, 36990: 21416, 36992: 36887, 36993: 21561, 36994: 22402, 36995: 24101, 36996: 25512, 36997: 27700, 36998: 28810, 36999: 30561, 37e3: 31883, 37001: 32736, 37002: 34928, 37003: 36930, 37004: 37204, 37005: 37648, 37006: 37656, 37007: 38543, 37008: 29790, 37009: 39620, 37010: 23815, 37011: 23913, 37012: 25968, 37013: 26530, 37014: 36264, 37015: 38619, 37016: 25454, 37017: 26441, 37018: 26905, 37019: 33733, 37020: 38935, 37021: 38592, 37022: 35070, 37023: 28548, 37024: 25722, 37025: 23544, 37026: 19990, 37027: 28716, 37028: 30045, 37029: 26159, 37030: 20932, 37031: 21046, 37032: 21218, 37033: 22995, 37034: 24449, 37035: 24615, 37036: 25104, 37037: 25919, 37038: 25972, 37039: 26143, 37040: 26228, 37041: 26866, 37042: 26646, 37043: 27491, 37044: 28165, 37045: 29298, 37046: 29983, 37047: 30427, 37048: 31934, 37049: 32854, 37050: 22768, 37051: 35069, 37052: 35199, 37053: 35488, 37054: 35475, 37055: 35531, 37056: 36893, 37057: 37266, 37058: 38738, 37059: 38745, 37060: 25993, 37061: 31246, 37062: 33030, 37063: 38587, 37064: 24109, 37065: 24796, 37066: 25114, 37067: 26021, 37068: 26132, 37069: 26512, 37070: 30707, 37071: 31309, 37072: 31821, 37073: 32318, 37074: 33034, 37075: 36012, 37076: 36196, 37077: 36321, 37078: 36447, 37079: 30889, 37080: 20999, 37081: 25305, 37082: 25509, 37083: 25666, 37084: 25240, 37085: 35373, 37086: 31363, 37087: 31680, 37088: 35500, 37089: 38634, 37090: 32118, 37091: 33292, 37092: 34633, 37093: 20185, 37094: 20808, 37095: 21315, 37096: 21344, 37097: 23459, 37098: 23554, 37099: 23574, 37100: 24029, 37101: 25126, 37102: 25159, 37103: 25776, 37104: 26643, 37105: 26676, 37106: 27849, 37107: 27973, 37108: 27927, 37109: 26579, 37110: 28508, 37111: 29006, 37112: 29053, 37113: 26059, 37114: 31359, 37115: 31661, 37116: 32218, 37184: 32330, 37185: 32680, 37186: 33146, 37187: 33307, 37188: 33337, 37189: 34214, 37190: 35438, 37191: 36046, 37192: 36341, 37193: 36984, 37194: 36983, 37195: 37549, 37196: 37521, 37197: 38275, 37198: 39854, 37199: 21069, 37200: 21892, 37201: 28472, 37202: 28982, 37203: 20840, 37204: 31109, 37205: 32341, 37206: 33203, 37207: 31950, 37208: 22092, 37209: 22609, 37210: 23720, 37211: 25514, 37212: 26366, 37213: 26365, 37214: 26970, 37215: 29401, 37216: 30095, 37217: 30094, 37218: 30990, 37219: 31062, 37220: 31199, 37221: 31895, 37222: 32032, 37223: 32068, 37224: 34311, 37225: 35380, 37226: 38459, 37227: 36961, 37228: 40736, 37229: 20711, 37230: 21109, 37231: 21452, 37232: 21474, 37233: 20489, 37234: 21930, 37235: 22766, 37236: 22863, 37237: 29245, 37238: 23435, 37239: 23652, 37240: 21277, 37241: 24803, 37242: 24819, 37243: 25436, 37244: 25475, 37245: 25407, 37246: 25531, 37248: 25805, 37249: 26089, 37250: 26361, 37251: 24035, 37252: 27085, 37253: 27133, 37254: 28437, 37255: 29157, 37256: 20105, 37257: 30185, 37258: 30456, 37259: 31379, 37260: 31967, 37261: 32207, 37262: 32156, 37263: 32865, 37264: 33609, 37265: 33624, 37266: 33900, 37267: 33980, 37268: 34299, 37269: 35013, 37270: 36208, 37271: 36865, 37272: 36973, 37273: 37783, 37274: 38684, 37275: 39442, 37276: 20687, 37277: 22679, 37278: 24974, 37279: 33235, 37280: 34101, 37281: 36104, 37282: 36896, 37283: 20419, 37284: 20596, 37285: 21063, 37286: 21363, 37287: 24687, 37288: 25417, 37289: 26463, 37290: 28204, 37291: 36275, 37292: 36895, 37293: 20439, 37294: 23646, 37295: 36042, 37296: 26063, 37297: 32154, 37298: 21330, 37299: 34966, 37300: 20854, 37301: 25539, 37302: 23384, 37303: 23403, 37304: 23562, 37305: 25613, 37306: 26449, 37307: 36956, 37308: 20182, 37309: 22810, 37310: 22826, 37311: 27760, 37312: 35409, 37313: 21822, 37314: 22549, 37315: 22949, 37316: 24816, 37317: 25171, 37318: 26561, 37319: 33333, 37320: 26965, 37321: 38464, 37322: 39364, 37323: 39464, 37324: 20307, 37325: 22534, 37326: 23550, 37327: 32784, 37328: 23729, 37329: 24111, 37330: 24453, 37331: 24608, 37332: 24907, 37333: 25140, 37334: 26367, 37335: 27888, 37336: 28382, 37337: 32974, 37338: 33151, 37339: 33492, 37340: 34955, 37341: 36024, 37342: 36864, 37343: 36910, 37344: 38538, 37345: 40667, 37346: 39899, 37347: 20195, 37348: 21488, 37349: 22823, 37350: 31532, 37351: 37261, 37352: 38988, 37353: 40441, 37354: 28381, 37355: 28711, 37356: 21331, 37357: 21828, 37358: 23429, 37359: 25176, 37360: 25246, 37361: 25299, 37362: 27810, 37363: 28655, 37364: 29730, 37365: 35351, 37366: 37944, 37367: 28609, 37368: 35582, 37369: 33592, 37370: 20967, 37371: 34552, 37372: 21482, 37440: 21481, 37441: 20294, 37442: 36948, 37443: 36784, 37444: 22890, 37445: 33073, 37446: 24061, 37447: 31466, 37448: 36799, 37449: 26842, 37450: 35895, 37451: 29432, 37452: 40008, 37453: 27197, 37454: 35504, 37455: 20025, 37456: 21336, 37457: 22022, 37458: 22374, 37459: 25285, 37460: 25506, 37461: 26086, 37462: 27470, 37463: 28129, 37464: 28251, 37465: 28845, 37466: 30701, 37467: 31471, 37468: 31658, 37469: 32187, 37470: 32829, 37471: 32966, 37472: 34507, 37473: 35477, 37474: 37723, 37475: 22243, 37476: 22727, 37477: 24382, 37478: 26029, 37479: 26262, 37480: 27264, 37481: 27573, 37482: 30007, 37483: 35527, 37484: 20516, 37485: 30693, 37486: 22320, 37487: 24347, 37488: 24677, 37489: 26234, 37490: 27744, 37491: 30196, 37492: 31258, 37493: 32622, 37494: 33268, 37495: 34584, 37496: 36933, 37497: 39347, 37498: 31689, 37499: 30044, 37500: 31481, 37501: 31569, 37502: 33988, 37504: 36880, 37505: 31209, 37506: 31378, 37507: 33590, 37508: 23265, 37509: 30528, 37510: 20013, 37511: 20210, 37512: 23449, 37513: 24544, 37514: 25277, 37515: 26172, 37516: 26609, 37517: 27880, 37518: 34411, 37519: 34935, 37520: 35387, 37521: 37198, 37522: 37619, 37523: 39376, 37524: 27159, 37525: 28710, 37526: 29482, 37527: 33511, 37528: 33879, 37529: 36015, 37530: 19969, 37531: 20806, 37532: 20939, 37533: 21899, 37534: 23541, 37535: 24086, 37536: 24115, 37537: 24193, 37538: 24340, 37539: 24373, 37540: 24427, 37541: 24500, 37542: 25074, 37543: 25361, 37544: 26274, 37545: 26397, 37546: 28526, 37547: 29266, 37548: 30010, 37549: 30522, 37550: 32884, 37551: 33081, 37552: 33144, 37553: 34678, 37554: 35519, 37555: 35548, 37556: 36229, 37557: 36339, 37558: 37530, 37559: 38263, 37560: 38914, 37561: 40165, 37562: 21189, 37563: 25431, 37564: 30452, 37565: 26389, 37566: 27784, 37567: 29645, 37568: 36035, 37569: 37806, 37570: 38515, 37571: 27941, 37572: 22684, 37573: 26894, 37574: 27084, 37575: 36861, 37576: 37786, 37577: 30171, 37578: 36890, 37579: 22618, 37580: 26626, 37581: 25524, 37582: 27131, 37583: 20291, 37584: 28460, 37585: 26584, 37586: 36795, 37587: 34086, 37588: 32180, 37589: 37716, 37590: 26943, 37591: 28528, 37592: 22378, 37593: 22775, 37594: 23340, 37595: 32044, 37596: 29226, 37597: 21514, 37598: 37347, 37599: 40372, 37600: 20141, 37601: 20302, 37602: 20572, 37603: 20597, 37604: 21059, 37605: 35998, 37606: 21576, 37607: 22564, 37608: 23450, 37609: 24093, 37610: 24213, 37611: 24237, 37612: 24311, 37613: 24351, 37614: 24716, 37615: 25269, 37616: 25402, 37617: 25552, 37618: 26799, 37619: 27712, 37620: 30855, 37621: 31118, 37622: 31243, 37623: 32224, 37624: 33351, 37625: 35330, 37626: 35558, 37627: 36420, 37628: 36883, 37696: 37048, 37697: 37165, 37698: 37336, 37699: 40718, 37700: 27877, 37701: 25688, 37702: 25826, 37703: 25973, 37704: 28404, 37705: 30340, 37706: 31515, 37707: 36969, 37708: 37841, 37709: 28346, 37710: 21746, 37711: 24505, 37712: 25764, 37713: 36685, 37714: 36845, 37715: 37444, 37716: 20856, 37717: 22635, 37718: 22825, 37719: 23637, 37720: 24215, 37721: 28155, 37722: 32399, 37723: 29980, 37724: 36028, 37725: 36578, 37726: 39003, 37727: 28857, 37728: 20253, 37729: 27583, 37730: 28593, 37731: 3e4, 37732: 38651, 37733: 20814, 37734: 21520, 37735: 22581, 37736: 22615, 37737: 22956, 37738: 23648, 37739: 24466, 37740: 26007, 37741: 26460, 37742: 28193, 37743: 30331, 37744: 33759, 37745: 36077, 37746: 36884, 37747: 37117, 37748: 37709, 37749: 30757, 37750: 30778, 37751: 21162, 37752: 24230, 37753: 22303, 37754: 22900, 37755: 24594, 37756: 20498, 37757: 20826, 37758: 20908, 37760: 20941, 37761: 20992, 37762: 21776, 37763: 22612, 37764: 22616, 37765: 22871, 37766: 23445, 37767: 23798, 37768: 23947, 37769: 24764, 37770: 25237, 37771: 25645, 37772: 26481, 37773: 26691, 37774: 26812, 37775: 26847, 37776: 30423, 37777: 28120, 37778: 28271, 37779: 28059, 37780: 28783, 37781: 29128, 37782: 24403, 37783: 30168, 37784: 31095, 37785: 31561, 37786: 31572, 37787: 31570, 37788: 31958, 37789: 32113, 37790: 21040, 37791: 33891, 37792: 34153, 37793: 34276, 37794: 35342, 37795: 35588, 37796: 35910, 37797: 36367, 37798: 36867, 37799: 36879, 37800: 37913, 37801: 38518, 37802: 38957, 37803: 39472, 37804: 38360, 37805: 20685, 37806: 21205, 37807: 21516, 37808: 22530, 37809: 23566, 37810: 24999, 37811: 25758, 37812: 27934, 37813: 30643, 37814: 31461, 37815: 33012, 37816: 33796, 37817: 36947, 37818: 37509, 37819: 23776, 37820: 40199, 37821: 21311, 37822: 24471, 37823: 24499, 37824: 28060, 37825: 29305, 37826: 30563, 37827: 31167, 37828: 31716, 37829: 27602, 37830: 29420, 37831: 35501, 37832: 26627, 37833: 27233, 37834: 20984, 37835: 31361, 37836: 26932, 37837: 23626, 37838: 40182, 37839: 33515, 37840: 23493, 37841: 37193, 37842: 28702, 37843: 22136, 37844: 23663, 37845: 24775, 37846: 25958, 37847: 27788, 37848: 35930, 37849: 36929, 37850: 38931, 37851: 21585, 37852: 26311, 37853: 37389, 37854: 22856, 37855: 37027, 37856: 20869, 37857: 20045, 37858: 20970, 37859: 34201, 37860: 35598, 37861: 28760, 37862: 25466, 37863: 37707, 37864: 26978, 37865: 39348, 37866: 32260, 37867: 30071, 37868: 21335, 37869: 26976, 37870: 36575, 37871: 38627, 37872: 27741, 37873: 20108, 37874: 23612, 37875: 24336, 37876: 36841, 37877: 21250, 37878: 36049, 37879: 32905, 37880: 34425, 37881: 24319, 37882: 26085, 37883: 20083, 37884: 20837, 37952: 22914, 37953: 23615, 37954: 38894, 37955: 20219, 37956: 22922, 37957: 24525, 37958: 35469, 37959: 28641, 37960: 31152, 37961: 31074, 37962: 23527, 37963: 33905, 37964: 29483, 37965: 29105, 37966: 24180, 37967: 24565, 37968: 25467, 37969: 25754, 37970: 29123, 37971: 31896, 37972: 20035, 37973: 24316, 37974: 20043, 37975: 22492, 37976: 22178, 37977: 24745, 37978: 28611, 37979: 32013, 37980: 33021, 37981: 33075, 37982: 33215, 37983: 36786, 37984: 35223, 37985: 34468, 37986: 24052, 37987: 25226, 37988: 25773, 37989: 35207, 37990: 26487, 37991: 27874, 37992: 27966, 37993: 29750, 37994: 30772, 37995: 23110, 37996: 32629, 37997: 33453, 37998: 39340, 37999: 20467, 38e3: 24259, 38001: 25309, 38002: 25490, 38003: 25943, 38004: 26479, 38005: 30403, 38006: 29260, 38007: 32972, 38008: 32954, 38009: 36649, 38010: 37197, 38011: 20493, 38012: 22521, 38013: 23186, 38014: 26757, 38016: 26995, 38017: 29028, 38018: 29437, 38019: 36023, 38020: 22770, 38021: 36064, 38022: 38506, 38023: 36889, 38024: 34687, 38025: 31204, 38026: 30695, 38027: 33833, 38028: 20271, 38029: 21093, 38030: 21338, 38031: 25293, 38032: 26575, 38033: 27850, 38034: 30333, 38035: 31636, 38036: 31893, 38037: 33334, 38038: 34180, 38039: 36843, 38040: 26333, 38041: 28448, 38042: 29190, 38043: 32283, 38044: 33707, 38045: 39361, 38046: 40614, 38047: 20989, 38048: 31665, 38049: 30834, 38050: 31672, 38051: 32903, 38052: 31560, 38053: 27368, 38054: 24161, 38055: 32908, 38056: 30033, 38057: 30048, 38058: 20843, 38059: 37474, 38060: 28300, 38061: 30330, 38062: 37271, 38063: 39658, 38064: 20240, 38065: 32624, 38066: 25244, 38067: 31567, 38068: 38309, 38069: 40169, 38070: 22138, 38071: 22617, 38072: 34532, 38073: 38588, 38074: 20276, 38075: 21028, 38076: 21322, 38077: 21453, 38078: 21467, 38079: 24070, 38080: 25644, 38081: 26001, 38082: 26495, 38083: 27710, 38084: 27726, 38085: 29256, 38086: 29359, 38087: 29677, 38088: 30036, 38089: 32321, 38090: 33324, 38091: 34281, 38092: 36009, 38093: 31684, 38094: 37318, 38095: 29033, 38096: 38930, 38097: 39151, 38098: 25405, 38099: 26217, 38100: 30058, 38101: 30436, 38102: 30928, 38103: 34115, 38104: 34542, 38105: 21290, 38106: 21329, 38107: 21542, 38108: 22915, 38109: 24199, 38110: 24444, 38111: 24754, 38112: 25161, 38113: 25209, 38114: 25259, 38115: 26e3, 38116: 27604, 38117: 27852, 38118: 30130, 38119: 30382, 38120: 30865, 38121: 31192, 38122: 32203, 38123: 32631, 38124: 32933, 38125: 34987, 38126: 35513, 38127: 36027, 38128: 36991, 38129: 38750, 38130: 39131, 38131: 27147, 38132: 31800, 38133: 20633, 38134: 23614, 38135: 24494, 38136: 26503, 38137: 27608, 38138: 29749, 38139: 30473, 38140: 32654, 38208: 40763, 38209: 26570, 38210: 31255, 38211: 21305, 38212: 30091, 38213: 39661, 38214: 24422, 38215: 33181, 38216: 33777, 38217: 32920, 38218: 24380, 38219: 24517, 38220: 30050, 38221: 31558, 38222: 36924, 38223: 26727, 38224: 23019, 38225: 23195, 38226: 32016, 38227: 30334, 38228: 35628, 38229: 20469, 38230: 24426, 38231: 27161, 38232: 27703, 38233: 28418, 38234: 29922, 38235: 31080, 38236: 34920, 38237: 35413, 38238: 35961, 38239: 24287, 38240: 25551, 38241: 30149, 38242: 31186, 38243: 33495, 38244: 37672, 38245: 37618, 38246: 33948, 38247: 34541, 38248: 39981, 38249: 21697, 38250: 24428, 38251: 25996, 38252: 27996, 38253: 28693, 38254: 36007, 38255: 36051, 38256: 38971, 38257: 25935, 38258: 29942, 38259: 19981, 38260: 20184, 38261: 22496, 38262: 22827, 38263: 23142, 38264: 23500, 38265: 20904, 38266: 24067, 38267: 24220, 38268: 24598, 38269: 25206, 38270: 25975, 38272: 26023, 38273: 26222, 38274: 28014, 38275: 29238, 38276: 31526, 38277: 33104, 38278: 33178, 38279: 33433, 38280: 35676, 38281: 36e3, 38282: 36070, 38283: 36212, 38284: 38428, 38285: 38468, 38286: 20398, 38287: 25771, 38288: 27494, 38289: 33310, 38290: 33889, 38291: 34154, 38292: 37096, 38293: 23553, 38294: 26963, 38295: 39080, 38296: 33914, 38297: 34135, 38298: 20239, 38299: 21103, 38300: 24489, 38301: 24133, 38302: 26381, 38303: 31119, 38304: 33145, 38305: 35079, 38306: 35206, 38307: 28149, 38308: 24343, 38309: 25173, 38310: 27832, 38311: 20175, 38312: 29289, 38313: 39826, 38314: 20998, 38315: 21563, 38316: 22132, 38317: 22707, 38318: 24996, 38319: 25198, 38320: 28954, 38321: 22894, 38322: 31881, 38323: 31966, 38324: 32027, 38325: 38640, 38326: 25991, 38327: 32862, 38328: 19993, 38329: 20341, 38330: 20853, 38331: 22592, 38332: 24163, 38333: 24179, 38334: 24330, 38335: 26564, 38336: 20006, 38337: 34109, 38338: 38281, 38339: 38491, 38340: 31859, 38341: 38913, 38342: 20731, 38343: 22721, 38344: 30294, 38345: 30887, 38346: 21029, 38347: 30629, 38348: 34065, 38349: 31622, 38350: 20559, 38351: 22793, 38352: 29255, 38353: 31687, 38354: 32232, 38355: 36794, 38356: 36820, 38357: 36941, 38358: 20415, 38359: 21193, 38360: 23081, 38361: 24321, 38362: 38829, 38363: 20445, 38364: 33303, 38365: 37610, 38366: 22275, 38367: 25429, 38368: 27497, 38369: 29995, 38370: 35036, 38371: 36628, 38372: 31298, 38373: 21215, 38374: 22675, 38375: 24917, 38376: 25098, 38377: 26286, 38378: 27597, 38379: 31807, 38380: 33769, 38381: 20515, 38382: 20472, 38383: 21253, 38384: 21574, 38385: 22577, 38386: 22857, 38387: 23453, 38388: 23792, 38389: 23791, 38390: 23849, 38391: 24214, 38392: 25265, 38393: 25447, 38394: 25918, 38395: 26041, 38396: 26379, 38464: 27861, 38465: 27873, 38466: 28921, 38467: 30770, 38468: 32299, 38469: 32990, 38470: 33459, 38471: 33804, 38472: 34028, 38473: 34562, 38474: 35090, 38475: 35370, 38476: 35914, 38477: 37030, 38478: 37586, 38479: 39165, 38480: 40179, 38481: 40300, 38482: 20047, 38483: 20129, 38484: 20621, 38485: 21078, 38486: 22346, 38487: 22952, 38488: 24125, 38489: 24536, 38490: 24537, 38491: 25151, 38492: 26292, 38493: 26395, 38494: 26576, 38495: 26834, 38496: 20882, 38497: 32033, 38498: 32938, 38499: 33192, 38500: 35584, 38501: 35980, 38502: 36031, 38503: 37502, 38504: 38450, 38505: 21536, 38506: 38956, 38507: 21271, 38508: 20693, 38509: 21340, 38510: 22696, 38511: 25778, 38512: 26420, 38513: 29287, 38514: 30566, 38515: 31302, 38516: 37350, 38517: 21187, 38518: 27809, 38519: 27526, 38520: 22528, 38521: 24140, 38522: 22868, 38523: 26412, 38524: 32763, 38525: 20961, 38526: 30406, 38528: 25705, 38529: 30952, 38530: 39764, 38531: 40635, 38532: 22475, 38533: 22969, 38534: 26151, 38535: 26522, 38536: 27598, 38537: 21737, 38538: 27097, 38539: 24149, 38540: 33180, 38541: 26517, 38542: 39850, 38543: 26622, 38544: 40018, 38545: 26717, 38546: 20134, 38547: 20451, 38548: 21448, 38549: 25273, 38550: 26411, 38551: 27819, 38552: 36804, 38553: 20397, 38554: 32365, 38555: 40639, 38556: 19975, 38557: 24930, 38558: 28288, 38559: 28459, 38560: 34067, 38561: 21619, 38562: 26410, 38563: 39749, 38564: 24051, 38565: 31637, 38566: 23724, 38567: 23494, 38568: 34588, 38569: 28234, 38570: 34001, 38571: 31252, 38572: 33032, 38573: 22937, 38574: 31885, 38575: 27665, 38576: 30496, 38577: 21209, 38578: 22818, 38579: 28961, 38580: 29279, 38581: 30683, 38582: 38695, 38583: 40289, 38584: 26891, 38585: 23167, 38586: 23064, 38587: 20901, 38588: 21517, 38589: 21629, 38590: 26126, 38591: 30431, 38592: 36855, 38593: 37528, 38594: 40180, 38595: 23018, 38596: 29277, 38597: 28357, 38598: 20813, 38599: 26825, 38600: 32191, 38601: 32236, 38602: 38754, 38603: 40634, 38604: 25720, 38605: 27169, 38606: 33538, 38607: 22916, 38608: 23391, 38609: 27611, 38610: 29467, 38611: 30450, 38612: 32178, 38613: 32791, 38614: 33945, 38615: 20786, 38616: 26408, 38617: 40665, 38618: 30446, 38619: 26466, 38620: 21247, 38621: 39173, 38622: 23588, 38623: 25147, 38624: 31870, 38625: 36016, 38626: 21839, 38627: 24758, 38628: 32011, 38629: 38272, 38630: 21249, 38631: 20063, 38632: 20918, 38633: 22812, 38634: 29242, 38635: 32822, 38636: 37326, 38637: 24357, 38638: 30690, 38639: 21380, 38640: 24441, 38641: 32004, 38642: 34220, 38643: 35379, 38644: 36493, 38645: 38742, 38646: 26611, 38647: 34222, 38648: 37971, 38649: 24841, 38650: 24840, 38651: 27833, 38652: 30290, 38720: 35565, 38721: 36664, 38722: 21807, 38723: 20305, 38724: 20778, 38725: 21191, 38726: 21451, 38727: 23461, 38728: 24189, 38729: 24736, 38730: 24962, 38731: 25558, 38732: 26377, 38733: 26586, 38734: 28263, 38735: 28044, 38736: 29494, 38737: 29495, 38738: 30001, 38739: 31056, 38740: 35029, 38741: 35480, 38742: 36938, 38743: 37009, 38744: 37109, 38745: 38596, 38746: 34701, 38747: 22805, 38748: 20104, 38749: 20313, 38750: 19982, 38751: 35465, 38752: 36671, 38753: 38928, 38754: 20653, 38755: 24188, 38756: 22934, 38757: 23481, 38758: 24248, 38759: 25562, 38760: 25594, 38761: 25793, 38762: 26332, 38763: 26954, 38764: 27096, 38765: 27915, 38766: 28342, 38767: 29076, 38768: 29992, 38769: 31407, 38770: 32650, 38771: 32768, 38772: 33865, 38773: 33993, 38774: 35201, 38775: 35617, 38776: 36362, 38777: 36965, 38778: 38525, 38779: 39178, 38780: 24958, 38781: 25233, 38782: 27442, 38784: 27779, 38785: 28020, 38786: 32716, 38787: 32764, 38788: 28096, 38789: 32645, 38790: 34746, 38791: 35064, 38792: 26469, 38793: 33713, 38794: 38972, 38795: 38647, 38796: 27931, 38797: 32097, 38798: 33853, 38799: 37226, 38800: 20081, 38801: 21365, 38802: 23888, 38803: 27396, 38804: 28651, 38805: 34253, 38806: 34349, 38807: 35239, 38808: 21033, 38809: 21519, 38810: 23653, 38811: 26446, 38812: 26792, 38813: 29702, 38814: 29827, 38815: 30178, 38816: 35023, 38817: 35041, 38818: 37324, 38819: 38626, 38820: 38520, 38821: 24459, 38822: 29575, 38823: 31435, 38824: 33870, 38825: 25504, 38826: 30053, 38827: 21129, 38828: 27969, 38829: 28316, 38830: 29705, 38831: 30041, 38832: 30827, 38833: 31890, 38834: 38534, 38835: 31452, 38836: 40845, 38837: 20406, 38838: 24942, 38839: 26053, 38840: 34396, 38841: 20102, 38842: 20142, 38843: 20698, 38844: 20001, 38845: 20940, 38846: 23534, 38847: 26009, 38848: 26753, 38849: 28092, 38850: 29471, 38851: 30274, 38852: 30637, 38853: 31260, 38854: 31975, 38855: 33391, 38856: 35538, 38857: 36988, 38858: 37327, 38859: 38517, 38860: 38936, 38861: 21147, 38862: 32209, 38863: 20523, 38864: 21400, 38865: 26519, 38866: 28107, 38867: 29136, 38868: 29747, 38869: 33256, 38870: 36650, 38871: 38563, 38872: 40023, 38873: 40607, 38874: 29792, 38875: 22593, 38876: 28057, 38877: 32047, 38878: 39006, 38879: 20196, 38880: 20278, 38881: 20363, 38882: 20919, 38883: 21169, 38884: 23994, 38885: 24604, 38886: 29618, 38887: 31036, 38888: 33491, 38889: 37428, 38890: 38583, 38891: 38646, 38892: 38666, 38893: 40599, 38894: 40802, 38895: 26278, 38896: 27508, 38897: 21015, 38898: 21155, 38899: 28872, 38900: 35010, 38901: 24265, 38902: 24651, 38903: 24976, 38904: 28451, 38905: 29001, 38906: 31806, 38907: 32244, 38908: 32879, 38976: 34030, 38977: 36899, 38978: 37676, 38979: 21570, 38980: 39791, 38981: 27347, 38982: 28809, 38983: 36034, 38984: 36335, 38985: 38706, 38986: 21172, 38987: 23105, 38988: 24266, 38989: 24324, 38990: 26391, 38991: 27004, 38992: 27028, 38993: 28010, 38994: 28431, 38995: 29282, 38996: 29436, 38997: 31725, 38998: 32769, 38999: 32894, 39e3: 34635, 39001: 37070, 39002: 20845, 39003: 40595, 39004: 31108, 39005: 32907, 39006: 37682, 39007: 35542, 39008: 20525, 39009: 21644, 39010: 35441, 39011: 27498, 39012: 36036, 39013: 33031, 39014: 24785, 39015: 26528, 39016: 40434, 39017: 20121, 39018: 20120, 39019: 39952, 39020: 35435, 39021: 34241, 39022: 34152, 39023: 26880, 39024: 28286, 39025: 30871, 39026: 33109, 39071: 24332, 39072: 19984, 39073: 19989, 39074: 20010, 39075: 20017, 39076: 20022, 39077: 20028, 39078: 20031, 39079: 20034, 39080: 20054, 39081: 20056, 39082: 20098, 39083: 20101, 39084: 35947, 39085: 20106, 39086: 33298, 39087: 24333, 39088: 20110, 39089: 20126, 39090: 20127, 39091: 20128, 39092: 20130, 39093: 20144, 39094: 20147, 39095: 20150, 39096: 20174, 39097: 20173, 39098: 20164, 39099: 20166, 39100: 20162, 39101: 20183, 39102: 20190, 39103: 20205, 39104: 20191, 39105: 20215, 39106: 20233, 39107: 20314, 39108: 20272, 39109: 20315, 39110: 20317, 39111: 20311, 39112: 20295, 39113: 20342, 39114: 20360, 39115: 20367, 39116: 20376, 39117: 20347, 39118: 20329, 39119: 20336, 39120: 20369, 39121: 20335, 39122: 20358, 39123: 20374, 39124: 20760, 39125: 20436, 39126: 20447, 39127: 20430, 39128: 20440, 39129: 20443, 39130: 20433, 39131: 20442, 39132: 20432, 39133: 20452, 39134: 20453, 39135: 20506, 39136: 20520, 39137: 20500, 39138: 20522, 39139: 20517, 39140: 20485, 39141: 20252, 39142: 20470, 39143: 20513, 39144: 20521, 39145: 20524, 39146: 20478, 39147: 20463, 39148: 20497, 39149: 20486, 39150: 20547, 39151: 20551, 39152: 26371, 39153: 20565, 39154: 20560, 39155: 20552, 39156: 20570, 39157: 20566, 39158: 20588, 39159: 20600, 39160: 20608, 39161: 20634, 39162: 20613, 39163: 20660, 39164: 20658, 39232: 20681, 39233: 20682, 39234: 20659, 39235: 20674, 39236: 20694, 39237: 20702, 39238: 20709, 39239: 20717, 39240: 20707, 39241: 20718, 39242: 20729, 39243: 20725, 39244: 20745, 39245: 20737, 39246: 20738, 39247: 20758, 39248: 20757, 39249: 20756, 39250: 20762, 39251: 20769, 39252: 20794, 39253: 20791, 39254: 20796, 39255: 20795, 39256: 20799, 39257: 20800, 39258: 20818, 39259: 20812, 39260: 20820, 39261: 20834, 39262: 31480, 39263: 20841, 39264: 20842, 39265: 20846, 39266: 20864, 39267: 20866, 39268: 22232, 39269: 20876, 39270: 20873, 39271: 20879, 39272: 20881, 39273: 20883, 39274: 20885, 39275: 20886, 39276: 20900, 39277: 20902, 39278: 20898, 39279: 20905, 39280: 20906, 39281: 20907, 39282: 20915, 39283: 20913, 39284: 20914, 39285: 20912, 39286: 20917, 39287: 20925, 39288: 20933, 39289: 20937, 39290: 20955, 39291: 20960, 39292: 34389, 39293: 20969, 39294: 20973, 39296: 20976, 39297: 20981, 39298: 20990, 39299: 20996, 39300: 21003, 39301: 21012, 39302: 21006, 39303: 21031, 39304: 21034, 39305: 21038, 39306: 21043, 39307: 21049, 39308: 21071, 39309: 21060, 39310: 21067, 39311: 21068, 39312: 21086, 39313: 21076, 39314: 21098, 39315: 21108, 39316: 21097, 39317: 21107, 39318: 21119, 39319: 21117, 39320: 21133, 39321: 21140, 39322: 21138, 39323: 21105, 39324: 21128, 39325: 21137, 39326: 36776, 39327: 36775, 39328: 21164, 39329: 21165, 39330: 21180, 39331: 21173, 39332: 21185, 39333: 21197, 39334: 21207, 39335: 21214, 39336: 21219, 39337: 21222, 39338: 39149, 39339: 21216, 39340: 21235, 39341: 21237, 39342: 21240, 39343: 21241, 39344: 21254, 39345: 21256, 39346: 30008, 39347: 21261, 39348: 21264, 39349: 21263, 39350: 21269, 39351: 21274, 39352: 21283, 39353: 21295, 39354: 21297, 39355: 21299, 39356: 21304, 39357: 21312, 39358: 21318, 39359: 21317, 39360: 19991, 39361: 21321, 39362: 21325, 39363: 20950, 39364: 21342, 39365: 21353, 39366: 21358, 39367: 22808, 39368: 21371, 39369: 21367, 39370: 21378, 39371: 21398, 39372: 21408, 39373: 21414, 39374: 21413, 39375: 21422, 39376: 21424, 39377: 21430, 39378: 21443, 39379: 31762, 39380: 38617, 39381: 21471, 39382: 26364, 39383: 29166, 39384: 21486, 39385: 21480, 39386: 21485, 39387: 21498, 39388: 21505, 39389: 21565, 39390: 21568, 39391: 21548, 39392: 21549, 39393: 21564, 39394: 21550, 39395: 21558, 39396: 21545, 39397: 21533, 39398: 21582, 39399: 21647, 39400: 21621, 39401: 21646, 39402: 21599, 39403: 21617, 39404: 21623, 39405: 21616, 39406: 21650, 39407: 21627, 39408: 21632, 39409: 21622, 39410: 21636, 39411: 21648, 39412: 21638, 39413: 21703, 39414: 21666, 39415: 21688, 39416: 21669, 39417: 21676, 39418: 21700, 39419: 21704, 39420: 21672, 39488: 21675, 39489: 21698, 39490: 21668, 39491: 21694, 39492: 21692, 39493: 21720, 39494: 21733, 39495: 21734, 39496: 21775, 39497: 21780, 39498: 21757, 39499: 21742, 39500: 21741, 39501: 21754, 39502: 21730, 39503: 21817, 39504: 21824, 39505: 21859, 39506: 21836, 39507: 21806, 39508: 21852, 39509: 21829, 39510: 21846, 39511: 21847, 39512: 21816, 39513: 21811, 39514: 21853, 39515: 21913, 39516: 21888, 39517: 21679, 39518: 21898, 39519: 21919, 39520: 21883, 39521: 21886, 39522: 21912, 39523: 21918, 39524: 21934, 39525: 21884, 39526: 21891, 39527: 21929, 39528: 21895, 39529: 21928, 39530: 21978, 39531: 21957, 39532: 21983, 39533: 21956, 39534: 21980, 39535: 21988, 39536: 21972, 39537: 22036, 39538: 22007, 39539: 22038, 39540: 22014, 39541: 22013, 39542: 22043, 39543: 22009, 39544: 22094, 39545: 22096, 39546: 29151, 39547: 22068, 39548: 22070, 39549: 22066, 39550: 22072, 39552: 22123, 39553: 22116, 39554: 22063, 39555: 22124, 39556: 22122, 39557: 22150, 39558: 22144, 39559: 22154, 39560: 22176, 39561: 22164, 39562: 22159, 39563: 22181, 39564: 22190, 39565: 22198, 39566: 22196, 39567: 22210, 39568: 22204, 39569: 22209, 39570: 22211, 39571: 22208, 39572: 22216, 39573: 22222, 39574: 22225, 39575: 22227, 39576: 22231, 39577: 22254, 39578: 22265, 39579: 22272, 39580: 22271, 39581: 22276, 39582: 22281, 39583: 22280, 39584: 22283, 39585: 22285, 39586: 22291, 39587: 22296, 39588: 22294, 39589: 21959, 39590: 22300, 39591: 22310, 39592: 22327, 39593: 22328, 39594: 22350, 39595: 22331, 39596: 22336, 39597: 22351, 39598: 22377, 39599: 22464, 39600: 22408, 39601: 22369, 39602: 22399, 39603: 22409, 39604: 22419, 39605: 22432, 39606: 22451, 39607: 22436, 39608: 22442, 39609: 22448, 39610: 22467, 39611: 22470, 39612: 22484, 39613: 22482, 39614: 22483, 39615: 22538, 39616: 22486, 39617: 22499, 39618: 22539, 39619: 22553, 39620: 22557, 39621: 22642, 39622: 22561, 39623: 22626, 39624: 22603, 39625: 22640, 39626: 27584, 39627: 22610, 39628: 22589, 39629: 22649, 39630: 22661, 39631: 22713, 39632: 22687, 39633: 22699, 39634: 22714, 39635: 22750, 39636: 22715, 39637: 22712, 39638: 22702, 39639: 22725, 39640: 22739, 39641: 22737, 39642: 22743, 39643: 22745, 39644: 22744, 39645: 22757, 39646: 22748, 39647: 22756, 39648: 22751, 39649: 22767, 39650: 22778, 39651: 22777, 39652: 22779, 39653: 22780, 39654: 22781, 39655: 22786, 39656: 22794, 39657: 22800, 39658: 22811, 39659: 26790, 39660: 22821, 39661: 22828, 39662: 22829, 39663: 22834, 39664: 22840, 39665: 22846, 39666: 31442, 39667: 22869, 39668: 22864, 39669: 22862, 39670: 22874, 39671: 22872, 39672: 22882, 39673: 22880, 39674: 22887, 39675: 22892, 39676: 22889, 39744: 22904, 39745: 22913, 39746: 22941, 39747: 20318, 39748: 20395, 39749: 22947, 39750: 22962, 39751: 22982, 39752: 23016, 39753: 23004, 39754: 22925, 39755: 23001, 39756: 23002, 39757: 23077, 39758: 23071, 39759: 23057, 39760: 23068, 39761: 23049, 39762: 23066, 39763: 23104, 39764: 23148, 39765: 23113, 39766: 23093, 39767: 23094, 39768: 23138, 39769: 23146, 39770: 23194, 39771: 23228, 39772: 23230, 39773: 23243, 39774: 23234, 39775: 23229, 39776: 23267, 39777: 23255, 39778: 23270, 39779: 23273, 39780: 23254, 39781: 23290, 39782: 23291, 39783: 23308, 39784: 23307, 39785: 23318, 39786: 23346, 39787: 23248, 39788: 23338, 39789: 23350, 39790: 23358, 39791: 23363, 39792: 23365, 39793: 23360, 39794: 23377, 39795: 23381, 39796: 23386, 39797: 23387, 39798: 23397, 39799: 23401, 39800: 23408, 39801: 23411, 39802: 23413, 39803: 23416, 39804: 25992, 39805: 23418, 39806: 23424, 39808: 23427, 39809: 23462, 39810: 23480, 39811: 23491, 39812: 23495, 39813: 23497, 39814: 23508, 39815: 23504, 39816: 23524, 39817: 23526, 39818: 23522, 39819: 23518, 39820: 23525, 39821: 23531, 39822: 23536, 39823: 23542, 39824: 23539, 39825: 23557, 39826: 23559, 39827: 23560, 39828: 23565, 39829: 23571, 39830: 23584, 39831: 23586, 39832: 23592, 39833: 23608, 39834: 23609, 39835: 23617, 39836: 23622, 39837: 23630, 39838: 23635, 39839: 23632, 39840: 23631, 39841: 23409, 39842: 23660, 39843: 23662, 39844: 20066, 39845: 23670, 39846: 23673, 39847: 23692, 39848: 23697, 39849: 23700, 39850: 22939, 39851: 23723, 39852: 23739, 39853: 23734, 39854: 23740, 39855: 23735, 39856: 23749, 39857: 23742, 39858: 23751, 39859: 23769, 39860: 23785, 39861: 23805, 39862: 23802, 39863: 23789, 39864: 23948, 39865: 23786, 39866: 23819, 39867: 23829, 39868: 23831, 39869: 23900, 39870: 23839, 39871: 23835, 39872: 23825, 39873: 23828, 39874: 23842, 39875: 23834, 39876: 23833, 39877: 23832, 39878: 23884, 39879: 23890, 39880: 23886, 39881: 23883, 39882: 23916, 39883: 23923, 39884: 23926, 39885: 23943, 39886: 23940, 39887: 23938, 39888: 23970, 39889: 23965, 39890: 23980, 39891: 23982, 39892: 23997, 39893: 23952, 39894: 23991, 39895: 23996, 39896: 24009, 39897: 24013, 39898: 24019, 39899: 24018, 39900: 24022, 39901: 24027, 39902: 24043, 39903: 24050, 39904: 24053, 39905: 24075, 39906: 24090, 39907: 24089, 39908: 24081, 39909: 24091, 39910: 24118, 39911: 24119, 39912: 24132, 39913: 24131, 39914: 24128, 39915: 24142, 39916: 24151, 39917: 24148, 39918: 24159, 39919: 24162, 39920: 24164, 39921: 24135, 39922: 24181, 39923: 24182, 39924: 24186, 39925: 40636, 39926: 24191, 39927: 24224, 39928: 24257, 39929: 24258, 39930: 24264, 39931: 24272, 39932: 24271, 4e4: 24278, 40001: 24291, 40002: 24285, 40003: 24282, 40004: 24283, 40005: 24290, 40006: 24289, 40007: 24296, 40008: 24297, 40009: 24300, 40010: 24305, 40011: 24307, 40012: 24304, 40013: 24308, 40014: 24312, 40015: 24318, 40016: 24323, 40017: 24329, 40018: 24413, 40019: 24412, 40020: 24331, 40021: 24337, 40022: 24342, 40023: 24361, 40024: 24365, 40025: 24376, 40026: 24385, 40027: 24392, 40028: 24396, 40029: 24398, 40030: 24367, 40031: 24401, 40032: 24406, 40033: 24407, 40034: 24409, 40035: 24417, 40036: 24429, 40037: 24435, 40038: 24439, 40039: 24451, 40040: 24450, 40041: 24447, 40042: 24458, 40043: 24456, 40044: 24465, 40045: 24455, 40046: 24478, 40047: 24473, 40048: 24472, 40049: 24480, 40050: 24488, 40051: 24493, 40052: 24508, 40053: 24534, 40054: 24571, 40055: 24548, 40056: 24568, 40057: 24561, 40058: 24541, 40059: 24755, 40060: 24575, 40061: 24609, 40062: 24672, 40064: 24601, 40065: 24592, 40066: 24617, 40067: 24590, 40068: 24625, 40069: 24603, 40070: 24597, 40071: 24619, 40072: 24614, 40073: 24591, 40074: 24634, 40075: 24666, 40076: 24641, 40077: 24682, 40078: 24695, 40079: 24671, 40080: 24650, 40081: 24646, 40082: 24653, 40083: 24675, 40084: 24643, 40085: 24676, 40086: 24642, 40087: 24684, 40088: 24683, 40089: 24665, 40090: 24705, 40091: 24717, 40092: 24807, 40093: 24707, 40094: 24730, 40095: 24708, 40096: 24731, 40097: 24726, 40098: 24727, 40099: 24722, 40100: 24743, 40101: 24715, 40102: 24801, 40103: 24760, 40104: 24800, 40105: 24787, 40106: 24756, 40107: 24560, 40108: 24765, 40109: 24774, 40110: 24757, 40111: 24792, 40112: 24909, 40113: 24853, 40114: 24838, 40115: 24822, 40116: 24823, 40117: 24832, 40118: 24820, 40119: 24826, 40120: 24835, 40121: 24865, 40122: 24827, 40123: 24817, 40124: 24845, 40125: 24846, 40126: 24903, 40127: 24894, 40128: 24872, 40129: 24871, 40130: 24906, 40131: 24895, 40132: 24892, 40133: 24876, 40134: 24884, 40135: 24893, 40136: 24898, 40137: 24900, 40138: 24947, 40139: 24951, 40140: 24920, 40141: 24921, 40142: 24922, 40143: 24939, 40144: 24948, 40145: 24943, 40146: 24933, 40147: 24945, 40148: 24927, 40149: 24925, 40150: 24915, 40151: 24949, 40152: 24985, 40153: 24982, 40154: 24967, 40155: 25004, 40156: 24980, 40157: 24986, 40158: 24970, 40159: 24977, 40160: 25003, 40161: 25006, 40162: 25036, 40163: 25034, 40164: 25033, 40165: 25079, 40166: 25032, 40167: 25027, 40168: 25030, 40169: 25018, 40170: 25035, 40171: 32633, 40172: 25037, 40173: 25062, 40174: 25059, 40175: 25078, 40176: 25082, 40177: 25076, 40178: 25087, 40179: 25085, 40180: 25084, 40181: 25086, 40182: 25088, 40183: 25096, 40184: 25097, 40185: 25101, 40186: 25100, 40187: 25108, 40188: 25115, 40256: 25118, 40257: 25121, 40258: 25130, 40259: 25134, 40260: 25136, 40261: 25138, 40262: 25139, 40263: 25153, 40264: 25166, 40265: 25182, 40266: 25187, 40267: 25179, 40268: 25184, 40269: 25192, 40270: 25212, 40271: 25218, 40272: 25225, 40273: 25214, 40274: 25234, 40275: 25235, 40276: 25238, 40277: 25300, 40278: 25219, 40279: 25236, 40280: 25303, 40281: 25297, 40282: 25275, 40283: 25295, 40284: 25343, 40285: 25286, 40286: 25812, 40287: 25288, 40288: 25308, 40289: 25292, 40290: 25290, 40291: 25282, 40292: 25287, 40293: 25243, 40294: 25289, 40295: 25356, 40296: 25326, 40297: 25329, 40298: 25383, 40299: 25346, 40300: 25352, 40301: 25327, 40302: 25333, 40303: 25424, 40304: 25406, 40305: 25421, 40306: 25628, 40307: 25423, 40308: 25494, 40309: 25486, 40310: 25472, 40311: 25515, 40312: 25462, 40313: 25507, 40314: 25487, 40315: 25481, 40316: 25503, 40317: 25525, 40318: 25451, 40320: 25449, 40321: 25534, 40322: 25577, 40323: 25536, 40324: 25542, 40325: 25571, 40326: 25545, 40327: 25554, 40328: 25590, 40329: 25540, 40330: 25622, 40331: 25652, 40332: 25606, 40333: 25619, 40334: 25638, 40335: 25654, 40336: 25885, 40337: 25623, 40338: 25640, 40339: 25615, 40340: 25703, 40341: 25711, 40342: 25718, 40343: 25678, 40344: 25898, 40345: 25749, 40346: 25747, 40347: 25765, 40348: 25769, 40349: 25736, 40350: 25788, 40351: 25818, 40352: 25810, 40353: 25797, 40354: 25799, 40355: 25787, 40356: 25816, 40357: 25794, 40358: 25841, 40359: 25831, 40360: 33289, 40361: 25824, 40362: 25825, 40363: 25260, 40364: 25827, 40365: 25839, 40366: 25900, 40367: 25846, 40368: 25844, 40369: 25842, 40370: 25850, 40371: 25856, 40372: 25853, 40373: 25880, 40374: 25884, 40375: 25861, 40376: 25892, 40377: 25891, 40378: 25899, 40379: 25908, 40380: 25909, 40381: 25911, 40382: 25910, 40383: 25912, 40384: 30027, 40385: 25928, 40386: 25942, 40387: 25941, 40388: 25933, 40389: 25944, 40390: 25950, 40391: 25949, 40392: 25970, 40393: 25976, 40394: 25986, 40395: 25987, 40396: 35722, 40397: 26011, 40398: 26015, 40399: 26027, 40400: 26039, 40401: 26051, 40402: 26054, 40403: 26049, 40404: 26052, 40405: 26060, 40406: 26066, 40407: 26075, 40408: 26073, 40409: 26080, 40410: 26081, 40411: 26097, 40412: 26482, 40413: 26122, 40414: 26115, 40415: 26107, 40416: 26483, 40417: 26165, 40418: 26166, 40419: 26164, 40420: 26140, 40421: 26191, 40422: 26180, 40423: 26185, 40424: 26177, 40425: 26206, 40426: 26205, 40427: 26212, 40428: 26215, 40429: 26216, 40430: 26207, 40431: 26210, 40432: 26224, 40433: 26243, 40434: 26248, 40435: 26254, 40436: 26249, 40437: 26244, 40438: 26264, 40439: 26269, 40440: 26305, 40441: 26297, 40442: 26313, 40443: 26302, 40444: 26300, 40512: 26308, 40513: 26296, 40514: 26326, 40515: 26330, 40516: 26336, 40517: 26175, 40518: 26342, 40519: 26345, 40520: 26352, 40521: 26357, 40522: 26359, 40523: 26383, 40524: 26390, 40525: 26398, 40526: 26406, 40527: 26407, 40528: 38712, 40529: 26414, 40530: 26431, 40531: 26422, 40532: 26433, 40533: 26424, 40534: 26423, 40535: 26438, 40536: 26462, 40537: 26464, 40538: 26457, 40539: 26467, 40540: 26468, 40541: 26505, 40542: 26480, 40543: 26537, 40544: 26492, 40545: 26474, 40546: 26508, 40547: 26507, 40548: 26534, 40549: 26529, 40550: 26501, 40551: 26551, 40552: 26607, 40553: 26548, 40554: 26604, 40555: 26547, 40556: 26601, 40557: 26552, 40558: 26596, 40559: 26590, 40560: 26589, 40561: 26594, 40562: 26606, 40563: 26553, 40564: 26574, 40565: 26566, 40566: 26599, 40567: 27292, 40568: 26654, 40569: 26694, 40570: 26665, 40571: 26688, 40572: 26701, 40573: 26674, 40574: 26702, 40576: 26803, 40577: 26667, 40578: 26713, 40579: 26723, 40580: 26743, 40581: 26751, 40582: 26783, 40583: 26767, 40584: 26797, 40585: 26772, 40586: 26781, 40587: 26779, 40588: 26755, 40589: 27310, 40590: 26809, 40591: 26740, 40592: 26805, 40593: 26784, 40594: 26810, 40595: 26895, 40596: 26765, 40597: 26750, 40598: 26881, 40599: 26826, 40600: 26888, 40601: 26840, 40602: 26914, 40603: 26918, 40604: 26849, 40605: 26892, 40606: 26829, 40607: 26836, 40608: 26855, 40609: 26837, 40610: 26934, 40611: 26898, 40612: 26884, 40613: 26839, 40614: 26851, 40615: 26917, 40616: 26873, 40617: 26848, 40618: 26863, 40619: 26920, 40620: 26922, 40621: 26906, 40622: 26915, 40623: 26913, 40624: 26822, 40625: 27001, 40626: 26999, 40627: 26972, 40628: 27e3, 40629: 26987, 40630: 26964, 40631: 27006, 40632: 26990, 40633: 26937, 40634: 26996, 40635: 26941, 40636: 26969, 40637: 26928, 40638: 26977, 40639: 26974, 40640: 26973, 40641: 27009, 40642: 26986, 40643: 27058, 40644: 27054, 40645: 27088, 40646: 27071, 40647: 27073, 40648: 27091, 40649: 27070, 40650: 27086, 40651: 23528, 40652: 27082, 40653: 27101, 40654: 27067, 40655: 27075, 40656: 27047, 40657: 27182, 40658: 27025, 40659: 27040, 40660: 27036, 40661: 27029, 40662: 27060, 40663: 27102, 40664: 27112, 40665: 27138, 40666: 27163, 40667: 27135, 40668: 27402, 40669: 27129, 40670: 27122, 40671: 27111, 40672: 27141, 40673: 27057, 40674: 27166, 40675: 27117, 40676: 27156, 40677: 27115, 40678: 27146, 40679: 27154, 40680: 27329, 40681: 27171, 40682: 27155, 40683: 27204, 40684: 27148, 40685: 27250, 40686: 27190, 40687: 27256, 40688: 27207, 40689: 27234, 40690: 27225, 40691: 27238, 40692: 27208, 40693: 27192, 40694: 27170, 40695: 27280, 40696: 27277, 40697: 27296, 40698: 27268, 40699: 27298, 40700: 27299, 40768: 27287, 40769: 34327, 40770: 27323, 40771: 27331, 40772: 27330, 40773: 27320, 40774: 27315, 40775: 27308, 40776: 27358, 40777: 27345, 40778: 27359, 40779: 27306, 40780: 27354, 40781: 27370, 40782: 27387, 40783: 27397, 40784: 34326, 40785: 27386, 40786: 27410, 40787: 27414, 40788: 39729, 40789: 27423, 40790: 27448, 40791: 27447, 40792: 30428, 40793: 27449, 40794: 39150, 40795: 27463, 40796: 27459, 40797: 27465, 40798: 27472, 40799: 27481, 40800: 27476, 40801: 27483, 40802: 27487, 40803: 27489, 40804: 27512, 40805: 27513, 40806: 27519, 40807: 27520, 40808: 27524, 40809: 27523, 40810: 27533, 40811: 27544, 40812: 27541, 40813: 27550, 40814: 27556, 40815: 27562, 40816: 27563, 40817: 27567, 40818: 27570, 40819: 27569, 40820: 27571, 40821: 27575, 40822: 27580, 40823: 27590, 40824: 27595, 40825: 27603, 40826: 27615, 40827: 27628, 40828: 27627, 40829: 27635, 40830: 27631, 40832: 40638, 40833: 27656, 40834: 27667, 40835: 27668, 40836: 27675, 40837: 27684, 40838: 27683, 40839: 27742, 40840: 27733, 40841: 27746, 40842: 27754, 40843: 27778, 40844: 27789, 40845: 27802, 40846: 27777, 40847: 27803, 40848: 27774, 40849: 27752, 40850: 27763, 40851: 27794, 40852: 27792, 40853: 27844, 40854: 27889, 40855: 27859, 40856: 27837, 40857: 27863, 40858: 27845, 40859: 27869, 40860: 27822, 40861: 27825, 40862: 27838, 40863: 27834, 40864: 27867, 40865: 27887, 40866: 27865, 40867: 27882, 40868: 27935, 40869: 34893, 40870: 27958, 40871: 27947, 40872: 27965, 40873: 27960, 40874: 27929, 40875: 27957, 40876: 27955, 40877: 27922, 40878: 27916, 40879: 28003, 40880: 28051, 40881: 28004, 40882: 27994, 40883: 28025, 40884: 27993, 40885: 28046, 40886: 28053, 40887: 28644, 40888: 28037, 40889: 28153, 40890: 28181, 40891: 28170, 40892: 28085, 40893: 28103, 40894: 28134, 40895: 28088, 40896: 28102, 40897: 28140, 40898: 28126, 40899: 28108, 40900: 28136, 40901: 28114, 40902: 28101, 40903: 28154, 40904: 28121, 40905: 28132, 40906: 28117, 40907: 28138, 40908: 28142, 40909: 28205, 40910: 28270, 40911: 28206, 40912: 28185, 40913: 28274, 40914: 28255, 40915: 28222, 40916: 28195, 40917: 28267, 40918: 28203, 40919: 28278, 40920: 28237, 40921: 28191, 40922: 28227, 40923: 28218, 40924: 28238, 40925: 28196, 40926: 28415, 40927: 28189, 40928: 28216, 40929: 28290, 40930: 28330, 40931: 28312, 40932: 28361, 40933: 28343, 40934: 28371, 40935: 28349, 40936: 28335, 40937: 28356, 40938: 28338, 40939: 28372, 40940: 28373, 40941: 28303, 40942: 28325, 40943: 28354, 40944: 28319, 40945: 28481, 40946: 28433, 40947: 28748, 40948: 28396, 40949: 28408, 40950: 28414, 40951: 28479, 40952: 28402, 40953: 28465, 40954: 28399, 40955: 28466, 40956: 28364, 161: 65377, 162: 65378, 163: 65379, 164: 65380, 165: 65381, 166: 65382, 167: 65383, 168: 65384, 169: 65385, 170: 65386, 171: 65387, 172: 65388, 173: 65389, 174: 65390, 175: 65391, 176: 65392, 177: 65393, 178: 65394, 179: 65395, 180: 65396, 181: 65397, 182: 65398, 183: 65399, 184: 65400, 185: 65401, 186: 65402, 187: 65403, 188: 65404, 189: 65405, 190: 65406, 191: 65407, 192: 65408, 193: 65409, 194: 65410, 195: 65411, 196: 65412, 197: 65413, 198: 65414, 199: 65415, 200: 65416, 201: 65417, 202: 65418, 203: 65419, 204: 65420, 205: 65421, 206: 65422, 207: 65423, 208: 65424, 209: 65425, 210: 65426, 211: 65427, 212: 65428, 213: 65429, 214: 65430, 215: 65431, 216: 65432, 217: 65433, 218: 65434, 219: 65435, 220: 65436, 221: 65437, 222: 65438, 223: 65439, 57408: 28478, 57409: 28435, 57410: 28407, 57411: 28550, 57412: 28538, 57413: 28536, 57414: 28545, 57415: 28544, 57416: 28527, 57417: 28507, 57418: 28659, 57419: 28525, 57420: 28546, 57421: 28540, 57422: 28504, 57423: 28558, 57424: 28561, 57425: 28610, 57426: 28518, 57427: 28595, 57428: 28579, 57429: 28577, 57430: 28580, 57431: 28601, 57432: 28614, 57433: 28586, 57434: 28639, 57435: 28629, 57436: 28652, 57437: 28628, 57438: 28632, 57439: 28657, 57440: 28654, 57441: 28635, 57442: 28681, 57443: 28683, 57444: 28666, 57445: 28689, 57446: 28673, 57447: 28687, 57448: 28670, 57449: 28699, 57450: 28698, 57451: 28532, 57452: 28701, 57453: 28696, 57454: 28703, 57455: 28720, 57456: 28734, 57457: 28722, 57458: 28753, 57459: 28771, 57460: 28825, 57461: 28818, 57462: 28847, 57463: 28913, 57464: 28844, 57465: 28856, 57466: 28851, 57467: 28846, 57468: 28895, 57469: 28875, 57470: 28893, 57472: 28889, 57473: 28937, 57474: 28925, 57475: 28956, 57476: 28953, 57477: 29029, 57478: 29013, 57479: 29064, 57480: 29030, 57481: 29026, 57482: 29004, 57483: 29014, 57484: 29036, 57485: 29071, 57486: 29179, 57487: 29060, 57488: 29077, 57489: 29096, 57490: 29100, 57491: 29143, 57492: 29113, 57493: 29118, 57494: 29138, 57495: 29129, 57496: 29140, 57497: 29134, 57498: 29152, 57499: 29164, 57500: 29159, 57501: 29173, 57502: 29180, 57503: 29177, 57504: 29183, 57505: 29197, 57506: 29200, 57507: 29211, 57508: 29224, 57509: 29229, 57510: 29228, 57511: 29232, 57512: 29234, 57513: 29243, 57514: 29244, 57515: 29247, 57516: 29248, 57517: 29254, 57518: 29259, 57519: 29272, 57520: 29300, 57521: 29310, 57522: 29314, 57523: 29313, 57524: 29319, 57525: 29330, 57526: 29334, 57527: 29346, 57528: 29351, 57529: 29369, 57530: 29362, 57531: 29379, 57532: 29382, 57533: 29380, 57534: 29390, 57535: 29394, 57536: 29410, 57537: 29408, 57538: 29409, 57539: 29433, 57540: 29431, 57541: 20495, 57542: 29463, 57543: 29450, 57544: 29468, 57545: 29462, 57546: 29469, 57547: 29492, 57548: 29487, 57549: 29481, 57550: 29477, 57551: 29502, 57552: 29518, 57553: 29519, 57554: 40664, 57555: 29527, 57556: 29546, 57557: 29544, 57558: 29552, 57559: 29560, 57560: 29557, 57561: 29563, 57562: 29562, 57563: 29640, 57564: 29619, 57565: 29646, 57566: 29627, 57567: 29632, 57568: 29669, 57569: 29678, 57570: 29662, 57571: 29858, 57572: 29701, 57573: 29807, 57574: 29733, 57575: 29688, 57576: 29746, 57577: 29754, 57578: 29781, 57579: 29759, 57580: 29791, 57581: 29785, 57582: 29761, 57583: 29788, 57584: 29801, 57585: 29808, 57586: 29795, 57587: 29802, 57588: 29814, 57589: 29822, 57590: 29835, 57591: 29854, 57592: 29863, 57593: 29898, 57594: 29903, 57595: 29908, 57596: 29681, 57664: 29920, 57665: 29923, 57666: 29927, 57667: 29929, 57668: 29934, 57669: 29938, 57670: 29936, 57671: 29937, 57672: 29944, 57673: 29943, 57674: 29956, 57675: 29955, 57676: 29957, 57677: 29964, 57678: 29966, 57679: 29965, 57680: 29973, 57681: 29971, 57682: 29982, 57683: 29990, 57684: 29996, 57685: 30012, 57686: 30020, 57687: 30029, 57688: 30026, 57689: 30025, 57690: 30043, 57691: 30022, 57692: 30042, 57693: 30057, 57694: 30052, 57695: 30055, 57696: 30059, 57697: 30061, 57698: 30072, 57699: 30070, 57700: 30086, 57701: 30087, 57702: 30068, 57703: 30090, 57704: 30089, 57705: 30082, 57706: 30100, 57707: 30106, 57708: 30109, 57709: 30117, 57710: 30115, 57711: 30146, 57712: 30131, 57713: 30147, 57714: 30133, 57715: 30141, 57716: 30136, 57717: 30140, 57718: 30129, 57719: 30157, 57720: 30154, 57721: 30162, 57722: 30169, 57723: 30179, 57724: 30174, 57725: 30206, 57726: 30207, 57728: 30204, 57729: 30209, 57730: 30192, 57731: 30202, 57732: 30194, 57733: 30195, 57734: 30219, 57735: 30221, 57736: 30217, 57737: 30239, 57738: 30247, 57739: 30240, 57740: 30241, 57741: 30242, 57742: 30244, 57743: 30260, 57744: 30256, 57745: 30267, 57746: 30279, 57747: 30280, 57748: 30278, 57749: 30300, 57750: 30296, 57751: 30305, 57752: 30306, 57753: 30312, 57754: 30313, 57755: 30314, 57756: 30311, 57757: 30316, 57758: 30320, 57759: 30322, 57760: 30326, 57761: 30328, 57762: 30332, 57763: 30336, 57764: 30339, 57765: 30344, 57766: 30347, 57767: 30350, 57768: 30358, 57769: 30355, 57770: 30361, 57771: 30362, 57772: 30384, 57773: 30388, 57774: 30392, 57775: 30393, 57776: 30394, 57777: 30402, 57778: 30413, 57779: 30422, 57780: 30418, 57781: 30430, 57782: 30433, 57783: 30437, 57784: 30439, 57785: 30442, 57786: 34351, 57787: 30459, 57788: 30472, 57789: 30471, 57790: 30468, 57791: 30505, 57792: 30500, 57793: 30494, 57794: 30501, 57795: 30502, 57796: 30491, 57797: 30519, 57798: 30520, 57799: 30535, 57800: 30554, 57801: 30568, 57802: 30571, 57803: 30555, 57804: 30565, 57805: 30591, 57806: 30590, 57807: 30585, 57808: 30606, 57809: 30603, 57810: 30609, 57811: 30624, 57812: 30622, 57813: 30640, 57814: 30646, 57815: 30649, 57816: 30655, 57817: 30652, 57818: 30653, 57819: 30651, 57820: 30663, 57821: 30669, 57822: 30679, 57823: 30682, 57824: 30684, 57825: 30691, 57826: 30702, 57827: 30716, 57828: 30732, 57829: 30738, 57830: 31014, 57831: 30752, 57832: 31018, 57833: 30789, 57834: 30862, 57835: 30836, 57836: 30854, 57837: 30844, 57838: 30874, 57839: 30860, 57840: 30883, 57841: 30901, 57842: 30890, 57843: 30895, 57844: 30929, 57845: 30918, 57846: 30923, 57847: 30932, 57848: 30910, 57849: 30908, 57850: 30917, 57851: 30922, 57852: 30956, 57920: 30951, 57921: 30938, 57922: 30973, 57923: 30964, 57924: 30983, 57925: 30994, 57926: 30993, 57927: 31001, 57928: 31020, 57929: 31019, 57930: 31040, 57931: 31072, 57932: 31063, 57933: 31071, 57934: 31066, 57935: 31061, 57936: 31059, 57937: 31098, 57938: 31103, 57939: 31114, 57940: 31133, 57941: 31143, 57942: 40779, 57943: 31146, 57944: 31150, 57945: 31155, 57946: 31161, 57947: 31162, 57948: 31177, 57949: 31189, 57950: 31207, 57951: 31212, 57952: 31201, 57953: 31203, 57954: 31240, 57955: 31245, 57956: 31256, 57957: 31257, 57958: 31264, 57959: 31263, 57960: 31104, 57961: 31281, 57962: 31291, 57963: 31294, 57964: 31287, 57965: 31299, 57966: 31319, 57967: 31305, 57968: 31329, 57969: 31330, 57970: 31337, 57971: 40861, 57972: 31344, 57973: 31353, 57974: 31357, 57975: 31368, 57976: 31383, 57977: 31381, 57978: 31384, 57979: 31382, 57980: 31401, 57981: 31432, 57982: 31408, 57984: 31414, 57985: 31429, 57986: 31428, 57987: 31423, 57988: 36995, 57989: 31431, 57990: 31434, 57991: 31437, 57992: 31439, 57993: 31445, 57994: 31443, 57995: 31449, 57996: 31450, 57997: 31453, 57998: 31457, 57999: 31458, 58e3: 31462, 58001: 31469, 58002: 31472, 58003: 31490, 58004: 31503, 58005: 31498, 58006: 31494, 58007: 31539, 58008: 31512, 58009: 31513, 58010: 31518, 58011: 31541, 58012: 31528, 58013: 31542, 58014: 31568, 58015: 31610, 58016: 31492, 58017: 31565, 58018: 31499, 58019: 31564, 58020: 31557, 58021: 31605, 58022: 31589, 58023: 31604, 58024: 31591, 58025: 31600, 58026: 31601, 58027: 31596, 58028: 31598, 58029: 31645, 58030: 31640, 58031: 31647, 58032: 31629, 58033: 31644, 58034: 31642, 58035: 31627, 58036: 31634, 58037: 31631, 58038: 31581, 58039: 31641, 58040: 31691, 58041: 31681, 58042: 31692, 58043: 31695, 58044: 31668, 58045: 31686, 58046: 31709, 58047: 31721, 58048: 31761, 58049: 31764, 58050: 31718, 58051: 31717, 58052: 31840, 58053: 31744, 58054: 31751, 58055: 31763, 58056: 31731, 58057: 31735, 58058: 31767, 58059: 31757, 58060: 31734, 58061: 31779, 58062: 31783, 58063: 31786, 58064: 31775, 58065: 31799, 58066: 31787, 58067: 31805, 58068: 31820, 58069: 31811, 58070: 31828, 58071: 31823, 58072: 31808, 58073: 31824, 58074: 31832, 58075: 31839, 58076: 31844, 58077: 31830, 58078: 31845, 58079: 31852, 58080: 31861, 58081: 31875, 58082: 31888, 58083: 31908, 58084: 31917, 58085: 31906, 58086: 31915, 58087: 31905, 58088: 31912, 58089: 31923, 58090: 31922, 58091: 31921, 58092: 31918, 58093: 31929, 58094: 31933, 58095: 31936, 58096: 31941, 58097: 31938, 58098: 31960, 58099: 31954, 58100: 31964, 58101: 31970, 58102: 39739, 58103: 31983, 58104: 31986, 58105: 31988, 58106: 31990, 58107: 31994, 58108: 32006, 58176: 32002, 58177: 32028, 58178: 32021, 58179: 32010, 58180: 32069, 58181: 32075, 58182: 32046, 58183: 32050, 58184: 32063, 58185: 32053, 58186: 32070, 58187: 32115, 58188: 32086, 58189: 32078, 58190: 32114, 58191: 32104, 58192: 32110, 58193: 32079, 58194: 32099, 58195: 32147, 58196: 32137, 58197: 32091, 58198: 32143, 58199: 32125, 58200: 32155, 58201: 32186, 58202: 32174, 58203: 32163, 58204: 32181, 58205: 32199, 58206: 32189, 58207: 32171, 58208: 32317, 58209: 32162, 58210: 32175, 58211: 32220, 58212: 32184, 58213: 32159, 58214: 32176, 58215: 32216, 58216: 32221, 58217: 32228, 58218: 32222, 58219: 32251, 58220: 32242, 58221: 32225, 58222: 32261, 58223: 32266, 58224: 32291, 58225: 32289, 58226: 32274, 58227: 32305, 58228: 32287, 58229: 32265, 58230: 32267, 58231: 32290, 58232: 32326, 58233: 32358, 58234: 32315, 58235: 32309, 58236: 32313, 58237: 32323, 58238: 32311, 58240: 32306, 58241: 32314, 58242: 32359, 58243: 32349, 58244: 32342, 58245: 32350, 58246: 32345, 58247: 32346, 58248: 32377, 58249: 32362, 58250: 32361, 58251: 32380, 58252: 32379, 58253: 32387, 58254: 32213, 58255: 32381, 58256: 36782, 58257: 32383, 58258: 32392, 58259: 32393, 58260: 32396, 58261: 32402, 58262: 32400, 58263: 32403, 58264: 32404, 58265: 32406, 58266: 32398, 58267: 32411, 58268: 32412, 58269: 32568, 58270: 32570, 58271: 32581, 58272: 32588, 58273: 32589, 58274: 32590, 58275: 32592, 58276: 32593, 58277: 32597, 58278: 32596, 58279: 32600, 58280: 32607, 58281: 32608, 58282: 32616, 58283: 32617, 58284: 32615, 58285: 32632, 58286: 32642, 58287: 32646, 58288: 32643, 58289: 32648, 58290: 32647, 58291: 32652, 58292: 32660, 58293: 32670, 58294: 32669, 58295: 32666, 58296: 32675, 58297: 32687, 58298: 32690, 58299: 32697, 58300: 32686, 58301: 32694, 58302: 32696, 58303: 35697, 58304: 32709, 58305: 32710, 58306: 32714, 58307: 32725, 58308: 32724, 58309: 32737, 58310: 32742, 58311: 32745, 58312: 32755, 58313: 32761, 58314: 39132, 58315: 32774, 58316: 32772, 58317: 32779, 58318: 32786, 58319: 32792, 58320: 32793, 58321: 32796, 58322: 32801, 58323: 32808, 58324: 32831, 58325: 32827, 58326: 32842, 58327: 32838, 58328: 32850, 58329: 32856, 58330: 32858, 58331: 32863, 58332: 32866, 58333: 32872, 58334: 32883, 58335: 32882, 58336: 32880, 58337: 32886, 58338: 32889, 58339: 32893, 58340: 32895, 58341: 32900, 58342: 32902, 58343: 32901, 58344: 32923, 58345: 32915, 58346: 32922, 58347: 32941, 58348: 20880, 58349: 32940, 58350: 32987, 58351: 32997, 58352: 32985, 58353: 32989, 58354: 32964, 58355: 32986, 58356: 32982, 58357: 33033, 58358: 33007, 58359: 33009, 58360: 33051, 58361: 33065, 58362: 33059, 58363: 33071, 58364: 33099, 58432: 38539, 58433: 33094, 58434: 33086, 58435: 33107, 58436: 33105, 58437: 33020, 58438: 33137, 58439: 33134, 58440: 33125, 58441: 33126, 58442: 33140, 58443: 33155, 58444: 33160, 58445: 33162, 58446: 33152, 58447: 33154, 58448: 33184, 58449: 33173, 58450: 33188, 58451: 33187, 58452: 33119, 58453: 33171, 58454: 33193, 58455: 33200, 58456: 33205, 58457: 33214, 58458: 33208, 58459: 33213, 58460: 33216, 58461: 33218, 58462: 33210, 58463: 33225, 58464: 33229, 58465: 33233, 58466: 33241, 58467: 33240, 58468: 33224, 58469: 33242, 58470: 33247, 58471: 33248, 58472: 33255, 58473: 33274, 58474: 33275, 58475: 33278, 58476: 33281, 58477: 33282, 58478: 33285, 58479: 33287, 58480: 33290, 58481: 33293, 58482: 33296, 58483: 33302, 58484: 33321, 58485: 33323, 58486: 33336, 58487: 33331, 58488: 33344, 58489: 33369, 58490: 33368, 58491: 33373, 58492: 33370, 58493: 33375, 58494: 33380, 58496: 33378, 58497: 33384, 58498: 33386, 58499: 33387, 58500: 33326, 58501: 33393, 58502: 33399, 58503: 33400, 58504: 33406, 58505: 33421, 58506: 33426, 58507: 33451, 58508: 33439, 58509: 33467, 58510: 33452, 58511: 33505, 58512: 33507, 58513: 33503, 58514: 33490, 58515: 33524, 58516: 33523, 58517: 33530, 58518: 33683, 58519: 33539, 58520: 33531, 58521: 33529, 58522: 33502, 58523: 33542, 58524: 33500, 58525: 33545, 58526: 33497, 58527: 33589, 58528: 33588, 58529: 33558, 58530: 33586, 58531: 33585, 58532: 33600, 58533: 33593, 58534: 33616, 58535: 33605, 58536: 33583, 58537: 33579, 58538: 33559, 58539: 33560, 58540: 33669, 58541: 33690, 58542: 33706, 58543: 33695, 58544: 33698, 58545: 33686, 58546: 33571, 58547: 33678, 58548: 33671, 58549: 33674, 58550: 33660, 58551: 33717, 58552: 33651, 58553: 33653, 58554: 33696, 58555: 33673, 58556: 33704, 58557: 33780, 58558: 33811, 58559: 33771, 58560: 33742, 58561: 33789, 58562: 33795, 58563: 33752, 58564: 33803, 58565: 33729, 58566: 33783, 58567: 33799, 58568: 33760, 58569: 33778, 58570: 33805, 58571: 33826, 58572: 33824, 58573: 33725, 58574: 33848, 58575: 34054, 58576: 33787, 58577: 33901, 58578: 33834, 58579: 33852, 58580: 34138, 58581: 33924, 58582: 33911, 58583: 33899, 58584: 33965, 58585: 33902, 58586: 33922, 58587: 33897, 58588: 33862, 58589: 33836, 58590: 33903, 58591: 33913, 58592: 33845, 58593: 33994, 58594: 33890, 58595: 33977, 58596: 33983, 58597: 33951, 58598: 34009, 58599: 33997, 58600: 33979, 58601: 34010, 58602: 34e3, 58603: 33985, 58604: 33990, 58605: 34006, 58606: 33953, 58607: 34081, 58608: 34047, 58609: 34036, 58610: 34071, 58611: 34072, 58612: 34092, 58613: 34079, 58614: 34069, 58615: 34068, 58616: 34044, 58617: 34112, 58618: 34147, 58619: 34136, 58620: 34120, 58688: 34113, 58689: 34306, 58690: 34123, 58691: 34133, 58692: 34176, 58693: 34212, 58694: 34184, 58695: 34193, 58696: 34186, 58697: 34216, 58698: 34157, 58699: 34196, 58700: 34203, 58701: 34282, 58702: 34183, 58703: 34204, 58704: 34167, 58705: 34174, 58706: 34192, 58707: 34249, 58708: 34234, 58709: 34255, 58710: 34233, 58711: 34256, 58712: 34261, 58713: 34269, 58714: 34277, 58715: 34268, 58716: 34297, 58717: 34314, 58718: 34323, 58719: 34315, 58720: 34302, 58721: 34298, 58722: 34310, 58723: 34338, 58724: 34330, 58725: 34352, 58726: 34367, 58727: 34381, 58728: 20053, 58729: 34388, 58730: 34399, 58731: 34407, 58732: 34417, 58733: 34451, 58734: 34467, 58735: 34473, 58736: 34474, 58737: 34443, 58738: 34444, 58739: 34486, 58740: 34479, 58741: 34500, 58742: 34502, 58743: 34480, 58744: 34505, 58745: 34851, 58746: 34475, 58747: 34516, 58748: 34526, 58749: 34537, 58750: 34540, 58752: 34527, 58753: 34523, 58754: 34543, 58755: 34578, 58756: 34566, 58757: 34568, 58758: 34560, 58759: 34563, 58760: 34555, 58761: 34577, 58762: 34569, 58763: 34573, 58764: 34553, 58765: 34570, 58766: 34612, 58767: 34623, 58768: 34615, 58769: 34619, 58770: 34597, 58771: 34601, 58772: 34586, 58773: 34656, 58774: 34655, 58775: 34680, 58776: 34636, 58777: 34638, 58778: 34676, 58779: 34647, 58780: 34664, 58781: 34670, 58782: 34649, 58783: 34643, 58784: 34659, 58785: 34666, 58786: 34821, 58787: 34722, 58788: 34719, 58789: 34690, 58790: 34735, 58791: 34763, 58792: 34749, 58793: 34752, 58794: 34768, 58795: 38614, 58796: 34731, 58797: 34756, 58798: 34739, 58799: 34759, 58800: 34758, 58801: 34747, 58802: 34799, 58803: 34802, 58804: 34784, 58805: 34831, 58806: 34829, 58807: 34814, 58808: 34806, 58809: 34807, 58810: 34830, 58811: 34770, 58812: 34833, 58813: 34838, 58814: 34837, 58815: 34850, 58816: 34849, 58817: 34865, 58818: 34870, 58819: 34873, 58820: 34855, 58821: 34875, 58822: 34884, 58823: 34882, 58824: 34898, 58825: 34905, 58826: 34910, 58827: 34914, 58828: 34923, 58829: 34945, 58830: 34942, 58831: 34974, 58832: 34933, 58833: 34941, 58834: 34997, 58835: 34930, 58836: 34946, 58837: 34967, 58838: 34962, 58839: 34990, 58840: 34969, 58841: 34978, 58842: 34957, 58843: 34980, 58844: 34992, 58845: 35007, 58846: 34993, 58847: 35011, 58848: 35012, 58849: 35028, 58850: 35032, 58851: 35033, 58852: 35037, 58853: 35065, 58854: 35074, 58855: 35068, 58856: 35060, 58857: 35048, 58858: 35058, 58859: 35076, 58860: 35084, 58861: 35082, 58862: 35091, 58863: 35139, 58864: 35102, 58865: 35109, 58866: 35114, 58867: 35115, 58868: 35137, 58869: 35140, 58870: 35131, 58871: 35126, 58872: 35128, 58873: 35148, 58874: 35101, 58875: 35168, 58876: 35166, 58944: 35174, 58945: 35172, 58946: 35181, 58947: 35178, 58948: 35183, 58949: 35188, 58950: 35191, 58951: 35198, 58952: 35203, 58953: 35208, 58954: 35210, 58955: 35219, 58956: 35224, 58957: 35233, 58958: 35241, 58959: 35238, 58960: 35244, 58961: 35247, 58962: 35250, 58963: 35258, 58964: 35261, 58965: 35263, 58966: 35264, 58967: 35290, 58968: 35292, 58969: 35293, 58970: 35303, 58971: 35316, 58972: 35320, 58973: 35331, 58974: 35350, 58975: 35344, 58976: 35340, 58977: 35355, 58978: 35357, 58979: 35365, 58980: 35382, 58981: 35393, 58982: 35419, 58983: 35410, 58984: 35398, 58985: 35400, 58986: 35452, 58987: 35437, 58988: 35436, 58989: 35426, 58990: 35461, 58991: 35458, 58992: 35460, 58993: 35496, 58994: 35489, 58995: 35473, 58996: 35493, 58997: 35494, 58998: 35482, 58999: 35491, 59e3: 35524, 59001: 35533, 59002: 35522, 59003: 35546, 59004: 35563, 59005: 35571, 59006: 35559, 59008: 35556, 59009: 35569, 59010: 35604, 59011: 35552, 59012: 35554, 59013: 35575, 59014: 35550, 59015: 35547, 59016: 35596, 59017: 35591, 59018: 35610, 59019: 35553, 59020: 35606, 59021: 35600, 59022: 35607, 59023: 35616, 59024: 35635, 59025: 38827, 59026: 35622, 59027: 35627, 59028: 35646, 59029: 35624, 59030: 35649, 59031: 35660, 59032: 35663, 59033: 35662, 59034: 35657, 59035: 35670, 59036: 35675, 59037: 35674, 59038: 35691, 59039: 35679, 59040: 35692, 59041: 35695, 59042: 35700, 59043: 35709, 59044: 35712, 59045: 35724, 59046: 35726, 59047: 35730, 59048: 35731, 59049: 35734, 59050: 35737, 59051: 35738, 59052: 35898, 59053: 35905, 59054: 35903, 59055: 35912, 59056: 35916, 59057: 35918, 59058: 35920, 59059: 35925, 59060: 35938, 59061: 35948, 59062: 35960, 59063: 35962, 59064: 35970, 59065: 35977, 59066: 35973, 59067: 35978, 59068: 35981, 59069: 35982, 59070: 35988, 59071: 35964, 59072: 35992, 59073: 25117, 59074: 36013, 59075: 36010, 59076: 36029, 59077: 36018, 59078: 36019, 59079: 36014, 59080: 36022, 59081: 36040, 59082: 36033, 59083: 36068, 59084: 36067, 59085: 36058, 59086: 36093, 59087: 36090, 59088: 36091, 59089: 36100, 59090: 36101, 59091: 36106, 59092: 36103, 59093: 36111, 59094: 36109, 59095: 36112, 59096: 40782, 59097: 36115, 59098: 36045, 59099: 36116, 59100: 36118, 59101: 36199, 59102: 36205, 59103: 36209, 59104: 36211, 59105: 36225, 59106: 36249, 59107: 36290, 59108: 36286, 59109: 36282, 59110: 36303, 59111: 36314, 59112: 36310, 59113: 36300, 59114: 36315, 59115: 36299, 59116: 36330, 59117: 36331, 59118: 36319, 59119: 36323, 59120: 36348, 59121: 36360, 59122: 36361, 59123: 36351, 59124: 36381, 59125: 36382, 59126: 36368, 59127: 36383, 59128: 36418, 59129: 36405, 59130: 36400, 59131: 36404, 59132: 36426, 59200: 36423, 59201: 36425, 59202: 36428, 59203: 36432, 59204: 36424, 59205: 36441, 59206: 36452, 59207: 36448, 59208: 36394, 59209: 36451, 59210: 36437, 59211: 36470, 59212: 36466, 59213: 36476, 59214: 36481, 59215: 36487, 59216: 36485, 59217: 36484, 59218: 36491, 59219: 36490, 59220: 36499, 59221: 36497, 59222: 36500, 59223: 36505, 59224: 36522, 59225: 36513, 59226: 36524, 59227: 36528, 59228: 36550, 59229: 36529, 59230: 36542, 59231: 36549, 59232: 36552, 59233: 36555, 59234: 36571, 59235: 36579, 59236: 36604, 59237: 36603, 59238: 36587, 59239: 36606, 59240: 36618, 59241: 36613, 59242: 36629, 59243: 36626, 59244: 36633, 59245: 36627, 59246: 36636, 59247: 36639, 59248: 36635, 59249: 36620, 59250: 36646, 59251: 36659, 59252: 36667, 59253: 36665, 59254: 36677, 59255: 36674, 59256: 36670, 59257: 36684, 59258: 36681, 59259: 36678, 59260: 36686, 59261: 36695, 59262: 36700, 59264: 36706, 59265: 36707, 59266: 36708, 59267: 36764, 59268: 36767, 59269: 36771, 59270: 36781, 59271: 36783, 59272: 36791, 59273: 36826, 59274: 36837, 59275: 36834, 59276: 36842, 59277: 36847, 59278: 36999, 59279: 36852, 59280: 36869, 59281: 36857, 59282: 36858, 59283: 36881, 59284: 36885, 59285: 36897, 59286: 36877, 59287: 36894, 59288: 36886, 59289: 36875, 59290: 36903, 59291: 36918, 59292: 36917, 59293: 36921, 59294: 36856, 59295: 36943, 59296: 36944, 59297: 36945, 59298: 36946, 59299: 36878, 59300: 36937, 59301: 36926, 59302: 36950, 59303: 36952, 59304: 36958, 59305: 36968, 59306: 36975, 59307: 36982, 59308: 38568, 59309: 36978, 59310: 36994, 59311: 36989, 59312: 36993, 59313: 36992, 59314: 37002, 59315: 37001, 59316: 37007, 59317: 37032, 59318: 37039, 59319: 37041, 59320: 37045, 59321: 37090, 59322: 37092, 59323: 25160, 59324: 37083, 59325: 37122, 59326: 37138, 59327: 37145, 59328: 37170, 59329: 37168, 59330: 37194, 59331: 37206, 59332: 37208, 59333: 37219, 59334: 37221, 59335: 37225, 59336: 37235, 59337: 37234, 59338: 37259, 59339: 37257, 59340: 37250, 59341: 37282, 59342: 37291, 59343: 37295, 59344: 37290, 59345: 37301, 59346: 37300, 59347: 37306, 59348: 37312, 59349: 37313, 59350: 37321, 59351: 37323, 59352: 37328, 59353: 37334, 59354: 37343, 59355: 37345, 59356: 37339, 59357: 37372, 59358: 37365, 59359: 37366, 59360: 37406, 59361: 37375, 59362: 37396, 59363: 37420, 59364: 37397, 59365: 37393, 59366: 37470, 59367: 37463, 59368: 37445, 59369: 37449, 59370: 37476, 59371: 37448, 59372: 37525, 59373: 37439, 59374: 37451, 59375: 37456, 59376: 37532, 59377: 37526, 59378: 37523, 59379: 37531, 59380: 37466, 59381: 37583, 59382: 37561, 59383: 37559, 59384: 37609, 59385: 37647, 59386: 37626, 59387: 37700, 59388: 37678, 59456: 37657, 59457: 37666, 59458: 37658, 59459: 37667, 59460: 37690, 59461: 37685, 59462: 37691, 59463: 37724, 59464: 37728, 59465: 37756, 59466: 37742, 59467: 37718, 59468: 37808, 59469: 37804, 59470: 37805, 59471: 37780, 59472: 37817, 59473: 37846, 59474: 37847, 59475: 37864, 59476: 37861, 59477: 37848, 59478: 37827, 59479: 37853, 59480: 37840, 59481: 37832, 59482: 37860, 59483: 37914, 59484: 37908, 59485: 37907, 59486: 37891, 59487: 37895, 59488: 37904, 59489: 37942, 59490: 37931, 59491: 37941, 59492: 37921, 59493: 37946, 59494: 37953, 59495: 37970, 59496: 37956, 59497: 37979, 59498: 37984, 59499: 37986, 59500: 37982, 59501: 37994, 59502: 37417, 59503: 38e3, 59504: 38005, 59505: 38007, 59506: 38013, 59507: 37978, 59508: 38012, 59509: 38014, 59510: 38017, 59511: 38015, 59512: 38274, 59513: 38279, 59514: 38282, 59515: 38292, 59516: 38294, 59517: 38296, 59518: 38297, 59520: 38304, 59521: 38312, 59522: 38311, 59523: 38317, 59524: 38332, 59525: 38331, 59526: 38329, 59527: 38334, 59528: 38346, 59529: 28662, 59530: 38339, 59531: 38349, 59532: 38348, 59533: 38357, 59534: 38356, 59535: 38358, 59536: 38364, 59537: 38369, 59538: 38373, 59539: 38370, 59540: 38433, 59541: 38440, 59542: 38446, 59543: 38447, 59544: 38466, 59545: 38476, 59546: 38479, 59547: 38475, 59548: 38519, 59549: 38492, 59550: 38494, 59551: 38493, 59552: 38495, 59553: 38502, 59554: 38514, 59555: 38508, 59556: 38541, 59557: 38552, 59558: 38549, 59559: 38551, 59560: 38570, 59561: 38567, 59562: 38577, 59563: 38578, 59564: 38576, 59565: 38580, 59566: 38582, 59567: 38584, 59568: 38585, 59569: 38606, 59570: 38603, 59571: 38601, 59572: 38605, 59573: 35149, 59574: 38620, 59575: 38669, 59576: 38613, 59577: 38649, 59578: 38660, 59579: 38662, 59580: 38664, 59581: 38675, 59582: 38670, 59583: 38673, 59584: 38671, 59585: 38678, 59586: 38681, 59587: 38692, 59588: 38698, 59589: 38704, 59590: 38713, 59591: 38717, 59592: 38718, 59593: 38724, 59594: 38726, 59595: 38728, 59596: 38722, 59597: 38729, 59598: 38748, 59599: 38752, 59600: 38756, 59601: 38758, 59602: 38760, 59603: 21202, 59604: 38763, 59605: 38769, 59606: 38777, 59607: 38789, 59608: 38780, 59609: 38785, 59610: 38778, 59611: 38790, 59612: 38795, 59613: 38799, 59614: 38800, 59615: 38812, 59616: 38824, 59617: 38822, 59618: 38819, 59619: 38835, 59620: 38836, 59621: 38851, 59622: 38854, 59623: 38856, 59624: 38859, 59625: 38876, 59626: 38893, 59627: 40783, 59628: 38898, 59629: 31455, 59630: 38902, 59631: 38901, 59632: 38927, 59633: 38924, 59634: 38968, 59635: 38948, 59636: 38945, 59637: 38967, 59638: 38973, 59639: 38982, 59640: 38991, 59641: 38987, 59642: 39019, 59643: 39023, 59644: 39024, 59712: 39025, 59713: 39028, 59714: 39027, 59715: 39082, 59716: 39087, 59717: 39089, 59718: 39094, 59719: 39108, 59720: 39107, 59721: 39110, 59722: 39145, 59723: 39147, 59724: 39171, 59725: 39177, 59726: 39186, 59727: 39188, 59728: 39192, 59729: 39201, 59730: 39197, 59731: 39198, 59732: 39204, 59733: 39200, 59734: 39212, 59735: 39214, 59736: 39229, 59737: 39230, 59738: 39234, 59739: 39241, 59740: 39237, 59741: 39248, 59742: 39243, 59743: 39249, 59744: 39250, 59745: 39244, 59746: 39253, 59747: 39319, 59748: 39320, 59749: 39333, 59750: 39341, 59751: 39342, 59752: 39356, 59753: 39391, 59754: 39387, 59755: 39389, 59756: 39384, 59757: 39377, 59758: 39405, 59759: 39406, 59760: 39409, 59761: 39410, 59762: 39419, 59763: 39416, 59764: 39425, 59765: 39439, 59766: 39429, 59767: 39394, 59768: 39449, 59769: 39467, 59770: 39479, 59771: 39493, 59772: 39490, 59773: 39488, 59774: 39491, 59776: 39486, 59777: 39509, 59778: 39501, 59779: 39515, 59780: 39511, 59781: 39519, 59782: 39522, 59783: 39525, 59784: 39524, 59785: 39529, 59786: 39531, 59787: 39530, 59788: 39597, 59789: 39600, 59790: 39612, 59791: 39616, 59792: 39631, 59793: 39633, 59794: 39635, 59795: 39636, 59796: 39646, 59797: 39647, 59798: 39650, 59799: 39651, 59800: 39654, 59801: 39663, 59802: 39659, 59803: 39662, 59804: 39668, 59805: 39665, 59806: 39671, 59807: 39675, 59808: 39686, 59809: 39704, 59810: 39706, 59811: 39711, 59812: 39714, 59813: 39715, 59814: 39717, 59815: 39719, 59816: 39720, 59817: 39721, 59818: 39722, 59819: 39726, 59820: 39727, 59821: 39730, 59822: 39748, 59823: 39747, 59824: 39759, 59825: 39757, 59826: 39758, 59827: 39761, 59828: 39768, 59829: 39796, 59830: 39827, 59831: 39811, 59832: 39825, 59833: 39830, 59834: 39831, 59835: 39839, 59836: 39840, 59837: 39848, 59838: 39860, 59839: 39872, 59840: 39882, 59841: 39865, 59842: 39878, 59843: 39887, 59844: 39889, 59845: 39890, 59846: 39907, 59847: 39906, 59848: 39908, 59849: 39892, 59850: 39905, 59851: 39994, 59852: 39922, 59853: 39921, 59854: 39920, 59855: 39957, 59856: 39956, 59857: 39945, 59858: 39955, 59859: 39948, 59860: 39942, 59861: 39944, 59862: 39954, 59863: 39946, 59864: 39940, 59865: 39982, 59866: 39963, 59867: 39973, 59868: 39972, 59869: 39969, 59870: 39984, 59871: 40007, 59872: 39986, 59873: 40006, 59874: 39998, 59875: 40026, 59876: 40032, 59877: 40039, 59878: 40054, 59879: 40056, 59880: 40167, 59881: 40172, 59882: 40176, 59883: 40201, 59884: 40200, 59885: 40171, 59886: 40195, 59887: 40198, 59888: 40234, 59889: 40230, 59890: 40367, 59891: 40227, 59892: 40223, 59893: 40260, 59894: 40213, 59895: 40210, 59896: 40257, 59897: 40255, 59898: 40254, 59899: 40262, 59900: 40264, 59968: 40285, 59969: 40286, 59970: 40292, 59971: 40273, 59972: 40272, 59973: 40281, 59974: 40306, 59975: 40329, 59976: 40327, 59977: 40363, 59978: 40303, 59979: 40314, 59980: 40346, 59981: 40356, 59982: 40361, 59983: 40370, 59984: 40388, 59985: 40385, 59986: 40379, 59987: 40376, 59988: 40378, 59989: 40390, 59990: 40399, 59991: 40386, 59992: 40409, 59993: 40403, 59994: 40440, 59995: 40422, 59996: 40429, 59997: 40431, 59998: 40445, 59999: 40474, 6e4: 40475, 60001: 40478, 60002: 40565, 60003: 40569, 60004: 40573, 60005: 40577, 60006: 40584, 60007: 40587, 60008: 40588, 60009: 40594, 60010: 40597, 60011: 40593, 60012: 40605, 60013: 40613, 60014: 40617, 60015: 40632, 60016: 40618, 60017: 40621, 60018: 38753, 60019: 40652, 60020: 40654, 60021: 40655, 60022: 40656, 60023: 40660, 60024: 40668, 60025: 40670, 60026: 40669, 60027: 40672, 60028: 40677, 60029: 40680, 60030: 40687, 60032: 40692, 60033: 40694, 60034: 40695, 60035: 40697, 60036: 40699, 60037: 40700, 60038: 40701, 60039: 40711, 60040: 40712, 60041: 30391, 60042: 40725, 60043: 40737, 60044: 40748, 60045: 40766, 60046: 40778, 60047: 40786, 60048: 40788, 60049: 40803, 60050: 40799, 60051: 40800, 60052: 40801, 60053: 40806, 60054: 40807, 60055: 40812, 60056: 40810, 60057: 40823, 60058: 40818, 60059: 40822, 60060: 40853, 60061: 40860, 60062: 40864, 60063: 22575, 60064: 27079, 60065: 36953, 60066: 29796, 60067: 20956, 60068: 29081 };
    }), (function(e3, t3, n2) {
      Object.defineProperty(t3, "__esModule", { value: true });
      var r2 = n2(1), i2 = n2(2);
      function a2(e4, t4, n3, r3) {
        var i3;
        t4.degree() < n3.degree() && (i3 = [n3, t4], t4 = i3[0], n3 = i3[1]);
        for (var a3 = t4, o3 = n3, s3 = e4.zero, c3 = e4.one; o3.degree() >= r3 / 2; ) {
          var l2 = a3, u2 = s3;
          if (a3 = o3, s3 = c3, a3.isZero()) return null;
          o3 = l2;
          for (var d2 = e4.zero, f2 = a3.getCoefficient(a3.degree()), p2 = e4.inverse(f2); o3.degree() >= a3.degree() && !o3.isZero(); ) {
            var m2 = o3.degree() - a3.degree(), h2 = e4.multiply(o3.getCoefficient(o3.degree()), p2);
            d2 = d2.addOrSubtract(e4.buildMonomial(m2, h2)), o3 = o3.addOrSubtract(a3.multiplyByMonomial(m2, h2));
          }
          if (c3 = d2.multiplyPoly(s3).addOrSubtract(u2), o3.degree() >= a3.degree()) return null;
        }
        var g2 = c3.getCoefficient(0);
        if (g2 === 0) return null;
        var _2 = e4.inverse(g2);
        return [c3.multiply(_2), o3.multiply(_2)];
      }
      function o2(e4, t4) {
        var n3 = t4.degree();
        if (n3 === 1) return [t4.getCoefficient(1)];
        for (var r3 = Array(n3), i3 = 0, a3 = 1; a3 < e4.size && i3 < n3; a3++) t4.evaluateAt(a3) === 0 && (r3[i3] = e4.inverse(a3), i3++);
        return i3 === n3 ? r3 : null;
      }
      function s2(e4, t4, n3) {
        for (var i3 = n3.length, a3 = Array(i3), o3 = 0; o3 < i3; o3++) {
          for (var s3 = e4.inverse(n3[o3]), c3 = 1, l2 = 0; l2 < i3; l2++) o3 !== l2 && (c3 = e4.multiply(c3, r2.addOrSubtractGF(1, e4.multiply(n3[l2], s3))));
          a3[o3] = e4.multiply(t4.evaluateAt(s3), e4.inverse(c3)), e4.generatorBase !== 0 && (a3[o3] = e4.multiply(a3[o3], s3));
        }
        return a3;
      }
      function c2(e4, t4) {
        var n3 = new Uint8ClampedArray(e4.length);
        n3.set(e4);
        for (var c3 = new r2.default(285, 256, 0), l2 = new i2.default(c3, n3), u2 = new Uint8ClampedArray(t4), d2 = false, f2 = 0; f2 < t4; f2++) {
          var p2 = l2.evaluateAt(c3.exp(f2 + c3.generatorBase));
          u2[u2.length - 1 - f2] = p2, p2 !== 0 && (d2 = true);
        }
        if (!d2) return n3;
        var m2 = new i2.default(c3, u2), h2 = a2(c3, c3.buildMonomial(t4, 1), m2, t4);
        if (h2 === null) return null;
        var g2 = o2(c3, h2[0]);
        if (g2 == null) return null;
        for (var _2 = s2(c3, h2[1], g2), v2 = 0; v2 < g2.length; v2++) {
          var y2 = n3.length - 1 - c3.log(g2[v2]);
          if (y2 < 0) return null;
          n3[y2] = r2.addOrSubtractGF(n3[y2], _2[v2]);
        }
        return n3;
      }
      t3.decode = c2;
    }), (function(e3, t3, n2) {
      Object.defineProperty(t3, "__esModule", { value: true }), t3.VERSIONS = [{ infoBits: null, versionNumber: 1, alignmentPatternCenters: [], errorCorrectionLevels: [{ ecCodewordsPerBlock: 7, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 19 }] }, { ecCodewordsPerBlock: 10, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 16 }] }, { ecCodewordsPerBlock: 13, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 13 }] }, { ecCodewordsPerBlock: 17, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 9 }] }] }, { infoBits: null, versionNumber: 2, alignmentPatternCenters: [6, 18], errorCorrectionLevels: [{ ecCodewordsPerBlock: 10, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 34 }] }, { ecCodewordsPerBlock: 16, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 28 }] }, { ecCodewordsPerBlock: 22, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 22 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 16 }] }] }, { infoBits: null, versionNumber: 3, alignmentPatternCenters: [6, 22], errorCorrectionLevels: [{ ecCodewordsPerBlock: 15, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 55 }] }, { ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 44 }] }, { ecCodewordsPerBlock: 18, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 17 }] }, { ecCodewordsPerBlock: 22, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 13 }] }] }, { infoBits: null, versionNumber: 4, alignmentPatternCenters: [6, 26], errorCorrectionLevels: [{ ecCodewordsPerBlock: 20, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 80 }] }, { ecCodewordsPerBlock: 18, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 32 }] }, { ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 24 }] }, { ecCodewordsPerBlock: 16, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 9 }] }] }, { infoBits: null, versionNumber: 5, alignmentPatternCenters: [6, 30], errorCorrectionLevels: [{ ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 108 }] }, { ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 43 }] }, { ecCodewordsPerBlock: 18, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 15 }, { numBlocks: 2, dataCodewordsPerBlock: 16 }] }, { ecCodewordsPerBlock: 22, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 11 }, { numBlocks: 2, dataCodewordsPerBlock: 12 }] }] }, { infoBits: null, versionNumber: 6, alignmentPatternCenters: [6, 34], errorCorrectionLevels: [{ ecCodewordsPerBlock: 18, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 68 }] }, { ecCodewordsPerBlock: 16, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 27 }] }, { ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 19 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 15 }] }] }, { infoBits: 31892, versionNumber: 7, alignmentPatternCenters: [6, 22, 38], errorCorrectionLevels: [{ ecCodewordsPerBlock: 20, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 78 }] }, { ecCodewordsPerBlock: 18, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 31 }] }, { ecCodewordsPerBlock: 18, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 14 }, { numBlocks: 4, dataCodewordsPerBlock: 15 }] }, { ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 13 }, { numBlocks: 1, dataCodewordsPerBlock: 14 }] }] }, { infoBits: 34236, versionNumber: 8, alignmentPatternCenters: [6, 24, 42], errorCorrectionLevels: [{ ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 97 }] }, { ecCodewordsPerBlock: 22, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 38 }, { numBlocks: 2, dataCodewordsPerBlock: 39 }] }, { ecCodewordsPerBlock: 22, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 18 }, { numBlocks: 2, dataCodewordsPerBlock: 19 }] }, { ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 14 }, { numBlocks: 2, dataCodewordsPerBlock: 15 }] }] }, { infoBits: 39577, versionNumber: 9, alignmentPatternCenters: [6, 26, 46], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 116 }] }, { ecCodewordsPerBlock: 22, ecBlocks: [{ numBlocks: 3, dataCodewordsPerBlock: 36 }, { numBlocks: 2, dataCodewordsPerBlock: 37 }] }, { ecCodewordsPerBlock: 20, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 16 }, { numBlocks: 4, dataCodewordsPerBlock: 17 }] }, { ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 12 }, { numBlocks: 4, dataCodewordsPerBlock: 13 }] }] }, { infoBits: 42195, versionNumber: 10, alignmentPatternCenters: [6, 28, 50], errorCorrectionLevels: [{ ecCodewordsPerBlock: 18, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 68 }, { numBlocks: 2, dataCodewordsPerBlock: 69 }] }, { ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 43 }, { numBlocks: 1, dataCodewordsPerBlock: 44 }] }, { ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 6, dataCodewordsPerBlock: 19 }, { numBlocks: 2, dataCodewordsPerBlock: 20 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 6, dataCodewordsPerBlock: 15 }, { numBlocks: 2, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 48118, versionNumber: 11, alignmentPatternCenters: [6, 30, 54], errorCorrectionLevels: [{ ecCodewordsPerBlock: 20, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 81 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 50 }, { numBlocks: 4, dataCodewordsPerBlock: 51 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 22 }, { numBlocks: 4, dataCodewordsPerBlock: 23 }] }, { ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 3, dataCodewordsPerBlock: 12 }, { numBlocks: 8, dataCodewordsPerBlock: 13 }] }] }, { infoBits: 51042, versionNumber: 12, alignmentPatternCenters: [6, 32, 58], errorCorrectionLevels: [{ ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 92 }, { numBlocks: 2, dataCodewordsPerBlock: 93 }] }, { ecCodewordsPerBlock: 22, ecBlocks: [{ numBlocks: 6, dataCodewordsPerBlock: 36 }, { numBlocks: 2, dataCodewordsPerBlock: 37 }] }, { ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 20 }, { numBlocks: 6, dataCodewordsPerBlock: 21 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 7, dataCodewordsPerBlock: 14 }, { numBlocks: 4, dataCodewordsPerBlock: 15 }] }] }, { infoBits: 55367, versionNumber: 13, alignmentPatternCenters: [6, 34, 62], errorCorrectionLevels: [{ ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 107 }] }, { ecCodewordsPerBlock: 22, ecBlocks: [{ numBlocks: 8, dataCodewordsPerBlock: 37 }, { numBlocks: 1, dataCodewordsPerBlock: 38 }] }, { ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 8, dataCodewordsPerBlock: 20 }, { numBlocks: 4, dataCodewordsPerBlock: 21 }] }, { ecCodewordsPerBlock: 22, ecBlocks: [{ numBlocks: 12, dataCodewordsPerBlock: 11 }, { numBlocks: 4, dataCodewordsPerBlock: 12 }] }] }, { infoBits: 58893, versionNumber: 14, alignmentPatternCenters: [6, 26, 46, 66], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 3, dataCodewordsPerBlock: 115 }, { numBlocks: 1, dataCodewordsPerBlock: 116 }] }, { ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 40 }, { numBlocks: 5, dataCodewordsPerBlock: 41 }] }, { ecCodewordsPerBlock: 20, ecBlocks: [{ numBlocks: 11, dataCodewordsPerBlock: 16 }, { numBlocks: 5, dataCodewordsPerBlock: 17 }] }, { ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 11, dataCodewordsPerBlock: 12 }, { numBlocks: 5, dataCodewordsPerBlock: 13 }] }] }, { infoBits: 63784, versionNumber: 15, alignmentPatternCenters: [6, 26, 48, 70], errorCorrectionLevels: [{ ecCodewordsPerBlock: 22, ecBlocks: [{ numBlocks: 5, dataCodewordsPerBlock: 87 }, { numBlocks: 1, dataCodewordsPerBlock: 88 }] }, { ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 5, dataCodewordsPerBlock: 41 }, { numBlocks: 5, dataCodewordsPerBlock: 42 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 5, dataCodewordsPerBlock: 24 }, { numBlocks: 7, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 11, dataCodewordsPerBlock: 12 }, { numBlocks: 7, dataCodewordsPerBlock: 13 }] }] }, { infoBits: 68472, versionNumber: 16, alignmentPatternCenters: [6, 26, 50, 74], errorCorrectionLevels: [{ ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 5, dataCodewordsPerBlock: 98 }, { numBlocks: 1, dataCodewordsPerBlock: 99 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 7, dataCodewordsPerBlock: 45 }, { numBlocks: 3, dataCodewordsPerBlock: 46 }] }, { ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 15, dataCodewordsPerBlock: 19 }, { numBlocks: 2, dataCodewordsPerBlock: 20 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 3, dataCodewordsPerBlock: 15 }, { numBlocks: 13, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 70749, versionNumber: 17, alignmentPatternCenters: [6, 30, 54, 78], errorCorrectionLevels: [{ ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 107 }, { numBlocks: 5, dataCodewordsPerBlock: 108 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 10, dataCodewordsPerBlock: 46 }, { numBlocks: 1, dataCodewordsPerBlock: 47 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 22 }, { numBlocks: 15, dataCodewordsPerBlock: 23 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 14 }, { numBlocks: 17, dataCodewordsPerBlock: 15 }] }] }, { infoBits: 76311, versionNumber: 18, alignmentPatternCenters: [6, 30, 56, 82], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 5, dataCodewordsPerBlock: 120 }, { numBlocks: 1, dataCodewordsPerBlock: 121 }] }, { ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 9, dataCodewordsPerBlock: 43 }, { numBlocks: 4, dataCodewordsPerBlock: 44 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 17, dataCodewordsPerBlock: 22 }, { numBlocks: 1, dataCodewordsPerBlock: 23 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 14 }, { numBlocks: 19, dataCodewordsPerBlock: 15 }] }] }, { infoBits: 79154, versionNumber: 19, alignmentPatternCenters: [6, 30, 58, 86], errorCorrectionLevels: [{ ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 3, dataCodewordsPerBlock: 113 }, { numBlocks: 4, dataCodewordsPerBlock: 114 }] }, { ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 3, dataCodewordsPerBlock: 44 }, { numBlocks: 11, dataCodewordsPerBlock: 45 }] }, { ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 17, dataCodewordsPerBlock: 21 }, { numBlocks: 4, dataCodewordsPerBlock: 22 }] }, { ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 9, dataCodewordsPerBlock: 13 }, { numBlocks: 16, dataCodewordsPerBlock: 14 }] }] }, { infoBits: 84390, versionNumber: 20, alignmentPatternCenters: [6, 34, 62, 90], errorCorrectionLevels: [{ ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 3, dataCodewordsPerBlock: 107 }, { numBlocks: 5, dataCodewordsPerBlock: 108 }] }, { ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 3, dataCodewordsPerBlock: 41 }, { numBlocks: 13, dataCodewordsPerBlock: 42 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 15, dataCodewordsPerBlock: 24 }, { numBlocks: 5, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 15, dataCodewordsPerBlock: 15 }, { numBlocks: 10, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 87683, versionNumber: 21, alignmentPatternCenters: [6, 28, 50, 72, 94], errorCorrectionLevels: [{ ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 116 }, { numBlocks: 4, dataCodewordsPerBlock: 117 }] }, { ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 17, dataCodewordsPerBlock: 42 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 17, dataCodewordsPerBlock: 22 }, { numBlocks: 6, dataCodewordsPerBlock: 23 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 19, dataCodewordsPerBlock: 16 }, { numBlocks: 6, dataCodewordsPerBlock: 17 }] }] }, { infoBits: 92361, versionNumber: 22, alignmentPatternCenters: [6, 26, 50, 74, 98], errorCorrectionLevels: [{ ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 111 }, { numBlocks: 7, dataCodewordsPerBlock: 112 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 17, dataCodewordsPerBlock: 46 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 7, dataCodewordsPerBlock: 24 }, { numBlocks: 16, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 24, ecBlocks: [{ numBlocks: 34, dataCodewordsPerBlock: 13 }] }] }, { infoBits: 96236, versionNumber: 23, alignmentPatternCenters: [6, 30, 54, 74, 102], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 121 }, { numBlocks: 5, dataCodewordsPerBlock: 122 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 47 }, { numBlocks: 14, dataCodewordsPerBlock: 48 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 11, dataCodewordsPerBlock: 24 }, { numBlocks: 14, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 16, dataCodewordsPerBlock: 15 }, { numBlocks: 14, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 102084, versionNumber: 24, alignmentPatternCenters: [6, 28, 54, 80, 106], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 6, dataCodewordsPerBlock: 117 }, { numBlocks: 4, dataCodewordsPerBlock: 118 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 6, dataCodewordsPerBlock: 45 }, { numBlocks: 14, dataCodewordsPerBlock: 46 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 11, dataCodewordsPerBlock: 24 }, { numBlocks: 16, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 30, dataCodewordsPerBlock: 16 }, { numBlocks: 2, dataCodewordsPerBlock: 17 }] }] }, { infoBits: 102881, versionNumber: 25, alignmentPatternCenters: [6, 32, 58, 84, 110], errorCorrectionLevels: [{ ecCodewordsPerBlock: 26, ecBlocks: [{ numBlocks: 8, dataCodewordsPerBlock: 106 }, { numBlocks: 4, dataCodewordsPerBlock: 107 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 8, dataCodewordsPerBlock: 47 }, { numBlocks: 13, dataCodewordsPerBlock: 48 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 7, dataCodewordsPerBlock: 24 }, { numBlocks: 22, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 22, dataCodewordsPerBlock: 15 }, { numBlocks: 13, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 110507, versionNumber: 26, alignmentPatternCenters: [6, 30, 58, 86, 114], errorCorrectionLevels: [{ ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 10, dataCodewordsPerBlock: 114 }, { numBlocks: 2, dataCodewordsPerBlock: 115 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 19, dataCodewordsPerBlock: 46 }, { numBlocks: 4, dataCodewordsPerBlock: 47 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 28, dataCodewordsPerBlock: 22 }, { numBlocks: 6, dataCodewordsPerBlock: 23 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 33, dataCodewordsPerBlock: 16 }, { numBlocks: 4, dataCodewordsPerBlock: 17 }] }] }, { infoBits: 110734, versionNumber: 27, alignmentPatternCenters: [6, 34, 62, 90, 118], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 8, dataCodewordsPerBlock: 122 }, { numBlocks: 4, dataCodewordsPerBlock: 123 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 22, dataCodewordsPerBlock: 45 }, { numBlocks: 3, dataCodewordsPerBlock: 46 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 8, dataCodewordsPerBlock: 23 }, { numBlocks: 26, dataCodewordsPerBlock: 24 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 12, dataCodewordsPerBlock: 15 }, { numBlocks: 28, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 117786, versionNumber: 28, alignmentPatternCenters: [6, 26, 50, 74, 98, 122], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 3, dataCodewordsPerBlock: 117 }, { numBlocks: 10, dataCodewordsPerBlock: 118 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 3, dataCodewordsPerBlock: 45 }, { numBlocks: 23, dataCodewordsPerBlock: 46 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 24 }, { numBlocks: 31, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 11, dataCodewordsPerBlock: 15 }, { numBlocks: 31, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 119615, versionNumber: 29, alignmentPatternCenters: [6, 30, 54, 78, 102, 126], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 7, dataCodewordsPerBlock: 116 }, { numBlocks: 7, dataCodewordsPerBlock: 117 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 21, dataCodewordsPerBlock: 45 }, { numBlocks: 7, dataCodewordsPerBlock: 46 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 1, dataCodewordsPerBlock: 23 }, { numBlocks: 37, dataCodewordsPerBlock: 24 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 19, dataCodewordsPerBlock: 15 }, { numBlocks: 26, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 126325, versionNumber: 30, alignmentPatternCenters: [6, 26, 52, 78, 104, 130], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 5, dataCodewordsPerBlock: 115 }, { numBlocks: 10, dataCodewordsPerBlock: 116 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 19, dataCodewordsPerBlock: 47 }, { numBlocks: 10, dataCodewordsPerBlock: 48 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 15, dataCodewordsPerBlock: 24 }, { numBlocks: 25, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 23, dataCodewordsPerBlock: 15 }, { numBlocks: 25, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 127568, versionNumber: 31, alignmentPatternCenters: [6, 30, 56, 82, 108, 134], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 13, dataCodewordsPerBlock: 115 }, { numBlocks: 3, dataCodewordsPerBlock: 116 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 46 }, { numBlocks: 29, dataCodewordsPerBlock: 47 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 42, dataCodewordsPerBlock: 24 }, { numBlocks: 1, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 23, dataCodewordsPerBlock: 15 }, { numBlocks: 28, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 133589, versionNumber: 32, alignmentPatternCenters: [6, 34, 60, 86, 112, 138], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 17, dataCodewordsPerBlock: 115 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 10, dataCodewordsPerBlock: 46 }, { numBlocks: 23, dataCodewordsPerBlock: 47 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 10, dataCodewordsPerBlock: 24 }, { numBlocks: 35, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 19, dataCodewordsPerBlock: 15 }, { numBlocks: 35, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 136944, versionNumber: 33, alignmentPatternCenters: [6, 30, 58, 86, 114, 142], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 17, dataCodewordsPerBlock: 115 }, { numBlocks: 1, dataCodewordsPerBlock: 116 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 14, dataCodewordsPerBlock: 46 }, { numBlocks: 21, dataCodewordsPerBlock: 47 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 29, dataCodewordsPerBlock: 24 }, { numBlocks: 19, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 11, dataCodewordsPerBlock: 15 }, { numBlocks: 46, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 141498, versionNumber: 34, alignmentPatternCenters: [6, 34, 62, 90, 118, 146], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 13, dataCodewordsPerBlock: 115 }, { numBlocks: 6, dataCodewordsPerBlock: 116 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 14, dataCodewordsPerBlock: 46 }, { numBlocks: 23, dataCodewordsPerBlock: 47 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 44, dataCodewordsPerBlock: 24 }, { numBlocks: 7, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 59, dataCodewordsPerBlock: 16 }, { numBlocks: 1, dataCodewordsPerBlock: 17 }] }] }, { infoBits: 145311, versionNumber: 35, alignmentPatternCenters: [6, 30, 54, 78, 102, 126, 150], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 12, dataCodewordsPerBlock: 121 }, { numBlocks: 7, dataCodewordsPerBlock: 122 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 12, dataCodewordsPerBlock: 47 }, { numBlocks: 26, dataCodewordsPerBlock: 48 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 39, dataCodewordsPerBlock: 24 }, { numBlocks: 14, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 22, dataCodewordsPerBlock: 15 }, { numBlocks: 41, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 150283, versionNumber: 36, alignmentPatternCenters: [6, 24, 50, 76, 102, 128, 154], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 6, dataCodewordsPerBlock: 121 }, { numBlocks: 14, dataCodewordsPerBlock: 122 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 6, dataCodewordsPerBlock: 47 }, { numBlocks: 34, dataCodewordsPerBlock: 48 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 46, dataCodewordsPerBlock: 24 }, { numBlocks: 10, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 2, dataCodewordsPerBlock: 15 }, { numBlocks: 64, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 152622, versionNumber: 37, alignmentPatternCenters: [6, 28, 54, 80, 106, 132, 158], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 17, dataCodewordsPerBlock: 122 }, { numBlocks: 4, dataCodewordsPerBlock: 123 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 29, dataCodewordsPerBlock: 46 }, { numBlocks: 14, dataCodewordsPerBlock: 47 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 49, dataCodewordsPerBlock: 24 }, { numBlocks: 10, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 24, dataCodewordsPerBlock: 15 }, { numBlocks: 46, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 158308, versionNumber: 38, alignmentPatternCenters: [6, 32, 58, 84, 110, 136, 162], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 4, dataCodewordsPerBlock: 122 }, { numBlocks: 18, dataCodewordsPerBlock: 123 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 13, dataCodewordsPerBlock: 46 }, { numBlocks: 32, dataCodewordsPerBlock: 47 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 48, dataCodewordsPerBlock: 24 }, { numBlocks: 14, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 42, dataCodewordsPerBlock: 15 }, { numBlocks: 32, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 161089, versionNumber: 39, alignmentPatternCenters: [6, 26, 54, 82, 110, 138, 166], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 20, dataCodewordsPerBlock: 117 }, { numBlocks: 4, dataCodewordsPerBlock: 118 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 40, dataCodewordsPerBlock: 47 }, { numBlocks: 7, dataCodewordsPerBlock: 48 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 43, dataCodewordsPerBlock: 24 }, { numBlocks: 22, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 10, dataCodewordsPerBlock: 15 }, { numBlocks: 67, dataCodewordsPerBlock: 16 }] }] }, { infoBits: 167017, versionNumber: 40, alignmentPatternCenters: [6, 30, 58, 86, 114, 142, 170], errorCorrectionLevels: [{ ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 19, dataCodewordsPerBlock: 118 }, { numBlocks: 6, dataCodewordsPerBlock: 119 }] }, { ecCodewordsPerBlock: 28, ecBlocks: [{ numBlocks: 18, dataCodewordsPerBlock: 47 }, { numBlocks: 31, dataCodewordsPerBlock: 48 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 34, dataCodewordsPerBlock: 24 }, { numBlocks: 34, dataCodewordsPerBlock: 25 }] }, { ecCodewordsPerBlock: 30, ecBlocks: [{ numBlocks: 20, dataCodewordsPerBlock: 15 }, { numBlocks: 61, dataCodewordsPerBlock: 16 }] }] }];
    }), (function(e3, t3, n2) {
      Object.defineProperty(t3, "__esModule", { value: true });
      var r2 = n2(0);
      function i2(e4, t4, n3, r3) {
        var i3 = e4.x - t4.x + n3.x - r3.x, a3 = e4.y - t4.y + n3.y - r3.y;
        if (i3 === 0 && a3 === 0) return { a11: t4.x - e4.x, a12: t4.y - e4.y, a13: 0, a21: n3.x - t4.x, a22: n3.y - t4.y, a23: 0, a31: e4.x, a32: e4.y, a33: 1 };
        var o3 = t4.x - n3.x, s3 = r3.x - n3.x, c2 = t4.y - n3.y, l2 = r3.y - n3.y, u2 = o3 * l2 - s3 * c2, d2 = (i3 * l2 - s3 * a3) / u2, f2 = (o3 * a3 - i3 * c2) / u2;
        return { a11: t4.x - e4.x + d2 * t4.x, a12: t4.y - e4.y + d2 * t4.y, a13: d2, a21: r3.x - e4.x + f2 * r3.x, a22: r3.y - e4.y + f2 * r3.y, a23: f2, a31: e4.x, a32: e4.y, a33: 1 };
      }
      function a2(e4, t4, n3, r3) {
        var a3 = i2(e4, t4, n3, r3);
        return { a11: a3.a22 * a3.a33 - a3.a23 * a3.a32, a12: a3.a13 * a3.a32 - a3.a12 * a3.a33, a13: a3.a12 * a3.a23 - a3.a13 * a3.a22, a21: a3.a23 * a3.a31 - a3.a21 * a3.a33, a22: a3.a11 * a3.a33 - a3.a13 * a3.a31, a23: a3.a13 * a3.a21 - a3.a11 * a3.a23, a31: a3.a21 * a3.a32 - a3.a22 * a3.a31, a32: a3.a12 * a3.a31 - a3.a11 * a3.a32, a33: a3.a11 * a3.a22 - a3.a12 * a3.a21 };
      }
      function o2(e4, t4) {
        return { a11: e4.a11 * t4.a11 + e4.a21 * t4.a12 + e4.a31 * t4.a13, a12: e4.a12 * t4.a11 + e4.a22 * t4.a12 + e4.a32 * t4.a13, a13: e4.a13 * t4.a11 + e4.a23 * t4.a12 + e4.a33 * t4.a13, a21: e4.a11 * t4.a21 + e4.a21 * t4.a22 + e4.a31 * t4.a23, a22: e4.a12 * t4.a21 + e4.a22 * t4.a22 + e4.a32 * t4.a23, a23: e4.a13 * t4.a21 + e4.a23 * t4.a22 + e4.a33 * t4.a23, a31: e4.a11 * t4.a31 + e4.a21 * t4.a32 + e4.a31 * t4.a33, a32: e4.a12 * t4.a31 + e4.a22 * t4.a32 + e4.a32 * t4.a33, a33: e4.a13 * t4.a31 + e4.a23 * t4.a32 + e4.a33 * t4.a33 };
      }
      function s2(e4, t4) {
        for (var n3 = a2({ x: 3.5, y: 3.5 }, { x: t4.dimension - 3.5, y: 3.5 }, { x: t4.dimension - 6.5, y: t4.dimension - 6.5 }, { x: 3.5, y: t4.dimension - 3.5 }), s3 = o2(i2(t4.topLeft, t4.topRight, t4.alignmentPattern, t4.bottomLeft), n3), c2 = r2.BitMatrix.createEmpty(t4.dimension, t4.dimension), l2 = function(e5, t5) {
          var n4 = s3.a13 * e5 + s3.a23 * t5 + s3.a33;
          return { x: (s3.a11 * e5 + s3.a21 * t5 + s3.a31) / n4, y: (s3.a12 * e5 + s3.a22 * t5 + s3.a32) / n4 };
        }, u2 = 0; u2 < t4.dimension; u2++) for (var d2 = 0; d2 < t4.dimension; d2++) {
          var f2 = l2(d2 + 0.5, u2 + 0.5);
          c2.set(d2, u2, e4.get(Math.floor(f2.x), Math.floor(f2.y)));
        }
        return { matrix: c2, mappingFunction: l2 };
      }
      t3.extract = s2;
    }), (function(e3, t3, n2) {
      Object.defineProperty(t3, "__esModule", { value: true });
      var r2 = 4, i2 = 0.5, a2 = 1.5, o2 = function(e4, t4) {
        return Math.sqrt((t4.x - e4.x) ** 2 + (t4.y - e4.y) ** 2);
      };
      function s2(e4) {
        return e4.reduce(function(e5, t4) {
          return e5 + t4;
        });
      }
      function c2(e4, t4, n3) {
        var r3, i3, a3, s3, c3 = o2(e4, t4), l3 = o2(t4, n3), u3 = o2(e4, n3), d3, f3, p3;
        return l3 >= c3 && l3 >= u3 ? (r3 = [t4, e4, n3], d3 = r3[0], f3 = r3[1], p3 = r3[2]) : u3 >= l3 && u3 >= c3 ? (i3 = [e4, t4, n3], d3 = i3[0], f3 = i3[1], p3 = i3[2]) : (a3 = [e4, n3, t4], d3 = a3[0], f3 = a3[1], p3 = a3[2]), (p3.x - f3.x) * (d3.y - f3.y) - (p3.y - f3.y) * (d3.x - f3.x) < 0 && (s3 = [p3, d3], d3 = s3[0], p3 = s3[1]), { bottomLeft: d3, topLeft: f3, topRight: p3 };
      }
      function l2(e4, t4, n3, r3) {
        var i3 = (s2(d2(e4, n3, r3, 5)) / 7 + s2(d2(e4, t4, r3, 5)) / 7 + s2(d2(n3, e4, r3, 5)) / 7 + s2(d2(t4, e4, r3, 5)) / 7) / 4;
        if (i3 < 1) throw Error(`Invalid module size`);
        var a3 = Math.round(o2(e4, t4) / i3), c3 = Math.round(o2(e4, n3) / i3), l3 = Math.floor((a3 + c3) / 2) + 7;
        switch (l3 % 4) {
          case 0:
            l3++;
            break;
          case 2:
            l3--;
        }
        return { dimension: l3, moduleSize: i3 };
      }
      function u2(e4, t4, n3, r3) {
        var i3 = [{ x: Math.floor(e4.x), y: Math.floor(e4.y) }], a3 = Math.abs(t4.y - e4.y) > Math.abs(t4.x - e4.x), s3, c3, l3, u3;
        a3 ? (s3 = Math.floor(e4.y), c3 = Math.floor(e4.x), l3 = Math.floor(t4.y), u3 = Math.floor(t4.x)) : (s3 = Math.floor(e4.x), c3 = Math.floor(e4.y), l3 = Math.floor(t4.x), u3 = Math.floor(t4.y));
        for (var d3 = Math.abs(l3 - s3), f3 = Math.abs(u3 - c3), p3 = Math.floor(-d3 / 2), m3 = s3 < l3 ? 1 : -1, h3 = c3 < u3 ? 1 : -1, g3 = true, _2 = s3, v2 = c3; _2 !== l3 + m3; _2 += m3) {
          var y2 = a3 ? v2 : _2, b2 = a3 ? _2 : v2;
          if (n3.get(y2, b2) !== g3 && (g3 = !g3, i3.push({ x: y2, y: b2 }), i3.length === r3 + 1)) break;
          if (p3 += f3, p3 > 0) {
            if (v2 === u3) break;
            v2 += h3, p3 -= d3;
          }
        }
        for (var x2 = [], S2 = 0; S2 < r3; S2++) i3[S2] && i3[S2 + 1] ? x2.push(o2(i3[S2], i3[S2 + 1])) : x2.push(0);
        return x2;
      }
      function d2(e4, t4, n3, r3) {
        var i3, a3 = t4.y - e4.y, o3 = t4.x - e4.x, s3 = u2(e4, t4, n3, Math.ceil(r3 / 2)), c3 = u2(e4, { x: e4.x - o3, y: e4.y - a3 }, n3, Math.ceil(r3 / 2)), l3 = s3.shift() + c3.shift() - 1;
        return (i3 = c3.concat(l3)).concat.apply(i3, s3);
      }
      function f2(e4, t4) {
        var n3 = s2(e4) / s2(t4), r3 = 0;
        return t4.forEach(function(t5, i3) {
          r3 += (e4[i3] - t5 * n3) ** 2;
        }), { averageSize: n3, error: r3 };
      }
      function p2(e4, t4, n3) {
        try {
          var r3 = d2(e4, { x: -1, y: e4.y }, n3, t4.length), i3 = d2(e4, { x: e4.x, y: -1 }, n3, t4.length), a3 = d2(e4, { x: Math.max(0, e4.x - e4.y) - 1, y: Math.max(0, e4.y - e4.x) - 1 }, n3, t4.length), o3 = d2(e4, { x: Math.min(n3.width, e4.x + e4.y) + 1, y: Math.min(n3.height, e4.y + e4.x) + 1 }, n3, t4.length), s3 = f2(r3, t4), c3 = f2(i3, t4), l3 = f2(a3, t4), u3 = f2(o3, t4), p3 = Math.sqrt(s3.error * s3.error + c3.error * c3.error + l3.error * l3.error + u3.error * u3.error), m3 = (s3.averageSize + c3.averageSize + l3.averageSize + u3.averageSize) / 4;
          return p3 + ((s3.averageSize - m3) ** 2 + (c3.averageSize - m3) ** 2 + (l3.averageSize - m3) ** 2 + (u3.averageSize - m3) ** 2) / m3;
        } catch {
          return 1 / 0;
        }
      }
      function m2(e4, t4) {
        for (var n3 = Math.round(t4.x); e4.get(n3, Math.round(t4.y)); ) n3--;
        for (var r3 = Math.round(t4.x); e4.get(r3, Math.round(t4.y)); ) r3++;
        for (var i3 = (n3 + r3) / 2, a3 = Math.round(t4.y); e4.get(Math.round(i3), a3); ) a3--;
        for (var o3 = Math.round(t4.y); e4.get(Math.round(i3), o3); ) o3++;
        return { x: i3, y: (a3 + o3) / 2 };
      }
      function h2(e4) {
        for (var t4 = [], n3 = [], o3 = [], l3 = [], u3 = function(r3) {
          for (var c3 = 0, u4 = false, d4 = [0, 0, 0, 0, 0], f4 = function(t5) {
            var o4 = e4.get(t5, r3);
            if (o4 === u4) c3++;
            else {
              d4 = [d4[1], d4[2], d4[3], d4[4], c3], c3 = 1, u4 = o4;
              var f5 = s2(d4) / 7, p4 = Math.abs(d4[0] - f5) < f5 && Math.abs(d4[1] - f5) < f5 && Math.abs(d4[2] - 3 * f5) < 3 * f5 && Math.abs(d4[3] - f5) < f5 && Math.abs(d4[4] - f5) < f5 && !o4, m3 = s2(d4.slice(-3)) / 3, h4 = Math.abs(d4[2] - m3) < m3 && Math.abs(d4[3] - m3) < m3 && Math.abs(d4[4] - m3) < m3 && o4;
              if (p4) {
                var g3 = t5 - d4[3] - d4[4], _3 = g3 - d4[2], v3 = { startX: _3, endX: g3, y: r3 }, y3 = n3.filter(function(e5) {
                  return _3 >= e5.bottom.startX && _3 <= e5.bottom.endX || g3 >= e5.bottom.startX && _3 <= e5.bottom.endX || _3 <= e5.bottom.startX && g3 >= e5.bottom.endX && d4[2] / (e5.bottom.endX - e5.bottom.startX) < a2 && d4[2] / (e5.bottom.endX - e5.bottom.startX) > i2;
                });
                y3.length > 0 ? y3[0].bottom = v3 : n3.push({ top: v3, bottom: v3 });
              }
              if (h4) {
                var b3 = t5 - d4[4], x3 = b3 - d4[3], v3 = { startX: x3, y: r3, endX: b3 }, y3 = l3.filter(function(e5) {
                  return x3 >= e5.bottom.startX && x3 <= e5.bottom.endX || b3 >= e5.bottom.startX && x3 <= e5.bottom.endX || x3 <= e5.bottom.startX && b3 >= e5.bottom.endX && d4[2] / (e5.bottom.endX - e5.bottom.startX) < a2 && d4[2] / (e5.bottom.endX - e5.bottom.startX) > i2;
                });
                y3.length > 0 ? y3[0].bottom = v3 : l3.push({ top: v3, bottom: v3 });
              }
            }
          }, p3 = -1; p3 <= e4.width; p3++) f4(p3);
          t4.push.apply(t4, n3.filter(function(e5) {
            return e5.bottom.y !== r3 && e5.bottom.y - e5.top.y >= 2;
          })), n3 = n3.filter(function(e5) {
            return e5.bottom.y === r3;
          }), o3.push.apply(o3, l3.filter(function(e5) {
            return e5.bottom.y !== r3;
          })), l3 = l3.filter(function(e5) {
            return e5.bottom.y === r3;
          });
        }, d3 = 0; d3 <= e4.height; d3++) u3(d3);
        t4.push.apply(t4, n3.filter(function(e5) {
          return e5.bottom.y - e5.top.y >= 2;
        })), o3.push.apply(o3, l3);
        var f3 = t4.filter(function(e5) {
          return e5.bottom.y - e5.top.y >= 2;
        }).map(function(t5) {
          var n4 = (t5.top.startX + t5.top.endX + t5.bottom.startX + t5.bottom.endX) / 4, r3 = (t5.top.y + t5.bottom.y + 1) / 2;
          if (e4.get(Math.round(n4), Math.round(r3))) {
            var i3 = [t5.top.endX - t5.top.startX, t5.bottom.endX - t5.bottom.startX, t5.bottom.y - t5.top.y + 1], a3 = s2(i3) / i3.length;
            return { score: p2({ x: Math.round(n4), y: Math.round(r3) }, [1, 1, 3, 1, 1], e4), x: n4, y: r3, size: a3 };
          }
        }).filter(function(e5) {
          return !!e5;
        }).sort(function(e5, t5) {
          return e5.score - t5.score;
        }).map(function(e5, t5, n4) {
          if (t5 > r2) return null;
          var i3 = n4.filter(function(e6, n5) {
            return t5 !== n5;
          }).map(function(t6) {
            return { x: t6.x, y: t6.y, score: t6.score + (t6.size - e5.size) ** 2 / e5.size, size: t6.size };
          }).sort(function(e6, t6) {
            return e6.score - t6.score;
          });
          if (i3.length < 2) return null;
          var a3 = e5.score + i3[0].score + i3[1].score;
          return { points: [e5].concat(i3.slice(0, 2)), score: a3 };
        }).filter(function(e5) {
          return !!e5;
        }).sort(function(e5, t5) {
          return e5.score - t5.score;
        });
        if (f3.length === 0) return null;
        var h3 = c2(f3[0].points[0], f3[0].points[1], f3[0].points[2]), _2 = h3.topRight, v2 = h3.topLeft, y2 = h3.bottomLeft, b2 = g2(e4, o3, _2, v2, y2), x2 = [];
        b2 && x2.push({ alignmentPattern: { x: b2.alignmentPattern.x, y: b2.alignmentPattern.y }, bottomLeft: { x: y2.x, y: y2.y }, dimension: b2.dimension, topLeft: { x: v2.x, y: v2.y }, topRight: { x: _2.x, y: _2.y } });
        var S2 = m2(e4, _2), C2 = m2(e4, v2), w2 = m2(e4, y2), T2 = g2(e4, o3, S2, C2, w2);
        return T2 && x2.push({ alignmentPattern: { x: T2.alignmentPattern.x, y: T2.alignmentPattern.y }, bottomLeft: { x: w2.x, y: w2.y }, topLeft: { x: C2.x, y: C2.y }, topRight: { x: S2.x, y: S2.y }, dimension: T2.dimension }), x2.length === 0 ? null : x2;
      }
      t3.locate = h2;
      function g2(e4, t4, n3, r3, i3) {
        var a3, c3, u3;
        try {
          a3 = l2(r3, n3, i3, e4), c3 = a3.dimension, u3 = a3.moduleSize;
        } catch {
          return null;
        }
        var d3 = { x: n3.x - r3.x + i3.x, y: n3.y - r3.y + i3.y }, f3 = (o2(r3, i3) + o2(r3, n3)) / 2 / u3, m3 = 1 - 3 / f3, h3 = { x: r3.x + m3 * (d3.x - r3.x), y: r3.y + m3 * (d3.y - r3.y) }, g3 = t4.map(function(t5) {
          var n4 = (t5.top.startX + t5.top.endX + t5.bottom.startX + t5.bottom.endX) / 4, r4 = (t5.top.y + t5.bottom.y + 1) / 2;
          if (e4.get(Math.floor(n4), Math.floor(r4))) {
            var i4 = [t5.top.endX - t5.top.startX, t5.bottom.endX - t5.bottom.startX, t5.bottom.y - t5.top.y + 1];
            return s2(i4) / i4.length, { x: n4, y: r4, score: p2({ x: Math.floor(n4), y: Math.floor(r4) }, [1, 1, 1], e4) + o2({ x: n4, y: r4 }, h3) };
          }
        }).filter(function(e5) {
          return !!e5;
        }).sort(function(e5, t5) {
          return e5.score - t5.score;
        });
        return { alignmentPattern: f3 >= 15 && g3.length ? g3[0] : h3, dimension: c3 };
      }
    })]).default;
  });
}))(), 1), St = /did:[a-z0-9]+:[A-Za-z0-9._%:-]+/;
function Ct(e2) {
  let t2 = St.exec(e2);
  if (!t2) return;
  let n2 = t2[0].replace(/[.:]+$/, ``);
  return /^did:[a-z0-9]+:[^:]/.test(n2) ? n2 : void 0;
}
function wt(e2) {
  let t2 = (0, xt.default)(e2.data, e2.width, e2.height, { inversionAttempts: `attemptBoth` });
  return t2 ? Ct(t2.data) : void 0;
}
var Tt = [1, 0.5, 0.25, 2], Et = 16e6;
function Dt(e2, t2, n2) {
  if (!(t2 > 0 && n2 > 0)) return;
  let r2 = document.createElement(`canvas`), i2 = r2.getContext(`2d`, { willReadFrequently: true });
  if (i2) for (let a2 of Tt) {
    let o2 = Math.max(1, Math.round(t2 * a2)), s2 = Math.max(1, Math.round(n2 * a2));
    if (o2 * s2 > Et) continue;
    r2.width = o2, r2.height = s2, i2.drawImage(e2, 0, 0, o2, s2);
    let c2 = wt(i2.getImageData(0, 0, o2, s2));
    if (c2) return c2;
  }
}
async function Ot(e2) {
  let t2 = await new Promise((t3, n2) => {
    let r2 = new Image();
    r2.onload = () => t3(r2), r2.onerror = () => n2(Error(`The image couldn't be read.`)), r2.src = e2;
  });
  return Dt(t2, t2.naturalWidth, t2.naturalHeight);
}
async function kt(e2) {
  let t2 = URL.createObjectURL(e2);
  try {
    return await Ot(t2);
  } finally {
    URL.revokeObjectURL(t2);
  }
}
async function At(e2) {
  for (let t3 of Array.from(e2.items ?? [])) {
    if (t3.kind !== `file` || !t3.type.startsWith(`image/`)) continue;
    let e3 = t3.getAsFile();
    if (!e3) continue;
    let n2 = await kt(e3);
    if (n2) return n2;
  }
  let t2 = e2.getData(`text/plain`) || e2.getData(`text`);
  return t2 ? Ct(t2) : void 0;
}
async function jt(e2) {
  return Ot(e2 === void 0 ? await chrome.tabs.captureVisibleTab({ format: `png` }) : await chrome.tabs.captureVisibleTab(e2, { format: `png` }));
}
var Mt = 300, Nt = 120, Pt = { x: 62, y: 60, r: 40 }, Ft = { x: 238, y: 60, r: 18 }, X = { cx: 150, cy: 60, rx: 136, ry: 50 }, It = Math.PI * (3 * (X.rx + X.ry) - Math.sqrt((3 * X.rx + X.ry) * (X.rx + 3 * X.ry)));
function Lt({ state: e2, host: t2, code: n2 }) {
  let i2 = (0, B.useRef)(null), a2 = (0, B.useRef)(null), o2 = typeof matchMedia == `function` && matchMedia(`(prefers-reduced-motion: reduce)`).matches;
  (0, B.useEffect)(() => {
    if (i2.current) return a2.current = r(i2.current, { interactive: false }), () => a2.current?.destroy();
  }, []), (0, B.useEffect)(() => {
    let t3 = e2 === `agreed` ? 1 : e2 === `offered` ? 0.6 : 0;
    a2.current?.setLayers({ field: { level: 1 }, sword: { level: 1 }, mage: { level: 1 }, routes: { level: e2 === `apart` || e2 === `none` ? 0.3 : 0.6 }, core: { level: t3, ...e2 === `offered` ? { next: true } : {} } });
  }, [e2]);
  let s2 = e2 === `agreed` ? 1 : e2 === `offered` ? 0.97 : e2 === `none` ? 0.35 : 0.55, c2 = e2 === `agreed` ? f.ok : e2 === `offered` ? f.accent : f.line, l2 = o2 ? `none` : `stroke-dashoffset 900ms ease, stroke 600ms ease, opacity 600ms ease`, u2 = (t2 ?? `?`).replace(/^www\./, ``).charAt(0).toUpperCase() || `?`, d2 = e2 === `agreed` ? `An agreement stands with ${t2 ?? `this community`}${n2 ? ` under ${n2}` : ``}.` : e2 === `offered` ? `${t2 ?? `This community`} takes your terms${n2 ? ` (${n2})` : ``}.` : e2 === `none` ? `${t2 ?? `This site`} publishes no terms.` : `No agreement with ${t2 ?? `this community`} yet.`;
  return (0, V.jsxs)(`figure`, { "data-testid": `handshake`, "data-state": e2, style: { margin: 0, position: `relative`, width: Mt, height: Nt, maxWidth: `100%`, justifySelf: `center` }, "aria-label": d2, role: `img`, children: [(0, V.jsxs)(`svg`, { width: Mt, height: Nt, viewBox: `0 0 ${Mt} ${Nt}`, style: { position: `absolute`, inset: 0, overflow: `visible` }, "aria-hidden": true, children: [(0, V.jsx)(`ellipse`, { cx: X.cx, cy: X.cy, rx: X.rx, ry: X.ry, fill: `none`, stroke: c2, strokeWidth: e2 === `agreed` ? 2 : 1.5, strokeDasharray: `${It}`, strokeDashoffset: `${It * (1 - s2)}`, strokeLinecap: `round`, style: { transition: l2, opacity: e2 === `none` ? 0.4 : 0.9 }, transform: `rotate(-20 ${X.cx} ${X.cy})` }), (0, V.jsx)(`circle`, { cx: Ft.x, cy: Ft.y, r: Ft.r, fill: `none`, stroke: e2 === `none` ? f.line : f.accent, strokeWidth: 1.5, style: { transition: l2 } }), (0, V.jsx)(`text`, { x: Ft.x, y: Ft.y + 5, textAnchor: `middle`, fontSize: `14`, fontWeight: `600`, fill: f.text, style: { fontFamily: `inherit` }, children: u2 }), (0, V.jsx)(`text`, { x: X.cx, y: X.cy + 8, textAnchor: `middle`, fontSize: `22`, style: { transition: l2, opacity: +(e2 === `offered` || e2 === `agreed`) }, children: `\u{1F91D}` }), e2 === `agreed` ? (0, V.jsx)(`text`, { x: X.cx + 18, y: X.cy - 6, fontSize: `11`, fill: f.ok, style: { transition: l2 }, children: `\u2713` }) : null] }), (0, V.jsx)(`canvas`, { ref: i2, "aria-hidden": true, style: { position: `absolute`, left: Pt.x - Pt.r, top: Pt.y - Pt.r, width: Pt.r * 2, height: Pt.r * 2, display: `block` } }), (0, V.jsx)(`figcaption`, { style: { position: `absolute`, left: 0, right: 0, bottom: -4, textAlign: `center`, fontSize: k.xs, color: f.muted }, "data-testid": `handshake-caption`, children: d2 })] });
}
var Rt = [`/.well-known/myterms-configuration`, `/myterms/configuration.json`];
async function zt(e2) {
  let t2 = `https://${e2}`;
  if (!await E(t2).catch(() => false)) return { status: `unreachable`, origin: t2 };
  for (let e3 of Rt) try {
    return { status: `takes`, terms: await A(`${t2}${e3}`, { timeoutMs: 6e3 }) };
  } catch {
  }
  return { status: `none` };
}
var Bt = 200;
async function Vt() {
  try {
    let e2 = await chrome.windows.getLastFocused({ windowTypes: [`normal`] });
    if (e2?.id === void 0) return;
    let [t2] = await chrome.tabs.query({ active: true, windowId: e2.id });
    if (!t2?.url) return;
    let n2 = new URL(t2.url);
    return n2.protocol === `https:` ? n2.host.toLowerCase() : void 0;
  } catch {
    return;
  }
}
var Ht = { agreed: `agreed`, proffered: `proffered, not yet decided`, declined: `declined` };
function Ut(e2) {
  try {
    return new Date(e2).toISOString().slice(0, 10);
  } catch {
    return ``;
  }
}
function Wt({ pageHost: e2 = Vt, readAgreements: t2 = ie, readSiteTerms: n2 = zt, readStanding: r2 = async () => j((await fe()).myTermsOffers), allowSite: i2 = (e3) => g(e3), openConsole: a2 = () => void chrome.tabs.create({ url: chrome.runtime.getURL(`manager.html#agreements`) }) } = {}) {
  let [o2, s2] = (0, B.useState)(``), [c2, l2] = (0, B.useState)(false), [p2, h2] = (0, B.useState)(null), [_2, v2] = (0, B.useState)(`off`), [y2, b2] = (0, B.useState)(), [x2, S2] = (0, B.useState)([]), [C2, w2] = (0, B.useState)(), [T2, E2] = (0, B.useState)([]), D2 = (0, B.useRef)(null), O2 = (0, B.useRef)(void 0), A2 = Ct(o2);
  (0, B.useEffect)(() => {
    let i3 = true;
    return Promise.all([e2().catch(() => void 0), t2().catch(() => []), r2().catch(() => [])]).then(async ([e3, t3, r3]) => {
      if (i3 && (b2(e3), S2(t3), E2(j(r3)), e3)) {
        let t4 = await n2(e3).catch(() => void 0);
        i3 && t4 && w2(t4);
      }
    }), () => {
      i3 = false;
    };
  }, []);
  let te2 = ae(x2, { ...y2 ? { host: y2 } : {}, ...A2 ? { counterparty: A2 } : {} }), ne2 = async () => {
    y2 && C2?.status === `unreachable` && await i2(C2.origin).catch(() => false) && w2(await n2(y2).catch(() => void 0));
  }, M2 = C2?.status === `takes` ? C2.terms.accepts : [], N2 = T2.find((e3) => M2.includes(e3)), re2 = N2 ?? (C2?.status === `takes` ? C2.terms.counterOffer ?? M2[0] : void 0), oe2 = te2.find((e3) => e3.status === `agreed`), se2 = oe2 ? `agreed` : N2 ? `offered` : C2?.status === `none` ? `none` : `apart`, P2 = y2 ?? (A2 ? `this community` : void 0), ce2 = () => {
    O2.current?.getTracks().forEach((e3) => e3.stop()), O2.current = void 0, v2(`off`);
  };
  (0, B.useEffect)(() => ce2, []);
  let F2 = async (e3, t3) => {
    h2(null);
    let n3 = await chrome.runtime.sendMessage({ type: pe, did: e3, source: t3 });
    return n3?.ok ? (ce2(), window.close(), true) : (h2(n3?.error ?? `The wallet did not answer.`), false);
  }, le2 = async () => {
    l2(true), h2(null);
    try {
      let e3 = await jt((await chrome.windows.getLastFocused({ windowTypes: [`normal`] }).catch(() => void 0))?.id);
      if (!e3) {
        h2(`No community code is visible on that page. Scroll it into view and try again, or paste the DID.`);
        return;
      }
      await F2(e3, `page`);
    } catch (e3) {
      h2(`Couldn't read the page: ${e3 instanceof Error ? e3.message : String(e3)}`);
    } finally {
      l2(false);
    }
  }, ue2 = async () => {
    h2(null), v2(`starting`);
    let e3;
    try {
      e3 = await navigator.mediaDevices.getUserMedia({ video: { facingMode: `environment` }, audio: false });
    } catch (e4) {
      v2(`off`), h2(e4?.name === `NotAllowedError` ? `Camera access was declined. Drop an image of the code here instead, or paste the DID.` : `No camera could be opened. Drop an image of the code here instead, or paste the DID.`);
      return;
    }
    O2.current = e3, v2(`on`);
    let t3 = D2.current, n3 = document.createElement(`canvas`), r3 = n3.getContext(`2d`, { willReadFrequently: true });
    if (!t3 || !r3) return;
    t3.srcObject = e3, await t3.play().catch(() => void 0);
    let i3 = setInterval(() => {
      if (O2.current !== e3) {
        clearInterval(i3);
        return;
      }
      if (t3.readyState < 2 || t3.videoWidth === 0) return;
      n3.width = t3.videoWidth, n3.height = t3.videoHeight, r3.drawImage(t3, 0, 0);
      let a3 = wt(r3.getImageData(0, 0, n3.width, n3.height));
      a3 && (clearInterval(i3), F2(a3, `camera`).then((e4) => {
        e4 || ce2();
      }));
    }, Bt);
  }, de2 = async (e3) => {
    if (e3 && Array.from(e3.items ?? []).some((e4) => e4.kind === `file` && e4.type.startsWith(`image/`))) {
      l2(true), h2(null);
      try {
        let t3 = await At(e3);
        if (!t3) {
          h2(`No community code in that image.`);
          return;
        }
        await F2(t3, `image`);
      } finally {
        l2(false);
      }
    }
  };
  return (0, V.jsxs)(`div`, { onPaste: (e3) => void de2(e3.clipboardData), onDragOver: (e3) => e3.preventDefault(), onDrop: (e3) => {
    e3.preventDefault(), de2(e3.dataTransfer);
  }, style: { maxWidth: 520, margin: `0 auto`, padding: `18px 20px 24px`, display: `grid`, gap: 12, fontSize: k.base, color: f.text, minHeight: `100vh`, boxSizing: `border-box` }, children: [(0, V.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 9 }, children: [(0, V.jsx)(ee, {}), (0, V.jsx)(`strong`, { children: `Join a community` })] }), (y2 || A2) && (0, V.jsxs)(`section`, { "data-testid": `join-agreements`, style: { display: `grid`, gap: 10, justifyItems: `stretch` }, children: [(0, V.jsx)(Lt, { state: se2, ...P2 ? { host: P2 } : {}, ...oe2 ? { code: oe2.terms.code } : N2 ? { code: N2 } : {} }), (0, V.jsxs)(`div`, { style: { display: `grid`, gap: 4, fontSize: k.sm, marginTop: 10 }, children: [y2 && C2 ? (0, V.jsx)(`p`, { style: { margin: 0, color: f.muted }, "data-testid": `join-site-terms`, children: C2.status === `takes` ? (0, V.jsxs)(V.Fragment, { children: [y2, ` takes `, M2.length ? M2.join(`, `) : `nothing this wallet knows`, N2 ? ` \xB7 yours: ${N2}` : T2.length ? ` \xB7 none of yours (${T2.join(`, `)})${re2 ? ` \xB7 it proposes ${re2}` : ``}` : ` \xB7 you present none yet${re2 ? ` \xB7 it proposes ${re2}` : ``}`] }) : C2.status === `none` ? (0, V.jsxs)(V.Fragment, { children: [y2, ` publishes no terms`] }) : (0, V.jsxs)(V.Fragment, { children: [y2, `: not readable yet`, ` `, (0, V.jsx)(`button`, { type: `button`, style: d(`quiet`), onClick: () => void ne2(), "data-testid": `join-site-allow`, children: `Allow and read its terms` })] }) }) : null, (0, V.jsxs)(`div`, { style: { color: f.muted }, children: [`With `, y2 ?? `this community`, y2 && A2 ? ` and the DID above` : ``, `:`] }), te2.length === 0 ? (0, V.jsx)(`span`, { "data-testid": `join-agreements-none`, style: { color: f.muted }, children: `none yet` }) : (0, V.jsx)(`ul`, { style: { margin: 0, paddingLeft: 18, display: `grid`, gap: 3 }, children: te2.map((e3) => (0, V.jsxs)(`li`, { "data-testid": `join-agreement`, children: [(0, V.jsx)(`code`, { children: e3.terms.code }), ` \xB7 `, Ht[e3.status], ` \xB7 `, Ut(e3.reached.at), ` \xB7 as`, ` `, (0, V.jsx)(`span`, { style: { ...u, fontSize: k.xs, overflowWrap: `anywhere` }, children: e3.holder })] }, e3.id)) }), (0, V.jsx)(`div`, { children: (0, V.jsx)(`button`, { type: `button`, style: d(`quiet`), onClick: a2, "data-testid": `join-agreements-open`, children: `Open Agreements` }) })] })] }), (0, V.jsxs)(`details`, { style: { color: f.muted, fontSize: k.sm }, children: [(0, V.jsx)(`summary`, { style: { cursor: `pointer` }, children: `What this does` }), (0, V.jsx)(`p`, { style: { margin: `6px 0 0` }, children: `Give the community's DID: paste it, read it off the code on the page you were on, or scan the code. The wallet reads its DID document, what it asks to join, and the terms it takes; nothing is sent until you say so in the next window. Agreements already made with this site are shown above; the Star and the site's mark close into one ring when terms meet.` })] }), (0, V.jsxs)(`form`, { style: { display: `flex`, gap: 6, minWidth: 0 }, onSubmit: (e3) => {
    e3.preventDefault(), A2 && F2(A2, `pasted`);
  }, children: [(0, V.jsx)(`input`, { type: `text`, "data-testid": `join-did`, placeholder: `did:webvh:\u2026`, value: o2, onChange: (e3) => s2(e3.target.value), spellCheck: false, autoComplete: `off`, autoFocus: true, style: { ...u, flex: 1, padding: `8px 10px`, minWidth: 0 } }), (0, V.jsx)(`button`, { type: `submit`, style: d(`primary`), disabled: c2 || !A2, "data-testid": `join-paste`, children: `Join` })] }), (0, V.jsxs)(`div`, { style: { display: `flex`, gap: 8, flexWrap: `wrap` }, children: [(0, V.jsx)(`button`, { type: `button`, style: d(), disabled: c2, onClick: () => void le2(), "data-testid": `join-page`, children: c2 ? `Reading\u2026` : `Read the code on the page` }), _2 === `off` ? (0, V.jsx)(`button`, { type: `button`, style: d(), disabled: c2, onClick: () => void ue2(), "data-testid": `join-camera`, children: `Use the camera` }) : (0, V.jsx)(`button`, { type: `button`, style: d(`quiet`), onClick: ce2, children: `Stop the camera` })] }), _2 !== `off` && (0, V.jsx)(`video`, { ref: D2, muted: true, playsInline: true, style: { width: `100%`, aspectRatio: `4 / 3`, background: `#000`, borderRadius: 8, objectFit: `cover` } }), _2 === `on` && (0, V.jsx)(`p`, { style: { margin: 0, color: f.muted }, children: `Point the camera at the community's code.` }), (0, V.jsxs)(`div`, { style: { ...m, display: `grid`, gap: 8 }, children: [(0, V.jsx)(`span`, { style: { color: f.muted, fontSize: k.sm }, children: `Or an image of the code: drop, paste, or choose.` }), (0, V.jsx)(`input`, { type: `file`, accept: `image/*`, onChange: (e3) => {
    let t3 = e3.target.files?.[0];
    t3 && (h2(null), kt(t3).then((e4) => {
      e4 ? F2(e4, `image`) : h2(`No community code in that image.`);
    }));
  } })] }), p2 && (0, V.jsx)(`p`, { style: { margin: 0, color: f.danger }, "data-testid": `join-note`, children: p2 }), (0, V.jsx)(`div`, { children: (0, V.jsx)(`button`, { type: `button`, style: d(`quiet`), onClick: () => window.close(), children: `Cancel` }) })] });
}
var Z = new URLSearchParams(window.location.search), Gt = Z.get(`cid`) ?? ``, Kt = Z.get(`kind`) === `task`, qt = Z.get(`kind`) === `disclosure`, Jt = Z.get(`kind`) === `approver`, Yt = Z.get(`kind`) === `room`, Xt = Z.get(`kind`) === `directory`, Zt = Z.get(`kind`) === `sign-in` ? Z.get(`flow`) : null, Qt = Z.get(`approver`) === `1`, $t = Z.get(`noRemember`) === `1`, en = Z.get(`origin`) ?? ``, tn = Z.get(`rpDid`), nn = Z.get(`holder`), rn = Z.get(`action`), an = Z.get(`stepUp`) === `1`, on = Z.get(`reason`), Q = Z.get(`chooseProfile`) === `1`, sn = Z.get(`allowHolder`) === `1`, cn = Z.get(`changedFrom`), ln = Z.get(`changedFromBase`), un = Z.get(`pinned`) === `1`, dn = Z.get(`pinnedBase`), fn = Z.get(`sessionKey`), pn = $e(Gt);
function mn(e2, t2 = false, n2, r2) {
  pn({ approved: e2, remember: t2, ...n2 ? { prfOutputB64u: n2 } : {}, ...r2 ? { selectedDid: r2 } : {} });
}
function hn(e2) {
  return p(e2).map((e3) => e3.text).join(``);
}
function gn(e2) {
  try {
    return new URL(e2).hostname;
  } catch {
    return;
  }
}
var $ = { bg: `var(--w-raised)`, card: `var(--w-surface)`, border: `var(--w-line)`, text: `var(--w-text)`, textMuted: `var(--w-faint)`, textSubtle: `var(--w-muted)`, primary: `var(--w-accent)`, primaryHover: `var(--w-accent)`, ok: `var(--w-ok)`, okBg: `var(--w-ok-soft)`, warn: `var(--w-warn)`, warnBg: `var(--w-warn-soft)`, danger: `var(--w-danger)`, dangerBg: `var(--w-danger-soft)`, mono: `ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace` }, _n = { worker: { label: `WORKER`, tagline: `Your agent is sending a request on your behalf`, icon: `\u{1F916}`, bannerBg: `var(--w-accent-soft)`, bannerFg: `var(--w-accent)`, accent: $.primary, accentHover: $.primaryHover, pageTint: `var(--w-accent-wash)` }, approver: { label: `APPROVER`, tagline: `You are authorizing a change \u2014 read it before you approve`, icon: `\u{1F6E1}\uFE0F`, bannerBg: `var(--w-danger-soft)`, bannerFg: `var(--w-danger)`, accent: $.danger, accentHover: `var(--w-danger)`, pageTint: `var(--w-danger-wash)` } };
function vn({ mode: e2, pad: t2 }) {
  let n2 = _n[e2];
  return (0, V.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 10, background: n2.bannerBg, color: n2.bannerFg, padding: `11px 16px`, margin: `-${t2}px -${t2}px 16px`, borderBottom: `3px solid ${n2.accent}` }, children: [(0, V.jsx)(`span`, { style: { fontSize: 20, lineHeight: 1 }, "aria-hidden": true, children: n2.icon }), (0, V.jsxs)(`div`, { style: { display: `grid`, gap: 1 }, children: [(0, V.jsxs)(`span`, { style: { fontSize: 12, fontWeight: 800, letterSpacing: 1.2 }, children: [n2.label, ` MODE`] }), (0, V.jsx)(`span`, { style: { fontSize: 11, opacity: 0.85 }, children: n2.tagline })] })] });
}
function yn({ tone: e2, children: t2 }) {
  let n2 = { ok: { fg: $.ok, bg: $.okBg, border: `var(--w-ok)` }, warn: { fg: $.warn, bg: $.warnBg, border: `var(--w-warn)` }, danger: { fg: $.danger, bg: $.dangerBg, border: `var(--w-danger)` }, neutral: { fg: $.textMuted, bg: `var(--w-raised)`, border: `var(--w-line)` } }[e2];
  return (0, V.jsx)(`span`, { style: { display: `inline-flex`, alignItems: `center`, gap: 4, padding: `2px 8px`, borderRadius: 10, fontSize: 11, fontWeight: 600, background: n2.bg, color: n2.fg, border: `1px solid ${n2.border}`, lineHeight: 1.4, whiteSpace: `nowrap` }, children: t2 });
}
function bn({ label: e2, value: t2, rightSlot: n2 }) {
  let [r2, i2] = (0, B.useState)(false), [a2, s2] = (0, B.useState)(false), c2 = t2.length > 48;
  async function l2() {
    try {
      await navigator.clipboard.writeText(t2), s2(true), window.setTimeout(() => s2(false), 1200);
    } catch {
    }
  }
  return (0, V.jsxs)(`div`, { style: { marginBottom: 12 }, children: [(0, V.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, justifyContent: `space-between`, marginBottom: 4, gap: 8 }, children: [(0, V.jsx)(`span`, { style: { color: $.textMuted, fontSize: 11, fontWeight: 600, letterSpacing: 0.3, textTransform: `uppercase` }, children: e2 }), n2] }), (0, V.jsx)(`div`, { style: { fontFamily: $.mono, fontSize: 11.5, lineHeight: 1.5, background: `var(--w-raised)`, border: `1px solid ${$.border}`, borderRadius: 6, padding: `8px 10px`, wordBreak: `break-all`, color: $.text }, title: t2, children: (0, V.jsx)(xn, { parts: r2 || !c2 ? o(t2) : p(t2) }) }), (0, V.jsxs)(`div`, { style: { display: `flex`, gap: 12, marginTop: 4 }, children: [c2 && (0, V.jsx)(`button`, { type: `button`, onClick: () => i2((e3) => !e3), style: Sn, children: r2 ? `Show less` : `Show full` }), (0, V.jsx)(`button`, { type: `button`, onClick: l2, style: Sn, children: a2 ? `Copied \u2713` : `Copy` }), (0, V.jsx)(C, { value: t2 })] })] });
}
function xn({ parts: e2 }) {
  let t2 = { method: { color: $.textMuted }, opaque: { color: $.textMuted }, host: { color: $.text, fontWeight: 700 }, path: { color: $.textMuted } };
  return (0, V.jsx)(V.Fragment, { children: e2.map((e3, n2) => (0, V.jsx)(`span`, { style: t2[e3.role], children: e3.text }, n2)) });
}
var Sn = { background: `none`, border: `none`, padding: 0, color: $.primary, cursor: `pointer`, fontSize: 11, fontWeight: 600 };
function Cn({ state: e2 }) {
  return e2.kind === `pending` ? (0, V.jsx)(yn, { tone: `neutral`, children: `Verifying\u2026` }) : e2.kind === `error` ? (0, V.jsx)(yn, { tone: `danger`, children: `Verification failed` }) : (0, V.jsx)(yn, { tone: `ok`, children: `Resolved \u2713` });
}
function wn({ state: e2 }) {
  if (e2.kind === `pending`) return (0, V.jsx)(`p`, { style: { margin: 0, fontSize: 11.5, color: $.textMuted }, children: `Resolving the relying-party DID and verifying its log\u2026` });
  if (e2.kind === `error`) return (0, V.jsxs)(`p`, { style: { margin: 0, fontSize: 11.5, color: $.danger }, children: [`Could not resolve this DID: `, e2.message] });
  let { result: t2 } = e2, n2 = [];
  return n2.push((0, V.jsxs)(`span`, { style: { color: $.textMuted }, children: [`Method: `, (0, V.jsxs)(`strong`, { style: { color: $.text }, children: [`did:`, t2.method] }), t2.method === `webvh` && ` \u2014 log chain + proofs verified`, (t2.method === `peer` || t2.method === `key`) && ` \u2014 self-certifying identifier`] }, `method`)), t2.domain && n2.push((0, V.jsxs)(`span`, { style: { color: $.textMuted }, children: [`Domain: `, (0, V.jsx)(`strong`, { style: { color: $.text, fontFamily: $.mono }, children: t2.domain })] }, `domain`)), (0, V.jsx)(`div`, { style: { display: `grid`, gap: 4, fontSize: 11.5 }, children: n2 });
}
function Tn() {
  let [e2, t2] = (0, B.useState)({ kind: `pending` }), [n2, r2] = (0, B.useState)(false), [i2, a2] = (0, B.useState)(null), [o2, c2] = (0, B.useState)(null), [l2, u2] = (0, B.useState)(``), d2 = gn(en), f2 = e2.kind === `ok` ? O(e2.result.alsoKnownAs).map(s)[0] : void 0;
  (0, B.useEffect)(() => {
    if (!tn) return;
    let e3 = false;
    return chrome.runtime.sendMessage({ type: le, did: tn }).then((n3) => {
      if (!e3) {
        if (!n3.ok) {
          t2({ kind: `error`, message: n3.error });
          return;
        }
        if (!n3.result.resolved) {
          t2({ kind: `error`, message: n3.result.error ?? `Unknown resolution error` });
          return;
        }
        t2({ kind: `ok`, result: n3.result });
      }
    }).catch((n3) => {
      e3 || t2({ kind: `error`, message: n3 instanceof Error ? n3.message : String(n3) });
    }), () => {
      e3 = true;
    };
  }, []), (0, B.useEffect)(() => {
    if (!Q) return;
    let e3 = false;
    return chrome.runtime.sendMessage({ type: de }).then((t3) => {
      if (!e3) {
        if (!t3.ok) {
          c2(t3.error);
          return;
        }
        a2(t3.result.dids), t3.result.dids.length === 1 && u2(t3.result.dids[0].did);
      }
    }).catch((t3) => {
      e3 || c2(t3 instanceof Error ? t3.message : String(t3));
    }), () => {
      e3 = true;
    };
  }, []);
  let p2 = !!rn, m2 = an ? `Step-up approval request` : Q ? `First sign-in at this site` : p2 ? `Confirmation request` : `Sign-in request`, h2 = Q ? d2 ? (0, V.jsxs)(V.Fragment, { children: [`You have not signed in to`, ` `, (0, V.jsx)(`strong`, { style: { fontFamily: $.mono }, children: d2 }), ` before. Choose the identity it should know you as \u2014 the wallet will remember it for this site.`] }) : (0, V.jsx)(V.Fragment, { children: `An unknown page is asking you to sign in for the first time.` }) : an ? d2 ? (0, V.jsxs)(V.Fragment, { children: [(0, V.jsx)(`strong`, { style: { fontFamily: $.mono }, children: d2 }), ` is asking you to re-approve your session at a higher assurance level.`] }) : (0, V.jsx)(V.Fragment, { children: `An unknown page is requesting a session step-up.` }) : p2 ? (0, V.jsxs)(V.Fragment, { children: [d2 ? (0, V.jsx)(`strong`, { style: { fontFamily: $.mono }, children: d2 }) : `An unknown page`, ` `, `is asking you to confirm: `, (0, V.jsx)(`strong`, { children: rn })] }) : d2 ? (0, V.jsxs)(V.Fragment, { children: [(0, V.jsx)(`strong`, { style: { fontFamily: $.mono }, children: d2 }), ` wants you to sign in.`] }) : (0, V.jsx)(V.Fragment, { children: `An unknown page is requesting sign-in.` });
  return (0, V.jsxs)(`div`, { style: { padding: 16, color: $.text, background: _n.worker.pageTint, minHeight: `100vh` }, children: [(0, V.jsx)(vn, { mode: `worker`, pad: 16 }), (0, V.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, justifyContent: `space-between`, marginBottom: 8 }, children: [(0, V.jsx)(`div`, { style: { fontSize: 11, fontWeight: 700, color: $.textSubtle, letterSpacing: 0.5, textTransform: `uppercase` }, children: `VTA Wallet` }), (0, V.jsx)(yn, { tone: `neutral`, children: p2 && !Q ? `Inbound` : `Outbound` })] }), (0, V.jsx)(`h1`, { style: { fontSize: 18, margin: `0 0 4px`, fontWeight: 700 }, children: m2 }), (0, V.jsx)(`p`, { style: { margin: `0 0 14px`, color: $.textMuted, fontSize: 13 }, children: h2 }), cn && (0, V.jsxs)(`div`, { role: `alert`, style: { border: `1px solid var(--w-danger)`, background: $.dangerBg, color: `var(--w-danger)`, padding: 12, margin: `0 0 14px`, borderRadius: 8 }, children: [(0, V.jsx)(`strong`, { style: { display: `block`, marginBottom: 4 }, children: `\u26A0 Relying-party identity changed` }), (0, V.jsx)(`div`, { style: { marginBottom: 6, fontSize: 12 }, children: `This site previously asked you to sign in to a different RP. Verify the new RP is correct before approving.` }), (0, V.jsx)(`div`, { style: { color: $.textMuted, fontSize: 11, marginBottom: 2 }, children: `Previously:` }), (0, V.jsx)(`div`, { style: { wordBreak: `break-all`, fontSize: 11, fontFamily: $.mono }, children: cn })] }), ln && (0, V.jsxs)(`div`, { role: `alert`, style: { border: `1px solid var(--w-danger)`, background: $.dangerBg, color: `var(--w-danger)`, padding: 12, margin: `0 0 14px`, borderRadius: 8 }, children: [(0, V.jsx)(`strong`, { style: { display: `block`, marginBottom: 4 }, children: `\u26A0 Relying-party address changed` }), (0, V.jsx)(`div`, { style: { marginBottom: 6, fontSize: 12 }, children: `This site previously signed you in through a different address. Approving pins the new one: later step-ups from this site will go there.` }), (0, V.jsx)(`div`, { style: { color: $.textMuted, fontSize: 11, marginBottom: 2 }, children: `Previously:` }), (0, V.jsx)(`div`, { style: { wordBreak: `break-all`, fontSize: 11, fontFamily: $.mono }, children: ln })] }), un && tn && (0, V.jsxs)(`div`, { "data-testid": `pinned-pairing`, style: { background: $.card, border: `1px solid ${$.border}`, borderLeft: `3px solid ${$.primary}`, borderRadius: 10, padding: 12, marginBottom: 12, fontSize: 12 }, children: [(0, V.jsx)(`div`, { style: { color: $.textMuted, fontSize: 11, fontWeight: 600, letterSpacing: 0.3, textTransform: `uppercase`, marginBottom: 6 }, children: `Pinned relying party` }), (0, V.jsxs)(`div`, { style: { wordBreak: `break-all`, fontFamily: $.mono }, children: [en || `unknown page`, ` \u2194 `, tn] }), dn && (0, V.jsxs)(`div`, { style: { wordBreak: `break-all`, fontFamily: $.mono, marginTop: 4 }, children: [`via `, dn] }), (0, V.jsx)(`p`, { style: { margin: `6px 0 0`, fontSize: 11, color: $.textMuted }, children: `You confirmed this pairing when you signed in from this site. The wallet acts for this page only toward that relying party.` })] }), fn && (0, V.jsx)(et, { sessionKey: fn }), an && on && (0, V.jsxs)(`div`, { style: { background: $.card, border: `1px solid ${$.border}`, borderLeft: `3px solid ${$.primary}`, borderRadius: 10, padding: 14, marginBottom: 12 }, children: [(0, V.jsx)(`div`, { style: { color: $.textMuted, fontSize: 11, fontWeight: 600, letterSpacing: 0.3, textTransform: `uppercase`, marginBottom: 6 }, children: `Reason given by the relying party` }), (0, V.jsx)(`div`, { style: { fontSize: 13, lineHeight: 1.5, whiteSpace: `pre-wrap`, overflowWrap: `anywhere`, maxHeight: 150, overflowY: `auto` }, children: on.length > 600 ? `${on.slice(0, 600)}\u2026` : on }), (0, V.jsx)(`p`, { style: { margin: `8px 0 0`, fontSize: 11, color: $.textMuted }, children: `Signature-verified as written by the relying party below. It is their claim \u2014 approve only if it matches what you were doing.` })] }), tn && (0, V.jsxs)(`div`, { style: { background: $.card, border: `1px solid ${$.border}`, borderRadius: 10, padding: 14, marginBottom: 12 }, children: [f2 && (0, V.jsxs)(`div`, { style: { marginBottom: 10 }, children: [(0, V.jsx)(`div`, { style: { color: $.textMuted, fontSize: 11, fontWeight: 600, letterSpacing: 0.3, textTransform: `uppercase`, marginBottom: 4 }, children: `Agent name` }), (0, V.jsx)(`div`, { style: { fontFamily: $.mono, fontSize: 14, fontWeight: 700, color: $.ok, wordBreak: `break-all` }, children: f2 }), (0, V.jsx)(`div`, { style: { fontSize: 11, color: $.textMuted, marginTop: 2 }, children: `Confirmed by this DID's own document.` })] }), (0, V.jsx)(bn, { label: `Relying party`, value: tn, rightSlot: (0, V.jsx)(Cn, { state: e2 }) }), (0, V.jsx)(wn, { state: e2 })] }), Q && (0, V.jsxs)(`div`, { style: { background: $.card, border: `1px solid ${$.border}`, borderLeft: `3px solid ${$.primary}`, borderRadius: 10, padding: 14, marginBottom: 14 }, children: [(0, V.jsx)(`div`, { style: { color: $.textMuted, fontSize: 11, fontWeight: 600, letterSpacing: 0.3, textTransform: `uppercase`, marginBottom: 6 }, children: `Sign in as` }), o2 ? (0, V.jsxs)(`div`, { style: { fontSize: 12, color: $.danger }, children: [`Could not read your identities: `, o2] }) : i2 === null ? (0, V.jsx)(`div`, { style: { fontSize: 12, color: $.textMuted }, children: `Loading your identities\u2026` }) : i2.length === 0 && !sn ? (0, V.jsx)(`div`, { style: { fontSize: 12, color: $.warn }, children: `Your agent hosts no identities yet, so there is nothing to sign in as. Create one in the wallet (Vault \u2192 identities) and try again.` }) : (0, V.jsxs)(V.Fragment, { children: [(0, V.jsxs)(`select`, { value: l2, onChange: (e3) => u2(e3.currentTarget.value), style: { width: `100%`, fontFamily: $.mono, fontSize: 12, padding: `8px 6px`, borderRadius: 6, border: `1px solid ${$.border}`, background: `var(--w-surface)`, color: $.text }, children: [(0, V.jsx)(`option`, { value: ``, children: `Choose an identity\u2026` }), i2.map((e3) => (0, V.jsxs)(`option`, { value: e3.did, children: [hn(e3.did), ` \xB7 `, e3.contextId] }, e3.did)), sn && (0, V.jsxs)(`option`, { value: `holder`, children: [`My wallet's own identity`, nn ? ` \xB7 ${hn(nn)}` : ``] })] }), l2 && (0, V.jsx)(`div`, { style: { marginTop: 10, fontFamily: $.mono, fontSize: 11, wordBreak: `break-all`, color: $.textMuted }, children: l2 === `holder` ? nn ?? `` : l2 }), l2 === `holder` ? (0, V.jsx)(`p`, { style: { margin: `10px 0 0`, fontSize: 11, color: $.warn }, children: `This is the same identity you use everywhere else, so any site that has it can work out you are the same person. Choose it when this site's access list already names your wallet's identity.` }) : (0, V.jsxs)(V.Fragment, { children: [(0, V.jsxs)(`p`, { style: { margin: `10px 0 0`, fontSize: 11, color: $.textMuted }, children: [`The site has to allow this identity before it will let you in. If sign-in is refused, ask`, ` `, d2 ? (0, V.jsx)(`strong`, { style: { fontFamily: $.mono }, children: d2 }) : `the site`, ` `, `to add the identity above to its access list, then try again.`] }), i2.length > 1 && (0, V.jsx)(`p`, { style: { margin: `6px 0 0`, fontSize: 11, color: $.textMuted }, children: `Using an identity you already use elsewhere lets both sites work out you are the same person. A fresh one for this site keeps them separate.` })] })] })] }), nn && !Q && (0, V.jsx)(`div`, { style: { background: $.card, border: `1px solid ${$.border}`, borderRadius: 10, padding: 14, marginBottom: 14 }, children: (0, V.jsx)(bn, { label: an ? `Approving as` : p2 ? `Acting as` : `Sign in as`, value: nn }) }), d2 && !$t && (0, V.jsxs)(`label`, { style: { display: `flex`, alignItems: `center`, gap: 8, margin: `0 0 12px`, fontSize: 12, color: $.textMuted, cursor: `pointer` }, children: [(0, V.jsx)(`input`, { type: `checkbox`, checked: n2, onChange: (e3) => r2(e3.currentTarget.checked) }), `Remember `, (0, V.jsx)(`strong`, { style: { fontFamily: $.mono }, children: d2 }), ` \u2014 don't ask again for this site`] }), (0, V.jsxs)(`div`, { style: { display: `flex`, gap: 8 }, children: [(0, V.jsx)(`button`, { autoFocus: true, onClick: () => mn(false), style: { flex: 1, padding: `10px 0`, border: `1px solid ${$.border}`, background: `var(--w-surface)`, color: $.text, borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: `pointer` }, children: `Deny` }), (0, V.jsx)(`button`, { disabled: Q && !l2, onClick: () => mn(true, n2, void 0, l2 || void 0), style: { flex: 1, padding: `10px 0`, border: `none`, background: Q && !l2 ? $.border : $.primary, color: Q && !l2 ? $.textMuted : `var(--w-accent-ink)`, borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: Q && !l2 ? `not-allowed` : `pointer` }, onMouseEnter: (e3) => {
    (!Q || l2) && (e3.currentTarget.style.background = $.primaryHover);
  }, onMouseLeave: (e3) => {
    (!Q || l2) && (e3.currentTarget.style.background = $.primary);
  }, children: Q ? `Approve & remember identity` : `Approve` })] })] });
}
function En(e2) {
  try {
    return P(e2);
  } catch {
    return null;
  }
}
function Dn(e2) {
  return /\/spec\/(.+)\/[\d.]+$/.exec(e2)?.[1] ?? e2;
}
function On({ effect: e2 }) {
  let t2 = _e(e2);
  if (!t2) return null;
  let n2 = t2.before !== void 0 || t2.after !== void 0;
  return (0, V.jsxs)(`div`, { style: { marginTop: 5, display: `grid`, gap: 3 }, children: [t2.path ? (0, V.jsx)(`div`, { style: { fontFamily: $.mono, fontSize: 10.5, color: $.textSubtle, letterSpacing: 0.2, wordBreak: `break-all` }, children: t2.path }) : null, n2 ? (0, V.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 6, flexWrap: `wrap`, fontFamily: $.mono, fontSize: 11 }, children: [(0, V.jsx)(`span`, { style: { padding: `1px 6px`, borderRadius: 4, background: $.dangerBg, color: $.danger, textDecoration: t2.before === void 0 ? `none` : `line-through`, wordBreak: `break-all` }, children: t2.before ?? `\u2205` }), (0, V.jsx)(`span`, { style: { color: $.textSubtle }, children: `\u2192` }), (0, V.jsx)(`span`, { style: { padding: `1px 6px`, borderRadius: 4, background: $.okBg, color: $.ok, wordBreak: `break-all` }, children: t2.after ?? `\u2205` })] }) : null] });
}
function kn() {
  let [e2, t2] = (0, B.useState)(null), [n2, r2] = (0, B.useState)(``), [i2, a2] = (0, B.useState)(false), [o2, s2] = (0, B.useState)(null);
  if ((0, B.useEffect)(() => {
    chrome.storage.session.get(`task-consent:${Gt}`).then((e3) => {
      t2(e3[`task-consent:${Gt}`] ?? null);
    });
  }, []), !e2) return (0, V.jsx)(`div`, { style: { padding: 20, fontSize: 13 }, children: `Loading request\u2026` });
  let c2 = e2.sideEffects === `destructive`, l2 = En(e2.payloadDigest), u2 = e2.effects.length > 0, d2 = e2.consequences ?? [], f2 = u2 || d2.length > 0, p2 = !c2 || l2 !== null && n2.trim().toLowerCase() === l2.toLowerCase(), m2 = e2.payloadDigest;
  async function h2() {
    if (!Qt) {
      mn(true);
      return;
    }
    a2(true), s2(null);
    try {
      let { prfOutput: e3 } = await D(chrome.runtime.id, m2);
      mn(true, false, ce(e3));
    } catch (e3) {
      s2(e3 instanceof Error ? e3.message : String(e3));
    } finally {
      a2(false);
    }
  }
  return (0, V.jsxs)(`div`, { style: { padding: 20, background: _n.approver.pageTint, minHeight: `100vh`, color: $.text, fontSize: 13 }, children: [(0, V.jsx)(vn, { mode: `approver`, pad: 20 }), (0, V.jsxs)(`div`, { style: { display: `grid`, gap: 14 }, children: [(0, V.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 8 }, children: [(0, V.jsx)(`span`, { style: { fontSize: 10, fontWeight: 700, letterSpacing: 0.6, textTransform: `uppercase`, padding: `3px 7px`, borderRadius: 4, color: `var(--w-accent-ink)`, background: c2 ? `var(--w-danger)` : e2.sideEffects === `mutating` ? `var(--w-warn)` : `var(--w-ok)` }, children: e2.sideEffects }), (0, V.jsx)(`strong`, { style: { fontSize: 14 }, children: `Approve this action?` })] }), (0, V.jsxs)(`div`, { style: { color: `var(--w-muted)`, lineHeight: 1.45 }, children: [`Your agent is asking permission to run`, ` `, (0, V.jsx)(`code`, { style: { fontSize: 12 }, children: Dn(e2.taskType) }), e2.subject ? (0, V.jsxs)(V.Fragment, { children: [` `, `on `, (0, V.jsx)(`code`, { style: { fontSize: 12 }, children: e2.subject })] }) : null, `.`] }), (0, V.jsxs)(`div`, { style: { border: `1px solid ${f2 ? `var(--w-line)` : `var(--w-danger)`}`, borderRadius: 6, padding: 12, background: f2 ? `var(--w-raised)` : `var(--w-danger-soft)` }, children: [(0, V.jsx)(`div`, { style: { fontWeight: 600, marginBottom: 8, fontSize: 12 }, children: f2 ? `This will:` : `\u26A0 Consequences unknown` }), f2 ? u2 ? (0, V.jsx)(`ul`, { style: { margin: 0, paddingLeft: 18, display: `grid`, gap: 10 }, children: e2.effects.map((e3, t3) => (0, V.jsxs)(`li`, { style: { lineHeight: 1.4 }, children: [e3.summary, (0, V.jsx)(On, { effect: e3 })] }, t3)) }) : (0, V.jsx)(`ul`, { style: { margin: 0, paddingLeft: 18, display: `grid`, gap: 6 }, children: d2.map((e3, t3) => (0, V.jsx)(`li`, { style: { lineHeight: 1.4 }, children: e3 }, t3)) }) : (0, V.jsx)(`div`, { style: { lineHeight: 1.45 }, children: `Your agent could not determine what this task will do. Approving it means approving an effect nobody has described to you.` })] }), e2.origin ? (0, V.jsxs)(`div`, { style: { fontSize: 12, color: `var(--w-muted)` }, children: [`Requested by `, (0, V.jsx)(`strong`, { children: gn(e2.origin) ?? e2.origin })] }) : null, e2.statePin ? (0, V.jsxs)(`div`, { style: { fontSize: 11, color: `var(--w-muted)` }, children: [`Computed against version `, (0, V.jsx)(`code`, { children: e2.statePin.version }), `. If it changes before you approve, your agent will ask again.`] }) : null, l2 === null ? (0, V.jsx)(`div`, { style: { fontSize: 11, color: $.danger, lineHeight: 1.4 }, children: `This request carries a digest this wallet cannot read, so there is no code to compare. Do not approve it \u2014 check that your agent and wallet are on the same version.` }) : (0, V.jsxs)(`div`, { style: { fontSize: 11, color: `var(--w-muted)` }, children: [`Request code`, ` `, (0, V.jsx)(`code`, { style: { fontSize: 13, letterSpacing: 1.5, color: `var(--w-text)` }, children: l2 })] }), c2 && l2 !== null ? (0, V.jsxs)(`div`, { style: { display: `grid`, gap: 6 }, children: [(0, V.jsx)(`label`, { style: { fontSize: 12, fontWeight: 600 }, children: `This cannot be undone. Type the request code shown where you started this action:` }), (0, V.jsx)(`input`, { value: n2, onChange: (e3) => r2(e3.target.value), placeholder: `\xB7`.repeat(6), style: { padding: `8px 10px`, fontSize: 15, letterSpacing: 2, fontFamily: `monospace`, border: `1px solid var(--w-line)`, borderRadius: 5 } })] }) : null, o2 ? (0, V.jsxs)(`div`, { style: { color: $.danger, fontSize: 12, lineHeight: 1.4 }, children: [`Not signed: `, o2] }) : null, (0, V.jsxs)(`div`, { style: { display: `flex`, gap: 8, justifyContent: `flex-end`, marginTop: 4 }, children: [(0, V.jsx)(`button`, { autoFocus: true, onClick: () => mn(false), style: { padding: `8px 16px`, fontSize: 13 }, children: `Deny` }), (0, V.jsx)(`button`, { disabled: !p2 || i2, onClick: () => void h2(), style: { padding: `8px 18px`, fontSize: 13, fontWeight: 700, border: `none`, borderRadius: 8, color: `var(--w-accent-ink)`, background: _n.approver.accent, opacity: p2 && !i2 ? 1 : 0.45, cursor: p2 && !i2 ? `pointer` : `not-allowed` }, children: i2 ? `Waiting for authenticator\u2026` : Qt ? `Approve with biometric` : `Approve` })] })] })] });
}
T(document);
var An = document.getElementById(`root`);
An && (0, xe.createRoot)(An).render((0, V.jsx)(B.StrictMode, { children: Z.get(`kind`) === `join` ? (0, V.jsx)(Wt, {}) : Zt ? (0, V.jsx)(_t, { flowId: Zt }) : Xt ? (0, V.jsx)(Ze, { consentId: Gt, decide: (e2) => void pn({ approved: e2, remember: false }) }) : Yt ? (0, V.jsx)(He, { consentId: Gt, decide: (e2, t2) => void pn({ approved: e2, remember: false, ...e2 && t2 ? { selectedRooms: t2 } : {} }) }) : Jt ? (0, V.jsx)(ke, { consentId: Gt, decide: (e2, t2) => mn(e2, false, t2) }) : qt ? (0, V.jsx)(Ce, { consentId: Gt, decide: (e2) => mn(e2) }) : Kt ? (0, V.jsx)(kn, {}) : (0, V.jsx)(Tn, {}) }));
