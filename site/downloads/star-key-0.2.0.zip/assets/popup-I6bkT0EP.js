import { i as e } from "./rolldown-runtime-Dd_uD5pT.js";
import { t } from "./star-brand-Dx2wZrCK.js";
import { a as n, r, t as i } from "./theme-pbhxFgxu.js";
import { M as a, N as o, a as s, c, d as l, j as u, m as d, p as f, t as p, z as m } from "./host-permissions-TPtLahe0.js";
import { S as h } from "./didcomm-D5nXYRy6.js";
import { bt as g, ft as _, jt as v, kt as y, nt as b, ot as x, tt as S, xt as C } from "./bridge-protocol-DoEW6v30.js";
import { a as w, c as T, i as E, n as D, o as O, r as k, t as A } from "./vault-panel-CoLPCGvg.js";
var j = e(n(), 1), M = i(), N = `vta-wallet-provider`;
function P(e2) {
  return e2.some((e3) => e3 === `<all_urls>` || e3 === `*://*/*`) ? [`<all_urls>`] : e2.filter((e3) => /^https?:\/\//.test(e3)).sort();
}
async function F() {
  try {
    return (await chrome.scripting.getRegisteredContentScripts({ ids: [`vta-wallet-provider`] }))[0]?.matches ?? [];
  } catch {
    return [];
  }
}
var I = Promise.resolve();
function L() {
  let e2 = I.then(R, R);
  return I = e2.catch(() => void 0), e2;
}
async function R() {
  let e2 = P((await chrome.permissions.getAll()).origins ?? []), t2 = await F();
  if (e2.length === t2.length && e2.every((e3, n3) => e3 === t2[n3])) return e2;
  if (e2.length === 0) return t2.length > 0 && await chrome.scripting.unregisterContentScripts({ ids: [N] }), [];
  let n2 = { id: N, js: [`content.js`], matches: e2, runAt: `document_start`, persistAcrossSessions: true, allFrames: false };
  return t2.length > 0 ? await chrome.scripting.updateContentScripts([n2]) : await chrome.scripting.registerContentScripts([n2]), e2;
}
async function z(e2) {
  if (!e2 || !/^https?:\/\//.test(e2)) return false;
  try {
    return await chrome.permissions.contains({ origins: [e2] });
  } catch {
    return false;
  }
}
var B = r(), V = { padding: 12, display: `grid`, gap: 8 }, H = { fontFamily: `ui-monospace, monospace`, fontSize: 11, wordBreak: `break-all`, minWidth: 0, maxWidth: `100%` };
function U({ onRequestAddVta: e2 }) {
  let t2 = k(), n2 = E((e3) => e3.connections.vtas), r2 = E((e3) => e3.activateVta), i2 = E((e3) => e3.forgetVta), [a2, o2] = (0, j.useState)(false), [s2, c2] = (0, j.useState)(null), l2 = Object.values(n2).sort((e3, t3) => e3.vtaDid.localeCompare(t3.vtaDid));
  async function u2(e3) {
    if (confirm(`Forget VTA ${e3}?

This removes the wallet identity for this VTA from this device. The VTA's ACL entry for your wallet stays \u2014 revoke it separately on the VTA side (\`pnm acl delete --did <holder>\`) if you don't want the wallet to be able to re-onboard.

Proceed?`)) {
      c2(e3);
      try {
        let t3 = await chrome.runtime.sendMessage({ type: S, vtaDid: e3 });
        if (!t3.ok) {
          alert(`Couldn't delete the wallet identity for ${e3}: ${t3.error}`);
          return;
        }
        i2(e3);
      } finally {
        c2(null);
      }
    }
  }
  return a2 ? (0, B.jsxs)(`div`, { style: { padding: 8, background: `var(--w-raised)`, border: `1px solid var(--w-line)`, borderRadius: 6, display: `grid`, gap: 6, fontSize: 11 }, children: [(0, B.jsxs)(`div`, { style: { display: `flex`, justifyContent: `space-between`, alignItems: `center` }, children: [(0, B.jsx)(`strong`, { style: { fontSize: 12 }, children: `VTAs on this device` }), (0, B.jsx)(`button`, { onClick: () => o2(false), style: { fontSize: 10, padding: `2px 6px` }, children: `Collapse` })] }), (0, B.jsx)(`ul`, { style: { listStyle: `none`, padding: 0, margin: 0, display: `grid`, gap: 4 }, children: l2.map((e3) => {
    let n3 = e3.vtaDid === t2.vtaDid;
    return (0, B.jsxs)(`li`, { style: { padding: 6, background: n3 ? `var(--w-ok-soft)` : `var(--w-surface)`, border: `1px solid ${n3 ? `var(--w-ok)` : `var(--w-line)`}`, borderRadius: 4, display: `grid`, gap: 4 }, children: [(0, B.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 6 }, children: [(0, B.jsx)(`span`, { style: { color: n3 ? `var(--w-ok)` : `var(--w-muted)`, fontWeight: 600 }, title: n3 ? `Currently active` : `Click Switch to activate`, children: n3 ? `\u25CF` : `\u25CB` }), (0, B.jsx)(`code`, { style: { ...H, flex: 1 }, children: e3.vtaDid }), (0, B.jsx)(d, { value: e3.vtaDid })] }), (0, B.jsxs)(`div`, { style: { display: `flex`, gap: 6, justifyContent: `flex-end` }, children: [!n3 && (0, B.jsx)(`button`, { onClick: () => {
      r2(e3.vtaDid), o2(false);
    }, style: { fontSize: 10 }, children: `Switch` }), (0, B.jsx)(`button`, { onClick: () => void u2(e3.vtaDid), disabled: s2 === e3.vtaDid, style: { fontSize: 10, color: `var(--w-danger)` }, title: `Delete this wallet identity from this device`, children: s2 === e3.vtaDid ? `Forgetting\u2026` : `Forget` })] })] }, e3.vtaDid);
  }) }), (0, B.jsx)(`button`, { onClick: () => {
    o2(false), e2();
  }, style: { fontSize: 11 }, children: `+ Add another VTA` })] }) : (0, B.jsxs)(`div`, { style: { padding: `6px 10px`, background: `var(--w-raised)`, border: `1px solid var(--w-line)`, borderRadius: 6, fontSize: 11, display: `flex`, alignItems: `center`, justifyContent: `space-between`, gap: 6 }, children: [(0, B.jsxs)(`span`, { style: { color: `var(--w-muted)` }, children: [`VTA: `, (0, B.jsx)(`code`, { style: H, children: W(t2.vtaDid) }), (0, B.jsx)(d, { value: t2.vtaDid }), l2.length > 1 && (0, B.jsxs)(`span`, { style: { color: `var(--w-muted)`, marginLeft: 6 }, children: [`(`, l2.length, ` configured)`] })] }), (0, B.jsx)(`button`, { onClick: () => o2(true), style: { fontSize: 10, padding: `2px 8px` }, title: l2.length > 1 ? `Switch between VTAs or add a new one` : `Add another VTA`, children: l2.length > 1 ? `Switch / manage` : `+ Add VTA` })] });
}
function W(e2) {
  return e2.length <= 36 ? e2 : `${e2.slice(0, 20)}\u2026${e2.slice(-12)}`;
}
function G({ onRequestAddVta: e2 }) {
  let t2 = k(), n2 = E((e3) => e3.clearConnection), r2 = w((e3) => e3.state), i2 = w((e3) => e3.setLockState), [a2, o2] = (0, j.useState)(false), [s2, c2] = (0, j.useState)(null), [l2, f2] = (0, j.useState)(false), [p2, m2] = (0, j.useState)(false), [h2, g2] = (0, j.useState)(null);
  (0, j.useEffect)(() => {
    (async () => {
      let e3 = await v();
      o2(!!e3.encryptHolderSecret);
    })();
  }, []);
  async function _2() {
    m2(true), g2(null);
    try {
      await u(t2.vtaDid), o2(true), i2({ encrypted: true, unlocked: true });
    } catch (e3) {
      g2(e3 instanceof Error ? e3.message : String(e3));
    } finally {
      m2(false);
    }
  }
  async function y2() {
    f2(true), c2(null);
    try {
      let e3 = await chrome.runtime.sendMessage({ type: x });
      if (!e3?.ok) throw Error(e3?.error ?? `lock failed`);
      a2 && i2({ encrypted: true, unlocked: false }), c2(`Locked \u2014 next operation re-prompts your authenticator.`);
    } catch (e3) {
      c2(`Error: ${e3 instanceof Error ? e3.message : String(e3)}`);
    } finally {
      f2(false);
    }
  }
  let b2 = [t2.tspMediatorDid ? `TSP` : null, t2.mediatorDid ? `DIDComm` : null, t2.restBaseUrl ? `REST` : null].filter(Boolean).join(` + `), S2 = r2 !== null && r2.encrypted === false;
  return (0, B.jsxs)(`div`, { style: V, children: [(0, B.jsx)(U, { onRequestAddVta: e2 }), S2 && (0, B.jsxs)(`div`, { style: { padding: 10, background: `var(--w-danger-soft)`, border: `2px solid var(--w-danger)`, borderRadius: 6, display: `grid`, gap: 6 }, children: [(0, B.jsx)(`strong`, { style: { color: `var(--w-danger)`, fontSize: 13 }, children: `\u26A0 Wallet is NOT encrypted` }), (0, B.jsxs)(`small`, { style: { color: `var(--w-danger)` }, children: [`Your wallet's long-term key is stored on this device `, (0, B.jsx)(`strong`, { children: `without encryption` }), `. Anyone with access to your browser profile (malware, a stolen laptop, a backup leak) can read it. Encrypt now with your platform authenticator (Touch ID, Windows Hello, hardware key).`] }), (0, B.jsx)(`button`, { onClick: () => void _2(), disabled: p2, style: { background: `var(--w-danger)`, color: `var(--w-accent-ink)`, border: `none`, padding: `8px 14px`, borderRadius: 4, fontWeight: 600, fontSize: 12, cursor: p2 ? `default` : `pointer` }, children: p2 ? `Encrypting\u2026` : `\u{1F510} Encrypt now` }), h2 && (0, B.jsxs)(`small`, { style: { color: `var(--w-danger)` }, children: [`Couldn't encrypt: `, h2] }), (0, B.jsx)(`small`, { style: { color: `var(--w-danger)`, fontSize: 10 }, children: `Heads up: if you lose this authenticator without first disabling encryption, the wallet becomes unrecoverable.` })] }), (0, B.jsx)(`h3`, { style: { margin: 0 }, children: `Connected \u2713` }), (0, B.jsx)(`div`, { style: { fontSize: 12, color: `var(--w-muted)` }, children: `Your wallet is authorized at this VTA.` }), (0, B.jsx)(`div`, { style: { fontSize: 12, color: `var(--w-muted)` }, children: `VTA` }), (0, B.jsxs)(`div`, { style: { display: `flex`, alignItems: `flex-start`, gap: 6 }, children: [(0, B.jsx)(`code`, { style: { ...H, flex: 1 }, children: t2.vtaDid }), (0, B.jsx)(d, { value: t2.vtaDid }), (0, B.jsx)(A, { text: t2.vtaDid })] }), (0, B.jsx)(`div`, { style: { fontSize: 12, color: `var(--w-muted)` }, children: `Holder (your wallet DID)` }), (0, B.jsxs)(`div`, { style: { display: `flex`, alignItems: `flex-start`, gap: 6 }, children: [(0, B.jsx)(`code`, { style: { ...H, flex: 1 }, children: t2.holderDid }), (0, B.jsx)(d, { value: t2.holderDid }), (0, B.jsx)(A, { text: t2.holderDid })] }), (0, B.jsxs)(`div`, { style: { fontSize: 12, color: `var(--w-muted)` }, children: [`Role: `, (0, B.jsx)(`b`, { children: t2.role }), ` \xA0\xB7\xA0 Transports: `, (0, B.jsx)(`b`, { children: b2 || `\u2014` })] }), (0, B.jsx)(`button`, { onClick: () => void chrome.tabs.create({ url: chrome.runtime.getURL(`manager.html`) }), style: { marginTop: 8 }, children: `Manage this agent \u2197` }), (0, B.jsx)(`small`, { style: { color: `var(--w-muted)` }, children: `Opens the management console in a new tab \u2014 contexts, keys, credentials, access and audit for this VTA.` }), a2 && (0, B.jsxs)(B.Fragment, { children: [(0, B.jsx)(`button`, { onClick: () => void y2(), disabled: l2, style: { marginTop: 8 }, children: l2 ? `Locking\u2026` : `\u{1F512} Lock wallet` }), s2 && (0, B.jsx)(`small`, { style: { color: s2.startsWith(`Error`) ? `var(--w-danger)` : `var(--w-ok)` }, children: s2 }), (0, B.jsx)(`small`, { style: { color: `var(--w-muted)` }, children: `Clears the in-memory key so the next operation re-prompts your authenticator. The wallet identity isn't forgotten \u2014 the locked state survives until a successful unlock OR a browser restart.` })] }), (0, B.jsx)(D, {}), (0, B.jsx)(`button`, { onClick: n2, style: { marginTop: 8 }, children: `Disconnect (forget this VTA)` }), (0, B.jsxs)(`small`, { style: { color: `var(--w-muted)` }, children: [`Forgets the connection in this popup. Your wallet DID stays in the VTA's ACL until the operator revokes it (`, (0, B.jsx)(`code`, { children: `pnm acl delete` }), `).`] })] });
}
function K() {
  let e2 = w((e3) => e3.setLockState), [t2, n2] = (0, j.useState)(false), [r2, i2] = (0, j.useState)(null);
  async function a2() {
    n2(true), i2(null);
    try {
      let { prfOutput: t3 } = await l(chrome.runtime.id), n3 = await chrome.runtime.sendMessage({ type: C, prfOutputB64u: h(t3) });
      if (!n3.ok) throw Error(n3.error);
      e2({ encrypted: true, unlocked: true });
      let r3 = await T();
      if (r3) try {
        await chrome.runtime.sendMessage({ type: g, prfOutputB64u: h(t3), vtaDid: r3 });
      } catch {
      }
    } catch (e3) {
      e3 instanceof c && e3.reason === `cancelled` ? i2(`Cancelled. Tap the button to try again.`) : i2(e3 instanceof Error ? e3.message : String(e3));
    } finally {
      n2(false);
    }
  }
  return (0, B.jsxs)(`div`, { style: V, children: [(0, B.jsx)(`h3`, { style: { margin: 0 }, children: `Unlock wallet` }), (0, B.jsx)(`small`, { children: `This wallet's identity is encrypted on this device. Tap your authenticator (Touch ID, Windows Hello, hardware key) to unlock for this session.` }), (0, B.jsx)(`small`, { style: { color: `var(--w-muted)` }, children: `Once unlocked, wallet operations work normally until you Lock or restart the browser.` }), (0, B.jsx)(`button`, { onClick: () => void a2(), disabled: t2, children: t2 ? `Waiting for authenticator\u2026` : `Unlock with authenticator` }), r2 && (0, B.jsx)(`small`, { style: { color: `var(--w-danger)` }, children: r2 })] });
}
function q({ reason: e2 }) {
  return (0, B.jsxs)(`div`, { style: { ...V, gap: 12 }, children: [(0, B.jsxs)(`div`, { children: [(0, B.jsx)(`h3`, { style: { margin: `0 0 4px`, fontSize: m.md }, children: `Set up your wallet` }), (0, B.jsx)(`div`, { style: { fontSize: m.sm, color: o.muted, lineHeight: 1.55 }, children: e2 })] }), (0, B.jsx)(`button`, { onClick: () => {
    chrome.tabs.create({ url: chrome.runtime.getURL(`options.html#setup`) }), window.close();
  }, style: { ...a(`primary`), justifySelf: `start` }, children: `Open setup` })] });
}
function J() {
  let [e2, t2] = (0, j.useState)(null), [n2, r2] = (0, j.useState)(null), [i2, c2] = (0, j.useState)(false);
  if ((0, j.useEffect)(() => {
    (async () => {
      let [e3] = await chrome.tabs.query({ active: true, currentWindow: true });
      e3?.url && /^https?:\/\//.test(e3.url) && (await z(e3.url) || (t2(new URL(e3.url).origin), r2(e3.id ?? null)));
    })();
  }, []), !e2) return null;
  async function l2() {
    c2(true);
    try {
      if (!await s(e2)) return;
      await L(), n2 !== null && await chrome.tabs.reload(n2), window.close();
    } finally {
      c2(false);
    }
  }
  return (0, B.jsxs)(`div`, { style: { display: `grid`, gap: 6, padding: `10px 12px`, borderLeft: `2px solid ${o.accent}`, background: o.accentSoft }, children: [(0, B.jsxs)(`strong`, { style: { fontSize: m.sm }, children: [`The wallet is off on `, p(e2)] }), (0, B.jsx)(`small`, { style: { color: o.muted, lineHeight: 1.5 }, children: `It only runs on sites you turn it on for. Enabling reloads the page so the site can see it.` }), (0, B.jsx)(`div`, { children: (0, B.jsx)(`button`, { onClick: () => void l2(), disabled: i2, style: a(`primary`), children: i2 ? `Enabling\u2026` : `Enable on ${p(e2)}` }) })] });
}
function Y() {
  let e2 = k(), n2 = E((e3) => e3.connections);
  return (0, B.jsxs)(B.Fragment, { children: [(0, B.jsx)(t, { active: !!e2 }), (0, B.jsxs)(`details`, { style: { padding: 16, overflowWrap: `anywhere` }, children: [(0, B.jsx)(`summary`, { children: `Your DIDs & how Star works` }), (0, B.jsx)(`p`, { children: `Remembered connections, not live site sessions.` }), !Object.keys(n2.vtas).length && (0, B.jsx)(`p`, { children: `No VTA connected. Use setup below.` }), Object.values(n2.vtas).map((t2) => (0, B.jsxs)(`section`, { children: [(0, B.jsx)(`strong`, { children: e2?.vtaDid === t2.vtaDid ? `Selected VTA` : `Remembered VTA` }), (0, B.jsxs)(`p`, { children: [`VTA: `, (0, B.jsx)(`code`, { children: t2.vtaDid })] }), (0, B.jsxs)(`p`, { children: [`Holder: `, (0, B.jsx)(`code`, { children: t2.holderDid })] }), (0, B.jsxs)(`p`, { children: [`Role: `, t2.role, ` \xB7 Context: `, t2.homeContext || `not recorded`] })] }, t2.vtaDid)), (0, B.jsx)(`p`, { children: `Compatible OpenVTC sites request sign-in through the wallet. Identity selection, site permissions and approval still apply. Remembered DIDs do not establish current access. Use the existing VTA controls for persona identities.` }), (0, B.jsx)(`p`, { children: `The Star expresses selected knowledge context. Key appearance, identity control and verified relationships are separate layers.` }), (0, B.jsxs)(`p`, { children: [(0, B.jsx)(`a`, { href: `https://guide.agentprivacy.ai/`, target: `_blank`, rel: `noreferrer`, children: `Guide wiki \u2197` }), ` \xB7 `, (0, B.jsx)(`a`, { href: `https://soulbis.com/star/`, target: `_blank`, rel: `noreferrer`, children: `Explore Star \u2197` }), ` \xB7 `, (0, B.jsx)(`a`, { href: `https://mages.city/`, target: `_blank`, rel: `noreferrer`, children: `Mages City \u2197` })] })] })] });
}
function X() {
  let e2 = k(), t2 = E((e3) => e3.setConnection), n2 = E((e3) => e3.clearConnection), [r2, i2] = (0, j.useState)(null), [a2, o2] = (0, j.useState)(false), [s2, c2] = (0, j.useState)(false), l2 = w((e3) => e3.state), u2 = w((e3) => e3.setLockState), f2 = async () => {
    let t3 = await chrome.runtime.sendMessage({ type: y, ...e2 ? { vtaDid: e2.vtaDid } : {} });
    t3.ok && u2(t3.result);
  };
  (0, j.useEffect)(() => {
    (async () => {
      let e3 = await chrome.runtime.sendMessage({ type: b });
      e3.ok && i2(e3.result), await f2();
    })();
  }, []), (0, j.useEffect)(() => {
    e2 && (async () => {
      let t3 = await chrome.runtime.sendMessage({ type: b });
      t3.ok && i2(t3.result), await f2(), await p2(e2);
    })();
  }, [e2]);
  async function p2(e3) {
    let n3 = await chrome.runtime.sendMessage({ type: _, vtaDid: e3.vtaDid });
    if (!n3.ok) {
      console.warn(`[pnm] VTA transport refresh failed:`, n3.error);
      return;
    }
    let r3 = n3.result;
    c2(!r3.restBaseUrl && !r3.mediatorDid);
    let i3 = (r3.restBaseUrl ?? null) !== (e3.restBaseUrl ?? null), a3 = (r3.mediatorDid ?? null) !== (e3.mediatorDid ?? null), o3 = (r3.tspMediatorDid ?? null) !== (e3.tspMediatorDid ?? null);
    if (!i3 && !a3 && !o3) return;
    let s3 = O(e3, r3);
    console.info(`[pnm] VTA transports refreshed:`, { tsp: !!r3.tspMediatorDid, rest: !!r3.restBaseUrl, didcomm: !!r3.mediatorDid }, `(was: tsp=` + !!e3.tspMediatorDid + `, rest=` + !!e3.restBaseUrl + `, didcomm=` + !!e3.mediatorDid + `)`), t2(s3);
  }
  let m2 = s2 && e2 && (0, B.jsxs)(`div`, { style: { padding: 10, background: `var(--w-danger-soft)`, border: `2px solid var(--w-danger)`, borderRadius: 6, display: `grid`, gap: 6, margin: `8px 12px 0` }, children: [(0, B.jsx)(`strong`, { style: { color: `var(--w-danger)`, fontSize: 13 }, children: `\u26A0 VTA advertises no transports` }), (0, B.jsxs)(`small`, { style: { color: `var(--w-danger)` }, children: [(0, B.jsx)(`code`, { style: H, children: e2.vtaDid }), (0, B.jsx)(d, { value: e2.vtaDid }), ` currently advertises neither`, ` `, (0, B.jsx)(`code`, { children: `#vta-rest` }), ` nor `, (0, B.jsx)(`code`, { children: `#vta-didcomm` }), `. Wallet operations will fail until the VTA re-enables at least one transport (`, (0, B.jsxs)(`code`, { children: [`vta services `, `{rest,didcomm}`, ` enable`] }), `).`] })] }), h2 = (0, j.useRef)(e2?.vtaDid);
  return (0, j.useEffect)(() => {
    e2?.vtaDid && e2.vtaDid !== h2.current && o2(false), h2.current = e2?.vtaDid;
  }, [e2?.vtaDid]), r2?.kind === `none` && e2 ? (0, B.jsxs)(`div`, { style: V, children: [(0, B.jsx)(`small`, { style: { color: `var(--w-danger)` }, children: `Stale connection cleared \u2014 no holder identity is persisted. Onboard fresh.` }), (0, B.jsx)(q, { reason: `Connect a trust agent to get started.` })] }) : a2 ? (0, B.jsx)(q, { reason: `Adding another trust agent opens the setup page.` }) : l2?.encrypted && !l2.unlocked ? (0, B.jsxs)(B.Fragment, { children: [m2, (0, B.jsx)(K, {})] }) : e2 ? (0, B.jsxs)(B.Fragment, { children: [m2, (0, B.jsx)(J, {}), (0, B.jsx)(G, { onRequestAddVta: () => o2(true) })] }) : r2?.kind === `v3` ? (0, B.jsxs)(`div`, { style: V, children: [(0, B.jsxs)(`div`, { style: { padding: 12, border: `1px solid var(--w-warn)`, background: `var(--w-warn-soft)`, borderRadius: 6, display: `grid`, gap: 6 }, children: [(0, B.jsx)(`strong`, { children: `Re-onboarding required` }), (0, B.jsxs)(`small`, { children: [`This wallet predates the VTA-minted identity migration. Your previous holder DID (`, (0, B.jsx)(`code`, { style: H, children: r2.did }), `) was generated locally by the wallet; this build expects the VTA to mint your long-term identity instead.`] }), (0, B.jsxs)(`small`, { children: [(0, B.jsx)(`strong`, { children: `What to expect:` }), ` connecting to a VTA below will mint a fresh holder DID and replace the old one. Every relying party that recognised the old DID will need to be re-granted with the new one.`] }), (0, B.jsx)(`button`, { onClick: () => {
    n2();
  }, children: `Dismiss banner` })] }), (0, B.jsx)(q, { reason: `Connect a trust agent to get started.` })] }) : (0, B.jsx)(q, { reason: `Your wallet needs to be re-connected before it can be used.` });
}
function Z() {
  return (0, B.jsxs)(`div`, { style: { textAlign: `center`, fontSize: 10, color: `var(--w-muted)`, padding: `8px 0 6px`, borderTop: `1px solid var(--w-raised)`, marginTop: 4, letterSpacing: 0.2 }, children: [`Built by`, ` `, (0, B.jsx)(`a`, { href: `https://www.affinidi.com`, target: `_blank`, rel: `noopener noreferrer`, style: { color: `var(--w-accent)`, textDecoration: `none`, fontWeight: 500 }, children: `Affinidi` })] });
}
f(document);
var Q = document.getElementById(`root`);
Q && (0, M.createRoot)(Q).render((0, B.jsxs)(j.StrictMode, { children: [(0, B.jsx)(Y, {}), (0, B.jsx)(X, {}), (0, B.jsx)(Z, {})] }));
