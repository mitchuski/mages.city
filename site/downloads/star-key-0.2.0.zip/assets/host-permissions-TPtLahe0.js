import { i as e } from "./rolldown-runtime-Dd_uD5pT.js";
import { a as t, n, r } from "./theme-pbhxFgxu.js";
import { S as i, x as a } from "./didcomm-D5nXYRy6.js";
import { Ft as o, It as s, Kt as c, Pt as l, Rt as u, Yt as d, xt as f, zt as p } from "./bridge-protocol-DoEW6v30.js";
var m = { ground: `var(--w-ground)`, surface: `var(--w-surface)`, raised: `var(--w-raised)`, line: `var(--w-line)`, lineSoft: `var(--w-line-soft)`, text: `var(--w-text)`, muted: `var(--w-muted)`, faint: `var(--w-faint)`, accent: `var(--w-accent)`, accentSoft: `var(--w-accent-soft)`, accentInk: `var(--w-accent-ink)`, ok: `var(--w-ok)`, okSoft: `var(--w-ok-soft)`, warn: `var(--w-warn)`, warnSoft: `var(--w-warn-soft)`, danger: `var(--w-danger)`, dangerSoft: `var(--w-danger-soft)` }, h = { xs: `var(--w-t-xs)`, sm: `var(--w-t-sm)`, base: `var(--w-t-base)`, md: `var(--w-t-md)`, lg: `var(--w-t-lg)`, xl: `var(--w-t-xl)` }, g = { sm: `var(--w-r-sm)`, md: `var(--w-r-md)`, lg: `var(--w-r-lg)` }, _ = { sans: `var(--w-sans)`, mono: `var(--w-mono)` }, v = { fontFamily: _.mono, fontSize: h.sm, wordBreak: `break-all` }, y = { fontSize: h.xs, textTransform: `uppercase`, letterSpacing: `0.1em`, fontWeight: 650, color: m.faint }, b = { background: m.surface, border: `1px solid ${m.line}`, borderRadius: g.md, padding: `16px 18px` };
function x(e2 = `default`) {
  let t2 = { fontFamily: _.sans, fontSize: h.sm, fontWeight: 600, padding: `7px 14px`, borderRadius: g.sm, border: `1px solid ${m.line}`, background: m.raised, color: m.text, cursor: `pointer`, whiteSpace: `nowrap` };
  switch (e2) {
    case `primary`:
      return { ...t2, background: m.accent, borderColor: m.accent, color: m.accentInk };
    case `quiet`:
      return { ...t2, background: `transparent`, borderColor: `transparent`, color: m.muted, padding: `7px 8px` };
    case `danger`:
      return { ...t2, background: `transparent`, borderColor: `transparent`, color: m.danger, padding: `7px 8px` };
    default:
      return t2;
  }
}
function ee(e2) {
  let t2 = { fontSize: `10.5px`, fontWeight: 650, letterSpacing: `0.045em`, textTransform: `uppercase`, padding: `2.5px 8px`, borderRadius: 999, whiteSpace: `nowrap`, display: `inline-block` }, n2 = { ok: { background: m.okSoft, color: m.ok }, warn: { background: m.warnSoft, color: m.warn }, danger: { background: m.dangerSoft, color: m.danger }, accent: { background: m.accentSoft, color: m.accent }, off: { background: m.raised, color: m.faint } };
  return { ...t2, ...n2[e2] };
}
async function te(e2) {
  await c(new d(), { vtaDid: e2, toWrap: new u(chrome.runtime.id) }), await l({ encryptHolderSecret: true });
  let t2 = u.consumeLastEnrolledPrfOutput();
  if (t2) {
    let e3 = await chrome.runtime.sendMessage({ type: f, prfOutputB64u: i(t2) });
    if (!e3.ok) throw Error(`offscreen unlock relay failed: ${e3.error}`);
  }
}
var S = function(e2, t2) {
  let n2 = e2, r2 = w[t2], i2 = null, a2 = 0, o2 = null, s2 = [], c2 = {}, l2 = function(e3, t3) {
    a2 = n2 * 4 + 17, i2 = (function(e4) {
      let t4 = Array(e4);
      for (let n3 = 0; n3 < e4; n3 += 1) {
        t4[n3] = Array(e4);
        for (let r3 = 0; r3 < e4; r3 += 1) t4[n3][r3] = null;
      }
      return t4;
    })(a2), u2(0, 0), u2(a2 - 7, 0), u2(0, a2 - 7), p2(), f2(), h2(e3, t3), n2 >= 7 && m2(e3), o2 ??= v2(n2, r2, s2), g2(o2, t3);
  }, u2 = function(e3, t3) {
    for (let n3 = -1; n3 <= 7; n3 += 1) if (!(e3 + n3 <= -1 || a2 <= e3 + n3)) for (let r3 = -1; r3 <= 7; r3 += 1) t3 + r3 <= -1 || a2 <= t3 + r3 || (0 <= n3 && n3 <= 6 && (r3 == 0 || r3 == 6) || 0 <= r3 && r3 <= 6 && (n3 == 0 || n3 == 6) || 2 <= n3 && n3 <= 4 && 2 <= r3 && r3 <= 4 ? i2[e3 + n3][t3 + r3] = true : i2[e3 + n3][t3 + r3] = false);
  }, d2 = function() {
    let e3 = 0, t3 = 0;
    for (let n3 = 0; n3 < 8; n3 += 1) {
      l2(true, n3);
      let r3 = E.getLostPoint(c2);
      (n3 == 0 || e3 > r3) && (e3 = r3, t3 = n3);
    }
    return t3;
  }, f2 = function() {
    for (let e3 = 8; e3 < a2 - 8; e3 += 1) i2[e3][6] ?? (i2[e3][6] = e3 % 2 == 0);
    for (let e3 = 8; e3 < a2 - 8; e3 += 1) i2[6][e3] ?? (i2[6][e3] = e3 % 2 == 0);
  }, p2 = function() {
    let e3 = E.getPatternPosition(n2);
    for (let t3 = 0; t3 < e3.length; t3 += 1) for (let n3 = 0; n3 < e3.length; n3 += 1) {
      let r3 = e3[t3], a3 = e3[n3];
      if (i2[r3][a3] == null) for (let e4 = -2; e4 <= 2; e4 += 1) for (let t4 = -2; t4 <= 2; t4 += 1) e4 == -2 || e4 == 2 || t4 == -2 || t4 == 2 || e4 == 0 && t4 == 0 ? i2[r3 + e4][a3 + t4] = true : i2[r3 + e4][a3 + t4] = false;
    }
  }, m2 = function(e3) {
    let t3 = E.getBCHTypeNumber(n2);
    for (let n3 = 0; n3 < 18; n3 += 1) {
      let r3 = !e3 && (t3 >> n3 & 1) == 1;
      i2[Math.floor(n3 / 3)][n3 % 3 + a2 - 8 - 3] = r3;
    }
    for (let n3 = 0; n3 < 18; n3 += 1) {
      let r3 = !e3 && (t3 >> n3 & 1) == 1;
      i2[n3 % 3 + a2 - 8 - 3][Math.floor(n3 / 3)] = r3;
    }
  }, h2 = function(e3, t3) {
    let n3 = r2 << 3 | t3, o3 = E.getBCHTypeInfo(n3);
    for (let t4 = 0; t4 < 15; t4 += 1) {
      let n4 = !e3 && (o3 >> t4 & 1) == 1;
      t4 < 6 ? i2[t4][8] = n4 : t4 < 8 ? i2[t4 + 1][8] = n4 : i2[a2 - 15 + t4][8] = n4;
    }
    for (let t4 = 0; t4 < 15; t4 += 1) {
      let n4 = !e3 && (o3 >> t4 & 1) == 1;
      t4 < 8 ? i2[8][a2 - t4 - 1] = n4 : t4 < 9 ? i2[8][15 - t4 - 1 + 1] = n4 : i2[8][15 - t4 - 1] = n4;
    }
    i2[a2 - 8][8] = !e3;
  }, g2 = function(e3, t3) {
    let n3 = -1, r3 = a2 - 1, o3 = 7, s3 = 0, c3 = E.getMaskFunction(t3);
    for (let t4 = a2 - 1; t4 > 0; t4 -= 2) for (t4 == 6 && --t4; ; ) {
      for (let n4 = 0; n4 < 2; n4 += 1) if (i2[r3][t4 - n4] == null) {
        let a3 = false;
        s3 < e3.length && (a3 = (e3[s3] >>> o3 & 1) == 1), c3(r3, t4 - n4) && (a3 = !a3), i2[r3][t4 - n4] = a3, --o3, o3 == -1 && (s3 += 1, o3 = 7);
      }
      if (r3 += n3, r3 < 0 || a2 <= r3) {
        r3 -= n3, n3 = -n3;
        break;
      }
    }
  }, _2 = function(e3, t3) {
    let n3 = 0, r3 = 0, i3 = 0, a3 = Array(t3.length), o3 = Array(t3.length);
    for (let s4 = 0; s4 < t3.length; s4 += 1) {
      let c4 = t3[s4].dataCount, l4 = t3[s4].totalCount - c4;
      r3 = Math.max(r3, c4), i3 = Math.max(i3, l4), a3[s4] = Array(c4);
      for (let t4 = 0; t4 < a3[s4].length; t4 += 1) a3[s4][t4] = 255 & e3.getBuffer()[t4 + n3];
      n3 += c4;
      let u3 = E.getErrorCorrectPolynomial(l4), d3 = O(a3[s4], u3.getLength() - 1).mod(u3);
      o3[s4] = Array(u3.getLength() - 1);
      for (let e4 = 0; e4 < o3[s4].length; e4 += 1) {
        let t4 = e4 + d3.getLength() - o3[s4].length;
        o3[s4][e4] = t4 >= 0 ? d3.getAt(t4) : 0;
      }
    }
    let s3 = 0;
    for (let e4 = 0; e4 < t3.length; e4 += 1) s3 += t3[e4].totalCount;
    let c3 = Array(s3), l3 = 0;
    for (let e4 = 0; e4 < r3; e4 += 1) for (let n4 = 0; n4 < t3.length; n4 += 1) e4 < a3[n4].length && (c3[l3] = a3[n4][e4], l3 += 1);
    for (let e4 = 0; e4 < i3; e4 += 1) for (let n4 = 0; n4 < t3.length; n4 += 1) e4 < o3[n4].length && (c3[l3] = o3[n4][e4], l3 += 1);
    return c3;
  }, v2 = function(e3, t3, n3) {
    let r3 = k.getRSBlocks(e3, t3), i3 = ne();
    for (let t4 = 0; t4 < n3.length; t4 += 1) {
      let r4 = n3[t4];
      i3.put(r4.getMode(), 4), i3.put(r4.getLength(), E.getLengthInBits(r4.getMode(), e3)), r4.write(i3);
    }
    let a3 = 0;
    for (let e4 = 0; e4 < r3.length; e4 += 1) a3 += r3[e4].dataCount;
    if (i3.getLengthInBits() > a3 * 8) throw `code length overflow. (` + i3.getLengthInBits() + `>` + a3 * 8 + `)`;
    for (i3.getLengthInBits() + 4 <= a3 * 8 && i3.put(0, 4); i3.getLengthInBits() % 8 != 0; ) i3.putBit(false);
    for (; !(i3.getLengthInBits() >= a3 * 8 || (i3.put(236, 8), i3.getLengthInBits() >= a3 * 8)); ) i3.put(17, 8);
    return _2(i3, r3);
  };
  c2.addData = function(e3, t3) {
    t3 ||= `Byte`;
    let n3 = null;
    switch (t3) {
      case `Numeric`:
        n3 = re(e3);
        break;
      case `Alphanumeric`:
        n3 = ie(e3);
        break;
      case `Byte`:
        n3 = ae(e3);
        break;
      case `Kanji`:
        n3 = oe(e3);
        break;
      default:
        throw `mode:` + t3;
    }
    s2.push(n3), o2 = null;
  }, c2.isDark = function(e3, t3) {
    if (e3 < 0 || a2 <= e3 || t3 < 0 || a2 <= t3) throw e3 + `,` + t3;
    return i2[e3][t3];
  }, c2.getModuleCount = function() {
    return a2;
  }, c2.make = function() {
    if (n2 < 1) {
      let e3 = 1;
      for (; e3 < 40; e3++) {
        let t3 = k.getRSBlocks(e3, r2), n3 = ne();
        for (let t4 = 0; t4 < s2.length; t4++) {
          let r3 = s2[t4];
          n3.put(r3.getMode(), 4), n3.put(r3.getLength(), E.getLengthInBits(r3.getMode(), e3)), r3.write(n3);
        }
        let i3 = 0;
        for (let e4 = 0; e4 < t3.length; e4++) i3 += t3[e4].dataCount;
        if (n3.getLengthInBits() <= i3 * 8) break;
      }
      n2 = e3;
    }
    l2(false, d2());
  }, c2.createTableTag = function(e3, t3) {
    e3 ||= 2, t3 = t3 === void 0 ? e3 * 4 : t3;
    let n3 = ``;
    n3 += `<table style="`, n3 += ` border-width: 0px; border-style: none;`, n3 += ` border-collapse: collapse;`, n3 += ` padding: 0px; margin: ` + t3 + `px;`, n3 += `">`, n3 += `<tbody>`;
    for (let t4 = 0; t4 < c2.getModuleCount(); t4 += 1) {
      n3 += `<tr>`;
      for (let r3 = 0; r3 < c2.getModuleCount(); r3 += 1) n3 += `<td style="`, n3 += ` border-width: 0px; border-style: none;`, n3 += ` border-collapse: collapse;`, n3 += ` padding: 0px; margin: 0px;`, n3 += ` width: ` + e3 + `px;`, n3 += ` height: ` + e3 + `px;`, n3 += ` background-color: `, n3 += c2.isDark(t4, r3) ? `#000000` : `#ffffff`, n3 += `;`, n3 += `"/>`;
      n3 += `</tr>`;
    }
    return n3 += `</tbody>`, n3 += `</table>`, n3;
  }, c2.createSvgTag = function(e3, t3, n3, r3) {
    let i3 = {};
    typeof arguments[0] == `object` && (i3 = arguments[0], e3 = i3.cellSize, t3 = i3.margin, n3 = i3.alt, r3 = i3.title), e3 ||= 2, t3 = t3 === void 0 ? e3 * 4 : t3, n3 = typeof n3 == `string` ? { text: n3 } : n3 || {}, n3.text = n3.text || null, n3.id = n3.text ? n3.id || `qrcode-description` : null, r3 = typeof r3 == `string` ? { text: r3 } : r3 || {}, r3.text = r3.text || null, r3.id = r3.text ? r3.id || `qrcode-title` : null;
    let a3 = c2.getModuleCount() * e3 + t3 * 2, o3, s3, l3, u3, d3 = ``, f3;
    for (f3 = `l` + e3 + `,0 0,` + e3 + ` -` + e3 + `,0 0,-` + e3 + `z `, d3 += `<svg version="1.1" xmlns="http://www.w3.org/2000/svg"`, d3 += i3.scalable ? `` : ` width="` + a3 + `px" height="` + a3 + `px"`, d3 += ` viewBox="0 0 ` + a3 + ` ` + a3 + `" `, d3 += ` preserveAspectRatio="xMinYMin meet"`, d3 += r3.text || n3.text ? ` role="img" aria-labelledby="` + y2([r3.id, n3.id].join(` `).trim()) + `"` : ``, d3 += `>`, d3 += r3.text ? `<title id="` + y2(r3.id) + `">` + y2(r3.text) + `</title>` : ``, d3 += n3.text ? `<description id="` + y2(n3.id) + `">` + y2(n3.text) + `</description>` : ``, d3 += `<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>`, d3 += `<path d="`, l3 = 0; l3 < c2.getModuleCount(); l3 += 1) for (u3 = l3 * e3 + t3, o3 = 0; o3 < c2.getModuleCount(); o3 += 1) c2.isDark(l3, o3) && (s3 = o3 * e3 + t3, d3 += `M` + s3 + `,` + u3 + f3);
    return d3 += `" stroke="transparent" fill="black"/>`, d3 += `</svg>`, d3;
  }, c2.createDataURL = function(e3, t3) {
    e3 ||= 2, t3 = t3 === void 0 ? e3 * 4 : t3;
    let n3 = c2.getModuleCount() * e3 + t3 * 2, r3 = t3, i3 = n3 - t3;
    return ue(n3, n3, function(t4, n4) {
      if (r3 <= t4 && t4 < i3 && r3 <= n4 && n4 < i3) {
        let i4 = Math.floor((t4 - r3) / e3), a3 = Math.floor((n4 - r3) / e3);
        return +!c2.isDark(a3, i4);
      }
      return 1;
    });
  }, c2.createImgTag = function(e3, t3, n3) {
    e3 ||= 2, t3 = t3 === void 0 ? e3 * 4 : t3;
    let r3 = c2.getModuleCount() * e3 + t3 * 2, i3 = ``;
    return i3 += `<img`, i3 += ` src="`, i3 += c2.createDataURL(e3, t3), i3 += `"`, i3 += ` width="`, i3 += r3, i3 += `"`, i3 += ` height="`, i3 += r3, i3 += `"`, n3 && (i3 += ` alt="`, i3 += y2(n3), i3 += `"`), i3 += `/>`, i3;
  };
  let y2 = function(e3) {
    let t3 = ``;
    for (let n3 = 0; n3 < e3.length; n3 += 1) {
      let r3 = e3.charAt(n3);
      switch (r3) {
        case `<`:
          t3 += `&lt;`;
          break;
        case `>`:
          t3 += `&gt;`;
          break;
        case `&`:
          t3 += `&amp;`;
          break;
        case `"`:
          t3 += `&quot;`;
          break;
        default:
          t3 += r3;
      }
    }
    return t3;
  }, b2 = function(e3) {
    e3 = e3 === void 0 ? 2 : e3;
    let t3 = c2.getModuleCount() * 1 + e3 * 2, n3 = e3, r3 = t3 - e3, i3, a3, o3, s3, l3, u3 = { "\u2588\u2588": `\u2588`, "\u2588 ": `\u2580`, " \u2588": `\u2584`, "  ": ` ` }, d3 = { "\u2588\u2588": `\u2580`, "\u2588 ": `\u2580`, " \u2588": ` `, "  ": ` ` }, f3 = ``;
    for (i3 = 0; i3 < t3; i3 += 2) {
      for (o3 = Math.floor((i3 - n3) / 1), s3 = Math.floor((i3 + 1 - n3) / 1), a3 = 0; a3 < t3; a3 += 1) l3 = `\u2588`, n3 <= a3 && a3 < r3 && n3 <= i3 && i3 < r3 && c2.isDark(o3, Math.floor((a3 - n3) / 1)) && (l3 = ` `), n3 <= a3 && a3 < r3 && n3 <= i3 + 1 && i3 + 1 < r3 && c2.isDark(s3, Math.floor((a3 - n3) / 1)) ? l3 += ` ` : l3 += `\u2588`, f3 += e3 < 1 && i3 + 1 >= r3 ? d3[l3] : u3[l3];
      f3 += `
`;
    }
    return t3 % 2 && e3 > 0 ? f3.substring(0, f3.length - t3 - 1) + Array(t3 + 1).join(`\u2580`) : f3.substring(0, f3.length - 1);
  };
  return c2.createASCII = function(e3, t3) {
    if (e3 ||= 1, e3 < 2) return b2(t3);
    --e3, t3 = t3 === void 0 ? e3 * 2 : t3;
    let n3 = c2.getModuleCount() * e3 + t3 * 2, r3 = t3, i3 = n3 - t3, a3, o3, s3, l3, u3 = Array(e3 + 1).join(`\u2588\u2588`), d3 = Array(e3 + 1).join(`  `), f3 = ``, p3 = ``;
    for (a3 = 0; a3 < n3; a3 += 1) {
      for (s3 = Math.floor((a3 - r3) / e3), p3 = ``, o3 = 0; o3 < n3; o3 += 1) l3 = 1, r3 <= o3 && o3 < i3 && r3 <= a3 && a3 < i3 && c2.isDark(s3, Math.floor((o3 - r3) / e3)) && (l3 = 0), p3 += l3 ? u3 : d3;
      for (s3 = 0; s3 < e3; s3 += 1) f3 += p3 + `
`;
    }
    return f3.substring(0, f3.length - 1);
  }, c2.renderTo2dContext = function(e3, t3) {
    t3 ||= 2;
    let n3 = c2.getModuleCount();
    for (let r3 = 0; r3 < n3; r3++) for (let i3 = 0; i3 < n3; i3++) e3.fillStyle = c2.isDark(r3, i3) ? `black` : `white`, e3.fillRect(i3 * t3, r3 * t3, t3, t3);
  }, c2;
};
S.stringToBytes = function(e2) {
  let t2 = [];
  for (let n2 = 0; n2 < e2.length; n2 += 1) {
    let r2 = e2.charCodeAt(n2);
    t2.push(r2 & 255);
  }
  return t2;
}, S.createStringToBytes = function(e2, t2) {
  let n2 = (function() {
    let n3 = ce(e2), r2 = function() {
      let e3 = n3.read();
      if (e3 == -1) throw `eof`;
      return e3;
    }, i2 = 0, a2 = {};
    for (; ; ) {
      let e3 = n3.read();
      if (e3 == -1) break;
      let t3 = r2(), o2 = r2(), s2 = r2(), c2 = String.fromCharCode(e3 << 8 | t3);
      a2[c2] = o2 << 8 | s2, i2 += 1;
    }
    if (i2 != t2) throw i2 + ` != ` + t2;
    return a2;
  })();
  return function(e3) {
    let t3 = [];
    for (let r2 = 0; r2 < e3.length; r2 += 1) {
      let i2 = e3.charCodeAt(r2);
      if (i2 < 128) t3.push(i2);
      else {
        let i3 = n2[e3.charAt(r2)];
        typeof i3 == `number` ? (i3 & 255) == i3 ? t3.push(i3) : (t3.push(i3 >>> 8), t3.push(i3 & 255)) : t3.push(63);
      }
    }
    return t3;
  };
};
var C = { MODE_NUMBER: 1, MODE_ALPHA_NUM: 2, MODE_8BIT_BYTE: 4, MODE_KANJI: 8 }, w = { L: 1, M: 0, Q: 3, H: 2 }, T = { PATTERN000: 0, PATTERN001: 1, PATTERN010: 2, PATTERN011: 3, PATTERN100: 4, PATTERN101: 5, PATTERN110: 6, PATTERN111: 7 }, E = (function() {
  let e2 = [[], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50], [6, 30, 54], [6, 32, 58], [6, 34, 62], [6, 26, 46, 66], [6, 26, 48, 70], [6, 26, 50, 74], [6, 30, 54, 78], [6, 30, 56, 82], [6, 30, 58, 86], [6, 34, 62, 90], [6, 28, 50, 72, 94], [6, 26, 50, 74, 98], [6, 30, 54, 78, 102], [6, 28, 54, 80, 106], [6, 32, 58, 84, 110], [6, 30, 58, 86, 114], [6, 34, 62, 90, 118], [6, 26, 50, 74, 98, 122], [6, 30, 54, 78, 102, 126], [6, 26, 52, 78, 104, 130], [6, 30, 56, 82, 108, 134], [6, 34, 60, 86, 112, 138], [6, 30, 58, 86, 114, 142], [6, 34, 62, 90, 118, 146], [6, 30, 54, 78, 102, 126, 150], [6, 24, 50, 76, 102, 128, 154], [6, 28, 54, 80, 106, 132, 158], [6, 32, 58, 84, 110, 136, 162], [6, 26, 54, 82, 110, 138, 166], [6, 30, 58, 86, 114, 142, 170]], t2 = 1335, n2 = 7973, r2 = {}, i2 = function(e3) {
    let t3 = 0;
    for (; e3 != 0; ) t3 += 1, e3 >>>= 1;
    return t3;
  };
  return r2.getBCHTypeInfo = function(e3) {
    let n3 = e3 << 10;
    for (; i2(n3) - i2(t2) >= 0; ) n3 ^= t2 << i2(n3) - i2(t2);
    return (e3 << 10 | n3) ^ 21522;
  }, r2.getBCHTypeNumber = function(e3) {
    let t3 = e3 << 12;
    for (; i2(t3) - i2(n2) >= 0; ) t3 ^= n2 << i2(t3) - i2(n2);
    return e3 << 12 | t3;
  }, r2.getPatternPosition = function(t3) {
    return e2[t3 - 1];
  }, r2.getMaskFunction = function(e3) {
    switch (e3) {
      case T.PATTERN000:
        return function(e4, t3) {
          return (e4 + t3) % 2 == 0;
        };
      case T.PATTERN001:
        return function(e4, t3) {
          return e4 % 2 == 0;
        };
      case T.PATTERN010:
        return function(e4, t3) {
          return t3 % 3 == 0;
        };
      case T.PATTERN011:
        return function(e4, t3) {
          return (e4 + t3) % 3 == 0;
        };
      case T.PATTERN100:
        return function(e4, t3) {
          return (Math.floor(e4 / 2) + Math.floor(t3 / 3)) % 2 == 0;
        };
      case T.PATTERN101:
        return function(e4, t3) {
          return e4 * t3 % 2 + e4 * t3 % 3 == 0;
        };
      case T.PATTERN110:
        return function(e4, t3) {
          return (e4 * t3 % 2 + e4 * t3 % 3) % 2 == 0;
        };
      case T.PATTERN111:
        return function(e4, t3) {
          return (e4 * t3 % 3 + (e4 + t3) % 2) % 2 == 0;
        };
      default:
        throw `bad maskPattern:` + e3;
    }
  }, r2.getErrorCorrectPolynomial = function(e3) {
    let t3 = O([1], 0);
    for (let n3 = 0; n3 < e3; n3 += 1) t3 = t3.multiply(O([1, D.gexp(n3)], 0));
    return t3;
  }, r2.getLengthInBits = function(e3, t3) {
    if (1 <= t3 && t3 < 10) switch (e3) {
      case C.MODE_NUMBER:
        return 10;
      case C.MODE_ALPHA_NUM:
        return 9;
      case C.MODE_8BIT_BYTE:
        return 8;
      case C.MODE_KANJI:
        return 8;
      default:
        throw `mode:` + e3;
    }
    else if (t3 < 27) switch (e3) {
      case C.MODE_NUMBER:
        return 12;
      case C.MODE_ALPHA_NUM:
        return 11;
      case C.MODE_8BIT_BYTE:
        return 16;
      case C.MODE_KANJI:
        return 10;
      default:
        throw `mode:` + e3;
    }
    else if (t3 < 41) switch (e3) {
      case C.MODE_NUMBER:
        return 14;
      case C.MODE_ALPHA_NUM:
        return 13;
      case C.MODE_8BIT_BYTE:
        return 16;
      case C.MODE_KANJI:
        return 12;
      default:
        throw `mode:` + e3;
    }
    else throw `type:` + t3;
  }, r2.getLostPoint = function(e3) {
    let t3 = e3.getModuleCount(), n3 = 0;
    for (let r4 = 0; r4 < t3; r4 += 1) for (let i4 = 0; i4 < t3; i4 += 1) {
      let a2 = 0, o2 = e3.isDark(r4, i4);
      for (let n4 = -1; n4 <= 1; n4 += 1) if (!(r4 + n4 < 0 || t3 <= r4 + n4)) for (let s2 = -1; s2 <= 1; s2 += 1) i4 + s2 < 0 || t3 <= i4 + s2 || (n4 != 0 || s2 != 0) && o2 == e3.isDark(r4 + n4, i4 + s2) && (a2 += 1);
      a2 > 5 && (n3 += 3 + a2 - 5);
    }
    for (let r4 = 0; r4 < t3 - 1; r4 += 1) for (let i4 = 0; i4 < t3 - 1; i4 += 1) {
      let t4 = 0;
      e3.isDark(r4, i4) && (t4 += 1), e3.isDark(r4 + 1, i4) && (t4 += 1), e3.isDark(r4, i4 + 1) && (t4 += 1), e3.isDark(r4 + 1, i4 + 1) && (t4 += 1), (t4 == 0 || t4 == 4) && (n3 += 3);
    }
    for (let r4 = 0; r4 < t3; r4 += 1) for (let i4 = 0; i4 < t3 - 6; i4 += 1) e3.isDark(r4, i4) && !e3.isDark(r4, i4 + 1) && e3.isDark(r4, i4 + 2) && e3.isDark(r4, i4 + 3) && e3.isDark(r4, i4 + 4) && !e3.isDark(r4, i4 + 5) && e3.isDark(r4, i4 + 6) && (n3 += 40);
    for (let r4 = 0; r4 < t3; r4 += 1) for (let i4 = 0; i4 < t3 - 6; i4 += 1) e3.isDark(i4, r4) && !e3.isDark(i4 + 1, r4) && e3.isDark(i4 + 2, r4) && e3.isDark(i4 + 3, r4) && e3.isDark(i4 + 4, r4) && !e3.isDark(i4 + 5, r4) && e3.isDark(i4 + 6, r4) && (n3 += 40);
    let r3 = 0;
    for (let n4 = 0; n4 < t3; n4 += 1) for (let i4 = 0; i4 < t3; i4 += 1) e3.isDark(i4, n4) && (r3 += 1);
    let i3 = Math.abs(100 * r3 / t3 / t3 - 50) / 5;
    return n3 += i3 * 10, n3;
  }, r2;
})(), D = (function() {
  let e2 = Array(256), t2 = Array(256);
  for (let t3 = 0; t3 < 8; t3 += 1) e2[t3] = 1 << t3;
  for (let t3 = 8; t3 < 256; t3 += 1) e2[t3] = e2[t3 - 4] ^ e2[t3 - 5] ^ e2[t3 - 6] ^ e2[t3 - 8];
  for (let n3 = 0; n3 < 255; n3 += 1) t2[e2[n3]] = n3;
  let n2 = {};
  return n2.glog = function(e3) {
    if (e3 < 1) throw `glog(` + e3 + `)`;
    return t2[e3];
  }, n2.gexp = function(t3) {
    for (; t3 < 0; ) t3 += 255;
    for (; t3 >= 256; ) t3 -= 255;
    return e2[t3];
  }, n2;
})(), O = function(e2, t2) {
  if (e2.length === void 0) throw e2.length + `/` + t2;
  let n2 = (function() {
    let n3 = 0;
    for (; n3 < e2.length && e2[n3] == 0; ) n3 += 1;
    let r3 = Array(e2.length - n3 + t2);
    for (let t3 = 0; t3 < e2.length - n3; t3 += 1) r3[t3] = e2[t3 + n3];
    return r3;
  })(), r2 = {};
  return r2.getAt = function(e3) {
    return n2[e3];
  }, r2.getLength = function() {
    return n2.length;
  }, r2.multiply = function(e3) {
    let t3 = Array(r2.getLength() + e3.getLength() - 1);
    for (let n3 = 0; n3 < r2.getLength(); n3 += 1) for (let i2 = 0; i2 < e3.getLength(); i2 += 1) t3[n3 + i2] ^= D.gexp(D.glog(r2.getAt(n3)) + D.glog(e3.getAt(i2)));
    return O(t3, 0);
  }, r2.mod = function(e3) {
    if (r2.getLength() - e3.getLength() < 0) return r2;
    let t3 = D.glog(r2.getAt(0)) - D.glog(e3.getAt(0)), n3 = Array(r2.getLength());
    for (let e4 = 0; e4 < r2.getLength(); e4 += 1) n3[e4] = r2.getAt(e4);
    for (let r3 = 0; r3 < e3.getLength(); r3 += 1) n3[r3] ^= D.gexp(D.glog(e3.getAt(r3)) + t3);
    return O(n3, 0).mod(e3);
  }, r2;
}, k = (function() {
  let e2 = [[1, 26, 19], [1, 26, 16], [1, 26, 13], [1, 26, 9], [1, 44, 34], [1, 44, 28], [1, 44, 22], [1, 44, 16], [1, 70, 55], [1, 70, 44], [2, 35, 17], [2, 35, 13], [1, 100, 80], [2, 50, 32], [2, 50, 24], [4, 25, 9], [1, 134, 108], [2, 67, 43], [2, 33, 15, 2, 34, 16], [2, 33, 11, 2, 34, 12], [2, 86, 68], [4, 43, 27], [4, 43, 19], [4, 43, 15], [2, 98, 78], [4, 49, 31], [2, 32, 14, 4, 33, 15], [4, 39, 13, 1, 40, 14], [2, 121, 97], [2, 60, 38, 2, 61, 39], [4, 40, 18, 2, 41, 19], [4, 40, 14, 2, 41, 15], [2, 146, 116], [3, 58, 36, 2, 59, 37], [4, 36, 16, 4, 37, 17], [4, 36, 12, 4, 37, 13], [2, 86, 68, 2, 87, 69], [4, 69, 43, 1, 70, 44], [6, 43, 19, 2, 44, 20], [6, 43, 15, 2, 44, 16], [4, 101, 81], [1, 80, 50, 4, 81, 51], [4, 50, 22, 4, 51, 23], [3, 36, 12, 8, 37, 13], [2, 116, 92, 2, 117, 93], [6, 58, 36, 2, 59, 37], [4, 46, 20, 6, 47, 21], [7, 42, 14, 4, 43, 15], [4, 133, 107], [8, 59, 37, 1, 60, 38], [8, 44, 20, 4, 45, 21], [12, 33, 11, 4, 34, 12], [3, 145, 115, 1, 146, 116], [4, 64, 40, 5, 65, 41], [11, 36, 16, 5, 37, 17], [11, 36, 12, 5, 37, 13], [5, 109, 87, 1, 110, 88], [5, 65, 41, 5, 66, 42], [5, 54, 24, 7, 55, 25], [11, 36, 12, 7, 37, 13], [5, 122, 98, 1, 123, 99], [7, 73, 45, 3, 74, 46], [15, 43, 19, 2, 44, 20], [3, 45, 15, 13, 46, 16], [1, 135, 107, 5, 136, 108], [10, 74, 46, 1, 75, 47], [1, 50, 22, 15, 51, 23], [2, 42, 14, 17, 43, 15], [5, 150, 120, 1, 151, 121], [9, 69, 43, 4, 70, 44], [17, 50, 22, 1, 51, 23], [2, 42, 14, 19, 43, 15], [3, 141, 113, 4, 142, 114], [3, 70, 44, 11, 71, 45], [17, 47, 21, 4, 48, 22], [9, 39, 13, 16, 40, 14], [3, 135, 107, 5, 136, 108], [3, 67, 41, 13, 68, 42], [15, 54, 24, 5, 55, 25], [15, 43, 15, 10, 44, 16], [4, 144, 116, 4, 145, 117], [17, 68, 42], [17, 50, 22, 6, 51, 23], [19, 46, 16, 6, 47, 17], [2, 139, 111, 7, 140, 112], [17, 74, 46], [7, 54, 24, 16, 55, 25], [34, 37, 13], [4, 151, 121, 5, 152, 122], [4, 75, 47, 14, 76, 48], [11, 54, 24, 14, 55, 25], [16, 45, 15, 14, 46, 16], [6, 147, 117, 4, 148, 118], [6, 73, 45, 14, 74, 46], [11, 54, 24, 16, 55, 25], [30, 46, 16, 2, 47, 17], [8, 132, 106, 4, 133, 107], [8, 75, 47, 13, 76, 48], [7, 54, 24, 22, 55, 25], [22, 45, 15, 13, 46, 16], [10, 142, 114, 2, 143, 115], [19, 74, 46, 4, 75, 47], [28, 50, 22, 6, 51, 23], [33, 46, 16, 4, 47, 17], [8, 152, 122, 4, 153, 123], [22, 73, 45, 3, 74, 46], [8, 53, 23, 26, 54, 24], [12, 45, 15, 28, 46, 16], [3, 147, 117, 10, 148, 118], [3, 73, 45, 23, 74, 46], [4, 54, 24, 31, 55, 25], [11, 45, 15, 31, 46, 16], [7, 146, 116, 7, 147, 117], [21, 73, 45, 7, 74, 46], [1, 53, 23, 37, 54, 24], [19, 45, 15, 26, 46, 16], [5, 145, 115, 10, 146, 116], [19, 75, 47, 10, 76, 48], [15, 54, 24, 25, 55, 25], [23, 45, 15, 25, 46, 16], [13, 145, 115, 3, 146, 116], [2, 74, 46, 29, 75, 47], [42, 54, 24, 1, 55, 25], [23, 45, 15, 28, 46, 16], [17, 145, 115], [10, 74, 46, 23, 75, 47], [10, 54, 24, 35, 55, 25], [19, 45, 15, 35, 46, 16], [17, 145, 115, 1, 146, 116], [14, 74, 46, 21, 75, 47], [29, 54, 24, 19, 55, 25], [11, 45, 15, 46, 46, 16], [13, 145, 115, 6, 146, 116], [14, 74, 46, 23, 75, 47], [44, 54, 24, 7, 55, 25], [59, 46, 16, 1, 47, 17], [12, 151, 121, 7, 152, 122], [12, 75, 47, 26, 76, 48], [39, 54, 24, 14, 55, 25], [22, 45, 15, 41, 46, 16], [6, 151, 121, 14, 152, 122], [6, 75, 47, 34, 76, 48], [46, 54, 24, 10, 55, 25], [2, 45, 15, 64, 46, 16], [17, 152, 122, 4, 153, 123], [29, 74, 46, 14, 75, 47], [49, 54, 24, 10, 55, 25], [24, 45, 15, 46, 46, 16], [4, 152, 122, 18, 153, 123], [13, 74, 46, 32, 75, 47], [48, 54, 24, 14, 55, 25], [42, 45, 15, 32, 46, 16], [20, 147, 117, 4, 148, 118], [40, 75, 47, 7, 76, 48], [43, 54, 24, 22, 55, 25], [10, 45, 15, 67, 46, 16], [19, 148, 118, 6, 149, 119], [18, 75, 47, 31, 76, 48], [34, 54, 24, 34, 55, 25], [20, 45, 15, 61, 46, 16]], t2 = function(e3, t3) {
    let n3 = {};
    return n3.totalCount = e3, n3.dataCount = t3, n3;
  }, n2 = {}, r2 = function(t3, n3) {
    switch (n3) {
      case w.L:
        return e2[(t3 - 1) * 4 + 0];
      case w.M:
        return e2[(t3 - 1) * 4 + 1];
      case w.Q:
        return e2[(t3 - 1) * 4 + 2];
      case w.H:
        return e2[(t3 - 1) * 4 + 3];
      default:
        return;
    }
  };
  return n2.getRSBlocks = function(e3, n3) {
    let i2 = r2(e3, n3);
    if (i2 === void 0) throw `bad rs block @ typeNumber:` + e3 + `/errorCorrectionLevel:` + n3;
    let a2 = i2.length / 3, o2 = [];
    for (let e4 = 0; e4 < a2; e4 += 1) {
      let n4 = i2[e4 * 3 + 0], r3 = i2[e4 * 3 + 1], a3 = i2[e4 * 3 + 2];
      for (let e5 = 0; e5 < n4; e5 += 1) o2.push(t2(r3, a3));
    }
    return o2;
  }, n2;
})(), ne = function() {
  let e2 = [], t2 = 0, n2 = {};
  return n2.getBuffer = function() {
    return e2;
  }, n2.getAt = function(t3) {
    let n3 = Math.floor(t3 / 8);
    return (e2[n3] >>> 7 - t3 % 8 & 1) == 1;
  }, n2.put = function(e3, t3) {
    for (let r2 = 0; r2 < t3; r2 += 1) n2.putBit((e3 >>> t3 - r2 - 1 & 1) == 1);
  }, n2.getLengthInBits = function() {
    return t2;
  }, n2.putBit = function(n3) {
    let r2 = Math.floor(t2 / 8);
    e2.length <= r2 && e2.push(0), n3 && (e2[r2] |= 128 >>> t2 % 8), t2 += 1;
  }, n2;
}, re = function(e2) {
  let t2 = C.MODE_NUMBER, n2 = e2, r2 = {};
  r2.getMode = function() {
    return t2;
  }, r2.getLength = function(e3) {
    return n2.length;
  }, r2.write = function(e3) {
    let t3 = n2, r3 = 0;
    for (; r3 + 2 < t3.length; ) e3.put(i2(t3.substring(r3, r3 + 3)), 10), r3 += 3;
    r3 < t3.length && (t3.length - r3 == 1 ? e3.put(i2(t3.substring(r3, r3 + 1)), 4) : t3.length - r3 == 2 && e3.put(i2(t3.substring(r3, r3 + 2)), 7));
  };
  let i2 = function(e3) {
    let t3 = 0;
    for (let n3 = 0; n3 < e3.length; n3 += 1) t3 = t3 * 10 + a2(e3.charAt(n3));
    return t3;
  }, a2 = function(e3) {
    if (`0` <= e3 && e3 <= `9`) return e3.charCodeAt(0) - 48;
    throw `illegal char :` + e3;
  };
  return r2;
}, ie = function(e2) {
  let t2 = C.MODE_ALPHA_NUM, n2 = e2, r2 = {};
  r2.getMode = function() {
    return t2;
  }, r2.getLength = function(e3) {
    return n2.length;
  }, r2.write = function(e3) {
    let t3 = n2, r3 = 0;
    for (; r3 + 1 < t3.length; ) e3.put(i2(t3.charAt(r3)) * 45 + i2(t3.charAt(r3 + 1)), 11), r3 += 2;
    r3 < t3.length && e3.put(i2(t3.charAt(r3)), 6);
  };
  let i2 = function(e3) {
    if (`0` <= e3 && e3 <= `9`) return e3.charCodeAt(0) - 48;
    if (`A` <= e3 && e3 <= `Z`) return e3.charCodeAt(0) - 65 + 10;
    switch (e3) {
      case ` `:
        return 36;
      case `$`:
        return 37;
      case `%`:
        return 38;
      case `*`:
        return 39;
      case `+`:
        return 40;
      case `-`:
        return 41;
      case `.`:
        return 42;
      case `/`:
        return 43;
      case `:`:
        return 44;
      default:
        throw `illegal char :` + e3;
    }
  };
  return r2;
}, ae = function(e2) {
  let t2 = C.MODE_8BIT_BYTE, n2 = S.stringToBytes(e2), r2 = {};
  return r2.getMode = function() {
    return t2;
  }, r2.getLength = function(e3) {
    return n2.length;
  }, r2.write = function(e3) {
    for (let t3 = 0; t3 < n2.length; t3 += 1) e3.put(n2[t3], 8);
  }, r2;
}, oe = function(e2) {
  let t2 = C.MODE_KANJI, n2 = S.stringToBytes;
  (function(e3, t3) {
    let r3 = n2(e3);
    if (r3.length != 2 || (r3[0] << 8 | r3[1]) != t3) throw `sjis not supported.`;
  })(`\u53CB`, 38726);
  let r2 = n2(e2), i2 = {};
  return i2.getMode = function() {
    return t2;
  }, i2.getLength = function(e3) {
    return ~~(r2.length / 2);
  }, i2.write = function(e3) {
    let t3 = r2, n3 = 0;
    for (; n3 + 1 < t3.length; ) {
      let r3 = (255 & t3[n3]) << 8 | 255 & t3[n3 + 1];
      if (33088 <= r3 && r3 <= 40956) r3 -= 33088;
      else if (57408 <= r3 && r3 <= 60351) r3 -= 49472;
      else throw `illegal char at ` + (n3 + 1) + `/` + r3;
      r3 = (r3 >>> 8 & 255) * 192 + (r3 & 255), e3.put(r3, 13), n3 += 2;
    }
    if (n3 < t3.length) throw `illegal char at ` + (n3 + 1);
  }, i2;
}, A = function() {
  let e2 = [], t2 = {};
  return t2.writeByte = function(t3) {
    e2.push(t3 & 255);
  }, t2.writeShort = function(e3) {
    t2.writeByte(e3), t2.writeByte(e3 >>> 8);
  }, t2.writeBytes = function(e3, n2, r2) {
    n2 ||= 0, r2 ||= e3.length;
    for (let i2 = 0; i2 < r2; i2 += 1) t2.writeByte(e3[i2 + n2]);
  }, t2.writeString = function(e3) {
    for (let n2 = 0; n2 < e3.length; n2 += 1) t2.writeByte(e3.charCodeAt(n2));
  }, t2.toByteArray = function() {
    return e2;
  }, t2.toString = function() {
    let t3 = ``;
    t3 += `[`;
    for (let n2 = 0; n2 < e2.length; n2 += 1) n2 > 0 && (t3 += `,`), t3 += e2[n2];
    return t3 += `]`, t3;
  }, t2;
}, se = function() {
  let e2 = 0, t2 = 0, n2 = 0, r2 = ``, i2 = {}, a2 = function(e3) {
    r2 += String.fromCharCode(o2(e3 & 63));
  }, o2 = function(e3) {
    if (e3 < 0) throw `n:` + e3;
    if (e3 < 26) return 65 + e3;
    if (e3 < 52) return 97 + (e3 - 26);
    if (e3 < 62) return 48 + (e3 - 52);
    if (e3 == 62) return 43;
    if (e3 == 63) return 47;
    throw `n:` + e3;
  };
  return i2.writeByte = function(r3) {
    for (e2 = e2 << 8 | r3 & 255, t2 += 8, n2 += 1; t2 >= 6; ) a2(e2 >>> t2 - 6), t2 -= 6;
  }, i2.flush = function() {
    if (t2 > 0 && (a2(e2 << 6 - t2), e2 = 0, t2 = 0), n2 % 3 != 0) {
      let e3 = 3 - n2 % 3;
      for (let t3 = 0; t3 < e3; t3 += 1) r2 += `=`;
    }
  }, i2.toString = function() {
    return r2;
  }, i2;
}, ce = function(e2) {
  let t2 = e2, n2 = 0, r2 = 0, i2 = 0, a2 = {};
  a2.read = function() {
    for (; i2 < 8; ) {
      if (n2 >= t2.length) {
        if (i2 == 0) return -1;
        throw `unexpected end of file./` + i2;
      }
      let e4 = t2.charAt(n2);
      if (n2 += 1, e4 == `=`) return i2 = 0, -1;
      e4.match(/^\s$/) || (r2 = r2 << 6 | o2(e4.charCodeAt(0)), i2 += 6);
    }
    let e3 = r2 >>> i2 - 8 & 255;
    return i2 -= 8, e3;
  };
  let o2 = function(e3) {
    if (65 <= e3 && e3 <= 90) return e3 - 65;
    if (97 <= e3 && e3 <= 122) return e3 - 97 + 26;
    if (48 <= e3 && e3 <= 57) return e3 - 48 + 52;
    if (e3 == 43) return 62;
    if (e3 == 47) return 63;
    throw `c:` + e3;
  };
  return a2;
}, le = function(e2, t2) {
  let n2 = e2, r2 = t2, i2 = Array(e2 * t2), a2 = {};
  a2.setPixel = function(e3, t3, r3) {
    i2[t3 * n2 + e3] = r3;
  }, a2.write = function(e3) {
    e3.writeString(`GIF87a`), e3.writeShort(n2), e3.writeShort(r2), e3.writeByte(128), e3.writeByte(0), e3.writeByte(0), e3.writeByte(0), e3.writeByte(0), e3.writeByte(0), e3.writeByte(255), e3.writeByte(255), e3.writeByte(255), e3.writeString(`,`), e3.writeShort(0), e3.writeShort(0), e3.writeShort(n2), e3.writeShort(r2), e3.writeByte(0);
    let t3 = s2(2);
    e3.writeByte(2);
    let i3 = 0;
    for (; t3.length - i3 > 255; ) e3.writeByte(255), e3.writeBytes(t3, i3, 255), i3 += 255;
    e3.writeByte(t3.length - i3), e3.writeBytes(t3, i3, t3.length - i3), e3.writeByte(0), e3.writeString(`;`);
  };
  let o2 = function(e3) {
    let t3 = e3, n3 = 0, r3 = 0, i3 = {};
    return i3.write = function(e4, i4) {
      if (e4 >>> i4) throw `length over`;
      for (; n3 + i4 >= 8; ) t3.writeByte(255 & (e4 << n3 | r3)), i4 -= 8 - n3, e4 >>>= 8 - n3, r3 = 0, n3 = 0;
      r3 = e4 << n3 | r3, n3 += i4;
    }, i3.flush = function() {
      n3 > 0 && t3.writeByte(r3);
    }, i3;
  }, s2 = function(e3) {
    let t3 = 1 << e3, n3 = (1 << e3) + 1, r3 = e3 + 1, a3 = c2();
    for (let e4 = 0; e4 < t3; e4 += 1) a3.add(String.fromCharCode(e4));
    a3.add(String.fromCharCode(t3)), a3.add(String.fromCharCode(n3));
    let s3 = A(), l2 = o2(s3);
    l2.write(t3, r3);
    let u2 = 0, d2 = String.fromCharCode(i2[u2]);
    for (u2 += 1; u2 < i2.length; ) {
      let e4 = String.fromCharCode(i2[u2]);
      u2 += 1, a3.contains(d2 + e4) ? d2 += e4 : (l2.write(a3.indexOf(d2), r3), a3.size() < 4095 && (a3.size() == 1 << r3 && (r3 += 1), a3.add(d2 + e4)), d2 = e4);
    }
    return l2.write(a3.indexOf(d2), r3), l2.write(n3, r3), l2.flush(), s3.toByteArray();
  }, c2 = function() {
    let e3 = {}, t3 = 0, n3 = {};
    return n3.add = function(r3) {
      if (n3.contains(r3)) throw `dup key:` + r3;
      e3[r3] = t3, t3 += 1;
    }, n3.size = function() {
      return t3;
    }, n3.indexOf = function(t4) {
      return e3[t4];
    }, n3.contains = function(t4) {
      return e3[t4] !== void 0;
    }, n3;
  };
  return a2;
}, ue = function(e2, t2, n2) {
  let r2 = le(e2, t2);
  for (let i3 = 0; i3 < t2; i3 += 1) for (let t3 = 0; t3 < e2; t3 += 1) r2.setPixel(t3, i3, n2(t3, i3));
  let i2 = A();
  r2.write(i2);
  let a2 = se(), o2 = i2.toByteArray();
  for (let e3 = 0; e3 < o2.length; e3 += 1) a2.writeByte(o2[e3]);
  return a2.flush(), `data:image/gif;base64,` + a2;
};
S.stringToBytes;
function de(e2) {
  let t2 = S(0, `M`);
  t2.addData(String.fromCharCode(...new TextEncoder().encode(e2)), `Byte`), t2.make();
  let n2 = t2.getModuleCount();
  return Array.from({ length: n2 }, (e3, r2) => Array.from({ length: n2 }, (e4, n3) => t2.isDark(r2, n3)));
}
function fe(e2) {
  let t2 = e2.length, n2 = ``;
  for (let r2 = 0; r2 < t2; r2++) {
    let i2 = e2[r2], a2 = 0;
    for (; a2 < t2; ) {
      if (!i2[a2]) {
        a2++;
        continue;
      }
      let e3 = a2;
      for (; a2 < t2 && i2[a2]; ) a2++;
      n2 += `M${e3 + 4} ${r2 + 4}h${a2 - e3}v1h-${a2 - e3}z`;
    }
  }
  return { d: n2, side: t2 + 8 };
}
function j(e2) {
  if (!e2.startsWith(`did:webvh:`)) return e2 ? [{ text: e2, role: `opaque` }] : [];
  let t2 = e2.split(`:`), n2 = t2[2], r2 = t2[3];
  if (!n2 || !r2) return [{ text: e2, role: `opaque` }];
  let i2 = [{ text: `did:webvh:`, role: `method` }, { text: n2, role: `opaque` }, { text: `:`, role: `method` }, { text: r2, role: `host` }], a2 = t2.slice(4);
  return a2.length > 0 && i2.push({ text: `:${a2.join(`:`)}`, role: `path` }), i2;
}
function M(e2) {
  return j(e2).find((e3) => e3.role === `host`)?.text;
}
function pe(e2, t2 = 10) {
  let n2 = j(e2);
  if (!n2.some((e3) => e3.role === `host`)) {
    let e3 = n2[0];
    return !e3 || e3.text.length <= 48 ? n2 : [{ text: `${e3.text.slice(0, 22)}\u2026${e3.text.slice(-12)}`, role: e3.role }];
  }
  return n2.map((e3) => e3.role === `opaque` && e3.text.length > t2 ? { text: `${e3.text.slice(0, t2)}\u2026`, role: e3.role } : e3);
}
function me(e2) {
  return e2.includes(`/@`);
}
function N(e2) {
  let t2 = e2.trim();
  if (!t2 || !t2.includes(`/@`)) return null;
  let n2 = t2.includes(`://`) ? t2 : `https://${t2}`, r2;
  try {
    r2 = new URL(n2);
  } catch {
    return null;
  }
  if (r2.protocol !== `https:` && r2.protocol !== `http:` || !r2.hostname) return null;
  let i2 = r2.protocol.replace(`:`, ``), a2 = r2.port ? `${r2.hostname}:${r2.port}` : r2.hostname, o2 = r2.pathname.split(`/`).filter((e3) => e3.length > 0);
  if (o2.length === 0) return null;
  let s2 = o2.shift();
  if (!s2.startsWith(`@`)) return null;
  let c2 = s2.slice(1);
  return c2 === `` && o2.length > 0 || o2.some((e3) => e3.startsWith(`@`)) ? null : { canonical: [`${i2}://${a2}/@${c2}`, ...o2].join(`/`), authority: a2, localName: c2, pathSegments: o2 };
}
function P(e2) {
  return e2.canonical.replace(/^https?:\/\//, ``);
}
function F(e2) {
  return e2.localName === `` ? `${e2.authority} (community)` : P(e2);
}
function he(e2) {
  return e2 ? e2.map(N).filter((e3) => e3 !== null) : [];
}
var I = e(t(), 1), L = r(), R = { method: { color: m.faint }, opaque: { color: m.muted }, host: { color: m.text, fontWeight: 620 }, path: { color: m.faint } };
function z({ value: e2, verified: t2 = false, size: n2 = h.sm, href: r2, title: i2, qr: a2 = true }) {
  let o2 = (0, L.jsx)(ge, { value: e2, verified: t2, size: n2, href: r2, title: i2 });
  return a2 ? (0, L.jsxs)(`span`, { style: { minWidth: 0 }, children: [o2, (0, L.jsx)(J, { value: e2 })] }) : o2;
}
function ge({ value: e2, verified: t2, size: n2, href: r2, title: i2 }) {
  let a2 = j(e2), o2 = M(e2);
  return (0, L.jsx)(r2 ? `a` : `span`, { ...r2 ? { href: r2, title: i2 ?? void 0, onClick: (e3) => e3.stopPropagation(), className: `did-link` } : {}, style: { fontFamily: _.mono, fontSize: n2, wordBreak: `break-all`, lineHeight: 1.45, ...r2 ? { color: `inherit`, textDecoration: `none`, borderBottom: `1px dotted ${m.faint}` } : {} }, "aria-label": o2 ? `DID at ${o2}: ${e2}` : e2, children: a2.map((e3, n3) => (0, L.jsx)(`span`, { style: e3.role === `host` && t2 ? { ...R.host, color: m.ok } : R[e3.role], children: e3.text }, n3)) });
}
function _e({ value: e2, agentName: t2, verified: n2 = false, suffix: r2 }) {
  let i2 = t2 ? F(t2) : void 0, a2 = M(e2);
  return !i2 && !a2 ? (0, L.jsx)(z, { value: e2, verified: n2 }) : (0, L.jsxs)(`div`, { style: { display: `grid`, gap: 3, minWidth: 0 }, children: [(0, L.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 8, flexWrap: `wrap` }, children: [(0, L.jsx)(`span`, { style: { fontSize: h.base, fontWeight: 640, color: n2 ? m.ok : m.text, wordBreak: `break-word` }, children: i2 ?? a2 }), r2] }), (0, L.jsx)(z, { value: e2, size: h.xs })] });
}
function ve({ tone: e2, children: t2 }) {
  return (0, L.jsx)(`span`, { style: ee(e2), children: t2 });
}
function B({ kind: e2 = `default`, onClick: t2, disabled: n2, title: r2, children: i2, style: a2 }) {
  return (0, L.jsx)(`button`, { onClick: t2, disabled: n2, title: r2, style: { ...x(e2), ...n2 ? { opacity: 0.5, cursor: `default` } : {}, ...a2 }, children: i2 });
}
var V = (0, I.createContext)(false);
function H({ children: e2 }) {
  let [t2, n2] = (0, I.useState)(false), r2 = (0, I.useRef)(null), [i2, a2] = (0, I.useState)(false);
  return (0, I.useLayoutEffect)(() => {
    let e3 = r2.current;
    e3 && a2(e3.scrollHeight > e3.clientHeight + 1);
  }, [e2]), (0, L.jsxs)(`div`, { style: { display: `grid`, gap: 2 }, children: [(0, L.jsx)(`p`, { ref: r2, style: { margin: 0, fontSize: h.sm, color: m.muted, lineHeight: 1.55, maxWidth: `82ch`, ...t2 ? {} : { display: `-webkit-box`, WebkitLineClamp: 2, WebkitBoxOrient: `vertical`, overflow: `hidden` } }, children: e2 }), (i2 || t2) && (0, L.jsx)(`button`, { onClick: () => n2((e3) => !e3), "aria-expanded": t2, style: { justifySelf: `start`, border: `none`, background: `transparent`, color: m.accent, fontSize: h.xs, fontWeight: 600, cursor: `pointer`, padding: `1px 0` }, children: t2 ? `Less` : `Why this matters` })] });
}
function ye({ title: e2, description: t2, children: n2 }) {
  return (0, I.useContext)(V) ? (0, L.jsxs)(`div`, { style: { display: `grid`, gridTemplateColumns: `minmax(0, 1fr)`, gap: 10 }, children: [e2 && (0, L.jsx)(`h2`, { style: { margin: 0, fontSize: h.md, fontWeight: 640, paddingRight: 26 }, children: e2 }), t2 && (0, L.jsx)(H, { children: t2 }), n2] }) : (0, L.jsxs)(`section`, { style: { background: m.surface, border: `1px solid ${m.line}`, borderRadius: `var(--w-r-md)`, padding: `16px 18px`, display: `grid`, gap: 10 }, children: [e2 && (0, L.jsx)(`h2`, { style: { margin: 0, fontSize: h.md, fontWeight: 640 }, children: e2 }), t2 && (0, L.jsx)(H, { children: t2 }), n2] });
}
function be({ tone: e2 = `warn`, children: t2 }) {
  let { edge: n2, bg: r2 } = { warn: { edge: m.warn, bg: m.warnSoft }, danger: { edge: m.danger, bg: m.dangerSoft }, accent: { edge: m.accent, bg: m.accentSoft } }[e2];
  return (0, L.jsx)(`div`, { style: { borderLeft: `2px solid ${n2}`, background: r2, padding: `9px 13px`, borderRadius: `0 var(--w-r-sm) var(--w-r-sm) 0`, fontSize: h.sm, lineHeight: 1.55, color: m.text }, children: t2 });
}
function xe({ children: e2 }) {
  return (0, L.jsx)(`div`, { style: { fontSize: h.sm, color: m.faint, padding: `10px 0` }, children: e2 });
}
function Se({ value: e2, label: t2 = `Copy`, kind: n2 = `quiet`, title: r2 }) {
  let [i2, a2] = (0, I.useState)(`idle`), o2 = (0, I.useRef)(void 0);
  return (0, I.useEffect)(() => () => clearTimeout(o2.current), []), (0, L.jsx)(B, { kind: n2, onClick: () => {
    clearTimeout(o2.current), navigator.clipboard.writeText(e2).then(() => a2(`done`), () => a2(`refused`)), o2.current = setTimeout(() => a2(`idle`), 2e3);
  }, ...r2 ? { title: i2 === `refused` ? `${r2} \u2014 the browser refused clipboard access` : r2 } : {}, children: i2 === `done` ? `Copied` : i2 === `refused` ? `Refused` : t2 });
}
function Ce() {
  return (0, L.jsx)(`span`, { "aria-hidden": true, style: { width: 22, height: 22, borderRadius: 6, background: m.accent, display: `grid`, placeItems: `center`, flex: `none` }, children: (0, L.jsx)(`svg`, { width: `12`, height: `12`, viewBox: `0 0 12 12`, children: (0, L.jsx)(`path`, { d: `M6 1 L10.5 3v3.2c0 2.3-1.9 4-4.5 4.8C3.4 10.2 1.5 8.5 1.5 6.2V3z`, fill: `var(--w-accent-ink)` }) }) });
}
var U = { contexts: `M3.4 4.6h17.2v14.8H3.4zM12 4.6v14.8M3.4 12h17.2`, terms: `M6 3.4h8.6l3.8 3.8v13.4H6zM14.6 3.4v3.8h3.8M8.8 10h6.4M8.8 13.2h6.4M9.6 17l1.6 1.6 3.2-3.2`, keys: `M11.2 12h9.4M18 12v3.2M15.1 12v2.4`, dids: `M3.9 10.9 10.9 3.9h6.6a2.6 2.6 0 0 1 2.6 2.6v6.6l-7 7a2.1 2.1 0 0 1-3 0l-6.2-6.2a2.1 2.1 0 0 1 0-3z`, "did-templates": `M6.6 13.6 3.4 10.4a1.9 1.9 0 0 1 0-2.7l6.3-6.3h3M9.6 13.1l5.9-5.9h4.5a1.8 1.8 0 0 1 1.8 1.8v4.5l-5.9 5.9a1.5 1.5 0 0 1-2.1 0l-4.2-4.2a1.5 1.5 0 0 1 0-2.1z`, credentials: `M6.9 8.2h7.2M6.9 11.6h4.6M14.9 19.7 14.3 23l2.3-1.4 2.3 1.4-.6-3.3`, persona: `M4.9 20.4a7.1 7.1 0 0 1 14.2 0`, memory: `M6.6 3.4h6.6l5.8 5.8v10.9a1.6 1.6 0 0 1-1.6 1.6H6.6A1.6 1.6 0 0 1 5 20.1V5A1.6 1.6 0 0 1 6.6 3.4zM13.2 3.4v5.8H19M8.4 13.9h7.2M8.4 17.1h4.6`, "app-state": `M3.4 9.1h17.2M7 13.2h6.4M7 16.1h4`, rooms: `M12 8.5V6.9M12 17.1v-1.6M8.5 12H6.9M17.1 12h-1.6`, services: `M7.9 6.4h5.9a2.9 2.9 0 0 1 0 5.8h-3.6a2.9 2.9 0 0 0 0 5.8h5.9`, mediator: `M10 10.5 6.8 7.3M14 10.5l3.2-3.2M12 14.6v3.4`, maintenance: `M20 5.2 16.9 8.3a1.4 1.4 0 0 1-2 0l-.7-.7a1.4 1.4 0 0 1 0-2L17.3 2.5a5.4 5.4 0 0 0-6.6 7.3l-7.1 7.1a2 2 0 0 0 2.8 2.8l7.1-7.1A5.4 5.4 0 0 0 20 5.2z`, audit: `M7 4.4v15.2M11.6 7.5h8.4M11.6 12h6.2M11.6 16.5h7.3`, access: `M2.9 18.7a4.9 4.9 0 0 1 9 0M14.6 8.3h6.5M14.6 12.4h6.5M14.6 16.5h4.2`, approvals: `M8.1 12.3 10.9 15.1 16 9.5`, policy: `M7.5 12h3.1a2.2 2.2 0 0 0 1.9-1.1l1.3-2.2a2.2 2.2 0 0 1 1.9-1.1h.8M7.5 12h3.1a2.2 2.2 0 0 1 1.9 1.1l1.3 2.2a2.2 2.2 0 0 0 1.9 1.1h.8`, sessions: `M12 7.1V12l3.3 2`, "fam-identity": `M5.2 20.2a6.8 6.8 0 0 1 13.6 0`, "fam-contact": `M12 21s6.8-6.1 6.8-11a6.8 6.8 0 1 0-13.6 0C5.2 14.9 12 21 12 21z`, "fam-public": `M3.7 12h16.6M12 3.7a13 13 0 0 1 0 16.6 13 13 0 0 1 0-16.6z`, "fam-gated": `M8.3 10.6V7.9a3.7 3.7 0 0 1 7.4 0v2.7`, "fam-unregistered": `M9.6 9.5a2.5 2.5 0 0 1 4.8.8c0 1.7-2.4 2.1-2.4 3.7`, "st-known": `M5.2 20.2a6.8 6.8 0 0 1 13.6 0`, "st-identified": `M5.2 20.2a6.8 6.8 0 0 1 13.6 0`, "st-absent": `M8.4 12h7.2`, "st-unreadable": `M12 8.2v4.6M12 16.4h.01`, chevron: `M9.5 5.5 16 12l-6.5 6.5`, close: `M6.5 6.5 17.5 17.5M17.5 6.5 6.5 17.5`, plus: `M12 5.5v13M5.5 12h13`, eye: `M2.5 12S6 5.8 12 5.8 21.5 12 21.5 12 18 18.2 12 18.2 2.5 12 2.5 12z`, "eye-off": `M4 4l16 16M9.9 5.9A9 9 0 0 1 12 5.8c6 0 9.5 6.2 9.5 6.2a17 17 0 0 1-3.2 3.9M6.5 8.1A17 17 0 0 0 2.5 12S6 18.2 12 18.2a9 9 0 0 0 2.6-.4`, search: `M20.5 20.5 16.2 16.2`, drag: ``, info: `M12 11.2v5.2M12 7.8h.01`, released: `M12 4.2v11.4M7.6 11.2 12 15.6l4.4-4.4M4.8 19.2h14.4`, qr: `M14.2 14.2h2.4M18.6 14.2v2.4M14.2 18.6v1.6h2.4M18.6 19.8v.4` }, we = { contexts: `<circle cx="7.7" cy="8.3" r="1.25" fill="currentColor" stroke="none"/>`, keys: `<circle cx="7.6" cy="12" r="3.6"/>`, dids: `<circle cx="16.2" cy="7.8" r="1.35"/>`, "did-templates": `<circle cx="18.4" cy="10.4" r="1.15"/>`, credentials: `<rect x="3.4" y="4.2" width="17.2" height="11.6" rx="2.2"/><circle cx="16.6" cy="17.4" r="2.9"/>`, persona: `<circle cx="12" cy="8.4" r="3.8"/>`, "app-state": `<rect x="3.4" y="4.6" width="17.2" height="14.8" rx="2.6"/><circle cx="6.7" cy="6.85" r=".75" fill="currentColor" stroke="none"/><circle cx="9.2" cy="6.85" r=".75" fill="currentColor" stroke="none"/>`, rooms: `<rect x="3.6" y="4.4" width="16.8" height="15.2" rx="2.4"/><circle cx="12" cy="12" r="3.5"/>`, services: `<circle cx="5.6" cy="6.4" r="2.3"/><circle cx="18.4" cy="17.6" r="2.3"/>`, mediator: `<circle cx="12" cy="12" r="2.6"/><circle cx="5.3" cy="5.8" r="2"/><circle cx="18.7" cy="5.8" r="2"/><circle cx="12" cy="20" r="2"/>`, audit: `<circle cx="7" cy="7.5" r="1.7"/><circle cx="7" cy="12" r="1.7"/><circle cx="7" cy="16.5" r="1.7"/>`, access: `<circle cx="7.4" cy="8.1" r="2.9"/>`, approvals: `<circle cx="12" cy="12" r="8.3"/>`, policy: `<circle cx="5.3" cy="12" r="2.2"/><circle cx="18.7" cy="6.6" r="2.2"/><circle cx="18.7" cy="17.4" r="2.2"/>`, sessions: `<circle cx="12" cy="12" r="8.3"/>`, "fam-identity": `<circle cx="12" cy="8.4" r="3.6"/>`, "fam-contact": `<circle cx="12" cy="10" r="2.5"/>`, "fam-public": `<circle cx="12" cy="12" r="8.3"/>`, "fam-gated": `<rect x="4.8" y="10.6" width="14.4" height="9.4" rx="2.2"/>`, "fam-unregistered": `<circle cx="12" cy="12" r="8.3"/><circle cx="12" cy="17.3" r=".95" fill="currentColor" stroke="none"/>`, "st-known": `<circle cx="12" cy="9" r="3.6" fill="currentColor" stroke="none"/>`, "st-identified": `<circle cx="12" cy="9" r="3.6"/>`, "st-absent": `<circle cx="12" cy="12" r="8.3"/>`, "st-unreadable": `<path d="M12 3.6 21.2 19.6H2.8z" stroke-linejoin="round"/>`, search: `<circle cx="11" cy="11" r="6.6"/>`, info: `<circle cx="12" cy="12" r="8.3"/>`, qr: `<rect x="3.4" y="3.4" width="7" height="7" rx="1.2"/><rect x="13.6" y="3.4" width="7" height="7" rx="1.2"/><rect x="3.4" y="13.6" width="7" height="7" rx="1.2"/><rect x="5.9" y="5.9" width="2" height="2" fill="currentColor" stroke="none"/><rect x="16.1" y="5.9" width="2" height="2" fill="currentColor" stroke="none"/><rect x="5.9" y="16.1" width="2" height="2" fill="currentColor" stroke="none"/>`, drag: `<circle cx="9" cy="6.5" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="6.5" r="1.2" fill="currentColor" stroke="none"/><circle cx="9" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="9" cy="17.5" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="17.5" r="1.2" fill="currentColor" stroke="none"/>` }, Te = { "st-identified": `2.6 2.2`, "st-absent": `2.6 2.4` };
function W({ name: e2, size: t2 = 18, style: n2, title: r2 }) {
  let i2 = Te[e2];
  return (0, L.jsx)(`svg`, { width: t2, height: t2, viewBox: `0 0 24 24`, fill: `none`, stroke: `currentColor`, strokeWidth: 1.6, strokeLinecap: `round`, strokeLinejoin: `round`, role: r2 ? `img` : void 0, "aria-label": r2, "aria-hidden": !r2 || void 0, style: { flexShrink: 0, display: `block`, ...n2 }, ...i2 ? { strokeDasharray: i2 } : {}, dangerouslySetInnerHTML: { __html: (we[e2] ?? ``) + (U[e2] ? `<path d="${U[e2]}"/>` : ``) } });
}
var G = 9, K = 12, q = 400;
function Ee(e2, t2) {
  let n2 = Math.min(t2.width || q, innerWidth - 24), r2 = t2.height, i2 = innerHeight - e2.bottom - G - K, a2 = e2.top - G - K, o2 = r2 > i2 && a2 > i2, s2 = e2.left;
  s2 + n2 > innerWidth - K && (s2 = innerWidth - K - n2), s2 < K && (s2 = K);
  let c2 = o2 ? e2.top - G - r2 : e2.bottom + G;
  c2 < K && (c2 = K), c2 + r2 > innerHeight - K && (c2 = Math.max(K, innerHeight - K - r2));
  let l2 = e2.left + e2.width / 2 - s2, u2 = Math.max(16, Math.min(l2, n2 - 16));
  return { left: s2, top: c2, arrow: u2, above: o2 };
}
function De({ anchor: e2, onClose: t2, title: n2, width: r2 = q, children: i2 }) {
  let a2 = (0, I.useRef)(null), [o2, s2] = (0, I.useState)(null), c2 = (0, I.useCallback)(() => {
    let n3 = e2.current, i3 = a2.current;
    if (!n3 || !i3) return;
    let o3 = n3.getBoundingClientRect();
    if (o3.bottom < 0 || o3.top > innerHeight) {
      t2();
      return;
    }
    s2(Ee(o3, { width: r2, height: i3.offsetHeight }));
  }, [e2, t2, r2]);
  return (0, I.useLayoutEffect)(() => {
    c2();
  }, [c2, i2]), (0, I.useEffect)(() => {
    let e3 = () => c2();
    return addEventListener(`scroll`, e3, { capture: true, passive: true }), addEventListener(`resize`, e3), () => {
      removeEventListener(`scroll`, e3, { capture: true }), removeEventListener(`resize`, e3);
    };
  }, [c2]), (0, I.useEffect)(() => {
    let n3 = (n4) => {
      n4.key === `Escape` && (n4.stopPropagation(), t2(), e2.current?.focus());
    };
    return addEventListener(`keydown`, n3, true), () => removeEventListener(`keydown`, n3, true);
  }, [e2, t2]), (0, I.useEffect)(() => {
    let e3 = a2.current;
    if (!e3) return;
    let t3 = e3.querySelector(`input:not([type=hidden]):not([disabled]), select:not([disabled]), textarea:not([disabled]), button[data-primary]`);
    t3?.focus(), t3 instanceof HTMLInputElement && t3.type === `text` && t3.select();
  }, []), (0, L.jsxs)(L.Fragment, { children: [(0, L.jsx)(`div`, { onClick: t2, style: { position: `fixed`, inset: 0, zIndex: 40 }, "aria-hidden": true }), (0, L.jsxs)(`div`, { ref: a2, role: `dialog`, "aria-label": n2, onClick: (e3) => e3.stopPropagation(), style: { position: `fixed`, zIndex: 41, left: o2?.left ?? 0, top: o2?.top ?? 0, width: r2, maxWidth: `calc(100vw - 24px)`, maxHeight: `calc(100vh - 24px)`, overflowY: `auto`, background: m.surface, border: `1px solid ${m.line}`, borderRadius: g.lg, boxShadow: `0 12px 34px rgba(15,20,32,.20), 0 2px 6px rgba(15,20,32,.10)`, padding: `15px 16px`, display: `grid`, gridTemplateColumns: `minmax(0, 1fr)`, gap: 11, opacity: +!!o2 }, children: [o2 && (0, L.jsx)(`span`, { "aria-hidden": true, style: { position: `absolute`, width: 11, height: 11, background: m.surface, borderLeft: `1px solid ${m.line}`, borderTop: `1px solid ${m.line}`, transform: `rotate(${o2.above ? 225 : 45}deg)`, left: o2.arrow - 5.5, ...o2.above ? { bottom: -6.5 } : { top: -6.5 } } }), (0, L.jsx)(`button`, { onClick: t2, "aria-label": `Close`, style: { position: `absolute`, top: 12, right: 12, border: `none`, background: `transparent`, color: m.faint, cursor: `pointer`, padding: 2, borderRadius: g.sm, lineHeight: 0 }, children: (0, L.jsx)(W, { name: `close`, size: 16 }) }), (0, L.jsx)(V.Provider, { value: true, children: i2 })] })] });
}
function Oe() {
  let e2 = (0, I.useRef)(null), [t2, n2] = (0, I.useState)(false);
  return { ref: e2, open: t2, show: (0, I.useCallback)(() => n2(true), []), hide: (0, I.useCallback)(() => n2(false), []) };
}
var ke = n();
function Ae({ text: e2, size: t2 = 232 }) {
  let { d: n2, side: r2 } = (0, I.useMemo)(() => fe(de(e2)), [e2]);
  return (0, L.jsxs)(`svg`, { role: `img`, "aria-label": `QR code of ${e2}`, width: t2, height: t2, viewBox: `0 0 ${r2} ${r2}`, shapeRendering: `crispEdges`, style: { display: `block`, flexShrink: 0 }, children: [(0, L.jsx)(`rect`, { width: r2, height: r2, fill: `#ffffff` }), (0, L.jsx)(`path`, { d: n2, fill: `#000000` })] });
}
function J({ value: e2, size: t2 = 14 }) {
  let n2 = Oe();
  return (0, L.jsxs)(L.Fragment, { children: [(0, L.jsx)(`button`, { ref: n2.ref, type: `button`, onClick: (e3) => {
    e3.stopPropagation(), n2.open ? n2.hide() : n2.show();
  }, "aria-label": `Show this DID as a QR code`, "aria-haspopup": `dialog`, "aria-expanded": n2.open, title: `Show as a QR code`, className: `did-qr-button`, style: { display: `inline-flex`, verticalAlign: `middle`, marginLeft: 4, padding: 2, border: `none`, background: `transparent`, color: m.faint, cursor: `pointer`, borderRadius: g.sm, lineHeight: 0 }, children: (0, L.jsx)(W, { name: `qr`, size: t2 }) }), n2.open && (0, ke.createPortal)((0, L.jsx)(`div`, { onClick: (e3) => e3.stopPropagation(), children: (0, L.jsxs)(De, { anchor: n2.ref, onClose: n2.hide, title: `DID as a QR code`, width: 292, children: [(0, L.jsx)(`div`, { style: { fontSize: h.base, fontWeight: 620, color: m.text, paddingRight: 24 }, children: `Scan with Keyring` }), (0, L.jsx)(`div`, { style: { justifySelf: `center`, padding: 6, background: `#ffffff`, border: `1px solid ${m.line}`, borderRadius: g.md }, children: (0, L.jsx)(Ae, { text: e2 }) }), (0, L.jsx)(`code`, { style: { fontFamily: _.mono, fontSize: h.xs, color: m.text, wordBreak: `break-all`, lineHeight: 1.5 }, children: e2 }), (0, L.jsxs)(`div`, { style: { display: `flex`, alignItems: `center`, gap: 8, flexWrap: `wrap` }, children: [(0, L.jsx)(Se, { value: e2, label: `Copy DID`, kind: `default`, title: `Copy this DID` }), (0, L.jsx)(`span`, { style: { fontSize: h.xs, color: m.muted }, children: `The code holds only this DID, which is public.` })] })] }) }), document.body)] });
}
function je(e2) {
  let t2 = e2.target;
  return !t2 || t2.tagName !== `SELECT` || typeof t2.blur != `function` ? null : t2;
}
function Me(e2) {
  let t2 = null, n2 = (e3) => {
    t2 = je(e3);
  }, r2 = () => {
    t2 = null;
  }, i2 = (e3) => {
    let n3 = je(e3);
    n3 && n3 === t2 && n3.blur(), t2 = null;
  };
  return e2.addEventListener(`pointerdown`, n2, true), e2.addEventListener(`keydown`, r2, true), e2.addEventListener(`change`, i2, true), () => {
    e2.removeEventListener(`pointerdown`, n2, true), e2.removeEventListener(`keydown`, r2, true), e2.removeEventListener(`change`, i2, true);
  };
}
var Y = `pnm/holder-prf/credentialId`, X = `pnm/holder-prf/salt`, Z = class extends Error {
  reason;
  constructor(e2, t2) {
    super(t2), this.name = `PrfUnlockError`, this.reason = e2;
  }
};
async function Ne(e2) {
  let t2 = new d(), n2 = await t2.get(Y), r2 = await t2.get(X);
  if (!n2 || !r2) throw new Z(`no-enrolment`, `Wallet isn't enrolled for encryption. Re-onboard and choose 'Encrypt with authenticator', or open Settings.`);
  return Q(e2, n2, r2, crypto.getRandomValues(new Uint8Array(32)));
}
async function Pe(e2, t2) {
  let n2 = new d(), r2 = await n2.get(Y), i2 = await n2.get(X);
  if (!r2 || !i2) throw new Z(`no-enrolment`, `Approver isn't enrolled for biometric approval. Create the approver identity in Settings first.`);
  return Q(e2, r2, i2, new Uint8Array(await crypto.subtle.digest(`SHA-256`, new TextEncoder().encode(t2))));
}
async function Fe() {
  let e2 = new d();
  return !!(await e2.get(Y) && await e2.get(X));
}
async function Ie(e2, t2) {
  let n2 = new d(), r2 = await n2.get(Y), i2 = await n2.get(X);
  if (!r2 || !i2) throw new Z(`no-enrolment`, `This wallet has no passkey yet.`);
  return Q(e2, r2, i2, a(t2));
}
async function Q(e2, t2, n2, r2) {
  let i2 = a(t2), c2 = a(n2), l2 = null;
  try {
    l2 = await navigator.credentials.get({ publicKey: { rpId: e2, challenge: r2, allowCredentials: [{ type: `public-key`, id: i2 }], userVerification: `required`, extensions: { prf: { eval: { first: c2 } } } } });
  } catch (e3) {
    throw e3 instanceof Error && e3.name === `NotAllowedError` ? new Z(`cancelled`, `Authenticator prompt cancelled.`) : e3;
  }
  if (!l2) throw new Z(`cancelled`, `Authenticator returned no assertion.`);
  let u2 = l2.getClientExtensionResults().prf?.results?.first;
  if (!u2) throw new Z(`no-prf-output`, await p() === false ? o : s);
  return { prfOutput: new Uint8Array(u2) };
}
function $(e2) {
  if (!e2) return null;
  let t2 = (() => {
    try {
      return decodeURIComponent(e2);
    } catch {
      return e2;
    }
  })(), n2 = /^[a-z][a-z0-9+.-]*:\/\//i.test(t2) ? t2 : `https://${t2}`, r2;
  try {
    r2 = new URL(n2);
  } catch {
    return null;
  }
  return !r2.hostname || r2.protocol !== `https:` && r2.protocol !== `http:` ? null : `${r2.protocol}//${r2.hostname}/*`;
}
async function Le(e2) {
  let t2 = $(e2);
  if (!t2) return false;
  try {
    return await chrome.permissions.contains({ origins: [t2] });
  } catch {
    return false;
  }
}
function Re(e2) {
  return ze([e2]);
}
function ze(e2) {
  let t2 = [...new Set(e2.map($))].filter((e3) => e3 !== null);
  return t2.length === 0 || t2.length !== new Set(e2.map($)).size ? Promise.resolve(false) : new Promise((e3) => {
    let n2 = false, r2 = (t3) => {
      if (!n2) {
        n2 = true;
        try {
          chrome.permissions.onAdded.removeListener(i2);
        } catch {
        }
        e3(t3);
      }
    }, i2 = () => {
      chrome.permissions.contains({ origins: t2 }).then((e4) => {
        e4 && r2(true);
      }).catch(() => {
      });
    };
    try {
      chrome.permissions.onAdded.addListener(i2);
    } catch {
    }
    let a2 = () => {
      chrome.permissions.contains({ origins: t2 }).then((e4) => r2(e4)).catch(() => r2(false));
    };
    try {
      chrome.permissions.request({ origins: t2 }).then((e4) => e4 ? r2(true) : a2(), a2);
    } catch {
      a2();
    }
  });
}
async function Be() {
  try {
    return ((await chrome.permissions.getAll()).origins ?? []).filter((e2) => e2 !== `<all_urls>` && e2 !== `*://*/*`).sort();
  } catch {
    return [];
  }
}
async function Ve() {
  try {
    return ((await chrome.permissions.getAll()).origins ?? []).some((e2) => e2 === `<all_urls>` || e2 === `*://*/*`);
  } catch {
    return false;
  }
}
async function He(e2) {
  let t2 = $(e2);
  if (!t2) return false;
  try {
    await chrome.permissions.remove({ origins: [t2] });
  } catch {
  }
  return !await Le(t2);
}
function Ue(e2) {
  let t2 = $(e2);
  return t2 ? t2.replace(/^https?:\/\//, ``).replace(/\/\*$/, ``) : e2;
}
export {
  j as A,
  F as C,
  P as D,
  N as E,
  _ as F,
  y as I,
  v as L,
  x as M,
  m as N,
  pe as O,
  b as P,
  g as R,
  ve as S,
  me as T,
  _e as _,
  Re as a,
  be as b,
  Z as c,
  Ne as d,
  Ie as f,
  z as g,
  B as h,
  Be as i,
  te as j,
  M as k,
  Fe as l,
  J as m,
  Ve as n,
  ze as o,
  Me as p,
  Le as r,
  He as s,
  Ue as t,
  Pe as u,
  xe as v,
  he as w,
  ye as x,
  Ce as y,
  h as z
};
