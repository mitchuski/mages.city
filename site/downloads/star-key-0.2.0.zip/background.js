var e = (e3, t2, n2) => () => {
  if (n2) throw n2[0];
  try {
    return e3 && (t2 = e3(e3 = 0)), t2;
  } catch (e4) {
    throw n2 = [e4], e4;
  }
}, t = [{ prefix: `https://trusttasks.org/spec/persona/`, why: `The persona family carries the holder's own identity, and a generic task prompt cannot tell them what a disclosure would reveal. Ask for a disclosure through the wallet's disclosure flow, which shows the holder exactly what would be sent, to whom, and what it would let you link \u2014 and returns the presentation rather than the underlying values.` }, { prefix: `https://trusttasks.org/spec/rooms/`, why: `A data room is governed by credentials the room itself issued, and a page holds none of them. Reading a record returns plaintext the room withholds even from its host; listing keys discloses what the holder is a member of; and the owner verbs mint credentials in the room's name, which is authority to admit or promote. A community's own member portal uses the rooms a member shares with it through window.vtaWallet.rooms, whose verbs are fixed, whose flows run in the wallet, and whose every write the member confirms.` }, { prefix: `https://trusttasks.org/spec/vtc/rooms/offers/`, why: `Accepting a community's offer of a room joins the member to it, and a generic prompt cannot say so. A community's own member portal lists offers with window.vtaWallet.rooms.offers and asks to accept one with window.vtaWallet.rooms.acceptOffer, which the member decides in the wallet's own window.` }, { prefix: `https://trusttasks.org/spec/vtc/rooms/memberships/`, why: `The community's record of which of its rooms the member is in is read by the wallet, as the member. A community's own member portal lists it with window.vtaWallet.rooms.offers.` }, { prefix: `https://trusttasks.org/spec/messaging/`, why: `The messaging family is the relay's operations surface: its queues, its accounts and a live feed of whom the holder exchanges messages with. A page has no use for any of it that the holder should be asked to approve; the holder inspects their own relay from the wallet's console.` }, { prefix: `https://trusttasks.org/spec/vtc/directory/`, why: `The directory family reads and publishes the member's own card. Ask for publication with window.vtaWallet.directory.publishCard, which shows the member every value and that anyone will be able to read it before anything is signed.` }, { prefix: `https://trusttasks.org/spec/keys/sign-document/`, why: `keys/sign-document makes a proof, as one of the holder's DIDs, over a document the caller wrote, which every verifier will read as the holder's own assertion. A page cannot ask for one: the wallet signs a document only within a flow that shows the holder what it says, such as window.vtaWallet.directory.publishCard.` }];
function n(e3) {
  let n2 = t.find((t2) => e3.startsWith(t2.prefix));
  return n2 ? `${e3} cannot be requested by a page. ${n2.why}` : null;
}
var r = `https://trusttasks.org/spec/auth/step-up/approve-`, i = `https://trusttasks.org/spec/auth/authenticate/`;
function a(e3, t2) {
  if (!e3 || typeof e3 != `object` || Array.isArray(e3)) return `signTrustTask needs a Trust Task document to sign.`;
  let { type: a2, recipient: o2 } = e3;
  return typeof a2 != `string` || a2 === `` ? `signTrustTask needs a document with a type.` : typeof o2 != `string` || o2 === `` ? `${a2} names no recipient. A page-signed document must be addressed to the party it is for, or the signature is good at any party that accepts the holder's key.` : o2 === t2 ? `${a2} is addressed to the holder's own agent. A page asks the agent through requestTask, where the agent's policy applies; the wallet does not sign documents to it on a page's behalf.` : a2.startsWith(r) ? `${a2} cannot be signed for a page. A step-up approval is built only by the wallet's step-up flow (stepUpVta), which verifies the relying party's request and asks the holder first.` : a2.startsWith(i) ? `${a2} cannot be signed for a page. A sign-in, and any session key it binds, goes through login(), whose prompt tells the holder what the site will be able to do.` : n(a2);
}
function o(e3) {
  let t2;
  try {
    t2 = new URL(e3);
  } catch {
    return null;
  }
  return t2.protocol !== `https:` && t2.protocol !== `http:` || t2.username || t2.password || t2.search || t2.hash ? null : `${t2.origin}${t2.pathname.replace(/\/+$/, ``)}`;
}
function s(e3, t2) {
  return `${e3} has no relying party pinned, so the wallet will not ${t2} for it. Sign in from this site first: the login prompt is where the site's relying party is shown and confirmed, and it pins that pairing.`;
}
function c(e3, t2, n2) {
  return t2 ? n2 === t2.rpDid ? null : `The document is addressed to ${n2}, but ${e3} is pinned to the relying party ${t2.rpDid}. A page can only have documents signed for the relying party it was signed in to.` : s(e3, `sign documents`);
}
function l(e3, t2, n2) {
  return t2 ? n2.rpDid === t2.rpDid ? t2.baseUrl ? o(n2.baseUrl) === t2.baseUrl ? null : `Step-up names the base URL ${n2.baseUrl}, but ${e3} is pinned to ${t2.baseUrl}. A page can only step up against the base URL it signed in with.` : `${e3} has no relying-party base URL pinned: its sign-in named none. Sign in from this site with login() so the base URL step-up will use is shown and confirmed.` : `Step-up names the relying party ${n2.rpDid}, but ${e3} is pinned to ${t2.rpDid}. A page can only step up its session at the relying party it was signed in to.` : s(e3, `step up a session`);
}
function u(e3) {
  let t2 = ``;
  for (let n2 = 0; n2 < e3.length; n2++) t2 += String.fromCharCode(e3[n2] ?? 0);
  return btoa(t2).replaceAll(`+`, `-`).replaceAll(`/`, `_`).replace(/=+$/, ``);
}
function d(e3) {
  if (!f.test(e3)) throw Error(`base64urlToBytes: input is not unpadded base64url`);
  if (e3.length % 4 == 1) throw Error(`base64urlToBytes: invalid base64url length`);
  let t2 = (e3 + (e3.length % 4 == 2 ? `==` : e3.length % 4 == 3 ? `=` : ``)).replaceAll(`-`, `+`).replaceAll(`_`, `/`), n2 = atob(t2), r2 = new Uint8Array(n2.length);
  for (let e4 = 0; e4 < n2.length; e4++) r2[e4] = n2.charCodeAt(e4);
  if (u(r2) !== e3) throw Error(`base64urlToBytes: non-canonical base64url encoding`);
  return r2;
}
var f, p = e((() => {
  f = /^[A-Za-z0-9_-]*$/;
}));
function m(e3) {
  let t2 = e3 instanceof Uint8Array ? e3 : new Uint8Array(e3 instanceof ArrayBuffer ? e3 : new Uint8Array(e3)), n2 = ``, r2 = 0;
  for (; r2 + 2 < t2.length; r2 += 3) {
    let e4 = t2[r2] << 16 | t2[r2 + 1] << 8 | t2[r2 + 2];
    n2 += g[e4 >> 18 & 63] + g[e4 >> 12 & 63] + g[e4 >> 6 & 63] + g[e4 & 63];
  }
  let i2 = t2.length - r2;
  if (i2 === 1) {
    let e4 = t2[r2] << 16;
    n2 += g[e4 >> 18 & 63] + g[e4 >> 12 & 63];
  } else if (i2 === 2) {
    let e4 = t2[r2] << 16 | t2[r2 + 1] << 8;
    n2 += g[e4 >> 18 & 63] + g[e4 >> 12 & 63] + g[e4 >> 6 & 63];
  }
  return n2;
}
function h(e3) {
  if (typeof e3 != `string`) throw TypeError(`base64url.decode expects a string, got ${typeof e3}`);
  let t2 = e3.replace(/[+]/g, `-`).replace(/[/]/g, `_`).replace(/=+$/, ``);
  if (t2.length % 4 == 1) throw Error(`base64url.decode: invalid length (${t2.length} chars; %4 === 1)`);
  let n2 = new Uint8Array(Math.floor(t2.length * 3 / 4)), r2 = 0, i2 = 0, a2 = 0;
  for (let e4 = 0; e4 < t2.length; e4++) {
    let o2 = t2.charCodeAt(e4), s2 = _[o2];
    if (s2 === void 0) throw Error(`base64url.decode: invalid character ${JSON.stringify(t2[e4])} at position ${e4}`);
    i2 = i2 << 6 | s2, a2 += 6, a2 >= 8 && (a2 -= 8, n2[r2++] = i2 >> a2 & 255);
  }
  return n2.subarray(0, r2);
}
var g, _, v = e((() => {
  g = `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_`, _ = (() => {
    let e3 = Array(128);
    for (let t2 = 0; t2 < 64; t2++) e3[g.charCodeAt(t2)] = t2;
    return e3;
  })();
})), y = e((() => {
  v();
}));
function b(e3) {
  switch (e3) {
    case `unsupported-vid`:
    case `unknown-flow`:
    case `unsupported-version`:
      return `update`;
    case `expired`:
      return `expired`;
    case `no-common-transport`:
      return `unreachable`;
    case `not-ours`:
      return `pass-on`;
    default:
      return `invalid`;
  }
}
function x(e3) {
  if (e3.length !== 0) return e3.map((e4) => {
    try {
      return decodeURIComponent(e4);
    } catch {
      return e4;
    }
  });
}
function ee(e3) {
  let t2 = /* @__PURE__ */ new Map();
  for (let n2 of e3) t2.set(n2.kind, n2);
  return { policyFor: (e4) => t2.get(e4) };
}
function te(e3, t2 = Oe) {
  let n2 = t2.policyFor(e3.kind);
  return n2?.route !== void 0 && n2.listsServices && n2.verified ? n2.route : void 0;
}
function ne(e3, t2 = Oe) {
  return te(e3, t2) !== void 0;
}
function S(e3, t2) {
  return { ok: false, reason: e3, outcome: b(e3), ...t2 ? { method: t2 } : {} };
}
function re(e3, t2) {
  let n2 = t2.flows ?? Ae, r2 = (t2.aliasSchemes ?? []).map((e4) => e4.toLowerCase()), i2 = be(typeof e3 == `string` ? e3 : ``);
  if (xe(i2) > 1536) return S(`too-long`);
  let a2 = /^([A-Za-z][A-Za-z0-9+.-]*):\/\//.exec(i2), o2 = a2?.[1]?.toLowerCase();
  if (!o2 || !(o2 === `https` || o2 === `http` || r2.includes(o2))) return S(`not-ours`);
  let s2 = i2.indexOf(`#`), c2 = s2 === -1 ? i2 : i2.slice(0, s2), l2 = s2 === -1 ? `` : i2.slice(s2 + 1), u2 = me(l2);
  if (!u2.some((e4) => ye(e4.name))) {
    let e4 = c2.indexOf(`?`);
    return S(me(e4 === -1 ? `` : c2.slice(e4 + 1)).some((e5) => ye(e5.name)) ? `query-form` : `not-ours`);
  }
  if (o2 === `http`) return S(`insecure-scheme`);
  for (let e4 of i2) {
    let t3 = e4.codePointAt(0);
    if (t3 <= 32 || t3 === 127) return S(`bad-grammar`);
  }
  if (l2.includes(`#`)) return S(`bad-grammar`);
  let d2 = c2.slice(a2[0].length), f2 = d2.search(/[/?\\]/), p2 = f2 === -1 ? d2 : d2.slice(0, f2);
  if (p2.includes(`@`) || p2.includes(`:`)) return S(`bad-authority`);
  let m2 = ae(p2);
  if (m2 === void 0 || !ie(m2)) return S(`bad-authority`);
  let h2 = {};
  for (let e4 of u2) if (ye(e4.name)) {
    if (h2[e4.name] !== void 0) return S(`repeated-param`);
    h2[e4.name] = { raw: e4.rawValue, value: e4.value };
  }
  let g2 = h2._from;
  if (g2 === void 0) return S(`missing-from`);
  let _2 = t2.contactMethods ?? Oe, v2 = ce(g2.value, _2);
  if (v2 === `bad-from` || v2 === `unsupported-vid`) return S(v2);
  let y2 = h2._id;
  if (y2 === void 0 || !oe(y2.value)) return S(`bad-id`);
  let b2;
  if (h2._exp !== void 0) {
    let e4 = se(h2._exp.value);
    if (e4 === void 0) return S(`bad-exp`);
    b2 = e4;
  }
  let x2;
  if (h2._type !== void 0) {
    let e4 = le(h2._type.raw, m2);
    if (e4 === void 0) return S(`bad-type`);
    let t3 = fe(e4, n2);
    if (!t3.ok) return S(t3.reason);
    x2 = t3.flow;
  }
  if (x2) {
    if (!x2.spec.allowsContact(v2, _2)) return S(`from-not-allowed`, v2.kind);
    if (x2.spec.requiresExp && b2 === void 0) return S(`missing-exp`);
  }
  return b2 !== void 0 && b2 + 60 <= t2.now ? S(`expired`) : { ok: true, link: { scheme: o2, host: m2, from: v2, id: y2.value, ...b2 === void 0 ? {} : { exp: b2 }, ...x2 ? { flow: x2 } : {} } };
}
function ie(e3) {
  if (typeof e3 != `string` || e3.length === 0 || e3.length > 253 || e3.endsWith(`.`)) return false;
  let t2 = e3.split(`.`);
  if (t2.length < 2) return false;
  for (let e4 of t2) if (!Me.test(e4)) return false;
  return !(/^[0-9]+$/.test(t2[t2.length - 1]) || e3 === `localhost` || e3.endsWith(`.localhost`) || e3.endsWith(`.local`) || e3 === `home.arpa` || e3.endsWith(`.home.arpa`));
}
function ae(e3) {
  if (e3.length !== 0) try {
    let t2 = new URL(`https://${e3}/`);
    return t2.username || t2.password || t2.port ? void 0 : t2.hostname;
  } catch {
    return;
  }
}
function oe(e3) {
  if (!/^[A-Za-z0-9_-]{22,43}$/.test(e3)) return false;
  let t2 = e3.length % 4;
  return t2 === 1 ? false : t2 === 0 || !(Ne.indexOf(e3[e3.length - 1]) & (t2 === 2 ? 15 : 3));
}
function se(e3) {
  if (!/^(0|[1-9][0-9]*)$/.test(e3) || e3.length > 16) return;
  let t2 = Number(e3);
  return Number.isSafeInteger(t2) ? t2 : void 0;
}
function ce(e3, t2) {
  if (e3.length === 0) return `bad-from`;
  if (e3.includes(`/@`)) return `unsupported-vid`;
  if (e3.startsWith(`did:`)) {
    if (!Pe.test(e3)) return `bad-from`;
    let n2 = `did:${e3.slice(4, e3.indexOf(`:`, 4))}`, r2 = t2.policyFor(n2);
    return !r2 || r2.route !== void 0 && !r2.verified ? `unsupported-vid` : r2.wellFormed && !r2.wellFormed(e3) ? `bad-from` : { kind: n2, value: e3 };
  }
  return `unsupported-vid`;
}
function le(e3, t2) {
  if (e3.startsWith(`/`)) return ue(e3) ? `https://${t2.toLowerCase()}${e3}` : void 0;
  if (!e3.startsWith(`https://`)) return;
  let n2 = e3.slice(8), r2 = n2.indexOf(`/`);
  if (r2 !== -1 && ie(n2.slice(0, r2))) return ue(n2.slice(r2)) ? e3 : void 0;
}
function ue(e3) {
  if (!/^\/[A-Za-z0-9\-._~/]+$/.test(e3)) return false;
  let t2 = e3.slice(1).split(`/`);
  return !t2.some((e4) => e4 === `` || e4 === `.` || e4 === `..`) && de(t2[t2.length - 1]);
}
function de(e3) {
  return /^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$/.test(e3);
}
function fe(e3, t2) {
  let n2 = e3.lastIndexOf(`/`), r2 = e3.slice(0, n2), [i2, a2] = e3.slice(n2 + 1).split(`.`), o2 = Number(i2), s2 = Number(a2), c2 = t2.find((e4) => e4.base === r2);
  if (!c2) {
    let e4 = pe(r2);
    return t2.some((t3) => pe(t3.base) === e4) ? { ok: false, reason: `wrong-host` } : { ok: false, reason: `unknown-flow` };
  }
  return o2 !== c2.major || !(c2.draft ? c2.minors.includes(s2) : s2 >= Math.min(...c2.minors)) ? { ok: false, reason: `unsupported-version` } : { ok: true, flow: { spec: c2, uri: e3, major: o2, minor: s2 } };
}
function pe(e3) {
  let t2 = e3.replace(/^https:\/\//i, ``), n2 = t2.indexOf(`/`);
  return n2 === -1 ? `` : t2.slice(n2);
}
function me(e3) {
  let t2 = [];
  for (let n2 of e3.split(`&`)) {
    if (n2.length === 0) continue;
    let e4 = n2.indexOf(`=`), r2 = e4 === -1 ? n2 : n2.slice(0, e4), i2 = e4 === -1 ? `` : n2.slice(e4 + 1);
    t2.push({ name: he(r2), value: he(i2), rawValue: i2 });
  }
  return t2;
}
function he(e3) {
  return ge(e3.replace(/\+/g, ` `));
}
function ge(e3) {
  let t2 = Fe.encode(e3), n2 = new Uint8Array(t2.length), r2 = 0;
  for (let e4 = 0; e4 < t2.length; e4++) {
    let i2 = t2[e4];
    i2 === 37 && e4 + 2 < t2.length && _e(t2[e4 + 1]) && _e(t2[e4 + 2]) ? (n2[r2++] = ve(t2[e4 + 1]) << 4 | ve(t2[e4 + 2]), e4 += 2) : n2[r2++] = i2;
  }
  return Ie.decode(n2.subarray(0, r2));
}
function _e(e3) {
  return e3 >= 48 && e3 <= 57 || e3 >= 65 && e3 <= 70 || e3 >= 97 && e3 <= 102;
}
function ve(e3) {
  return e3 <= 57 ? e3 - 48 : e3 <= 70 ? e3 - 65 + 10 : e3 - 97 + 10;
}
function ye(e3) {
  return je.includes(e3);
}
function be(e3) {
  return e3.replace(/^[\t\n\f\r ]+|[\t\n\f\r ]+$/g, ``);
}
function xe(e3) {
  let t2 = 0;
  for (let n2 of e3) t2++;
  return t2;
}
var Se, Ce, we, Te, Ee, De, Oe, ke, Ae, je, Me, Ne, Pe, Fe, Ie, Le = e((() => {
  Se = `https://link.trustoverip.org/vti/flow/`, Ce = { kind: `did:webvh`, route: `host-named`, listsServices: true, verified: true, wellFormed: (e3) => {
    let t2 = e3.split(`:`);
    return t2.length >= 4 && !!t2[2] && !!t2[3];
  }, hostPath: (e3) => x(e3.split(`:`).slice(3)) }, we = { kind: `did:web`, route: `host-named`, listsServices: true, verified: true, hostPath: (e3) => x(e3.split(`:`).slice(2)) }, Te = { kind: `did:key`, listsServices: false, verified: true, wellFormed: (e3) => /^did:key:z[1-9A-HJ-NP-Za-km-z]+$/.test(e3) }, Ee = { kind: `did:peer`, listsServices: true, verified: true }, De = [Ce, we, Te, Ee], Oe = ee(De), Object.freeze(Object.fromEntries(De.map((e3) => [e3.kind, { namesHost: e3.route === `host-named`, listsServices: e3.listsServices, verified: e3.verified }]))), ke = { name: `sign-in`, base: `${Se}sign-in`, major: 0, minors: [1], draft: true, requiresExp: true, allowsContact: ne }, Ae = [ke], je = [`_from`, `_id`, `_exp`, `_type`], Me = /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/, Ne = `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_`, Pe = /^did:[a-z0-9]+:(?:(?:[A-Za-z0-9._-]|%[0-9A-Fa-f]{2})*:)*(?:[A-Za-z0-9._-]|%[0-9A-Fa-f]{2})+$/, Fe = new TextEncoder(), Ie = new TextDecoder(`utf-8`);
})), Re = class extends Error {
  code;
  status;
  details;
  suggestion;
  constructor(e3, t2, n2 = {}) {
    super(t2), this.name = `VtaClientError`, this.code = e3, n2.status !== void 0 && (this.status = n2.status), n2.details !== void 0 && (this.details = n2.details), n2.suggestion !== void 0 && (this.suggestion = n2.suggestion);
  }
}, ze = 2e4;
function Be(e3, t2 = ze) {
  let n2 = e3 ?? fetch.bind(globalThis);
  return (e4, r2) => {
    let i2 = AbortSignal.timeout(t2), a2 = r2?.signal, o2 = i2;
    return a2 && (o2 = typeof AbortSignal.any == `function` ? AbortSignal.any([a2, i2]) : i2), n2(e4, { ...r2, signal: o2 });
  };
}
function Ve(e3) {
  let t2 = /* @__PURE__ */ new WeakSet();
  return n2(e3);
  function n2(e4) {
    if (e4 === null) return `null`;
    if (e4 === true) return `true`;
    if (e4 === false) return `false`;
    if (typeof e4 == `number`) {
      if (!Number.isFinite(e4)) throw Error(`JCS rejects non-finite numbers`);
      return Object.is(e4, -0) ? `0` : String(e4);
    }
    if (typeof e4 == `string`) return r2(e4);
    if (Array.isArray(e4)) {
      if (t2.has(e4)) throw Error(`circular reference in JCS input`);
      t2.add(e4);
      let r3 = `[` + e4.map(n2).join(`,`) + `]`;
      return t2.delete(e4), r3;
    }
    if (typeof e4 == `object` && e4) {
      if (t2.has(e4)) throw Error(`circular reference in JCS input`);
      t2.add(e4);
      let i2 = e4, a2 = Object.keys(i2).sort().map((e5) => r2(e5) + `:` + n2(i2[e5]));
      return t2.delete(e4), `{` + a2.join(`,`) + `}`;
    }
    throw Error(`JCS cannot encode value of type ${typeof e4}`);
  }
  function r2(e4) {
    let t3 = `"`;
    for (let n3 = 0; n3 < e4.length; n3++) {
      let r3 = e4.charCodeAt(n3);
      t3 += r3 === 34 ? `\\"` : r3 === 92 ? `\\\\` : r3 === 8 ? `\\b` : r3 === 12 ? `\\f` : r3 === 10 ? `\\n` : r3 === 13 ? `\\r` : r3 === 9 ? `\\t` : r3 < 32 ? `\\u` + r3.toString(16).padStart(4, `0`) : e4[n3];
    }
    return t3 + `"`;
  }
}
var He = e((() => {
}));
function Ue(e3) {
  return typeof e3 == `string` && /^https:\/\/trusttasks\.org\/spec\/trust-task-error\/0\.\d+$/.test(e3);
}
var We = /^did:key:z[1-9A-HJ-NP-Za-km-z]+$/, Ge = 512;
function Ke(e3) {
  return typeof e3 == `string` && e3.length <= Ge && We.test(e3);
}
var C, qe = e((() => {
  C = class {
    dbName;
    storeName;
    dbPromise = null;
    constructor(e3) {
      this.dbName = e3?.dbName ?? `pnm`, this.storeName = e3?.storeName ?? `kv`;
    }
    async get(e3) {
      let t2 = await this.openDb();
      return new Promise((n2, r2) => {
        let i2 = t2.transaction(this.storeName, `readonly`).objectStore(this.storeName).get(e3);
        i2.onsuccess = () => n2(i2.result), i2.onerror = () => r2(i2.error);
      });
    }
    async put(e3, t2) {
      let n2 = await this.openDb();
      await new Promise((r2, i2) => {
        let a2 = n2.transaction(this.storeName, `readwrite`);
        a2.objectStore(this.storeName).put(t2, e3), a2.oncomplete = () => r2(), a2.onerror = () => i2(a2.error);
      });
    }
    async delete(e3) {
      let t2 = await this.openDb();
      await new Promise((n2, r2) => {
        let i2 = t2.transaction(this.storeName, `readwrite`);
        i2.objectStore(this.storeName).delete(e3), i2.oncomplete = () => n2(), i2.onerror = () => r2(i2.error);
      });
    }
    async keys(e3) {
      let t2 = await this.openDb(), n2 = e3 === void 0 ? void 0 : IDBKeyRange.bound(e3, e3 + `\uFFFF`, false, false);
      return new Promise((e4, r2) => {
        let i2 = t2.transaction(this.storeName, `readonly`).objectStore(this.storeName), a2 = n2 === void 0 ? i2.getAllKeys() : i2.getAllKeys(n2);
        a2.onsuccess = () => e4(a2.result.map(String)), a2.onerror = () => r2(a2.error);
      });
    }
    openDb() {
      return this.dbPromise ||= new Promise((e3, t2) => {
        let n2 = indexedDB.open(this.dbName, 1);
        n2.onupgradeneeded = () => {
          let e4 = n2.result;
          e4.objectStoreNames.contains(this.storeName) || e4.createObjectStore(this.storeName);
        }, n2.onsuccess = () => e3(n2.result), n2.onerror = () => t2(n2.error);
      }), this.dbPromise;
    }
  };
})), Je, Ye = e((() => {
  Je = `pnm/step-up-approver/v1/`, `${Je}`, `${Je}`;
})), Xe = `inbound:pending`;
async function Ze(e3) {
  return await e3.get(Xe) ?? [];
}
function Qe(e3, t2) {
  if (e3 !== `persona/disclosure/present:stepUpRequired`) return null;
  let n2 = t2 ?? {}, r2 = typeof n2.previewId == `string` ? n2.previewId : ``, i2 = n2.approveRequest;
  return !r2 || !i2 || typeof i2 != `object` ? null : { kind: `stepUpRequired`, previewId: r2, previewRetained: n2.previewRetained === true, unverifiedApproveRequest: i2 };
}
function $e(e3, t2 = {}) {
  let n2 = t2.what ?? `URL`, r2;
  try {
    r2 = new URL(e3);
  } catch {
    throw Error(`${n2} ${JSON.stringify(e3)} is not a URL, so nothing was sent to it`);
  }
  let i2 = it(r2.hostname), a2 = t2.allowLoopback === true && et(i2);
  if (r2.protocol !== `https:` && !(a2 && r2.protocol === `http:`)) throw Error(`${n2} ${r2.href} is ${r2.protocol} \u2014 it must be https, so nothing was sent to it`);
  if (r2.username !== `` || r2.password !== ``) throw Error(`${n2} carries a username or password in the URL, which hides the host it would actually reach (${i2}), so nothing was sent to it`);
  if (a2) return r2;
  if (!tt(r2.hostname)) throw Error(`${n2}'s host ${i2} is not a public internet host, so nothing was sent to it`);
  return r2;
}
function et(e3) {
  let t2 = it(e3);
  if (t2 === `localhost` || t2.endsWith(`.localhost`) || t2 === `::1`) return true;
  let n2 = ct(t2);
  return n2 !== null && n2[0] === 127;
}
function tt(e3) {
  let t2 = it(e3);
  if (t2 === ``) return false;
  if (e3.startsWith(`[`)) return st(t2);
  let n2 = ct(t2);
  return n2 ? !ot(lt(n2)) : !rt(t2);
}
var nt = [`localhost`, `local`, `internal`, `home.arpa`];
function rt(e3) {
  return !e3.includes(`.`) || nt.some((t2) => e3 === t2 || e3.endsWith(`.${t2}`));
}
function it(e3) {
  let t2 = e3.toLowerCase();
  return t2.startsWith(`[`) && t2.endsWith(`]`) ? t2.slice(1, -1) : t2.replace(/\.+$/, ``);
}
var at = [[`0.0.0.0`, 8], [`10.0.0.0`, 8], [`100.64.0.0`, 10], [`127.0.0.0`, 8], [`169.254.0.0`, 16], [`172.16.0.0`, 12], [`192.0.0.0`, 24], [`192.0.2.0`, 24], [`192.168.0.0`, 16], [`198.18.0.0`, 15], [`198.51.100.0`, 24], [`203.0.113.0`, 24], [`224.0.0.0`, 4], [`240.0.0.0`, 4]];
function ot(e3) {
  return at.some(([t2, n2]) => {
    let r2 = ct(t2);
    if (!r2) return false;
    let i2 = 32 - n2;
    return e3 >>> i2 == lt(r2) >>> i2;
  });
}
function st(e3) {
  if (e3.includes(`.`)) return false;
  let t2 = (t3) => {
    let n3 = e3.split(`:`)[t3] ?? ``, r2 = Number.parseInt(n3, 16);
    return Number.isFinite(r2) ? r2 : 0;
  }, n2 = e3.startsWith(`::`) ? 0 : t2(0);
  if (n2 < 8192 || n2 > 16383 || n2 === 8194) return false;
  if (n2 === 8193) {
    let e4 = t2(1);
    if (e4 < 512 || e4 === 3512) return false;
  }
  return !(n2 === 16383 && t2(1) < 4096);
}
function ct(e3) {
  let t2 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(e3);
  if (!t2) return null;
  let n2 = [];
  for (let e4 of t2.slice(1)) {
    if (e4.length > 1 && e4.startsWith(`0`)) return null;
    let t3 = Number(e4);
    if (t3 > 255) return null;
    n2.push(t3);
  }
  return n2;
}
function lt(e3) {
  return ((e3[0] ?? 0) << 24 >>> 0) + ((e3[1] ?? 0) << 16) + ((e3[2] ?? 0) << 8) + (e3[3] ?? 0);
}
var ut = `https://trusttasks.org/spec/push/register/0.2`;
async function dt(e3) {
  $e(e3.gatewayUrl, { what: `push gateway URL` });
  let t2 = Be(e3.fetch), n2 = e3.gatewayUrl.replace(/\/+$/, ``), r2 = { id: globalThis.crypto.randomUUID(), type: ut, issuedAt: (/* @__PURE__ */ new Date()).toISOString(), payload: { registration: e3.registration, controllerVtaDid: e3.controllerVtaDid } }, i2 = await t2(`${n2}/trust-tasks`, { method: `POST`, headers: { "content-type": `application/json` }, body: JSON.stringify(r2) }), a2, o2;
  try {
    o2 = await i2.text(), a2 = JSON.parse(o2);
  } catch {
    throw Error(`push/register: ${n2}/trust-tasks failed (${i2.status}): ${o2 ?? `(no body)`}`);
  }
  if (Ue(a2?.type)) {
    let e4 = a2?.payload;
    throw Error(`${e4?.code ?? `unknown`}: ${e4?.message ?? `(no message)`}`);
  }
  if (!i2.ok) throw Error(`push/register: ${n2}/trust-tasks failed (${i2.status}): ${o2}`);
  if (a2?.type === `https://trusttasks.org/spec/push/register/0.2#response`) {
    let e4 = a2.payload?.wakeHandle;
    if (!e4?.gateway || !e4?.handle) throw Error(`push/register: malformed response payload: ${JSON.stringify(a2)}`);
    return e4;
  }
  throw Error(`push/register: unexpected response type ${a2?.type ?? `(none)`}`);
}
function ft(e3) {
  if (e3?.tab) {
    if (e3.origin) return e3.origin;
    if (e3.url) try {
      return new URL(e3.url).origin;
    } catch {
      return;
    }
  }
}
He();
var pt = `https://trusttasks.org/spec/auth/step-up/approve-response/0.6`, mt = `https://trusttasks.org/spec/task-consent/decision/0.2`, ht = 3e5;
function gt(e3, t2, n2) {
  return typeof n2 != `string` || !n2.startsWith(`did:`) ? `A step-up approver call needs the relying party's DID as audience.` : t2 ? n2 === t2.rpDid ? null : `The approver call names the relying party ${n2}, but ${e3} is pinned to ${t2.rpDid}. A page can only use the approver it holds for the relying party it was signed in to.` : `${e3} has no relying party pinned, so the wallet will not use a step-up approver for it. Sign in from this site first: the login prompt is where the site's relying party is shown and confirmed, and it pins that pairing.`;
}
function _t(e3) {
  let t2 = e3?.payload?.evidence?.statement?.id;
  return typeof t2 == `string` && t2 !== `` ? t2 : null;
}
var vt = /* @__PURE__ */ new Set([`subject`, `challenge`, `decision`, `evidence`, `sessionId`]);
function yt(e3, t2, n2, r2, i2 = Date.now()) {
  let a2 = (e4) => `${pt} cannot be signed for this page: ${e4}.`;
  if (!e3 || typeof e3 != `object` || Array.isArray(e3)) return a2(`it is not a Trust Task document`);
  let o2 = e3;
  if (o2.type !== `https://trusttasks.org/spec/auth/step-up/approve-response/0.6`) return a2(`wrong type`);
  if (o2.proof !== void 0) return a2(`it is already signed`);
  let s2 = o2.payload;
  if (!s2 || typeof s2 != `object` || Array.isArray(s2)) return a2(`it has no payload`);
  for (let e4 of Object.keys(s2)) if (!vt.has(e4)) return a2(`it carries an unexpected member ${e4}`);
  if (s2.decision !== `approved`) return a2(`only an approval is built this way`);
  let c2 = s2.evidence;
  if (!c2 || typeof c2 != `object` || c2.kind !== `approverSigned`) return a2(`its evidence is not an approver's statement`);
  for (let e4 of Object.keys(c2)) if (e4 !== `kind` && e4 !== `statement`) return a2(`its evidence carries ${e4}`);
  if (!t2) return a2(`it carries no statement this wallet's approver issued to it`);
  if ((t2.purpose ?? `stepUp`) !== `stepUp`) return a2(`the statement it carries was issued for a decision, not a step-up`);
  if (i2 > t2.expiresAt) return a2(`the approver's statement has lapsed`);
  if (t2.origin !== n2) return a2(`the statement was issued to another page`);
  if (o2.recipient !== t2.audience) return a2(`it is not addressed to the relying party the statement is for`);
  if (s2.subject !== t2.subject || s2.challenge !== t2.challenge) return a2(`its subject or challenge differs from the statement's`);
  if (r2 !== t2.subject) return a2(`it must be signed as its subject`);
  if (o2.issuer !== void 0 && o2.issuer !== t2.subject) return a2(`its issuer is not its subject`);
  let l2 = false;
  try {
    l2 = Ve(c2.statement) === Ve(t2.statement);
  } catch {
    l2 = false;
  }
  return l2 ? null : a2(`the statement it carries is not the one this wallet issued`);
}
function bt(e3) {
  return e3 === `enrol` ? null : e3 === `decision` ? `attestApprover does not sign decision statements; use approveDecision, which shows the action and checks its payloadDigest.` : e3 === `stepUp` ? `attestApprover does not sign step-up statements; use approveStepUp.` : `attestApprover signs enrolment statements only (purpose: enrol)`;
}
function xt(e3) {
  let t2 = e3?.payload?.evidence;
  if (t2?.kind !== `approverSigned`) return null;
  let n2 = t2.statement?.id;
  return typeof n2 == `string` && n2 !== `` ? n2 : null;
}
function St(e3) {
  let t2 = e3;
  return t2?.type === `https://trusttasks.org/spec/task-consent/decision/0.2` && t2.payload?.evidence?.kind === `approverSigned`;
}
var Ct = /* @__PURE__ */ new Set([`challenge`, `payloadDigest`, `decision`, `reason`, `actionId`, `evidence`]);
function wt(e3, t2, n2, r2, i2 = Date.now()) {
  let a2 = (e4) => `${mt} with an approver's statement cannot be signed for this page: ${e4}.`;
  if (!e3 || typeof e3 != `object` || Array.isArray(e3)) return a2(`it is not a Trust Task document`);
  let o2 = e3;
  if (o2.type !== `https://trusttasks.org/spec/task-consent/decision/0.2`) return a2(`wrong type`);
  if (o2.proof !== void 0) return a2(`it is already signed`);
  let s2 = o2.payload;
  if (!s2 || typeof s2 != `object` || Array.isArray(s2)) return a2(`it has no payload`);
  for (let e4 of Object.keys(s2)) if (!Ct.has(e4)) return a2(`it carries an unexpected member ${e4}`);
  let c2 = s2.evidence;
  if (!c2 || typeof c2 != `object` || c2.kind !== `approverSigned`) return a2(`its evidence is not an approver's statement`);
  for (let e4 of Object.keys(c2)) if (e4 !== `kind` && e4 !== `statement`) return a2(`its evidence carries ${e4}`);
  if (!t2) return a2(`it carries no statement this wallet's approver issued to it`);
  if (t2.purpose !== `decision`) return a2(`the statement it carries was not issued for a decision`);
  if (i2 > t2.expiresAt) return a2(`the approver's statement has lapsed`);
  if (t2.origin !== n2) return a2(`the statement was issued to another page`);
  if (o2.recipient !== t2.audience) return a2(`it is not addressed to the relying party the statement is for`);
  if (s2.challenge !== t2.challenge || s2.payloadDigest !== t2.payloadDigest) return a2(`its challenge or payloadDigest differs from the statement's`);
  if (s2.decision !== t2.decision) return a2(`its decision is not the ${String(t2.decision)} that was approved`);
  if ((s2.reason ?? void 0) !== (t2.reason ?? void 0)) return a2(`its reason is not the one shown when it was approved`);
  if ((s2.actionId ?? void 0) !== (t2.actionId ?? void 0)) return a2(`its actionId is not the action that was shown`);
  if (r2 !== t2.subject) return a2(`it must be signed as the statement's subject`);
  if (o2.issuer !== void 0 && o2.issuer !== t2.subject) return a2(`its issuer is not the statement's subject`);
  let l2 = false;
  try {
    l2 = Ve(c2.statement) === Ve(t2.statement);
  } catch {
    l2 = false;
  }
  return l2 ? null : a2(`the statement it carries is not the one this wallet issued`);
}
function Tt(e3) {
  if (typeof e3 == `string`) return e3.slice(0, 500) || void 0;
  if (!e3 || typeof e3 != `object` || Array.isArray(e3)) return;
  let { title: t2, effect: n2 } = e3, r2 = [t2, n2].filter((e4) => typeof e4 == `string` && e4 !== ``);
  return r2.length ? r2.join(` \u2014 `).slice(0, 500) : void 0;
}
var Et = `approver-consent:`;
async function Dt() {
  return Ot((await chrome.storage.local.get(`pnm-connection/v3`))[`pnm-connection/v3`]);
}
function Ot(e3) {
  if (typeof e3 != `string`) return null;
  try {
    return JSON.parse(e3).state?.connections?.activeVtaDid ?? null;
  } catch {
    return null;
  }
}
async function kt() {
  return At((await chrome.storage.local.get(`pnm-connection/v3`))[`pnm-connection/v3`]);
}
function At(e3) {
  if (typeof e3 != `string`) return [];
  try {
    let t2 = JSON.parse(e3);
    return Object.keys(t2.state?.connections?.vtas ?? {});
  } catch {
    return [];
  }
}
async function jt() {
  return Mt((await chrome.storage.local.get(`pnm-connection/v3`))[`pnm-connection/v3`]);
}
function Mt(e3) {
  if (typeof e3 != `string`) return {};
  try {
    let t2 = JSON.parse(e3), n2 = {};
    for (let [e4, r2] of Object.entries(t2.state?.connections?.vtas ?? {})) typeof r2?.mediatorDid == `string` && r2.mediatorDid && (n2[e4] = r2.mediatorDid);
    return n2;
  } catch {
    return {};
  }
}
async function Nt() {
  let e3 = (await chrome.storage.local.get(`pnm-connection/v3`))[`pnm-connection/v3`];
  if (typeof e3 != `string`) return null;
  try {
    let t2 = JSON.parse(e3).state?.connections;
    return t2?.activeVtaDid ? t2.vtas?.[t2.activeVtaDid]?.holderDid ?? null : null;
  } catch {
    return null;
  }
}
var Pt = `origin-pin:`;
function Ft(e3) {
  return `${Pt}${e3}`;
}
async function It(e3, t2, n2) {
  let r2 = await Lt(e3);
  if (!r2) return { firstSeen: true, rpDidChanged: false, baseUrlChanged: false };
  let i2 = n2 === void 0 ? void 0 : o(n2);
  return { firstSeen: false, pinnedRpDid: r2.rpDid, rpDidChanged: r2.rpDid !== t2, ...r2.baseUrl ? { pinnedBaseUrl: r2.baseUrl } : {}, baseUrlChanged: n2 !== void 0 && r2.baseUrl !== void 0 && i2 !== r2.baseUrl };
}
async function w(e3) {
  let t2 = await Lt(e3);
  if (t2 && typeof t2.rpDid == `string` && t2.rpDid !== ``) return { rpDid: t2.rpDid, ...typeof t2.baseUrl == `string` ? { baseUrl: t2.baseUrl } : {} };
}
async function Lt(e3) {
  let t2 = Ft(e3);
  return (await chrome.storage.local.get(t2))[t2];
}
async function Rt(e3, t2, n2) {
  let r2;
  if (n2 !== void 0) r2 = o(n2) ?? void 0;
  else {
    let n3 = await Lt(e3);
    n3 && n3.rpDid === t2 && (r2 = n3.baseUrl);
  }
  let i2 = { rpDid: t2, ...r2 ? { baseUrl: r2 } : {}, pinnedAt: Date.now() };
  await chrome.storage.local.set({ [Ft(e3)]: i2 });
}
var zt = 2592e6, Bt = `room-grants:`, Vt = `room-consent:`, Ht = 67108864, Ut = `room-names:`;
function Wt(e3, t2) {
  return `${Ut}${e3}|${t2}`;
}
function Gt(e3, t2, n2) {
  let r2 = {};
  if (e3 && typeof e3 == `object` && !Array.isArray(e3)) for (let [t3, n3] of Object.entries(e3)) {
    let e4 = n3;
    e4 && typeof e4.label == `string` && e4.label !== `` && typeof e4.seenAt == `number` && (r2[t3] = { label: e4.label, ...typeof e4.visibility == `string` ? { visibility: e4.visibility } : {}, seenAt: e4.seenAt });
  }
  for (let [e4, i3] of Object.entries(t2)) typeof i3?.label == `string` && i3.label !== `` && (r2[e4] = { label: i3.label, ...i3.visibility === void 0 ? {} : { visibility: i3.visibility }, seenAt: n2 });
  let i2 = Object.entries(r2);
  return i2.length <= 500 ? r2 : Object.fromEntries(i2.sort((e4, t3) => t3[1].seenAt - e4[1].seenAt).slice(0, 500));
}
function Kt(e3, t2) {
  return `${Bt}${t2}|${e3}`;
}
function qt(e3, t2, n2) {
  return e3.filter((e4) => e4.origin === t2.origin && e4.hostDid === t2.hostDid && e4.vtaDid === t2.vtaDid && e4.expiresAt > n2 && typeof e4.member == `string` && e4.member.startsWith(`did:`));
}
function Jt(e3, t2, n2, r2) {
  let i2 = qt(e3, t2, r2).find((e4) => e4.roomId === n2);
  return i2 ? { ok: true, grant: i2 } : { ok: false, error: `${t2.origin} has not been given that room. Ask the member to share it (window.vtaWallet.rooms.choose), which they do in their wallet's own window.` };
}
function Yt(e3, t2, n2, r2) {
  let i2 = new Map(n2.map((e4) => [e4.roomId, e4.member]));
  return [...e3.filter((e4) => e4.expiresAt > r2 && !(e4.origin === t2.origin && e4.hostDid === t2.hostDid && e4.vtaDid === t2.vtaDid && i2.has(e4.roomId))), ...[...i2].map(([e4, n3]) => ({ ...t2, roomId: e4, member: n3, grantedAt: r2, expiresAt: r2 + zt }))];
}
function Xt(e3, t2, n2) {
  return e3.filter((e4) => e4.origin !== t2.origin || e4.hostDid !== t2.hostDid || e4.vtaDid !== t2.vtaDid || e4.roomId !== n2);
}
function Zt(e3, t2, n2) {
  return e3 === n2 ? null : `${e3} is not ${t2}'s portal: its DID document names ${n2}. A page can use a community's rooms only from the portal the community's own DID document names.`;
}
var Qt = 2048, $t = 512, en = 512, tn = 2048, nn = 1048576, rn = 32, an = 64, on = 255, sn = 255, cn = (e3) => [...e3].length;
function T(e3, t2) {
  return typeof e3 == `string` && e3.startsWith(`did:`) && e3.length <= Qt ? null : `${t2} must be a DID`;
}
function E(e3, t2, n2, r2 = false) {
  return e3 === void 0 ? r2 ? `${t2} is required` : null : typeof e3 == `string` ? r2 && e3.trim() === `` ? `${t2} is required` : cn(e3) > n2 ? `${t2} is longer than ${n2} characters` : null : `${t2} must be a string`;
}
function ln(e3) {
  return e3 === void 0 ? null : !Array.isArray(e3) || e3.length > rn || e3.some((e4) => typeof e4 != `string` || cn(e4) > an) ? `tags: at most ${rn} of ${an} characters each` : null;
}
var un = /* @__PURE__ */ new Set([`list`, `choose`, `forget`, `info`, `browse`, `read`, `putNote`, `offers`, `acceptOffer`]);
function dn(e3) {
  if (!e3 || typeof e3 != `object` || Array.isArray(e3)) return `rooms: expected an object`;
  let t2 = e3;
  if (typeof t2.op != `string` || !un.has(t2.op)) return `rooms: unknown operation ${String(t2.op)}`;
  let n2 = t2, r2 = T(n2.hostDid, `hostDid`) ?? (n2.op === `list` || n2.op === `choose` || n2.op === `offers` ? null : T(n2.roomId, `roomId`)) ?? (n2.op === `choose` && n2.suggest !== void 0 ? T(n2.suggest, `suggest`) : null) ?? ((n2.op === `choose` || n2.op === `acceptOffer`) && n2.member !== void 0 ? T(n2.member, `member`) : null);
  if (r2) return r2;
  switch (n2.op) {
    case `browse`:
      return E(n2.prefix, `prefix`, $t) ?? (n2.sinceVersion !== void 0 && !(Number.isSafeInteger(n2.sinceVersion) && n2.sinceVersion >= 0) ? `sinceVersion must be a whole number` : null);
    case `read`:
      return E(n2.key, `key`, $t, true);
    case `putNote`:
      return E(n2.title, `title`, en, true) ?? E(n2.body, `body`, nn) ?? E(n2.description, `description`, tn) ?? ln(n2.tags);
    default:
      return null;
  }
}
function fn(e3) {
  if (!e3 || typeof e3 != `object` || Array.isArray(e3)) return `a transfer starts with get or put`;
  let t2 = e3;
  return t2.kind !== `get` && t2.kind !== `put` ? `a transfer starts with get or put` : (T(t2.hostDid, `hostDid`) ?? T(t2.roomId, `roomId`)) || (t2.kind === `get` ? E(t2.key, `key`, $t, true) : !Number.isSafeInteger(t2.size) || t2.size < 0 ? `size must be the file's length in bytes` : t2.size > 67108864 ? `a file of ${t2.size} bytes is more than the ${Ht} the wallet seals in one piece` : E(t2.name, `name`, on, true) ?? E(t2.mediaType, `mediaType`, sn) ?? E(t2.title, `title`, en) ?? E(t2.description, `description`, tn) ?? ln(t2.tags));
}
function pn(e3, t2 = 280) {
  if (!e3) return ``;
  let n2 = [...e3];
  return n2.length <= t2 ? e3 : `${n2.slice(0, t2).join(``)}\u2026`;
}
function mn(e3) {
  return e3 === void 0 ? `unknown` : e3.includes(`admin`) ? `administers` : `member`;
}
function hn(e3, t2) {
  return `${e3}|${t2}`;
}
function gn(e3, t2, n2, r2, i2, a2 = {}) {
  let o2 = new Set(t2.filter((e4) => e4 !== n2)), s2 = [], c2 = /* @__PURE__ */ new Set(), l2 = /* @__PURE__ */ new Set();
  for (let t3 of e3) {
    if (!t3.member || !o2.has(t3.member)) {
      c2.add(t3.roomId);
      continue;
    }
    let e4 = hn(t3.roomId, t3.member);
    if (l2.has(e4)) continue;
    l2.add(e4);
    let n3 = r2.some((e5) => e5.roomId === t3.roomId && e5.member === t3.member);
    s2.push({ key: e4, roomId: t3.roomId, member: t3.member, ...t3.context === void 0 ? {} : { context: t3.context }, role: mn(t3.actions), ...a2[t3.roomId] ? { label: a2[t3.roomId].label } : {}, shared: n3, ticked: n3 });
  }
  if (i2.suggest !== void 0 && !s2.some((e4) => e4.roomId === i2.suggest && e4.ticked)) {
    let e4 = s2.filter((e5) => e5.roomId === i2.suggest), t3 = e4.length === 1 ? e4[0] : e4.find((e5) => i2.member !== void 0 && e5.member === i2.member);
    t3 && (t3.ticked = true);
  }
  let u2 = new Set(s2.map((e4) => e4.roomId));
  return { rows: s2, others: [...c2].filter((e4) => !u2.has(e4)).length };
}
function _n(e3, t2) {
  let n2 = new Map(e3.map((e4) => [e4.key, e4])), r2 = /* @__PURE__ */ new Map();
  for (let e4 of new Set(t2)) {
    let t3 = n2.get(e4);
    if (t3) {
      if (r2.has(t3.roomId) && r2.get(t3.roomId) !== t3.member) return { ok: false, error: `${t3.roomId} was ticked as two members; a page uses a room as one` };
      r2.set(t3.roomId, t3.member);
    }
  }
  return { ok: true, shares: [...r2].map(([e4, t3]) => ({ roomId: e4, member: t3 })) };
}
function vn(e3) {
  return e3 === `private` ? `it is a private room: its host is not to learn which member acts, and this page is the host's own and knows who is signed in. Use it from your wallet's console instead.` : null;
}
var yn = 3e5, D = class extends Error {
}, bn = class {
  deps;
  portals = /* @__PURE__ */ new Map();
  namesReadAt = /* @__PURE__ */ new Map();
  profiles = /* @__PURE__ */ new Map();
  constructor(e3) {
    this.deps = e3;
  }
  async portal(e3, t2) {
    let n2 = this.deps.now(), r2 = this.portals.get(t2);
    if (r2 && n2 - r2.at < yn) return r2;
    let i2 = await this.deps.offscreen(e3, { op: `portal`, hostDid: t2 });
    if (!i2.ok) throw new D(i2.error);
    let a2 = i2.result;
    return this.portals.set(t2, { ...a2, at: n2 }), a2;
  }
  async atPortal(e3, t2, n2) {
    let r2 = await this.deps.active();
    if (!r2.ok) throw new D(r2.error);
    let { portalOrigin: i2, endpoint: a2 } = await this.portal(r2.vta, t2), o2 = Zt(e3, t2, i2);
    if (o2) throw new D(o2);
    if (n2.needReach && !await this.deps.canReach(a2)) throw new D(`The wallet may not reach ${new URL(a2).origin} yet. Share a room again (rooms.choose) and allow it there, or allow it from the wallet's popup.`);
    return { vta: r2.vta, endpoint: a2 };
  }
  async granted(e3, t2, n2, r2) {
    let i2 = Jt(await this.deps.loadGrants(e3, n2.vtaDid), { origin: e3, hostDid: t2, vtaDid: n2.vtaDid }, r2, this.deps.now());
    if (!i2.ok) throw new D(i2.error);
    return i2.grant.member;
  }
  async offscreen(e3, t2) {
    let n2 = await this.deps.offscreen(e3, t2);
    if (!n2.ok) throw new D(n2.error);
    return n2.result;
  }
  async handle(e3, t2) {
    try {
      let n2 = dn(t2);
      return n2 ? { ok: false, error: n2 } : { ok: true, result: await this.run(e3, t2) };
    } catch (e4) {
      return { ok: false, error: e4 instanceof Error ? e4.message : String(e4) };
    }
  }
  async run(e3, t2) {
    switch (t2.op) {
      case `list`: {
        let { vta: n2 } = await this.atPortal(e3, t2.hostDid, { needReach: false });
        return { rooms: await this.views(e3, t2.hostDid, n2) };
      }
      case `choose`:
        return this.choose(e3, t2.hostDid, { suggest: t2.suggest, member: t2.member });
      case `forget`: {
        let { vta: n2 } = await this.atPortal(e3, t2.hostDid, { needReach: false }), r2 = await this.deps.loadGrants(e3, n2.vtaDid), i2 = Xt(r2, { origin: e3, hostDid: t2.hostDid, vtaDid: n2.vtaDid }, t2.roomId);
        return await this.deps.saveGrants(e3, n2.vtaDid, i2), { forgotten: i2.length !== r2.length };
      }
      case `info`:
      case `browse`:
      case `read`: {
        let { vta: n2 } = await this.atPortal(e3, t2.hostDid, { needReach: true }), r2 = await this.granted(e3, t2.hostDid, n2, t2.roomId), i2 = { hostDid: t2.hostDid, roomId: t2.roomId, member: r2 };
        return this.offscreen(n2, t2.op === `info` ? { op: `info`, ...i2 } : t2.op === `read` ? { op: `read`, ...i2, key: t2.key } : { op: `browse`, ...i2, ...t2.prefix === void 0 ? {} : { prefix: t2.prefix }, ...t2.sinceVersion === void 0 ? {} : { sinceVersion: t2.sinceVersion } });
      }
      case `offers`:
      case `acceptOffer`: {
        if (!this.deps.offers) throw new D(`this wallet does not handle room offers`);
        let { vta: n2 } = await this.atPortal(e3, t2.hostDid, { needReach: false }), r2 = (await this.offscreen(n2, { op: `members`, hostDid: t2.hostDid })).filter((e4) => e4 !== t2.hostDid);
        if (t2.op === `offers`) return this.deps.offers.forPortal(n2, t2.hostDid, r2);
        if (t2.member !== void 0 && !r2.includes(t2.member)) throw new D(`${t2.member} is not an identity you use at this community`);
        return this.deps.offers.accept({ communityDid: t2.hostDid, roomId: t2.roomId, ...t2.member === void 0 ? {} : { member: t2.member }, origin: e3, vta: n2, members: r2 });
      }
      case `putNote`: {
        let { vta: n2 } = await this.atPortal(e3, t2.hostDid, { needReach: true }), r2 = await this.granted(e3, t2.hostDid, n2, t2.roomId), i2 = await this.offscreen(n2, { op: `info`, hostDid: t2.hostDid, roomId: t2.roomId, member: r2 });
        if (!(await this.deps.prompt({ kind: `write`, origin: e3, hostDid: t2.hostDid, roomId: t2.roomId, member: i2.member, visibility: i2.visibility, what: { note: true, title: t2.title, excerpt: pn(t2.body), bodyChars: [...t2.body ?? ``].length } })).approved) throw new D(`the member declined to add this note`);
        return this.offscreen(n2, { op: `putNote`, hostDid: t2.hostDid, roomId: t2.roomId, member: r2, title: t2.title, ...t2.body === void 0 ? {} : { body: t2.body }, ...t2.description === void 0 ? {} : { description: t2.description }, ...t2.tags === void 0 ? {} : { tags: t2.tags } });
      }
    }
  }
  async roomNames(e3, t2, n2) {
    let r2 = this.deps.now(), i2;
    try {
      i2 = this.deps.loadRoomNames ? await this.deps.loadRoomNames(e3.vtaDid, t2) : void 0;
    } catch {
      i2 = void 0;
    }
    let a2 = (n3) => `${e3.vtaDid}|${t2}|${n3}`, o2 = [...new Set(n2)].filter((e4) => {
      let t3 = this.namesReadAt.get(a2(e4));
      return t3 === void 0 || r2 - t3 >= 6e4;
    }), s2 = Gt(i2, {}, r2);
    if (o2.length > 0) {
      for (let e4 of o2) this.namesReadAt.set(a2(e4), r2);
      try {
        let n3 = await this.deps.offscreen(e3, { op: `roomNames`, hostDid: t2, members: o2 });
        n3.ok && n3.result && typeof n3.result == `object` && !Array.isArray(n3.result) && (s2 = Gt(i2, n3.result, r2), await this.deps.saveRoomNames?.(e3.vtaDid, t2, s2));
      } catch {
      }
    }
    return Object.fromEntries(Object.entries(s2).map(([e4, t3]) => [e4, { label: t3.label, ...t3.visibility === void 0 ? {} : { visibility: t3.visibility } }]));
  }
  async roomProfiles(e3, t2, n2) {
    let r2 = this.deps.now(), i2 = (n3) => `${e3.vtaDid}|${t2}|${n3.roomId}|${n3.member}`, a2 = n2.filter((e4) => {
      let t3 = this.profiles.get(i2(e4));
      return t3 === void 0 || r2 - t3.at >= 6e4;
    });
    if (a2.length > 0) {
      let n3 = {};
      try {
        let r3 = await this.deps.offscreen(e3, { op: `roomProfiles`, hostDid: t2, rooms: a2 });
        r3.ok && r3.result && typeof r3.result == `object` && !Array.isArray(r3.result) && (n3 = r3.result);
      } catch {
      }
      for (let e4 of a2) this.profiles.set(i2(e4), { at: r2, summary: n3[e4.roomId] ?? null });
    }
    let o2 = {};
    for (let e4 of n2) {
      let t3 = this.profiles.get(i2(e4))?.summary;
      t3 && o2[e4.roomId] === void 0 && (o2[e4.roomId] = t3);
    }
    return o2;
  }
  async displayNames(e3, t2, n2, r2) {
    return xn(await this.roomNames(e3, t2, n2), await this.roomProfiles(e3, t2, r2));
  }
  async views(e3, t2, n2) {
    let r2 = qt(await this.deps.loadGrants(e3, n2.vtaDid), { origin: e3, hostDid: t2, vtaDid: n2.vtaDid }, this.deps.now());
    if (r2.length === 0) return [];
    let i2 = await this.offscreen(n2, { op: `held` }), a2 = await this.displayNames(n2, t2, r2.map((e4) => e4.member), r2.filter((e4) => i2.some((t3) => t3.roomId === e4.roomId && t3.member === e4.member)));
    return r2.map((e4) => {
      let t3 = i2.find((t4) => t4.roomId === e4.roomId && t4.member === e4.member);
      return { roomId: e4.roomId, member: e4.member, held: t3 !== void 0, ...t3 ? { epoch: t3.epoch, earliestReadableEpoch: t3.earliestReadableEpoch } : {}, sharedAt: new Date(e4.grantedAt).toISOString(), expiresAt: new Date(e4.expiresAt).toISOString(), ...a2[e4.roomId] ? a2[e4.roomId] : {} };
    });
  }
  async choose(e3, t2, n2) {
    let { vta: r2, endpoint: i2 } = await this.atPortal(e3, t2, { needReach: false }), a2 = { origin: e3, hostDid: t2, vtaDid: r2.vtaDid }, o2 = this.deps.now(), s2 = await this.deps.loadGrants(e3, r2.vtaDid), c2 = await this.offscreen(r2, { op: `held` }), l2 = await this.offscreen(r2, { op: `members`, hostDid: t2 }), u2 = l2.filter((e4) => e4 !== t2), d2 = await this.displayNames(r2, t2, u2, c2.flatMap((e4) => e4.member !== void 0 && u2.includes(e4.member) ? [{ roomId: e4.roomId, member: e4.member }] : [])), { rows: f2, others: p2 } = gn(c2, l2, t2, qt(s2, a2, o2), { ...n2.suggest === void 0 ? {} : { suggest: n2.suggest }, ...n2.member === void 0 ? {} : { member: n2.member } }, d2), m2 = await this.deps.canReach(i2), h2 = await this.deps.prompt({ kind: `share`, origin: e3, hostDid: t2, rooms: f2, members: l2, others: p2, ...m2 ? {} : { needsOrigin: new URL(i2).origin } });
    if (!h2.approved) return { rooms: await this.views(e3, t2, r2), refused: [] };
    let g2 = _n(f2, h2.selectedRooms ?? []);
    if (!g2.ok) throw new D(g2.error);
    let _2 = [], v2 = [];
    for (let e4 of g2.shares) {
      let n3 = await this.deps.offscreen(r2, { op: `info`, hostDid: t2, ...e4 });
      if (!n3.ok) {
        _2.push({ roomId: e4.roomId, reason: `the community could not confirm it holds this room for ${e4.member}: ${n3.error}` });
        continue;
      }
      let i3 = vn(n3.result.visibility);
      if (i3) {
        _2.push({ roomId: e4.roomId, reason: `not shared: ${i3}` });
        continue;
      }
      v2.push(e4);
    }
    let y2 = s2.filter((n3) => n3.origin !== e3 || n3.hostDid !== t2 || n3.vtaDid !== r2.vtaDid);
    return y2 = Yt(y2, a2, v2, o2), await this.deps.saveGrants(e3, r2.vtaDid, y2), { rooms: await this.views(e3, t2, r2), refused: _2 };
  }
  servePort(e3, t2) {
    let n2 = true, r2, i2 = (t3) => {
      if (n2) try {
        e3.postMessage(t3);
      } catch {
        n2 = false, r2?.disconnect();
      }
    }, a2 = (t3) => {
      i2(t3), n2 && (n2 = false, e3.disconnect()), r2?.disconnect();
    };
    e3.onDisconnect.addListener(() => {
      n2 = false, r2?.disconnect();
    });
    let o2 = false, s2;
    e3.onMessage.addListener((e4) => {
      if (!o2) {
        o2 = true, this.startTransfer(t2, e4, i2, a2, (e5) => {
          r2 = e5;
        }, (e5) => {
          s2 = e5;
        }).catch((e5) => a2({ kind: `failed`, error: e5 instanceof Error ? e5.message : String(e5) }));
        return;
      }
      let n3 = e4;
      if (!s2?.ready || !r2) return a2({ kind: `failed`, error: `send the file only after the wallet is ready` });
      if (n3.kind === `data` && typeof n3.data == `string`) {
        if (s2.sent += Math.floor(n3.data.length * 3 / 4), s2.sent > s2.size + 2) return a2({ kind: `failed`, error: `more bytes than the file was declared to hold` });
        r2.postMessage({ kind: `data`, data: n3.data });
      } else n3.kind === `end` ? r2.postMessage({ kind: `end` }) : a2({ kind: `failed`, error: `a transfer takes data, then end` });
    });
  }
  async startTransfer(e3, t2, n2, r2, i2, a2) {
    let o2 = fn(t2);
    if (o2) return r2({ kind: `failed`, error: o2 });
    let s2 = t2, c2, l2;
    try {
      ({ vta: c2 } = await this.atPortal(e3, s2.hostDid, { needReach: true })), l2 = await this.granted(e3, s2.hostDid, c2, s2.roomId);
    } catch (e4) {
      return r2({ kind: `failed`, error: e4 instanceof Error ? e4.message : String(e4) });
    }
    let u2 = { vtaDid: c2.vtaDid, ...c2.restBaseUrl ? { restBaseUrl: c2.restBaseUrl } : {}, roomId: s2.roomId, hostDid: s2.hostDid, member: l2 };
    if (s2.kind === `put`) {
      let t3 = await this.offscreen(c2, { op: `info`, hostDid: s2.hostDid, roomId: s2.roomId, member: l2 });
      if (!(await this.deps.prompt({ kind: `write`, origin: e3, hostDid: s2.hostDid, roomId: s2.roomId, member: t3.member, visibility: t3.visibility, what: { file: true, name: s2.name, size: s2.size, ...s2.mediaType === void 0 ? {} : { mediaType: s2.mediaType }, ...s2.title === void 0 ? {} : { title: s2.title } } })).approved) return r2({ kind: `failed`, error: `the member declined to add this file` });
    }
    let d2 = await this.deps.openTransfer();
    i2(d2);
    let f2 = [], p2, m2 = false;
    d2.onMessage.addListener((e4) => {
      let t3 = e4;
      switch (t3.kind) {
        case `progress`:
          n2({ kind: `progress`, stage: t3.stage, ...t3.done === void 0 ? {} : { done: t3.done }, ...t3.total === void 0 ? {} : { total: t3.total } });
          return;
        case `provisional`:
          f2.push(t3.data);
          return;
        case `got`:
          p2 = t3, m2 = true, n2({ kind: `got`, file: t3.file, author: t3.author, version: t3.version, ...t3.title === void 0 ? {} : { title: t3.title }, ...t3.description === void 0 ? {} : { description: t3.description }, ...t3.tags === void 0 ? {} : { tags: t3.tags } });
          for (let e5 of f2.splice(0)) n2({ kind: `data`, data: e5 });
          r2({ kind: `done` });
          return;
        case `put`:
          m2 = true, r2({ kind: `put`, key: t3.key, version: t3.version, size: t3.size });
          return;
        case `failed`:
          m2 = true, f2.length = 0, r2({ kind: `failed`, error: t3.error });
          return;
      }
    }), d2.onDisconnect.addListener(() => {
      f2.length = 0, !m2 && !p2 && r2({ kind: `failed`, error: `the wallet's transfer ended before it finished` });
    });
    let h2 = s2.kind === `get` ? { kind: `get`, ...u2, key: s2.key } : { kind: `put`, ...u2, name: s2.name, size: s2.size, ...s2.mediaType === void 0 ? {} : { mediaType: s2.mediaType }, ...s2.title === void 0 ? {} : { title: s2.title }, ...s2.description === void 0 ? {} : { description: s2.description }, ...s2.tags === void 0 ? {} : { tags: s2.tags } };
    d2.postMessage(h2), s2.kind === `put` && (a2({ size: s2.size, sent: 0, ready: true }), n2({ kind: `ready` }));
  }
};
function xn(e3, t2) {
  let n2 = {};
  for (let [t3, r2] of Object.entries(e3)) n2[t3] = { ...r2, labelSource: `community` };
  for (let [e4, r2] of Object.entries(t2)) {
    let t3 = n2[e4], i2 = { ...r2.stale ? { profileStale: true } : {}, ...r2.renameRefused ? { renameRefused: true } : {} };
    r2.status === `found` && r2.name !== void 0 ? n2[e4] = { label: r2.name, ...t3?.visibility === void 0 ? {} : { visibility: t3.visibility }, labelSource: `profile`, ...r2.description === void 0 ? {} : { description: r2.description }, ...i2 } : t3 && (n2[e4] = { ...t3, ...i2 });
  }
  return n2;
}
var Sn = `directory-consent:`, Cn = 2048;
function wn(e3) {
  return typeof e3 == `string` && e3.startsWith(`did:`) && e3.length <= Cn;
}
function Tn(e3) {
  if (!e3 || typeof e3 != `object` || Array.isArray(e3)) return `the call must be an object`;
  let t2 = e3;
  if (t2.op !== `publishCard`) return `unknown directory operation`;
  for (let e4 of Object.keys(t2)) if (![`op`, `hostDid`, `member`].includes(e4)) return `publishCard takes no \`${e4}\``;
  return wn(t2.hostDid) ? t2.member !== void 0 && !wn(t2.member) ? `member must be a DID` : null : `hostDid must be a DID`;
}
function En(e3, t2, n2) {
  return e3 === n2 ? null : `${e3} is not ${t2}'s portal: its DID document names ${n2}. A page can publish a member's card only from the portal the community's own DID document names.`;
}
var Dn = 3e5, O = class extends Error {
}, On = class {
  deps;
  portals = /* @__PURE__ */ new Map();
  constructor(e3) {
    this.deps = e3;
  }
  async offscreen(e3, t2) {
    let n2 = await this.deps.offscreen(e3, t2);
    if (!n2.ok) throw new O(n2.error);
    return n2.result;
  }
  async portal(e3, t2) {
    let n2 = this.deps.now(), r2 = this.portals.get(t2);
    if (r2 && n2 - r2.at < Dn) return r2;
    let i2 = await this.offscreen(e3, { op: `portal`, hostDid: t2 });
    return this.portals.set(t2, { ...i2, at: n2 }), i2;
  }
  async handle(e3, t2) {
    try {
      let n2 = Tn(t2);
      return n2 ? { ok: false, error: n2 } : { ok: true, result: await this.publishCard(e3, t2) };
    } catch (e4) {
      return { ok: false, error: e4 instanceof Error ? e4.message : String(e4) };
    }
  }
  async publishCard(e3, t2) {
    let n2 = await this.deps.active();
    if (!n2.ok) throw new O(n2.error);
    let r2 = n2.vta, { portalOrigin: i2, endpoint: a2 } = await this.portal(r2, t2.hostDid), o2 = En(e3, t2.hostDid, i2);
    if (o2) throw new O(o2);
    if (!await this.deps.canReach(a2)) throw new O(`The wallet may not reach ${new URL(a2).origin} yet. Allow it from the wallet's popup, then try again.`);
    let s2 = (await this.offscreen(r2, { op: `members`, hostDid: t2.hostDid })).filter((e4) => e4 !== t2.hostDid), c2;
    if (t2.member !== void 0) {
      if (!s2.includes(t2.member)) throw new O(`The wallet holds no such identity for this community.`);
      c2 = t2.member;
    } else if (s2.length === 1) c2 = s2[0];
    else throw new O(s2.length === 0 ? `The wallet holds no identity you use at this community.` : `You use more than one identity at this community: sign in with the one whose card to publish.`);
    let l2 = await this.offscreen(r2, { op: `prepare`, hostDid: t2.hostDid, member: c2 });
    if (!(await this.deps.prompt({ kind: `publishCard`, origin: e3, hostDid: t2.hostDid, communityName: l2.communityName, member: c2, meaning: l2.said.meaning, values: l2.said.values, closing: l2.said.closing })).approved) throw new O(`You did not publish your card.`);
    return await this.offscreen(r2, { op: `publish`, hostDid: t2.hostDid, member: c2, card: l2.card, revision: l2.revision });
  }
};
function kn(e3) {
  if (!e3 || typeof e3 != `object`) return false;
  let t2 = e3;
  return typeof t2.id == `string` && t2.kind === `myterms` && typeof t2.vtaDid == `string` && typeof t2.holder == `string` && typeof t2.counterparty == `string` && typeof t2.site == `string` && !!t2.terms && typeof t2.terms.code == `string` && !!t2.reached && typeof t2.reached.at == `number` && (t2.status === `proffered` || t2.status === `agreed` || t2.status === `declined`);
}
function An(e3) {
  let t2 = /* @__PURE__ */ new Map();
  for (let n2 of e3) {
    let e4 = t2.get(n2.counterparty);
    (!e4 || n2.reached.at > e4.reached.at) && t2.set(n2.counterparty, n2);
  }
  return [...t2.values()].sort((e4, t3) => t3.reached.at - e4.reached.at);
}
var jn = 2048;
function Mn(e3) {
  return typeof e3 == `string` && e3.startsWith(`did:`) && e3.length <= jn;
}
function Nn(e3) {
  if (!e3 || typeof e3 != `object` || Array.isArray(e3)) return `the call must be an object`;
  let t2 = e3;
  if (t2.op !== `status`) return `unknown membership operation`;
  for (let e4 of Object.keys(t2)) if (![`op`, `hostDid`].includes(e4)) return `status takes no \`${e4}\``;
  return Mn(t2.hostDid) ? null : `hostDid must be a DID`;
}
function Pn(e3, t2, n2) {
  let r2 = [...new Set(t2.filter((t3) => t3 !== e3))];
  if (r2.length === 0) return { member: false };
  let i2 = An(n2.filter((t3) => t3.counterparty === e3))[0];
  return { member: true, identities: r2, ...i2 ? { agreement: { code: i2.terms.code, status: i2.status, at: i2.reached.at } } : {} };
}
var Fn = 3e5, In = class extends Error {
}, Ln = class {
  deps;
  portals = /* @__PURE__ */ new Map();
  constructor(e3) {
    this.deps = e3;
  }
  async offscreen(e3, t2) {
    let n2 = await this.deps.offscreen(e3, t2);
    if (!n2.ok) throw new In(n2.error);
    return n2.result;
  }
  async portalOrigin(e3, t2) {
    let n2 = this.deps.now(), r2 = this.portals.get(t2);
    if (r2 && n2 - r2.at < Fn) return r2.portalOrigin;
    let i2 = await this.offscreen(e3, { op: `portal`, hostDid: t2 });
    return this.portals.set(t2, { portalOrigin: i2.portalOrigin, at: n2 }), i2.portalOrigin;
  }
  async handle(e3, t2) {
    try {
      let n2 = Nn(t2);
      return n2 ? { ok: false, error: n2 } : { ok: true, result: await this.status(e3, t2) };
    } catch (e4) {
      return { ok: false, error: e4 instanceof Error ? e4.message : String(e4) };
    }
  }
  async status(e3, t2) {
    let n2 = await this.deps.active();
    if (!n2.ok) throw new In(n2.error);
    let r2 = n2.vta, i2 = En(e3, t2.hostDid, await this.portalOrigin(r2, t2.hostDid));
    if (i2) throw new In(i2);
    let a2 = await this.offscreen(r2, { op: `members`, hostDid: t2.hostDid }), o2 = await this.deps.agreements(r2.vtaDid).catch(() => []);
    return Pn(t2.hostDid, a2, o2);
  }
}, Rn = `agreements:`;
async function zn(e3) {
  let t2 = `${Rn}${e3}`, n2 = (await chrome.storage.local.get(t2))[t2];
  return Array.isArray(n2) ? n2.filter(kn) : [];
}
function Bn(e3, t2, n2) {
  return n2 !== t2 && e3.some((e4) => e4.communityDid === t2 && e4.members.includes(n2));
}
function Vn(e3) {
  return e3.state === `offered` || e3.state === `unfinished`;
}
function Hn(e3) {
  return e3.filter(Vn).length;
}
function Un(e3) {
  return { roomId: e3.roomId, member: e3.member, label: e3.label, visibility: e3.visibility, actions: [...e3.actions], validUntil: e3.validUntil, offeredAt: e3.offeredAt, ...e3.description === void 0 ? {} : { description: e3.description }, ...e3.admittedAt === void 0 ? {} : { admittedAt: e3.admittedAt }, ...e3.removedAt === void 0 ? {} : { removedAt: e3.removedAt }, ...e3.repeatAcceptUntil === void 0 ? {} : { repeatAcceptUntil: e3.repeatAcceptUntil }, state: e3.state };
}
function Wn(e3, t2, n2) {
  let r2 = e3.filter((e4) => e4.roomId === t2 && Vn(e4) && (n2 === void 0 || e4.member === n2));
  return r2.length === 1 ? { ok: true, offer: r2[0] } : r2.length === 0 ? { ok: false, error: `There is no open offer of that room to you here, and nothing to finish.` } : { ok: false, error: `That room is offered to more than one identity you use here: name the one to join as (member).` };
}
var k = class extends Error {
  code;
  constructor(e3, t2) {
    super(e3), this.code = t2, this.name = `RoomOffersRefusal`;
  }
}, Gn = 6e4, Kn = 1e4, qn = 3e5, Jn = class {
  deps;
  endpoints = /* @__PURE__ */ new Map();
  lists = /* @__PURE__ */ new Map();
  accepting = /* @__PURE__ */ new Set();
  constructor(e3) {
    this.deps = e3;
  }
  async offscreen(e3, t2) {
    let n2 = await this.deps.offscreen(e3, t2);
    if (!n2.ok) throw new k(n2.error, n2.code);
    return n2.result;
  }
  async vta() {
    let e3 = await this.deps.active();
    if (!e3.ok) throw new k(e3.error);
    return e3.vta;
  }
  async endpoint(e3, t2) {
    let n2 = this.deps.now(), r2 = this.endpoints.get(t2);
    if (r2 && n2 - r2.at < qn) return r2;
    let i2;
    try {
      i2 = { endpoint: (await this.offscreen(e3, { op: `endpoint`, communityDid: t2 })).endpoint };
    } catch (e4) {
      i2 = { error: e4 instanceof Error ? e4.message : String(e4), ...e4 instanceof k && e4.code ? { code: e4.code } : {} };
    }
    return this.endpoints.set(t2, { ...i2, at: n2 }), i2;
  }
  key(e3, t2, n2) {
    return `${e3.vtaDid}|${t2}|${n2}`;
  }
  async listed(e3, t2, n2, r2) {
    let i2 = this.deps.now(), a2 = this.key(e3, t2, n2), o2 = this.lists.get(a2), s2 = r2 ? Kn : Gn;
    if (o2 && i2 - o2.at < s2) return o2;
    let c2;
    try {
      let r3 = await this.offscreen(e3, { op: `list`, communityDid: t2, member: n2 });
      c2 = { at: i2, offers: r3 };
      let a3 = {};
      for (let e4 of r3) e4.label !== `` && (a3[e4.roomId] = { label: e4.label, visibility: e4.visibility });
      Object.keys(a3).length > 0 && await this.deps.rememberNames?.(e3.vtaDid, t2, a3).catch(() => {
      });
    } catch (e4) {
      c2 = { at: i2, error: e4 instanceof Error ? e4.message : String(e4), ...e4 instanceof k && e4.code ? { code: e4.code } : {} };
    }
    return this.lists.set(a2, c2), c2;
  }
  async overview(e3 = {}) {
    let t2 = await this.vta(), n2 = await this.offscreen(t2, { op: `sources` }), r2 = [], i2 = [];
    for (let a3 of n2) {
      let n3 = await this.endpoint(t2, a3.communityDid);
      if (!n3.endpoint && n3.code === `noRoomOffers`) {
        i2.push(a3.communityDid);
        continue;
      }
      if (!n3.endpoint) {
        r2.push({ communityDid: a3.communityDid, reachable: false, error: n3.error ?? `no endpoint`, members: [] });
        continue;
      }
      let o2 = new URL(n3.endpoint).origin;
      if (!await this.deps.canReach(n3.endpoint)) {
        r2.push({ communityDid: a3.communityDid, endpointOrigin: o2, reachable: false, members: [] });
        continue;
      }
      let s2 = [];
      for (let n4 of a3.members) {
        let r3 = await this.listed(t2, a3.communityDid, n4, e3.force === true);
        `error` in r3 && r3.code === `noRoomOffers` || s2.push(`offers` in r3 ? { member: n4, offers: r3.offers } : { member: n4, offers: [], error: r3.error, ...r3.code ? { code: r3.code } : {} });
      }
      if (s2.length === 0 && a3.members.length > 0) {
        i2.push(a3.communityDid);
        continue;
      }
      r2.push({ communityDid: a3.communityDid, endpointOrigin: o2, reachable: true, members: s2 });
    }
    let a2 = Hn(r2.flatMap((e4) => e4.members.flatMap((e5) => e5.offers)));
    return await this.deps.setOpenCount?.(t2.vtaDid, a2).catch(() => {
    }), { vtaDid: t2.vtaDid, communities: r2, noOffers: i2, openCount: a2, readAt: new Date(this.deps.now()).toISOString() };
  }
  async forPortal(e3, t2, n2) {
    let r2 = await this.endpoint(e3, t2);
    if (!r2.endpoint && r2.code === `noRoomOffers`) return { offers: [] };
    if (!r2.endpoint) throw new k(`the wallet could not find where ${t2} takes requests`);
    if (!await this.deps.canReach(r2.endpoint)) return { offers: [], needsOrigin: new URL(r2.endpoint).origin };
    let i2 = [];
    for (let r3 of new Set(n2)) {
      if (r3 === t2) continue;
      let n3 = await this.listed(e3, t2, r3, false);
      `offers` in n3 && i2.push(...n3.offers.map(Un));
    }
    return { offers: i2 };
  }
  async accept(e3) {
    let t2 = e3.vta ?? await this.vta(), n2 = e3.members;
    if (!n2) {
      let r3 = await this.offscreen(t2, { op: `sources` });
      if (e3.member === void 0 || !Bn(r3, e3.communityDid, e3.member)) throw new k(`${e3.member ?? `(no identity)`} is not an identity you sign in to ${e3.communityDid} with`);
      n2 = [e3.member];
    }
    n2 = n2.filter((t3) => t3 !== e3.communityDid);
    let r2 = await this.endpoint(t2, e3.communityDid);
    if (!r2.endpoint) throw new k(r2.error ?? `the wallet could not find where ${e3.communityDid} takes requests`, r2.code);
    let i2 = await this.deps.canReach(r2.endpoint), a2 = [];
    if (i2) for (let r3 of n2) {
      if (e3.member !== void 0 && r3 !== e3.member) continue;
      let n3 = await this.listed(t2, e3.communityDid, r3, true);
      if (`offers` in n3) a2.push(...n3.offers);
      else if (e3.member !== void 0) throw new k(n3.error, n3.code);
    }
    if (!i2) {
      if (!(await this.deps.prompt({ kind: `offer`, ...e3.origin === void 0 ? {} : { origin: e3.origin }, communityDid: e3.communityDid, member: e3.member ?? n2[0] ?? ``, roomId: e3.roomId, label: ``, visibility: ``, actions: [], validUntil: ``, resume: false, needsOrigin: new URL(r2.endpoint).origin })).approved) throw new k(`the member did not allow the wallet to reach the community`, `declined`);
      return this.accept({ ...e3, vta: t2, members: n2 });
    }
    let o2 = Wn(a2, e3.roomId, e3.member);
    if (!o2.ok) throw new k(o2.error, `noOffer`);
    let s2 = o2.offer, c2 = `${this.key(t2, s2.communityDid, s2.member)}|${s2.roomId}`;
    if (this.accepting.has(c2)) throw new k(`this offer is being accepted already`, `busy`);
    this.accepting.add(c2);
    try {
      if (!(await this.deps.prompt({ kind: `offer`, ...e3.origin === void 0 ? {} : { origin: e3.origin }, communityDid: s2.communityDid, member: s2.member, roomId: s2.roomId, label: s2.label, ...s2.description === void 0 ? {} : { description: s2.description }, visibility: s2.visibility, actions: s2.actions, validUntil: s2.validUntil, resume: s2.state === `unfinished` })).approved) throw new k(`the member declined the offer here; it stays open`, `declined`);
      try {
        return await this.offscreen(t2, { op: `accept`, communityDid: s2.communityDid, member: s2.member, roomId: s2.roomId });
      } finally {
        this.lists.delete(this.key(t2, s2.communityDid, s2.member));
      }
    } finally {
      this.accepting.delete(c2);
    }
  }
}, Yn = `trusted-site:`;
function Xn(e3) {
  return `${Yn}${e3}`;
}
async function Zn(e3) {
  if (!e3) return false;
  let t2 = Xn(e3);
  return (await chrome.storage.local.get(t2))[t2] !== void 0;
}
async function Qn(e3, t2) {
  if (!e3) return;
  let n2 = { origin: e3, trustedAt: Date.now(), ...t2 ? { rpDid: t2 } : {} };
  await chrome.storage.local.set({ [Xn(e3)]: n2 });
}
function $n(e3) {
  return !e3.changedFromRpDid && !e3.changedFromBaseUrl && !e3.sessionKey;
}
function er(e3) {
  return !e3.sessionKey;
}
var tr = `site-identity:`, nr = `holder`;
function rr(e3) {
  return `${tr}${e3}`;
}
async function ir(e3) {
  if (!e3) return false;
  let t2 = rr(e3);
  return (await chrome.storage.local.get(t2))[t2]?.kind === nr;
}
async function ar(e3) {
  if (!e3) return;
  let t2 = { kind: nr, chosenAt: Date.now() };
  await chrome.storage.local.set({ [rr(e3)]: t2 });
}
async function or(e3) {
  e3 && await chrome.storage.local.remove(rr(e3));
}
var A = `didSelfIssued`;
function sr(e3, t2) {
  return e3.filter((e4) => e4.secretKind === `didSelfIssued` && e4.targets.some((e5) => e5.kind === `webOrigin` && e5.origin === t2)).sort((e4, t3) => e4.createdAt.localeCompare(t3.createdAt))[0];
}
function cr(e3) {
  try {
    return new URL(e3).hostname || e3;
  } catch {
    return e3;
  }
}
function lr(e3) {
  return { contextId: e3.contextId, label: cr(e3.origin), targets: [{ kind: `webOrigin`, origin: e3.origin }, ...e3.rpDid ? [{ kind: `did`, did: e3.rpDid }] : []], secretKind: A, secret: { kind: `didSelfIssued`, did: e3.did, signingKeyId: e3.signingKeyId } };
}
function ur(e3, t2, n2) {
  let r2 = sr(e3, t2);
  return r2 ? { kind: `persona`, entryId: r2.id } : n2 ? { kind: `holder` } : { kind: `ask` };
}
async function dr(e3, t2) {
  let { origin: n2, did: r2, rpDid: i2 } = t2;
  try {
    let t3 = (await e3.listDids()).find((e4) => e4.did === r2);
    if (!t3) return { ok: false, error: `${r2} is not an identity this agent hosts` };
    let a2 = await e3.deriveSigningKeyIds(r2);
    if (a2.error) return { ok: false, error: a2.error };
    let o2 = a2.candidates;
    if (o2.length !== 1) return { ok: false, error: o2.length === 0 ? `no signing key could be derived from ${r2}` : `${r2} has ${o2.length} possible signing keys \u2014 bind it from the wallet's vault panel, which lets you choose one` };
    let { entryId: s2 } = await e3.upsert(lr({ origin: n2, did: r2, contextId: t3.contextId, signingKeyId: o2[0], ...i2 ? { rpDid: i2 } : {} }));
    return { ok: true, entryId: s2 };
  } catch (e4) {
    return { ok: false, error: e4 instanceof Error ? e4.message : String(e4) };
  }
}
qe();
function fr(e3, t2) {
  if (t2 && e3.source !== `operator` && !(e3.did && e3.source === `agent`)) return t2;
}
var pr = `pnm/settings/v1`;
function mr(e3) {
  let t2 = {};
  for (let [n2, r2] of Object.entries(e3)) {
    let e4 = r2;
    e4 && typeof e4.did == `string` && e4.did && (e4.source === `agent` || e4.source === `operator`) && (t2[n2] = { did: e4.did, source: e4.source });
  }
  return t2;
}
async function hr() {
  return await new C().get(pr) ?? {};
}
async function j() {
  let e3 = await hr(), t2 = typeof e3?.encryptHolderSecret == `boolean` && e3.encryptHolderSecret;
  return { ...e3?.inboxes ? { inboxes: mr(e3.inboxes) } : {}, ...e3?.mediatorDid ? { mediatorDid: e3.mediatorDid } : {}, ...e3?.mediatorDidSource === `agent` || e3?.mediatorDidSource === `operator` ? { mediatorDidSource: e3.mediatorDidSource } : {}, ...e3?.defaultStepUpVtaDid ? { defaultStepUpVtaDid: e3.defaultStepUpVtaDid } : {}, ...e3?.defaultStepUpVtaMediatorDid ? { defaultStepUpVtaMediatorDid: e3.defaultStepUpVtaMediatorDid } : {}, ...Array.isArray(e3?.enrolledExecutorDids) ? { enrolledExecutorDids: e3.enrolledExecutorDids.filter((e4) => typeof e4 == `string` && e4.length > 0) } : {}, encryptHolderSecret: t2, preferTsp: typeof e3?.preferTsp != `boolean` || e3.preferTsp, ...Array.isArray(e3?.myTermsOffers) && e3.myTermsOffers.some((e4) => typeof e4 == `string` && e4 !== ``) ? { myTermsOffers: e3.myTermsOffers.filter((e4) => typeof e4 == `string` && e4 !== ``) } : {}, ...e3?.pushGatewayUrl ? { pushGatewayUrl: e3.pushGatewayUrl } : {}, ...e3?.pushGatewayVapidPublicKey ? { pushGatewayVapidPublicKey: e3.pushGatewayVapidPublicKey } : {} };
}
function gr(e3, t2) {
  return e3.inboxes?.[t2];
}
async function _r(e3, t2) {
  let n2 = await hr();
  await new C().put(pr, { ...n2, inboxes: { ...n2.inboxes ?? {}, [e3]: t2 } });
}
async function vr() {
  let e3 = await hr();
  delete e3.mediatorDid, delete e3.mediatorDidSource, await new C().put(pr, e3);
}
p();
var yr = `BOp_ZH4GUVZ1aPNmBJl9rpQWTJyNQWLGAclN3d2VYJKxhyzYqYoKbOwwU98C9jaa1IiTjz-IasJFV74Yop0qUOQ`;
async function br() {
  try {
    let { pushGatewayVapidPublicKey: e3 } = await j(), t2 = e3 || yr, n2 = self.registration;
    if (!n2.active) return console.info(`[pnm push] service worker not active yet \u2014 deferring subscribe to activate`), null;
    let r2 = await n2.pushManager.getSubscription();
    return r2 && !xr(r2, t2) && (await r2.unsubscribe(), r2 = null), r2 ||= await n2.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: d(t2) }), console.info(`[pnm push] subscription:
` + JSON.stringify(r2.toJSON())), r2;
  } catch (e3) {
    return console.error(`[pnm push] subscribe failed:`, e3), null;
  }
}
function xr(e3, t2) {
  let n2 = e3.options?.applicationServerKey;
  if (!n2) return true;
  let r2 = new Uint8Array(n2), i2 = d(t2);
  if (r2.length !== i2.length) return false;
  for (let e4 = 0; e4 < r2.length; e4++) if (r2[e4] !== i2[e4]) return false;
  return true;
}
y(), qe();
var Sr = `webauthn-prf-aes-gcm`, Cr = `pnm/holder-prf/credentialId`, wr = `pnm/holder-prf/salt`, Tr = class extends Error {
  constructor() {
    super(`wallet is locked: unlock via popup before retrying`), this.name = `WalletLockedError`;
  }
};
function Er(e3) {
  let t2 = e3.getClientExtensionResults().prf, n2 = t2?.results?.first;
  return n2 ? { kind: `output`, prfOutput: new Uint8Array(n2) } : t2?.enabled === true ? { kind: `needs-assertion` } : { kind: `unsupported` };
}
var Dr = class extends Error {
  constructor(e3) {
    super(e3), this.name = `PrfUnavailableError`;
  }
}, Or = `This passkey can't protect the wallet: it doesn't support the PRF (hmac-secret) extension. Use a security key such as a YubiKey 5 or Nitrokey 3 with a PIN set, or choose your phone in the browser's passkey dialog.`, kr = `This browser doesn't offer the passkey PRF extension the wallet needs. Update Chrome or Chromium (116 or later), or use another browser.`;
async function Ar() {
  let e3 = globalThis.PublicKeyCredential;
  if (typeof e3?.getClientCapabilities == `function`) try {
    let t2 = (await e3.getClientCapabilities())[`extension:prf`];
    return typeof t2 == `boolean` ? t2 : void 0;
  } catch {
    return;
  }
}
var jr = `The passkey answered without the wallet's key. Use the same security key or phone the wallet was set up with, with its PIN or biometric; a key that was reset no longer holds the passkey.`;
function Mr() {
  return new C();
}
var M = null, N = null, Nr = class e2 {
  rpId;
  algorithm = Sr;
  constructor(e3) {
    this.rpId = e3;
  }
  async wrap(e3) {
    let t2 = await this.enrollOrLoadCredential();
    if (!t2) return null;
    let n2 = await this.deriveAesKey(t2.prfOutput);
    M = n2, N = t2.prfOutput;
    let r2 = crypto.getRandomValues(new Uint8Array(12)), i2 = new Uint8Array(await crypto.subtle.encrypt({ name: `AES-GCM`, iv: r2 }, n2, e3));
    return { algorithm: this.algorithm, ciphertextB64u: m(i2), ivB64u: m(r2), params: { credentialId: t2.credentialId, prfSalt: m(t2.prfSalt) } };
  }
  async unwrap(e3) {
    let t2 = e3.params;
    if (!t2.credentialId || !t2.prfSalt) throw Error(`webauthn-prf-wrap: missing credentialId or prfSalt in record`);
    if (!M) throw new Tr();
    let n2 = h(e3.ivB64u), r2 = h(e3.ciphertextB64u), i2 = await crypto.subtle.decrypt({ name: `AES-GCM`, iv: n2 }, M, r2);
    return new Uint8Array(i2);
  }
  static lock() {
    M = null, N = null;
  }
  static consumeLastEnrolledPrfOutput() {
    let e3 = N;
    return N = null, e3;
  }
  static isUnlocked() {
    return M !== null;
  }
  static async seedCachedKeyFromPrfOutput(t2) {
    M = await new e2(``).deriveAesKey(t2);
  }
  static async unenroll() {
    M = null, N = null;
    let e3 = Mr();
    await e3.delete(Cr), await e3.delete(wr);
  }
  async enrollOrLoadCredential() {
    let e3 = Mr(), t2 = await e3.get(Cr), n2 = await e3.get(wr);
    if (t2 && n2) {
      let e4 = h(n2), r3 = await this.assertPrfOutput(t2, e4);
      return r3 ? { credentialId: t2, prfSalt: e4, prfOutput: r3 } : null;
    }
    if (await Ar() === false) throw new Dr(kr);
    let r2 = crypto.getRandomValues(new Uint8Array(32)), i2 = crypto.getRandomValues(new Uint8Array(32)), a2 = crypto.getRandomValues(new Uint8Array(16)), o2 = await navigator.credentials.create({ publicKey: { rp: { id: this.rpId, name: `OpenVTC Wallet` }, user: { id: a2, name: `wallet@openvtc`, displayName: `OpenVTC Wallet` }, challenge: i2, pubKeyCredParams: [{ type: `public-key`, alg: -8 }, { type: `public-key`, alg: -7 }, { type: `public-key`, alg: -257 }], authenticatorSelection: { residentKey: `required`, userVerification: `required` }, extensions: { prf: { eval: { first: r2 } } } } });
    if (!o2) return null;
    let s2 = m(new Uint8Array(o2.rawId)), c2 = Er(o2);
    if (c2.kind === `unsupported`) throw new Dr(Or);
    let l2 = c2.kind === `output` ? c2.prfOutput : await this.assertPrfOutput(s2, r2);
    return l2 ? (await e3.put(Cr, s2), await e3.put(wr, m(r2)), { credentialId: s2, prfSalt: r2, prfOutput: l2 }) : null;
  }
  async assertPrfOutput(e3, t2) {
    let n2 = crypto.getRandomValues(new Uint8Array(32)), r2 = h(e3), i2 = await navigator.credentials.get({ publicKey: { rpId: this.rpId, challenge: n2, allowCredentials: [{ type: `public-key`, id: r2 }], userVerification: `required`, extensions: { prf: { eval: { first: t2 } } } } });
    if (!i2) return null;
    let a2 = i2.getClientExtensionResults().prf?.results?.first;
    if (!a2) throw Error(jr);
    return new Uint8Array(a2);
  }
  async unlockAesKey(e3, t2) {
    let n2 = crypto.getRandomValues(new Uint8Array(32)), r2 = h(e3), i2 = await navigator.credentials.get({ publicKey: { rpId: this.rpId, challenge: n2, allowCredentials: [{ type: `public-key`, id: r2 }], userVerification: `required`, extensions: { prf: { eval: { first: t2 } } } } });
    if (!i2) return null;
    let a2 = i2.getClientExtensionResults().prf?.results?.first;
    if (!a2) throw Error(jr);
    return this.deriveAesKey(new Uint8Array(a2));
  }
  async deriveAesKey(e3) {
    let t2 = await crypto.subtle.importKey(`raw`, e3, { name: `HKDF` }, false, [`deriveKey`]);
    return crypto.subtle.deriveKey({ name: `HKDF`, hash: `SHA-256`, salt: new Uint8Array(), info: new TextEncoder().encode(`pnm/holder-secret/aes-gcm/v1`) }, t2, { name: `AES-GCM`, length: 256 }, false, [`encrypt`, `decrypt`]);
  }
}, Pr = `vta-wallet/broadcast-event`, Fr = `vta-wallet/login`, Ir = `vta-wallet/login-didcomm`, Lr = `vta-wallet/step-up-vta`, Rr = `vta-wallet/api-get`, zr = `vta-wallet/api-post`, Br = `vta-wallet/mediator-status`, Vr = `vta-wallet/wallet-defaults`, Hr = `vta-wallet/sign-trust-task`, Ur = `vta-wallet/approver-identity`, Wr = `vta-wallet/approve-step-up`, Gr = `vta-wallet/attest-approver`, Kr = `vta-wallet/approve-decision`, qr = `vta-wallet/request-task`, Jr = `vta-wallet/disclose`, Yr = `vta-wallet/wallet-profile`, Xr = `vta-wallet/verify-rp-did`, Zr = `vta-wallet/refresh-vta-transports`, Qr = `vta-wallet/list-dids`, $r = `vta-wallet/derive-signing-key-id`, P = `vta-wallet/vault-list`, ei = `vta-wallet/vault-upsert`, ti = `vta-wallet/vault-proxy-login-page`, ni = `vta-wallet/vault-list-page`, F = `offscreen`, ri = `offscreen/didcomm-login`, ii = `offscreen/step-up-vta`, ai = `offscreen/lock-wallet`, oi = `offscreen/start-inbound`, si = `offscreen/get-status`, ci = `offscreen/run-diagnostics`, li = `offscreen/onboard-prepare`, ui = `offscreen/onboard-connect`, di = `offscreen/holder-state`, fi = `offscreen/unlock-prf`, pi = `offscreen/approver-state`, mi = `offscreen/unlock-approver`, hi = `offscreen/forget-holder-record`, gi = `offscreen/lock-state`, _i = `offscreen/refresh-vta-transports`, vi = `offscreen/list-contexts`, yi = `offscreen/list-dids`, bi = `offscreen/create-context`, xi = `offscreen/derive-signing-key-id`, Si = `offscreen/set-wake`, Ci = `offscreen/sign-trust-task`, wi = `offscreen/verify-did`, Ti = `offscreen/vault-list`, Ei = `offscreen/request-task`, Di = `offscreen/vault-upsert`, Oi = `offscreen/vault-delete`, ki = `offscreen/vault-release`, Ai = `offscreen/vault-proxy-login`, ji = `offscreen/onboard-contexts`, Mi = `offscreen/rest-login`, Ni = `pnm/offscreen-disclosure-step-up`, Pi = `vta-wallet/manager-task`, Fi = `vta-wallet/mediator-lens`, Ii = `offscreen/mediator`, Li = [Fr, Ir, Lr, Rr, zr, Br, Vr, Hr, ti, Yr, ni, qr, Jr, Ur, Wr, Gr, Kr, `vta-wallet/rooms-page`, `vta-wallet/directory-page`, `vta-wallet/membership-page`, `vta-wallet/trigger-link`, `vta-wallet/trigger-link-number`], Ri = `offscreen/sign-in-page-number`, zi = `offscreen/sign-in-step`, Bi = `vta-wallet/room-files-prepare`, Vi = `offscreen/room-host-endpoint`, Hi = `vta-wallet/room-files`, Ui = `vta-wallet/room-offers`;
function Wi(e3) {
  if (e3 == null) return;
  let t2;
  try {
    t2 = JSON.parse(JSON.stringify(e3));
  } catch {
    return;
  }
  if (t2 != null && (typeof t2 != `object` || Array.isArray(t2) || Object.keys(t2).length !== 0)) return t2;
}
function Gi(e3) {
  return e3 instanceof Error ? e3.message : String(e3);
}
function Ki(e3) {
  let t2 = Gi(e3);
  if (!(e3 instanceof Re)) return { ok: false, error: t2 };
  let n2 = e3.details, r2 = typeof n2?.code == `string` && n2.code.length > 0 ? n2.code : void 0, i2 = Wi(r2 === void 0 ? e3.details : n2?.details);
  return { ok: false, error: t2, code: r2 ?? e3.code, ...i2 === void 0 ? {} : { details: i2 } };
}
var qi = `vta-wallet-provider`;
function Ji(e3) {
  return e3.some((e4) => e4 === `<all_urls>` || e4 === `*://*/*`) ? [`<all_urls>`] : e3.filter((e4) => /^https?:\/\//.test(e4)).sort();
}
async function Yi() {
  try {
    return (await chrome.scripting.getRegisteredContentScripts({ ids: [`vta-wallet-provider`] }))[0]?.matches ?? [];
  } catch {
    return [];
  }
}
var Xi = Promise.resolve();
function I() {
  let e3 = Xi.then(Zi, Zi);
  return Xi = e3.catch(() => void 0), e3;
}
async function Zi() {
  let e3 = Ji((await chrome.permissions.getAll()).origins ?? []), t2 = await Yi();
  if (e3.length === t2.length && e3.every((e4, n3) => e4 === t2[n3])) return e3;
  if (e3.length === 0) return t2.length > 0 && await chrome.scripting.unregisterContentScripts({ ids: [qi] }), [];
  let n2 = { id: qi, js: [`content.js`], matches: e3, runAt: `document_start`, persistAcrossSessions: true, allFrames: false };
  return t2.length > 0 ? await chrome.scripting.updateContentScripts([n2]) : await chrome.scripting.registerContentScripts([n2]), e3;
}
function Qi(e3) {
  let t2 = e3.trim();
  if (!t2 || !t2.includes(`/@`)) return null;
  let n2 = t2.includes(`://`) ? t2 : `https://${t2}`, r2;
  try {
    r2 = new URL(n2);
  } catch {
    return null;
  }
  if (r2.protocol !== `https:` && r2.protocol !== `http:` || !r2.hostname) return null;
  let i2 = r2.protocol.replace(`:`, ``), a2 = r2.port ? `${r2.hostname}:${r2.port}` : r2.hostname, o2 = r2.pathname.split(`/`).filter((e4) => e4.length > 0);
  if (o2.length === 0) return null;
  let s2 = o2.shift();
  if (!s2.startsWith(`@`)) return null;
  let c2 = s2.slice(1);
  return c2 === `` && o2.length > 0 || o2.some((e4) => e4.startsWith(`@`)) ? null : { canonical: [`${i2}://${a2}/@${c2}`, ...o2].join(`/`), authority: a2, localName: c2, pathSegments: o2 };
}
function L(e3) {
  return e3.canonical.replace(/^https?:\/\//, ``);
}
function $i(e3, t2) {
  return e3 ? e3.some((e4) => {
    let n2 = Qi(e4);
    return n2 ? n2.canonical === t2.canonical : e4 === t2.canonical || e4 === L(t2);
  }) : false;
}
var ea = `agent-name/invalid`, ta = `agent-name/insecure`, na = `agent-name/no-redirect`, ra = `agent-name/unreadable`, ia = `agent-name/unresolvable-did`, aa = `agent-name/not-authorized`, R = class extends Error {
  code;
  constructor(e3, t2) {
    super(t2), this.code = e3, this.name = `AgentNameError`;
  }
};
function oa(e3) {
  try {
    return decodeURIComponent(e3);
  } catch {
    return null;
  }
}
function sa(e3, t2) {
  let n2;
  try {
    n2 = new URL(e3, t2);
  } catch {
    return null;
  }
  let r2 = n2.searchParams.get(`did`)?.trim();
  if (r2?.startsWith(`did:`)) return r2;
  let i2 = n2.pathname.split(`/`).filter((e4) => e4.length > 0).pop(), a2 = i2 ? oa(i2) : null;
  return a2?.startsWith(`did:`) ? a2 : null;
}
function ca(e3) {
  if (typeof e3 != `object` || !e3) return null;
  let t2 = e3, n2 = (e4) => {
    let n3 = t2[e4];
    return typeof n3 == `object` && n3 ? n3.id : void 0;
  };
  for (let e4 of [t2.did, t2.id, n2(`didDocument`), n2(`state`)]) if (typeof e4 == `string` && e4.trim().startsWith(`did:`)) return e4.trim();
  return null;
}
function la(e3) {
  let t2 = e3.trim();
  if (!t2) return null;
  if (t2.startsWith(`did:`) && !/\s/.test(t2)) return t2;
  for (let e4 of [t2, t2.split(`
`, 1)[0] ?? ``]) try {
    let t3 = ca(JSON.parse(e4));
    if (t3) return t3;
  } catch {
  }
  return null;
}
function ua(e3, t2) {
  let n2 = e3.location?.trim();
  if (n2) {
    if (n2.startsWith(`did:`)) return n2;
    let e4 = sa(n2, t2);
    if (e4) return e4;
  }
  if (e3.url && e3.url !== t2) {
    let n3 = sa(e3.url, t2);
    if (n3) return n3;
  }
  return e3.body ? la(e3.body) : null;
}
async function da(e3, t2) {
  let n2 = Qi(e3);
  if (!n2) throw new R(ea, `'${e3}' is not an agent name. Expected something like example.com/@alice.`);
  if (n2.canonical.startsWith(`http://`)) throw new R(ta, `Refusing to resolve ${L(n2)} over plain HTTP; agent names must use HTTPS.`);
  let r2 = await t2.fetchName(n2.canonical), i2 = ua(r2, n2.canonical);
  if (!i2) {
    let e4 = r2.location?.trim();
    throw new R(na, e4 ? `${L(n2)} redirected to '${e4}', which is not a DID.` : `${L(n2)} did not answer with a DID (HTTP ${r2.status}); expected a redirect to a did: URI, or a response naming one.`);
  }
  let a2 = await t2.resolveDid(i2);
  if (!a2.resolved) throw new R(ia, `${L(n2)} points at ${i2}, which does not resolve${a2.error ? `: ${a2.error}` : ``}.`);
  if (!$i(a2.alsoKnownAs, n2)) throw new R(aa, `Agent name ${L(n2)} is not authorized by DID ${i2}: its DID Document's alsoKnownAs does not contain the name.`);
  return { did: i2, name: n2 };
}
var fa = `wallet/host-permission-required`;
function pa(e3) {
  if (!e3) return null;
  let t2 = (() => {
    try {
      return decodeURIComponent(e3);
    } catch {
      return e3;
    }
  })(), n2 = /^[a-z][a-z0-9+.-]*:\/\//i.test(t2) ? t2 : `https://${t2}`, r2;
  try {
    r2 = new URL(n2);
  } catch {
    return null;
  }
  return !r2.hostname || r2.protocol !== `https:` && r2.protocol !== `http:` ? null : `${r2.protocol}//${r2.hostname}/*`;
}
async function z(e3) {
  let t2 = pa(e3);
  if (!t2) return false;
  try {
    return await chrome.permissions.contains({ origins: [t2] });
  } catch {
    return false;
  }
}
function ma(e3) {
  let t2 = pa(e3);
  return t2 ? t2.replace(/^https?:\/\//, ``).replace(/\/\*$/, ``) : e3;
}
function ha(e3) {
  return $e(e3, { allowLoopback: true, what: `request URL` });
}
function ga(e3, t2) {
  return `${e3}\0${JSON.stringify(t2)}`;
}
var _a = class {
  #e = /* @__PURE__ */ new Map();
  #t;
  #n;
  #r;
  constructor(e3 = {}) {
    this.#t = e3.ttlMs ?? 6e5, this.#n = e3.maxEntries ?? 32, this.#r = e3.now ?? (() => Date.now());
  }
  recordConsentRequired(e3, t2) {
    if (this.#i(), this.#e.size >= this.#n && !this.#e.has(e3)) {
      let e4 = this.#e.keys().next();
      e4.done || this.#e.delete(e4.value);
    }
    this.#e.set(e3, { digest: t2, granted: false, at: this.#r() });
  }
  recordGranted(e3) {
    this.#i();
    for (let t2 of this.#e.values()) t2.digest === e3 && (t2.granted = true);
  }
  consumeIfArmed(e3) {
    return this.#i(), this.#e.get(e3)?.granted ? (this.#e.delete(e3), true) : false;
  }
  get size() {
    return this.#i(), this.#e.size;
  }
  #i() {
    let e3 = this.#r() - this.#t;
    for (let [t2, n2] of this.#e) n2.at <= e3 && this.#e.delete(t2);
  }
}, va = 1e3;
function ya() {
  return { windows: chrome.windows, lastError: () => chrome.runtime.lastError?.message, setTimer: (e3, t2) => setTimeout(e3, t2), graceMs: va };
}
function B(e3, t2 = ya()) {
  let { url: n2, bounds: r2, deny: i2, tag: a2, what: o2 } = e3;
  t2.windows.create({ url: n2, type: `popup`, ...r2 }, (e4) => {
    let n3 = e4?.id;
    if (n3 === void 0) {
      let e5 = t2.lastError() ?? `no window was created`;
      console.error(`${a2} could not open the ${o2} \u2014 treating as a denial:`, e5), i2();
      return;
    }
    console.info(`${a2} ${o2} opened`, `id=`, n3, `bounds=`, JSON.stringify(r2));
    let s2 = (e5) => {
      e5 === n3 && (t2.windows.onRemoved.removeListener(s2), t2.setTimer(i2, t2.graceMs));
    };
    t2.windows.onRemoved.addListener(s2);
  });
}
function ba(e3, t2) {
  let n2 = e3.get(t2.consentId);
  if (!n2) return false;
  let r2 = Array.isArray(t2.selectedRooms) ? t2.selectedRooms.filter((e4) => typeof e4 == `string`) : void 0;
  return n2(t2.approved, !!t2.remember, t2.prfOutputB64u, t2.selectedDid, r2), true;
}
var xa = [`link.trustoverip.org`], Sa = /(?:^|&)_(?:from|id|exp|type)=/;
function Ca(e3, t2 = xa) {
  let n2;
  try {
    n2 = new URL(e3);
  } catch {
    return false;
  }
  return n2.protocol !== `https:` || n2.username || n2.password || n2.port || !t2.some((e4) => e4.toLowerCase() === n2.hostname) || n2.pathname !== `/t` || n2.search !== `` ? false : Sa.test(n2.hash.slice(1));
}
function wa(e3, t2) {
  return { step: e3, code: t2.code, ...t2.cause && t2.cause !== t2.code ? { cause: t2.cause } : {}, ...t2.stage ? { stage: t2.stage } : {}, ...t2.party ? { party: t2.party } : {} };
}
var Ta = /did:[a-z0-9]+:[A-Za-z0-9._%:-]+/;
function Ea(e3) {
  let t2 = Ta.exec(e3);
  if (!t2) return;
  let n2 = t2[0].replace(/[.:]+$/, ``);
  return /^did:[a-z0-9]+:[^:]/.test(n2) ? n2 : void 0;
}
qe(), Ye(), Le();
var Da = new _a();
chrome.permissions.onAdded.addListener(() => void I()), chrome.permissions.onRemoved.addListener(() => void I()), chrome.runtime.onStartup.addListener(() => {
  I(), Co();
}), I().then((e3) => {
  console.info(e3.length > 0 ? `[pnm] page provider registered for: ${e3.join(`, `)}` : `[pnm] page provider registered for no sites \u2014 grant one to enable sign-in`);
}), chrome.runtime.onInstalled.addListener((e3) => {
  console.info(`[pnm] extension installed:`, e3.reason), ja(), Co(), e3.reason === `install` && chrome.tabs.create({ url: chrome.runtime.getURL(`options.html#setup`) }), I(), e3.reason === `update` && ka();
});
async function Oa() {
  return Ji((await chrome.permissions.getAll()).origins ?? []);
}
async function ka() {
  let e3 = await Oa();
  if (e3.length === 0) return;
  let t2 = await chrome.tabs.query({ url: e3 });
  for (let e4 of t2) if (e4.id !== void 0) try {
    await chrome.tabs.reload(e4.id);
  } catch (t3) {
    console.warn(`[pnm] tab reload failed:`, e4.id, t3);
  }
}
async function V(e3, t2) {
  let n2 = await Oa();
  if (n2.length === 0) return;
  let r2 = await chrome.tabs.query({ url: n2 }), i2 = { type: Pr, event: e3, ...t2 ? { detail: t2 } : {} };
  for (let e4 of r2) if (e4.id !== void 0) try {
    await chrome.tabs.sendMessage(e4.id, i2);
  } catch {
  }
}
self.addEventListener(`push`, (e3) => {
  let t2 = e3, n2 = ``;
  try {
    n2 = t2.data ? t2.data.text() : ``;
  } catch {
    n2 = `(unreadable payload)`;
  }
  console.info(`[pnm push] push received:`, n2), t2.waitUntil(Aa(n2));
});
async function Aa(e3) {
  let t2 = self.registration.showNotification(`VTA Wallet`, { body: e3 || `Checking for pending requests\u2026` });
  try {
    await H();
  } catch (e4) {
    console.warn(`[pnm push] wake-drain failed:`, e4);
  }
  await t2;
}
self.addEventListener(`activate`, (e3) => {
  e3.waitUntil((async () => {
    try {
      await self.clients.claim();
    } catch {
    }
    await ja();
  })());
}), ja();
async function ja() {
  let e3 = await br();
  if (!e3) return;
  let { pushGatewayUrl: t2 } = await j();
  if (!t2) return;
  let n2 = await Q();
  if (!n2.ok) {
    console.info(`[pnm push] subscribed; skipping gateway register \u2014 ${n2.error}`);
    return;
  }
  let r2 = e3.toJSON(), i2 = r2.keys?.p256dh, a2 = r2.keys?.auth;
  if (!r2.endpoint || !i2 || !a2) {
    console.warn(`[pnm push] subscription is missing Web Push keys; cannot register`);
    return;
  }
  try {
    let e4 = await dt({ gatewayUrl: t2, registration: { platform: `webpush`, endpoint: r2.endpoint, keys: { p256dh: i2, auth: a2 } }, controllerVtaDid: n2.conn.vtaDid });
    console.info(`[pnm push] registered with gateway; handle:`, JSON.stringify(e4));
    let o2 = await Zo();
    await W();
    let s2 = await chrome.runtime.sendMessage({ target: F, type: Si, vtaDid: n2.conn.vtaDid, restBaseUrl: n2.conn.restBaseUrl, wakeHandle: e4, pushPlatform: `webpush`, ...o2?.mediatorDid ? { suggestedTriggers: [o2.mediatorDid] } : {} });
    s2?.ok ? console.info(`[pnm push] device/set-wake ok \u2014 pushCapable:`, s2.result?.pushCapable, `triggers:`, s2.result?.triggerPolicy?.allowedTriggers ?? []) : console.warn(`[pnm push] device/set-wake failed:`, s2?.error);
  } catch (e4) {
    console.warn(`[pnm push] gateway register / set-wake failed:`, e4);
  }
}
var Ma = [], Na = null;
async function Pa(e3) {
  let t2 = await j(), n2 = await jt();
  if (t2.mediatorDid || t2.mediatorDidSource) {
    let e4 = await Dt();
    t2.mediatorDidSource === `operator` && t2.mediatorDid && e4 && (await _r(e4, { did: t2.mediatorDid, source: `operator` }), console.info(`[pnm inbound] carried the pinned relay over to`, e4)), await vr();
  }
  let r2 = await j();
  for (let t3 of e3) {
    let e4 = fr(gr(r2, t3) ?? {}, n2[t3]);
    e4 ? (await _r(t3, { did: e4, source: `agent` }), console.info(`[pnm inbound] inbox adopted from agent:`, t3, `\u2192`, e4)) : !gr(r2, t3) && !n2[t3] && console.warn(`[pnm inbound]`, t3, `has no inbox relay and advertises none to adopt \u2014 it cannot reach this wallet.`);
  }
}
async function H() {
  let e3 = (await kt()).sort();
  Ma = e3, await Pa(e3), Na = await Dt(), await W(), await chrome.runtime.sendMessage({ target: F, type: oi, vtaDids: e3 });
}
H(), chrome.storage.onChanged.addListener((e3, t2) => {
  if (t2 !== `local`) return;
  let n2 = e3[`pnm-connection/v3`];
  if (!n2) return;
  let r2 = At(n2.newValue).sort(), i2 = Ot(n2.newValue), a2 = r2.length === Ma.length && r2.every((e4, t3) => e4 === Ma[t3]), o2 = i2 === Na;
  o2 || (Na = i2, V(`connectionchanged`)), !a2 && (Ma = r2, o2 && V(`connectionchanged`), (async () => {
    await W(), await chrome.runtime.sendMessage({ target: F, type: oi, vtaDids: r2 });
  })());
});
var U = null;
async function W() {
  if (U) return U;
  let e3 = await chrome.offscreen.hasDocument();
  if (U) return U;
  e3 || (U = chrome.offscreen.createDocument({ url: `offscreen.html`, reasons: [chrome.offscreen.Reason.WORKERS], justification: `Run the DIDComm mediator session (WebSocket + did:webvh resolution) for wallet login.` }).finally(() => {
    U = null;
  }), await U);
}
async function Fa() {
  try {
    let e3 = (await Ze(new C())).filter((e4) => e4.isApprover).length;
    if (e3 > 0) {
      await chrome.action.setBadgeText({ text: String(e3) }), await chrome.action.setBadgeBackgroundColor({ color: `#8B1A1A` });
      return;
    }
    let t2 = await Ra();
    await chrome.action.setBadgeText({ text: t2 > 0 ? String(t2) : `` }), t2 > 0 && await chrome.action.setBadgeBackgroundColor({ color: `#1F5FAD` });
  } catch (e3) {
    console.warn(`[pnm consent] could not refresh the pending badge:`, e3);
  }
}
Fa();
async function Ia(e3) {
  let t2 = crypto.randomUUID();
  await chrome.storage.session.set({ [`${Vt}${t2}`]: e3 });
  let n2 = `${chrome.runtime.getURL(`confirm.html`)}?cid=${t2}&kind=room`, r2 = await K(e3.kind === `share` ? 640 : 560);
  return new Promise((e4) => {
    let i2 = false, a2 = (n3, r3) => {
      i2 || (i2 = true, G.delete(t2), chrome.storage.session.remove(`${Vt}${t2}`), e4(n3 ? { approved: true, ...r3 ? { selectedRooms: r3 } : {} } : { approved: false }));
    };
    G.set(t2, (e5, t3, n3, r3, i3) => a2(e5, i3)), B({ url: n2, bounds: r2, deny: () => a2(false), tag: `[pnm rooms]`, what: `room window` });
  });
}
var La = `room-offers-open`;
async function Ra() {
  let e3 = (await chrome.storage.local.get(La))[La];
  if (!e3 || typeof e3.count != `number` || e3.count <= 0) return 0;
  let t2 = await Q();
  return t2.ok && t2.conn.vtaDid === e3.vtaDid ? e3.count : 0;
}
async function za() {
  let e3 = await Q();
  return e3.ok ? { ok: true, vta: { vtaDid: e3.conn.vtaDid, ...e3.conn.restBaseUrl ? { restBaseUrl: e3.conn.restBaseUrl } : {} } } : { ok: false, error: e3.error };
}
var Ba = new Jn({ active: za, async offscreen(e3, t2) {
  return await W(), await chrome.runtime.sendMessage({ target: `offscreen`, type: `offscreen/room-offers`, vtaDid: e3.vtaDid, ...e3.restBaseUrl ? { restBaseUrl: e3.restBaseUrl } : {}, params: t2 }) ?? { ok: false, error: `the offscreen document did not answer` };
}, canReach: (e3) => z(e3), prompt: Ia, async rememberNames(e3, t2, n2) {
  let r2 = Wt(e3, t2), i2 = (await chrome.storage.local.get(r2))[r2];
  await chrome.storage.local.set({ [r2]: Gt(i2, n2, Date.now()) });
}, async setOpenCount(e3, t2) {
  await chrome.storage.local.set({ [La]: { vtaDid: e3, count: t2 } }), await Fa();
}, now: () => Date.now() }), Va = new bn({ offers: Ba, async active() {
  let e3 = await Q();
  return e3.ok ? { ok: true, vta: { vtaDid: e3.conn.vtaDid, ...e3.conn.restBaseUrl ? { restBaseUrl: e3.conn.restBaseUrl } : {} } } : { ok: false, error: e3.error };
}, async offscreen(e3, t2) {
  return await W(), await chrome.runtime.sendMessage({ target: `offscreen`, type: `offscreen/rooms-page`, vtaDid: e3.vtaDid, ...e3.restBaseUrl ? { restBaseUrl: e3.restBaseUrl } : {}, params: t2 }) ?? { ok: false, error: `the offscreen document did not answer` };
}, canReach: (e3) => z(e3), async loadGrants(e3, t2) {
  let n2 = Kt(e3, t2), r2 = (await chrome.storage.local.get(n2))[n2];
  return Array.isArray(r2) ? r2 : [];
}, async saveGrants(e3, t2, n2) {
  let r2 = Kt(e3, t2);
  n2.length === 0 ? await chrome.storage.local.remove(r2) : await chrome.storage.local.set({ [r2]: n2 });
}, async loadRoomNames(e3, t2) {
  let n2 = Wt(e3, t2);
  return (await chrome.storage.local.get(n2))[n2];
}, async saveRoomNames(e3, t2, n2) {
  await chrome.storage.local.set({ [Wt(e3, t2)]: n2 });
}, prompt: Ia, async openTransfer() {
  return await W(), chrome.runtime.connect({ name: Hi });
}, now: () => Date.now() });
async function Ha(e3) {
  let t2 = crypto.randomUUID();
  await chrome.storage.session.set({ [`${Sn}${t2}`]: e3 });
  let n2 = `${chrome.runtime.getURL(`confirm.html`)}?cid=${t2}&kind=directory`, r2 = await K(620);
  return new Promise((e4) => {
    let i2 = false, a2 = (n3) => {
      i2 || (i2 = true, G.delete(t2), chrome.storage.session.remove(`${Sn}${t2}`), e4({ approved: n3 }));
    };
    G.set(t2, (e5) => a2(e5)), B({ url: n2, bounds: r2, deny: () => a2(false), tag: `[pnm directory]`, what: `directory window` });
  });
}
var Ua = new On({ async active() {
  let e3 = await Q();
  return e3.ok ? { ok: true, vta: { vtaDid: e3.conn.vtaDid, ...e3.conn.restBaseUrl ? { restBaseUrl: e3.conn.restBaseUrl } : {} } } : { ok: false, error: e3.error };
}, async offscreen(e3, t2) {
  return await W(), await chrome.runtime.sendMessage({ target: `offscreen`, type: `offscreen/directory-page`, vtaDid: e3.vtaDid, ...e3.restBaseUrl ? { restBaseUrl: e3.restBaseUrl } : {}, params: t2 }) ?? { ok: false, error: `the offscreen document did not answer` };
}, canReach: (e3) => z(e3), prompt: Ha, now: () => Date.now() }), Wa = new Ln({ async active() {
  let e3 = await Q();
  return e3.ok ? { ok: true, vta: { vtaDid: e3.conn.vtaDid, ...e3.conn.restBaseUrl ? { restBaseUrl: e3.conn.restBaseUrl } : {} } } : { ok: false, error: e3.error };
}, async offscreen(e3, t2) {
  return await W(), await chrome.runtime.sendMessage({ target: `offscreen`, type: `offscreen/directory-page`, vtaDid: e3.vtaDid, ...e3.restBaseUrl ? { restBaseUrl: e3.restBaseUrl } : {}, params: t2 }) ?? { ok: false, error: `the offscreen document did not answer` };
}, agreements: (e3) => zn(e3), now: () => Date.now() });
chrome.runtime.onConnect.addListener((e3) => {
  if (e3.name !== `vta-wallet/room-files-page`) return;
  let t2 = e3.sender ? ft(e3.sender) : void 0;
  if (!t2 || !e3.sender?.tab || Y(e3.sender)) {
    e3.disconnect();
    return;
  }
  Va.servePort(e3, t2);
}), chrome.runtime.onConnect.addListener((e3) => {
  e3.name === `pnm/consent-keepalive` && (Fa(), e3.onDisconnect.addListener(() => {
    Fa();
  }));
});
var G = /* @__PURE__ */ new Map();
async function K(e3, t2 = 1100) {
  let n2 = Math.max(480, t2);
  try {
    let t3 = await chrome.windows.getLastFocused(), r2 = t3?.width, i2 = t3?.height;
    if (!r2 || !i2) return { width: 480, height: e3 };
    let a2 = Math.max(480, Math.min(n2, r2 - 96)), o2 = Math.max(360, Math.min(e3, i2 - 48));
    return { width: a2, height: o2, left: Math.round((t3.left ?? 0) + (r2 - a2) / 2), top: Math.round((t3.top ?? 0) + Math.max(0, (i2 - o2) / 2)) };
  } catch {
    return { width: 480, height: e3 };
  }
}
async function q(e3) {
  let t2 = crypto.randomUUID(), n2 = chrome.runtime.getURL(`confirm.html`) + `?cid=${t2}` + (e3.rpDid ? `&rpDid=${encodeURIComponent(e3.rpDid)}` : ``) + (e3.origin ? `&origin=${encodeURIComponent(e3.origin)}` : ``) + (e3.holderDid ? `&holder=${encodeURIComponent(e3.holderDid)}` : ``) + (e3.action ? `&action=${encodeURIComponent(e3.action)}` : ``) + (e3.noRemember ? `&noRemember=1` : ``) + (e3.stepUp ? `&stepUp=1` : ``) + (e3.sessionKey ? `&sessionKey=${encodeURIComponent(e3.sessionKey)}` : ``) + (e3.chooseProfile ? `&chooseProfile=1` : ``) + (e3.allowHolder ? `&allowHolder=1` : ``) + (e3.reason ? `&reason=${encodeURIComponent(e3.reason)}` : ``) + (e3.changedFromRpDid ? `&changedFrom=${encodeURIComponent(e3.changedFromRpDid)}` : ``) + (e3.changedFromBaseUrl ? `&changedFromBase=${encodeURIComponent(e3.changedFromBaseUrl)}` : ``) + (e3.pinned ? `&pinned=1` : ``) + (e3.pinned?.baseUrl ? `&pinnedBase=${encodeURIComponent(e3.pinned.baseUrl)}` : ``), r2 = await K(e3.reason ? 660 : e3.chooseProfile ? 680 : 560);
  return new Promise((e4) => {
    let i2 = false, a2 = (n3, r3, a3) => {
      i2 || (i2 = true, G.delete(t2), e4({ approved: n3, remember: r3, ...a3 ? { selectedDid: a3 } : {} }));
    };
    G.set(t2, (e5, t3, n3, r3) => a2(e5, t3, r3)), B({ url: n2, bounds: r2, deny: () => a2(false, false), tag: `[pnm consent]`, what: `consent window` });
  });
}
var Ga = `disclosure-consent:`, Ka = `https://trusttasks.org/spec/persona/disclosure/preview/1.0`, qa = `https://trusttasks.org/spec/persona/disclosure/present/1.0`;
async function Ja(e3, t2, n2, r2) {
  return await W(), await chrome.runtime.sendMessage({ target: F, type: Ei, vtaDid: e3.vtaDid, restBaseUrl: e3.restBaseUrl, origin: t2, params: { type: n2, payload: r2 } });
}
async function Ya(e3) {
  let t2 = await Q();
  if (!t2.ok) return { ok: false, error: t2.error };
  let n2 = await cs(e3.origin);
  if (!n2.ok) return { ok: false, error: n2.error };
  if (!n2.entryId) return { ok: false, error: `this site has no identity for you yet \u2014 call walletProfile() first so the holder can choose which persona it knows them as` };
  let r2 = await Qa(e3.origin, n2.entryId);
  if (!r2.ok) return { ok: false, error: r2.error };
  let i2 = await Ja(t2.conn, e3.origin, Ka, { contextId: r2.contextId, personaDid: r2.did, verifierDid: e3.params.verifierDid, ...e3.params.purpose === void 0 ? {} : { purpose: e3.params.purpose }, ...e3.params.requestedClaims?.length ? { requestedClaims: e3.params.requestedClaims } : {}, ...e3.params.renderer === void 0 ? {} : { renderer: e3.params.renderer } });
  if (!i2.ok) return { ok: false, error: i2.error };
  let a2 = i2.result;
  if (typeof a2?.previewId != `string`) return { ok: false, error: `the agent returned no preview; refusing to disclose` };
  let o2 = crypto.randomUUID();
  if (await chrome.storage.session.set({ [`${Ga}${o2}`]: { preview: a2, verifierDid: e3.params.verifierDid, ...e3.params.purpose === void 0 ? {} : { purpose: e3.params.purpose }, contextId: r2.contextId, personaDid: r2.did } }), !await $a(o2)) return { ok: false, error: `user declined the disclosure` };
  let s2 = async () => Ja(t2.conn, e3.origin, qa, { contextId: r2.contextId, previewId: a2.previewId }), c2 = await s2(), l2 = Qe(c2.ok ? void 0 : c2.code, c2.ok ? void 0 : c2.details);
  if (l2) {
    let n3 = await Xa(t2.conn, e3.origin, l2);
    if (!n3.ok) return { ok: false, error: n3.error };
    c2 = await s2();
  }
  return c2.ok ? { ok: true, result: c2.result ?? {} } : { ok: false, error: c2.error };
}
async function Xa(e3, t2, n2) {
  await W();
  let r2 = { target: F, type: Ni, vtaDid: e3.vtaDid, ...e3.restBaseUrl === void 0 ? {} : { restBaseUrl: e3.restBaseUrl }, origin: t2, refusal: { previewId: n2.previewId, previewRetained: n2.previewRetained, unverifiedApproveRequest: n2.unverifiedApproveRequest } };
  return await chrome.runtime.sendMessage(r2) ?? { ok: false, error: `the step-up ceremony returned nothing` };
}
async function Za(e3) {
  let { origin: t2, agentDid: n2 } = e3, r2 = { verifierDid: e3.verifierDid, claimTypes: e3.claimTypes, purpose: e3.purpose }, { approved: i2 } = await q({ origin: t2, rpDid: n2, noRemember: true, stepUp: true, action: `let this leave`, reason: `Release ${r2.claimTypes.length === 1 ? r2.claimTypes[0] : `${r2.claimTypes.length} attributes (${r2.claimTypes.join(`, `)})`}${r2.verifierDid ? ` to ${r2.verifierDid}` : ``}${r2.purpose ? ` \u2014 they say it is for: ${r2.purpose}` : ``}. This approval covers this one departure, and nothing else.` });
  return { approved: i2 };
}
async function Qa(e3, t2) {
  let n2 = await Z({ type: P, filter: { secretKind: A, targetOriginPrefix: e3 } });
  if (!n2.ok) return { ok: false, error: n2.error };
  let r2 = n2.result.entries.find((e4) => e4.id === t2);
  return r2?.principalDid ? r2.contextId ? { ok: true, did: r2.principalDid, contextId: r2.contextId } : { ok: false, error: `vault entry ${t2} names no context` } : { ok: false, error: `vault entry ${t2} names no persona DID` };
}
async function $a(e3) {
  let t2 = `${chrome.runtime.getURL(`confirm.html`)}?cid=${e3}&kind=disclosure`, n2 = await K(680);
  return new Promise((r2) => {
    let i2 = false, a2 = (t3) => {
      i2 || (i2 = true, G.delete(e3), chrome.storage.session.remove(`${Ga}${e3}`), r2(t3));
    };
    G.set(e3, (e4) => a2(e4)), B({ url: t2, bounds: n2, deny: () => a2(false), tag: `[pnm disclose]`, what: `disclosure window` });
  });
}
var eo = `task-consent:`;
async function to(e3, t2 = false) {
  let n2 = crypto.randomUUID();
  await chrome.storage.session.set({ [`${eo}${n2}`]: e3 });
  let r2 = `${chrome.runtime.getURL(`confirm.html`)}?cid=${n2}&kind=task` + (t2 ? `&approver=1` : ``), i2 = await K(e3.sideEffects === `destructive` ? 680 : 620);
  return new Promise((e4) => {
    let t3 = false, a2 = (r3, i3) => {
      t3 || (t3 = true, G.delete(n2), chrome.storage.session.remove(`${eo}${n2}`), e4({ approved: r3, ...i3 ? { prfOutputB64u: i3 } : {} }));
    };
    G.set(n2, (e5, t4, n3) => a2(e5, n3)), B({ url: r2, bounds: i2, deny: () => a2(false), tag: `[pnm consent]`, what: `consent window` });
  });
}
async function J(e3) {
  if (e3.origin && $n(e3) && await Zn(e3.origin)) return true;
  let { approved: t2, remember: n2 } = await q({ ...e3, ...er(e3) ? {} : { noRemember: true } });
  return t2 && n2 && e3.origin && await Qn(e3.origin, e3.rpDid), t2;
}
async function no(e3) {
  let t2 = await Nt();
  if (!t2) return { ok: false, error: `no active VTA connection \u2014 connect first` };
  let n2 = e3.params.sessionKey;
  if (n2 !== void 0 && !Ke(n2)) return { ok: false, error: `sessionKey must be a did:key (did:key:z\u2026), with no fragment` };
  let r2 = e3.origin ? await It(e3.origin, e3.params.rpDid, e3.params.baseUrl) : { firstSeen: true, rpDidChanged: false, baseUrlChanged: false }, i2 = { origin: e3.origin, rpDid: e3.params.rpDid, holderDid: t2, ...n2 === void 0 ? {} : { sessionKey: n2 } };
  if (r2.rpDidChanged && r2.pinnedRpDid && (i2.changedFromRpDid = r2.pinnedRpDid), r2.baseUrlChanged && r2.pinnedBaseUrl && (i2.changedFromBaseUrl = r2.pinnedBaseUrl), !await J(i2)) return { ok: false, error: `login denied by user` };
  e3.origin && await Rt(e3.origin, e3.params.rpDid, e3.params.baseUrl);
  let a2 = await ro(e3.origin, e3.params.rpDid, t2);
  if (!a2.ok) return { ok: false, error: a2.error };
  await W();
  let o2 = await Q();
  if (!o2.ok) return { ok: false, error: o2.error };
  let s2 = o2.conn.vtaDid, c2 = o2.conn, l2 = await chrome.runtime.sendMessage({ target: F, type: Mi, vtaDid: s2, params: e3.params, ...a2.entryId ? { entryId: a2.entryId } : {}, ...c2?.restBaseUrl ? { restBaseUrl: c2.restBaseUrl } : {} });
  return !l2.ok && a2.bound ? { ok: false, error: `${l2.error} \u2014 this was the first sign-in as ${a2.did}. If ${e3.origin ?? `the site`} refused it, that identity needs to be on its access list.` } : l2;
}
async function ro(e3, t2, n2) {
  if (!e3) return { ok: true, did: n2, bound: false };
  let r2 = await Z({ type: P, filter: { secretKind: A, targetOriginPrefix: e3 } });
  if (!r2.ok) return { ok: false, error: r2.error };
  let i2 = ur(r2.result.entries, e3, await ir(e3));
  if (i2.kind === `holder`) return { ok: true, did: n2, bound: false };
  if (i2.kind === `persona`) {
    let t3 = await os(e3, i2.entryId);
    return t3.ok ? { ok: true, entryId: i2.entryId, did: t3.did, bound: false } : { ok: false, error: t3.error };
  }
  let a2 = await q({ origin: e3, rpDid: t2, holderDid: n2, chooseProfile: true, allowHolder: true });
  if (!a2.approved || !a2.selectedDid) return { ok: false, error: `login denied by user` };
  if (a2.remember && await Qn(e3, t2), a2.selectedDid === `holder`) return await ar(e3), { ok: true, did: n2, bound: false };
  let o2 = await ls(e3, a2.selectedDid, t2);
  return o2.ok ? (await or(e3), { ok: true, entryId: o2.entryId, did: a2.selectedDid, bound: true }) : { ok: false, error: o2.error };
}
async function io(e3) {
  let t2 = await Nt();
  if (!t2) return { ok: false, error: `no active VTA connection \u2014 connect first` };
  let n2 = e3.origin ? await It(e3.origin, e3.params.controlDid) : { firstSeen: true, rpDidChanged: false, baseUrlChanged: false, pinnedRpDid: void 0 }, r2 = { origin: e3.origin, rpDid: e3.params.controlDid, holderDid: t2 };
  if (n2.rpDidChanged && n2.pinnedRpDid && (r2.changedFromRpDid = n2.pinnedRpDid), !await J(r2)) return { ok: false, error: `login denied by user` };
  e3.origin && await Rt(e3.origin, e3.params.controlDid);
  let i2 = await ro(e3.origin, e3.params.controlDid, t2);
  if (!i2.ok) return { ok: false, error: i2.error };
  await W();
  let a2 = await Q();
  if (!a2.ok) return { ok: false, error: a2.error };
  let o2 = { target: F, type: ri, vtaDid: a2.conn.vtaDid, params: e3.params, ...i2.entryId ? { entryId: i2.entryId } : {}, ...a2.conn.restBaseUrl ? { restBaseUrl: a2.conn.restBaseUrl } : {} }, s2 = await chrome.runtime.sendMessage(o2);
  return !s2.ok && i2.bound ? { ok: false, error: `${s2.error} \u2014 this was the first sign-in as ${i2.did}. If ${e3.origin ?? `the site`} refused it, that identity needs to be on its access list.` } : s2;
}
async function ao(e3) {
  if (!await Nt()) return { ok: false, error: `no active VTA connection \u2014 connect first` };
  let t2 = l(e3.origin, await w(e3.origin), e3.params);
  if (t2) return { ok: false, error: t2 };
  let n2 = await Q();
  if (!n2.ok) return { ok: false, error: n2.error };
  await W();
  let r2 = { target: F, type: ii, vtaDid: n2.conn.vtaDid, params: e3.params, origin: e3.origin };
  return await chrome.runtime.sendMessage(r2);
}
var oo = 500;
async function so(e3) {
  let t2 = e3.reason?.replace(/[\u0000-\u0008\u000B-\u001F\u007F\u200E\u200F\u202A-\u202E\u2066-\u2069]/g, ``).trim(), n2 = t2 && t2.length > oo ? `${t2.slice(0, oo)}\u2026` : t2, r2 = await w(e3.origin);
  return l(e3.origin, r2, { rpDid: e3.rpDid, baseUrl: e3.baseUrl }) ? { approved: false } : { approved: await J({ origin: e3.origin, rpDid: e3.rpDid, holderDid: e3.holderDid, stepUp: true, pinned: { ...r2?.baseUrl ? { baseUrl: r2.baseUrl } : {} }, ...n2 ? { reason: n2 } : {} }) };
}
var co = 2e4, lo = class extends Error {
  origin;
  code = fa;
  constructor(e3) {
    super(`access to ${ma(e3)} has not been granted \u2014 approve it in the wallet popup and retry`), this.origin = e3, this.name = `HostPermissionError`;
  }
};
async function uo(e3, t2) {
  if (ha(e3), !await z(e3)) throw new lo(e3);
  try {
    return await fetch(e3, { ...t2, redirect: `error`, signal: AbortSignal.timeout(co) });
  } catch (t3) {
    throw t3 instanceof DOMException && t3.name === `TimeoutError` ? Error(`request to ${e3} timed out after ${co / 1e3}s (VTA unreachable or not responding)`) : t3;
  }
}
async function fo(e3) {
  let t2 = await uo(e3.params.baseUrl.replace(/\/+$/, ``) + e3.params.path, { headers: { authorization: `Bearer ${e3.params.accessToken}` } }), n2 = await t2.text(), r2;
  try {
    r2 = JSON.parse(n2);
  } catch {
    r2 = n2;
  }
  return { ok: true, result: { status: t2.status, body: r2 } };
}
async function po() {
  return await W(), { ok: true, result: await chrome.runtime.sendMessage({ target: F, type: si }) };
}
async function mo() {
  try {
    return await chrome.runtime.sendMessage({ target: `offscreen`, type: `offscreen/transport-health` }) ?? { ok: true, result: { byVta: {}, sessions: [] } };
  } catch {
    return { ok: true, result: { byVta: {}, sessions: [] } };
  }
}
async function ho(e3) {
  return await W(), await chrome.runtime.sendMessage({ target: F, type: ci, vtaDid: e3.vtaDid });
}
async function go(e3) {
  return await W(), await chrome.runtime.sendMessage({ target: F, type: li, vtaDid: e3.vtaDid, adminScope: e3.adminScope, ...e3.context ? { context: e3.context } : {}, ...e3.personaHolder ? { personaHolder: true } : {} });
}
async function _o() {
  return await W(), await chrome.runtime.sendMessage({ target: F, type: ji });
}
async function vo(e3) {
  return await W(), await chrome.runtime.sendMessage({ target: F, type: ui, context: e3.context, adminScope: e3.adminScope, ...e3.createIfMissing ? { createIfMissing: true } : {}, ...e3.mediatorDid ? { mediatorDid: e3.mediatorDid } : {} });
}
async function yo() {
  return await W(), await chrome.runtime.sendMessage({ target: F, type: di });
}
async function bo(e3) {
  await W();
  let t2 = await chrome.runtime.sendMessage({ target: F, type: fi, prfOutputB64u: e3.prfOutputB64u });
  return t2.ok && (H(), V(`unlocked`)), t2;
}
async function xo(e3) {
  return await W(), await chrome.runtime.sendMessage({ target: F, type: mi, prfOutputB64u: e3.prfOutputB64u, vtaDid: e3.vtaDid });
}
async function So(e3) {
  return await W(), await chrome.runtime.sendMessage({ target: F, type: gi, ...e3.vtaDid ? { vtaDid: e3.vtaDid } : {} });
}
async function Co() {
  let e3 = await kt();
  if (e3.length === 0) return;
  let t2 = await j(), n2 = false;
  for (let r2 of e3) {
    let e4 = gr(t2, r2);
    if (e4?.source === `operator`) continue;
    let i2;
    try {
      let e5 = await wo({ type: Zr, vtaDid: r2 });
      if (!e5.ok) throw Error(e5.error);
      i2 = e5.result.mediatorDid;
    } catch (e5) {
      console.warn(`[pnm inbound] could not re-resolve the relay for`, r2, e5);
      continue;
    }
    if (!i2) {
      console.warn(`[pnm inbound]`, r2, `advertises no DIDComm relay \u2014 nothing can be pushed to this wallet through it.`);
      continue;
    }
    i2 !== e4?.did && (await _r(r2, { did: i2, source: `agent` }), n2 = true, console.info(`[pnm inbound]`, r2, `moved its relay:`, e4?.did ?? `(none)`, `\u2192`, i2));
  }
  n2 && await H();
}
async function wo(e3) {
  return await W(), await chrome.runtime.sendMessage({ target: F, type: _i, vtaDid: e3.vtaDid });
}
async function To(e3) {
  return await W(), await chrome.runtime.sendMessage({ target: F, type: hi, vtaDid: e3.vtaDid });
}
async function Eo() {
  let e3 = await Q();
  return e3.ok ? (await W(), await chrome.runtime.sendMessage({ target: F, type: vi, vtaDid: e3.conn.vtaDid, restBaseUrl: e3.conn.restBaseUrl })) : { ok: false, error: e3.error };
}
async function Do(e3) {
  let t2 = await Q();
  return t2.ok ? (await W(), await chrome.runtime.sendMessage({ target: F, type: yi, vtaDid: t2.conn.vtaDid, restBaseUrl: t2.conn.restBaseUrl, ...e3.contextId ? { contextId: e3.contextId } : {} })) : { ok: false, error: t2.error };
}
async function Oo(e3) {
  let t2 = await Q();
  return t2.ok ? (await W(), await chrome.runtime.sendMessage({ target: F, type: bi, vtaDid: t2.conn.vtaDid, restBaseUrl: t2.conn.restBaseUrl, id: e3.id, ...e3.name ? { name: e3.name } : {}, ...e3.description ? { description: e3.description } : {} })) : { ok: false, error: t2.error };
}
async function ko(e3) {
  return await W(), await chrome.runtime.sendMessage({ target: F, type: xi, did: e3.did });
}
function Ao(e3) {
  return /\/spec\/(.+)\/[\d.]+$/.exec(e3)?.[1] ?? e3;
}
async function jo(e3) {
  let t2 = await Q();
  if (!t2.ok) return { ok: false, error: t2.error };
  let r2 = n(e3.params.type);
  if (r2 !== null) return { ok: false, error: r2 };
  let i2 = ga(e3.origin, e3.params);
  if (!Da.consumeIfArmed(i2) && !(await q({ origin: e3.origin, action: `send a "${Ao(e3.params.type)}" request to your VTA`, noRemember: true })).approved) return { ok: false, error: `user denied the request` };
  await W();
  let a2 = await chrome.runtime.sendMessage({ target: F, type: Ei, vtaDid: t2.conn.vtaDid, restBaseUrl: t2.conn.restBaseUrl, origin: e3.origin, params: e3.params });
  if (a2.ok && a2.result?.kind === `consentRequired`) {
    let e4 = a2.result.payloadDigest;
    typeof e4 == `string` && e4 && Da.recordConsentRequired(i2, e4);
  }
  return a2.ok ? a2 : { ok: false, error: a2.error };
}
function Y(e3) {
  let t2 = chrome.runtime.getURL(``);
  return typeof e3.url == `string` && e3.url.startsWith(t2);
}
async function Mo(e3) {
  let t2 = await Q();
  return t2.ok ? (await W(), await chrome.runtime.sendMessage({ target: F, type: Ei, vtaDid: t2.conn.vtaDid, restBaseUrl: t2.conn.restBaseUrl, params: e3.params })) : { ok: false, error: t2.error };
}
async function No(e3) {
  let t2 = await Q();
  if (!t2.ok) return { ok: false, error: t2.error };
  await W();
  let n2 = await chrome.runtime.sendMessage({ target: F, type: Vi, hostDid: e3.hostDid });
  return n2.ok ? { ok: true, result: { endpoint: n2.endpoint, granted: await z(n2.endpoint), vtaDid: t2.conn.vtaDid, ...t2.conn.restBaseUrl ? { restBaseUrl: t2.conn.restBaseUrl } : {} } } : { ok: false, error: n2.error, ...n2.code ? { code: n2.code } : {} };
}
async function Po(e3) {
  let t2 = await Q();
  if (!t2.ok) return { ok: false, error: t2.error };
  if (e3.params.envelope?.type === `https://trusttasks.org/spec/auth/step-up/approve-response/0.6`) return Uo(e3, t2.conn.vtaDid, t2.conn.restBaseUrl);
  if (St(e3.params.envelope)) return Ho(e3, t2.conn.vtaDid, t2.conn.restBaseUrl);
  let n2 = a(e3.params.envelope, t2.conn.vtaDid);
  if (n2) return { ok: false, error: n2 };
  let { type: r2, recipient: i2 } = e3.params.envelope, o2 = c(e3.origin, await w(e3.origin), i2);
  return o2 ? { ok: false, error: o2 } : (await q({ origin: e3.origin, rpDid: i2, pinned: {}, ...e3.params.asDid ? { holderDid: e3.params.asDid } : {}, action: `Sign ${r2}`, noRemember: true })).approved ? (await W(), await chrome.runtime.sendMessage({ target: F, type: Ci, vtaDid: t2.conn.vtaDid, restBaseUrl: t2.conn.restBaseUrl, params: e3.params })) : { ok: false, error: `user denied signing` };
}
var Fo = `approver-statement:`;
async function X(e3) {
  return await W(), await chrome.runtime.sendMessage({ target: `offscreen`, type: `offscreen/step-up-approver`, ...e3 }) ?? { ok: false, error: `the offscreen document did not answer` };
}
async function Io(e3) {
  let t2 = crypto.randomUUID();
  await chrome.storage.session.set({ [`${Et}${t2}`]: e3 });
  let n2 = `${chrome.runtime.getURL(`confirm.html`)}?cid=${t2}&kind=approver`, r2 = await K(e3.kind === `stepUp` || e3.kind === `decision` ? 700 : 600);
  return new Promise((e4) => {
    let i2 = false, a2 = (n3, r3) => {
      i2 || (i2 = true, G.delete(t2), chrome.storage.session.remove(`${Et}${t2}`), e4(n3 && r3 ? { approved: true, prfOutputB64u: r3 } : { approved: false }));
    };
    G.set(t2, (e5, t3, n3) => a2(e5, n3)), B({ url: n2, bounds: r2, deny: () => a2(false), tag: `[pnm approver]`, what: `approver window` });
  });
}
async function Lo(e3, t2) {
  return gt(e3, await w(e3), t2);
}
async function Ro(e3) {
  let t2 = e3.params?.audience, n2 = await Lo(e3.origin, t2);
  if (n2) return { ok: false, error: n2 };
  let r2 = await X({ op: `identity`, audience: t2 });
  if (!r2.ok && r2.code === `step-up-approver/setup-required`) {
    let n3 = await Io({ kind: `setup`, origin: e3.origin, audience: t2 });
    if (!n3.approved) return { ok: false, error: `user denied approver setup` };
    r2 = await X({ op: `identity`, audience: t2, prfOutputB64u: n3.prfOutputB64u });
  }
  return r2.ok ? { ok: true, result: { approverDid: String(r2.result.approverDid) } } : { ok: false, error: r2.error };
}
async function zo(e3) {
  let t2 = e3.params, n2 = await Lo(e3.origin, t2?.audience);
  if (n2) return { ok: false, error: n2 };
  let r2 = await X({ op: `check-step-up`, params: t2 });
  if (!r2.ok) return { ok: false, error: r2.error };
  let i2 = await Io({ kind: `stepUp`, origin: e3.origin, audience: t2.audience, approverDid: String(r2.result.approverDid), subject: String(t2.request.subject), reason: typeof t2.request.reason == `string` ? t2.request.reason : ``, operation: { type: t2.operation.type, payload: t2.operation.payload }, challenge: String(t2.request.challenge), boundTo: String(r2.result.boundTo) });
  if (!i2.approved) return { ok: false, error: `user denied the step-up` };
  let a2 = await X({ op: `sign-step-up`, params: t2, prfOutputB64u: i2.prfOutputB64u });
  if (!a2.ok) return { ok: false, error: a2.error };
  let o2 = a2.result.statement, s2 = { statement: o2, origin: e3.origin, audience: t2.audience, subject: String(t2.request.subject), challenge: String(t2.request.challenge), expiresAt: Date.now() + ht };
  return await chrome.storage.session.set({ [`${Fo}${String(o2.id)}`]: s2 }), { ok: true, result: { statement: o2, approverDid: String(a2.result.approverDid) } };
}
async function Bo(e3) {
  let t2 = e3.params, n2 = await Lo(e3.origin, t2?.audience);
  if (n2) return { ok: false, error: n2 };
  let r2 = bt(t2?.purpose);
  if (r2) return { ok: false, error: r2 };
  let i2 = await X({ op: `identity`, audience: t2.audience }), a2 = await Io({ kind: `enrol`, origin: e3.origin, audience: t2.audience, ...i2.ok ? { approverDid: String(i2.result.approverDid) } : {}, subject: t2.subject, challenge: t2.challenge, boundTo: t2.boundTo });
  if (!a2.approved) return { ok: false, error: `user denied the approver enrolment` };
  let o2 = await X({ op: `sign-enrol`, params: t2, prfOutputB64u: a2.prfOutputB64u });
  return o2.ok ? { ok: true, result: { statement: o2.result.statement, approverDid: String(o2.result.approverDid) } } : { ok: false, error: o2.error };
}
async function Vo(e3) {
  let t2 = e3.params, n2 = await Lo(e3.origin, t2?.audience);
  if (n2) return { ok: false, error: n2 };
  let r2 = t2.decision?.reason;
  if (r2 !== void 0 && (typeof r2 != `string` || r2.length > 500)) return { ok: false, error: `decision.reason must be a string of at most 500 characters` };
  let i2 = await X({ op: `check-decision`, params: t2 });
  if (!i2.ok) return { ok: false, error: i2.error };
  let a2 = Tt(t2.action.summary), o2 = await Io({ kind: `decision`, origin: e3.origin, audience: t2.audience, approverDid: String(i2.result.approverDid), subject: t2.subject, operation: { type: t2.action.type, payload: t2.action.payload }, challenge: t2.decision.challenge, boundTo: String(i2.result.boundTo), decision: t2.decision.decision, ...r2 === void 0 ? {} : { reason: r2 }, ...a2 === void 0 ? {} : { summary: a2 }, ...t2.action.actionId === void 0 ? {} : { actionId: t2.action.actionId } });
  if (!o2.approved) return { ok: false, error: `user denied the decision` };
  let s2 = await X({ op: `sign-decision`, params: t2, prfOutputB64u: o2.prfOutputB64u });
  if (!s2.ok) return { ok: false, error: s2.error };
  let c2 = s2.result.statement, l2 = { statement: c2, origin: e3.origin, audience: t2.audience, subject: t2.subject, challenge: t2.decision.challenge, expiresAt: Date.now() + ht, purpose: `decision`, payloadDigest: t2.decision.payloadDigest, decision: t2.decision.decision, ...r2 === void 0 ? {} : { reason: r2 }, ...t2.action.actionId === void 0 ? {} : { actionId: t2.action.actionId } };
  return await chrome.storage.session.set({ [`${Fo}${String(c2.id)}`]: l2 }), { ok: true, result: { statement: c2, approverDid: String(s2.result.approverDid) } };
}
async function Ho(e3, t2, n2) {
  let r2 = xt(e3.params.envelope), i2 = r2 ? `${Fo}${r2}` : void 0, a2 = i2 ? (await chrome.storage.session.get(i2))[i2] : void 0, o2 = wt(e3.params.envelope, a2, e3.origin, e3.params.asDid);
  if (o2) return { ok: false, error: o2 };
  let s2 = e3.params.envelope.recipient, l2 = c(e3.origin, await w(e3.origin), s2);
  return l2 ? { ok: false, error: l2 } : (await chrome.storage.session.remove(i2), await W(), await chrome.runtime.sendMessage({ target: F, type: Ci, vtaDid: t2, restBaseUrl: n2, params: e3.params }));
}
async function Uo(e3, t2, n2) {
  let r2 = _t(e3.params.envelope), i2 = r2 ? `${Fo}${r2}` : void 0, a2 = i2 ? (await chrome.storage.session.get(i2))[i2] : void 0, o2 = yt(e3.params.envelope, a2, e3.origin, e3.params.asDid);
  if (o2) return { ok: false, error: o2 };
  let s2 = e3.params.envelope.recipient, l2 = c(e3.origin, await w(e3.origin), s2);
  return l2 ? { ok: false, error: l2 } : (await chrome.storage.session.remove(i2), await W(), await chrome.runtime.sendMessage({ target: F, type: Ci, vtaDid: t2, restBaseUrl: n2, params: e3.params }));
}
async function Wo() {
  let e3 = await j();
  return { ok: true, result: { ...e3.defaultStepUpVtaDid ? { stepUpVtaDid: e3.defaultStepUpVtaDid } : {}, ...e3.defaultStepUpVtaMediatorDid ? { stepUpVtaMediatorDid: e3.defaultStepUpVtaMediatorDid } : {} } };
}
async function Go() {
  let e3 = await Dt();
  return e3 ? (await W(), await chrome.runtime.sendMessage({ target: F, type: pi, vtaDid: e3 })) : { ok: true, result: { minted: false, running: false } };
}
var Ko = 262144;
async function qo(e3) {
  let t2 = e3.replace(/^https?:\/\//, ``), n2;
  try {
    n2 = await fetch(e3, { method: `GET`, headers: { Accept: `application/json, application/did+json;q=0.9, text/html;q=0.8` }, redirect: `follow`, signal: AbortSignal.timeout(15e3) });
  } catch (e4) {
    throw new R(ra, `Could not read ${t2}: ${e4 instanceof Error ? e4.message : String(e4)}. Either the name's server is unreachable, or it answered with a bare did: redirect, which a browser is not allowed to read \u2014 paste the full did:\u2026 instead.`);
  }
  if (n2.type === `opaqueredirect`) throw new R(ra, `${t2} answered with a redirect the browser will not expose. Paste the full did:\u2026 instead.`);
  let r2 = await Jo(n2, Ko);
  return { status: n2.status, url: n2.url || e3, ...r2 ? { body: r2 } : {} };
}
async function Jo(e3, t2) {
  let n2 = e3.body?.getReader();
  if (!n2) return (await e3.text()).slice(0, t2);
  let r2 = new TextDecoder(), i2 = ``;
  try {
    for (; i2.length < t2; ) {
      let { done: e4, value: t3 } = await n2.read();
      if (e4) break;
      i2 += r2.decode(t3, { stream: true });
    }
  } finally {
    await n2.cancel().catch(() => {
    });
  }
  return i2.slice(0, t2);
}
async function Yo(e3) {
  try {
    let { did: t2, name: n2 } = await da(e3.name, { fetchName: qo, resolveDid: async (e4) => {
      let t3 = await Xo({ type: Xr, did: e4 });
      return t3.ok ? { resolved: t3.result.resolved, ...t3.result.alsoKnownAs ? { alsoKnownAs: t3.result.alsoKnownAs } : {}, ...t3.result.error ? { error: t3.result.error } : {} } : { resolved: false, error: t3.error };
    } });
    return { ok: true, result: { did: t2, name: n2.canonical } };
  } catch (e4) {
    if (e4 instanceof R) return { ok: false, error: e4.message, code: e4.code };
    throw e4;
  }
}
async function Xo(e3) {
  await W();
  let t2 = await chrome.runtime.sendMessage({ target: F, type: wi, did: e3.did });
  return t2.ok ? { ok: true, result: t2.result } : { ok: false, error: t2.error };
}
async function Z(e3) {
  let t2 = await Q();
  return t2.ok ? (await W(), await chrome.runtime.sendMessage({ target: F, type: Ti, vtaDid: t2.conn.vtaDid, restBaseUrl: t2.conn.restBaseUrl, ...e3.filter ? { filter: e3.filter } : {} })) : { ok: false, error: t2.error };
}
async function Q() {
  let e3 = await Zo();
  return e3 ? !e3.restBaseUrl && !e3.mediatorDid ? { ok: false, error: `active VTA advertises no usable transport (#vta-rest or #vta-didcomm)` } : { ok: true, conn: { vtaDid: e3.vtaDid, restBaseUrl: e3.restBaseUrl ?? `` } } : { ok: false, error: `no active VTA connection \u2014 connect first` };
}
async function Zo() {
  let e3 = (await chrome.storage.local.get(`pnm-connection/v3`))[`pnm-connection/v3`];
  if (typeof e3 != `string`) return null;
  let t2;
  try {
    t2 = JSON.parse(e3);
  } catch {
    return null;
  }
  let n2 = t2?.state?.connections;
  if (!n2?.activeVtaDid) return null;
  let r2 = n2.vtas?.[n2.activeVtaDid];
  return r2?.vtaDid ? { vtaDid: r2.vtaDid, ...r2.restBaseUrl ? { restBaseUrl: r2.restBaseUrl } : {}, ...r2.mediatorDid ? { mediatorDid: r2.mediatorDid } : {} } : null;
}
async function Qo() {
  let e3 = (await chrome.storage.local.get(`pnm-connection/v3`))[`pnm-connection/v3`];
  if (typeof e3 != `string`) return [];
  try {
    let t2 = JSON.parse(e3);
    return Object.values(t2.state?.connections?.vtas ?? {}).filter((e4) => typeof e4?.vtaDid == `string`).map((e4) => ({ vtaDid: e4.vtaDid, ...e4.restBaseUrl ? { restBaseUrl: e4.restBaseUrl } : {} }));
  } catch {
    return [];
  }
}
async function $o(e3) {
  let t2 = await Q();
  if (!t2.ok) return { ok: false, error: t2.error };
  await W();
  let { type: n2, ...r2 } = e3;
  return await chrome.runtime.sendMessage({ target: F, type: Di, vtaDid: t2.conn.vtaDid, restBaseUrl: t2.conn.restBaseUrl, body: r2 });
}
async function es(e3) {
  let t2 = await Q();
  if (!t2.ok) return { ok: false, error: t2.error };
  await W();
  let { type: n2, ...r2 } = e3;
  return await chrome.runtime.sendMessage({ target: F, type: Oi, vtaDid: t2.conn.vtaDid, restBaseUrl: t2.conn.restBaseUrl, body: r2 });
}
async function ts(e3) {
  let t2 = await Q();
  if (!t2.ok) return { ok: false, error: t2.error };
  await W();
  let { type: n2, ...r2 } = e3;
  return await chrome.runtime.sendMessage({ target: F, type: ki, vtaDid: t2.conn.vtaDid, restBaseUrl: t2.conn.restBaseUrl, body: r2 });
}
async function ns(e3) {
  let t2 = await Q();
  if (!t2.ok) return { ok: false, error: t2.error };
  await W();
  let { type: n2, ...r2 } = e3;
  return await chrome.runtime.sendMessage({ target: F, type: Ai, vtaDid: t2.conn.vtaDid, restBaseUrl: t2.conn.restBaseUrl, body: r2 });
}
async function rs(e3) {
  return await J({ origin: e3.origin, action: `See your wallet's vault entries`, ...e3.params.targetDid ? { rpDid: e3.params.targetDid } : {} }) ? Z({ type: P, filter: { ...e3.params.targetDid === void 0 ? {} : { targetDid: e3.params.targetDid }, ...e3.params.targetOriginPrefix === void 0 ? {} : { targetOriginPrefix: e3.params.targetOriginPrefix }, ...e3.params.secretKind === void 0 ? {} : { secretKind: e3.params.secretKind } } }) : { ok: false, error: `vault list denied by user` };
}
async function is(e3) {
  let t2 = e3.params.target, n2 = t2?.kind === `did` ? t2.did : void 0, r2 = await cs(e3.origin, e3.params.entryId);
  if (!r2.ok) return { ok: false, error: r2.error };
  let i2 = n2 ? await It(e3.origin, n2) : void 0, a2 = i2?.rpDidChanged ? i2.pinnedRpDid : void 0, o2 = async () => {
    n2 && await Rt(e3.origin, n2);
  };
  if (r2.entryId) return await J({ origin: e3.origin, action: `Sign in via your VTA (proxied SIOP)`, ...n2 ? { rpDid: n2 } : {}, ...a2 ? { changedFromRpDid: a2 } : {} }) ? (await o2(), ss({ ...e3.params, entryId: r2.entryId })) : { ok: false, error: `proxy-login denied by user` };
  let s2 = await q({ origin: e3.origin, action: `Sign in via your VTA (proxied SIOP)`, chooseProfile: true, ...n2 ? { rpDid: n2 } : {}, ...a2 ? { changedFromRpDid: a2 } : {} });
  if (!s2.approved || !s2.selectedDid) return { ok: false, error: `proxy-login denied by user` };
  let c2 = await ls(e3.origin, s2.selectedDid, n2);
  if (!c2.ok) return { ok: false, error: c2.error };
  await o2(), s2.remember && await Qn(e3.origin, n2);
  let l2 = await ss({ ...e3.params, entryId: c2.entryId });
  return l2.ok ? l2 : { ok: false, error: `${l2.error} \u2014 this was the first sign-in as ${s2.selectedDid}. If ${e3.origin} refused it, that identity needs to be on the site's access list.` };
}
async function as(e3) {
  let t2 = e3.params.target, n2 = t2?.kind === `did` ? t2.did : void 0, r2 = await cs(e3.origin);
  if (!r2.ok) return { ok: false, error: r2.error };
  if (r2.entryId) {
    let t3 = await os(e3.origin, r2.entryId);
    return t3.ok ? { ok: true, result: { did: t3.did, entryId: r2.entryId, bound: false } } : { ok: false, error: t3.error };
  }
  let i2 = await q({ origin: e3.origin, action: `Choose the identity this site knows you as`, chooseProfile: true, ...n2 ? { rpDid: n2 } : {} });
  if (!i2.approved || !i2.selectedDid) return { ok: false, error: `identity selection denied by user` };
  let a2 = await ls(e3.origin, i2.selectedDid, n2);
  return a2.ok ? (i2.remember && await Qn(e3.origin, n2), { ok: true, result: { did: i2.selectedDid, entryId: a2.entryId, bound: true } }) : { ok: false, error: a2.error };
}
async function os(e3, t2) {
  let n2 = await Z({ type: P, filter: { secretKind: A, targetOriginPrefix: e3 } });
  if (!n2.ok) return { ok: false, error: n2.error };
  let r2 = n2.result.entries.find((e4) => e4.id === t2);
  return r2?.principalDid ? { ok: true, did: r2.principalDid } : { ok: false, error: `vault entry ${t2} names no persona DID` };
}
async function ss(e3) {
  let t2 = await Q();
  return t2.ok ? (await W(), await chrome.runtime.sendMessage({ target: F, type: Ai, vtaDid: t2.conn.vtaDid, restBaseUrl: t2.conn.restBaseUrl, body: e3 })) : { ok: false, error: t2.error };
}
async function cs(e3, t2) {
  if (t2) return { ok: true, entryId: t2 };
  let n2 = await Z({ type: P, filter: { secretKind: A, targetOriginPrefix: e3 } });
  if (!n2.ok) return { ok: false, error: n2.error };
  let r2 = sr(n2.result.entries, e3);
  return { ok: true, ...r2 ? { entryId: r2.id } : {} };
}
async function ls(e3, t2, n2) {
  return dr({ listDids: async () => {
    let e4 = await Do({ type: Qr });
    if (!e4.ok) throw Error(e4.error);
    return e4.result.dids;
  }, deriveSigningKeyIds: async (e4) => {
    let t3 = await ko({ type: $r, did: e4 });
    if (!t3.ok) throw Error(t3.error);
    return t3.result;
  }, upsert: async (e4) => {
    let t3 = await $o({ type: ei, ...e4 });
    if (!t3.ok) throw Error(t3.error);
    return { entryId: t3.result.entry.id };
  } }, { origin: e3, did: t2, ...n2 ? { rpDid: n2 } : {} });
}
async function us(e3) {
  let t2 = await uo(e3.params.baseUrl.replace(/\/+$/, ``) + e3.params.path, { method: `POST`, headers: { "content-type": `application/json`, authorization: `Bearer ${e3.params.accessToken}` }, body: JSON.stringify(e3.params.body) }), n2 = await t2.text(), r2;
  try {
    r2 = JSON.parse(n2);
  } catch {
    r2 = n2;
  }
  return { ok: true, result: { status: t2.status, body: r2 } };
}
var ds = new Set(Li), $ = `sign-in-flow:`;
async function fs(e3) {
  let t2 = typeof e3.did == `string` ? Ea(e3.did) : void 0;
  if (!t2 || t2 !== e3.did.trim()) return { ok: false, error: `That isn't a DID.` };
  let n2 = e3.source === `page` || e3.source === `camera` || e3.source === `image` ? e3.source : `pasted`, r2 = await Q();
  if (!r2.ok) return { ok: false, error: r2.error };
  let i2 = crypto.randomUUID(), a2 = { joinDid: t2, joinSource: n2 };
  return await chrome.storage.session.set({ [`${$}${i2}`]: a2 }), B({ url: `${chrome.runtime.getURL(`confirm.html`)}?kind=sign-in&flow=${i2}`, bounds: await K(660, 560), deny: () => void hs(i2), tag: `[pnm join]`, what: `join window` }), { ok: true };
}
async function ps(e3, t2) {
  let n2 = typeof e3.link == `string` ? e3.link : ``;
  if (!Ca(n2)) return;
  let r2 = re(n2, { now: Math.floor(Date.now() / 1e3) });
  if (!r2.ok && r2.outcome === `pass-on`) return;
  if (!(await Q()).ok) {
    t2 !== void 0 && await chrome.tabs.update(t2, { url: n2 }).catch(() => void 0);
    return;
  }
  let i2 = crypto.randomUUID(), a2 = { link: e3.link, origin: e3.origin };
  await chrome.storage.session.set({ [`${$}${i2}`]: a2 }), B({ url: `${chrome.runtime.getURL(`confirm.html`)}?kind=sign-in&flow=${i2}`, bounds: await K(660, 560), deny: () => void hs(i2), tag: `[pnm sign-in]`, what: `sign-in window` });
}
async function ms(e3) {
  if (typeof e3.requestId != `string` || typeof e3.matchNumber != `string` || !/^[0-9]{2}$/.test(e3.matchNumber)) return;
  let t2 = await chrome.storage.session.get(null);
  for (let [n2, r2] of Object.entries(t2)) {
    if (!n2.startsWith($)) continue;
    let t3 = r2;
    if (!(`link` in t3) || t3.origin !== e3.origin) continue;
    let i2 = re(t3.link, { now: 0 });
    i2.ok && i2.link.id === e3.requestId && (await W(), await chrome.runtime.sendMessage({ target: F, type: Ri, flowId: n2.slice(13), matchNumber: e3.matchNumber }));
  }
}
async function hs(e3) {
  let t2 = `${$}${e3}`, n2 = (await chrome.storage.session.get(t2))[t2] !== void 0;
  if (await chrome.storage.session.remove(t2), n2) try {
    await W(), await chrome.runtime.sendMessage({ target: F, type: zi, flowId: e3, vtaDid: ``, step: `cancel` });
  } catch {
  }
}
async function gs(e3) {
  let t2 = await Qo();
  await W();
  let { type: n2, ...r2 } = e3;
  return await chrome.runtime.sendMessage({ ...r2, target: `offscreen`, type: `offscreen/uv-settings`, agents: t2 }) ?? { ok: false, error: `The wallet's background document didn't answer.` };
}
async function _s(e3) {
  let t2 = `${$}${e3.flowId}`, n2 = (await chrome.storage.session.get(t2))[t2];
  if (!n2) return { ok: true, result: { kind: `failed`, code: `sign-in/out-of-order`, message: `Refresh the code on the website and try again.` } };
  let r2 = await Q();
  if (!r2.ok) return { ok: false, error: r2.error };
  await W();
  let { type: i2, flowId: a2, ...o2 } = e3, s2 = { ...o2, target: F, type: zi, flowId: a2, vtaDid: r2.conn.vtaDid, ...r2.conn.restBaseUrl ? { restBaseUrl: r2.conn.restBaseUrl } : {}, ...e3.step === `prepare` ? `link` in n2 ? { link: n2.link, origin: n2.origin } : { joinDid: n2.joinDid, joinSource: n2.joinSource } : {} }, c2 = await chrome.runtime.sendMessage(s2);
  return c2?.ok && c2.result.kind === `failed` && console.warn(`[pnm sign-in] step failed`, wa(e3.step, c2.result)), c2.ok && (c2.result.kind === `done` || c2.result.kind === `refused` || c2.result.kind === `not-member` || c2.result.kind === `join-elsewhere` || c2.result.kind === `join-pending` || c2.result.kind === `join-admitted` || c2.result.kind === `already-member` || c2.result.kind === `not-a-community`) && await chrome.storage.session.remove(t2), c2;
}
chrome.runtime.onMessage.addListener((e3, t2, n2) => {
  if (t2.id !== chrome.runtime.id) return console.warn(`[background] rejecting message from foreign sender id=${t2.id} url=${t2.url}`), n2({ ok: false, error: `foreign sender rejected` }), false;
  if (e3?.target === `offscreen`) return false;
  let r2 = e3?.type;
  if (r2 === `vta-wallet/trigger-link`) {
    let n3 = ft(t2);
    if (!n3 || Y(t2) || e3.origin !== n3) return false;
  }
  if (r2 && ds.has(r2)) {
    let i2 = ft(t2);
    if (!i2) return console.warn(`[background] rejecting page-facing ${r2} with no browser-attested origin`), n2({ ok: false, error: `no attested origin` }), false;
    e3.origin = i2;
  }
  if (r2 === `vta-wallet/trigger-link-number`) return Y(t2) || ms(e3).catch(() => void 0), false;
  if (r2 === `vta-wallet/trigger-link`) return ps(e3, t2.tab?.id).catch(() => void 0), false;
  if (r2 === `vta-wallet/join-community`) return Y(t2) ? (fs(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : (n2({ ok: false, error: `a join starts from the wallet's own window` }), false);
  if (r2 === `vta-wallet/sign-in-step`) return Y(t2) ? (_s(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : (n2({ ok: false, error: `sign-in steps come from the wallet's own window` }), false);
  if (r2 === `vta-wallet/uv-settings`) return Y(t2) ? (gs(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : (n2({ ok: false, error: `sign-in approval settings are the wallet's own` }), false);
  if (r2 === `vta-wallet/directory-page`) {
    let t3 = e3;
    return Ua.handle(t3.origin, t3.params).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  }
  if (r2 === `vta-wallet/membership-page`) {
    let t3 = e3;
    return Wa.handle(t3.origin, t3.params).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  }
  if (r2 === `vta-wallet/rooms-page`) {
    let t3 = e3;
    return Va.handle(t3.origin, t3.params).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  }
  if (e3?.type === `vta-wallet/api-get`) return fo(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/api-post`) return us(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/mediator-status`) return po().then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/run-diagnostics`) return ho(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/transport-health`) return mo().then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/emit-wallet-event`) {
    let t3 = e3;
    if (t3.event === `consentgranted`) {
      let e4 = t3.detail?.payloadDigest;
      typeof e4 == `string` && e4 && Da.recordGranted(e4);
    }
    return V(t3.event, t3.detail), false;
  }
  if (e3?.type === `vta-wallet/notify`) {
    if (!Y(t2)) return false;
    let n3 = e3;
    return chrome.notifications.create({ type: `basic`, iconUrl: chrome.runtime.getURL(`icon-128.png`), title: String(n3.title), message: String(n3.message), priority: 2 }, () => void chrome.runtime.lastError), false;
  }
  if (e3?.type === `vta-wallet/onboard-prepare`) return go(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/onboard-contexts`) return _o().then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/onboard-connect`) return vo(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/holder-state`) return yo().then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/unlock-prf`) return bo(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/unlock-approver`) return xo(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/refresh-vta-transports`) return wo(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/forget-holder-record`) return To(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/restart-inbox`) return H().then(() => n2({ ok: true })).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/lock-state`) return So(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/list-contexts`) return Eo().then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/list-dids`) return Do(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/create-context`) return Oo(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/derive-signing-key-id`) return ko(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true;
  if (e3?.type === `vta-wallet/task-consent`) {
    let t3 = e3;
    return to(t3.request, t3.approver === true).then(n2).catch(() => n2({ approved: false })), true;
  }
  if (e3?.type === `vta-wallet/step-up-consent`) return so(e3).then(n2).catch(() => n2({ approved: false })), true;
  if (e3?.type === `vta-wallet/disclosure-step-up-consent`) return Za(e3).then(n2).catch(() => n2({ approved: false })), true;
  if (e3?.type === `vta-wallet/mediator-lens`) return Y(t2) ? ((async () => (await W(), await chrome.runtime.sendMessage({ target: F, type: Ii, op: e3.op })))().then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : (console.warn(`[background] rejecting ${Fi} from non-extension sender url=${t2.url}`), n2({ ok: false, error: `mediator surface is not page-reachable` }), false);
  if (e3?.type === `vta-wallet/room-offers`) {
    if (!Y(t2)) return console.warn(`[background] rejecting ${Ui} from non-extension sender url=${t2.url}`), n2({ ok: false, error: `room offers are not page-reachable` }), false;
    let { params: r3 } = e3;
    return (r3?.op === `accept` ? Ba.accept({ communityDid: r3.communityDid, member: r3.member, roomId: r3.roomId }) : Ba.overview({ force: r3?.op === `overview` && r3.force === true })).then((e4) => n2({ ok: true, result: e4 })).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4), ...e4 instanceof k && e4.code ? { code: e4.code } : {} })), true;
  }
  return e3?.type === `vta-wallet/room-files-prepare` ? Y(t2) ? (No(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : (console.warn(`[background] rejecting ${Bi} from non-extension sender url=${t2.url}`), n2({ ok: false, error: `room files are not page-reachable` }), false) : e3?.type === `vta-wallet/manager-task` ? Y(t2) ? (Mo(e3).then(n2).catch((e4) => n2(Ki(e4))), true) : (console.warn(`[background] rejecting ${Pi} from non-extension sender url=${t2.url}`), n2({ ok: false, error: `manager surface is not page-reachable` }), false) : e3?.type === `vta-wallet/disclose` ? (Ya(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/request-task` ? (jo(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/approver-identity` ? (Ro(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/approve-step-up` ? (zo(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/approve-decision` ? (Vo(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/attest-approver` ? (Bo(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/sign-trust-task` ? (Po(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/vault-list` ? (Z(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/vault-upsert` ? ($o(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/vault-delete` ? (es(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/vault-release` ? (ts(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/vault-proxy-login` ? (ns(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/wallet-profile` ? (as(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/vault-proxy-login-page` ? (is(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/vault-list-page` ? (rs(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/lock-wallet` ? (Nr.lock(), chrome.runtime.sendMessage({ target: F, type: ai }).catch(() => {
  }), V(`locked`), n2({ ok: true }), false) : e3?.type === `vta-wallet/wallet-defaults` ? (Wo().then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/login` ? (no(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/login-didcomm` ? (io(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/approver-state` ? (Go().then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/resolve-agent-name` ? (Yo(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/verify-rp-did` ? (Xo(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : e3?.type === `vta-wallet/step-up-vta` ? (ao(e3).then(n2).catch((e4) => n2({ ok: false, error: e4 instanceof Error ? e4.message : String(e4) })), true) : (e3?.type === `vta-wallet/consent-result` && n2({ ok: true, matched: ba(G, e3) }), false);
});
