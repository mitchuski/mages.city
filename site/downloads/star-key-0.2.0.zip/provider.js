var e = `vta-wallet/inpage`, t = /* @__PURE__ */ new Map();
window.addEventListener(`message`, (e2) => {
  if (e2.source !== window) return;
  let n2 = e2.data;
  if (!n2 || n2.source !== `vta-wallet/content`) return;
  if (`kind` in n2 && n2.kind === `event`) {
    window.dispatchEvent(new CustomEvent(`vtawallet:${n2.event}`, { detail: n2.detail }));
    return;
  }
  if (`kind` in n2 && n2.kind === `roomFile`) {
    let e3 = n2;
    a.get(e3.id)?.(e3.msg);
    return;
  }
  if (!(`id` in n2)) return;
  let r2 = t.get(n2.id);
  r2 && (t.delete(n2.id), n2.ok ? r2.resolve(n2.result) : r2.reject(Error(n2.error)));
});
function n(n2, r2) {
  let i2 = crypto.randomUUID();
  return new Promise((a2, o2) => {
    t.set(i2, { resolve: (e2) => a2(e2), reject: o2 }), window.postMessage({ source: e, id: i2, method: n2, params: r2 }, window.origin);
  });
}
var r = /* @__PURE__ */ new Set();
function i(e2, t2) {
  return r.has(e2) || (r.add(e2), console.warn(`[vtaWallet] ${e2}() is deprecated legacy sign-in. Use wallet sign-in with a trigger link (a clickable auth/oob sign-in code); keep ${e2}() behind an "Using an older wallet?" link.`)), t2();
}
var a = /* @__PURE__ */ new Map(), o = 262144;
function s(e2) {
  let t2 = ``;
  for (let n2 = 0; n2 < e2.length; n2 += 32768) t2 += String.fromCharCode(...e2.subarray(n2, n2 + 32768));
  return btoa(t2).replace(/\+/g, `-`).replace(/\//g, `_`).replace(/=+$/, ``);
}
function c(e2) {
  let t2 = e2.length % 4 == 0 ? `` : `=`.repeat(4 - e2.length % 4), n2 = atob(e2.replace(/-/g, `+`).replace(/_/g, `/`) + t2), r2 = new Uint8Array(n2.length);
  for (let e3 = 0; e3 < n2.length; e3++) r2[e3] = n2.charCodeAt(e3);
  return r2;
}
function l(t2, n2) {
  window.postMessage({ source: e, kind: `roomFile`, id: t2, msg: n2 }, window.origin);
}
function u(e2) {
  let t2 = crypto.randomUUID(), { onProgress: n2, ...r2 } = e2;
  return new Promise((e3, i2) => {
    let o2 = [], s2;
    a.set(t2, (r3) => {
      switch (r3.kind) {
        case `progress`:
          n2?.({ stage: r3.stage, ...r3.done === void 0 ? {} : { done: r3.done }, ...r3.total === void 0 ? {} : { total: r3.total } });
          return;
        case `got`:
          s2 = r3;
          return;
        case `data`:
          o2.push(c(r3.data));
          return;
        case `done`: {
          if (a.delete(t2), l(t2, { kind: `cancel` }), !s2) return i2(Error(`the wallet finished a download it never described`));
          let { kind: n3, ...r4 } = s2, c2 = s2.file.mediaType ?? `application/octet-stream`;
          e3({ ...r4, blob: new Blob(o2, { type: c2 }) });
          return;
        }
        case `failed`:
          a.delete(t2), i2(Error(r3.error));
          return;
        case `closed`:
          a.delete(t2), i2(Error(`the wallet stopped the download`));
          return;
        default:
          return;
      }
    }), l(t2, { kind: `get`, hostDid: r2.hostDid, roomId: r2.roomId, key: r2.key });
  });
}
function d(e2) {
  let t2 = crypto.randomUUID(), { onProgress: n2, file: r2, ...i2 } = e2;
  return new Promise((e3, c2) => {
    a.set(t2, (i3) => {
      switch (i3.kind) {
        case `progress`:
          n2?.({ stage: i3.stage, ...i3.done === void 0 ? {} : { done: i3.done }, ...i3.total === void 0 ? {} : { total: i3.total } });
          return;
        case `ready`:
          (async () => {
            for (let e4 = 0; e4 < r2.size; e4 += o) {
              let n3 = new Uint8Array(await r2.slice(e4, e4 + o).arrayBuffer());
              l(t2, { kind: `data`, data: s(n3) });
            }
            l(t2, { kind: `end` });
          })().catch((e4) => {
            a.delete(t2), l(t2, { kind: `cancel` }), c2(e4 instanceof Error ? e4 : Error(String(e4)));
          });
          return;
        case `put`:
          a.delete(t2), l(t2, { kind: `cancel` }), e3({ key: i3.key, version: i3.version, size: i3.size });
          return;
        case `failed`:
          a.delete(t2), c2(Error(i3.error));
          return;
        case `closed`:
          a.delete(t2), c2(Error(`the wallet stopped the upload`));
          return;
        default:
          return;
      }
    }), l(t2, { kind: `put`, hostDid: i2.hostDid, roomId: i2.roomId, name: i2.name, size: r2.size, ...r2.type ? { mediaType: r2.type } : {}, ...i2.title === void 0 ? {} : { title: i2.title }, ...i2.description === void 0 ? {} : { description: i2.description }, ...i2.tags === void 0 ? {} : { tags: i2.tags } });
  });
}
window.vtaWallet || (window.vtaWallet = { login: (e2) => i(`login`, () => n(`login`, e2)), loginDidcomm: (e2) => i(`loginDidcomm`, () => n(`loginDidcomm`, e2)), stepUpVta: (e2) => n(`stepUpVta`, e2), apiGet: (e2) => n(`apiGet`, e2), apiPost: (e2) => n(`apiPost`, e2), mediatorStatus: () => n(`mediatorStatus`, {}), walletDefaults: () => n(`walletDefaults`, {}), signTrustTask: (e2) => n(`signTrustTask`, e2), proxyLogin: (e2) => i(`proxyLogin`, () => n(`proxyLogin`, e2)), walletProfile: (e2) => n(`walletProfile`, e2), vaultList: (e2) => n(`vaultList`, e2), requestTask: (e2) => n(`requestTask`, e2), approverIdentity: (e2) => n(`approverIdentity`, e2), approveStepUp: (e2) => n(`approveStepUp`, e2), attestApprover: (e2) => n(`attestApprover`, e2), approveDecision: (e2) => n(`approveDecision`, e2), rooms: { list: (e2) => n(`rooms`, { op: `list`, hostDid: e2.hostDid }), choose: (e2) => n(`rooms`, { op: `choose`, hostDid: e2.hostDid, ...e2.suggest === void 0 ? {} : { suggest: e2.suggest }, ...e2.member === void 0 ? {} : { member: e2.member } }), forget: (e2) => n(`rooms`, { op: `forget`, hostDid: e2.hostDid, roomId: e2.roomId }), info: (e2) => n(`rooms`, { op: `info`, hostDid: e2.hostDid, roomId: e2.roomId }), browse: (e2) => n(`rooms`, { ...e2, op: `browse` }), read: (e2) => n(`rooms`, { op: `read`, hostDid: e2.hostDid, roomId: e2.roomId, key: e2.key }), putNote: (e2) => n(`rooms`, { ...e2, op: `putNote` }), offers: (e2) => n(`rooms`, { op: `offers`, hostDid: e2.hostDid }), acceptOffer: (e2) => n(`rooms`, { op: `acceptOffer`, hostDid: e2.hostDid, roomId: e2.roomId, ...e2.member === void 0 ? {} : { member: e2.member } }), getFile: u, putFile: d }, directory: { publishCard: (e2) => n(`directory`, { op: `publishCard`, hostDid: e2.hostDid, ...e2.member === void 0 ? {} : { member: e2.member } }) }, membership: { status: (e2) => n(`membership`, { op: `status`, hostDid: e2.hostDid }) } });
